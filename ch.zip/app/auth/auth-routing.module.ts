// import { LoginComponent } from './container/login/login.component';
import { SignupFormComponent } from './components/signup-form/signup-form.component';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { InvalidKeyTokenComponent } from './components/invalid-key-token/invalid-key-token.component';

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VerificationFormComponent } from './components/verification-form/verification-form.component';

const routes: Routes = [
  {path: '', redirectTo: 'auth', pathMatch: 'full'},
  {
    path: 'auth', children: 
      [
        {path: '', component: LoginComponent},
        {path: 'login', component: LoginComponent},
        {path: 'signup', component: SignupFormComponent},
        {path: 'resetpassword/:key', component: ResetPasswordComponent},
        {path: 'forgetpassword', component: ForgetPasswordComponent},
        {path: 'accountverify', component: VerificationFormComponent},
        {path: 'accountverify/:key', component: VerificationFormComponent},
        {path: 'invalidkey', component: InvalidKeyTokenComponent}
      ]
  }
];
  
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
