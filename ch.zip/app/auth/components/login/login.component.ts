import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { AuthBusiness } from '../../business/auth.business';
import { Login } from '../../models/user';

import { Router, ActivatedRoute } from '@angular/router';

import {Config, UserAccountStatus } from '../../../config/constant';
import { debuglog } from 'util';
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { UserDetailMessage } from "@app/config/constant"
import { ApiUrl } from '../../../../environments/environment';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  private apiUrl = ApiUrl;

  loginForm: FormGroup;
  formSubmit = false;
  private errorMessage : any;
  //validater custom variable
  // alphaNumericPattern = '[a-zA-Z0-9]+';
  // emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  // passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,15}$';
  msg_code;
  controlEmail;
  controlPassword;
  //validater custom variable
  private userDetailMessage:UserDetailMessage;
  // login: Login = {
  //   email: "",
  //   password: ""
  // }
  // private login: Login;

  public loading = false;

  public userData: any;
  public mytoken: any;
  constructor(private config: Config, private fb: FormBuilder, public authBusiness: AuthBusiness, private router: Router,private userDetailService: UserDetailService) {
    this.userDetailMessage = new UserDetailMessage(); }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    const email = '';
    const password = '';
    this.loginForm = this.fb.group({
      email: ['', 
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.config.emailPattern)
          ]
        )
      ],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(15),
        Validators.pattern(this.config.passwordAlphaNumericPattern)
      ]
      )]
    }
    );
  }

  onSubmit() {
    const values = this.loginForm.value;
    const keys = Object.keys(values);
    this.formSubmit = true;
    // console.log(values);
    if (this.loginForm.valid) {
      this.loading = true;
      let resetMessage = this.authBusiness.login(values).subscribe(result => {
        this.mytoken = result._body;
        this.loading = false;
        if(result.token){
          // localStorage.setItem('authToken', result.token);
          // localStorage.setItem('user_subscription_contactId', result.contactId);
          // localStorage.setItem('user_channelstatus', result.channelStatusId);
          this.errorMessage = "";
          // console.log('result.statusID',result.statusID);
          if (result.channelStatusId != undefined) {
            if (result.channelStatusId == UserAccountStatus.VERIFICATION ||
              result.channelStatusId == UserAccountStatus.REVERIFICATION ||
              result.channelStatusId == UserAccountStatus.REVERIFICATION_MAILCHANGE) {
                this.userDetailMessage.email = values.email;
                this.userDetailMessage.action = this.apiUrl.VERIFICATIONPENDING;
                this.userDetailService.onUserDetailChange(this.userDetailMessage);
                this.router.navigate(['auth/accountverify']);
            this.router.navigate(['auth/accountverify']);
          }
          else if (result.channelStatusId == UserAccountStatus.SUBSCRIPTION) {
            this.router.navigate(['user_profile_selection']);
          }
          else {
            this.router.navigate(['home/home']);
          }
        }
        else {
          this.router.navigate(['home/home']);
        }

        }else{
          this.errorMessage = "Please check your email and password.";
        }
      },
        (error) => {
          console.log(error);
        });

    } else {
      keys.forEach(val => {
        const ctrl = this.loginForm.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        };
      });
    }
  }

}