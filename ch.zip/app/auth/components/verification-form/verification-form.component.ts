import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { AuthBusiness } from '../../business/auth.business';
// import { UserDetailService } from "../../services/user-detail.service";
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { SuccesErrorMessage, UserDetailMessage, Config, UserAccountStatus } from '@app/config/constant';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ApiUrl,AppLocalStorageKeys } from '../../../../environments/environment';
import { ValidationService } from '@app/shared/shared-service/validation-service';

@Component({
  selector: 'accountverify',
  templateUrl: './verification-form.component.html',
  styleUrls: ['./verification-form.component.scss']
})
export class VerificationFormComponent implements OnInit {
  private apiUrl = ApiUrl;
  public loading = false;
  private email: string;
  isChangeEmailHidden: boolean;
  verifyContentMessage: string = "";
  private queryParams: any;

  //Verification constants
  subscriptionSuccessAction: string = "SubscriptionSuccess";
  verificationExpiredAction: string = "VerificationExpired";
  resendVerificationAction: string = "ResendVerification";
  changeAndResendVerificationAction: string = "ChangeAndResendVerification";
  verificationPendingAction: string = "VerificationPending";
  resendVerificationBtnName: string = "ResendVerification";
  loginToVerifyBtnName: string = "LoginToVerify";
  goToSubscriptionBtnName: string = "GoToSubscription";
  resendEmailBtnName: string = "ResendEmail";
  changeEmailBtnName: string = "ChangeEmail";
  changeAndResendEmailBtnName: string = "ChangeAndResendEmail";
  public verificationObject: SuccesErrorMessage;
  private userDetailMessage: UserDetailMessage;
  loginBtnName: string = "Login";
  // isEmailAlreadyExists:boolean=false;

  constructor(private activeRoute: ActivatedRoute, private router: Router,
    private authBusiness: AuthBusiness, private userDetailService: UserDetailService, private config: Config, private sharedBusiness: SharedBusiness) {
    this.email = "";
    this.isChangeEmailHidden = true;
    this.userDetailMessage = new UserDetailMessage();
  }

  ngOnInit() {
    this.loadVerificationForm();
  }

  loadVerificationForm(): void {
    var GetId = this.activeRoute.params.subscribe(params => {
      this.queryParams = params;
    });
    var key = this.queryParams.key;
    let channelStatusId = 0;
    if (key != null && key.trim().length > 0) {
      let response = this.authBusiness.verifyValidUserBusiness(key).subscribe(result => {
        if (result && result.token != undefined && result.token.length > 0) {
          // localStorage.setItem('authToken', result.token);
          // this.userDetailMessage.email = "";
          // this.userDetailMessage.action =  this.apiUrl.VERIFICATIONSUCCESS;
          // this.userDetailService.onUserDetailChange(this.userDetailMessage);
          this.setVerificationUITemplate(true, true);
        }
        else if (result[0] != null && result[0].errors != undefined) {
          let errors = result[0].errors;
          if (errors[0].code == 1428) {
            localStorage.removeItem(AppLocalStorageKeys.AUTH_Token);
            localStorage.removeItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
            localStorage.removeItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
            this.setVerificationUITemplate(true, true, true);
          }
          else if (errors[0].code == 1001 || errors[0].code == 1002 || errors[0].code == 1002 || errors[0].code == 1425 || errors[0].code == 1427) {
            localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
            this.router.navigate(['auth/login']);
          }
          else if (errors[0].code == 1425) {
            this.setVerificationUITemplate(true, false);
          }
          else {
            this.setVerificationUITemplate(true, false);
          }
        }
        else {
          this.setVerificationUITemplate(true, false);
        }
      },
        (error) => {
          let errors = error[0].errors;
          if (errors[0].code == 1001 || errors[0].code == 1002 || errors[0].code == 1002 || errors[0].code == 1425 || errors[0].code == 1427) {
            localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
            this.router.navigate(['auth/login']);
          }
          else {
            this.setVerificationUITemplate(true, false);
          }
        });
    }
    else {
      let statusResponse = this.sharedBusiness.getUserStatus().subscribe(result => {
        channelStatusId = result.channelStatusId;
        if (channelStatusId != undefined) {
          if (channelStatusId == UserAccountStatus.VERIFICATION ||
            channelStatusId == UserAccountStatus.REVERIFICATION ||
            channelStatusId == UserAccountStatus.REVERIFICATION_MAILCHANGE) {
            this.loadAccountVerifyChangeorResendEmailPage();
          }
          else if (channelStatusId == UserAccountStatus.SUBSCRIPTION) {
            this.router.navigate(['user_profile_selection']);
          }
          else {
            this.loadAccountVerifyChangeorResendEmailPage();
          }
        }
        else {
          this.loadAccountVerifyChangeorResendEmailPage();
        }
      },
        (error) => {
          if (error[0].code == 1001 || error[0].code == 1002 || error[0].code == 1002 || error[0].code == 1425 || error[0].code == 1427) {
            localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
            this.router.navigate(['auth/login']);
          }
          else {
            this.loadAccountVerifyChangeorResendEmailPage();
          }
        });
    }
  }

  loadAccountVerifyChangeorResendEmailPage() {
    if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != '') {
      this.userDetailService.currentUserDetail.subscribe(x => {
        this.userDetailMessage = x
      });
      if (this.userDetailMessage != undefined && this.userDetailMessage != null && this.userDetailMessage.action != undefined && this.userDetailMessage.action != null) {
        this.email = this.userDetailMessage.email;
        if (this.userDetailMessage.action == this.apiUrl.SUBSCRIPTIONSUCCESS) {
          this.getVerifyContentMessage(this.subscriptionSuccessAction);
        }

        if (this.userDetailMessage.action == this.apiUrl.VERIFICATIONPENDING) {
          this.getVerifyContentMessage(this.verificationPendingAction);
        }

        // console.log(this.userDetailMessage);
        this.setVerificationUITemplate(false, false);
      }
      else {
        this.getVerifyContentMessage("");
        this.setVerificationUITemplate(false, false);
      }
    }
    else {
      //go to login
      this.router.navigate(['auth/login']);
      // this.setVerificationUITemplate(false, false);
    }
  }

  setVerificationUITemplate(isVerificationLanding: boolean, isVerificationLinkSuccess: boolean, isAlreadyVerified: boolean = false) {
    if (isVerificationLanding) {
      if (isAlreadyVerified) {
        this.verificationObject = {
          errorId: "1",
          errorType: "success",
          errorTitle: "Account Verification",
          icon: "fa-check",
          iconMessage: "Verified Already",
          messages: [
            {
              messageContent: "You have verified already",
            },
            {
              messageContent: "To continue, follow the below link",
            }
          ],
          button: [{
            buttonType: "success",
            buttonName: this.loginBtnName,
            buttonValue: "Go To Login",
            buttonLink: "test()"
          }],
          showButtonBlock: true
        }
      }
      else if (isVerificationLinkSuccess) {
        this.verificationObject = {
          errorId: "1",
          errorType: "success",
          errorTitle: "Account Verification",
          icon: "fa-check",
          iconMessage: "Verified Successfully",
          messages: [
            {
              messageContent: "Welcome to Channel HUB,",
            },
            {
              messageContent: "World's Largest Consumer Electronics B2B Portal",
            }
          ],
          button: [{
            buttonType: "success",
            buttonName: this.goToSubscriptionBtnName,
            buttonValue: "Go To Subscription",
            buttonLink: ""
          }],
          showButtonBlock: true
        }
      }
      else {
        this.verificationObject = {
          errorId: "2",
          errorType: "failure",
          errorTitle: "Account Verification",
          icon: "fa-times",
          iconMessage: "Verification Failed",
          messages: [
            {
              messageContent: "Your Verification URL expired.",
            },
            {
              messageContent: "Resend Verification or change mail Id",
            }
          ],
          button: [{
            buttonType: "success",
            buttonName: localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != '' ? this.resendVerificationBtnName : this.loginToVerifyBtnName,
            buttonValue: localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != '' ? "Resend Verification" : "Login To Verify",
            buttonLink: ""
          }],
          showButtonBlock: true
        }
      }
    }
    else {
      this.verificationObject = {
        errorId: "3",
        errorType: "Verified",
        errorTitle: "Verification",
        icon: "",
        iconMessage: "",
        messages: [
          {
            messageContent: this.verifyContentMessage,
          }
        ],
        button: [
          {
            buttonType: "change",
            buttonName: this.changeEmailBtnName,
            buttonValue: "Change Email",
            buttonLink: "showchangeEmailBlock()"
          },
          {
            buttonType: "retry",
            buttonName: this.resendEmailBtnName,
            buttonValue: "Resend Email",
            buttonLink: "resendEmail()"
          }
        ],
        showButtonBlock: true
      }
    }
  }

  onVerificationCallback(obj: any): void {

    // console.log(obj);
    if (obj.name == this.changeAndResendEmailBtnName) {
      // this.verifyContentMessage = "Your request is processing";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = true;
      this.changeAndResendEmail();

    }
    else if (obj.name == this.resendEmailBtnName) {
      // this.verifyContentMessage = "Your request is processing";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = true;
      this.resendEmail();
    }
    else if (obj.name == this.loginToVerifyBtnName) {
      this.isChangeEmailHidden = true;
      this.router.navigate(['auth/login']);
    }
    else if (obj.name == this.goToSubscriptionBtnName) {
      this.isChangeEmailHidden = true;
      this.router.navigate(['user_profile_selection']);
    }
    else if (obj.name == this.resendVerificationBtnName) {
      this.isChangeEmailHidden = true;
      this.resendEmail();
      // this.router.navigate(['auth/accountverify']);
    }
    else if (obj.name == this.changeEmailBtnName) {
      // this.verifyContentMessage = "";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = false;
    }
    else if (obj.name == this.loginBtnName) {
      this.isChangeEmailHidden = true;
      this.router.navigate(['auth/login']);
    }
    else {
      this.isChangeEmailHidden = true;
    }
  }

  resendEmail(): void {
    this.isChangeEmailHidden = true;
    this.loading = true;
    let resetMessage = this.authBusiness.resendEmail().subscribe(result => {
      this.loading = false;
      console.log('resendEmail', result);
      if (result.length == 0 || ValidationService.isNullOrEmpty(result)) {
        this.onResendEmailSuccess();
      }
      else {
        if (!ValidationService.isNullOrEmpty(result[0]) &&
          !ValidationService.isNullOrEmpty(result[0].errors[0]) && !ValidationService.isNullOrEmpty(result[0].errors[0].code)) {
          if (result[0].errors[0].code == 1003) {
            document.getElementById("btnLogout").click();
          }
          else {
            this.onResendEmailFailure("");
          }
        }
        else {
          this.onResendEmailSuccess();
        }
      }
    },
      (error) => {
        this.onResendEmailFailure(error);
      });
  }

  onResendEmailSuccess(): void {
    this.getVerifyContentMessage(this.resendVerificationAction);
    if (this.verificationObject.errorId != "3") {
      this.setVerificationUITemplate(false, false);
    }
    else {
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    }
  }

  onResendEmailFailure(error: any): void {
    this.verifyContentMessage = "Failed to resend verification link to your email.Try again.";
    if (this.verificationObject.errorId != "3") {
      this.setVerificationUITemplate(false, false);
    }
    else {
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    }

  }

  changeAndResendEmail() {
    this.loading = true;
    this.verifyContentMessage = "";
    this.authBusiness.isEmailRegisterd(this.email).subscribe((res: any) => {
      this.loading = false;
      let isEmailUnique;
      if (res.isavialble === false) {
        isEmailUnique = false;
      } else {
        isEmailUnique = true;
      }
      this.verifyContentMessage = "";
      if (isEmailUnique) {
        this.isChangeEmailHidden = true;
        this.loading = true;
        let resetMessage = this.authBusiness.changeAndResendEmail(this.email).subscribe(result => {
          this.loading = false;
          // console.log('change mail', result);
          if (!ValidationService.isNullOrEmpty(result) && !ValidationService.isNullOrEmpty(result.email)) {
            this.onChangeAndResendEmailSuccess();
          }
          else {
            if (!ValidationService.isNullOrEmpty(result[0]) &&
              !ValidationService.isNullOrEmpty(result[0].errors[0]) && !ValidationService.isNullOrEmpty(result[0].errors[0].code)) {
              if (result[0].errors[0].code == 1003) {
                document.getElementById("btnLogout").click();
              }
              else {
                this.onChangeAndResendEmailFailure(result[0].errors[0].message);
              }
            }
            else {
              this.onChangeAndResendEmailFailure("");
            }
          }
        },
          (error) => {
            this.onChangeAndResendEmailFailure(error);
          });
      }
      else {
        this.verifyContentMessage = this.email + " already exists.";
        this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      }

    });
  }

  onChangeAndResendEmailSuccess(): void {
    this.getVerifyContentMessage(this.changeAndResendVerificationAction);
    localStorage.removeItem(AppLocalStorageKeys.AUTH_Token);
    localStorage.removeItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    localStorage.removeItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    this.verificationObject.showButtonBlock = false;
    this.verificationObject.button = [
      {
        buttonType: "success",
        buttonName: this.loginBtnName,
        buttonValue: "Go To Login",
        buttonLink: ""
      }
    ];
    this.verificationObject.showButtonBlock = true;
    this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    this.email = "";
    this.loading = false;
  }

  onChangeAndResendEmailFailure(error: any): void {
    this.verifyContentMessage = "Failed to change your e-mail and resend the verification link.Try again.";
    this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    this.email = "";
  }

  getVerifyContentMessage(forAction: string): void {
    if (forAction == this.subscriptionSuccessAction) {
      this.verifyContentMessage = "Thank you for subscribing. You are one step to go, please verify your account with the link sent to" +
        " your registered e-mail " + this.userDetailMessage.email + ", kindly verify.<br><h5>Note: link is valid only for 24 hours</h5>";
    }
    else if (forAction == this.verificationExpiredAction) {
      this.verifyContentMessage = "Your verification url is expired. Resend verification or change e-mail";
    }
    else if (forAction == this.resendVerificationAction) {
      this.verifyContentMessage = "We have resent verification link to" +
        " your registered e-mail id <b>" + this.email + "</b><br><h5>  Note: link is valid only for 24 hours</h5>";
    }
    else if (forAction == this.changeAndResendVerificationAction) {
      this.verifyContentMessage = "We have sent verification link to your changed e-mail <b>" + this.email + "</b>, Kindly verfiy or click below button to continue." +
        "<br><h5> Note: link is valid only for 24 hours</h5>";
    }
    else if (forAction == this.verificationPendingAction) {
      this.verifyContentMessage = "Your verification is pending. Kindly verify or else click resend email to resend verification link to your e-mail <b>" + this.email + "</b>";
    }
    else {
      this.verifyContentMessage = "You can resend verification link by clicking resend e-mail button or change your e-mail by clicking change e-mail button";
    }
  }
}