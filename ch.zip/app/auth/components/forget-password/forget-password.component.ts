import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { AuthBusiness } from '../../business/auth.business';
import { Login } from '../../models/user';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  public forgetpassword_message: any;
  public loading = false;

  forgetForm: FormGroup;
  formSubmit = false;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  
  // forgetPass:Login = {
  //   email: "",
  //   password: ""
  // }

  constructor( private fb: FormBuilder, public authBusiness: AuthBusiness) { }

  ngOnInit() { 
    this.initForm();
  }

  initForm() {
    const email = '';
    this.forgetForm = this.fb.group({
      email: ['', Validators.compose(
        [Validators.required,
        Validators.email,
        Validators.pattern(this.emailPattern)]
      )]
    }
    );
  }

  onSubmit() {
    const values = this.forgetForm.value;
    const keys = Object.keys(values);
    this.formSubmit = true;
    
    if (this.forgetForm.valid) {
      this.loading = true;
      this.forgetForm.reset();
      let resetMessage = this.authBusiness.forgetPasswordBusiness(values).subscribe(result => {
        this.loading = false;
        //console.log('Forget Password result : ',result[0].errors[0].code);
        if(!result.message) {
          if(result[0].message.statusCode == 500){
            this.forgetpassword_message = 'Mail Sending error..!';
          }else{
            this.forgetpassword_message ="";
          }                
        } else {
          this.forgetpassword_message = result.message;         
          // console.log(result.message);
        }
      },
      (error) => {
        this.forgetForm.reset();
        console.log(error);
      });

    } else {
      console.log('form filling error');
    }

  }

  clearError() {
    this.forgetpassword_message ="";
  }
}
