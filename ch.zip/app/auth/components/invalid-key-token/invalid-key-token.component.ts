import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-key-token',
  templateUrl: './invalid-key-token.component.html',
  styleUrls: ['./invalid-key-token.component.scss']
})
export class InvalidKeyTokenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
