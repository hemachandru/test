import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { Login, Register } from '../../models/user';
import { AuthBusiness } from '@app/auth/business/auth.business';
import { Router } from '@angular/router';
// import { UserDetailService } from '../../services/user-detail.service';
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { UserDetailMessage } from "@app/config/constant"
@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.scss']
})
export class SignupFormComponent implements OnInit {
  signUpForm: FormGroup;
  formSubmit = false;
  countryId;
  alphaNumericPattern = '[a-zA-Z0-9]+';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,15}$';
  public loading = false;
  ctrl_name;
  msg_code;
  registerSubs;
  controlFirstName;
  controlLastName;
  controlEmail;
  controlPassword;
  controlRetypePassword;
  controlCountry;
  userDetailMessage: UserDetailMessage;
  public selectClass: any = "grey-selectbox";

  constructor(
    private fb: FormBuilder,
    private authBusiness: AuthBusiness,
    private router: Router,
    private userDetailService: UserDetailService) {
    this.userDetailMessage = new UserDetailMessage();
  }

  ngOnInit() {
    this.initForm();
  }


  initForm() {
    const firstName = '';
    const lastName = '';
    const email = '';
    const password = '';
    const retypePassword = '';
    const country = '';

    this.signUpForm = this.fb.group({
      firstName: ['', Validators.compose(
        [Validators.required,
        Validators.minLength(2),
        Validators.maxLength(30),
        Validators.pattern(this.alphaNumericPattern)]
      )],
      lastName: ['', Validators.compose(
        [Validators.required,
        Validators.minLength(1),
        Validators.maxLength(30),
        Validators.pattern(this.alphaNumericPattern)]
      )],
      email: ['', [
        Validators.required,
        Validators.pattern(this.emailPattern)]
        , this.isEmailUnique.bind(this)
      ],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(15),
        Validators.pattern(this.passwordAlphaNumericPattern)]
      )],
      retypePassword: ['', Validators.compose([
        Validators.required
      ]
      )]
    }, { validator: this.matchingPasswords('password', 'retypePassword') }
    );
  }

  onSubmit() {
    const values = this.signUpForm.value;
    values['country'] = this.countryId;
    const keys = Object.keys(values);
    this.formSubmit = true;
    const self = this;

    const registerData = {
      "firstname": values.firstName,
      "lastname": values.lastName,
      "email": values.email,
      "password": values.password,
      "country": this.countryId
    };
    if (this.signUpForm.valid && this.countryId) {
      this.loading = true;
      const resList = this.authBusiness.register(registerData).subscribe(data => {
        this.loading = false;
        if (data.length) {
          const errors = data;
          if (errors) {
            console.log(errors);
            errors.forEach(val => {
              if (val.firstname) {
                this.controlFirstName = 'firstname';
                this.msg_code = val.password[0].code;
              }
              if (val.lastname) {
                this.controlLastName = 'lastname';
                this.msg_code = val.lastname[0].code;
              }
              if (val.email) {
                this.controlEmail = 'email';
                this.msg_code = val.email[0].code;
              }
              if (val.password) {
                this.controlPassword = 'password';
                this.msg_code = val.password[0].code;
              }
              if (val.country) {
                this.controlCountry = 'country';
                this.msg_code = val.country[0].code;
              }
              if (val.code) {
                this.controlEmail = 'email';
                this.msg_code = val.code;
              }
              if (val.errors) {
                this.controlEmail = 'email';
                this.msg_code = val.errors[0].code;
              }
            });
          }
        } else {
          const LoginData = {
            "email": values.email,
            "password": values.password
          };
          this.loginUser(LoginData);
        }

      });
    } else {
      keys.forEach(val => {
        const ctrl = this.signUpForm.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        };
        if(!this.countryId){
          this.controlCountry = 'country';
          this.msg_code = '0002';
        }
      });



    }
  }
  loginUser(data: Login) {
    let resetMessage = this.authBusiness.login(data).subscribe(res => {
      this.userDetailMessage.email = data.email;
      this.userDetailMessage.action = "SubscriptionSuccess";
      this.userDetailService.onUserDetailChange(this.userDetailMessage);
      this.router.navigate(['auth/accountverify']);
    }, (err) => {
      this.router.navigate(['auth/login']);
    });
  }

  private async getContryID(data: string): Promise<any> {
    this.countryId = parseInt(data, 10);
    if (data) {
      this.controlCountry = '';
      this.msg_code = '';
    }
  }

  signUpReset() {
    this.signUpForm.reset();
  }
  //Password and confirm password mismatch
  matchingPasswords(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      const password = group.controls[passwordKey];
      const confirmPassword = group.controls[confirmPasswordKey];

      if (password.value !== confirmPassword.value) {
        return {
          mismatchedPasswords: true
        };
      }
    };
  }
  //Exisitng Email validation
  isEmailUnique(control: FormControl) {
    const q = new Promise((resolve, reject) => {
      this.authBusiness.isEmailRegisterd(control.value).subscribe((res: any) => {
        if (res.isavialble === false) {
          resolve({ 'isEmailUnique': true })
        } else {
          resolve(null)
        }
      });
    });
    return q;
  }

}
