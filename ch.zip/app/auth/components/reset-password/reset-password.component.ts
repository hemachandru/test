import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { AuthBusiness } from '../../business/auth.business';
import { Login } from '../../models/user';

import { Router, NavigationStart, NavigationEnd, ActivatedRoute, Event as NavigationEvent } from '@angular/router';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import {AppLocalStorageKeys} from '../../../../environments/environment'
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  resetPassForm: FormGroup;
  formSubmit = false;
  private queryParams: any;
  private userId: any;
  private iserror: boolean = false;
  private error_message = 'false';
  public error_Message_Token_block: any;
  public loading = false;

  // public resetPasswordBlock = 'true';
  // resetPass:Login = {
  //   email: "",
  //   password: ""
  // }

  constructor(private router: Router, private fb: FormBuilder, public authBusiness: AuthBusiness, private activeRoute: ActivatedRoute) { }

  ngOnInit() {
    var GetId = this.activeRoute.params.subscribe(params => {
      this.queryParams = params;
      // console.log('this.queryParams', this.queryParams)
    });

    var key = this.queryParams.key;
    //  console.log('this.queryParams', key)
    // console.log('key : ', key);
    this.loading = true;
    let resetMessage = this.authBusiness.resetPasswordTokenCheckBusiness(key).subscribe(result => {
      this.resetPassForm.reset();
      this.loading = false;
      // console.log('success..!', result[0].errors[0].code);
      if (result.length) {
        const errors = result;
        if (errors) {
          errors.forEach(val => {
            if (val.errors[0].code === 1404) {
              this.router.navigate(['auth/invalidkey']);
            }
          });
        }
      } else {
        this.userId = result.userId;
        // console.log('Success Result : ', this.userId)
        localStorage.setItem(AppLocalStorageKeys.USER_ID, this.userId);
      }
    },
      (error) => {
        this.resetPassForm.reset();
        console.log(error);
      });

    this.initForm();
  }

  initForm() {
    const password = '';
    const retypePassword = '';

    this.resetPassForm = this.fb.group({
      password: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(8)
          // Validators.maxLength(10)
        ]
      )],
      retypePassword: ['', Validators.required]
    }, { validator: this.matchingPasswords('password', 'retypePassword') }
    );

  }

  matchingPasswords(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      const password = group.controls[passwordKey];
      const confirmPassword = group.controls[confirmPasswordKey];

      if (password.value !== confirmPassword.value) {
        return {
          mismatchedPasswords: true
        };
      }
    };
  }

  onSubmit() {
    let password = this.resetPassForm.value.password;
    const keys = Object.keys(password);
    this.formSubmit = true;
    let uid = localStorage.getItem(AppLocalStorageKeys.USER_ID);
    // console.log('user ID..! : ', uid);
    if (this.resetPassForm.valid) {
      this.loading = true;
      let values = { 'password': password };
      let resetMessage = this.authBusiness.resetPasswordBusiness(uid, JSON.stringify(values)).subscribe(result => {
        if (!ValidationService.isNullOrEmpty(result.message)) {
          this.resetPassForm.reset();
          this.iserror = true;
          this.error_message = "Your password has been updated, please kindly <a class='orange_text' href='/auth/login'>LOGIN</a>";
        }
        else {
          this.iserror = true;
          this.error_message = result[0].errors[0].message;
        }

        this.loading = false;
      },
        (error) => {
          this.loading = false;
          console.log(error);
        });
    } else {
      console.log('error');
    }
  }

}
