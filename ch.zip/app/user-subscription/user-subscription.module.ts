import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SlimScrollModule } from 'ng2-slimscroll';
import { TooltipModule } from "ng2-tooltip";

import { UserSubscriptionRoutingModule } from './user-subscription-routing.module';
import { SharedModule } from './../shared/shared.module';
import { SearchCompanyComponent } from './components/search-company/search-company.component';
import { RegisterCompanyInformationComponent } from './components/register-company-information/register-company-information.component';
import { RegisterContactInformationComponent } from './components/register-contact-information/register-contact-information.component';
import { TransactionComponent } from './components/transaction/transaction.component';
import { ConfirmSubscriptionPlanComponent } from './components/confirm-subscription-plan/confirm-subscription-plan.component';
// import { PaymentProcessComponent } from './components/payment-process/payment-process.component';
import { SubscriptionService } from './service/subscription.service';
import { LinkedinComponent } from '../shared/shared-component/linkedin/linkedin.component'
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS, MAT_DIALOG_DATA } from '@angular/material';
import { UserSubscriptionBusiness } from './business/user-subscription.business'
import { UserSubscriptionService } from './service/user-subscription.service';
import { SubscriptionPlanComponent } from '@app/user-subscription/components/subscription-plan/subscription-plan.component';
import { ClaimCompanyDocumentUploadComponent } from '@app/user-subscription/components/claim-company-document-upload/claim-company-document-upload.component';
import { ClaimCompanyInformationComponent } from './components/claim-company-information/claim-company-information.component';
import { ClaimContactInformationComponent } from './components/claim-contact-information/claim-contact-information.component';
import { ClaimCompanySuccessMessageComponent } from './components/claim-company-success-message/claim-company-success-message.component';

@NgModule({
  imports: [
    CommonModule,
    UserSubscriptionRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    SlimScrollModule,
    TooltipModule,
    FormsModule,
    MatDialogModule
  ],
  declarations: [
    SearchCompanyComponent,
    RegisterCompanyInformationComponent,
    RegisterContactInformationComponent,
    TransactionComponent,
    ConfirmSubscriptionPlanComponent,
    SubscriptionPlanComponent,
    ClaimCompanyDocumentUploadComponent,
    ClaimCompanyInformationComponent,
    ClaimContactInformationComponent,
    ClaimCompanySuccessMessageComponent,
    // PaymentProcessComponent
  ],
  exports: [

  ],
  providers: [SubscriptionService,UserSubscriptionBusiness,UserSubscriptionService,
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } },
    { provide: MAT_DIALOG_DATA, useValue: {} }
  ],
  entryComponents: [LinkedinComponent, RegisterContactInformationComponent, ClaimCompanyDocumentUploadComponent]
})
export class UserSubscriptionModule { }
