export class CompanyAddress {
    address: string;
    countryId: number;
    postalCode: number;
}

export class Billingaddress {
    address: string;
    countryId: number;
    postalCode: number;
}

export interface Address {
    companyAddress:CompanyAddress;
    billingAddress?:Billingaddress;
}

export interface ContactInfo {
    firstName: string;
    lastName: string;
    phone: number;
    email: string;
    jobTitle: string;
    linkedIn: string;
    image: string;
}

export class Document
{
    documentPath:string;
}

export class Channel {
    channelId: number;
    // signUpStatusId: number;
    companyName: string;
    oldChannelId: number;
    claimChannelId: number;
    channelTypeId: number;
    channelTypeName:string;
    regAddressId: number;
    billAddressId: number;
    companyMail: string;
    companyphone: number;
    companyphone2: number;
    comapanywebside: string;
    address:Address;
    subscriptionId: number;
    subscriptionType: string;
    describtion: string;
    document: Array<Document>;
}

export class ChannelSubscriptionData {
    channel:Channel;
    contact: ContactInfo;
};

export interface PublicUploadRequest {
    path:string;
    url:string;
}

// export class channel implements SubscriptionInterface;
