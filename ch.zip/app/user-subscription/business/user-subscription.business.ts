import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Config } from '@app/config/constant';
import { UserSubscriptionService } from '../service/user-subscription.service';
import { ChannelSubscriptionData } from '../models/subscription';
import { SubscriptionService } from '../service/subscription.service';
import { ApiUrl } from '../../../environments/environment';

@Injectable()
export class UserSubscriptionBusiness {
  private apiUrl = ApiUrl;  

  constructor( private _userSubscription: UserSubscriptionService,
    private router: Router, private subscriptionService: SubscriptionService) {
  }

  checkCouponCodeBusiness(couponCodeData) {
    // console.log('business : ', couponCodeData)
    let url = this.apiUrl.COUPONCODECHECKING;
    return this._userSubscription.subscriptionDataPostService(couponCodeData, url).map(res => {
      return res
    });
  }

  subscriptionDataPostBusiness(subscriptionData: ChannelSubscriptionData) {
    let url = this.apiUrl.USERSUBSCRIPTION;
    return this._userSubscription.subscriptionDataPostService(subscriptionData, url).map(res => {
      return res
    });
  }

  subscriptionIdPostBusiness(subscriptionId) {
    console.log('subscriptionId : ',subscriptionId)
    let url = this.apiUrl.CHANNEL_SUBSCRIBE;
    return this._userSubscription.subscriptionDataPostService(subscriptionId, url).map(res => {
      return res
    });
  }

  getContactInfo(userId: number) {
    let url = this.apiUrl.CONTACTINFO;
    return this._userSubscription.getContactInfoGetService(userId, url).map(res => {
      return res
    });
  }

  payemntProcess(data: any) {
    let url = this.apiUrl.PAYMENT;

    return this.subscriptionService.paymentgateway(data, url).map(res => {
      return res;
    });
  }

  getSubscribePeriodBusiness(): Observable<any> {
    const url = this.apiUrl.GETSUBSCRIPTIONPERIOD;
    return this._userSubscription.getSubscribePeriodService(url)
      .map(res => {
        return res;
      });
  }

  getSubscribePlanBusiness(channelTypeId: number): Observable<any> {
    const url = this.apiUrl.GETSUBSCRIPTIONPLAN;
    return this._userSubscription.getSubscribePlanService(channelTypeId, url)
      .map(res => {
        return res;
      });
  }
}
