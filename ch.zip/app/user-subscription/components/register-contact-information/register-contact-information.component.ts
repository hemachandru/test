import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { SharedModule } from '../../../shared/shared.module';
import { ChannelSubscriptionData, ContactInfo } from '../../models/subscription';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { LinkedinComponent } from '../../../shared/shared-component/linkedin/linkedin.component';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { UserSubscriptionBusiness } from '../../business/user-subscription.business';
import { ActivatedRoute, Router } from '@angular/router';
import { Linkedin } from '../../../shared/models/linkedin';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ApiUrl,AppLocalStorageKeys } from '../../../../environments/environment';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { Config } from '../../../config/constant';
import { FetchUploadService } from '../../../shared/shared-service/fetch-upload-service'
import { PublicUploadRequest } from '../../models/subscription'
@Component({
  selector: 'subscription_contact_info',
  templateUrl: './register-contact-information.component.html',
  styleUrls: ['./register-contact-information.component.scss']
})
export class RegisterContactInformationComponent implements OnInit {
  private apiUrl = ApiUrl;
  contactInfoFormGroup: FormGroup;
  private title: string;
  private userDetails = [];
  ourFile: File;
  buttonNext = [];
  public btnNextData = this.buttonNext;
  public pageHeadder: any = "Contact Information";
  private folderName = "contact-s3/";
  // emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  // phoneNoPattern = '^((\\+91-?)|0)?[0-9]{15}$';
  private channelSubscriptionData: ChannelSubscriptionData;
  controlFirstName;
  controlLastName;
  controlPhone;
  controlEmail;
  controlJobTitle;
  controlProfileImage;
  regImgView;
  public linkedin: Linkedin;
  public profileImage: any;
  public loadImage: any = "";
  public profileImgClassBool: any;
  public profileImgErr: any;
  public loading = false;
  public userImage: boolean = false;
  public userIcon: boolean = true;
  constructor(private fb: FormBuilder, public dialog: MatDialog, private userSubscriptionBusiness: UserSubscriptionBusiness, private router: Router,
    private config: Config, private uploadFileService: UploadFileService, public sharedBusiness: SharedBusiness, private s3UploadFileService: S3UploadFileService
  ) {
  }

  ngOnInit() {
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    console.log('SubscrpitionData check ', data);
    this.channelSubscriptionData = data as ChannelSubscriptionData;
    this.setPageHeader();
    this.initForm();
    this.fillForm();
  }

  fillForm() {
    let result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    let contactId: number;
    if (result != null && result != '') {
      contactId = parseInt(result);
      this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
        let contactInfo = response as ContactInfo;
        this.contactInfoFormGroup.controls['firstName'].setValue(!ValidationService.isNullOrEmpty(contactInfo.firstName) ? contactInfo.firstName : '');
        this.contactInfoFormGroup.controls['lastName'].setValue(!ValidationService.isNullOrEmpty(contactInfo.lastName) ? contactInfo.lastName : '');
        this.contactInfoFormGroup.controls['phone'].setValue(!ValidationService.isNullOrEmpty(contactInfo.phone) ? contactInfo.phone : null);
        this.contactInfoFormGroup.controls['email'].setValue(!ValidationService.isNullOrEmpty(contactInfo.email) ? contactInfo.email : '');
        this.contactInfoFormGroup.controls['jobTitle'].setValue(!ValidationService.isNullOrEmpty(contactInfo.jobTitle) ? contactInfo.jobTitle : '');
        this.contactInfoFormGroup.controls['linkedIn'].setValue(!ValidationService.isNullOrEmpty(contactInfo.linkedIn) ? contactInfo.linkedIn : '');
        this.contactInfoFormGroup.controls['image'].setValue(!ValidationService.isNullOrEmpty(contactInfo.image) ? contactInfo.image : '');
      },
        (error) => {
          console.log(error);
        });
    }
  }

  initForm() {
    this.contactInfoFormGroup = this.fb.group({
      firstName: ['', Validators.compose([Validators.required])],
      lastName: ['', Validators.compose([Validators.required])],
      phone: ['',
        Validators.compose([Validators.required,
        Validators.pattern(this.config.mobnumPattern)])],
      email: ['', Validators.compose([Validators.required,
      Validators.pattern(this.config.emailPattern)])],
      jobTitle: ['', Validators.compose([Validators.required])],
      linkedIn: [''],
      image: ['']
      // image: ['', Validators.compose([Validators.required])]
    });
  }

  onSubmit() {
    let imgs = this.profileImage;
    let contactInfo = this.contactInfoFormGroup.value as ContactInfo;
    contactInfo.image = !ValidationService.isNullOrEmpty(imgs) ? imgs : '';
    this.channelSubscriptionData.contact = contactInfo;
    // this.channelSubscriptionData.channel.subscriptionId = 2;
    if (this.contactInfoFormGroup.valid && this.regImgView) {
      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.channelSubscriptionData));
      if (this.channelSubscriptionData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
        console.log("Claim Redirection");
        this.router.navigate(['/user/claim_company_document']);
      }
      else {
        this.router.navigate(['/user/subscriptionplan']);
      }

    }
    else {
      let keys = Object.keys(contactInfo);
      keys.forEach(val => {
        const ctrl = this.contactInfoFormGroup.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        }
      });

      if (!this.regImgView) {
        this.profileImgErr = "Please upload your image";
      }
      else {
        this.profileImgErr = "";
      }
    }

    console.log(this.channelSubscriptionData);
  }

  openDialog(): void {
    this.linkedin = new Linkedin();
    this.linkedin.firstName = "";
    this.linkedin.lastName = "";
    this.linkedin.email = "";
    this.linkedin.jobTitle = "";
    this.linkedin.profileUrl = "";
    let uid = "";
    this.sharedBusiness.socialLogin('linkedin').subscribe(response => {
      console.log(response);
      this.linkedin = response as Linkedin;
      let names = this.linkedin.name.split(" ", 2);
      this.linkedin.firstName = names[0];
      this.linkedin.lastName = names[1];
      uid = this.linkedin.uid;
      let dialogRef = this.dialog.open(LinkedinComponent, {
        data: {
          name: this.linkedin.name,
          firstName: this.linkedin.firstName, lastName: this.linkedin.lastName,
          email: this.linkedin.email, jobTitle: this.linkedin.jobTitle,
          profileUrl: this.linkedin.profileUrl,
          image: this.linkedin.image
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        this.loading = true;
        this.sharedBusiness.logout();
        this.linkedin = result as Linkedin;
        document.getElementsByTagName('html').item(0).style.removeProperty('top');
        if (!ValidationService.isNullOrEmpty(this.linkedin.firstName)) {
          this.contactInfoFormGroup.controls['firstName'].setValue(this.linkedin.firstName);
        }

        if (!ValidationService.isNullOrEmpty(this.linkedin.lastName)) {
          this.contactInfoFormGroup.controls['lastName'].setValue(this.linkedin.lastName);
        }

        if (!ValidationService.isNullOrEmpty(this.linkedin.jobTitle)) {
          this.contactInfoFormGroup.controls['jobTitle'].setValue(this.linkedin.jobTitle);
        }

        if (!ValidationService.isNullOrEmpty(this.linkedin.profileUrl)) {
          this.contactInfoFormGroup.controls['linkedIn'].setValue(this.linkedin.profileUrl);
        }

        if (!ValidationService.isNullOrEmpty(this.linkedin.image)) {
          let publicUploadRequest: PublicUploadRequest = {
            'path': this.folderName + uid + ".jpeg",
            'url': this.linkedin.image
          };
          this.sharedBusiness.uploadLinkedInImageBusiness(publicUploadRequest).subscribe(response => {         
            if (response.length) {
              this.profileImgErr = 'Profile image import error please retry';
              this.userImage = false;
              this.userIcon = true;
            }
            else {//success
              this.userImage = true;
              this.userIcon = false;
              this.profileImage = publicUploadRequest.path;
              this.profileImgErr = 'Profile image successfully updated';
              this.regImgView = this.linkedin.image;             
            }
            this.loading = false;
          },
            (error) => {
              this.profileImgErr = 'Profile image import error please retry';
              this.loading = false;
            });
        }
      });
    },
      (error) => {
        console.log(error);
      });
  }

  openInput(event) {
    document.getElementById("fileInput").click();
  }

  async selectFile(event, urlLink) {

    let selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    // console.log(event.target.files[0]);
    if (file) {
      this.loading = true;
      const resImagePath: any = await this.uploadFileService.uploadfile(file, this.folderName)
      // this.profileImage = resImagePath.Location;
      this.profileImage = resImagePath.key;
      // console.log(resImagePath);
      if (this.profileImage) {
        this.profileImgClassBool = 1;
        this.profileImgErr = 'Profile image successfully updated';
        this.loading = false;
        this.userImage = true;
        this.userIcon = false;
        var reader = new FileReader();
        reader.onload = (event: any) => {
          this.regImgView = event.target.result;
        }
        reader.readAsDataURL(event.target.files[0]);
      } else {
        this.profileImgClassBool = 0;
        this.userImage = false;
        this.userIcon = true;
        this.profileImgErr = 'Profile image update error please retry';
        this.loading = false;
      }

      // console.log(resImagePath.Bucket);
      // console.log(resImagePath.Key);
      // console.log(resImagePath.Location);
    }
  }

  goBack(): void {
    this.router.navigate(['/user/register']);
  }

  setPageHeader(): void {
    if (this.channelSubscriptionData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_NEW) {
      this.title = "New Vendor Registration";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        }
      ];
    }
    else if (this.channelSubscriptionData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_OLD) {
      this.title = "Verify / Update Information";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        }
      ];
    }
    else if (this.channelSubscriptionData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.title = "Claim Company";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        },
        {
          "pageNum": "3",
          "pageClass": "menu-page2"
        }
      ];
    }

    this.btnNextData = this.buttonNext;
  }
}
