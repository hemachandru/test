import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { ActivatedRoute, Router } from '@angular/router';

import { ISlimScrollOptions } from 'ng2-slimscroll';

import { ChannelSubscriptionData, Billingaddress, CompanyAddress, Address } from '../../models/subscription';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ApiUrl,AppLocalStorageKeys } from '../../../../environments/environment';
import { Config } from '@app/config/constant';

// const buttonNext = [
//   {
//     "pageNum": "1",
//     "pageClass": "menu-page1"
//   },
//   {
//     "pageNum": "2",
//     "pageClass": "menu-page2"
//   }
// ];

@Component({
  selector: 'app-register-company-information',
  templateUrl: './register-company-information.component.html',
  styleUrls: ['./register-company-information.component.scss']
})
export class RegisterCompanyInformationComponent implements OnInit {
  private apiUrl = ApiUrl;

  registerCompany: FormGroup;
  formSubmit = false;
  // alphaNumericPattern = '[a-zA-Z][a-zA-Z ]+';
  // emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  // mobnumPattern = '^((\\+91-?)|0)?[0-9]{10}$';
  // webPattern = '^[a-z0-9._%+-]+.[a-z0-9.-]+\.[a-z]{2,4}$';

  public opts: ISlimScrollOptions;
  buttonNext = [];
  public btnNextData = this.buttonNext;
  public pageHeadder: any = "Company Information";
  public title: any = "";
  public testDataCheck: any;
  public CompanyAddr = '';
  public CompanyAddrPostalCode = '';
  public billAddress = '';

  //prefilled form variables
  public channelId = null;
  public channelTypeId = null;
  public claimChannelId = null;
  public oldChannelId = null;
  // public signUpStatusId = null;
  public companyName = null;
  public companyAddress = null;
  public companycountryId = null;
  public companyPostalcode: number;
  public companyPhone1 = null;
  public companyPhone2 = null;
  public companyEmail = "";
  public companyWebsite = "";
  public billingAddress = "";
  public billingcountryId = null;
  public billingPostalcode: number;
  public FillCompanyCountryId: number;
  public FillBillingCountryId: number;

  companyCountry;
  billingCountry;
  msg_code;
  msg_codeBill;

  companyData: ChannelSubscriptionData;

  constructor(private router: Router, private fb: FormBuilder, private config: Config) { }

  ngOnInit() {

    this.initForm();
    this.opts = {
      //position: 'right',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    // let data = JSON.parse(localStorage.getItem("SubscrpitionData"));
    // console.log('Mydata : ', data);
    // this.companyData = data as ChannelSubscriptionData;
    // console.log(this.companyData);
    this.fillForm();
    this.setPageHeader();

    // this.channelId = this.companyData.channel.channelId;
    // this.channelTypeId = this.companyData.channel.channelTypeId;
    // this.claimChannelId = this.companyData.channel.claimChannelId;
    // this.oldChannelId = this.companyData.channel.oldChannelId;
    // // this.signUpStatusId = this.companyData.channel.signUpStatusId;
    // this.companyName = this.companyData.channel.companyName;
    // this.companyAddress = this.companyData.channel.address.companyAddress != null ? this.companyData.channel.address.companyAddress.address : '';
    // this.companycountryId = this.companyData.channel.address.companyAddress != null ? this.companyData.channel.address.companyAddress.countryId : null;
    // this.companyPostalcode = this.companyData.channel.address.companyAddress != null ? this.companyData.channel.address.companyAddress.postalcode : null;
    // this.companyPhone1 = this.companyData.channel.companyphone;
    // this.companyPhone2 = this.companyData.channel.companyphone2;
    // this.companyEmail = this.companyData.channel.companyMail;
    // this.companyWebsite = this.companyData.channel.comapanywebside;
    // this.billingAddress = this.companyData.channel.address.billingaddress != null ? this.companyData.channel.address.billingaddress.address : '';
    // this.billingcountryId = this.companyData.channel.address.billingaddress != null ? this.companyData.channel.address.billingaddress.countryId : null;
    // this.billingPostalcode = this.companyData.channel.address.billingaddress != null ? this.companyData.channel.address.billingaddress.postalcode : null;
  }

  fillForm() {
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    this.companyData = data as ChannelSubscriptionData;
    if (this.companyData.channel.address.companyAddress == null) {
      this.FillCompanyCountryId = 0;
    } else {
      this.FillCompanyCountryId = this.companyData.channel.address.companyAddress.countryId;
    }

    if (this.companyData.channel.address.billingAddress == null) {
      this.FillBillingCountryId = 0;
    } else {
      this.FillBillingCountryId = this.companyData.channel.address.billingAddress.countryId;
    }

    this.registerCompany.controls['companyName'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.companyName) ? this.companyData.channel.companyName : '');
    this.registerCompany.controls['companyAddress'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.address.companyAddress.address) ? this.companyData.channel.address.companyAddress.address : '');
    this.registerCompany.controls['companyPostalcode'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.address.companyAddress.postalCode) ? this.companyData.channel.address.companyAddress.postalCode : '');
    this.registerCompany.controls['companyPhone1'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.companyphone) ? this.companyData.channel.companyphone : '');
    this.registerCompany.controls['companyPhone2'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.companyphone2) ? this.companyData.channel.companyphone2 : '');
    this.registerCompany.controls['companyEmail'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.companyMail) ? this.companyData.channel.companyMail : '');
    this.registerCompany.controls['companyWebsite'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.comapanywebside) ? this.companyData.channel.comapanywebside : '');
    this.registerCompany.controls['billingAddress'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.address.billingAddress.address) ? this.companyData.channel.address.billingAddress.address : '');
    this.registerCompany.controls['billingPostalcode'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.address.billingAddress.postalCode) ? this.companyData.channel.address.billingAddress.postalCode : '');

    //this.companyData.channel.address.companyAddress.countryId
    //this.companyData.channel.address.billingaddress.countryId
  }

  initForm() {
    const companyName = '';
    const companyAddress = '';
    const companyPostalcode = '';
    const companyPhone1 = '';
    const companyPhone2 = '';
    const companyEmail = '';
    const companyWebsite = '';
    const billingAddress = '';
    const billingPostalcode = '';
    const country = '';

    this.registerCompany = this.fb.group({
      companyName: ['', Validators.compose([Validators.required])],
      companyAddress: ['', Validators.compose([Validators.required])],
      companyPostalcode: ['', Validators.compose([Validators.required])],
      companyPhone1: ['', Validators.compose(
        [
          Validators.required,
          Validators.pattern(this.config.mobnumPattern)
        ]
      )],
      companyPhone2: ['', Validators.compose(
        [
          Validators.pattern(this.config.mobnumPattern)
        ]
      )],
      companyEmail: ['', Validators.compose(
        [
          Validators.required,
          Validators.pattern(this.config.emailPattern)
        ]
      )],
      companyWebsite: ['', Validators.compose(
        [
          Validators.pattern(this.config.webPattern)
        ]
      )],
      billingAddress: ['', Validators.compose([Validators.required])],
      billingPostalcode: ['', Validators.compose([Validators.required])]
      // companyPhone1: ['', Validators.pattern(this.mobnumPattern)],
    }
    );
  }

  private async getCompanyCountryID(data: string): Promise<any> {
    this.FillCompanyCountryId = parseInt(data, 10);
    this.companyCountry = '';
    this.msg_code = '';
  }

  private async getBillingCountryID(data: string): Promise<any> {
    // this.billingcountryId = parseInt(data, 10);
    this.FillBillingCountryId = parseInt(data, 10);
    this.billingCountry = '';
    this.msg_codeBill = '';
  }

  getSameAddress(event) {
    debugger;
    let sameAddress = event.target.checked;
    this.registerCompany.controls['billingAddress'].setValue(!ValidationService.isNullOrEmpty(this.CompanyAddr) ? this.CompanyAddr : '');
    this.registerCompany.controls['billingPostalcode'].setValue(!ValidationService.isNullOrEmpty(this.CompanyAddrPostalCode) ? this.CompanyAddrPostalCode : '');
    // console.log('Country : ', this.companycountryId);
    this.FillBillingCountryId = this.FillCompanyCountryId
    // this.billingcountryId = this.FillBillingCountryId;
  }

  getDifferentAddress(event) {
    let differentAddress = event.target.checked;
    let clearBillAddress = '';
    let clearBillPostalcode = '';
    this.FillBillingCountryId = 0;
    this.registerCompany.controls['billingAddress'].setValue(!ValidationService.isNullOrEmpty(clearBillAddress) ? clearBillAddress : '');
    this.registerCompany.controls['billingPostalcode'].setValue(!ValidationService.isNullOrEmpty(clearBillPostalcode) ? clearBillPostalcode : '');
    // this.billAddress = '';
    // console.log(differentAddress);
  }

  onSubmit() {
    debugger;
    let values = this.registerCompany.value;
    // console.log(values);
    const keys = Object.keys(values);
    this.formSubmit = true;
    if (this.registerCompany.valid && this.FillCompanyCountryId && this.FillBillingCountryId) {
      this.companyData.channel.companyName = values.companyName;
      this.companyData.channel.companyphone = values.companyPhone1;
      if (!ValidationService.isNullOrEmpty(values.companyPhone2)) {
        this.companyData.channel.companyphone2 = values.companyPhone2;
      }
      this.companyData.channel.companyMail = values.companyEmail;
      if (!ValidationService.isNullOrEmpty(values.companyWebsite)) {
        this.companyData.channel.comapanywebside = values.companyWebsite;
      }
      let companyAddress: CompanyAddress = new CompanyAddress();
      companyAddress.address = values.companyAddress;
      companyAddress.countryId = this.FillCompanyCountryId;
      companyAddress.postalCode = values.companyPostalcode;
      let billAddress: Billingaddress = new Billingaddress();
      billAddress.address = values.billingAddress;
      billAddress.countryId = this.FillBillingCountryId;
      billAddress.postalCode = values.billingPostalcode;
      let address = { 'companyAddress': companyAddress, 'billingAddress': billAddress }
      this.companyData.channel.address = address;

      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.companyData));
      // console.log('Test data : ', this.companyData);
      this.router.navigate(['/user/subscription_contact_info']);
    } else {
      keys.forEach(val => {
        const ctrl = this.registerCompany.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        };
        //billingCountry  billingcountryId msg_codeBill
      });
      if (ValidationService.isNullOrEmpty(this.FillCompanyCountryId) || this.FillCompanyCountryId == 0 || isNaN(this.FillCompanyCountryId)) {
        this.companyCountry = 'country';
        this.msg_code = '0002';
      } else {
        this.companyCountry = '';
        this.msg_code = '';
      }
      if (ValidationService.isNullOrEmpty(this.FillBillingCountryId) || this.FillBillingCountryId == 0 || isNaN(this.FillBillingCountryId)) {
        this.billingCountry = 'country';
        this.msg_codeBill = '0002';
      } else {
        this.billingCountry = '';
        this.msg_codeBill = '';
      }

      // if (ValidationService.isNullOrEmpty(this.billingcountryId) || ValidationService.isNullOrEmpty(this.FillBillingCountryId)) {
      //   this.billingCountry = 'country';
      //   this.msg_codeBill = '0002';
      // } else {
      //   this.billingCountry = '';
      //   this.msg_codeBill = '';
      // }
    }
  }

  setPageHeader(): void {
    if (this.companyData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_NEW) {
      this.title = "New Vendor Registration";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        }
      ];
    }
    else if (this.companyData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_OLD) {
      this.title = "Verify / Update Information";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        }
      ];
    }
    else if (this.companyData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.title = "Claim Company";
      this.buttonNext = [
        {
          "pageNum": "1",
          "pageClass": "menu-page1"
        },
        {
          "pageNum": "2",
          "pageClass": "menu-page2"
        },
        {
          "pageNum": "3",
          "pageClass": "menu-page2"
        }
      ];
    }

    this.btnNextData = this.buttonNext;
  }

}
