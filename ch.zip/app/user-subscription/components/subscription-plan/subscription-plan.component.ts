import { Component, OnInit } from '@angular/core';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
import { Router } from '@angular/router';
import { ChannelSubscriptionData } from '@app/user-subscription/models/subscription';
import {AppLocalStorageKeys} from '../../../../environments/environment';
@Component({
  selector: 'app-subscription-plan',
  templateUrl: './subscription-plan.component.html',
  styleUrls: ['./subscription-plan.component.scss']
})
export class SubscriptionPlanComponent implements OnInit {
  public loading = false;
  msg_code;
  subscriptionPlanError;
  collapsed1: boolean = true;
  collapsed2: boolean = false;
  collapsed3: boolean = false;
  selectedTab: string = '0';
  selected: boolean;

  public title: any = "Subscription Plan";
  public subTitle: any = "Choose your plan that best fits your business and you can also try fee.";
  subscribePlanDetails: any = [];
  subscribeDetails: any = [];
  periodTabs = [];
  yearlyPlan = [];
  monthlyTab: boolean = true;
  yearlyTab: boolean = false;
  offerBox: boolean = false;
  Object = Object;
  selectedIndex: number;
  selectedToggle: any = 0;
  private channelSubscriptionData: ChannelSubscriptionData;
  planlist: any;
  planName: string;
  planAmount: string;
  constructor(private sharedBusiness: SharedBusiness, private userSubscriptionBusiness: UserSubscriptionBusiness, private router: Router) { }


  ngOnInit() {
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    this.channelSubscriptionData = data as ChannelSubscriptionData;
    let channelTypeId = this.channelSubscriptionData.channel.channelTypeId;
    this.getSubscribePlanDetails(channelTypeId);
    this.getsubscriptionPeriod();
  }
  selectPlan(event, planPeriod) {
    let target = event.target || event.srcElement || event.currentTarget;
    let idAttr = target.attributes.id;
    let value = idAttr.nodeValue;
    this.selectedIndex = parseInt(value);
    this.planName = planPeriod.planName;
    this.planAmount = planPeriod.amount;
  }

  getsubscriptionPeriod() {
    this.loading = true;
    let result = this.userSubscriptionBusiness.getSubscribePeriodBusiness().subscribe(response => {
      this.periodTabs = response;
      this.loading = false;
    }, (error) => {
      this.loading = false;
      console.log(error);
    });
  }


  getSubscribePlanDetails(channelTypeId) {
    this.loading = true;
    let result = this.userSubscriptionBusiness.getSubscribePlanBusiness(channelTypeId).subscribe(response => {
      if (response) {
        this.subscribeDetails = response;
        this.planlist = this.subscribeDetails[0];
      }
      this.loading = false;
    }, (error) => {
      this.subscriptionPlanError = 'apiError';
      this.msg_code = '0000';
      this.loading = false;
    });
  }

  getPlanId(index) {
    this.selectedTab = index;
    if (this.selectedTab == '1') {
      this.offerBox = true
      this.planlist = this.subscribeDetails[1];
    }
    else {
      this.offerBox = false
      this.planlist = this.subscribeDetails[0];
    }
  }
  showDiv(index) {
    this.selectedToggle = index;
  }

  goBack(): void {
    this.router.navigate(['/user/register']);
  }

  goNext() {
    let getPlanId: number = this.selectedIndex;
    let planNameValue: any = this.planName;
    let planAmountValue: any = this.planAmount;
    let subcriptionPlan = {
      "subscriptionId": getPlanId,
      "amount":planAmountValue,
      "planName":planNameValue
    }
    if (getPlanId) {
      this.channelSubscriptionData.channel.subscriptionId = getPlanId;
      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.channelSubscriptionData));
      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_PLAN_DETAIL, JSON.stringify(subcriptionPlan));
      this.router.navigate(['/user/confirmplan']);
    } else {
      this.subscriptionPlanError = 'subscriptionPlan';
      this.msg_code = '0050';
    }
  }

  trackByFn(index, item) {
    return index;
  }


}
