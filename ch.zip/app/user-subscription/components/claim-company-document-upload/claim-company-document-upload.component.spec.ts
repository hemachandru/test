import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimCompanyDocumentUploadComponent } from './claim-company-document-upload.component';

describe('ClaimCompanyDocumentUploadComponent', () => {
  let component: ClaimCompanyDocumentUploadComponent;
  let fixture: ComponentFixture<ClaimCompanyDocumentUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimCompanyDocumentUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimCompanyDocumentUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
