import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '@app/shared/shared.module';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { ChannelSubscriptionData, Document } from '@app/user-subscription/models/subscription';
import { Router } from '@angular/router';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
import {AppLocalStorageKeys} from '../../../../environments/environment'
const buttonNext = [
  {
    "pageNum": "1",
    "pageClass": "menu-page1"
  },
  {
    "pageNum": "2",
    "pageClass": "menu-page2"
  }
];
@Component({
  selector: 'app-claim-company-document-upload',
  templateUrl: './claim-company-document-upload.component.html',
  styleUrls: ['./claim-company-document-upload.component.scss']
})
export class ClaimCompanyDocumentUploadComponent implements OnInit {
  public btnNextData = buttonNext;
  public pageHeadder: any = "Company Information";
  public title: any = "New Vendor Registration";
  dropBox: boolean = false;
  imageArraytemp = [];
  imageObjtemp = {};
  private imageFileName;
  private channelSubscriptionData: ChannelSubscriptionData;
  removeImageItem;
  document: Document;
  finalImageArray = [];
  claimDocError;
  msg_code;
  public loading: boolean = false;
  documentOtp: string;
  constructor(private s3UploadFileService: S3UploadFileService, private router: Router, private userSubscriptionBusiness: UserSubscriptionBusiness) { }

  ngOnInit() {
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    console.log('SubscrpitionData check ', data);
    this.channelSubscriptionData = data as ChannelSubscriptionData;
  }

  private async setDocuments() {
    this.channelSubscriptionData.channel.document = new Array<Document>();
    this.finalImageArray = this.imageArraytemp.map(item => {
      return item.s3UploadImage;
    });
    this.finalImageArray.forEach(keyValue => {
      this.document = new Document();
      this.document.documentPath = keyValue;
      console.log(this.document);
      this.channelSubscriptionData.channel.document.push(this.document);
    });

  }
  private async onClaimSubmit() {
    if (this.imageArraytemp.length) {
      await this.setDocuments();
      let describtion = this.documentOtp;
      if (describtion)
        this.channelSubscriptionData.channel.describtion = describtion;
      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.channelSubscriptionData));
      this.onClaimCompany();
    } else {
      this.claimDocError = 'claimDoc';
      this.msg_code = '0051';
    }

  }

  async onUploadFinished(event) {
    this.dropBox = true;
    const fileImgeSource = event.src;
    const file = event.file;
    const fileName = event.file.name;
    const folderName = 'claimDocument/';
    const resImagePath: any = await this.s3UploadFileService.uploadfile(file, folderName)
    if (resImagePath) {
      this.imageArraytemp.push({
        "s3UploadImage": resImagePath.key,
        "uploadImage": file.name
      })
    } else {
      this.onRemoved(event);
      console.log("s3 srror");
    }
    if (this.imageArraytemp.length > 0) {
      this.claimDocError = '';
      this.msg_code = '';
    }
  }
  onUploadStateChanged(event) {
    this.onRemoved(event);
  }
  //Remove image
  onRemoved(event) {
    console.log(event);
    this.imageArraytemp.forEach((item, index) => {
      let deleteItem = item.uploadImage === event.file.name;
      if (deleteItem) {
        this.imageArraytemp.splice(index, 1);
      }
    });
    console.log('img' + this.imageArraytemp);
  }

  onClaimCompany() {
    let self = this;
    this.loading = true;
    let values = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    let resetMessage = this.userSubscriptionBusiness.subscriptionDataPostBusiness(values).subscribe(result => {
      if (result.length) {
        const errors = result;
        console.log(errors);
        // if (errors) {
        //   this.loading = false;
        //   errors.forEach(val => {
        //   });
        // }
      } else {
        this.router.navigate(['/user/claim_company_success']);
      }
    },
      (error) => {
        console.log(error);
      });
  }
}
