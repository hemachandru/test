import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { SuccesErrorMessage } from '@app/config/constant';
import{ OrderDetails } from "@app/config/constant";
import { SubscriptionService } from '../../service/subscription.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.scss']
})
export class TransactionComponent implements OnInit {
  value:any ="WERF5345GFDG43";
  public orderData: OrderDetails;
  transactionObject:SuccesErrorMessage;

  constructor(private _subscriptionService: SubscriptionService,private router: Router) {
    this.paymentStatus();
   }

  /**
   * Transaction Success Objects
   */

  paymentStatus() {
    this._subscriptionService.currentOrderDetail.subscribe(x => {
      this.orderData = x      
    });

    if(this.orderData) {
      if(this.orderData.status == "paid") {
        
        /**
         * Transaction Congratz Objects for Claim
          */
        this.transactionObject = {
          errorId: "2",
          errorType: "success",
          errorTitle: "Subscription",
          icon: "fa-check",
          iconMessage: "Payment Successful",
          messages: [
            {
              messageContent: "Let's Setup your Account and Trafe information to do matchmaking process for your profile.",
            },
            {
              messageContent: "Profile Strenght more than 75 % is needed for ChannelHUB approval and makes us to suggest you better results.", 
            }
          ],
          button  : [{
            buttonType: "success",
            buttonName: "account-setup",
            buttonValue: "Go To Account Setup",
            buttonLink: "test()"
          }],
          showButtonBlock:true
        }
      
      }else if(this.orderData.status == "faild"){
        /**
       * Transaction Verification Objects
       */

        this.transactionObject = {
          errorId: "3",
          errorType: "Verified",
          errorTitle: "Transaction Failed!",
          icon: "",
          iconMessage: "",
          messages: [
            {
              messageContent: "Sorry Your Transaction is decalined / failed.",
            },
            {
              messageContent: "Please Retry your transaction by clicking retry or kindly cancel to restart your transaction", 
            }     
          ],
          button  : [
            {
              buttonType: "cancel",
              buttonName: "cancel",
              buttonValue: "Cancel",
              buttonLink: "showMessage()"
            },
            {
              buttonType: "retry",
              buttonName: "retry",
              buttonValue: "Retry",
              buttonLink: "showMessage()"
            }
          ],
          showButtonBlock:true
          }
        }
    }else {
        this.router.navigate(['/home/home']);  
      }   
   }

    /**
     * Transaction Congratz Objects for Claim
     */

    transactionObject2:SuccesErrorMessage = {
      errorId: "1",
      errorType: "congrats",
      errorTitle: "Congratulations!",
      icon: "",
      iconMessage: "",
      messages: [
        {
          messageContent: "Claim Report Submitted Successfully!",
        },
        {
          messageContent: "Complaint registration number: "+ this.value, 
        }
        ,
        {
          messageContent: "Your requested has been forwarded to concern team for verification process.", 
        }
        ,
        {
          messageContent: "You will hear from us within 48 hrs."
        },
        {
          messageContent: "Incase you want to contact us, please write to report_claim@channelhub.com with complaint number"
        }
      ],
      button  : [{
        buttonType: "done",
        buttonName: "congrats",
        buttonValue: "Done",
        buttonLink: "test()"
      }],
      showButtonBlock:true
    }

  ngOnInit() {
   
  }

  showMessage(obj:any){ 
    if(obj.name == "account-setup") {
      this.router.navigate(['/account/account']);  
    }

    if(obj.name == "retry") {
      this.router.navigate(['/user/payment']);  
    } 
    
    if(obj.name == "cancel") {
      this.router.navigate(['/home/home']);  
    }
 }
}
