import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimCompanySuccessMessageComponent } from './claim-company-success-message.component';

describe('ClaimCompanySuccessMessageComponent', () => {
  let component: ClaimCompanySuccessMessageComponent;
  let fixture: ComponentFixture<ClaimCompanySuccessMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimCompanySuccessMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimCompanySuccessMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
