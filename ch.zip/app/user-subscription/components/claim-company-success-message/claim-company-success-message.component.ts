import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-company-success-message',
  templateUrl: './claim-company-success-message.component.html',
  styleUrls: ['./claim-company-success-message.component.scss']
})
export class ClaimCompanySuccessMessageComponent implements OnInit {
  public title: any = "Congratulations";
  constructor() { }

  ngOnInit() {
  }

}
