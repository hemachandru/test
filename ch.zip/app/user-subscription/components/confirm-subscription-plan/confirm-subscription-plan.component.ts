import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { SubscriptionService } from '../../service/subscription.service';
import { OrderDetails } from "@app/config/constant"
import { UserSubscriptionBusiness } from '../../business/user-subscription.business';
import { AppLocalStorageKeys } from '../../../../environments/environment'

@Component({
  selector: 'app-confirm-subscription-plan',
  templateUrl: './confirm-subscription-plan.component.html',
  styleUrls: ['./confirm-subscription-plan.component.scss']
})
export class ConfirmSubscriptionPlanComponent implements OnInit {
  couponCodeForm: FormGroup;
  formSubmit = false;
  public title: any = "Confirm Subscription Plan";
  private order: OrderDetails;
  public showCard: boolean = false;
  public herebyAcceptBool: any;
  public herebyAcceptBoolError: any;

  public order_id: any;
  public subscription_id: any;
  public coupon_code: any;
  public order_amount: any;
  public plan_name: any;
  public plan_cost: any;
  public plan_total: any;
  public plan_subtotal: any;
  public plan_amount_pay: any;
  public couponMsg: any;
  public couponDiscountMsg: any;
  public couponErrorBool: any = 0;
  public couponBool: boolean = false;
  public couponDiscountBool: boolean = false;
  public couponCodeData: any = {};
  public subscriptionIdData: any = {};

  constructor(private fb: FormBuilder, private userSubscriptionBusiness: UserSubscriptionBusiness,
    private _subscriptionService: SubscriptionService, private router: Router) {
    this.order = new OrderDetails();
    this.order.id = "WERF5345GFDG43";
    this.order.status = "paid";
  }
  public loading = false;

  ngOnInit() {
    this.initForm(); 
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_PLAN_DETAIL));
    //{"subscriptionId":11,"amount":"0.00","planName":"Free"}
    this.plan_name = data.planName;
    this.plan_cost = data.amount;
    this.plan_total = data.amount;
    this.plan_subtotal = data.amount;
    this.plan_amount_pay = data.amount;
    if (this.plan_cost == 0 || this.plan_cost == 0.00) {
      this.showCard = false;
    } else {
      this.showCard = true;
    }
    // this.showCard = true;
    // console.log('Data : ', data);
  }

  //subscriptionplan
  changePlan() {
    this.router.navigate(['/user/subscriptionplan']);
  }
  callSubsribe() {
    this.loading = true;
    let values = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    let resetMessage = this.userSubscriptionBusiness.subscriptionDataPostBusiness(values).subscribe(result => {
      // console.log('success..!', result);
      // this.loading = false;
      if (result.length) {
        const errors = result;
        if (errors) {
          this.loading = false;
          errors.forEach(val => {
            // console.log(val.errors[0].code);
          });
        }
      } else {
        // this.loading = false;
        console.log('callSubsribe success..!');
        let channel_subscriptionId = values.channel.subscriptionId;
        this.callSubscriptionIdGet(channel_subscriptionId);
      }
    },
      (error) => {
        console.log(error);
      });

    // this.openCheckout(this.order_id, this.subscription_id, this.coupon_code, this.order_amount);
  }
  /** Payment strip popup */

  callSubscriptionIdGet(channel_subscriptionId) {
    this.subscriptionIdData = {
      "subscribtionId": channel_subscriptionId,
      "couponCode": this.couponCodeData.couponCode
    }
    let resetMessage = this.userSubscriptionBusiness.subscriptionIdPostBusiness(this.subscriptionIdData).subscribe(result => {
      if (result.length) {
        const errors = result;
        if (errors) {
          this.loading = false;
          errors.forEach(val => {
            // console.log(val.errors[0].code);
          });
        }
      } else {
        this.loading = false;
        // console.log('callSubscriptionIdGet result..! : ', result);
        // this.couponCodeData = {
        //   "couponCode": "GFER2345",

        this.order_id = result.transactionId;
        this.subscription_id = channel_subscriptionId;
        this.coupon_code = this.couponCodeData.couponCode;
        this.order_amount = result.amount;
        console.log('this.coupon_code : ', this.coupon_code);
        this.openCheckout(this.order_id, this.subscription_id, this.coupon_code, this.order_amount);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  openCheckout(order_id: any, subscription_id: any, coupon_code: any, order_amount: any) {
    let self = this;
    var handler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_DVXKyv7Bc55F9bdJZhEv9qRr',
      locale: 'auto',
      // metadata: {'order_id': '6735'},  // Order id
      image: 'assets/images/logo-icon.png',
      // email: "channelHub@gmail.com", //user mail id
      token: function (token: any) {
        // console.log('Payment successful!', token);
        self.order.id = order_id;
        self.order.status = "paid";

        let paymentData = {
          "subscribtionId": subscription_id,
          "transactionId": order_id,
          "couponCode": coupon_code,
          "token": token.id,
          "amount": order_amount
        }
        self.userSubscriptionBusiness.payemntProcess(paymentData).subscribe(result => {
          self._subscriptionService.onOrderDetail(self.order);
          self.loading = true;
          self.router.navigate(['/user/transaction']);
        },
          (error) => {
            console.log(error);
          });
      }
    }, function (err, charge) {
      self.order.id = "WERF5345GFDG40";
      self.order.status = "faild";

      self._subscriptionService.onOrderDetail(self.order);
      self.router.navigate(['/user/transaction']);
    });

    handler.open({
      name: 'ChannelHub',
      description: 'Payment Process',
      // amount: 23000,
      amount: parseInt(order_amount),
      currency: 'nok',
      source: "tok_mastercard", // obtained with Stripe.js
    });
  }

  initForm() {
    this.couponCodeForm = this.fb.group({
      coupon: ['',
        Validators.compose(
          [
            //Validators.required
          ]
        )
      ]
    }
    );
  }

  herebyAccept(event) {
    this.herebyAcceptBool = event.target.checked;
  }

  //check coupon code
  onSubmit() {
    // console.log('dfdfdfdf : ', this.herebyAcceptBool);
    this.loading = true;
    const values = this.couponCodeForm.value;
    let value = {};
    // let values = {
    //   'couponCode': this.couponCodeForm.value,
    //   'subscriptionId': 122
    // } SubscrpitionPlanDetail   SubscrpitionData    
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_PLAN_DETAIL));
    let Channeldata = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    let subscriptionId = parseInt(data.subscriptionId);
    let channelTypeId = parseInt(Channeldata.channel.channelTypeId);
    let couponCodeValue = this.couponCodeForm.value.coupon;

    this.couponCodeData = {
      "couponCode": couponCodeValue,
      "subscriptionId": subscriptionId,
      "channelTypeId": channelTypeId
    }
    // this.couponCodeData = {
    //   "couponCode": "GFER2345",
    //   "subscriptionId":1,
    //   "channelTypeId": 2
    // }

    const keys = Object.keys(values);
    if (this.couponCodeForm.valid) {
      let resetMessage = this.userSubscriptionBusiness.checkCouponCodeBusiness(this.couponCodeData).subscribe(result => {
        if (result.length) {
          const errors = result;
          if (errors) {
            this.loading = false;
            errors.forEach(val => {
              // console.log(val.errors[0].code);
              if (val.errors[0].code === 1659) {
                this.couponMsg = val.errors[0].message;
                this.couponErrorBool = 0;
                this.couponBool = true;
                this.couponDiscountBool = false;
              }
              if (val.errors[0].code === 1682) {
                this.couponMsg = val.errors[0].message;
                this.couponErrorBool = 0;
                this.couponBool = true;
                this.couponDiscountBool = false;
              }
            });
          }
        } else {
          this.couponMsg = 'Coupon Applied'
          //this.couponMsg = 'Coupon Discount Amount '+ result.couponOfferValue + ' Rupees';
          this.couponErrorBool = 1;
          this.couponBool = true;
          // console.log('discountUnit..! : ', result.discountUnit);
          // console.log('couponOfferValue..! : ', result.couponOfferValue);
          if (result.discountUnit == 1) {
            // - calc
            this.plan_amount_pay = "";
            let offerPrice = parseInt(data.amount) - parseInt(result.couponOfferValue);
            this.plan_subtotal = offerPrice + ".00";
            this.plan_amount_pay = offerPrice + ".00";
            this.couponDiscountMsg = '$ ' + result.couponOfferValue + ' .00';
            this.loading = false;
            this.couponDiscountBool = true;
          } else {
            // % calc
            this.plan_amount_pay = "";
            let discountAmt = parseInt(data.amount) / parseInt(result.couponOfferValue);
            let finalAmt = parseInt(data.amount) - discountAmt;
            this.plan_subtotal = finalAmt.toFixed(2);;
            this.plan_amount_pay = finalAmt.toFixed(2);
            this.couponDiscountMsg = '$ ' + discountAmt + ' (' + result.couponOfferValue + '%)';
            this.loading = false;
            this.couponDiscountBool = true;
            //console.log('Discount Price : ', discountAmt.toFixed(2), 'Final Price : ', finalAmt.toFixed(2));
          }
        }
      },
        (error) => {
          console.log(error);
        });
    } else {
      keys.forEach(val => {
        const ctrl = this.couponCodeForm.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        };
      });
    }
  }
}
