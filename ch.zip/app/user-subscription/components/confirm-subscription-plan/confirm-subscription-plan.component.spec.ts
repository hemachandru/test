import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmSubscriptionPlanComponent } from './confirm-subscription-plan.component';

describe('ConfirmSubscriptionPlanComponent', () => {
  let component: ConfirmSubscriptionPlanComponent;
  let fixture: ComponentFixture<ConfirmSubscriptionPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmSubscriptionPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmSubscriptionPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
