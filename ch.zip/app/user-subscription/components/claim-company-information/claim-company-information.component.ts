import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { ChannelSubscriptionData, Billingaddress, CompanyAddress, Address } from '../../models/subscription';
import { ActivatedRoute, Router } from '@angular/router';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AppLocalStorageKeys } from '../../../../environments/environment';

@Component({
  selector: 'app-claim-company-information',
  templateUrl: './claim-company-information.component.html',
  styleUrls: ['./claim-company-information.component.scss']
})
export class ClaimCompanyInformationComponent implements OnInit {
  public pageHeadder: any = "Company Information";
  public title: any = "";
  formSubmit = false;
  claimCompanyInfo: FormGroup;
  companyData: ChannelSubscriptionData;

  constructor(private router: Router, private fb: FormBuilder) { }

  ngOnInit() {
    this.initForm();
    this.fillForm();
    //this.setPageHeader();
  }

  fillForm() {
    let data = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    this.companyData = data as ChannelSubscriptionData;
    this.claimCompanyInfo.controls['companyName'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.companyName) ? this.companyData.channel.companyName : '');
    this.claimCompanyInfo.controls['companyAddress'].setValue(!ValidationService.isNullOrEmpty(this.companyData.channel.address.companyAddress.address) ? this.companyData.channel.address.companyAddress.address : '');

  }

  initForm() {
    const companyName = '';
    const companyAddress = '';

    this.claimCompanyInfo = this.fb.group({
      companyName: ['', Validators.compose([Validators.required])],
      companyAddress: ['', Validators.compose([Validators.required])],
    });
  }

  onSubmit() {
    let values = this.claimCompanyInfo.value;
    const keys = Object.keys(values);
    this.formSubmit = true;
    if (this.claimCompanyInfo.valid) {
      this.companyData.channel.companyName = values.companyName;
      let companyAddress: CompanyAddress = new CompanyAddress();
      companyAddress.address = values.companyAddress;
      let address = { 'companyAddress': companyAddress }
      this.companyData.channel.address = address;

      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.companyData));
      this.router.navigate(['/user/claim_contact_info']);
    } else {
      keys.forEach(val => {
        const ctrl = this.claimCompanyInfo.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        };
      });
    }
  }

}
