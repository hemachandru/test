import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimCompanyInformationComponent } from './claim-company-information.component';

describe('ClaimCompanyInformationComponent', () => {
  let component: ClaimCompanyInformationComponent;
  let fixture: ComponentFixture<ClaimCompanyInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimCompanyInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimCompanyInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
