import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimContactInformationComponent } from './claim-contact-information.component';

describe('ClaimContactInformationComponent', () => {
  let component: ClaimContactInformationComponent;
  let fixture: ComponentFixture<ClaimContactInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimContactInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimContactInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
