import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-contact-information',
  templateUrl: './claim-contact-information.component.html',
  styleUrls: ['./claim-contact-information.component.scss']
})
export class ClaimContactInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
