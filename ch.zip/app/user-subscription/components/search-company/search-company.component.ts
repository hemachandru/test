import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { ActivatedRoute, Router } from '@angular/router';
import 'rxjs/add/operator/filter';
import { ISlimScrollOptions } from 'ng2-slimscroll';

import { SearchService } from '../../../shared/shared-service/search.service';
import { debug } from 'util';
import { ChannelSubscriptionData, Billingaddress, CompanyAddress, Address, Channel } from '../../models/subscription';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ApiUrl, AppLocalStorageKeys } from '../../../../environments/environment';

@Component({
  selector: 'app-search-company',
  templateUrl: './search-company.component.html',
  styleUrls: ['./search-company.component.scss'],
  providers: [SearchService]
})
export class SearchCompanyComponent implements OnInit {
  private apiUrl = ApiUrl;

  public title: any;
  public search: any;
  public autosearchResult: any;
  public enteredResult: any;
  public resultshow: any;
  public existingMoreDataResult: any = false;
  public claimMoreDataResult: any = false;
  public currentResult = [];
  public claimResult = [];
  public sameData: any = false;

  results: Object;
  searchTerm$ = new Subject<string>();
  data$ = new Subject<string>();

  public opts: ISlimScrollOptions;

  public channelTypeId: number;
  public isClaim: any = 0;
  public channelTypeName: any;
  public SubscrpitionData: any;
  private channelSubscriptionData: ChannelSubscriptionData;

  constructor(private searchService: SearchService, private route: ActivatedRoute, private router: Router) {
    this.channelSubscriptionData = new ChannelSubscriptionData();
    this.route.queryParams
      .filter(params => params.channelTypeId)
      .subscribe(params => {
        this.channelTypeId = params.channelTypeId;
        this.channelTypeName = params.channelTypeName;

        this.SubscrpitionData = [{
          'user': {
            "channelTypeId": this.channelTypeId,
            "channelTypeName": this.channelTypeName
          }
        }
        ]
        this.channelSubscriptionData.channel = new Channel();
        this.channelSubscriptionData.channel.channelTypeId = parseInt(this.channelTypeId.toString());
        this.channelSubscriptionData.channel.channelTypeName = this.channelTypeName;

        localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.SubscrpitionData));
        let data = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA)
      });

    /*Search Function*/
    this.searchService.search(this.searchTerm$, this.channelTypeId)
      .subscribe(results => {
        this.results = results;
        this.searchEvent();
      });
  }

  ngOnInit() {
    this.title = "Add / Search Your Company";
    this.search = "";
    this.resultshow = false;
    this.autosearchResult = false;

    this.opts = {
      // position: 'left',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }

  /** Search Enter event
   * and
   * Search Button clcik event  * */

  searchEvent() {
    debugger;
    this.autosearchResult = false;
    // this.enteredResult = data;
    // this.search = data;
    this.resultshow = true;
    let formdata = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));
    this.currentResult = [];
    this.claimResult = [];

    this.currentResult = this.results[1];
    this.claimResult = this.results[0];

    for (let i = 0; i < this.claimResult.length; i++) {
      if (this.claimResult[i].companyName.toLowerCase() == this.search.toLowerCase()) {
        this.sameData = true;
        break;
      } else {
        this.sameData = false;
      }
    }

    for (let i = 0; i < this.currentResult.length; i++) {
      if (this.currentResult[i].companyName.toLowerCase() == this.search.toLowerCase()) {
        this.sameData = true;
        break;
      } else {
        this.sameData = false;
      }
    }

    this.autosearchResult = false;
    this.resultshow = true;

    // let resultValue: any = this.results;

    // if(resultValue){
    //   for(let j=0; j < resultValue.length; j++) {
    //     if(this.results[j].claimChannelId) {
    //       this.claimResult.push(this.results[j])
    //     } else {
    //       this.currentResult.push(this.results[j]);
    //     }
    //   }
    // }
  }

  searchlistSelection(data) {
    this.autosearchResult = false;
    this.enteredResult = data;
    this.search = data;
    // this.resultshow = true;
  }

  /**store value to local */

  registerFormFunction(dbtype, index) {
    let companyData = [];

    if (dbtype == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      delete (this.claimResult[index].verificationSentAt);
      delete (this.claimResult[index].verificationCode);

      companyData = [{
        'company': this.claimResult[index]
      }]
    } else if (dbtype == this.apiUrl.SUBSCRIPTION_TYPE_OLD) {
      delete (this.currentResult[index].verificationSentAt);
      delete (this.currentResult[index].verificationCode);

      companyData = [{
        'company': this.currentResult[index]
      }]
    } else if (dbtype == this.apiUrl.SUBSCRIPTION_TYPE_NEW) {
      for (let i = 0; i < this.claimResult.length; i++) {
        if (this.claimResult[i].companyName == index) {
          return false;
        }
      }

      for (let i = 0; i < this.currentResult.length; i++) {
        if (this.currentResult[i].companyName == index) {
          return false;
        }
      }

      companyData = [{
        'company': {
          "channelId": null,
          // "signUpStatusId": "9",
          "companyName": index,
          "companyMail": null,
          "countryId": null,
          "oldChannelId": null,
          "claimChannelId": null,
          "channelTypeId": this.channelTypeId,
          "regAddressId": null,
          "billAddressId": null,
          "regAddress": null,
          "billAddress": null
        }
      }]
    }

    let storageData = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_DATA));

    for (let i = 0; i < storageData.length; i++) {
      if (storageData[i].company) {

        delete (storageData[i].company);
      }
    }
debugger;
    let concatedData = storageData.concat(companyData);
    concatedData = concatedData.filter(o => !Object.keys(o).every(k => !o[k]));
    // localStorage.setItem('SubscrpitionData', JSON.stringify(concatedData));
    localStorage.removeItem(AppLocalStorageKeys.SUBSCRIPTION_DATA);
    console.log(JSON.stringify(companyData));
    if (companyData.length > 0 && companyData[0].company!=null && companyData[0].company!=undefined) {
      this.setSubscriptionData(companyData[0].company, dbtype);
      debugger;
      if (this.channelSubscriptionData.channel.subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
        this.router.navigate(['/user/claim_company_info'], { relativeTo: this.route });
      }
      else {
        this.router.navigate(['/user/register'], { relativeTo: this.route });
      }
    }
  }

  /* More button action*/
  moreData(typeofData) {
    if (typeofData == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.claimMoreDataResult = true;
    } else {
      this.existingMoreDataResult = true;
    }
  }

  setSubscriptionData(company: any, subscriptionType: string) {
    let regAddress = company.regAddress as CompanyAddress;
    let billAddress = company.billAddress as Billingaddress;

    this.channelSubscriptionData.channel.subscriptionType = subscriptionType;
    // if (!ValidationService.isNullOrEmpty(company.signUpStatusId)) {
    //   this.channelSubscriptionData.channel.signUpStatusId =company.signUpStatusId;
    // }
    this.channelSubscriptionData.channel.companyName = !ValidationService.isNullOrEmpty(company.companyName) ?
      company.companyName : "";

    this.channelSubscriptionData.channel.companyMail = !ValidationService.isNullOrEmpty(company.companyMail) ?
      company.companyMail : "";

    if (!ValidationService.isNullOrEmpty(company.oldChannelId)) {
      this.channelSubscriptionData.channel.oldChannelId = company.oldChannelId;
    }


    if (!ValidationService.isNullOrEmpty(company.regAddressId) && subscriptionType != this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.channelSubscriptionData.channel.regAddressId = company.regAddressId;
    }

    if (!ValidationService.isNullOrEmpty(company.billAddressId) && subscriptionType != this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.channelSubscriptionData.channel.billAddressId = company.billAddressId;
    }

    if (!ValidationService.isNullOrEmpty(company.channelId) && subscriptionType != this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.channelSubscriptionData.channel.channelId = company.channelId;
    }

    if (!ValidationService.isNullOrEmpty(company.channelId) && subscriptionType == this.apiUrl.SUBSCRIPTION_TYPE_CLAIM) {
      this.channelSubscriptionData.channel.claimChannelId = parseInt(company.channelId);
    }

    if (!ValidationService.isNullOrEmpty(company.companyphone)) {
      this.channelSubscriptionData.channel.companyphone = company.companyphone;
    }

    if (!ValidationService.isNullOrEmpty(company.companyphone2)) {
      this.channelSubscriptionData.channel.companyphone2 = company.companyphone2;
    }

    if (!ValidationService.isNullOrEmpty(company.comapanywebside)) {
      this.channelSubscriptionData.channel.comapanywebside = company.comapanywebside;
    }

    if (!ValidationService.isNullOrEmpty(company.subscriptionId)) {
      this.channelSubscriptionData.channel.subscriptionId = company.subscriptionId;
    }

    this.channelSubscriptionData.channel.describtion = !ValidationService.isNullOrEmpty(company.describtion) ? company.describtion : "";

    let address = { 'companyAddress': regAddress, 'billingAddress': billAddress }
    this.channelSubscriptionData.channel.address = address;
    localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_DATA, JSON.stringify(this.channelSubscriptionData));
  }
}
