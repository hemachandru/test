import { RegisterCompanyInformationComponent } from './components/register-company-information/register-company-information.component';
import { SearchCompanyComponent } from './components/search-company/search-company.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterContactInformationComponent } from './components/register-contact-information/register-contact-information.component';
import { TransactionComponent } from './components/transaction/transaction.component';
import { ConfirmSubscriptionPlanComponent } from './components/confirm-subscription-plan/confirm-subscription-plan.component';
import { ClaimCompanyDocumentUploadComponent } from '@app/user-subscription/components/claim-company-document-upload/claim-company-document-upload.component';

import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { SubscriptionPlanComponent } from '@app/user-subscription/components/subscription-plan/subscription-plan.component';
import { ClaimCompanyInformationComponent } from '@app/user-subscription/components/claim-company-information/claim-company-information.component';
import { ClaimContactInformationComponent } from '@app/user-subscription/components/claim-contact-information/claim-contact-information.component';
import { ClaimCompanySuccessMessageComponent } from '@app/user-subscription/components/claim-company-success-message/claim-company-success-message.component';

const routes: Routes = [
  { path: '', redirectTo: 'user', pathMatch: 'full' },
  {
    path: 'user', children: [
      { path: 'search', component: SearchCompanyComponent, canActivate: [AuthGuard] },
      { path: 'register', component: RegisterCompanyInformationComponent, canActivate: [AuthGuard] },
      { path: 'transaction', component: TransactionComponent, canActivate: [AuthGuard] },
      { path: 'subscription_contact_info', component: RegisterContactInformationComponent, canActivate: [AuthGuard] },
      { path: 'confirmplan', component: ConfirmSubscriptionPlanComponent, canActivate: [AuthGuard] },
      { path: 'subscriptionplan', component: SubscriptionPlanComponent, canActivate: [AuthGuard] },
      { path: 'claim_company_document', component: ClaimCompanyDocumentUploadComponent, canActivate: [AuthGuard] },
      { path: 'claim_company_info', component: ClaimCompanyInformationComponent, canActivate: [AuthGuard] },
      { path: 'claim_contact_info', component: ClaimContactInformationComponent, canActivate: [AuthGuard] },
      { path: 'claim_company_success', component: ClaimCompanySuccessMessageComponent, canActivate: [AuthGuard] }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserSubscriptionRoutingModule { }
