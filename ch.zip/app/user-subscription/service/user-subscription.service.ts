import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';

@Injectable()
export class UserSubscriptionService {

  constructor(private http: HttpClient, private _httpReqService: HttpRequestService) { }

  subscriptionDataPostService(dataparams: any, url: string) {
    return this._httpReqService.postHttpRequest(dataparams, url);
  }

  getContactInfoGetService(dataparams: any, url: string) {
    return this._httpReqService.getHttpRequestWithData(dataparams, url);
  }

  getSubscribePeriodService(url: string) {
    return this._httpReqService.getHttpRequest(url);
  }


  getSubscribePlanService(dataparams: any, url: string) {
    return this._httpReqService.getHttpRequestWithData(dataparams, url);
  }

  uploadLinkedInImageService(dataparams: any, url: string) {
    return this._httpReqService.postHttpRequest(dataparams, url);
  }

}
