import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { OrderDetails } from "@app/config/constant"
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';

@Injectable()
export class SubscriptionService {
  private orderId: OrderDetails;
  private orderSource = new BehaviorSubject<OrderDetails>(this.orderId);
  currentOrderDetail = this.orderSource.asObservable();

  constructor(private http: HttpClient, private _httpReqService: HttpRequestService) { }

  onOrderDetail(orderobject: OrderDetails) {
    this.orderSource.next(orderobject);
  }

  paymentgateway(data, url) {
    // console.log(data);
    return this._httpReqService.postHttpRequest(data, url);
  }

}
