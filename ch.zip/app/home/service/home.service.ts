import { Injectable } from '@angular/core';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';


@Injectable()
export class HomeService {

  constructor(private _httpRequestService: HttpRequestService) { }

  getUserAuthorizationCode(data: any, url: string) {
    return this._httpRequestService.postHttpRequestAPPToken(data, url);
  }

  userSelection(url) {   
     return this._httpRequestService.getHttpRequest(url);
  }

}
