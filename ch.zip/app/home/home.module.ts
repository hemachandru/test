import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './containers/home/home.component';
import { HomeBannerComponent } from './components/home-banner/home-banner.component';
import { UserProfileSelectionComponent } from './components/user-profile-selection/user-profile-selection.component';
import { HomeBusiness } from './business/home.business';
import { HomeService } from './service/home.service';
const COMPONENTS = [
  HomeComponent
];

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule,
    SharedModule
  ],
  declarations: [
    ...COMPONENTS,
    HomeBannerComponent,
    UserProfileSelectionComponent
  ],
  exports: [
    HomeBannerComponent
  ],
  providers: [
    HomeBusiness,
    HomeService 
  ],
})
export class HomeModule { }
