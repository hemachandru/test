import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserProfileSelectionComponent } from './components/user-profile-selection/user-profile-selection.component';
import { HomeComponent } from './containers/home/home.component';

import { AuthGuard } from '../shared/shared-service/auth-guard.service';

const routes: Routes = [
  {path: '', redirectTo: 'home', pathMatch: 'full'},
  // {path: 'home', children: [
  //   {path: 'home', component: HomeComponent},
  //   {path: 'user_profile_selection', component: UserProfileSelectionComponent},
  // ]}
  {path: 'home', component: HomeComponent},
  {path: 'user_profile_selection', component: UserProfileSelectionComponent,canActivate: [AuthGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
