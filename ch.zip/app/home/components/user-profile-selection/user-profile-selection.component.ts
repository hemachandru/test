import { Component, OnInit } from '@angular/core';
import { userSelctionList } from '@app/config/constant';
import { HomeBusiness } from '../../business/home.business';
import { concat } from 'rxjs/operators/concat';

@Component({
  selector: 'app-user-profile-selection',
  templateUrl: './user-profile-selection.component.html',
  styleUrls: ['./user-profile-selection.component.scss']
})
export class UserProfileSelectionComponent implements OnInit {

  public title : any = "Please select your profile";
  public userlist:any = userSelctionList;
  public result: any;
  
  constructor(private _homeBusiness: HomeBusiness) { }

  ngOnInit() {
    this.getChannelType();
  }

  getChannelType() {
    this._homeBusiness.getUserselection().subscribe(data => {      
      this.result=data;
      for (let i =0; i<this.userlist.length;i++){
        this.userlist[i].id = this.result[i].channelTypeId;
        this.userlist[i].UserName = this.result[i].channelType && this.result[i].channelType.toLowerCase();
      }
    });
  }

}
