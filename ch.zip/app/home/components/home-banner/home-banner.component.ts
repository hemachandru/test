import { Component, OnInit } from '@angular/core';
import { SharedModule } from '@app/shared/shared.module';

import {TranslateService} from '@ngx-translate/core';
import { UserAccountStatus } from '@app/config/constant';


@Component({
  selector: 'app-home-banner',
  templateUrl: './home-banner.component.html',
  styleUrls: ['./home-banner.component.scss']
})
export class HomeBannerComponent implements OnInit {
  public isTokenExists:boolean;
  public userChannelStatus : any;
  public isSubscriptedUser: any = false;

  constructor(private translate: TranslateService) {
    translate.addLangs(["en", "fr"]);
    translate.setDefaultLang('en');
    let browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
   }

  ngOnInit() {
    this.userChannelStatus = localStorage.getItem('user_channelstatus');
    this.isTokenExists = localStorage.getItem('authToken')!=null && localStorage.getItem('authToken')!=''?true:false;
    if(this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP ||
      this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_COMPANYPROFILE||
      this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION||
      this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADELOCATION) {              
        this.isSubscriptedUser = true;
    }else {                        
      this.isSubscriptedUser = false;      
    } 
  }

}
