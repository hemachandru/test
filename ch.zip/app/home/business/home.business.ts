import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HomeService } from '../service/home.service';
import { environment, ApiUrl,AppLocalStorageKeys } from '../../../environments/environment';

@Injectable()
export class HomeBusiness {
  private apiUrl = ApiUrl;
  private environment = environment;

  constructor(private _homeService: HomeService, private router: Router) {
  }

  getUserAuthorizationCode() {
    var self = this;
    let tokenBodyData = {
      'clientKey': self.environment.clientKey,
      'secretKey': self.environment.secretKey
    }

    let url = this.apiUrl.APP;
    return this._homeService.getUserAuthorizationCode(tokenBodyData, url).map(res => {
      localStorage.setItem(AppLocalStorageKeys.APP_Token, res.Authorization);
    });  
  }

  getUserselection() {
    let url:any = this.apiUrl.CHANNELTYPE;
    return this._homeService.userSelection(url)
      .map(res => {         
          return res;
      });   
  }
}
