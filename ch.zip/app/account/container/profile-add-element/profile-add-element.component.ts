import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-profile-add-element',
  templateUrl: './profile-add-element.component.html',
  styleUrls: ['./profile-add-element.component.scss']
})

export class ProfileAddElementComponent implements OnInit {
  accCertiId: Array <any> =[];
  accCertificate: string = '';
  @Output() accAddClick = new EventEmitter<any>();
  @Input() multipleData: string;

  constructor() {
    // this.accCertiId = [];    
   }

  ngOnInit() {
    // this.commonLabel = this.multipleData;
  }

  addCertificateId(val:any) {
    if(val.length<3 || val.length>70)
    return false;
    this.accCertiId.push(val);
    this.accCertificate ="";
    // this.accAddClick.emit(this.accCertiId);
   }

   deleteCertificateId(index) {
    this.accCertiId.splice(index,1);
   }
}
