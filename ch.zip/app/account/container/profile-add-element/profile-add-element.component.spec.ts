import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileAddElementComponent } from './profile-add-element.component';

describe('ProfileAddElementComponent', () => {
  let component: ProfileAddElementComponent;
  let fixture: ComponentFixture<ProfileAddElementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileAddElementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileAddElementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
