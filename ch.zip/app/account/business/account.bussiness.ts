import { Injectable } from '@angular/core';

import { ApiUrl } from '../../../environments/environment';

import { AccountService } from './../services/account.service';
import { Profile } from './../models/profile';

@Injectable()
export class AccountBusiness {
    private apiUrl = ApiUrl;
    constructor(private _accountService: AccountService) {
    }

    getSellingZoneBusiness() {
        let url: any = this.apiUrl.ZONE_LIST;
        return this._accountService.getAccountListService(url).map(res => {
            return res
        });
    }

    postZoneRegionCompanyBusiness(zoneID_list) {
        let url:any = this.apiUrl.ZONE_BASED_REGION_COUNTRY;
        return this._accountService.postAccountService(zoneID_list, url).map(res => {
          return res;
        });   
    }

    postProfile(profile: Profile) {
        let url:any = this.apiUrl.POST_COMPANY;
        return this._accountService.postAccountService(profile, url).map(res => {
            return res;
        });
    }

    getUserProfileBusiness() {
        let url: any = this.apiUrl.COMPANY;
        return this._accountService.getAccountListService(url)
            .map(res => {
                return res;
            });
    }

    // Trade Information
    //Customer Profile Search
    getCustomerProfile(name: string,channelId:string) {
        let url = this.apiUrl.CUSTOMER_PROFILE;
        return this._accountService.getradeInfoGetcustomerProfile(url,channelId,name).map(res => {
            return res;
        });
    }

    // List of Service Search
    getListService(searchkey: string) {
        let url = this.apiUrl.LIST_SERVICE;
        return this._accountService.getradeInfoGetService(searchkey, url).map(res => {
            return res;
        });
    }

    // Product Family
    getProductFamily(searchkey: string) {
        let url = this.apiUrl.PRODUCT_FAMILY;
        return this._accountService.getradeInfoGetService(searchkey, url).map(res => {
            return res;
        });
    }
    
    // Product Family
    getProductCategory(searchkey: string,subsearchkey:string) {
        let url = this.apiUrl.PRODUCT_CATEGORY;
        return this._accountService.getradeInfoGetsubService(searchkey, url,subsearchkey).map(res => {
            return res;
        });
    }
    
}