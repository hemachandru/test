import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TradeLocationComponent } from './trade-location.component';

describe('TradeLocationComponent', () => {
  let component: TradeLocationComponent;
  let fixture: ComponentFixture<TradeLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TradeLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TradeLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
