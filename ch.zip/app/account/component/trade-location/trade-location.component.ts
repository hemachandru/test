import { Component, OnInit,ViewChild,AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import {AccountModalConfirmComponent} from '../account-modal-confirm/account-modal-confirm.component';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import{LocationMapComponent} from '../location-map/location-map.component'
import { ISlimScrollOptions } from 'ng2-slimscroll';
const region = [
  {
    "id": "1",
    "name": "NCSA"
  },
  {
    "id": "2",
    "name": "AMER"
  },
  {
    "id": "3",
    "name": "AMS"
  },
  {
    "id": "4",
    "name": "NALA"
  },
  {
    "id": "5",
    "name": "Eastern Europe"
  },
  {
    "id": "6",
    "name": "Northern Europe"
  },
  {
    "id": "7",
    "name": "South Europe"
  },
  {
    "id": "8",
    "name": "West Europe"
  }
];

const country = [
  {
    "id": "1",
    "name": "Albania"
  },
  {
    "id": "2",
    "name": "Afghanistan"
  },
  {
    "id": "3",
    "name": " Algeria"
  },
  {
    "id": "4",
    "name": "Andorra"
  },
  {
    "id": "5",
    "name": "Argentina"
  },
  {
    "id": "6",
    "name": "Armenia"
  },
  {
    "id": "7",
    "name": "Aruba"
  },
  {
    "id": "8",
    "name": "Australia"
  },
  {
    "id": "9",
    "name": "Albania"
  },
  {
    "id": "10",
    "name": "Afghanistan"
  },
  {
    "id": "11",
    "name": " Algeria"
  },
  {
    "id": "12",
    "name": "Andorra"
  },
  {
    "id": "13",
    "name": "Argentina"
  },
  {
    "id": "14",
    "name": "Armenia"
  },
  {
    "id": "15",
    "name": "Aruba"
  },
  {
    "id": "16",
    "name": "Australia"
  },
  {
    "id": "17",
    "name": "Albania"
  }
];

@Component({
  selector: 'app-trade-location',
  templateUrl: './trade-location.component.html',
  styleUrls: ['./trade-location.component.scss']
})

export class TradeLocationComponent implements OnInit,AfterViewInit {

  public opts: ISlimScrollOptions;

  // public regionData = region;
  public regionData : any;
  // public countryData = country;
  public countryData : any;
  public zoneList : any;
  testData;
  public zoneID_list : any = {};

  public region_list :any[] = [];
  public country_list :any[] = [];

  public loading = false;
  public locationScale : boolean = false;
  @ViewChild(LocationMapComponent) locationMapComponent: LocationMapComponent;
  constructor(private dialog:MatDialog, private accountBusiness: AccountBusiness ) { }

  ngOnInit() {
    this.getSellingZone();
    this.opts = {
      //position: 'right',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }

  ngAfterViewInit() {
    console.log(`ngAfterViewInit - jokeViewChild is ${this.locationMapComponent}`);
  }

  getSellingZone(){
    this.loading = true;
    let resetMessage = this.accountBusiness.getSellingZoneBusiness().subscribe(result => {
      if(result){
        console.log('Zone List Result : ', result);
        this.zoneList = result;
        this.loading = false;
      }
      // this.loading = false;
    },
    (error) => {
      this.loading = false;
      console.log(error);
    });
  }

  checkZone(event){
    var zoneID = [];
    let chkZone ;
    if(event.target.checked == true){
      let chkZone = event.target.id;
      zoneID.push(chkZone);
    }
    // else if( event.target.checked == false){
    //   let chkZone = event.target.id;
    //   zoneID.slice(chkZone);
    // }
    // console.log(zoneID);

    this.zoneID_list = {
      "zone": zoneID
    }
    // console.log(this.zoneID_list);
    this.loading = true;
    let resetMessage = this.accountBusiness.postZoneRegionCompanyBusiness(this.zoneID_list).subscribe(result => {
      if(result){
        // console.log('Region Country List Result : ', result[0]);
        let regionLength = result[0].region.length;
        for(let i =0 ; i< regionLength ; i++){
            let regionData = {
              id: result[0].region[i].regionId,
              name: result[0].region[i].region
            };
            this.region_list.push(regionData);

          let countryLength = result[0].region[i].country.length;
          for(let j =0 ; j< countryLength ; j++){
              let countryData = {
                id: result[0].region[i].country[j].countryId,
                name: result[0].region[i].country[j].country,
                region_id: result[0].region[i].regionId
              };
              this.country_list.push(countryData);
          }
        }
        this.regionData = this.region_list;
        this.countryData = this.country_list;
        // this.countryDatas =  this.country_list;
        this.locationMapComponent.setMap(this.countryData);
        this.locationScale = true;
        this.loading = false;
        //  console.log('Region : ', this.region_list);
        //  console.log('Country : ', this.country_list);

      //    let map_ChartData = [
      //     ['Country'],
      //     ['Brazil'],
      //     ['IN']
      // ];
        
        // this.zoneList = result;
      }
    },
    (error) => {
      console.log(error);
    });

  }

  private async clickData(data: string): Promise<any> {
    this.testData = data;
    // region.splice(1);
    // console.log(region);
     console.log('Region : ', this.testData);
  }

  private async clickCountryData(data: string): Promise<any> {
    this.testData = data;
    // region.splice(1);
    // console.log(region);
    // console.log('Country : ', this.testData);
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(AccountModalConfirmComponent, {
      data: {
        firstName: "test", lastName: "test"
      }
    });

    dialogRef.afterClosed().subscribe(result => {     
      // console.log('after closed', result);
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    });
  }
}
