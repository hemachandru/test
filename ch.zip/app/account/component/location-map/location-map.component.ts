import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-location-map',
  templateUrl: './location-map.component.html',
  styleUrls: ['./location-map.component.scss']
})
export class LocationMapComponent implements OnInit {

  @Input() mapCountryListData = [];

  public map_ChartDatas = [];

  public map_ChartData = [
    ['Country'],
    // ['Brazil'],
    // ['IN']
];

public map_ChartOptions = {};
  public org_ChartOptions = {
      allowHtml: true
  };
  constructor() { }

  ngOnInit() {
    // console.log('Country List Map component Data : ', this.mapCountryListData)
  }

  setMap(val:any)
  {
    for(var i in val){
      this.map_ChartData.push([val[i].name]); 
    }
    // console.log('setMap : ',this.map_ChartData);
  }

}
