import { Component, OnInit } from '@angular/core';
import { SuccesErrorMessage, UserDetailMessage, Config, UserAccountStatus } from '@app/config/constant';

@Component({
  selector: 'app-account-verification',
  templateUrl: './account-verification.component.html',
  styleUrls: ['./account-verification.component.scss']
})
export class AccountVerificationComponent implements OnInit {
  public verificationObject: SuccesErrorMessage;
  channelHubContactMail:string = "testmail@test.com";
  constructor() { }

  ngOnInit() {
    this.bindVerificationPage();
  }

  bindVerificationPage()
  {
    this.verificationObject = {
      errorId: "2",
      errorType: "Verified",
      errorTitle: "Verification",
      icon: "",
      iconMessage: "",
      messages: [
        {
          messageContent: "Your profile is complete and sent for approval for more details contact "+this.channelHubContactMail,
        }
      ],
      button: [{
        buttonType: "",
        buttonName: "",
        buttonValue: "",
        buttonLink: ""
      }],
      showButtonBlock: false
    }

  }
}
