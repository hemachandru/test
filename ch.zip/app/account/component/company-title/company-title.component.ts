import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-company-title',
  templateUrl: './company-title.component.html',
  styleUrls: ['./company-title.component.scss']
})

export class CompanyTitleComponent implements OnInit {
  public title : any = "Account Setup";
  public percent : number = 20;
  @Input() profilePercentages:number;

  constructor() { }

  ngOnInit() {
    this.profilePercentages=20;
  }

}
