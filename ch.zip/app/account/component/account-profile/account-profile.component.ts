import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { AccountBusiness } from './../../business/account.bussiness';
import { Pipe, PipeTransform } from '@angular/core';
import { Config } from '@app/config/constant';
import { Profile, MultiCertificate, Certificate, Certify, ProfileAddress} from './../../models/profile';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ScrollToService } from 'ng2-scroll-to-el';

@Component({
  selector: 'app-account-profile',
  templateUrl: './account-profile.component.html',
  styleUrls: ['./account-profile.component.scss']
})

export class AccountProfileComponent implements OnInit {
  profileForm: FormGroup;
  public submitData: Profile;
  public defaultConfig: MultiCertificate;
  public certificate: Certificate = new Certificate();
  public profileAdd: ProfileAddress = new ProfileAddress();

  formSubmit = false;
  public WebsiteURL: any = "Website URL";
  public accCerficatedata: any = "Certificate No / ID";
  public accAwardIssued: any = "Issued By";
  public accOtherB2B: any = "Other B2B or Trade Portals Website URLs";
  public regCountry: string = "profileRegCountry";
  public billCountry: string = "profileBillCountry";
  public profileGetData: any = [];
  public proGetRegAddress: any = [];
  public proGetBillAddress: any = [];
  public getCountryId: string;
  public getCountryIdReg: number;
  public getCountryIdBill: number;
  controlname;
  control;
  public flag = 1;

  @Input() multipleData: any = '';
  @Input() getCountry: any = '';
  @Output() percentageOutput = new EventEmitter<any>();

  public regInfo: boolean = true;
  comInfo: boolean = false;
  collapsed3: boolean = false;
  taxInfo: boolean = false;
  awardsInfo: boolean = false;
  socialInfo: boolean = false;
  authorizedInfo: boolean = false;
  companyInfo: boolean = false;
  accCerficateIdNo: string = '';
  accCertificateName: string = '';
  profileAddressVal: string = '';
  profilePhoneVal: string = '';
  profileMobileVal: string = '';
  profileZipVal: string = '';
  profileCityVal: string = '';
  profilePhone2Val: string = '';
  profileemailVal: string = '';
  public sameBillAdd: boolean = false;
  public result: any;
  public someDate: Date;
  public percent: number = 20;
  constructor(private Const: Config, private fb: FormBuilder, private uploadService: UploadFileService, private _accountBusiness: AccountBusiness,
    private scrollService: ScrollToService) {
  }

  ngOnInit() {
    this.submitData = new Profile();
    this.defaultConfig = new MultiCertificate();
    this.initForm();
    console.log("Test",this.profileForm.controls['test'])
    this.getUserProfile();
    for (let i = 0; i < 3; i++) {
      this.defaultConfig.accCertiNameId.push(new Certify());
    }
  }

  onChangePercentage(event, flag) {
    if (flag == 0) {
      this.onCheckNewPercent(event);
    }
    else
      this.onCheckUpdatePercent(event);
    this.percentageOutput.emit(this.percent);
  }

  onCheckNewPercent(event) {
    if (this.profileForm.controls[event.target.name].valid && this.Const.flag_percent[event.target.name][1] == 1) {
      this.percent = this.percent + this.Const.flag_percent[event.target.name][0];
      this.Const.flag_percent[event.target.name][1] = 0;
    }
    else if (!this.profileForm.controls[event.target.name].valid && this.Const.flag_percent[event.target.name][1] == 0) {
      this.percent = this.percent - this.Const.flag_percent[event.target.name][0];
      this.Const.flag_percent[event.target.name][1] = 1;
    }
  }

  onCheckUpdatePercent(event) {
    if (this.profileForm.controls[event.target.name].valid && this.Const.flag_percent[event.target.name][1] == 0) {
      this.percent = this.percent + this.Const.flag_percent[event.target.name][0];
      this.Const.flag_percent[event.target.name][1] = 1;
    }
    else if (!this.profileForm.controls[event.target.name].valid && this.Const.flag_percent[event.target.name][1] == 1) {
      this.percent = this.percent - this.Const.flag_percent[event.target.name][0];
      this.Const.flag_percent[event.target.name][1] = 0;
    }
  }

  addCertificateIdName(arr, val, valId, IssueBy) {
    if (!this.profileForm.controls[val].valid || !this.profileForm.controls[valId].valid)
      return false;
    arr != 2 ? this.defaultConfig.accCertiNameId[arr].certi.push({ "name": this.profileForm.controls[val].value, "id": this.profileForm.controls[valId].value } as Certificate) :
      this.defaultConfig.accCertiNameId[arr].certi.push({ "details": this.profileForm.controls[val].value, "issued_by": this.profileForm.controls[valId].value, "valid_upto": this.profileForm.controls[IssueBy].value } as Certificate);
    this.profileForm.controls[val].reset();
    this.profileForm.controls[valId].reset();
    if(arr == 2)
    this.profileForm.controls[IssueBy].reset();
  }

  deleteCertificateIdName(arr, index) {
    this.defaultConfig.accCertiNameId[arr].certi.splice(index, 1);
  }

  private async getContryID(data: string): Promise<any> {
    this.profileAdd.countryId = parseInt(data, 10);
    if (data) {
      this.getCountryIdBill=(this.sameBillAdd)?this.profileAdd.countryId:this.getCountryIdBill;
    }
  }

  onSubmit() {
    this.submitData.company_logo_url = this.defaultConfig.arrImage[0].loc;
    this.submitData.company_icon_url = this.defaultConfig.arrImage[1].loc;
    this.submitData.company_name = this.profileForm.controls['legalName'].value;

    this.submitData.registeration_certificate = this.defaultConfig.accCertiNameId[0].certi;
    this.submitData.year_of_estabilishment = this.profileForm.controls['establishYear'].value;
    this.submitData.year_of_registration = this.profileForm.controls['registrationYear'].value;
    this.submitData.reg_address = this.profileForm.controls['profileAddress'].value;
    this.submitData.reg_country_id = this.getCountryIdReg;
    this.submitData.bill_country_id = this.getCountryIdBill;
    this.submitData.reg_postal_code = parseInt(this.profileForm.controls['profileZip'].value);
    this.submitData.reg_city = this.profileForm.controls['profileCity'].value;
    this.submitData.reg_address_id = parseInt(this.defaultConfig.jsonData.channel.regAddress.addressId);
    this.submitData.bill_address_id = parseInt(this.defaultConfig.jsonData.channel.billAddress.addressId);

    this.submitData.company_phone1 = this.profileForm.controls['profilePhone'].value;
    this.submitData.company_phone2 = this.profileForm.controls['profilePhone2'].value;
    this.submitData.company_mobile_no = this.profileForm.controls['profileMobile'].value;
    this.submitData.company_email = this.profileForm.controls['profileemail'].value;
    this.submitData.company_about = this.defaultConfig.htmlContent;

    this.submitData.bill_address = this.profileForm.controls['profileRegAdd'].value;
    this.submitData.bill_postal_code = parseInt(this.profileForm.controls['profileRegZip'].value);
    this.submitData.bill_city = this.profileForm.controls['profileRegcity'].value;
    this.submitData.is_same_address = this.sameBillAdd == true ? 1 : 0;

    this.submitData.company_website_url = this.profileForm.controls['profileWebsiteURL'].value;
    this.submitData.tax_certificate = this.defaultConfig.accCertiNameId[1].certi;
    this.submitData.award_details = this.defaultConfig.accCertiNameId[2].certi;

    this.submitData.social_linkedin_url = this.profileForm.controls['profilelinkedURL'].value;
    this.submitData.social_googleplus_url = this.profileForm.controls['profileGoogleURL'].value;
    this.submitData.social_instagram_url = this.profileForm.controls['profileInstaURL'].value;
    this.submitData.B2B_url = this.profileForm.controls['profileb2b'].value;

    this.submitData.contact_first_name = this.profileForm.controls['profileFirstName'].value;
    this.submitData.contact_last_name = this.profileForm.controls['profileLastname'].value;
    this.submitData.contact_phone1 = this.profileForm.controls['profileContactno'].value;
    this.submitData.contact_phone2 = this.profileForm.controls['profileAuthCont2'].value;
    this.submitData.contact_mobile_no = this.profileForm.controls['profileAuthmob'].value;
    this.submitData.contact_email = this.profileForm.controls['profileAuthEmail'].value;
    this.submitData.contact_job_title = this.profileForm.controls['profileJobtitle'].value;
    this.submitData.contact_linkedin_url = this.profileForm.controls['profileAuthLink'].value;
    this.submitData.contact_profile_image_url = this.defaultConfig.arrImage[2].loc;
    this.submitData.company_owner_first_name = this.profileForm.controls['ownerFirstName'].value;

    this.submitData.company_owner_last_name = this.profileForm.controls['ownerLastName'].value;
    // if(this.profileForm.valid){
    // debugger;
    console.log(this.submitData);
    let flagValid= true;
    Object.keys( this.profileForm.controls).forEach(key => {
      console.log(key);
      if(key!="regcertificate" && key!="accCerficateId") {
        console.log("Validation*********",key,this.profileForm.controls[key].valid)
        flagValid=this.profileForm.controls[key].valid?true:false;
        if(flagValid == false)
        return false;
      }
   });
    localStorage.setItem('hhhhhhh', JSON.stringify(this.submitData));

    // if(flagValid == true) {
    //     this._accountBusiness.postProfile(this.submitData).subscribe(res => {
    //   localStorage.setItem('hhhhhhh', JSON.stringify(this.submitData));
    // }), (error) => {
    //   console.log(error);
    // };  
    // }
    
    // this._accountBusiness.postProfile(this.submitData).subscribe(res => {
    //   localStorage.setItem('hhhhhhh', JSON.stringify(this.submitData));
    // }), (error) => {
    //   console.log(error);
    // };
    // }
  }

  getDateFormat(date) {
    var dateParse = new Date(date);
    return [
      dateParse.getFullYear(),
      ('0' + (dateParse.getMonth() + 1)).slice(-2),
      ('0' + dateParse.getDate()).slice(-2)
    ].join('-');
  }

  scrollTop(el) {
    this.scrollService.scrollTo(el,1000);
  }
  
getUserProfile() {
    this._accountBusiness.getUserProfileBusiness().subscribe(data => {
      this.defaultConfig.preloader= false;
      if(data.length>0){

      }
      else {
        this.defaultConfig.jsonData = data;
        console.log("********************************",data);
  
        this.profileGetData = this.defaultConfig.jsonData;
        this.profileForm.controls['legalName'].setValue(this.profileGetData.channel.companyName);
        this.profileForm.controls['ownerFirstName'].setValue(this.profileGetData.channel.companyName);
        this.profileForm.controls['ownerLastName'].setValue(this.profileGetData.channel.companyName);
        this.profileForm.controls['establishYear'].setValue(this.getDateFormat(this.profileGetData.channel.channelDetail.estYear));
        this.profileForm.controls['registrationYear'].setValue(this.getDateFormat(this.profileGetData.channel.channelDetail.regYear));
        this.profileForm.controls['profileAddress'].setValue(this.profileGetData.channel.regAddress.address);
        this.profileForm.controls['profileZip'].setValue(this.profileGetData.channel.regAddress.postalCode);
        this.profileForm.controls['profileCity'].setValue(this.profileGetData.channel.regAddress.city);
        this.profileForm.controls['profileemail'].setValue(this.profileGetData.channel.company_email);
  
        this.proGetRegAddress = this.defaultConfig.jsonData.channel.regAddress;
        this.proGetBillAddress = this.defaultConfig.jsonData.channel.billAddress;
  
        this.sameBillAdd = (this.defaultConfig.jsonData.channel.regAddress.addressId !=
          this.defaultConfig.jsonData.channel.billAddress.addressId) ? false : true;
        this.profileForm.controls['profileRegAdd'].setValue(this.profileGetData.channel.billAddress.address);
        this.profileForm.controls['profileRegZip'].setValue(this.profileGetData.channel.billAddress.postalCode);
        this.profileForm.controls['profileRegcity'].setValue(this.profileGetData.channel.regAddress.city);
  
        this.profileForm.controls['profilePhone'].setValue(this.profileGetData.contact.phone1);
        this.profileForm.controls['profilePhone2'].setValue(this.profileGetData.contact.phone2);
        this.profileForm.controls['profileMobile'].setValue(this.profileGetData.contact.mobileNo);
  
        this.profileForm.controls['profileWebsiteURL'].setValue(this.profileGetData.channel.channelDetail.webSiteUrl);
        this.profileForm.controls['profileFirstName'].setValue(this.profileGetData.contact.firstName);
        this.profileForm.controls['profileLastname'].setValue(this.profileGetData.contact.lastName);
        this.profileForm.controls['profileAuthEmail'].setValue(this.profileGetData.contact.email);
  
        this.profileForm.controls['profileContactno'].setValue(this.profileGetData.contact.phone1);
        this.profileForm.controls['profileAuthCont2'].setValue(this.profileGetData.contact.phone2);
        this.profileForm.controls['profileJobtitle'].setValue(this.profileGetData.contact.jobTitle);
        this.profileForm.controls['profileAuthLink'].setValue(this.profileGetData.contact.linkedIn);
        this.getCountryId = this.defaultConfig.jsonData.channel.countryId;
        this.getCountryIdReg = parseInt(this.defaultConfig.jsonData.channel.regAddress.countryId);
        this.getCountryIdBill = parseInt(this.defaultConfig.jsonData.channel.billAddress.countryId);
        console.log(this.profileGetData.channel.companyName, "STarted", this.defaultConfig.jsonData)
      }

    }), (error) => {
      this.defaultConfig.preloader= false;
        console.log(error+"error");
      };


  }

  async accountProfileUpload(event, urlLink) {
    let selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    console.log(event.target.files[0]);
    if (file) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.defaultConfig.arrImage[urlLink].src = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);
      let folderName = "account-s3/"
      const resImagePath: any = await this.uploadService.uploadfile(file, folderName);
      this.defaultConfig.arrImage[urlLink].loc = resImagePath.Location;
      alert(this.defaultConfig.arrImage[urlLink].loc)
      // this.profileForm.controls['fileprofileLogo'].status = true;
      this.onChangePercentage(event, 0)
    }
  }

  initForm() {
    this.profileForm = this.fb.group({
      test:'',
      fileprofileLogo: [],
      ownerFirstName: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      ownerLastName: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      profileAuthEmail: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      fileprofileFavicon: [],
      legalName: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(2)
          ]
        )
      ],
      regcertificate: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(35)
          ])],
      accCerficateId: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(70)
          ]
        )],
      establishYear: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )],
      registrationYear: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )],
      profileAddress: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(254)
          ]
        )],
      profileZip: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(10),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileCity: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileRegAdd: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(254)
          ]
        )],
      profileRegZip: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(10),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileRegcity: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profilePhone: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(8),
            Validators.maxLength(10),
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profilePhone2: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(8),
            Validators.maxLength(10),
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profileMobile: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profileemail: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.Const.emailPattern)
          ]
        )],
      profileTaxCertiId: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(254),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileTaxCertno: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(254),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileAwardDtl: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(254),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileValidTill: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )],
      profileIssuedBy: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(254),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profilelinkedURL: ['',
        Validators.compose(
          [
            Validators.minLength(25),
            Validators.maxLength(254),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
      profileGoogleURL: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(25),
            Validators.maxLength(254),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
      profileInstaURL: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(254),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
      profileWebsiteURL: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(253),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
      profileb2b: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(253),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
      profileFirstName: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(1),
            Validators.maxLength(30),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileLastname: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(1),
            Validators.maxLength(30),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileContactno: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(8),
            Validators.maxLength(15),
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profileAuthCont2: ['',
        Validators.compose(
          [
            Validators.minLength(8),
            Validators.maxLength(15),
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profileAuthmob: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(15),
            Validators.pattern(this.Const.mobnumPattern)
          ]
        )],
      profileJobtitle: ['',
        Validators.compose(
          [
            Validators.minLength(2),
            Validators.maxLength(50),
            Validators.pattern(this.Const.alphaNumericPattern)
          ]
        )],
      profileAuthLink: ['',
        Validators.compose(
          [
            Validators.minLength(2),
            Validators.maxLength(50),
            // Validators.pattern(this.Const.urlPattern)          
          ]
        )],
    });

    // console.log("we*****"+this.profileForm.controls['profileJobtitle'].valid);
  }




  onAdClick(list: Array<any>) {
    console.log('******************', list);
  }

  onAdClick1(list: Array<any>) {
    console.log('list2', list);
  }

  accTaxCerti(list: Array<any>) {
    console.log('list3', list);
  }

  accAwardIssue(list: Array<any>) {
    console.log('list3', list);
  }

  accOtherB2BFun(list: Array<any>) {
    console.log('list3', list);
  }

}
