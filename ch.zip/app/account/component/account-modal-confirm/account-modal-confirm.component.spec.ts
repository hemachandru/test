import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountModalConfirmComponent } from './account-modal-confirm.component';

describe('AccountModalConfirmComponent', () => {
  let component: AccountModalConfirmComponent;
  let fixture: ComponentFixture<AccountModalConfirmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountModalConfirmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountModalConfirmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
