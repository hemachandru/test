import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-account-modal-confirm',
  templateUrl: './account-modal-confirm.component.html',
  styleUrls: ['./account-modal-confirm.component.scss']
})
export class AccountModalConfirmComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<AccountModalConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.data.firstName="";
    document.getElementsByTagName('html').item(0).style.setProperty('top', '0px');
  }

  close(){
    this.dialogRef.close(this.data);
  }
}
