import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { TradeInformationData, CustomerSearchItem, DistributorSearchItem } from '@app/account/models/profile';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import {AppLocalStorageKeys} from '../../../../environments/environment';
const accessoriesConnectivity = [
  {
    "id": "1",
    "name": "Batteries and charges"
  },
  {
    "id": "2",
    "name": "Cabling connectivity"
  },
  {
    "id": "3",
    "name": "Display accessories"
  }
];

const computingComponent = [
  {
    "id": "1",
    "name": "Cases & power supplies"
  },
  {
    "id": "2",
    "name": "Thin computing"
  },
  {
    "id": "3",
    "name": "cooling & Tunning"
  }
];

const mobility = [
  {
    "id": "1",
    "name": "Mobile Phones, Smart Phones & Accessories"
  },
  {
    "id": "2",
    "name": "Subscription & Prepaid Products"
  }
];

const tradeLists = [
  {
    "id": "1",
    "name": "1 - 10"
  },
  {
    "id": "2",
    "name": "10 - 50"
  },
  {
    "id": "3",
    "name": "50 - 100"
  },
  {
    "id": "4",
    "name": "100 - Above"
  }
];

const tradeannualOvers = [
  {
    "id": "1",
    "name": "$5000 - $10000"
  },
  {
    "id": "2",
    "name": "$10000 - $50000"
  },
  {
    "id": "3",
    "name": "$50000 - $100000"
  },
  {
    "id": "4",
    "name": "100000 - Above"
  }
];

const retailerTypes=[
  {
  "id":"1",
  "name":"Retailer1"
},
{
  "id":"2",
  "name":"Retailer2"
},
];
@Component({
  selector: 'app-account-trade-information',
  templateUrl: './account-trade-information.component.html',
  styleUrls: ['./account-trade-information.component.scss']
})
export class AccountTradeInformationComponent implements OnInit {

  productCategoryName: string;
  noData: any;
  private channelName: any;
  private channelId: any;
  activeannualMenu: any;
  activeMenu: any;
  tradeinfoForm: FormGroup;
  formSubmit = false;
  public tradeinfoData: any = [];
  urlIcon: string = '';
  tradebtnLists: Array<any> = tradeLists;
  tradeannualOversLists: Array<any> = tradeannualOvers;
public retailerdata:Array<any>=retailerTypes;

  public customerProfileData: Array<CustomerSearchItem>;
  public productFamilyData: Array<DistributorSearchItem>;
  public productCategoryData: Array<DistributorSearchItem>;
  public distributorlistData: Array<DistributorSearchItem>;
  public retailerTypeData:Array<DistributorSearchItem>;
  public listofservicesData: Array<DistributorSearchItem>;
  public customerProfileSelectedData: any = [];
  public productFamilySelectedData: any = [];
  public productCategorySelectedData: any = [];
  public distributorlistSelectedData: any = [];
  public retailerTypeSelectedData:any=[];
  public listlistofservicesSelectedData: any = [];
  public productCategorylist: any = [];

  testData;
  private tradeInformationData: TradeInformationData;

  constructor(private formbuilder: FormBuilder, private uploadService: UploadFileService, private accountBusiness: AccountBusiness) {
  }

  ngOnInit() {
    this.initForm();
    localStorage.setItem(AppLocalStorageKeys.CHANNEL_NAME, 'DISTRIBUTOR');

    let data = localStorage.getItem(AppLocalStorageKeys.CHANNEL_NAME);
    this.channelName = data;

    localStorage.setItem(AppLocalStorageKeys.CHANNEL_ID, '3');

    let data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    this.channelId = data1;
    // this.tradeInformationData = data as TradeInformationData;
    // let channelTypeId =  this.tradeInformationData.user[0].channelTypeId;
    // console.log(channelTypeId);
  }

  initForm() {
    const brandName = '';

    this.tradeinfoForm = this.formbuilder.group({
      brandName: ['', Validators.compose(
        [Validators.required,
        Validators.minLength(2),
        Validators.maxLength(50),
          // Validators.pattern(this.alphaNumericPattern)
        ]
      )]
    }
    );
  }



  private async clickaccessoriesConnectivityData(data: string): Promise<any> {
    this.testData = data;
    // region.splice(1);
    // console.log(region);
    console.log('productCategoryData : ', this.testData);
  }

  private async clickcomputingComponentData(data: string): Promise<any> {
    this.testData = data;
    // region.splice(1);
    // console.log(region);
    console.log('computingComponentData : ', this.testData);
  }

  // Remove the Customer Profile
  private async removecustomerProfileData(data): Promise<any> {
    const index: number = this.customerProfileSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.customerProfileSelectedData.splice(index, 1);
      this.customerProfileData.push(data);
    }
  }

  // Select the Customer Profile
  selectedProfile(profileitem: CustomerSearchItem) {
    this.customerProfileSelectedData.push({
      id: profileitem.Channel_Profile_ID,
      name: profileitem.Channel_Profile_Name,
      channeltypeId: profileitem.Channel_Type_ID,
      channeltypnName: profileitem.Channel_Type_Name,
      default: profileitem.Default
    });
    const index: number = this.customerProfileData.indexOf(profileitem, 0);
    if (index !== -1) {
      this.customerProfileData.splice(index, 1);
    }
  }

  // Search the Customer Profile
  changeSearchcustomerProfile(event) {
    debugger;
    let changecustomerProfile = this.accountBusiness.getCustomerProfile(event, this.channelId).subscribe(result => {
      if (this.channelName == 'DISTRIBUTOR') {

        // if (result) {
        this.customerProfileData = result.RETAILER as Array<CustomerSearchItem>;

        this.customerProfileSelectedData.forEach((value) => {
          for (let i = 0; i < this.customerProfileData.length; i++) {
            if ((<CustomerSearchItem>this.customerProfileData[i]).Channel_Profile_ID == value.id) {
              this.customerProfileData.splice(i, 1);
            }
          }

        });
        // }
        // else{
        //   this.noData = result[0].errors.message
        // }
      }

    },
      (error) => {
        console.log(error);
      });
  }


  // Remove the List of Service
  private async removelistofServicesData(data): Promise<any> {
    const index: number = this.listlistofservicesSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.listlistofservicesSelectedData.splice(index, 1);
      this.listofservicesData.push(data);
    }
  }

  // Select the List of Service
  selectedlistofServices(profileitem: DistributorSearchItem) {
    this.listlistofservicesSelectedData.push({
      id: profileitem.id,
      name: profileitem.name

    });
    const index: number = this.listofservicesData.indexOf(profileitem, 0);
    if (index !== -1) {
      this.listofservicesData.splice(index, 1);
    }
  }

  // Search the List of Service
  changelistofServices(event) {
    debugger;
    let changelistofservices = this.accountBusiness.getListService(event).subscribe(result => {
      console.log(result);
      if (this.channelName == 'DISTRIBUTOR') {

        // if (result) {
        this.listofservicesData = result as Array<DistributorSearchItem>;

        this.listlistofservicesSelectedData.forEach((value) => {
          for (let i = 0; i < this.listofservicesData.length; i++) {
            if ((<DistributorSearchItem>this.listofservicesData[i]).id == value.id) {
              this.listofservicesData.splice(i, 1);
            }
          }

        });
        // }
        // else{
        //   this.noData = result[0].errors.message
        // }
      }

    },
      (error) => {
        console.log(error);
      });
  }



  // Remove the Product Family
  private async removeproductfamilyData(data): Promise<any> {
    debugger;
    const index: number = this.productFamilySelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.productFamilySelectedData.splice(index, 1);
      this.productCategorylist.splice(index, 1);
      this.productFamilyData.push(data);
    }
  }

  // Select the Product Family
  selectedproductfamily(profileitem: DistributorSearchItem) {
    this.productFamilySelectedData.push({
      id: profileitem.id,
      name: profileitem.name
    });
    const index: number = this.productFamilyData.indexOf(profileitem, 0);
    if (index !== -1) {
      this.productFamilyData.splice(index, 1);
    }
    this.productCategorylist.push(profileitem);
  }

  // Search the  Product Family
  changeSearchproductfamily(event) {
    let changecustomerProfile = this.accountBusiness.getProductFamily(event).subscribe(result => {
      if (this.channelName == 'DISTRIBUTOR') {

        // if (result) {
        this.productFamilyData = result as Array<DistributorSearchItem>;

        this.productFamilySelectedData.forEach((value) => {
          for (let i = 0; i < this.productFamilyData.length; i++) {
            if ((<DistributorSearchItem>this.productFamilyData[i]).id == value.id) {
              this.productFamilyData.splice(i, 1);
            }
          }

        });
        // }
        // else{
        //   this.noData = result[0].errors.message
        // }
      }

    },
      (error) => {
        console.log(error);
      });
  }


   // Remove the Distributor List
   private async removedistributorlistData(data): Promise<any> {
    debugger;
    const index: number = this.distributorlistSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.distributorlistSelectedData.splice(index, 1);
      this.distributorlistData.push(data);
    }
  }
  // Select the Distributor List
  selectedDistributorlist(profileitem: DistributorSearchItem) {
    this.distributorlistSelectedData.push({
      id: profileitem.id,
      name: profileitem.name
    });
    const index: number = this.distributorlistData.indexOf(profileitem, 0);
    if (index !== -1) {
      this.distributorlistData.splice(index, 1);
    }
  }

  // Search the Distributor List
  changeDistributorList(event) {
    debugger;
    let changelistofservices = this.accountBusiness.getProductFamily(event).subscribe(result => {
      console.log(result);
      if (this.channelName == 'DISTRIBUTOR') {

        // if (result) {
        this.distributorlistData = result as Array<DistributorSearchItem>;

        this.distributorlistSelectedData.forEach((value) => {
          for (let i = 0; i < this.distributorlistData.length; i++) {
            if ((<DistributorSearchItem>this.distributorlistData[i]).id == value.id) {
              this.distributorlistData.splice(i, 1);
            }
          }

        });
        // }
        // else{
        //   this.noData = result[0].errors.message
        // }
      }

    },
      (error) => {
        console.log(error);
      });
  }

     // Remove the Retailer Types
     private async removeretailerTypeData(data): Promise<any> {
      debugger;
      const index: number = this.retailerTypeSelectedData.indexOf(data, 0);
      if (index !== -1) {
        this.retailerTypeSelectedData.splice(index, 1);
        this.retailerTypeData.push(data);
      }
    }
    // Select the Distributor List
    selectedretailerType(profileitem: DistributorSearchItem) {
      this.retailerTypeSelectedData.push({
        id: profileitem.id,
        name: profileitem.name
      });
      const index: number = this.retailerTypeData.indexOf(profileitem, 0);
      if (index !== -1) {
        this.retailerTypeData.splice(index, 1);
      }
    }
  
    // Search the Distributor List
    changeretailerType(event) {
      debugger;
      let changelistofservices = this.accountBusiness.getProductFamily(event).subscribe(result => {
        console.log(result);
        if (this.channelName == 'DISTRIBUTOR') {
  
          // if (result) {
          this.retailerTypeData = result as Array<DistributorSearchItem>;
  
          this.retailerTypeSelectedData.forEach((value) => {
            for (let i = 0; i < this.retailerTypeData.length; i++) {
              if ((<DistributorSearchItem>this.retailerTypeData[i]).id == value.id) {
                this.retailerTypeData.splice(i, 1);
              }
            }
  
          });
          // }
          // else{
          //   this.noData = result[0].errors.message
          // }
        }
  
      },
        (error) => {
          console.log(error);
        });
    }

  // Remove Corresponding Product Category
  private async removeproductCategoryData(data): Promise<any> {
    debugger;
    const index: number = this.productCategorySelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.productCategorySelectedData.splice(index, 1);
      this.productCategoryData.push(data);
    }
  }

  // Select Corresponding Product Category
  selectedproductcategory(categoryitem: DistributorSearchItem) {
    this.productCategorySelectedData.push({
      id: categoryitem.id,
      name: categoryitem.name
    });
    const index: number = this.productCategoryData.indexOf(categoryitem, 0);
    if (index !== -1) {
      this.productCategoryData.splice(index, 1);
    }
  }

  // Search Corresponding Product Category
  changeSearchproductcategory(event, productId) {
    let changeproductCategory = this.accountBusiness.getProductCategory(event, productId).subscribe(result => {
      if (this.channelName == 'DISTRIBUTOR') {

        // if (result) {
        this.productCategoryData = result as Array<DistributorSearchItem>;

        this.productCategorySelectedData.forEach((value) => {
          for (let i = 0; i < this.productCategoryData.length; i++) {
            if ((<DistributorSearchItem>this.productCategoryData[i]).id == value.id) {
              this.productCategoryData.splice(i, 1);
            }
          }

        });
        // }
        // else{
        //   this.noData = result[0].errors.message
        // }
      }

    },
      (error) => {
        console.log(error);
      });
  }

  accountProfileUpload(event, urlLink) {
    let selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    console.log(event.target.files[0]);
    if (file) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        this.urlIcon = event.target.result;
      }
      reader.readAsDataURL(event.target.files[0]);

      let folderName = "account-s3/"
      this.uploadService.uploadfile(file, folderName);
    }
  }



  btncolorChange(emp) {
    this.activeMenu = emp;
  }
  tradeannualoverbtnChange(annualover) {
    this.activeannualMenu = annualover;

  }
}
