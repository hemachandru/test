import { Email } from "aws-sdk/clients/guardduty";

export class MultiCertificate {
    accCertiNameId: Array<Certify> = [];
    public editorConfig = {
        editable: true,
        spellcheck: false,
        height: '20rem',
        minHeight: '5rem',
        placeholder: 'testsss',
        translate: 'no'
      };
      public arrImage = [{"src":'assets/images/acc-logo.jpg',"loc":''},{"src":'assets/images/logo-icon.png',"loc":''},{"src":'assets/images/user.png',"loc":''}];
      public arrMultipleLable = ['regcertificate','accCerficateId','profileTaxCertiId','profileTaxCertno','profileAwardDtl'
                                ,'profileIssuedBy','profileValidTill'];
      public flag_mandatory=1;
      public htmlContent: any;
      public preloader: boolean = true;
      public jsonData={
        "userId": "29",
        "contactId": "29",
        "channelId": "28",
        "email": "sendhilkumaranp@ihorsetechnologies.com",
        "contact": {
            "contactId": "29",
            "channelId": null,
            "firstName": "Sendhil",
            "lastName": "Kumaran",
            "phone": 9443639833,
            "email": "sendhilkumaranp@ihorsetechnologies.com",
            "jobTitle": "job-title",
            "linkedIn": "linked-in",
            "documentId": null,
            "countryId": "61",
            "isDefaultContact": "0"
        },
        "channel": {
            "channelId": "28",
            "signUpStatusId": "7",
            "companyName": "SSK",
            "companyMail": null,
            "countryId": "61",
            "verificationCode": "ecWm",
            "verificationSentAt": "2018-03-09T06:41:52.236Z",
            "oldChannelId": null,
            "claimChannelId": null,
            "channelTypeId": null,
            "regAddressId": 1,
            "billAddressId": 2,
            "regAddress": {
                "addressId": "1",
                "address": "tuituyiotyyoitiytiyrt",
                "city": "null",
                "countryId": "1",
                "postalCode": "605102"
            },
            "billAddress": {
                "addressId": "2",
                "address": "ewrhtryutdsrerwe",
                "city": "nussll",
                "countryId": "2",
                "postalCode": "605009"
            },
            "channelDetail": {
                "channelDetailId": "1",
                "channelId": "28",
                "phone1": "0413222477",
                "phone2": "0413222478",
                "mobileNo": "9042495010",
                "webSiteUrl": "www.channelhub.com",
                "estYear": "2018-03-21T07:18:24.668Z",
                "regYear": "2018-04-21T07:18:24.668Z",
                "detailDesc": null,
                "empCntRange": null,
                "empCnt": null,
                "empCntDSale": null,
                "empCntISale": null,
                "empCntDMar": null,
                "empCntIMar": null,
                "turnoverRange": null,
                "turnover": null,
                "revD": null,
                "revI": null,
                "deletedAt": null,
                "createdAt": "2018-03-21T07:18:24.668Z",
                "updatedAt": null
            }
        }
    };
}

export class ProfileAddress {
    address: string;
    postalCode: number;
    city: string;
    countryId: number;
}

export class CustomerSearchItem {
    Channel_Profile_ID: number;
    Channel_Profile_Name: string;
    Channel_Type_ID: number;
    Channel_Type_Name: string;
    Default: null;
}
export class DistributorSearchItem {
    id: number;
    name: string;
    //   public htmlContent: string;
    //   public jsonData: any;     
}

export class Certify {
    certi: Array<Certificate> =[];
}

export class Profile {

    company_logo_url: string;
    company_icon_url: string;
    company_name: string;
    company_owner_first_name: string;
    company_owner_last_name: string;
    company_email: string;
    company_website_url: string;
    company_phone1: string;
    company_phone2: string;
    company_mobile_no: string;
    company_about: string;

    registeration_certificate: Array<Certificate>;
    year_of_estabilishment: Date;
    year_of_registration: Date;
    reg_address_id: number;
    reg_address: string;
    reg_country_id: number;
    reg_postal_code: number;
    reg_city: string;
    bill_address_id: number;
    bill_address: string;
    bill_postal_code: number;
    bill_city: string;
    bill_country_id: number;
    is_same_address: number;
    
    tax_certificate: Array<Certificate>;
    award_details: Array<Certificate>;

    social_linkedin_url: string;
    social_googleplus_url: string;
    social_instagram_url: string;
    B2B_url: string;

    contact_first_name: string;
    contact_last_name: string;
    contact_phone1: number;
    contact_phone2: number;
    contact_mobile_no: string;
    contact_email: string;
    contact_job_title: string;
    contact_linkedin_url: string;   
    contact_profile_image_url: string;        
    
};

export class Certificate {
    name: string;
    id: string;
    details: string;
    issued_by: string;
    valid_upto: Date;
}

export class Tradeinfo {
    channelTypeId: number;

}

export class TradeInformationData {
    user: Tradeinfo;
};