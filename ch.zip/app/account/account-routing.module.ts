import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountComponent } from './container/account/account.component';
import { AccountVerificationComponent } from './component/account-verification/account-verification.component';

const routes: Routes = [
  {path: '', redirectTo: 'account', pathMatch: 'full'},
  {
    path: 'account', children: 
    [
      {path: '', component: AccountComponent},
      {path: 'account', component: AccountComponent},
      {path: 'verify', component: AccountVerificationComponent}
    ]
  }
  // {path: 'account', component: AccountComponent}
  // }  
    // {path: 'account', component: CompanyTitleComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AccountRoutingModule { }
