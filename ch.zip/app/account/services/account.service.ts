import { Injectable } from '@angular/core';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { HttpParams, HttpClient } from '@angular/common/http';


@Injectable()
export class AccountService {

  constructor(private _httpRequestService: HttpRequestService, ) { }

  getAccountListService(url) {
    return this._httpRequestService.getHttpRequest(url);
  }

  postAccountService(dataparams: any, url: string) {
    return this._httpRequestService.postHttpRequest(dataparams, url);
  }

  getradeInfoGetService(searchparams: any, url: string) {
    let params = new HttpParams();
    params = params.set("name", searchparams);
    return this._httpRequestService.getHttpRequestWithQueryString(params, url);
  }

  getradeInfoGetcustomerProfile(url: string, channelId: any, name: any) {
    let params = new HttpParams();
    params = params.set("channelTypeId", channelId);
    params = params.set("name", name);
    return this._httpRequestService.getHttpRequestWithSubQueryString(params, url);
  }

  getradeInfoGetsubService(searchparams: any, url: string, searchsubparams: any) {
    let params = new HttpParams();
    params = params.set("productFamilyId", searchsubparams);
    params = params.set("name", searchparams);
    return this._httpRequestService.getHttpRequestWithSubQueryString(params, url);
  }

}

