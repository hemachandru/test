import { SlimScrollModule } from 'ng2-slimscroll';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgProgressModule, NgProgressBrowserXhr, NgProgressInterceptor } from 'ngx-progressbar';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { SharedModule } from './../shared/shared.module';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LeftMenuComponent } from './components/left-menu/left-menu.component';
import { TokenInterceptor } from '../auth/interceptors/token.interceptor';
import { AppComponent } from './containers/app/app.component';
import {TopMenuComponent } from './components/top-menu/top-menu.component';
import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { SideMenuComponent } from './components/side-menu/side-menu.component';
import { MenuItemsComponent } from './components/menu-items/menu-items.component';

export const COMPONENTS = [
  AppComponent,
  HeaderComponent,
  FooterComponent,
  TopMenuComponent,
  LeftMenuComponent,
  //AccountVideoBannerComponent,
  SideMenuComponent,
  MenuItemsComponent
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    HttpClientModule,
    NgProgressModule,
    SlimScrollModule    
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS
})
export class CoreModule {
  static forRoot() {
    return {
      ngModule: CoreModule,
      providers: [
        // HttpRequestService,
        AuthGuard,
        { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: NgProgressInterceptor, multi: true }
      ],
    };
  }
}
