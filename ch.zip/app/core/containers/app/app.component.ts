import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';
import { Component, AfterViewChecked, AfterViewInit } from '@angular/core';

import { Logout } from './../../../auth/store/actions/auth.actions';
import { AuthService } from './../../../auth/services/auth.service';
import * as fromAuth from '../../../auth/store/reducers';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { UserAccountStatus } from '@app/config/constant';


import { Router, NavigationStart, NavigationEnd, ActivatedRoute, Event as NavigationEvent } from '@angular/router';

import { HomeBusiness } from '../../../home/business/home.business';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { AppLocalStorageKeys } from '../../../../environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements AfterViewChecked, AfterViewInit {
  isLoggedIn$: Observable<boolean>;
  menuopen: any;
  public activeURL: string;
  public checklandURLBool: boolean;
  public isTokenExists: boolean;
  public userChannelStatus: any;
  public isSubscriptedUser: any = false;
  public loginIdExists: any;
  public loginNameExists: any;
  private isLoginStateUpdated: boolean = false;
  private isLogoutStateUpdated: boolean = false;
  constructor(private userSubscriptionBusiness: UserSubscriptionBusiness, private _homeBusiness: HomeBusiness, private store: Store<fromAuth.State>, private route: ActivatedRoute, private router: Router) {

    this.isLoggedIn$ = this.store.select(fromAuth.getLoggedIn);
    this.router.events.subscribe(event => {

      if (event instanceof NavigationEnd) {
        this.isTokenExists = localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != '' ? true : false;
        let loginNameExistsBool = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID) != null && localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID) != '' ? true : false;
        //this.loginIdExists
        if (loginNameExistsBool === true) {
          this.loginIdExists = true;
          this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
          let result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
          let contactId: number;
          contactId = parseInt(result);
          if (!ValidationService.isNullOrEmpty(contactId)) {
            this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
              this.loginNameExists = response.firstName;
            },
              (error) => {
                console.log(error);
              });
          }
          else {
            LocalStorageService.clearAllDataExceptAppToken();
            this.router.navigate(['auth/login']);
          }
          // this.loginNameExists = 'Chandru test name';
        } else {
          this.loginIdExists = false;
          this.loginNameExists = '';
        }
        // this.userChannelStatus = localStorage.getItem('user_channelstatus');
        // let result = localStorage.getItem('user_subscription_contactId');
        //   let contactId: number;
        //   contactId = parseInt(result);
        //   if(contactId){
        //     this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
        //       this.loginName = response.firstName;
        //     },
        //       (error) => {
        //         console.log(error);
        //       }); 
        //   }

        if (this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP ||
          this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_COMPANYPROFILE ||
          this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION ||
          this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADELOCATION) {
          this.isSubscriptedUser = true;
        } else {
          this.isSubscriptedUser = false;
        }

        this.activeURL = event.url;
        if (this.activeURL == '/auth/login' || this.activeURL == '/auth/signup') {
          this.checklandURLBool = true;
        } else {
          this.checklandURLBool = false;
        }

      }
    });
  }

  ngOnInit() {
    this.getAuthrozationCode();
  }

  getAuthrozationCode() {
    this._homeBusiness.getUserAuthorizationCode().subscribe(res => {
    }, (err) => {
      console.log("Error" + err);
    });
  }

  logout() { this.store.dispatch(new Logout()); }

  MenuOpen(menuopen) {
    this.menuopen = !menuopen;
  }

  ngAfterViewInit() {
  }

  ngAfterViewChecked() {
    let tokenExists = localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) != '' ? true : false;
    if (tokenExists) {
      let result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
      let contactId: number;
      contactId = parseInt(result);
      if (!this.isLoginStateUpdated) {
        this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
          this.loginIdExists = true;
          this.loginNameExists = response.firstName;
          this.isTokenExists = tokenExists;
          this.isLoginStateUpdated = true;
        },
          (error) => {
            console.log(error);
            this.loginIdExists = false;
            this.loginNameExists = "";
          });
      }
      else {
        if (!this.isLoginStateUpdated) {
          this.isTokenExists = false;
          this.loginIdExists = false;
          this.loginNameExists = "";
        }
      }
      this.isLoginStateUpdated = true;
    }
    else {
      if (this.isLoginStateUpdated && !this.isLogoutStateUpdated) {
        this.loginNameExists = "";
        this.loginIdExists = false;
        this.isTokenExists = false;
        this.isLogoutStateUpdated = true;
      }
    }
  }
}
