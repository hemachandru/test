import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgClass } from '@angular/common';
import { Router, NavigationStart, NavigationEnd, ActivatedRoute, Event as NavigationEvent } from '@angular/router';


import { RoleMenu } from '../../../config/constant';
import { SearchComponent } from '../../../shared/shared-component/search/search.component';
import { UserAccountStatus } from '@app/config/constant';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
// import { UserDetailService } from ".services/user-detail.service";
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { SuccesErrorMessage, UserDetailMessage, Config, } from '@app/config/constant';
import { ApiUrl,AppLocalStorageKeys } from '../../../../environments/environment';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { ValidationService } from '@app/shared/shared-service/validation-service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {
  @Input() isGuestUser:any = false;
  @Output() logoutClick = new EventEmitter<boolean>();
  private menuValue : any =[];
  public inputClass : any ="headerSearch";
  public blockClass : any = "headerSearch-container";
  public isSubscriptedUser: any = false;
  public userdropdown:any = false;
  public loginName: any;
  
  @Input() userChannelStatus :any;

  @Input() userLoged : any;
  @Input() userLogedProfileBool : any;
  @Input() userLogedProfileName: any;
  private userDetailMessage: UserDetailMessage;
  private apiUrl = ApiUrl;
  constructor( private router: Router, private route:ActivatedRoute, private userSubscriptionBusiness: UserSubscriptionBusiness,private userDetailService:UserDetailService,private config:Config) { 
    console.log('My profile name boolean : ',this.userLogedProfileBool, this.userLogedProfileName);
    this.userDetailMessage = new UserDetailMessage();
  }

  ngOnInit() {
    this.headderLoadEvent();
    // this.listenVerificationSuccess();
    //uname
  }

  headderLoadEvent(){
    this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS); 
    
    this.router.events.subscribe(event => {

      if (event instanceof NavigationEnd) {        
        this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS); 
                
          if(this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP ||
            this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_COMPANYPROFILE||
            this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION||
            this.userChannelStatus == UserAccountStatus.ACCOUNTSETUP_TRADELOCATION) {             
              this.isSubscriptedUser = true;
          }else {
            
            this.isSubscriptedUser = false;      
          }                  
      }
    });  
    this.menuValue = RoleMenu;
    this.userLoged = !ValidationService.isNullOrEmpty(localStorage.getItem(AppLocalStorageKeys.AUTH_Token))?true:false;
    // this.getUserInfo();
    // this.loginName = this.userProfileName;
    // if(this.loginName != ""){
    //   console.log(this.userProfileName);
    //   this.loginName = this.userProfileName;
    // }
  }

  getUserInfo(){
    let result = localStorage.getItem('user_subscription_contactId');
    let contactId: number;
    contactId = parseInt(result);
    // console.log(contactId);
    this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => { 
      console.log('Response daaa : ',response.firstName);
      this.loginName = response.firstName;
    },
      (error) => {
        console.log(error);
      });
  }

  userLogout(){
    // localStorage.removeItem('authToken');
    // localStorage.removeItem('user_subscription_contactId');  
    // localStorage.removeItem('user_channelstatus');
    LocalStorageService.clearAllDataExceptAppToken();
    this.isGuestUser = false; 
    this.userdropdown = false;    
    this.router.navigate(['auth/login']);    
  }

  toggledropdown(userdropdown){  
    this.userdropdown = !this.userdropdown;
  }  

  logout() { this.logoutClick.emit(); }

listenVerificationSuccess()
{
  this.userDetailService.currentUserDetail.subscribe(x => {
    this.userDetailMessage = x
  });
  if (this.userDetailMessage != undefined && this.userDetailMessage != null && this.userDetailMessage.action != undefined && this.userDetailMessage.action != null) {
  
    if (this.userDetailMessage.action == this.apiUrl.VERIFICATIONSUCCESS) {
      this.userLoged = !ValidationService.isNullOrEmpty(localStorage.getItem(AppLocalStorageKeys.AUTH_Token))?true:false;
      this.getUserInfo();
    }
  }
}
}
