import { Component, OnInit } from '@angular/core';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { MENU_ITEMS,SIDEMENU_ITEMS } from '@app/config/constant'

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent implements OnInit {
  public menu:any = SIDEMENU_ITEMS;
  public opts: ISlimScrollOptions;

  constructor() { }

  ngOnInit() {
    this.opts = {
      //position: 'right',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }

}
