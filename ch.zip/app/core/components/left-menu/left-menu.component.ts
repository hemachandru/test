import { Component, OnInit } from '@angular/core';

import { SIDEMENU } from '../../../config/constant';

@Component({
  selector: 'app-left-menu',
  templateUrl: './left-menu.component.html',
  styleUrls: ['./left-menu.component.scss']
})
export class LeftMenuComponent implements OnInit {
  private menuValue =  SIDEMENU;
  constructor() { }

  ngOnInit() {
    // for (let index = 0; index < SIDEMENU.length; index++) {
    //   this.menuValue.push({ "id": SIDEMENU[index].id,"menuname": SIDEMENU[index].menuname, "icon": SIDEMENU[index].icon });
    // }
    // console.log('dffdfdfdf : ',this.menuValue);
  }

}
