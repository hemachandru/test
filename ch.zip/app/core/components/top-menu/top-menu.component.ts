import { Component, OnInit } from '@angular/core';

import { menuList } from '../../../config/constant';


@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})

export class TopMenuComponent implements OnInit {
  private menuArray = menuList;
  private menuValue: any = [];
  public exact: boolean = false;
  toggleMenu: boolean = false;

  constructor() { }

  ngOnInit() {
    for (let i = 0; i < this.menuArray.length; i++) {
      this.menuValue.push(this.menuArray[i]);
    }
  }
  onToggleMenu() {
    if (this.toggleMenu === true) {
      this.toggleMenu = false;
    } else {
      this.toggleMenu = true;
    }
  }
}
