import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-menu-items',
  templateUrl: './menu-items.component.html',
  styleUrls: ['./menu-items.component.scss']
})
export class MenuItemsComponent implements OnInit {
  @Input() menuItem: any;   
  constructor() { }

  ngOnInit() {
    // console.log(this.menuItem);
  }

  onHoverItem(obj) {
    // console.log(obj);
  }

  onToggleSubMenu(menuItem) {    
    menuItem.selected = !menuItem.selected; 
    menuItem.expanded = !menuItem.expanded;
  }

}
