import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { AuthService } from "angular2-social-login";
import { ApiUrl } from '../../../environments/environment';


@Injectable()
export class SharedBusiness {
  private apiUrl = ApiUrl;

  constructor(private sharedService: SharedService, private router: Router, private auth: AuthService) {
  }

  getCountryListBusiness(): Observable<any> {
    // console.log('Business');
    const url = this.apiUrl.COUNTRYLIST;
    return this.sharedService.getCountryListService(url)
      .map(res => {
        return res;
      });
  }

  getUserStatus() {
    let url = this.apiUrl.GETUSERSTATUS;
    return this.sharedService.getUserStatus(url).map(res => {
      return res
    });
  }

  socialLogin(provider: any) {
    return this.auth.login(provider).map(res => {
      return res
    });
  }

  signIn(provider) {
    // console.log("Provider :" + provider);
  }

  logout() {
    this.auth.logout().subscribe(
      (data) => {
        //  console.log(data);
       }
    )
  }

  uploadLinkedInImageBusiness(data: any) {
    let url = this.apiUrl.PUBLICUPLOAD;
    return this.sharedService.uploadLinkedInImageService(data, url).map(res => {
      return res
    });
  }
}
