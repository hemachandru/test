import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpParams, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';


@Injectable()
export class SearchService {
  baseUrl: string = 'channel'

  constructor(private http: Http,private httpClient: HttpClient, private _httpRequestService: HttpRequestService) { }

  search(terms: Observable<string>, userId) {   
    return terms.debounceTime(10)
    .distinctUntilChanged()
    .switchMap(term => this.searchEntries(term, userId));
  }

  searchEntries(term, userId) { 
    let params = new HttpParams();
    params = params.set("channelTypeId", userId);
    // params = params.set("isClaim", "1");
    
      return this._httpRequestService      
      .getHttpRequestWithoutTokenQueryString(term, params, this.baseUrl)
      .map(res => <any>res);     
  }
}