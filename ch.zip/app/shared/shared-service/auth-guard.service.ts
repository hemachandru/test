import { Injectable } from '@angular/core';
import {AppLocalStorageKeys} from '../../../environments/environment'
import {
  CanActivate, Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivateChild,
  NavigationExtras,
  CanLoad, Route
} from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {
  constructor(private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let url: string = state.url;
    // console.log('Auth Check URL : ', url)
    return this.checkLogin(url);
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.canActivate(route, state);
  }

  canLoad(route: Route): boolean {
    let url = `/${route.path}`;
    //console.log("URL TOken Here====>" + localStorage.getItem('token') + "=====" + typeof (localStorage.getItem('token')));
    return this.checkLogin(url);
  }

  checkLogin(url: string): boolean {
    if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
      return true;
    } else {
      // Navigate to the login page with extras
      this.router.navigate(['/auth/login']);
      return false;
    }
  }
}