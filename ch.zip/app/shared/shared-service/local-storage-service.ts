import {AppLocalStorageKeys} from '../../../environments/environment'
export class LocalStorageService {
    static clearAllDataExceptAppToken() {
        var appToken = localStorage.getItem(AppLocalStorageKeys.APP_Token);
        localStorage.clear();
        localStorage.setItem(AppLocalStorageKeys.APP_Token, appToken);
      }
    
     static clearAll() {
        localStorage.clear();
      }
}