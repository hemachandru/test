import { Injectable } from '@angular/core';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';

@Injectable()
export class SharedService {

  constructor(private httpRequestService: HttpRequestService) { }
  getCountryListService(url) {
    // console.log('SErvice');
    return this.httpRequestService.getHttpRequestWithoutToken(url);
  }

  getUserStatus(url) {
    return this.httpRequestService.getHttpRequest(url);
  }

  uploadLinkedInImageService(data:any,url:string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data,url);
  }
}
