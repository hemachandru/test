import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import{UserDetailMessage} from "@app/config/constant"

@Injectable()
export class UserDetailService {
  user:UserDetailMessage;  
  private userSource = new BehaviorSubject<UserDetailMessage>(this.user);
  currentUserDetail = this.userSource.asObservable();

  constructor() { }

  onUserDetailChange(userDetail: UserDetailMessage) {    
    this.userSource.next(userDetail);
  }
}