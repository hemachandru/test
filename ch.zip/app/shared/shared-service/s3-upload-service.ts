import { Injectable, Output, EventEmitter } from '@angular/core';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import { environment } from '../../../environments/environment';

@Injectable()
export class S3UploadFileService {
  private options = {
    accessKeyId: environment.AWS_ACCESS_KEY,
    secretAccessKey: environment.AWS_SECRET_ACCESS_KEY,
    region: environment.AWS_REGION
  };
  private s3 = new S3(this.options);
  FOLDER = '';
  constructor() {

  }

  async uploadfile(file, folderName): Promise<any> {
    try {
      this.FOLDER = folderName;
      let fileName = file.name;
      let fileExtension = fileName.substr((fileName.lastIndexOf('.') + 1));
      const params = {
        Bucket: environment.TEMP_AWS_BUCKET,
        Key: this.FOLDER + this.GenerateRandomString(8) + "_" + new Date().getTime() + "."+fileExtension,
        Body: file
      };
      let resultPromise = await this.s3.upload(params).promise();
      if (resultPromise)
        // this.onUploadImage.emit(resultPromise);
        return resultPromise;

      return false;
    } catch (e) {
      console.log(e);
      return false;
    }
  }

  GenerateRandomString(len) {
    var text = "";
    var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (var i = 0; i < len; i++)
      text += charset.charAt(Math.floor(Math.random() * charset.length));
    return text;
  }







  // async uploadfile1(file, filename) {

  //   const bucket = new S3(
  //     {
  //       accessKeyId: environment.AWS_ACCESS_KEY,
  //       secretAccessKey: environment.AWS_SECRET_ACCESS_KEY,
  //       region: environment.AWS_REGION
  //     }
  //   );

  //   const params = {
  //     Bucket: environment.TEMP_AWS_BUCKET,
  //     Key: this.FOLDER + filename,
  //     Body: file
  //   };

  //   bucket.upload(params, function (err, data) {
  //     if (err) {
  //       console.log('There was an error uploading your file: ', err);
  //       return false;
  //     }

  //     console.log('Successfully uploaded file.', data);
  //     return data;
  //   });
  // }

}



