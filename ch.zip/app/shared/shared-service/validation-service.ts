import { FormGroup } from "@angular/forms";

export class ValidationService {
  static getValidatorErrorMessage(controlname, validatorName: string, validatorValue?: any) {
    let config = {
      'firstName': {
        'required': `Please enter a first name.`,
        'minlength': `First name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `First name must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Firstname should be characters only`,
      },
      'lastName': {
        'required': `Please enter a last name.`,
        'minlength': `Last name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Last name must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': 'Last name should be characters only',
      },
      'email': {
        'required': 'Please enter a email id',
        'pattern': 'Please enter a valid email id',
        'isEmailUnique': 'Email already registered.'
      },
      'password': {
        'required': 'Please enter a Password.',
        'minlength': `Password must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Password must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': 'Password  alphanumeric and special characters.',
      },
      'retypePassword': {
        'mismatchedPasswords': 'Password mismatch'
      },
      'country': {
        'required': 'Please select your country.',
      },
      'phone': {
        'required': 'Please enter phone number.',
        'minlength': `Phone no must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Phone no must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': 'Please enter a Valid Phone number',
      },
      'jobTitle': {
        'required': 'Please enter job title.',
      },
      'profileImage': {
        'required': 'Please select profile image.',
      },
      'companyName': {
        'required': 'Please enter a company name.',
      },
      'companyAddress': {
        'required': 'Please enter a company Address.',
      },
      'companyPostalcode': {
        'required': 'Please enter a company postal code.',
      },
      'companyPhone1': {
        'required': 'Please enter a company phone.',
        'pattern': 'Please enter a Valid Phone number',
      },
      'companyPhone2': {
        'pattern': 'Please enter a valid phone number',
      },
      'companyEmail': {
        'required': 'Please enter a company email.',
        'pattern': 'Please enter a Valid Email Id',
      },
      'companyWebsite': {
        'required': 'Please enter a company Website.',
        'pattern': 'Please enter a Valid URL',
      },
      'billingAddress': {
        'required': 'Please enter a Billing Address',
      },
      'billingPostalcode': {
        'required': 'Please enter a Postal code',
      },
      'coupon': {
        'required': 'Please enter a coupon code',
      },
      'fileprofileLogo': {
        'required': 'Please enter company legal name.',
      },
      'legalName': {
        'required': 'Please enter company legal name.',
        'minlength': `Company Legal name must be minimum ${validatorValue.requiredLength} characters.`,
      },
      'regcertificate': {
        'required': 'Please enter certificate name.',
        'minlength': `Certificate name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Certificate name must be maximum ${validatorValue.requiredLength} characters.`,
      },
      'accCerficateId': {
        'required': 'Please enter certificate id/name.',
        'minlength': `Certificate name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Certificate name must be maximum ${validatorValue.requiredLength} characters.`,
      },
      'profileAddress': {
        'required': 'Please enter address.',
        'minlength': `Address must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Address must be maximum ${validatorValue.requiredLength} characters.`,
      },
      'profileZip': {
        'required': 'Please enter Zip Code.',
        'minlength': `Zip Code must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Zip Code must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profileCity': {
        'required': 'Please enter city.',
        'pattern': `Text must be alpha numeric`,
      },
      'profileRegAdd': {
        'required': 'Please enter address.',
        'minlength': `Address must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Address must be maximum ${validatorValue.requiredLength} characters.`,
      },
      'profileRegZip': {
        'required': 'Please enter Zip Code.',
        'minlength': `Zip Code must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Zip Code must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profileRegcity': {
        'required': 'Please enter city.',
        'pattern': `Text must be alpha numeric`,
      },
      'profilePhone': {
        'required': 'Please enter phone no.',
        'minlength': `Phone No. must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Phone No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid No.`,
      },
      'profilePhone2': {
        'required': 'Please enter Phone No.',
        'minlength': `Phone No. must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Phone No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid No.`,
      },
      'profileMobile': {
        'required': 'Please enter Mobile No.',
        'pattern': `Provide Valid No.`,
      },
      'profileemail': {
        'required': 'Please enter Email Id.',
        'pattern': `Enter Valid Email ID`,
      },
      'profileTaxCertiId': {
        'required': 'Please enter Tax Certificate ID.',
        'minlength': `Tax Certificate ID. must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Tax Certificate ID. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profileTaxCertno': {
        'required': 'Please enter Tax Certificate No.',
        'minlength': `Tax Certificate No. must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Tax Certificate No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profileAwardDtl': {
        'required': 'Please enter Award Detail.',
        'minlength': `Award Detail must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Award Detail must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profileIssuedBy': {
        'required': 'Please enter Issued by.',
        'minlength': `Issued by must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Issued by must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Text must be alpha numeric`,
      },
      'profilelinkedURL': {
        'required': 'Please enter Linked URL.',
        'minlength': `Linked URL must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Linked URL must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid URL`,
      },
      'profileGoogleURL': {
        'required': 'Please enter Google URL.',
        'minlength': `Google URL must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Google URL must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid URL`,
      },
      'profileInstaURL': {
        'required': 'Please enter Instagram URL.',
        'minlength': `Instagram URL must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Instagram URL must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid URL`,
      },
      'profileWebsiteURL': {
        'required': 'Please enter Website URL.',
        'minlength': `Website URL must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Website URL must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid URL`,
      },
      'profileFirstName': {
        'required': 'Please enter First Name',
        'minlength': `Name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Name must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Alpha Numerics Only`,
      },
      'profileLastname': {
        'required': 'Please enter Last Name',
        'minlength': `Name must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Name must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Alpha Numerics Only`,
      },
      'profileContactno': {
        'required': 'Please enter Contact No.',
        'minlength': `Contact No.must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Contact No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Number Only`,
      },
      'profileAuthCont2': {
        'minlength': `Contact No.must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Contact No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Number Only`,
      },
      'profileAuthmob': {
        'required': 'Please enter Mobile No.',
        'minlength': `Mobile No. must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Mobile No. must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Number Only`,
      },
      'profileJobtitle': {
        'minlength': `Title must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `Title must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Alpha Numerics Only`,
      },
      'profileAuthLink': {
        'minlength': `URL must be minimum ${validatorValue.requiredLength} characters.`,
        'maxlength': `URL must be maximum ${validatorValue.requiredLength} characters.`,
        'pattern': `Provide Valid URL`,
      },

    };

    return config[controlname][validatorName];
  }

  static getSignUpValidatorErrorMessage(controlname: any, validatorName: any, ) {
    let config = {
      'firstname': {
        '1213': `Please enter a First name.`,
      },
      'lastname': {
        '1215': `Please enter a Last name.`,
      },
      'email': {
        '1413': 'Email already exist',
      },
      'password': {
        '1412': 'Password alphanumeric and special characters.',
      },
      'country': {
        '0002': 'Please select your country.',
      },
      'subscriptionPlan': {
        '0050': 'Please choose your plan.',
      },
      'apiError': {
        '0000': 'API ERROR',
      },
      'claimDoc': {
        '0051': 'Please upload documents and submit. ',
      },

    };
    return config[controlname][validatorName];
  }

  static isNullOrEmpty(val: any): boolean {
    if (val != undefined && val != null) {
      if (typeof val === "string") {
        return val.toString().trim() != '' ? false : true;
      }
      else {
        return false;
      }
    }
    else {
      return true;
    }
  }

}
