import { Injectable } from '@angular/core';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3';
import { environment } from '../../../environments/environment';

@Injectable()
export class UploadFileService {
  private options = {
    accessKeyId: environment.AWS_ACCESS_KEY,
    secretAccessKey: environment.AWS_SECRET_ACCESS_KEY,
    region: environment.AWS_REGION
  };
  private bucket = new S3(this.options);
  FOLDER = '';

  constructor() { }

  async uploadfile(file, folderName): Promise<any> {
    try {
      this.FOLDER = folderName;    
      const params = {
        Bucket: environment.TEMP_AWS_BUCKET,
        Key: this.FOLDER + file.name,
        Body: file
      };
      
        let resultPromise = await this.bucket.upload(params).promise();
          if (resultPromise)
              return resultPromise;
            return false;
    } catch (e) {
        console.log(e);
        return false;
    }
}

  // uploadfiles(file, folderName) {
  //   this.FOLDER = folderName;    
  //   const params = {
  //     Bucket: environment.TEMP_AWS_BUCKET,
  //     Key: this.FOLDER + file.name,
  //     Body: file
  //   };
  //   this.bucket.upload(params, function (err, data) {
  //     if (err) {
  //       console.log('There was an error uploading your file: ', err);
  //       return false;
  //     }
  //     console.log('Successfully uploaded file.', data.Location);
  //     sessionStorage.setItem('profileImage', data.Location);
  //     return true;
  //     // return data;
  //   });
  // }

}
