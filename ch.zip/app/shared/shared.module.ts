import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { ToastyModule } from 'ng2-toasty';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { CollapsibleModule } from 'angular2-collapsible';

import { HttpModule, Http } from '@angular/http';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { CountryListComponent } from '@app/shared/shared-component/country-list/country-list.component';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { PageTitleComponent } from '@app/shared/shared-component/page-title/page-title.component';
import { HeadderPaginationComponent } from './shared-component/headder-pagination/headder-pagination.component';
import { SuccessErrorMessageComponent } from './shared-component/success-error-message/success-error-message.component';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { SearchComponent } from './shared-component/search/search.component';

import { SlimScrollModule } from 'ng2-slimscroll';

//translate module dependencies
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ControlMessagesComponent } from './shared-component/control-error-message/control-error-message.component';
import { ServiceErrorMessageResponseComponent } from './shared-component/service-error-message-response/service-error-message-response.component';
import { ErrorMessageServiceComponent } from '@app/shared/shared-component/error-message-service/error-message-service.component';
import { LinkedinComponent } from '../shared/shared-component/linkedin/linkedin.component'
import { UploadFileService } from '../shared/shared-service/upload-file.service';
import { MatDialogModule } from '@angular/material';
import { KeysPipe } from '@app/shared/pipes/keys.pipe';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { ImageUploadModule } from "angular2-image-upload";
import { ButtonWithCloseIconComponent } from './shared-component/button-with-close-icon/button-with-close-icon.component';
import { Angular2SocialLoginModule } from 'angular2-social-login';
import { AuthService } from "angular2-social-login";
import { NgxPasswordToggleModule } from 'ngx-password-toggle';
import { UserDetailService } from './shared-service/user-detail.service';
let providers = {
  /*"google": {
    "clientId": "GOOGLE_CLIENT_ID"
  },*/
  "linkedin": {
    "clientId": "77lf7znqv0i3mk"
  },
  /*"facebook": {
    "clientId": "FACEBOOK_CLIENT_ID",
    "apiVersion": "v2.4"
  }*/
};

export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient, "i18n/", ".json");
}

@NgModule({
  imports: [
    HttpModule,
    CommonModule,
    ToastyModule.forRoot(),
    ModalModule.forRoot(),
    BsDropdownModule.forRoot(),
    CollapsibleModule,
    SlimScrollModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.threeBounce,
      primaryColour: '#0a85c9',
      secondaryColour: '#115378',
      tertiaryColour: '#115378'
    }),
    ImageUploadModule.forRoot(),
    MatDialogModule,
    NgxPasswordToggleModule
  ],
  declarations: [
    CountryListComponent,
    HeadderPaginationComponent,
    PageTitleComponent,
    SuccessErrorMessageComponent,
    SearchComponent,
    ControlMessagesComponent,
    ServiceErrorMessageResponseComponent,
    ErrorMessageServiceComponent,
    LinkedinComponent,
    KeysPipe,
    ButtonWithCloseIconComponent,
  ],
  providers: [
    SharedBusiness,
    SharedService,
    HttpRequestService,
    UploadFileService,
    AuthService,
    S3UploadFileService,
    UserDetailService
  ],
  exports: [
    ReactiveFormsModule,
    RouterModule,
    ToastyModule,
    ModalModule,
    BsDropdownModule,
    CountryListComponent,
    HeadderPaginationComponent,
    PageTitleComponent,
    SuccessErrorMessageComponent,
    SearchComponent,
    TranslateModule,
    LoadingModule,
    ControlMessagesComponent,
    ServiceErrorMessageResponseComponent,
    ErrorMessageServiceComponent,
    LinkedinComponent,
    KeysPipe,
    ImageUploadModule,
    ButtonWithCloseIconComponent,
    NgxPasswordToggleModule
  ]
})
export class SharedModule { }
Angular2SocialLoginModule.loadProvidersScripts(providers);
