import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-headder-pagination',
  templateUrl: './headder-pagination.component.html',
  styleUrls: ['./headder-pagination.component.scss']
})
export class HeadderPaginationComponent implements OnInit {
  
  @Input() headderName: string;
  @Input() buttonData = [];

  constructor() { }

  ngOnInit() {
  }

}
