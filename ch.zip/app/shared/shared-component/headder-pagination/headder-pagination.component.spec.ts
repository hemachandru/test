import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeadderPaginationComponent } from './headder-pagination.component';

describe('HeadderPaginationComponent', () => {
  let component: HeadderPaginationComponent;
  let fixture: ComponentFixture<HeadderPaginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeadderPaginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeadderPaginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
