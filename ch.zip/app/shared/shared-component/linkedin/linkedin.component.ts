import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Linkedin } from '../../models/linkedin';
import { ValidationService } from '@app/shared/shared-service/validation-service';

@Component({
  selector: 'app-linkedin',
  templateUrl: './linkedin.component.html',
  styleUrls: ['./linkedin.component.scss']
})
export class LinkedinComponent implements OnInit {
  private userDetails = [];
  public opts: ISlimScrollOptions;
  public returnData: Linkedin;
  constructor(
    public dialogRef: MatDialogRef<LinkedinComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.opts = {
      //position: 'right',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }

  ngOnInit() {
    this.returnData = new Linkedin();
    this.returnData.firstName = '';
    this.returnData.lastName = '';
    this.returnData.email = '';
    this.returnData.jobTitle = '';
    // this.returnData.phoneNumber = '';
    this.returnData.profileUrl = '';
    document.getElementsByTagName('html').item(0).style.setProperty('top', '0px');
    // console.log(this.data);
  }

  finish() {
    this.dialogRef.close(this.returnData);
  }

  onDataImport(field: string) {
    if (field == "firstName") {
      this.returnData.firstName = this.data.firstName;
    }
    else if (field == "lastName") {
      this.returnData.lastName = this.data.lastName;
    }
    else if (field == "email") {
      this.returnData.email = this.data.email;
    }
    else if (field == "jobTitle") {
      this.returnData.jobTitle = this.data.jobTitle;
    }
    else if (field == "profileUrl") {
      this.returnData.profileUrl = this.data.profileUrl;
      this.returnData.image = this.data.image;
    }
    else {
      this.autoFill();
    }
  }

  autoFill() {
    this.returnData.firstName = this.data.firstName;
    this.returnData.lastName = this.data.lastName;
    this.returnData.email = this.data.email;
    this.returnData.jobTitle = this.data.jobTitle;
    // this.returnData.phoneNumber = this.data.phoneNumber;
    this.returnData.profileUrl = this.data.profileUrl;
    this.returnData.image = this.data.image;
  }
}