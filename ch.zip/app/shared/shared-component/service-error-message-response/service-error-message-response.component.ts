import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-service-error-message-response',
  templateUrl: './service-error-message-response.component.html',
  styleUrls: ['./service-error-message-response.component.scss']
})
export class ServiceErrorMessageResponseComponent implements OnInit {
  @Input() errorMessage: string;

  constructor() { }

  ngOnInit() {
    if(this.errorMessage === '200'){
      alert('fname error')
    }
  }

}
