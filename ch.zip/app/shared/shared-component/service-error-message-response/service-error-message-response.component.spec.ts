import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceErrorMessageResponseComponent } from './service-error-message-response.component';

describe('ServiceErrorMessageResponseComponent', () => {
  let component: ServiceErrorMessageResponseComponent;
  let fixture: ComponentFixture<ServiceErrorMessageResponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceErrorMessageResponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceErrorMessageResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
