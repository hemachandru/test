import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { integer } from 'aws-sdk/clients/cloudfront';

@Component({
  selector: 'app-country-list',
  templateUrl: './country-list.component.html',
  styleUrls: ['./country-list.component.scss']
})
export class CountryListComponent implements OnInit {
  countryList: any;
  constructor(private sharedBusiness: SharedBusiness) { }

  // tslint:disable-next-line:no-output-on-prefix
  @Output() onSelectCountry = new EventEmitter();
  @Input() selectClass: string;
  @Input() getCountry: integer;
  @Input() controlName: string;

  ngOnInit() {
     this.getCountryList();
   }

    getCountryList() {
      // console.log('component');
      const resList = this.sharedBusiness.getCountryListBusiness().subscribe(data => {
        this.countryList = data;
        if (data) {
          // console.log(data);
        } else {
          console.log('error');
        }
      });
    }

    onChange(countryid) {
      // console.log(countryid);
      this.onSelectCountry.emit(countryid);
  }
}
