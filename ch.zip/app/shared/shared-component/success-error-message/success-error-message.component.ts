import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
@Component({
  selector: 'app-success-error-message',
  templateUrl: './success-error-message.component.html',
  styleUrls: ['./success-error-message.component.scss']
})
export class SuccessErrorMessageComponent implements OnInit {
  @Input() errorType: any;
  @Input() callback: Function;
  @Output() onButtonClick = new EventEmitter<any>();
  public title : any;

  constructor(private router: Router) {
  }

  ngOnInit() {
    // this.title = this.errorType.errorTitle;
  }

  buttonClicked(btnObj:string){
    this.onButtonClick.emit(btnObj);
  }

  navigateToLogin()
  {
    this.router.navigate(['auth/login']);
  }
}
