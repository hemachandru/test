import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-button-with-close-icon',
  templateUrl: './button-with-close-icon.component.html',
  styleUrls: ['./button-with-close-icon.component.scss']
})
export class ButtonWithCloseIconComponent implements OnInit {
//onSelectCountryData
  @Output() onSelectData = new EventEmitter();

  @Input() buttonData = [];
  constructor() { }

  ngOnInit() {
  }

  myClick(mydata) {
    this.onSelectData.emit(mydata);
  }
}
