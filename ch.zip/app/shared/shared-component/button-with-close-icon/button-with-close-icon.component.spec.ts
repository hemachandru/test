import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonWithCloseIconComponent } from './button-with-close-icon.component';

describe('ButtonWithCloseIconComponent', () => {
  let component: ButtonWithCloseIconComponent;
  let fixture: ComponentFixture<ButtonWithCloseIconComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ButtonWithCloseIconComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonWithCloseIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
