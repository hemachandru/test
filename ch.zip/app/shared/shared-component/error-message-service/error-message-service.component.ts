import { Component, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ValidationService } from '@app/shared/shared-service/validation-service';


@Component({
  selector: 'app-error-message-service',
  template: `<div *ngIf="errorMessage !== null" class="alert alert-danger">{{errorMessage}}</div>`,
  styleUrls: ['./error-message-service.component.scss']
})
export class ErrorMessageServiceComponent {
  @Input() errorControlName: any;
  @Input() errorCode: any;
  constructor() { }

  ngOnInit() {
  }

  get errorMessage() {
    if (this.errorControlName && this.errorCode) {
      return ValidationService.getSignUpValidatorErrorMessage(this.errorControlName, this.errorCode);
    }
  }

}
