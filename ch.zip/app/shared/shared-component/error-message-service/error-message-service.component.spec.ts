import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorMessageServiceComponent } from './error-message-service.component';

describe('ErrorMessageServiceComponent', () => {
  let component: ErrorMessageServiceComponent;
  let fixture: ComponentFixture<ErrorMessageServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorMessageServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorMessageServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
