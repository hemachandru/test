export class Linkedin {
    firstName: string;
    lastName: string;
    email: string;
    jobTitle: string;
    profileUrl: string;
    image:string;    
    name:string;
    uid:string;
}
