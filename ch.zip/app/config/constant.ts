
export class Config {

  //validation patterns
  alphaNumericPattern = '[a-zA-Z0-9]+';
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,15}$';
  mobnumPattern = '^((\\+91-?)|0)?[0-9]{7,15}$';
  webPattern = '^[a-z0-9._%+-]+.[a-z0-9.-]+\.[a-z]{2,4}$';
  urlPattern ='/^(http[s]?:\/\/){0,1}(www\.){0,1}[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,5}[\.]{0,1}/';
  flag_percent = {'legalName':[2,1],'certificateNo':[2,1],
                        'profileAddress':[2,1],'profileMobile':[1,1]
                        ,'profileemail':[1,1],'profilelinkedURL':[1,1],
                        'profileGoogleURL':[1,1],'profileInstaURL':[1,1],
                        'profileJobtitle':[2,1],'profileFirstName':[1,1],
                        'profileAuthmob':[2,1],'profileLastname':[1,1],
                        'fileprofileLogo':[3,1],'accCerficateId':[2,1],'profileTaxCertno':[3,1]
                        ,'profileIssuedBy':[2,1],'fileprofileFavicon':[2,1]};
                       
}

export declare abstract class MenuItem {
  /**
   * Item Title
   * @type {string}
   */
  title: string;
  /**
   * Item relative link (for routerLink)
   * @type {string}
   */
  link?: string;
  /**
   * Item URL (absolute)
   * @type {string}
   */
  url?: string;
  /**
   * Icon class name
   * @type {string}
   */
  icon?: string;
  /**
   * Expanded by defaul
   * @type {boolean}
   */
  expanded?: boolean;
  /**
   * Children items
   * @type {List<MenuItem>}
   */
  children?: MenuItem[];
  /**
   * Children items height
   * @type {number}
   */
  subMenuHeight?: number;
  /**
   * HTML Link target
   * @type {string}
   */
  target?: string;
  /**
   * Hidden Item
   * @type {boolean}
   */
  hidden?: boolean;
  /**
   * Item is selected when partly or fully equal to the current url
   * @type {string}
   */
  pathMatch?: string;
  /**
   * Where this is a home item
   * @type {boolean}
   */
  home?: boolean;
  /**
   * Whether the item is just a group (non-clickable)
   * @type {boolean}
   */
  group?: boolean;
  parent?: MenuItem;
  selected?: boolean;
  data?: any;
  fragment?: string;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    title: 'Home',
    icon: 'fa-home',
    link: '/channel/dashboard',
    home: true
  },
  {
    title: 'Approval Center',
    icon: 'fa-file-text',
    link: '/channel/Approval',
    children: [
      {
        title: 'Channels',
        link: '/channel/approval/Channels',
      },
      {
        title: 'Products',
        link: '/channel/Approval-Center/Products',
      },
      {
        title: 'Spot Deals',
        link: '/channel/Approval-Center/Spot-Deals',
      },
      {
        title: 'Ratings',
        link: '/channel/Approval-Center/Ratings',
        children: [
          {
            title: 'Channels',
            link: '/channel/Approval-Center/Channels Rating',
          },
          {
            title: 'Channels',
            link: '/channel/Approval-Center/Product Ratings',
          }
        ]
      }
    ],
  },
  {
    title: 'Customers',
    icon: 'fa-group',
    link: '/channel/Customers',
    children: [{
      title: "Channels",
      link: ' /channel/Customers/Channels'
      },
      {
        title: "Billings",
        link: '/channel/Customers/Billings',
        children: [
          {
            title: 'Subscriptions',
            link: '/channel/Customers/Billings/Subscriptions',
          },
          {
            title: 'SalesRep Invoices',
            link: '/channel/Customers/Billings/SalesRep-Invoices',
          },
          {
            title: 'Trade Show Enrollments',
            link: '/channel/Customers/Billings/Trade-Show-Enrollments ',
          }
        ]
      },
      {
        title: 'Payments',
        link: '/channel/Customers/Payments',
        children: [{
          title: 'Sales Rep Payments',
          link: '/channel/Customers/Payments/Sales-Rep-Payments ',
          },
          {
          title: 'Trade Show Refunds',
          link: '/channel/Customers/Payments/SalesRep-Invoices',
        }]
      }
    ],
  },
  {
    title: 'Ratings & Review',
    icon: 'fa-star',
    link: '/channel/Ratings&Review',
    children: [{
      title: 'Ratings',
      link: '/channel/Ratings/tree',
    },
    {
      title: 'Product Rating Approvals',
      link: '/channel/components/product-rating-approvals',
    }]
  },
  {
    title: 'Recommendations',
    icon: 'fa-file-text',
    link: '/channel/Recommendations',
    children: [{
      title: 'Vendors',
      link: '/channel/Recommendations/vendors',
      },
      {
      title: 'Distributor',
      link: '/channel/Recommendations/Distributor',
      },
      {
      title: 'Retailer',
      link: '/channel/Recommendations/Retailer',
      },
      {
      title: 'Sales Rep',
      link: '/channel/Recommendations/Sales Rep',
      },
      {
      title: 'Products',
      link: '/channel/Recommendations/Products',
      }
    ]
  },
  {
    title: 'Catalog',
    icon: 'fa-bar-chart',
    link: '/channel/Catalog',
    children: [{
      title: 'Products',
      link: '/channel/Catalog/Products',
      },
      {
      title: 'Spot Deals',
      link: '/channel/Catalog/Spot-Deals',
      }
    ]
  },
  {
    title: 'Samples Management',
    icon: 'fa-group',
    link: '/channel/Samples-Management',
    children: [{
      title: 'Smart Table',
      link: '/channel/tables/smart-table',
      }
    ]
  },
  {
    title: 'Support',
    icon: 'fa-comments-o',
    link: '/channel/Support',
    children: [{
      title: 'Complaints',
      link: '/channel/Support/Complaints',
      },
      {
      title: 'General',
      link: '/channel/Support/General',
      },
      {
      title: 'IPR Complaints',
      link: '/channel/Support/IPR-Complaints',
      }
    ]
  },
  {
    title: 'Marketing',
    icon: 'fa-comments-o',
    link: '/channel/Marketing',
    children: [{
      title: 'News Letter',
      link: '/channel/Marketing/News-Letter',
      },
      {
      title: 'Coupons',
      link: '/channel/Marketing/Coupons',
      },
      {
      title: 'Error Reporting Rewards',
      link: '/channel/Marketing/Error-Reporting-Rewards',
      }
    ]
  },
  {
    title: 'User Management',
    icon: 'fa-group',
    link: '/channel/User-Management',
  },
  {
    title: 'CMS',
    icon: 'fa-file-text',
    link: '/channel/CMS',
    home: true,
    children: [{
      title: 'Pages',
      link: '/channel/CMS/pages',
      },
      {
      title: 'News',
      link: '/channel/CMS/News',
      },
      {
      title: 'FAQ',
      link: '/channel/CMS/FAQ',
      },
      {
      title: 'Preset Messages',
      link: '/channel/CMS/Preset-Messages',
      },
      {
      title: 'Mail Templates',
      link: '/channel/CMS/Mail-Templates',
      },
      {
      title: 'Site Ticker',
      link: '/channel/CMS/Site-Ticker',
      }
    ]
  },
  {
    title: 'Settings',
    icon: 'fa-gear',
    link: '/channel/Settings',
    children: [{
      title: 'Catalog',
      link: '/channel/Settings/Catalog',
      },
      {
      title: 'Payment Gateway',
      link: '/channel/Settings/Payment-Gateway',
      },
      {
      title: 'Location Management',
      link: '/channel/Settings/Location-Management',
      },
      {
      title: 'Preferences',
      link: '/channel/Settings/Preferences',
      },
      {
      title: 'Subscription',
      link: '/channel/Settings/Subscription',
      },
    ]
  },
  {
    title: 'Reports',
    icon: 'fa-file-text',
    link: '/channel/Reports',
    home: true,
    children: [{
      title: 'Channel Reports',
      link: '/channel/Reports/Channel-Reports',
      children: [{
        title: 'Billing Reports',
        link: '/channel/Reports/Billing Reports',
        },
        {
        title: 'Payment Reports',
        link: '/channel/Reports/Payment Reports'
      }]
    }],
}];

export const SIDEMENU_ITEMS: MenuItem[] = [
  {
    title: 'Profile',
    icon: 'fa-user',
    link: '/channel/dashboard',
    home: true
  },  
  {
    title: 'Suggestion',
    icon: 'fa-lightbulb-o',
    link: '/channel/Approval',
    children: [
      {
        title: 'Channels',
        link: '/channel/approval/Channels',
      }, 
      {
        title: 'Products',
        link: '/channel/Approval-Center/Products',
      }, 
      {
        title: 'Spot Deals',
        link: '/channel/Approval-Center/Spot-Deals',
      }, 
      {
        title: 'Ratings',
        link: '/channel/Approval-Center/Ratings',
        children: [
          {
            title: 'Channels',
            link: '/channel/Approval-Center/Channels Rating',
          }, 
          {
            title: 'Channels',
            link: '/channel/Approval-Center/Product Ratings',
          }
        ]
      }
    ],
  }, 
  {
    title: 'My Prospects',
    icon: 'fa-wifi',
    link: '/channel/Customers',
    children: [{
      title: "Channels",
      link: ' /channel/Customers/Channels'
      },
      {
        title: "Billings",
        link: '/channel/Customers/Billings',
        children: [
          {
            title: 'Subscriptions',
            link: '/channel/Customers/Billings/Subscriptions',
          },
          {
            title: 'SalesRep Invoices',
            link: '/channel/Customers/Billings/SalesRep-Invoices',
          }, 
          {
            title: 'Trade Show Enrollments',
            link: '/channel/Customers/Billings/Trade-Show-Enrollments ',
          }
        ]
      },
      {
        title: 'Payments',
        link: '/channel/Customers/Payments',
        children: [{
          title: 'Sales Rep Payments',
          link: '/channel/Customers/Payments/Sales-Rep-Payments ',
          },
          {
          title: 'Trade Show Refunds',
          link: '/channel/Customers/Payments/SalesRep-Invoices',
        }]
      }
    ],
  },    
  {
    title: 'My Channels',
    icon: 'fa-star',
    link: '/channel/Ratings&Review',
    children: [{
      title: 'Ratings',
      link: '/channel/Ratings/tree',
    }, 
    {
      title: 'Product Rating Approvals',
      link: '/channel/components/product-rating-approvals',
    }]
  },
  {
    title: 'Spot Deal',
    icon: 'fa-tags',
    link: '/channel/Recommendations',
    children: [{
      title: 'Vendors',
      link: '/channel/Recommendations/vendors',
      },
      {
      title: 'Distributor',
      link: '/channel/Recommendations/Distributor',
      },
      {
      title: 'Retailer',
      link: '/channel/Recommendations/Retailer',
      },
      {
      title: 'Sales Rep',
      link: '/channel/Recommendations/Sales Rep',
      },
      {
      title: 'Products',
      link: '/channel/Recommendations/Products',
      }
    ]
  },  
  {
    title: 'My Products',
    icon: 'fa-product-hunt',
    link: '/channel/Catalog',
    children: [{
      title: 'Products',
      link: '/channel/Catalog/Products',
      }, 
      {
      title: 'Spot Deals',
      link: '/channel/Catalog/Spot-Deals',
      }
    ]    
  },
  {
    title: 'My Contacts',
    icon: 'fa-address-card',
    link: '/channel/Samples-Management',
    children: [{
      title: 'Smart Table',
      link: '/channel/tables/smart-table',
      } 
    ]
  }, 
  {
    title: 'My Requests',
    icon: 'fa-file',
    link: '/channel/Support',
    children: [{
      title: 'Complaints',
      link: '/channel/Support/Complaints',
      },
      {
      title: 'General',
      link: '/channel/Support/General',
      }, 
      {
      title: 'IPR Complaints',
      link: '/channel/Support/IPR-Complaints',
      }
    ]
  },     
  {
    title: 'Sample Order',
    icon: 'fa-first-order',
    link: '/channel/Marketing',
    children: [{
      title: 'News Letter',
      link: '/channel/Marketing/News-Letter',
      },
      {
      title: 'Coupons',
      link: '/channel/Marketing/Coupons',
      }, 
      {
      title: 'Error Reporting Rewards',
      link: '/channel/Marketing/Error-Reporting-Rewards',
      }
    ]
  },   
  {
    title: 'Help / Report',
    icon: 'fa-info-circle',
    link: '/channel/User-Management',    
  }];

export const SIDEMENU: any = [
  { "id": "1", "menuname": "Profile", "icon": "glyphicon glyphicon-user" },
  { "id": "2", "menuname": "Suggestion", "icon": "glyphicon  glyphicon-user" },
  { "id": "3", "menuname": "My Prospects", "icon": "glyphicon glyphicon-user" },
  { "id": "4", "menuname": "My Channels", "icon": "glyphicon glyphicon-user" },
  { "id": "5", "menuname": "Spot Deal", "icon": "glyphicon glyphicon-user" },
  { "id": "6", "menuname": "My Products", "icon": "glyphicon glyphicon-home" },
  { "id": "7", "menuname": "My Contacts", "icon": "glyphicon glyphicon-user" },
  { "id": "8", "menuname": "My Requests", "icon": "glyphicon glyphicon-user" },
  { "id": "9", "menuname": "Sample Order", "icon": "glyphicon glyphicon-user" },
  { "id": "10", "menuname": "Help / Report", "icon": "glyphicon glyphicon-exclamation-sign" }
]


export const menuList: any = [
  { id: '1', menuName: 'Home', menuLink: 'home/home', menuactive: 'active' },
  { id: '2', menuName: 'Hawk Eye', menuLink: 'Hawk.html' },
  { id: '2', menuName: 'Directory', menuLink: 'Directory.html' },
  { id: '2', menuName: 'Subscription', menuLink: 'Subscription.html' },
  { id: '2', menuName: 'My ChannelHub', menuLink: 'ChannelHub.html' },
  { id: '2', menuName: 'News', menuLink: 'News.html' },
  { id: '2', menuName: 'Community', menuLink: 'Community.html' }
];

export const RoleMenu: any = [
  { id: 1, menuName: "Home", icon: "fa fa-home", count: "" },
  { id: 2, menuName: "WishList", icon: "fa fa-heart", count: "" },
  { id: 3, menuName: "My Cart", icon: "fa fa-shopping-cart", count: "2" },
  { id: 4, menuName: "Message", icon: "fa fa-envelope", count: "3" },
  { id: 5, menuName: "Notification", icon: "fa fa-bell", count: "6" }
]

export const userSelctionList: any = [
  {
    id: 2,
    UserName: "Vendor",
    className: "vendor",
    message: [
      { msg: "Increase your sales" },
      { msg: "Work with reliable channel partners" },
      { msg: "Sample Management" },
      { msg: "Find your local sales force" }
    ]
  },
  {
    id: 3,
    UserName: "Distributor",
    className: "distributor",
    message: [
      { msg: "Source new products & Increase your sales" },
      { msg: "Work with reliable vendors" },
      { msg: "Sample Management" },
    ]
  },
  {
    id: 4,
    UserName: "Retailer",
    className: "retailer",
    message: [
      { msg: "Source new products" },
      { msg: "Work with reliable vendors" },
      { msg: "Sample Management" }
    ]
  },
  {
    id: 5,
    UserName: "Sales Rep",
    className: "sales-rep",
    message: [
      { msg: "Increase your sales" },
      { msg: "Work with reliable vendors and channel partners" },
      { msg: "Sample Management" },
    ]
  },
]

export class SuccesErrorMessage {
  errorId: string;
  errorType: string;
  errorTitle: string;
  icon: string;
  iconMessage: string;
  messages: [{
    messageContent: string;
  }];
  button: [{
    buttonType: string;
    buttonName: string;
    buttonValue: string;
    buttonLink: any;
  }];
  showButtonBlock:boolean=true;
}

export class UserDetailMessage {
  email: string;
  action: string;
}

export enum UserAccountStatus {
  VERIFICATION = 1,
  REVERIFICATION = 2,
  REVERIFICATION_MAILCHANGE = 3,
  SUBSCRIPTION = 4,
  PAYMENT_PENDING = 5,
  PAYMENT_FAILURE = 6,
  ACCOUNTSETUP = 7,
  ACCOUNTSETUP_COMPANYPROFILE = 8,
  ACCOUNTSETUP_TRADEINFORMATION = 9,
  ACCOUNTSETUP_TRADELOCATION = 10,
  CLAIM = 11,
  CLAIM_APPROVED = 12,
  CLAIM_REJECTED = 13,
  CHANNEL_APPROVAL = 14,
  CHANNEL_APPROVED = 15
}

export class OrderDetails {
  id: string;
  status: string;
}
