import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';

import { AccountBusiness } from '../../business/account.business'
import { AccountService } from '../../service/account-service';
import { HttpRequestService } from '../../../../service/http-request.service';

import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

//data send via services
import { DataService} from '../../../../shared/shared-service/data.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [AccountBusiness, AccountService, HttpRequestService] 
})
export class LoginComponent implements OnInit {
  @Output() loginState = new EventEmitter();
  message:string;

  data:any = {text: "example"};

  constructor(
    private router: Router, 
    private loginBusiness: AccountBusiness, 
    private formBuilder: FormBuilder,
    private dataService: DataService
    ) {}

  ngOnInit() {
      this.profileForm = this.formBuilder.group({
        userName: ['', [Validators.required]],
        password: ['', [Validators.required]]
    });
  }

  profileForm = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl(''),
  });
  

  layoutStatus = 'login';
  login;
  onSignup() {
    this.login = 'signup';
    this.loginState.emit(this.login);    
    // this.router.navigate(['account/signup']);
    // window.location.href = 'https://www.google.com/';
  }
  public menuList = [];
  public submenuList = [];
  onSubmit() {
    this.loginBusiness.travlogixLogin(JSON.stringify(this.profileForm.value)).subscribe(res => {
      if(res.messageCode == "Success")
      {
        this.dataService.setData(res);
        // for(let i=0; i< res.data.ObjMenu.length; i++){
        //   if(res.data.ObjMenu[i].ParentKey == "-1" || res.data.ObjMenu[i].ParentKey == "54"){
        //     this.menuList.push(res.data.ObjMenu[i]);
        //   }
        // }  
        
        this.getTableList()
        // this.router.navigate(['home/home']);
      }else{
        var data =  this.profileForm.value;
        this.onSubmittravelb2b(data);
      }
    }, (err) => {
        console.log("login travlogix error" + err);
    });
  }

  onSubmittravelb2b(data: any) {
    var userData = [data.userName, data.password]
    this.loginBusiness.travelB2BLogin(JSON.stringify(userData)).subscribe(res => {
      this.router.navigate(['home/home']);
    }, (err) => {
        console.log("login travelb2b error" + err);
    });
  }


childlistObj= [];
clickMe(event)
{  
    // console.log(event.target.attributes.id.nodeValue);
    var jsData = this.dataService.getJsonData();
    // console.log(jsData)

    for (var i = 0; i < jsData.length; i++) {
      if (jsData[i].id == event.target.attributes.id.nodeValue) {
          // console.log('true : ', jsData[i].id);         
          
          if (jsData[i].segmentList.length){
            console.log("segmentList length : ",jsData[i].segmentList.length)
            // debugger
            for( let j = 0 ; j< jsData[i].segmentList.length; j++){
              // debugger
              console.log(jsData[i].segmentList)
              var segmentList = {};
              segmentList["id"] = jsData[i].segmentList[j].id;
              segmentList["index"] = jsData[i].segmentList[j].index;
              segmentList["xmltag"] = jsData[i].segmentList[j].xmltag;
              this.childlistObj.push(segmentList);
            }
            console.log('childlistObj list : ', this.childlistObj) 
          }
          
      }
  }

}

listObj = [];
  getTableList() {
    this.loginBusiness.getJsonBusiness().subscribe(res => {
      // console.log("segmentList success --> : ", res.obj.segments.segmentList[0].segmentList);
      // console.log("fieldList success --> : ", res.obj.segments.segmentList[0].fieldList);

      var chk = res.obj.segments.segmentList[0].segmentList
      this.dataService.setJsonData(chk);
      // console.log(chk)
      // localStorage.setItem('jsVal', JSON.stringify(chk))


      for( let i = 0 ; i< res.obj.segments.segmentList[0].segmentList.length; i++){
        // this.myObj.segmentLists.push(res.obj.segments.segmentList[0].segmentList[i].xmltag);
        var segmentList = {};
        segmentList["id"] = res.obj.segments.segmentList[0].segmentList[i].id;
        segmentList["index"] = res.obj.segments.segmentList[0].segmentList[i].index;
        segmentList["xmltag"] = res.obj.segments.segmentList[0].segmentList[i].xmltag;
        this.listObj.push(segmentList);
        // this.obj.push(res.obj.segments.segmentList[0].segmentList[i].xmltag);
      }
      

      // console.log('myObj list : ', this.listObj)     

    }, (err) => {
        console.log("error" + err);
    });
  }

}
