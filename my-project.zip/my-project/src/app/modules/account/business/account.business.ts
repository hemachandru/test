import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Config } from '../../../config/constant';
import { AccountService } from '../service/account-service';

@Injectable()
export class AccountBusiness{
    constructor(
      private config: Config, 
      private router: Router, 
      private accountService: AccountService
    ) {}
    
    travlogixLogin(data) {
      let apiUrl = this.config.getBaseURLtravlogix() + this.config.travlogixLogin
      return this.accountService.getLoginService(data, apiUrl).map((result => result));
    }

    travelB2BLogin(data) {
      let apiUrl = this.config.getBaseURLtravelb2b() + this.config.travelb2bLogin
      return this.accountService.getLoginService(data, apiUrl).map((result => result));
    }

    getJsonBusiness() {
      let apiUrl = this.config.jsonList
      return this.accountService.getJsonService(apiUrl).map((result => result));
    }

}