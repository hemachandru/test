import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NotfoundComponent } from './component/notfound/notfound.component';

//jwt token ckecking
// import { AuthGuardService as AuthGuard } from './auth/auth-guard.service';
// import { AuthGuardService } from './auth/auth-guard.service';

const routes: Routes = [  
  {
    path: 'home',
    children: [
      {
        path:"",
        loadChildren:"./modules/home/home.module#HomeModule"
        // canLoad: [AuthGuardService]
      }  //Lazy loading integration [load children]
    ]
  },
  {
    path: '',
    children: [
      {
        path:"",
        loadChildren:"./modules/account/account.module#AccountModule"
      } //Lazy loading integration 
    ]
  },
  { path: '**', component: NotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
