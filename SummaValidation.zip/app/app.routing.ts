import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './modules/dashboad/containers';
import { notfoundComponent } from '../app/not-found/404.component'

import { AuthGuard } from './auth-service/auth-guard.service';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  // {
  //   path: 'login',
  //   loadChildren: './modules/account/account.module#AccountModule'
  // },
  {
    path: '',
    loadChildren: './modules/account/account.module#AccountModule'
  },

  {
    path: 'dashboard',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    children: [
      {
        path: '',
        loadChildren: './modules/dashboad/dashboard.module#DashboardModule',
        canLoad: [AuthGuard]
      }
    ]
  },

  { path: '**', component: notfoundComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
