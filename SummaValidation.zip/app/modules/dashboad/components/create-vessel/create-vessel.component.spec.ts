import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateVesselComponent } from './create-vessel.component';

describe('CreateVesselComponent', () => {
  let component: CreateVesselComponent;
  let fixture: ComponentFixture<CreateVesselComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateVesselComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateVesselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
