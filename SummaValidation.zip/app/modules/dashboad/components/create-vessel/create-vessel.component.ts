import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { NgxSpinnerService } from 'ngx-spinner';

import { Config } from '../../../../config/constant';
import { navItems} from '../../model/dashboad';
// countryList
import { countryList } from '../../model/country'

import {DashboadBusiness} from '../../business/dashboad.business'
import { DashboadService } from '../../services/dashboad.service';
import { HttpRequestService } from '../../../../shared/http-service/http-request.service';
import { from } from 'rxjs';

@Component({
  selector: 'app-create-vessel',
  templateUrl: './create-vessel.component.html',
  styleUrls: ['./create-vessel.component.scss'],
  providers: [DashboadBusiness, DashboadService, HttpRequestService]
})
export class CreateVesselComponent implements OnInit {

  vesselCreationForm: FormGroup;
  formSubmit = false;

  //form 
  shipname: any;
  vesselcode: any;
  displacementTonnage: any;
  registerTonnage: any;
  beam: any;
  deadWeightTonnage: any;
  draft: any;
  length: any;
  ownerCompany: any;
  //form

  countryErrorMessage: boolean = false;
  public countryList = countryList;
  public navItems = navItems;

  constructor(
    private config: Config, 
    private fb: FormBuilder, 
    private spinner: NgxSpinnerService,
    private dashboadBusiness: DashboadBusiness
  ) { }

  ngOnInit() {
    this.initForm();
    console.log(this.countryList)
    for(let i = 0; i<= this.navItems.length; i++){
      console.log('ssssssssssssssssssss',this.navItems[i].attributes)
    }
  }

  initForm() {
    const shipname = '';
    const vesselcode = '';
    
    this.vesselCreationForm = this.fb.group({
      
      shipname: ['', Validators.compose(
        [
          Validators.required,
        ]        
      )],
      vesselcode: ['', Validators.compose(
        [
          Validators.required
        ]
      )]
      // ,displacementTonnage: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // registerTonnage: ['', Validators.compose(
      //   [
      //     Validators.required,
      //   ]
      // )],
      // beam: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // deadWeightTonnage: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // draft: ['', Validators.compose(
      //   [
      //     Validators.required,
      //   ]
      // )],
      // length: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // ownerCompany: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // callSign: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )],
      // description: ['', Validators.compose(
      //   [
      //     Validators.required
      //   ]
      // )]

    });
  }

  onSubmit() {
    const values = this.vesselCreationForm.value;
    this.formSubmit = true;
    console.log('values  --  : ',values);

    this.spinner.show();
    this.dashboadBusiness.saveVesselData(values).subscribe(res => {
      console.log("success --> : ", res);
      this.spinner.hide();
    }, (err) => {
        console.log("error" + err);
    });

    // this.errorCountry = Validators.required;
  }

  onChange(countryid) {
    console.log(countryid);
    
    // if(countryid == "null"){
    //   this.countryErrorMessage == true
    // }else{
    //   this.countryErrorMessage == false
    // }
  }

  // onClick(countryid) {
  //   console.log(countryid);
  //   debugger
  //   if(countryid == "null"){
  //     this.countryErrorMessage == true
  //   }else{
  //     this.countryErrorMessage == false
  //   }
  // }

  resetData() {
    this.shipname = "";
    this.vesselcode = "";
    this.displacementTonnage = "";
    this.registerTonnage = "";
    this.beam = "";
    this.deadWeightTonnage = "";
    this.draft = "";
    this.length = "";
    this.ownerCompany = "";
  }

}
