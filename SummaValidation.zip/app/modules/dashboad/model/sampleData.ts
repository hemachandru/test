

export const TableList =
[ 
    {
        shipName: 'Afghanistan', 
        isValid: true,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: false,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: false,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: true,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: false,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: true,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    },
    {
        shipName: 'Afghanistan', 
        isValid: false,
        ownerCompany: 'Test company',
        country: 'Gibraltar',
        displacementTonnage: 'ddd',
        length: '112.2'
    }
]