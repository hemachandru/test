// interface NavAttributes {
//   [propName: string]: any;
// }
// interface NavWrapper {
//   attributes: NavAttributes;
//   element: string;
// }
// interface NavLabel {
//   class?: string;
//   variant: string;
// }
interface NavBadge {
  text: string;
  variant: string;
}
interface Permissions {
  save:boolean;
  edit:boolean;
  delete:boolean;
}

export interface NavData {
  name?: string;
  url?: string;
  icon?: string;
  badge?: NavBadge;
  attributes?: Permissions;
  children?: NavData[];
}

export const navItems: NavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    // icon: 'icon-speedometer',
    badge: {
      variant: 'info',
      text: ''
    },
    attributes: {
      save : true,
      edit : true,
      delete : true,
    }
  },
  {
    name: 'Vessel Announcement',
    url: '#',
    // icon: 'icon-puzzle',
    children: [
      {
        name: 'Vessel List',
        url: '/dashboard/list',
        // icon: 'icon-puzzle'
      }
    ]
  }
];
