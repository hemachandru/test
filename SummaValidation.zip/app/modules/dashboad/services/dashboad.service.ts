import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
//import http method 

import { HttpRequestService } from '../../../shared/http-service/http-request.service';

@Injectable()
export class DashboadService {
  constructor(private httpRequest: HttpRequestService) {}

  saveVesselService(data:string, url: string) {
    return this.httpRequest.postHttpRequestWithToken(data, url);
  }

  listService(url: string) {
    return this.httpRequest.getHttpRequest(url);
  }

}
