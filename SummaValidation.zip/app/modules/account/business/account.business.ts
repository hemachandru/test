import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Config } from '../../../config/constant';
import { AccountService } from '../services/account.service';

@Injectable()
export class AccountBusiness{
    constructor(
      private config: Config, 
      private router: Router, 
      private accountService: AccountService
    ) {}
    
    accountLogin(data) {
       //debugger
      let apiUrl = this.config.login
      return this.accountService.loginService(data, apiUrl).map((result => result));
    }
}
