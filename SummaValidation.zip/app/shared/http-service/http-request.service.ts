import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { debug } from 'util';

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    constructor(private http: Http) {
        this.headers = new Headers();
    }

    /** Http POST Request without user token **/
  /**Params {data: userdata, url: apiurl} */
  postHttpRequestWithoutToken(datas: any, url: string) {
    //debugger
        var self = this;
        self.headers.set('Content-Type', 'application/x-www-form-urlencoded');
        self.headers.set('Accept', 'application/json');
        let data = `grant_type=password&username=${datas.username}&password=${datas.password}`
        return self.http.post(url, data ,{
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
    }

  /** Http POST Request with user token **/
  postHttpRequestWithToken(data: any, url: string) {
    var self = this;
    self.headers.set('Content-Type', 'application/x-www-form-urlencoded');
    self.headers.set('Accept', 'application/json');
    this.headers.set('Authorization', 'Bearer ' + localStorage.getItem('token'));
    return self.http.post(url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse)
  }


    /** Http GET Request **/
    getHttpRequest(url: string) {
      var self = this;
      self.headers.set('Content-Type', 'application/json');
      self.headers.set('Accept', 'application/json');
      this.headers.set('Authorization', 'Bearer ' + localStorage.getItem('token'));
        return self.http.get(url , {
            headers: self.headers
        })
        .map(self.successResponse)
        .catch(self.errorResponse)
    }

    //************** callback methods  **************

     /**successResponse*/
    private successResponse(result: Response) {
         //debugger
        return result.json() || null;
    }

    /**errorResponse*/
    private errorResponse(error: Response) {
        console.log('Error Response : ',error)
         //debugger
        return Observable.throw(error.json() || null);
    }

    /**onFinally*/
    private onFinally(): void {
        console.log('Loading....')
    }

}
