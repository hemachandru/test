import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import { ReactiveFormsModule } from '@angular/forms';

//components and modules import
import { AccountRoutingModule } from './account-routing.module';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
//dependency injections
import { AccountService } from './service/account-service';
import { AccountBusiness } from './business/account.business'
import { Config } from '../../config/constant';
import { AccountLayoutComponent } from './component/account-layout/account-layout.component';

@NgModule({
  declarations: [LoginComponent, SignupComponent, AccountLayoutComponent],
  imports: [
    CommonModule,
    AccountRoutingModule,
    HttpModule,
    ReactiveFormsModule
  ],
  providers: [AccountBusiness, AccountService, Config]
})
export class AccountModule { }
