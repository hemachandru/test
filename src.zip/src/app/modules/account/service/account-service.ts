import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../service/http-request.service';

@Injectable()
export class AccountService {
  constructor(private httpRequest: HttpRequestService) {}
  
  getLoginService(data: any, url: string) {
    return this.httpRequest.postHttpRequestWithoutToken(data, url);
  }

}