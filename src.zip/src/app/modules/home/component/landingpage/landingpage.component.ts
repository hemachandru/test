import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';

//data receive via services
import { DataService} from '../../../../shared/shared-service/data.service'

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.scss']
})
export class LandingpageComponent implements OnInit {
  message:string;
  data:any;
  public menuList = [];
  public submenuList = [];
  public  = {};
  public finalMenu = [];

  constructor(
    private router: Router, 
    private route: ActivatedRoute,
    private dataService: DataService
  ) {}

  ngOnInit() {
    this.data = this.dataService.getData();
    if (this.data){
      //  console.log(this.data.data.ObjMenu)
      //ng serve --host 172.17.135.173

      for(let i=0; i< this.data.data.ObjMenu.length; i++){
        if(this.data.data.ObjMenu[i].ParentKey == "-1" || this.data.data.ObjMenu[i].ParentKey == "54"){
          // console.log('Business Category Details -------- Name :', res.data.ObjMenu[i].ProgramPageName,'--- ParentKey : ',res.data.ObjMenu[i].ParentKey,' ----- KEY :', res.data.ObjMenu[i].Key)
          this.menuList.push(this.data.data.ObjMenu[i]);
        }
      }

      for(let j=0; j< this.menuList.length; j++){
        if(this.menuList[j].Key == this.data.data.ObjMenu[j].ParentKey){
          this.submenuList.push(this.data.data.ObjMenu[j]);
          // KEY : 2 == ParentKey: 2  submenuLists
        }
      }

      // console.log(this.menuList.Key)
      console.log(this.submenuList.length)

    }else{
      this.router.navigate(['/layout']);
    }
    
  }

  onSelect(hero: any): void {
    console.log(hero.Key);
    this.data = this.dataService.getData();
    for(let i=0; i< this.data.data.ObjMenu.length; i++){
      if (this.data.data.ObjMenu[i].ParentKey == hero.Key){
        this.submenuList.push(this.data.data.ObjMenu[i]);
      }    
    }
    // this.submenuList
  }

  onLogin() {
    this.router.navigate(['account/login']);
    // window.location.href = 'https://www.google.com/';
  }
}
