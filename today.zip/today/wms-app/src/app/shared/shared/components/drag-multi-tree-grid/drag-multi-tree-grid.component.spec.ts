import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DragMultiTreeGridComponent } from './drag-multi-tree-grid.component';

describe('DragMultiTreeGridComponent', () => {
  let component: DragMultiTreeGridComponent;
  let fixture: ComponentFixture<DragMultiTreeGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DragMultiTreeGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DragMultiTreeGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
