import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeLoadmoreComponent } from './tree-loadmore.component';

describe('TreeLoadmoreComponent', () => {
  let component: TreeLoadmoreComponent;
  let fixture: ComponentFixture<TreeLoadmoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreeLoadmoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreeLoadmoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
