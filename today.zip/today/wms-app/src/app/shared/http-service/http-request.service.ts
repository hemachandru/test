import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    constructor(private http: Http) {
        this.headers = new Headers();
    }

    postHttpRequest(data: string, url: string) {
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');
        // this.headers.set('Authorization', 'Bearer ' + "token");
        return self.http.post(url, data ,{
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
    }


    /** GET Http Request **/
    getHttpRequest(url: string) {
        // debugger
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');
        return self.http.get(url , {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
    }

    //************** HERE We do the default(Must Reusable) callback methods  **************

     /**successResponse*/
    private successResponse(result: Response) {
        // debugger
        return result.json() || null;
    }

    /**errorResponse*/
    private errorResponse(error: Response) {
        console.log(error)
        // debugger
        return Observable.throw(error.json() || null);
    }

    /**onFinally*/
    private onFinally(): void {
        console.log('Loading....')
    }

}