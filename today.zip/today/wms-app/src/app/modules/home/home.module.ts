import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import { HomeRoutingModule } from './home-routing.module';
import { DescriptorComponent } from './component/descriptor/descriptor.component';

import { SharedModule } from '../../shared/shared/shared.module'

import { Config } from '../../config/constant';
import { HomeComponent } from './component/home/home.component';

import { DemoMaterialModule } from '../../../material-module'

import { TreeviewModule } from 'ngx-treeview';

@NgModule({
  declarations: [DescriptorComponent, HomeComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    HttpModule,
    SharedModule,
    DemoMaterialModule,

    TreeviewModule
    
  ],
  providers: [Config],
  exports: []
})
export class HomeModule { }
