import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './component/login/login.component';
import { DeviceEntryComponent } from './modules/entry/component/device-entry/device-entry.component';
import { DeviceReturnComponent } from './modules/entry/component/device-return/device-return.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'entry', component: DeviceEntryComponent },
  { path: 'return', component: DeviceReturnComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule { }
