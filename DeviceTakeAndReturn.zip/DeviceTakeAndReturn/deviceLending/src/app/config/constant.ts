
var env = require("./../../../config.json");

export class InfoEntity {
    id: number;
    info: string;
}

export class Config {
    baseURL = env.redirectURL;
    SITE_URL = env.siteURL;
    getEmployeeById ="getEmployeeById";
    getDeviceById ="getDeviceById";
    getLendingsByDeviceId ="getLendingsByDeviceId";
    postDeviceEntry ="postDeviceEntry";
    updatetDeviceEntry = "updatetDeviceEntry";
    getDeviceListByUser ="getDeviceListByUser";
    
    constructor() { }

    getBaseURL() {
        return this.baseURL;
    }
}