import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod, Request } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { Config } from '../../app/config/constant';


@Injectable()
export class HttpRequestService {
    private headers: Headers;

    constructor(private config: Config, private http: Http, private router: Router) {
        this.headers = new Headers();
    }

  
    /**
     * GET Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequest(url: string): Observable<Response> {
        this.headers.set('Content-Type', 'application/json');
        let self = this;
        const options = new RequestOptions({
            method: RequestMethod.Get,
            url: self.config.getBaseURL() + url,
            headers: this.headers
        });
         return self.http.get(self.config.getBaseURL() + url, {
            headers: self.headers
        })
    }


    /**
     * POST Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequestWithoutToken(data: string, url: string) {
        // debugger
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.post(self.config.getBaseURL() + url, data, {
            headers: self.headers
        });
    }
}