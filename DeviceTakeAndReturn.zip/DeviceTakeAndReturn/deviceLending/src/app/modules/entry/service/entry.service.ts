import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../service/http-request.service';

@Injectable()
export class EntryService {
  constructor(private httpRequestService: HttpRequestService) {
  }
 
  getSingleEmployeeService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data,url);
  }

  //get Device list by user service
  getDeviceListByEmployeeService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data,url);
  }

  getSingleDeviceService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data,url);
  }

  getSingleLendingsService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data,url);
  }

  saveDeviceEntryService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data, url);
  }

  updateDeviceEntryService(data: any, url: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data, url);
  }
}