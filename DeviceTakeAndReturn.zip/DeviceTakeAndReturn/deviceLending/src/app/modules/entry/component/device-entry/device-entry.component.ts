import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import { AppComponent } from '../../../../app.component';

import { EntryBusiness } from '../../business/entry.business';

import { Device } from '../../entity/device';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-device-entry',
  templateUrl: './device-entry.component.html',
  styleUrls: ['./device-entry.component.css']
})
@NgModule({
  imports: [ BrowserModule, FormsModule ],
  declarations: [ AppComponent ],
  bootstrap: [ AppComponent ]
})
export class DeviceEntryComponent {
  device: Device = {
    device_id: "",
    employee_id: ""
  };

  public EmpID : any;
  public EmpName : any;
  public EmpTeam : any;

  public deviceID : any;
  public deviceName : any;
  public deviceOS : any;

  public today : any;
  public dd : any;
  public mm : any;
  public yyyy : any;

  public myDevices : any;
  public myDevicesNoRecord = "none";
  public myDevicesRecord : any;

  constructor(private router: Router, private entryBusiness: EntryBusiness) { }
  // constructor(private router: Router) { }

  ngOnInit() {
  }


  getEmployeeID(empID: any, event: any){
    let empID1 = {
            'employee_id': empID
          }
      let resList = this.entryBusiness.getSingleEmployeeBusiness(empID1).subscribe(data => {
        console.log('called');
        if(data.length <= 0){
          console.log("Invalid");
        }else{
          // console.log("Success..!", data[0].employee_id);
          this.EmpID = data[0].employee_id;
          this.EmpName = data[0].employee_name;
          this.EmpTeam = data[0].employee_team;
        }
      });

      //get Device list by user component
      let devList = this.entryBusiness.getDeviceListByEmployeeBusiness(empID1).subscribe(data => {
        if(data.length <= 0){
          this.myDevicesNoRecord = 'block';
          // this.myDevicesRecord = 'none';
          this.myDevicesRecord = data.length;
        }else{
          this.myDevicesNoRecord = 'none';
          // this.myDevicesRecord = 'block';
          this.myDevicesRecord = data.length;
          this.myDevices = data;
        }
      });

  }

  getDeviceID(deviceID: any, event: any){
    let deviceID1 = {
      'device_id': deviceID
    }
    let resList = this.entryBusiness.getSingleDeviceBusiness(deviceID1).subscribe(data => {
      if(data.length <= 0){
        console.log("Invalid");
      }else{
        // console.log("Success..!", data);
        this.deviceID = data[0].device_id;
        this.deviceName = data[0].device_name;
        this.deviceOS = data[0].device_platform;
      }
    });
  }

  saveData(data: any, event: any){
    this.today = new Date();
    this.dd = this.today.getDate();
    this.mm = this.today.getMonth()+1; //January is 0!
    this.yyyy = this.today.getFullYear();
    if(this.dd<10) {
      this.dd = '0'+this.dd
    }
    if(this.mm<10) {
      this.mm = '0'+this.mm
    }
    this.today = this.mm + '/' + this.dd + '/' + this.yyyy;
    //get current time
    var d = new Date(),
      h = (d.getHours()<10?'0':'') + d.getHours(),
      m = (d.getMinutes()<10?'0':'') + d.getMinutes();
      let curTime = h + ':' + m;
      
      let saveData = {
        'date': this.today,
        'time': curTime,
        'employee_id': data.employee_id,
        'device_id': data.device_id,
        'status': '0'
      }
      //console.log(saveData);

    let resList = this.entryBusiness.saveDeviceEntryBusiness(saveData).subscribe(data => {
      console.log("Success..! ",data);
    });
  }

}
