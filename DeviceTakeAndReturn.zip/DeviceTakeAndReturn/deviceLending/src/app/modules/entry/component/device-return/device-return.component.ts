import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import { AppComponent } from '../../../../app.component';

import { Router, ActivatedRoute, Params } from '@angular/router';

import { EntryBusiness } from '../../business/entry.business';
import { Device } from '../../entity/device';

@Component({
  selector: 'app-device-return',
  templateUrl: './device-return.component.html',
  styleUrls: ['./device-return.component.css']
})
export class DeviceReturnComponent implements OnInit {

  device: Device = {
    device_id: "",
    employee_id: ""
  };

  public date : any;
  public time : any;
  public employee_id : any;
  public device_id : any;
  public status : any;

  constructor(private router: Router, private entryBusiness: EntryBusiness) { }

  ngOnInit() {
  }

  getLendingDeviceID(deviceID: any, event: any){
    let deviceID1 = {
      'device_id': deviceID
    }
    let resList = this.entryBusiness.getSingleLendingsBusiness(deviceID1).subscribe(data => {
      if(data.length <= 0){
        console.log("Invalid");
      }else{
        // console.log("Success..!", data);
        this.date = data[0].date;
        this.time = data[0].time;
        this.employee_id = data[0].employee_id;
        this.device_id = data[0].device_id;
        // this.status = data[0].status;
        if(data[0].status == 0){
          this.status = "Not Return";
        }else{
          this.status = "Already Returned";
        }
      }
    });
  }
  
  returnDevice(device: any, event: any){
    let updateData = {
      'device_id': device,
      'status': '1'
    }
    let resList = this.entryBusiness.updateDeviceEntryBusiness(updateData).subscribe(data => {
      console.log("Success..! ",data);
    });
  }

}
