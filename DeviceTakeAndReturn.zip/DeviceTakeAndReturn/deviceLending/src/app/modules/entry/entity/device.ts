export class Device {  
    device_id: string;
    employee_id: string;
  }