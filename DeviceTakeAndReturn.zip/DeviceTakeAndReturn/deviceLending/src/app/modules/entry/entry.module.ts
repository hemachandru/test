import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';

import { Config } from '../../config/constant';

import { EntryBusiness } from "../entry/business/entry.business";
import { EntryService } from "../entry/service/entry.service";
import { HttpRequestService } from '../../service/http-request.service';

import { DeviceEntryComponent } from './component/device-entry/device-entry.component';
import { DeviceReturnComponent } from './component/device-return/device-return.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [DeviceEntryComponent, DeviceReturnComponent],
  providers: [
    EntryBusiness,
        HttpRequestService,
        Config,
        EntryService
  ]
})
export class EntryModule { }
