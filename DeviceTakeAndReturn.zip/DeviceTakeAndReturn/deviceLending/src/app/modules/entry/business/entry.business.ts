import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { EntryService } from '../service/entry.service';
import { Config } from '../../../config/constant';

@Injectable()
export class EntryBusiness {
  constructor(private config: Config, private entryService: EntryService, private router: Router) {
  }
  
  getSingleEmployeeBusiness(data: any){
    let url = this.config.getEmployeeById;
    return this.entryService.getSingleEmployeeService(data,url).map(res => res.json());
  }

  //get Device list by user business
  getDeviceListByEmployeeBusiness(data: any){
    let url = this.config.getDeviceListByUser;
    return this.entryService.getDeviceListByEmployeeService(data,url).map(res => res.json());
  }

  getSingleDeviceBusiness(data: any){
    let url = this.config.getDeviceById;
    return this.entryService.getSingleDeviceService(data,url).map(res => res.json());
  }

  getSingleLendingsBusiness(data: any){
    let url = this.config.getLendingsByDeviceId;
    return this.entryService.getSingleLendingsService(data,url).map(res => res.json());
  }

  saveDeviceEntryBusiness(data: any){
    let url = this.config.postDeviceEntry;
    return this.entryService.saveDeviceEntryService(data, url).map(res => res.json());
  }

  updateDeviceEntryBusiness(data: any){
    let url = this.config.updatetDeviceEntry;
    return this.entryService.updateDeviceEntryService(data, url).map(res => res.json());
  }

}