import { DeviceLendingPage } from './app.po';

describe('device-lending App', function() {
  let page: DeviceLendingPage;

  beforeEach(() => {
    page = new DeviceLendingPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
