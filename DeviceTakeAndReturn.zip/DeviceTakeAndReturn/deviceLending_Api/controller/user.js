var user = require('../service/user');

module.exports = {
    GetUser: function (router) {
       router.get('/getuser', function (req, res,next) {
            user.GetUserDetial(req, res);
        });
    },    
}