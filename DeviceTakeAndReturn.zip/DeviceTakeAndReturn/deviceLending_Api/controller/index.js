const auth = require("./auth");
const user = require("./user");

module.exports = {
    auth: auth,
    user: user
}