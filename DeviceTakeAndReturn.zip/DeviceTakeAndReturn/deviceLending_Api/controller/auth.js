const service = require("../service/index");

class AuthController extends service {
    constructor() {
        super()
    }    

    get Login() {
        return this.auth.Login;
    }
}

module.exports = new AuthController();