module.exports = {
    Configuration:"mysql://root@localhost/devicelending"
}