var express = require('express');
var app = express();

var bodyParser = require('body-parser');

var routers = require('./router/index');
var modules = require('./modules/user');
var configs = require('./config/config');

var router = express.Router();
var cors = require('cors');


// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse application/json
app.use(bodyParser.json());
app.use(modules.UserModel);

app.use(cors());
app.options('*', cors());
    routers.apiRouters(router);

app.use('/', router);



app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});