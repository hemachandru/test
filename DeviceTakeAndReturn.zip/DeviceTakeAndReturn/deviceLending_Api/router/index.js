var user = require('../controller/user');

module.exports = {
    apiRouters: function (router) {
        user.GetUser(router);
    },
}