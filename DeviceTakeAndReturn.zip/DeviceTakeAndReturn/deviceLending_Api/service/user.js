var userModule = require('../modules/user');

module.exports = {
    GetUserDetial: function (req, res, next) {
        req.models.user.find({}, function (err, results) {
            if (err) return next(err);            
            return res.send(results);
        });
    },
}