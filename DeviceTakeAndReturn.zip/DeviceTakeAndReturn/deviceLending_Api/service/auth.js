class AuthService {
        constructor() {
    
        }
    
         GetLogin(data, cb) {
            let self = this;
            return cb("data");
         }
    
         get Login() {
              let self = this;
             self.GetLogin("data", function (userData) {
                res.send("data");
             })
         }
    
         static bootstrap() {
            return new AuthService();
        }
    
    }
    
    module.exports = AuthService;