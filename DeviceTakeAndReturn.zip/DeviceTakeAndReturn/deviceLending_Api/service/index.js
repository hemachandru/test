// const DB = require("../models/db");

const auth = require("./auth");
const user = require("./user");

class Service {
    constructor() {
        // super();
        this.auth = auth.bootstrap();
        this.user = user.bootstrap();
    }

    static bootstrap() {
        return new Service();
    }
}

module.exports = Service;