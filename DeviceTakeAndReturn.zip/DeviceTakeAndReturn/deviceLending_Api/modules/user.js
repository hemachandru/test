var orm= require("orm");
var con = require('../config/config');

module.exports = {
    UserModel: orm.express(con.Configuration, {
        define: function (db, models, next) {  
            //End User Table definition
            models.user = db.define("user", {  
                User_name:String,
                Password:String,
                Team_id:Number,
            });          
            next();   
        }
    })
}