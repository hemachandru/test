var express = require('express');
var app = express();
var nodemailer = require("nodemailer");
var bodyParser = require('body-parser');
var routers = require('./app/router/routers');
var modules = require('./app/modules/user');
var configs = require('./app/config/config');
var router = express.Router();
var cors = require('cors');
var multer  =   require('multer');


// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
// parse application/json
app.use(bodyParser.json());
app.use(modules.UserModel);
app.use(express.static('uploads'));
app.use(cors());
app.options('*', cors());
    routers.apiRouters(router);

app.use('/', router);



app.listen(3018, function () {
  console.log('Example app listening on port 3018!');
});