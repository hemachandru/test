var userModule = require('../modules/sub_categries');
var moment = require("moment");

module.exports = {
    GetSubCategriesDetial: function (req, res) {
         req.models.sub_categries.find({},function(err, results) {
            return res.send(results);
        });
    },
    AddSubCategriesDetial: function (req, res) {
         var now = moment(new Date());
       req.models.sub_categries.aggregate({}).min("Sub_categries_id").max("Sub_categries_id").get(function (err, min, max) {
            var sub_categri_id=max+1;
            var sub_categri_name=req.body.sub_categri_name;
                var categri_id=req.body.categri_id;
            var created_name=req.body.created_name;
            var created_date=now.format("YYYY-MM-DD");
            var modified_name=req.body.created_name;
            var modified_date=now.format("YYYY-MM-DD");
            var is_act=1;
            req.models.sub_categries.create({Sub_cat_name:sub_categri_name,Categries_id:categri_id,Created_by:created_name,Created_date:created_date,Modified_by:modified_name,Modified_date:modified_date,Is_active:is_act,Sub_categries_id:sub_categri_id},function(err){            
                if(err) throw err;
                    res.send("Submited Successfully");
            });
        });     
    },
    DeleteSubCategriesDetial: function (req, res) {
        var sub_categries_id = req.body.sub_categries_id;
        req.models.sub_categries.find({Sub_Categries_id:sub_categries_id }).remove(function (err){
        return res.send("Deleted Successfully");
        });
    },
    ParticularSubCategriesDetial:function(req,res){
        var categries_id = req.body.categries_id;
         req.models.sub_categries.find({Categries_id:categries_id},function(err, results) {
            return res.send(results);
        });
    },
}