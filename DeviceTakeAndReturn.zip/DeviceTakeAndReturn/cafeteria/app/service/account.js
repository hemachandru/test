var userModule = require('../modules/account');
//var con = require('../config/config');
var moment = require("moment");
var twilio = require('twilio'),
client = twilio('AC9c48ae1306ded45266b729816c72edef', '255a0e61d73c190fd839aca78ac98ddf');

module.exports = {
    GetAccountDetial: function (req, res) {
        req.models.account.find({Deliver_status:0},function(err, results) {
            return res.send(results);
        });
    },
    GetAccountlistDetial: function (req, res) {       
        req.models.account.find({},function(err, results) {
            return res.send(results);
     });
    },
      GetmonthlylistDetial: function (req, res) {
        var user_id=req.body.userid;    
            req.models.account.find({User_id:user_id},function(err, results) {
                return res.send(results);
        });
    },
    GetpaymentlistDetial: function (req, res) {
        //var userid=req.body.user_id;
         req.models.account.aggregate(["User_id"],{}).sum("Total_amt").groupBy("User_id").get(function (err, stats) {
                res.send(stats);
        });
    },   
    
    //******************************************************** 
    GetfilterpaymentlistDetial: function (req, res) {
        var dateid=req.body.Items_date;
       // var user=req.body.user_id;       
       //console.log("hai");
         //var now = moment(new Date()); 
         //var created_date=dateid.format("MM"); 
         req.models.account.aggregate(["User_id"],{Month:dateid}).sum("Total_amt").groupBy("User_id").get(function (err, stats) {
                res.send(stats);
        });
    }, 
    
    //**************************************
    AddAccountDetial: function (req, res) {
      req.models.account.aggregate({}).min("Order_id").max("Order_id").get(function (err, min, max) {
            var order_id=max+1;
            var now = moment(new Date());            
            var user_id=req.body.user_id;
            var total_amt=req.body.total_amt;
            var balance=req.body.balance;
            var paid_amt=req.body.paid_amt;
            var paid_status=req.body.paid_status;
            var paid_mod=req.body.paid_mod;
            var created_name=req.body.created_name;
            var created_date=now.format("YYYY-MM-DD");
            var month=now.format("MM");
            var modified_name=req.body.modified_name;
            var modified_date= now.format("YYYY-MM-DD");
            var is_act=req.body.is_act;
            req.models.account.create({Order_id:order_id,User_id:user_id,Total_amt:total_amt,Balance:balance,Paid_amt:paid_amt,Paid_status:paid_status,Paid_mod:paid_mod,Created_by:created_name,Created_date:created_date,Month:month,Modified_by:modified_name,Modified_date:modified_date,Is_active:is_act},function(err){
                if(err) throw err;
                    res.send("Submited Successfully");
            });
        });    
    },
    DeleteAccountDetial: function (req, res) {
        var order_id = req.body.order_id;
        req.models.account.find({Order_id:order_id }).remove(function (err){
        return res.send("Deleted Successfully");
        });
    },
     UpdatedeliverDetial: function (req, res) {
        var order_id = req.body.orderid;        
        req.models.account.find({ Order_id: order_id }).each(function (person) {
            person.Deliver_status = 1;
        }).save(function (err) {
            req.models.order.find({ Order_id: order_id }).each(function (person) {
            person.Delivery_mod = 1;
            }).save(function (err) {               
                return res.send("Updated Successfully");
            });
        });        
    },
    SendSmsDetails:function(req,res){
       // var user_id=re.body.userid;
       client.sendMessage({
                to:'+919500661719',
                from:'+18454069812',
                body:'Your Order has been Ready so come and get soon'
            },function(err,data){
                if(err)
                console.log(err);
                console.log(data);
            });
    }      
}