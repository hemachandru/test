var userModule = require('../modules/special');
var userModules = require('../modules/team');
var multer = require('multer');
var moment = require("moment");
var http = require('http')
    , fs = require('fs');
module.exports = {
    GetItemsspecialDetial: function (req, res) {
        req.models.special.find({}, function (err, results) {
            return res.send(results);
        });
        // req.models.special.find({}, function (err, results) {
        //     return res.send(results);            
        // });
    },
    AddItemsspecialDetial: function (req, res) {
        console.log("ahdflksfj");
        var now = moment(new Date());
        var item_name = req.body.item_name;
        var cost = req.body.cost;
        var quantity = req.body.quantity;
        var created_name = req.body.created_name;
        var created_date = now.format("YYYY-MM-DD");
        var modified_name = req.body.created_name;
        var modified_date = now.format("YYYY-MM-DD");
        
         req.models.special.create({Item_name:item_name,Cost: cost, Quantity: quantity,Created_by:created_name,Created_date:created_date,Modified_by:modified_name,Modified_date:modified_date},function(err){
                if(err) throw err;
                    res.send("Submited Successfully");
            });
        // req.models.special.create({ Item_name: item_name, Cost: cost, Quantity: quantity, Created_by: created_name, Created_date: created_date, Modified_by: modified_name, Modified_date: modified_date }, function (err) {
        //     //if (err) throw err;
        //     res.send("Submited Successfully");
        // });
        console.log("ads");
    },
    DeleteItemsspecialDetial: function (req, res) {
        var item_id = req.body.item_id;
        req.models.special.find({ Item_id: item_id }).remove(function (err) {
            return res.send("Deleted Successfully");
        });
    }
}