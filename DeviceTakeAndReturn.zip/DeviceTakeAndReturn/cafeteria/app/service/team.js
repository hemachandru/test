var userModule = require('../modules/team');
var moment = require("moment");

module.exports = {
    GetTeamDetial: function (req, res) {
        req.models.team.find({}, function (err, results) {
            return res.send(results);
        });
    },
    AddTeamDetial: function (req, res) {
        var now = moment(new Date());
       req.models.team.aggregate({}).min("Team_id").max("Team_id").get(function (err, min, max) {
            var team_id = max + 1;
            var team_name = req.body.team_name;
            var created_name = req.body.created_name;
            var created_date = now.format("YYYY-MM-DD");
            var modified_name = req.body.modified_name;
            var modified_date = now.format("YYYY-MM-DD");
            var is_act = req.body.is_act;
            req.models.team.create({ Team_name: team_name, Created_by: created_name, Created_date: created_date, Modified_by: modified_name, Modified_date: modified_date, Is_active: is_act, Team_id: team_id }, function (err) {

                if (err) throw err;
                res.send("Submited Successfully");
            });
        });
    },
    DeleteTeamDetial: function (req, res) {
        var name_id = req.body.name_id;
        //var name = req.body.name;
        req.models.team.find({ team_id: name_id }).remove(function (err) {
            return res.send("Deleted Successfully");
        });
    },
    UpdateTeamDetial: function (req, res) {
        var team_id = req.body.team_id;
        var team_name = req.body.team_naem;
        req.models.team.find({ Team_id: team_id }).each(function (person) {
            person.Team_name = team_name;
        }).save(function (err) {
            return res.send("Updated Successfully");
        });
    },
}