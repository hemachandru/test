var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var multer = require('multer');

/** Serving from the same express Server
No cors required */
app.use(express.static('../client'));
app.use(bodyParser.json());
 var imgfilename=null;
var storage = multer.diskStorage({ //multers disk storage settings
    destination: function (req, file, cb,res) {
        cb(null, './uploads/')
    },
    filename: function (req, file, cb,res) {
        var datetimestamp = Date.now();
      imgfilename=file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1];
        //cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
    cb(null,imgfilename)
   // return imgfilename;
    //res.send(imgfilename);
    }
});
//console.log(storage.filename())

var upload = multer({ //multer settings
    storage: storage
}).single('file');
//console.log(upload());
/** API path that will upload the files */
app.post('/upload', function (req, res) {
    upload(req, res, function (err) {
        if (err) {
            res.json({ error_code: 1, err_desc: err });
            return;
        }
        res.json({ error_code: 0, err_desc: imgfilename });
    })
});


app.listen('3002', function () {
    console.log('running on 3002...');
});