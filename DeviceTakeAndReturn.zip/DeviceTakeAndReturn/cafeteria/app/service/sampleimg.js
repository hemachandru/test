var http = require('http')
  , fs = require('fs');

fs.readFile('uploads/items/file-1455175948164.jpg', function(err, data) {
  if (err) throw err; // Fail if the file can't be read.
  
  
});