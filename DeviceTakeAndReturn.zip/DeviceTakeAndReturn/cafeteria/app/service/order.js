/* global outputJSON */
var userModule = require('../modules/order');
var moment = require("moment");
var user = require('../modules/user');
 

module.exports = {
    GetOrderDetial: function (req, res) {
        var user_id=req.body.userid;
        
        // req.models.account.find({User_id:user_id},function(err,result){
        //     console.log("asds"+Object.keys(result).length);
        //     var count=Object.keys(result).length;
        //   
        //     for(var i = 0; i<count; i++){
        //        
        //         var orderid=result[i].Order_id;
               req.models.order.find({USer_id:user_id},"Date",function(err, results) {
                  // state.userorder=(results);
                    return res.send(results); 
                   // console.log(results);
                   // console.log(data);
                }); 
        //     }
        //     //return res.send(result); 
        //     //console.log("asd"+state.userorder);
        //     // req.models.order.find({},function(err, results) {
        //     //     return res.send(results);   
        //     // });
        // });
    }, 
     ViewOrdermonthDetial: function (req, res) {
        var user_id=req.body.userid;
        var dateid=req.body.Items_date;
        req.models.order.find({User_id:user_id,Month:dateid},function(err, results) {            
        return res.send(results);
        });
    },
    ViewOrderDetial: function (req, res) {
        var order_id = req.body.orderid;
        req.models.order.find({Order_id:order_id },function(err, results) {
        return res.send(results);
        });
    },
    DeleteOrderDetial: function (req, res) {
        var order_id = req.body.order_id;
        req.models.order.find({Order_id:order_id }).remove(function (err){
        return res.send("Deleted Successfully");
        });
    },
    AddOrderDetial: function(req,res)
    {  
        var now = moment(new Date());
        var order=req.body.orderuser;
        var count=Object.keys(order).length;
        var time=now.format("HH-mm");        
        var user_id=req.body.userid;        
        req.models.user.find({User_id:user_id},function(err, results) {
           var user_name=results[0].User_name;
           req.models.account.aggregate({}).min("Order_id").max("Order_id").get(function (err, min, max) {
                var order_id=max+1;                 
                var total_amt=req.body.total_amt;
                var balance=req.body.total_amt;
                var paid_amt=0;
                var paid_status="No";
                var paid_mod="Salary Account";
                var deliver_status=0;
                var created_name=user_name;
                var created_date=now.format("YYYY-MM-DD");
                var month=now.format("MM");
                var modified_name=user_name;
                var modified_date=now.format("YYYY-MM-DD");
                var is_act=1;
                req.models.account.create({Order_id:order_id,User_id:user_id,Total_amt:total_amt,Balance:balance,Paid_amt:paid_amt,Paid_status:paid_status,Paid_mod:paid_mod,Deliver_status:deliver_status,Time:time,Created_by:created_name,Created_date:created_date,Month:month,Modified_by:modified_name,Modified_date:modified_date,Is_active:is_act},function(err){
                    if(err) throw err;                        
            for(var i = 0; i<count; i++)
            {   
                    var orderitem=order[i].itemData;
                    var items_id=orderitem.Item_id;
                    var items_name=orderitem.Item_name
                    var quantity=order[i].count;
                    var created_date=now.format("YYYY-MM-DD");
                    var cost=orderitem.Cost;
                    var created_by=user_name;                    
                    var delivery_mod=0;
                    var is_act=1;
                    if(quantity>0)
                    {
                    req.models.order.create({Order_id:order_id,Items_id:items_id,Items_name:items_name,Quantity:quantity,Date:created_date,Month:month,Time:time,Cost:cost,User_id:user_id,Total_amt:total_amt,Delivery_mod:delivery_mod,Created_by:created_by,Created_date:created_date,Modified_by:created_by,Modified_date:created_date,Is_active:is_act},function(err){          
                         if(err) throw err;                         
                    });
                    }
              }
                    res.send("Order Booked Successfully");
                });
            });
      });           
    }
}
