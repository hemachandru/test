var userModule = require('../modules/sps');
var moment = require("moment");

module.exports = {
    GetspsDetial: function (req, res) {
        req.models.sps.find({}, function (err, results) {
            return res.send(results);
        });
    },
     AddspsDetial: function (req, res) { 
         var now = moment(new Date());
        var item_name = req.body.item_name;
        var cost = req.body.cost;
        var quantity = req.body.quantity;
        var created_name = req.body.created_name;
        var created_date =now.format("YYYY-MM-DD");
        req.models.sps.create({ Items_name: item_name,Cost:cost,Quantity:quantity,Created_by: created_name, Created_at: created_date}, function (err) {
                if (err) throw err;
                res.send("Submited Successfully");
            });       
        console.log("fhgdsj");
        // req.models.team.aggregate({}).min("Team_id").max("Team_id").get(function (err, min, max) {
        //     var team_id = max + 1;
        //     var team_name = req.body.team_name;
        //     var created_name = req.body.created_name;
        //     var created_date = now.format("YYYY-MM-DD");
        //     var modified_name = req.body.modified_name;
        //     var modified_date = now.format("YYYY-MM-DD");
        //     var is_act = req.body.is_act;
        //     req.models.team.create({ Team_name: team_name, Created_by: created_name, Created_date: created_date, Modified_by: modified_name, Modified_date: modified_date, Is_active: is_act, Team_id: team_id }, function (err) {

        //         if (err) throw err;
        //         res.send("Submited Successfully");
        //     });
        // });
        //  req.models.sps.create({Items_name:item_name,Cost: cost, Quantity: quantity,Created_by:created_name,Created_date:created_date},function(err,result){
        //         //if(err) throw err;
        //             res.send("Submited Successfully"+result);
        //     });
     },
}