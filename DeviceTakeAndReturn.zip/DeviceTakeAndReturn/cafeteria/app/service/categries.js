var userModule = require('../modules/categries');
var moment = require("moment");

module.exports = {
    GetCategriesDetial: function (req, res) {
        req.models.categries.find({},function(err, results) {
        return res.send(results);
        });
    },
    AddCategriesDetial: function (req, res) {
         var now = moment(new Date());
       // req.models.categries.count({}, function (err, count) {
           req.models.categries.aggregate({}).min("Categries_id").max("Categries_id").get(function (err, min, max) {
            var categri_id=max+1;
            var categri_name=req.body.categri_name;
            var created_name=req.body.created_name;
            var created_date=now.format("YYYY-MM-DD");
            var modified_name=req.body.created_name;
            var modified_date=now.format("YYYY-MM-DD");
            var is_act=1;
            req.models.categries.create({Categries_name:categri_name,Created_by:created_name,Created_date:created_date,Modified_by:modified_name,Modified_date:modified_date,Is_active:is_act,Categries_id:categri_id},function(err){
                if(err) throw err;
                    res.send("Submited Successfully");
            });
        });  
    },
    DeleteCategriesDetial: function (req, res) {
        var categries_id = req.body.categries_id;
        req.models.categries.find({Categries_id:categries_id }).remove(function (err){
        return res.send("Deleted Successfully");
        });
    },
}