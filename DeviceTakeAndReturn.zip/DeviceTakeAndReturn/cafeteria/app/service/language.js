var userModule = require('../modules/language');


module.exports = {
    GetLanguageDetial: function (req, res) {
        req.models.language.find({},function(err, results) {
            return res.send(results);
        });
    },
    AddLanguageDetial: function (req, res) {
       req.models.language.count({}, function (err, count) {
            var order_id=count+1;
            var user_id=req.body.user_id;
            var total_amt=req.body.total_amt;
            var balance=req.body.balance;
            var paid_amt=req.body.paid_amt;
            var paid_status=req.body.paid_status;
            var paid_mod=req.body.paid_mod;
            var created_name=req.body.created_name;
            var created_date=req.body.created_date;
            var modified_name=req.body.modified_name;
            var modified_date=req.body.modified_date;
            var is_act=req.body.is_act;
            req.models.account.create({Order_id:order_id,User_id:user_id,Total_amt:total_amt,Balance:balance,Paid_amt:paid_amt,Paid_status:paid_status,Paid_mod:paid_mod,Created_by:created_name,Created_date:created_date,Modified_by:modified_name,Modified_date:modified_date,Is_active:is_act},function(err){
                if(err) throw err;
                    res.send("Submited Successfully");
            });
        });    
    },
    DeleteLanguageDetial: function (req, res) {
        var order_id = req.body.order_id;
        req.models.language.find({Order_id:order_id }).remove(function (err){
        return res.send("Deleted Successfully");
        });
    },
}