var userModule = require('../modules/user');
var forgot = require('../modules/forgotpwd');
var multer = require('multer');
var moment = require("moment");
var uuid = require('node-uuid');

module.exports = {
    GetUserDetial: function (req, res, next) {
        req.models.user.find({}, function (err, results) {
            if (err) return next(err);            
            return res.send(results);
        });
    },
    GetProfileDetial: function (req, res, next) {
        var user_id = req.body.userid;
        req.models.user.find({ User_id: user_id }, function (err, results) {
            if (err) return next(err);
            return res.send(results);
        });
    },
    AddUserDetial: function (req, res) {
        var now = moment(new Date());
        var user_name = req.body.user_name;
        var user_pwd = req.body.user_pwd;
        var team_id = req.body.team_id;
        var sys_no = req.body.sys_no;
        var intercom_no = req.body.intercom_no;
        var address = req.body.address;
        var mb_no = req.body.mb_no;
        var mail_id = req.body.mail_id;
        var images = req.body.images;
        var uuid1 = uuid.v4();
        var created_name = req.body.user_name;
        var created_date = now.format("YYYY-MM-DD");
        var modified_name = req.body.user_name;
        var modified_date = now.format("YYYY-MM-DD");
        var is_act = 1;
        var user_type = req.body.user_type;
        var user_id = req.body.user_id;
        req.models.user.create({ User_name: user_name, Password: user_pwd, Team_id: team_id, System_no: sys_no, Intercom_no: intercom_no, Address: address, Mobile_no: mb_no, Email_id: mail_id, Image: images, Uuid: uuid1, Created_by: created_name, Created_date: created_date, Modified_by: modified_name, Modified_date: modified_date, Is_active: is_act, User_type: user_type, User_id: user_id }, function (err) {
            if (err) throw err;
            res.send("Submited Successfully");
        });
    },
    DeleteUserDetial: function (req, res) {
        var user_id = req.body.user_id;
        req.models.user.find({ User_id: user_id }).remove(function (err) {
            return res.send("Deleted Successfully");
        });
    },
    LoginUserDetial: function (req, res) {
        var user_id = req.body.userid;
        var user_pwd = req.body.password;
        if (user_id == "" && user_pwd == "") {
            return res.send("Please Enter Your User id and Password");
        }
        else {
            if (user_id == "") {
                return res.send("Please Enter Your User id");
            }
            else {
                if (user_pwd == "") {
                    return res.send("Please Enter Your Password");
                }
                else {
                    req.models.user.find({ User_id: user_id, Password: user_pwd }, function (err, results) {
                        if (err) throw err;
                        if (results == "") {
                            return res.send("invalid user name and password");
                        }
                        else {
                            return res.send("1," + results[0].Image + "," + results[0].User_name);
                        }
                    });
                }
            }
        }
    },
    UserProfileDetial: function (req, res, next) {
        var imgfilename = null;
        var storage = multer.diskStorage({ //multers disk storage settings
            destination: function (req, file, cb, res) {
                cb(null, './uploads/user/')
            },
            filename: function (req, file, cb, res) {
                var datetimestamp = Date.now();
                imgfilename = file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1];
                cb(null, imgfilename)
            }
        });
        var upload = multer({ //multer settings
            storage: storage
        }).single('file');
        upload(req, res, function (err) {
            if (err) {
                res.json({ error_code: 1, err_desc: err });
                return;
            }
            res.json({ error_code: 0, err_desc: imgfilename });
        })
    },
    UpdateProfileDetial: function (req, res, next) {
        var imgfilename = null;
        var storage = multer.diskStorage({ //multers disk storage settings
            destination: function (req, file, cb, res) {
                cb(null, './uploads/user/')
            },
            filename: function (req, file, cb, res) {
                var datetimestamp = Date.now();
                imgfilename = file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1];
                cb(null, imgfilename)
            }
        });
        var upload = multer({ //multer settings
            storage: storage
        }).single('file');
        upload(req, res, function (err) {
            if (err) {
                res.json({ error_code: 1, err_desc: err });
                return;
            }
            req.models.user.find({ User_id: req.body.userid }).each(function (person) {
                person.Image = imgfilename;
            }).save(function (err) {
                res.json({ error_code: 0, err_desc: imgfilename });
                // return res.send(1);
            });

        })
    },
    ForgotPwdDetial: function (req, res, next) {
        var mail_id = req.body.mail_id;
        if (mail_id == "") {
            return res.send("Please Enter Your Mail id");
        }
        else {
            req.models.user.find({ Email_id: mail_id }, function (err, results) {
                if (err) throw err;
                mail_id="punithaboopathy5@gmail.com,punitha.punibca@gmail.com";
                /*------------------SMTP Over-----------------------------*/
                /*------------------Routing Started ------------------------*/
                var mailOptions = {
                    to: mail_id,
                    subject: "Verification mail",
                    text: "  Please click this link  http://localhost/design/cafeteria/dist/index1.html#/change/?code=" + results[0].Uuid
                }
                console.log(mailOptions);
                forgot.smtpTransport.sendMail(mailOptions, function (error, response) {
                    if (error) {
                        console.log(error);
                        res.end("error");
                    } else {
                        console.log("Message sent: " + response.message);
                        res.end("Mail has been sent please open and check it");
                    }
                });
            });
        }
    },
    ChangePwdDetial: function (req, res, next) {
        var user_cpwd = req.body.user_cpwd;
        var user_pwd = req.body.user_pwd;
        var uniqcode = req.body.code;
        if (user_pwd == "") {
            return res.send("Please enter password");
        }
        if (user_cpwd == "") {
            return res.send("Please enter conformation password");
        }
        else {
            if (user_cpwd != user_pwd) {
                return res.send("Missmatch Password");
            }
            else {
                req.models.user.find({ Uuid: uniqcode.code }).each(function (person) {
                    person.Password = user_cpwd;
                }).save(function (err) {
                    return res.send(1);
                });
            }
        }
    },
    EditPwdDetial: function (req, res, next) {
        var user_cpwd = req.body.user_cpwd;
        var user_pwd = req.body.user_pwd;
        var user_id = req.body.userid;
        if (user_pwd == "") {
            return res.send("Please enter password");
        }
        if (user_cpwd == "") {
            return res.send("Please enter conformation password");
        }
        else {
            if (user_cpwd != user_pwd) {
                return res.send("Missmatch Password");
            }
            else {
                req.models.user.find({ User_id: user_id }).each(function (person) {
                    person.Password = user_cpwd;
                }).save(function (err) {
                    return res.send(1);
                });
            }
        }
    },
    UserUpdateDetial: function (req, res, next) {
        var now = moment(new Date());
        var user_name = req.body.username;
        var team_id = req.body.teamid;
        var sys_no = req.body.sysno;
        var inter_com = req.body.intercom;
        var address = req.body.address;
        var mb_no = req.body.mbno;
        var email = req.body.email;
        var user_id = req.body.userid;
        req.models.user.find({ User_id: user_id }).each(function (person) {
            person.User_name = user_name;
            person.Team_id = team_id;
            person.System_no = sys_no;
            person.Intercom_no = inter_com;
            person.Address = address;
            person.Mobile_no = mb_no;
            person.Email_id = email;
            person.Modified_by=user_name;
            person.	Modified_date=now.format("YYYY-MM-DD");
        }).save(function (err) {
            return res.send("Your information has been changed successfully");
        });
    },
}