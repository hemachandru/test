var userModule = require('../modules/items_list');
var multer = require('multer');
var moment = require("moment");
var http = require('http')
    , fs = require('fs');

module.exports = {
    GetItemsDetial: function (req, res) {
        req.models.items_list.find({},"Sub_categries_id", function (err, results) {
            return res.send(results);
        });
    },
    AddItemsDetial: function (req, res) {
        var now = moment(new Date());
        req.models.items_list.aggregate({}).min("Item_id").max("Item_id").get(function (err, min, max) {
            var item_id = max + 1;
            var item_name = req.body.item_name;
            var categries_id = req.body.categries_id;
            var sub_categries_id = req.body.sub_categries_id;
            var cost = req.body.cost;
            var quantity = req.body.quantity;
            var available_statu = req.body.available_status;
            var img = req.body.image;
            var created_name = req.body.created_name;
            var created_date = now.format("YYYY-MM-DD");
            var modified_name = req.body.created_name;
            var modified_date = now.format("YYYY-MM-DD");
            var is_act = 1;
            req.models.items_list.create({ Item_id: item_id, Item_name: item_name, Categries_id: categries_id, Sub_categries_id: sub_categries_id, Cost: cost, Quantity: quantity, Available_status: available_statu, Image: img, Created_by: created_name, Created_date: created_date, Modified_by: modified_name, Modified_date: modified_date, Is_active: is_act }, function (err) {

                if (err) throw err;
                res.send("Submited Successfully");
            });
        });
    },
    DeleteItemsDetial: function (req, res) {
        var item_id = req.body.item_id;
        req.models.items_list.find({ Item_id: item_id }).remove(function (err) {
            return res.send("Deleted Successfully");
        });
    },
    ImageItemsDetial: function (req, res, next) {
        var imgfilename = null;
        var storage = multer.diskStorage({ //multers disk storage settings
            destination: function (req, file, cb, res) {
                cb(null, './uploads/items/')
            },
            filename: function (req, file, cb, res) {
                var datetimestamp = Date.now();
                imgfilename = file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1];
                cb(null, imgfilename)
            }
        });
        var upload = multer({ //multer settings
            storage: storage
        }).single('file');
        upload(req, res, function (err) {
            if (err) {
                res.json({ error_code: 1, err_desc: err });
                return;
            }
            res.json({ error_code: 0, err_desc: imgfilename });
        })
    },
    ImageGetDetial: function (req, res, next) {
        var sub_categries_id = req.body.sub_categries_id;
        //var categries_id = req.body.categries_id;        
        req.models.items_list.find({ Sub_categries_id: sub_categries_id }, function (err, results) {
            return res.send(results);
        });
    },
    EditItemsDetial: function (req, res, next) {
        var items_id = req.body.Items_id;
        var available_status = req.body.available_status;
        var now = moment(new Date());
        var modified_name = "admin";
        var modified_date = now.format("YYYY-MM-DD");
        if(available_status==1 || available_status==true)
        {
         req.models.items_list.find({ Item_id: items_id }).each(function (person) {
            person.Available_status = 0;
            person.Modified_by =modified_name;
            person.Modified_date = modified_date;            
        }).save(function (err) {
            return res.sendStatus(1);
        });   
        }
        else{
             req.models.items_list.find({ Item_id: items_id }).each(function (person) {
            person.Available_status = 1;
            person.Modified_by =modified_name;
            person.Modified_date = modified_date;            
        }).save(function (err) {
            return res.sendStatus(1);
        }); 
        }        
    },
    EditAmtDetial: function (req, res, next) {
        var items_id = req.body.Items_id;
        var cost = req.body.cost;
        var now = moment(new Date());
        var modified_name = "admin";
        var modified_date = now.format("YYYY-MM-DD");

        req.models.items_list.find({ Item_id: items_id }).each(function (person) {
            person.Cost = cost;
            person.Modified_by = modified_name;
            person.Modified_date = modified_date;            
        }).save(function (err) {
            return res.sendStatus(1);
        });
    }
}