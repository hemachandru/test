var orm= require("orm");
var con = require('../config/config');
module.exports = {
    TeamModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
              //Team Table definition
            models.team = db.define("team", {
               // id:
                Team_name: String,
                Created_by: String,
                Created_date: Date,
                Modified_by: String,
                Modified_date: Date,
                Is_active: Number,
                Team_id: Number
            }),
            
               next();
        }
    })
}