var orm= require("orm");
var con = require('../config/config');
module.exports = {
    LanguageModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
              //Language Table definition
              models.language = db.define("language", {  
                bibliographical:String,
                terminological:String,
                alpha2:String,
                name_en:String,
                name_fr:String
              });
             next();
        }
    })
}