var orm= require("orm");
var con = require('../config/config');
module.exports = {
    OrderModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
            //Order Table definition
              models.order = db.define("order", {  
                Order_id:Number,	
                Items_id:Number,
                Items_name:String,
                Quantity:Number,	
                Date:Date,
                Month:Number,
                Time:String,
                Cost:Number,
                User_id:String,
                Total_amt:Number,	
                Delivery_mod:Number,	               
                Created_by:String,
                Created_date:Date,	
                Modified_by:String,
                Modified_date:Date,
                Is_active:Number
             });
               next();
        }
    })
}