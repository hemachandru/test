var nodemailer = require("nodemailer");
module.exports = {

smtpTransport : nodemailer.createTransport("SMTP", {
    service: "Gmail",
    auth: {
        user: "happicafeteria@gmail.com",
        pass: "cafeteria1"
    }
}),
}