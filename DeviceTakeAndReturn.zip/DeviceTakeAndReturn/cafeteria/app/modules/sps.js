var orm = require("orm");
var con = require('../config/config');
module.exports = {
    spsModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
            //Team Table definition           
            models.sps = db.define("sps", {
                Items_name: String,
                Cost:Number,
                Quantity:Number,
                Created_by:String,
                Created_at:Date
            }),
            next();
        }
    })
}