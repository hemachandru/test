/* global imgfilename */
var imgfilename=null;
var multer = require('multer');
//var uploaded=require('../controller/upload');
 
module.exports = {
    //imgfilename:'null';
     storage: multer.diskStorage({ //multers disk storage settings
        destination: function (req, file, cb) {
            cb(null, './uploads/')
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
             imgfilename=file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1];
           // cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
            cb(null,imgfilename); 
            //console.log(imgfilename);  
        }
    }),
    upload: multer({ //multer settings
        storage:this.storage
    }).single('file')

}