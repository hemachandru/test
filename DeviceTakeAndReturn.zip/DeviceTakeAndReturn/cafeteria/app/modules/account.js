var orm= require("orm");
var con = require('../config/config');
module.exports = {
    AccountModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
             //Account Table definition
             models.account = db.define("account", {   
                Order_id:Number,		
                User_id:Number,
                Total_amt:Number,
                Balance:Number,
                Paid_amt:Number,
                Paid_status:String,	
                Paid_mod:String,
                Deliver_status:Number,
                Time:String,
                Created_by:String,
                Created_date:Date,
                Month:Number,
                Modified_by:String,
                Modified_date:Date,			
                Is_active:Number 
            });
               next();
        }
    })
}