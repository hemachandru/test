var orm= require("orm");
var con = require('../config/config');
module.exports = {
    ItemsModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
             //Items_list Table definition
             models.items_list = db.define("items_list", {  
                Item_id:Number,		
                Item_name:String,	
                Categries_id:Number,			
                Sub_categries_id:Number,	
                Cost:Number,	
                Quantity:Number,		
                Available_status:Number,
                Image:String,	
                Created_by:String,
                Created_date:Date,		
                Modified_by:String,
                Modified_date:Date,
                Is_active:Number
             });
               next();
        }
    })
}