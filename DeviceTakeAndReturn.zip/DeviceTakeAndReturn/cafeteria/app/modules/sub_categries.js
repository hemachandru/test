var orm= require("orm");
var con = require('../config/config');
module.exports = {
    SubModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
             //Sub_Categries Table definition
             models.sub_categries = db.define("sub_categries", {  
                Sub_cat_name:String,		
                Categries_id:Number,		
                Created_by:String,	
                Created_date:Date,			
                Modified_by:String,
                Modified_date:Date,				
                Is_active:Number,	
                Sub_categries_id:Number
            });
            
               next();
        }
    })
}