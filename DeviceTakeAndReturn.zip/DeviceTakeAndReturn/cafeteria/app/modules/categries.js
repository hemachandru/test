var orm= require("orm");
var con = require('../config/config');
module.exports = {
    CategriesModel: orm.express(con.Configuration, {
        define: function (db, models, next) {
              //Categries Table definition
            models.categries = db.define("categries", {    
                Categries_name:String,	
                Created_by:String,		
                Created_date:Date,
                Modified_by:String,
                Modified_date:Date,		
                Is_active:Number,
                Categries_id:Number 
            });
               next();
        }
    })
}