var orm= require("orm");
var con = require('../config/config');
module.exports = {
    UserModel: orm.express(con.Configuration, {
        define: function (db, models, next) {  
            //End User Table definition
            models.user = db.define("user", {  
                User_name:String,
                Password:String,
                Team_id:Number,
                System_no:String,
                Intercom_no:Number,
                Address:String,
                Mobile_no:String,
                Email_id:String,
                Image:String,
                Uuid:String,
                Created_by:String,
                Created_date:Date,
                Modified_by:String,
                Modified_date:Date,
                Is_active:Number,
                User_type:Number,
                User_id:Number
            });          
            next();   
        }
    })
}