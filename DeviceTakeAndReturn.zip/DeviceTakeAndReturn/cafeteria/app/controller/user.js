var user = require('../service/user');

module.exports = {
    GetUser: function (router) {
       router.get('/getuser', function (req, res,next) {
            user.GetUserDetial(req, res);
        });
    },
    GetProfile: function (router) {
       router.post('/getprofile', function (req, res,next) {
            user.GetProfileDetial(req, res);
        });
    },
    AddUser:function (router) {
        router.post('/adduser', function (req, res,next) {
            user.AddUserDetial(req, res);
        });
    },
     DeleteUser:function (router) {
        router.post('/deleteuser', function (req, res,next) {
            user.DeleteUserDetial(req, res);
        });
    },
    LoginUser:function (router) {
        router.post('/loginuser',function (req, res, next) {
            user.LoginUserDetial(req, res);
        });
    },
    UserProfile:function (router) {
        router.post('/upload',function (req, res, next) {
            user.UserProfileDetial(req, res); 
        });
    },
    UpdateProfile:function (router) {
        router.post('/updateimg',function (req, res, next) {
            user.UpdateProfileDetial(req, res); 
        });
    },    
    ForgotPwd:function (router) {
        router.post('/forgotpwd',function (req, res, next) {
            user.ForgotPwdDetial(req, res); 
        });
    },
    ChangePwd:function (router) {
        router.post('/changepwd',function (req, res, next) {
            user.ChangePwdDetial(req, res); 
        });
    },
    EditPwd:function (router) {
        router.post('/editpwd',function (req, res, next) {
            user.EditPwdDetial(req, res); 
        });
    },
    UserUpdate:function (router) {
        router.post('/userupdate',function (req, res, next) {
            user.UserUpdateDetial(req, res); 
        });
    },        
}