var user = require('../service/language');

module.exports = {
    GetLanguage: function (router) {
       router.get('/getlanguage', function (req, res) {
            user.GetLanguageDetial(req, res);
        });
    },
    AddLanguage:function (router) {
        router.post('/addlanguage', function (req, res) {
            user.AddLanguageDetial(req, res);
        });
    },
     DeleteLanguage:function (router) {
        router.post('/deletelanguage', function (req, res) {
            user.DeleteLanguageDetial(req, res);
        });
    },
}