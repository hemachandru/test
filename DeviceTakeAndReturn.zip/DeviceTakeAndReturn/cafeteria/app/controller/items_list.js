var user = require('../service/items_list');

module.exports = {
    GetItems: function (router) {
       router.get('/getitems', function (req, res) {
            user.GetItemsDetial(req, res);
        });
    },
    AddItems:function (router) {
        router.post('/additems', function (req, res) {
            user.AddItemsDetial(req, res);
        });
    },
     DeleteItems:function (router) {
        router.post('/deleteitems', function (req, res) {
            user.DeleteItemsDetial(req, res);
        });
    },
    ImageItems:function (router) {
        router.post('/imageitems', function (req, res) {
            user.ImageItemsDetial(req, res);
        });
    },
    ImagegetItems:function(router){
        router.post('/imagegetitems',function(req,res){
           user.ImageGetDetial(req,res); 
        });
    },
     EditItemsItems:function(router){
        router.post('/edititems',function(req,res){
           user.EditItemsDetial(req,res); 
        });
    },
     EditAmtItems:function(router){
        router.post('/editamt',function(req,res){
           user.EditAmtDetial(req,res); 
        });
    }
}