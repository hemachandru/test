var user = require('../service/order');

module.exports = {
    GetOrder: function (router) {
       router.post('/getorder', function (req, res) {
            user.GetOrderDetial(req, res);
        });
    },
    AddOrder:function (router) {
        router.post('/addorder', function (req, res) {
            user.AddOrderDetial(req, res);
        });
    },
     DeleteOrder:function (router) {
        router.post('/deleteorder', function (req, res) {
            user.DeleteOrderDetial(req, res);
        });
    },    
    ViewOrder:function(router){
        router.post('/vieworder',function(req, res){
            user.ViewOrderDetial(req, res);
        });
    },
    ViewOrdermonth:function(router){
        router.post('/viewordermonth',function(req, res){
            user.ViewOrdermonthDetial(req, res);
        });
    },
}