var user = require('../service/categries');

module.exports = {
    GetCategries: function (router) {
       router.get('/getcategries', function (req, res) {
            user.GetCategriesDetial(req, res);
        });
    },
    AddCategries:function (router) {
        router.post('/addcategries', function (req, res) {
            user.AddCategriesDetial(req, res);
        });
    },
     DeleteCategries:function (router) {
        router.post('/deletecategries', function (req, res) {
            user.DeleteCategriesDetial(req, res);
        });
    },
}