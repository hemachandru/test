var special = require('../service/special');

module.exports = {
    GetItemsspecial: function (router) {
       router.get('/getspecialitems', function (req, res) {
            special.GetItemsspecialDetial(req, res);
        });
    },
    AddItemsspecial:function (router) {
        router.post('/addspecialitems', function (req, res) {
            special.AddItemsspecialDetial(req, res);
        });
    },
     DeleteItemsspecial:function (router) {
    //     router.post('/deletespecialtemitems', function (req, res) {
    //         special.DeleteItemsspecialDetial(req, res);
    //     });
    },
}