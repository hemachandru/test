var team = require('../service/team');

module.exports = {
   GetTeam: function (router) {
       router.get('/getteam', function (req, res) {
            team.GetTeamDetial(req, res);
        });
    },
    AddTeam:function (router) {
        router.post('/addteam', function (req, res) {
            team.AddTeamDetial(req, res);
        });
    },
    DeleteTeam:function (router) {
        router.post('/deleteteam', function (req, res) {
            team.DeleteTeamDetial(req, res);
        });
    },
     UpdateTeam:function (router) {
        router.post('/updateteam', function (req, res) {
            team.UpdateTeamDetial(req, res);
        });
    },
}