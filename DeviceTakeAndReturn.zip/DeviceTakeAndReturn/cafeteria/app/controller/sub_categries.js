var user = require('../service/sub_categries');

module.exports = {
    GetSubCategries: function (router) {
       router.get('/getsubcategries', function (req, res) {
            user.GetSubCategriesDetial(req, res);
        });
    },
    AddSubCategries:function (router) {
        router.post('/addsubcategries', function (req, res) {
            user.AddSubCategriesDetial(req, res);
        });
    },
     DeleteSubCategries:function (router) {
        router.post('/deletesubcategries', function (req, res) {
            user.DeleteSubCategriesDetial(req, res);
        });
    },
    ParticularSubCategries:function (router) {
        router.post('/particularsubcategries', function (req, res) {
            user.ParticularSubCategriesDetial(req, res);
        });
    },
}