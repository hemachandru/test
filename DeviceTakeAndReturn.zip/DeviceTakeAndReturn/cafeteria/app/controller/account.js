var user = require('../service/account');

module.exports = {
    GetAccount: function (router) {
       router.get('/getaccount', function (req, res) {
            user.GetAccountDetial(req, res);
        });
    },
    GetAccountlist: function (router) {
       router.get('/getlistaccount', function (req, res) {
            user.GetAccountlistDetial(req, res);
        });
    },
    Getpaymentlist: function (router) {
       router.get('/getpaymentaccount', function (req, res) {
            user.GetpaymentlistDetial(req, res);
        });
    },
     Getfilterpaymentlist: function (router) {
       router.post('/getfilterpaymentaccount', function (req, res) {
            user.GetfilterpaymentlistDetial(req, res);
        });
    },
    Getmonthlist: function (router) {
       router.post('/getmonthaccount', function (req, res) {
            user.GetmonthlylistDetial(req, res);
        });
    },    
    AddAccount:function (router) {
        router.post('/addaccount', function (req, res) {
            user.AddAccountDetial(req, res);
        });
    },
     DeleteAccount:function (router) {
        router.post('/deleteaccount', function (req, res) {
            user.DeleteAccountDetial(req, res);
        });
    },
    Updatedeliver:function (router) {
        router.post('/updatedeliver', function (req, res) {
            user.UpdatedeliverDetial(req, res);
        });
    },
    SendSms:function(router){
        router.post('/sendsms',function(req,res){
            user.SendSmsDetails(req,res);
        });        
    },
}