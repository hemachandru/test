var sps = require('../service/sps');
module.exports = {
   SpsTeam: function (router) {
       router.get('/getsps', function (req, res) {
            sps.GetspsDetial(req, res);
        });
    },
     Addsps:function (router) {
        router.post('/addsps', function (req, res) {
            sps.AddspsDetial(req, res);
        });
    },
}