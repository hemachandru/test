module.exports = {
    Configuration:"mysql://root@localhost/hapi_cafeteria"
}