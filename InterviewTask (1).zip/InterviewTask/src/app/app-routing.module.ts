import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//page not found component import
import { PagenotfoundComponent } from './generic/pagenotfound/pagenotfound.component';

import {AccountModule} from './module/account/account.module'
import {HomeModule} from './module/home/home.module'
import { AuthGuardService } from './shared/shared/service/auth-guard.service';

const routes: Routes = [  
  {
    path: 'home',
    children: [
      {
        path:'',
        loadChildren: ()=> HomeModule,
        canActivate: [AuthGuardService]
      }
    ]
  },
  {
    path: '',
    children: [
      {
        path:'',
        loadChildren: ()=> AccountModule
      }
    ]
  },{
    path: 'login',
    children: [
      {
        path:'',
        loadChildren: ()=> AccountModule
      }
    ]
  },
  { path: '**', component: PagenotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
