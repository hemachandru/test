// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
// import { HttpClient } from '@angular/common/http';
import { Http, Response, Headers, RequestMethod } from '@angular/http';

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    constructor(private http: Http) {
        this.headers = new Headers();
    }


    getHttpRequest(url: string){
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Accept', 'application/json');
        return this.http.get(url)
            .map(this.successResponse)
            .catch(this.errorResponse)
    }

    private successResponse(result: Response) {
        return result.json() || null;
    }
    private errorResponse(error: Response) {
        console.log(error)
        return Observable.throw(error.json() || null);
    }
}