import { DecimalPipe } from '@angular/common';

export class ValidationService {
  static decimalPipe: DecimalPipe = new DecimalPipe('en-us');

  // static decimalPipe: DecimalPipe = this.dp;
  static getValidatorErrorMessage(controlname: any , validatorName: string, validatorValue?: any) {
    const config = {
      searchRequestValue: {
        minlength: 'Must be 11 digits.',
        maxlength: 'Must be 11 digits.',
        pattern: 'Invalid discount id.',
        required: 'Please complete',
      }
    };

    // return config[controlname][validatorName] ;
    return 'data error'
  }

}
