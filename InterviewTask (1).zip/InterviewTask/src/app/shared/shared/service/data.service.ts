import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class DataService {
  private data:any = undefined;
  private savedData:any = undefined;
  private dataId:any = undefined;

  constructor() { }

    setTokenData(data:any){
      this.data = data;
    }

    getTokenData():any{
      return this.data;
    }

    storeData(data:any){
      this.savedData = data;
    }

    getStoredData():any{
      return this.savedData;
    }

    storeId(data:any){
      this.dataId = data;
    }

    getStoredId():any{
      return this.dataId;
    }
}
