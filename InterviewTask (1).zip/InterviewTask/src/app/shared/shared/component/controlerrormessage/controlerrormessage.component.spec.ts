import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlerrormessageComponent } from './controlerrormessage.component';

describe('ControlerrormessageComponent', () => {
  let component: ControlerrormessageComponent;
  let fixture: ComponentFixture<ControlerrormessageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ControlerrormessageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlerrormessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
