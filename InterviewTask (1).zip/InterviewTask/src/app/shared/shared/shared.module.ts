import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReactiveFormsModule } from '@angular/forms';

import { ControlerrormessageComponent } from './component/controlerrormessage/controlerrormessage.component';



@NgModule({
  declarations: [
    ControlerrormessageComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ControlerrormessageComponent
  ]
})
export class SharedModule { }
