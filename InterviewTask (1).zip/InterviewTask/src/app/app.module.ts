import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PagenotfoundComponent } from './generic/pagenotfound/pagenotfound.component';

// import { HttpClientModule } from '@angular/common/http';
import { HttpRequestService } from './shared/http/http-request.service';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from './shared/shared/shared.module';
import { AuthGuardService } from './shared/shared/service/auth-guard.service';

@NgModule({
  declarations: [
    AppComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    // HttpClientModule
  ],
  providers: [HttpRequestService, AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
