import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';

import { HttpRequestService } from '../../../../shared/http/http-request.service';
import { AccountBusiness } from '../../business/account.business';
import { AccountService } from '../../service/account-service';

import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { DataService } from 'src/app/shared/shared/service/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [HttpRequestService, AccountBusiness, AccountService],
})
export class LoginComponent implements OnInit {

  // profileForm : FormGroup | any;


  constructor(
    private router: Router,  
    private loginBusiness: AccountBusiness, 
    private formBuilder: FormBuilder,
    private dataService: DataService
    ) { }


    profileForm = new FormGroup({
      userName: new FormControl(''),
      password: new FormControl(''),
    });

  ngOnInit(): void {
    this.initForm();
    // this.router.navigate(['home']);
  }

  initForm() {
    this.profileForm = this.formBuilder.group({
      userName: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit() {
    this.loginBusiness.applicationLogin().subscribe(res => {
      let item = []
      item = res.find((
        (item: { username: any; password: any; })  => 
        (item.username == this.profileForm.value.userName) && (item.password == this.profileForm.value.password)
      ));
      console.log(item);
      if (item) {
        this.dataService.setTokenData(item);
        this.router.navigate(['home']);
      } else {
        alert('Incorrect password');
      }
    }, (err) => {
        console.log("login error" + err);
    });
  }


}
