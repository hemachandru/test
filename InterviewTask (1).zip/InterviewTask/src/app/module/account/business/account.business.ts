import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { AccountService } from '../service/account-service';

@Injectable()
export class AccountBusiness{
    constructor( 
      private accountService: AccountService
    ) {}
    
     
    
    applicationLogin() {
      console.log('business')
      const apiUrl = "http://localhost:3000/users"
      return this.accountService.getLoginService(apiUrl).map((result => result));
    }
}