import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/http/http-request.service';

@Injectable()
export class AccountService {
  constructor(private httpRequest: HttpRequestService) {}
  
  getLoginService(url: string) {
    console.log('service')
    return this.httpRequest.getHttpRequest(url);
  }

}