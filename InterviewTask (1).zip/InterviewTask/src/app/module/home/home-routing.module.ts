import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UsersComponent } from './component/users/users.component';
import { UsersdetailsComponent } from './component/usersdetails/usersdetails.component';
import { AdduserComponent } from './component/adduser/adduser.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {path:"", redirectTo:"home",pathMatch: 'full'},
      {path:"", component:UsersComponent},
      {path:"users", component:UsersComponent},
      {path:"adduser", component:AdduserComponent},
      {path:"details", component:UsersdetailsComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
