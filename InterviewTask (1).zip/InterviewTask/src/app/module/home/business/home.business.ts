import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { HomeService } from '../service/home-service';

@Injectable()
export class HomeBusiness{
    constructor( 
      private homeService: HomeService
    ) {}
    
     
    
    getList() {
      console.log('business')
      const apiUrl = "http://localhost:3000/users"
      return this.homeService.getService(apiUrl).map((result => result));
    }
}