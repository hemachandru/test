import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

import { HttpRequestService } from '../../../../shared/http/http-request.service';

import { HomeBusiness } from '../../business/home.business';
import { HomeService } from '../../service/home-service';
import { DataService } from 'src/app/shared/shared/service/data.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers: [HttpRequestService, HomeBusiness, HomeService]
})
export class UsersComponent implements OnInit {

  constructor(
    private router: Router,  
    private homeBusiness: HomeBusiness,
    private dataService: DataService,
    private formBuilder: FormBuilder,
    ) { }

    tableData: any = '';

    formShow = false;

    profileForm = new FormGroup({
      userId: new FormControl(''),
      firstName: new FormControl(''),
      lastName: new FormControl(''),
      userName: new FormControl(''),
    });

  ngOnInit(): void {
    console.log('chandru === ',this.dataService.getStoredData())
    if (this.dataService.getStoredData() === '' || this.dataService.getStoredData() === undefined) {
      // alert('not empty test')
      this.homeBusiness.getList().subscribe(res => {
        this.tableData = res;
        this.dataService.storeData(res);
        // this.viewTableData();
        console.log('results   ---- ',this.tableData);
      }, (err) => {
          console.log("error" + err);
      });
    } else {
      // alert('empty')
      this.tableData =this.dataService.getStoredData()
    }
    this.initForm();
  }

  initForm() {
    this.profileForm = this.formBuilder.group({
      userId: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      userName: ['', [Validators.required]],
    });
  }

  viewTableData() {
    this.tableData =this.dataService.getStoredData()
  }

  onSubmit() {
    // console.log(this.profileForm.value)
    let id = this.profileForm.value.userId;
    let items = []
    items = this.tableData.find((item: { id: any })  => item.id == id);

    let item = []
    item = this.tableData.findIndex((item: { id: any })  => item.id == id);
    this.tableData.splice(item, 1);
    let obj = { 
      "id":  this.profileForm.value.userId, 
      "fname": this.profileForm.value.firstName, 
      "lname": this.profileForm.value.lastName,
      "username": this.profileForm.value.userName, 
      "password": items.password, 
      "token": items.token, 
      "isAdmin": items.isAdmin 
    }
    this.tableData.push(obj);
    this.tableData.sort((a: { id: number; },b: { id: number; }) => a.id - b.id)
    this.formShow = false
  }

  cancelClick() {
    this.formShow = false;
  }

  isAdminAccess = false
  edit(id: any) {
    this.formShow = true;
    let item = []
    item = this.tableData.find((item: { id: any })  => item.id == id);
    // console.log(this.dataService.getTokenData().isAdmin)
    this.profileForm.patchValue({
      userId: item.id,
      firstName: item.fname,
      lastName: item.lname,
      userName: item.username
    })
    this.isAdminAccess = this.dataService.getTokenData().isAdmin
  }
  
  delete(id: any) {
    let item = []
    item = this.tableData.findIndex((item: { id: any })  => item.id == id);
    this.tableData.splice(item, 1);
    // this.dataService.storeData(this.tableData);
    // this.viewTableData();
  }

  viewData(id : any){
    this.dataService.storeData(this.tableData);
    this.dataService.storeId(id);
    this.router.navigate(['home/details']);
  }

  addNew() {
    this.router.navigate(['home/adduser']);
  }

}
