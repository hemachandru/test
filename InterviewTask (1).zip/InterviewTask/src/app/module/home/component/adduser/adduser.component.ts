import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { DataService } from 'src/app/shared/shared/service/data.service';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {

  constructor(
    private router: Router,
    private dataService: DataService,
    private formBuilder: FormBuilder,
  ) { }

  profileForm = new FormGroup({
    userId: new FormControl(''),
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    userName: new FormControl(''),
    userPassword: new FormControl(''),
    userToken: new FormControl(''),
    isAdmin: new FormControl(''),
  });

  tableData: any;
  ngOnInit(): void {
    this.tableData = this.dataService.getStoredData()
    const test = this.tableData
    const res = test[test.length - 1]
    console.log(res.id, this.generateToken())
    this.initForm();
    this.profileForm.patchValue({
      userId: res.id + 1,
      userToken: this.generateToken()
    })
  }

  initForm() {
    this.profileForm = this.formBuilder.group({
      userId: ['', [Validators.required]],
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      userName: ['', [Validators.required]],
      userPassword: ['', [Validators.required]],
      userToken: ['', [Validators.required]],
      isAdmin: ['', [Validators.required]],
    });
  }

  cancelClick() {
    this.router.navigate(['home']);
  }

  onSubmit() {
    console.log(this.profileForm )
    let obj = { 
      "id":  this.profileForm.value.userId, 
      "fname": this.profileForm.value.firstName, 
      "lname": this.profileForm.value.lastName,
      "username": this.profileForm.value.userName, 
      "password": this.profileForm.value.userName, 
      "token": this.profileForm.value.userToken,
      "isAdmin": this.profileForm.value.userName 
    }
    this.tableData.push(obj);
    this.tableData.sort((a: { id: number; },b: { id: number; }) => a.id - b.id)
    this.dataService.storeData(this.tableData);
    alert('Saved...!')
    this.router.navigate(['home']);
  }
  
  generateToken() {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < 10; i++ ) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }
}
