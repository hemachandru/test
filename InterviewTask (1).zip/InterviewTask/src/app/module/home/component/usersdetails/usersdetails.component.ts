import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/shared/shared/service/data.service';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-usersdetails',
  templateUrl: './usersdetails.component.html',
  styleUrls: ['./usersdetails.component.css']
})
export class UsersdetailsComponent implements OnInit {

  constructor(private router: Router,  private dataService: DataService,) { }
 
  result: any;
  ngOnInit(): void {
    const data = this.dataService.getStoredData();
    const id = this.dataService.getStoredId();
    // let item = []
    this.result = data.find((item: { id: any })  => item.id == id);
    console.log(this.result)
  }

  goBack() {
    this.router.navigate(['home']);
  }
}
