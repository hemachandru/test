import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeRoutingModule } from './home-routing.module';
import { UsersComponent } from './component/users/users.component';
import { UsersdetailsComponent } from './component/usersdetails/usersdetails.component';

import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AdduserComponent } from './component/adduser/adduser.component';

@NgModule({
  declarations: [
    UsersComponent,
    UsersdetailsComponent,
    AdduserComponent
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    HttpModule,
    ReactiveFormsModule
  ]
})
export class HomeModule { }
