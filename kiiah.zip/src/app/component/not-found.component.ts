import { Component, OnInit, ElementRef, Renderer, Input } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';

@Component({
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.scss']
})
export class PageNotFoundComponent { 
  public displayNoneBool: any;
  public menuBool: boolean = false;
  ngOnInit() {
    this.displayNoneBool='none';
    document.getElementById("navHeader").style.display = "none" ;
  }
}