import { Component, OnInit, AfterViewInit } from '@angular/core';
import '../assets/css/styles.scss';
import { LoaderService } from './utility/helper.service';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';

//import { TranslateService } from "ng2-translate";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  showLoader: boolean;
  constructor(
    private loaderService: LoaderService, private router: Router) {
    this.router.events
      .filter(e => e.constructor.name === 'RoutesRecognized')
      .pairwise()
      .subscribe((e: any[]) => {
        //   if (e[0].url == "/share-login" && e[1].url == "/thankyoustudioedit" || e[0].url == "/share-login" && e[1].url == "/payment-type"){
        //     this.router.navigate(['/share-login']);
        //   }
        // console.log("previous route", e[0].url);
        // console.log("current route", e[1].url);

        if(e[1].url == '/response/2' || e[1].url == '/response/1' ){
          //console.log('password not match');
          let pwdNtMatch = 'passwordnot';
          sessionStorage.setItem("passwordnot", pwdNtMatch)
        }

      });
  }
  ngOnInit() {
    this.loaderService.status.subscribe((val: boolean) => {
      setTimeout(() => {  
        this.showLoader = val;
      }, 100);
     
    }, (error: any) => {
    });   
  }

  ngAfterViewInit() {

  }  


}

