import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

@Injectable()
export class FileUpload {
    public myFile: any;
    private base64textString: String = "";
    public myFileInfo: any;
    public maxFileSize: any;
    public previewImg: any;


    constructor(public router: Router) {
        this.myFileInfo = {
            avatarInfo: {
                content_type: '',
                filename: '',
                file_data: ''
            },
            previewImage: '',
            fileSize: ''
        }

    }

    // S3FileUpload(file: any) {
    //     AWS.config.accessKeyId = AwsAccessKey;
    //     AWS.config.secretAccessKey = AwsSecretKey;
    //     var bucket = new AWS.S3({ params: { Bucket: AwsBucket } });
    //     var params = { Key: file.name, Body: file };
    //     bucket.upload(params, function (err: any, data: any) {
    //         console.log(data);
    //         console.log(err);
    //     });
    // }

    /* For Image upload */
    ImageUpload(event: any) {

        let fileList: FileList = event.target.files;
        let file: File = fileList[0];

        if (fileList && file) {


            if (file.size <= 1024 * 1024 * 2) {
                this.maxFileSize = 'hidden';
                this.myFile = file;

                /* For Base64 Image convert */
                var reader = new FileReader();
                reader.onload = this._handleReaderLoaded.bind(this, this.myFile);
                reader.readAsBinaryString(file);

            } else {
                this.maxFileSize = 'visible';
            }
            //return this.myFileInfo;

        }
    }

    /* For Base64 Image convert */
    _handleReaderLoaded(fileData: any, readerEvt: any) {
        var binaryString = readerEvt.target.result;
        this.base64textString = btoa(binaryString);
        this.previewImg = "data:" + fileData.type + ";base64," + this.base64textString;

        // this.myFileInfo = {
        //     avatarInfo: {
        //         content_type: fileData.type,
        //         filename: fileData.name,
        //         file_data: this.base64textString
        //     },
        //     previewImage: this.previewImg,
        //     fileSize: this.maxFileSize
        // }

    }

    /* End Image upload */



}