import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Ng2UiAuthModule, AuthService, SharedService } from 'ng2-ui-auth';
import { socialAuthConfig } from './auth.config';
import { socialAuthentication } from './socialAuth';
import { SetHeightDirective } from "./set-height.directive";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    Ng2UiAuthModule.forRoot(socialAuthConfig),
  ],
  declarations: [
    SetHeightDirective
  ],
  providers: [AuthService, SharedService, socialAuthentication],
  exports: [SetHeightDirective]
})
export class UtilityModule { }

