import {
    Directive, ElementRef, AfterViewChecked,
    Input, HostListener
} from '@angular/core';

@Directive({
    selector: '[setMatchHeight]'
})
export class SetHeightDirective implements AfterViewChecked {

    // class name to match height
    @Input()
    height: any;

    constructor(private el: ElementRef) {
    }

    ngAfterViewChecked() {
        // call our matchHeight function here later
        this.setHeight(this.el.nativeElement);
    }

    @HostListener('window:resize')
    onResize() {
        // call our matchHeight function here later
        this.setHeight(this.el.nativeElement);
    }

    setHeight(parent: HTMLElement) {
        let winHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
        
        if (winHeight < 580) {
            winHeight = 530;
        }
        // if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        //     winHeight = window.screen.height;
        // } else {
        //     winHeight = window.innerHeight;
        // }

        //let winHeight: any;
        const mq = window.matchMedia("(max-width: 767px)");
        let height: any;
        let value = document.getElementsByTagName('main')[0];
        let result = window.getComputedStyle(value, null).getPropertyValue('padding-top').split('px')[0];
        if (mq.matches) {
            height = parseInt(result);
            //winHeight = window.screen.height;
        } else {
            height = parseInt(result);
            //winHeight = window.innerHeight;
        }
        let actualHeight;
        let browserbarHight = 20;
        if (winHeight < 580) {
            actualHeight = winHeight + browserbarHight;
        } else {
            actualHeight = (winHeight) - height;
        }

        parent.style.minHeight = `${actualHeight}px`;
    }
}