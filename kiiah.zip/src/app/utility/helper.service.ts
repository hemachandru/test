import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

const mojs = require('mo-js/build/mo.js');
@Injectable()
export class LoaderService {
    public status: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

    display(value: boolean) {
        if(this.status.value != value){
            this.status.next(value)
        }
    }
}

@Injectable()

export class MojsBurstButtonAnimation {
    private burst: any;
    public timeOutValue= 500;
    constructor(private loaderService:LoaderService){
    }

    intializeMojs(){
        //duration: 1500
        this.burst = new mojs.Burst({
            className: "mojs-btn",
            left: 0, top: 0,
            radius: { 0: 60 },
            count: 10,
            children: {
              shape: 'circle',
              radius: 7,
              fill: ['#30a6fd'],
              strokeWidth: 3,
              duration: 7000
            }
          });
    }

    createMojsStyle(event: any){
        var width = event.target.offsetWidth;
        var height = event.target.offsetHeight;
        
        var ButtonCenterX = width / 2;
        var ButtonCenterY = height / 2;

        var elTop = this.getCoords(event.target).top;
        var elLeft = this.getCoords(event.target).left;
        
        var pointLeft = ButtonCenterX + elLeft;
        var pointTop = ButtonCenterY + elTop;
  
        this.burst
          .tune({ x: pointLeft, y: pointTop })
          .setSpeed(10)
          .replay();
    }

    
    resetMojsStyle(document:any){
        let parentElms: any = document.getElementsByClassName('mojs-btn');
        for (let i = 0; i < parentElms.length; i++) {
          parentElms[i].style.transform = "scale(0, 0)";
          let childElms: any = document.getElementsByClassName('mojs-btn')[i].childNodes
          for (var j = 0; j < childElms.length; j++) {
            childElms[j].style.transform = "scale(0, 0)";
          }
        }
    }


    getCoords(elem: any) {
        var box = elem.getBoundingClientRect();
    
        var body = document.body;
        var docEl = document.documentElement;
    
        var scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
        var scrollLeft = window.pageXOffset || docEl.scrollLeft || body.scrollLeft;
    
        var clientTop = docEl.clientTop || body.clientTop || elem.clientTop ||0;
        var clientLeft = docEl.clientLeft || body.clientLeft || elem.clientLeft || 0;
    
        // var top = box.top + scrollTop - clientTop;
        // var left = box.left + scrollLeft - clientLeft;

        var top = box.top ;
        var left = box.left ;
    
        return { top: Math.round(top), left: Math.round(left) };
      }

      setTimeOut_Animation(navigationUrl :any, self:any, paramValue?:any){
        this.loaderService.display(true);
        let timeoutId = setTimeout(() => {  
            this.loaderService.display(false);
            if(paramValue){
                self.router.navigate([navigationUrl, paramValue]);
            }else{
                self.router.navigate([navigationUrl]); 
            }
            
          }, this.timeOutValue);
      }
   
}