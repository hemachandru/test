import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';
import { AuthService } from 'ng2-ui-auth';

@Injectable()
export class socialAuthentication {
    public token: string;


    constructor(public router: Router, private auth: AuthService) {
        var fixed = document.getElementById('loadingDiv');

        fixed.addEventListener('touchmove', function (e) {

            e.preventDefault();

        }, false);
    }

    loginSocialAccount(accountType: string) {
        //document.getElementById("loadingDiv").style.display = "block";

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.auth.authenticate(accountType)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    googleAccountAuth(accountType: string, typeParam: any) {
       // document.getElementById("loadingDiv").style.display = "block";
        var userData = {
            loginType: typeParam
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.auth.authenticate(accountType, userData)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }
}