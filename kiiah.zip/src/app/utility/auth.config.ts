import { CustomConfig } from 'ng2-ui-auth';
import { FACEBOOK_CLIENT_ID, TWITTER_KEY, GOOGLE_CLIENT_ID, baseURL, YAHOO_CLIENT_ID, OUTLOOK_CLIENT_ID } from '../config/constant';

export class socialAuthConfig extends CustomConfig {

    defaultHeaders = { 'Content-Type': 'application/json'};
    providers = {
        facebook: {
            clientId: FACEBOOK_CLIENT_ID
        },
        twitter: {
            clientId: TWITTER_KEY
        },
        google: {
            clientId: GOOGLE_CLIENT_ID,
            scope: ['profile', 'email', 'https://www.google.com/m8/feeds']
        },
        yahoo: {
            clientId: YAHOO_CLIENT_ID
        },
        live: {
            clientId: OUTLOOK_CLIENT_ID,
            scope: ['openid', 'profile', 'User.Read', 'Mail.Read', 'Contacts.Read'],
            authorizationEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
        }
    };
    baseUrl = baseURL;
}