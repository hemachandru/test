import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { LoaderService } from '../utility/helper.service';
import { baseURL } from '../config/constant';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
const langUrl = "?lang="+ localStorage.getItem("lang");

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    public langUrl:any;
   

    constructor(private http: Http, private loaderService:LoaderService) {
        this.headers = new Headers();
        //this.langUrl = "?lang="+ localStorage.getItem("lang");
    }

    /**
     * GET Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequestWithoutToken(url: string) {
        this.requestInterceptor();
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.get(baseURL + url + "?lang="+ localStorage.getItem("lang"), {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });
    }

    /**
     * POST Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequestWithoutToken(data: string, url: string) {
        this.requestInterceptor();
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');

        return self.http.post(baseURL + url + "?lang="+ localStorage.getItem("lang"), data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });
    }

    /**
     * PUT Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUt request with data.
     * 
     * @return {Observable}
     */
    putHttpRequestWithoutToken(data: string, url: string) {
        this.requestInterceptor();
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');

        return self.http.put(baseURL + url + "?lang="+ localStorage.getItem("lang"), data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });;

    }
    /**
     * GET Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequest(url: string) {
        this.requestInterceptor();
        this.headers.set('Accept', 'application/json');
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.get(baseURL + url + "?lang="+ localStorage.getItem("lang"), {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });
    }

    /**
     * POST Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequest(data: string, url: string) {
        this.requestInterceptor();
        this.headers.set('Accept', 'application/json');
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.post(baseURL + url + "?lang="+ localStorage.getItem("lang"), data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });
    }

    /**
     * POST Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequestMultipart(data: any, url: string) {
        //this.headers.set('Accept', 'application/json');
        //this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        //this.headers.set('Content-Type', "false");
        //this.headers.set('Content-Type', 'application/x-www-form-urlencoded');
        //this.headers.set('Content-Type', 'application/json;charset=utf-8');
        //this.headers.set('Content-Type', undefined);
        //this.headers.set('Content-Type', "multipart/form-data");
        this.requestInterceptor();
        var self = this;
        // return self.http.post(baseURL + url + '?Authorization=' + localStorage.getItem("token"), data, {
        //     headers: self.headers
        // })
        //     .map(self.successResponse)
        //     .catch(self.errorResponse);

        return self.http.post(baseURL + url + '?Authorization=' + localStorage.getItem("token"), data)
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });

        // var xhr = new XMLHttpRequest();
        // xhr.open('POST', baseURL + url, true);
        // xhr.setRequestHeader('Accept', 'application/json');
        // xhr.setRequestHeader('Authorization', 'Bearer ' + localStorage.getItem("token"));
        // xhr.setRequestHeader('Content-Type', undefined);
        // xhr.onload = function () {
        //     // do something to response
        //     console.log(this);
        // };
        // xhr.send(data);


    }

    /**
     * PUT Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUT request with data.
     * 
     * @return {Observable}
     */
    putHttpRequest(data: string, url: string) {
        this.requestInterceptor();
        this.headers.set('Accept', 'application/json');
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.put(baseURL + url + "?lang="+ localStorage.getItem("lang"), data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });

    }

    /**
     * errorResponse 
     * Common method to handle error response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private errorResponse(error: Response) {
        return Observable.throw(error.json() || null);
    }

    /**
     * successResponse 
     * Common method to handle success response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private successResponse(result: Response) {
        return result.json() || null;
    }

    /**
    * GET Http Request without token 
    * Common service to handle PUT Http Request
    * 
    * @param {string} url - Get request end point URL.
    * 
    * @return {Observable}
    */
    deleteHttpRequestWithToken(url: string) {
        this.requestInterceptor();
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');
        self.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));

        return self.http.delete(baseURL + url + "?lang="+ localStorage.getItem("lang"), {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            .finally(() => {
                this.onFinally();
            });
    }

    /**
     * Request interceptor.
     */
    private requestInterceptor(): void {
        this.loaderService.display(true);
    }


    /**
     * Response interceptor.
     */
    private responseInterceptor(): void {
        this.loaderService.display(false);
    }

    /**
     * onFinally
     */
    private onFinally(): void {
        this.responseInterceptor();
    }
}