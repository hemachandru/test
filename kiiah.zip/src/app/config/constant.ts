var env = require("./../../../config.json");

export const baseURL = env.redirectURL;
export const SITE_URL = env.siteURL;
//export const baseURL = "http://192.168.10.83:3000/v1/";

 // "siteURL": "https://test-frontend.outsourcelive.com",    
/* For Social Authendicate Keys */

export const FACEBOOK_CLIENT_ID =  env.FACEBOOK_CLIENT_ID;
export const TWITTER_KEY = env.TWITTER_KEY;
export const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID;
export const YAHOO_CLIENT_ID = env.YAHOO_CLIENT_ID;
export const OUTLOOK_CLIENT_ID = env.OUTLOOK_CLIENT_ID;
export const TEMP_BUCKET_ACCESS_KEY = env.TEMP_BUCKET_ACCESS_KEY;
export const TEMP_BUCKET_SECRET_KEY = env.TEMP_BUCKET_SECRET_KEY;
export const TEMP_BUCKET_NAME = env.TEMP_BUCKET_NAME;
export const PAYPAL_AUTH_ID = env.PAYPAL_AUTH_ID;
export const DEFAULT_IMAGE_URL = env.DEFAULT_IMAGE_URL;
