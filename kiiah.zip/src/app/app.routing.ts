import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './service/auth-guard.service';
import { LayoutComponent } from './modules/layout/component/layout.component';
import { PageNotFoundComponent } from './component/not-found.component';

export const routes: Routes = [
    {
        path: '',
        redirectTo: '/socialsignup',
        pathMatch: 'full'
    },
    {
        path: 'login',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'signin',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'signup',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'socialsignup',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'forgetpassword',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'resetsuccess',
        loadChildren: './modules/account/account.module#AccountModule'
    },    
    {
        path: 'response/:res_id',
        loadChildren: './modules/account/account.module#AccountModule'
    },
    {
        path: 'firstwish',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'userwish',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'userwish/:id',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'addwish',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'addwish/:id',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishsuccess',
        loadChildren: './modules/userwish/wish.module#WishModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'contactus',
        loadChildren: './modules/support/support.module#SupportModule'
    },
    {
        path: 'faq',
        loadChildren: './modules/support/support.module#SupportModule'
    },
    {
        path: 'wishes-contributor',
        loadChildren: './modules/contributor/contributor.module#ContributorModule'
    },
    {
        path: 'mywishes',
        loadChildren: './modules/contributor/contributor.module#ContributorModule'
    },
    {
        path: 'payment-type',
        loadChildren: './modules/payment/payment.module#PaymentModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'payment-type/:code',
        loadChildren: './modules/payment/payment.module#PaymentModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'paypal-login-success',
        loadChildren: './modules/payment/payment.module#PaymentModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'cardpayment',
        loadChildren: './modules/payment/payment.module#PaymentModule'
    },
    {
        
        path: 'paypalsuccess/:id',
        loadChildren: './modules/payment/payment.module#PaymentModule'
    },
    {
        path: 'invitee-list',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'secure-link',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'share-notification',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishlist-shared',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishlist-invitation',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishlist-invitation-new',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishlist-thankyou',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'wishlist-thankyou-new',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'email-import',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'shared-success',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'share-login',
        loadChildren: './modules/share/share.module#ShareModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'myaccount',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'updatesuccess',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'message-centre',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'message-view/:id',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'special-date',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'contributions',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: 'myprofile',
        loadChildren: './modules/user/user.module#UserModule',
        canLoad: [AuthGuard]
    },
    {
        path: "myinvitation/:type",
        loadChildren: "./modules/invitation/invitation.module#InvitationModule",
        canLoad: [AuthGuard]
    },
    {
        path: "invitationedit",
        loadChildren: "./modules/invitation/invitation.module#InvitationModule",
        canLoad: [AuthGuard]
    },
    {
        path: "invitationsuccess/:type",
        loadChildren: "./modules/invitation/invitation.module#InvitationModule",
        canLoad: [AuthGuard]
    },
    {
        path: "termsandconditions",
        loadChildren: './modules/support/support.module#SupportModule'
    },
    {
        path: "privacypolicy",
        loadChildren: './modules/support/support.module#SupportModule'
    },
    {
        path: 'thankyou-message',
        loadChildren: './modules/well-wishes/well-wishes.module#WellwishesModule'
    },
    {
        path: 'wellwishes-studio',
        loadChildren: './modules/well-wishes/well-wishes.module#WellwishesModule'
    },
    {
        path: 'message-sent',
        loadChildren: './modules/well-wishes/well-wishes.module#WellwishesModule'
    },
    {
        path: "thankyoustudio/:type",
        loadChildren: "./modules/thankyoustudio/thankyoustudio.module#ThankyouStudioModule",
        canLoad: [AuthGuard]
    },
    {
        path: "thankyoustudio-success/:type",
        loadChildren: "./modules/thankyoustudio/thankyoustudio.module#ThankyouStudioModule",
        canLoad: [AuthGuard]
    },
    {
        path: "thankyoustudioedit",
        loadChildren: "./modules/thankyoustudio/thankyoustudio.module#ThankyouStudioModule",
        canLoad: [AuthGuard]
    },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: false })],
    exports: [RouterModule]
})
export class AppRoutingModule { }