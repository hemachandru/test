import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateService } from "ng2-translate";
import { SharedModule } from './modules/share/translate-shared.module';
import { NgxPaginationModule } from 'ngx-pagination';

import { AppRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { LayoutComponent } from './modules/layout/component/layout.component';
import { LayoutBusiness } from './modules/layout/business/layout.business';
import { LayoutService } from './modules/layout/service/layout.service';
import { PageNotFoundComponent } from './component/not-found.component';

import { LoaderService, MojsBurstButtonAnimation } from './utility/helper.service';
import { HttpRequestService } from './service/http-request.service';
import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { SlimScrollModule } from 'ng2-slimscroll';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';

import { AuthGuard } from './service/auth-guard.service';
import { AuthService } from './service/auth.service';
import { FileUpload } from './utility/fileUpload';
// import { TRANSLATION_PROVIDERS, TranslatePipe, TranslateService} from './utility/translation';
//import { SharedModule } from './modules/share/translate-shared.module';
@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    SlimScrollModule,
    HttpModule,
    TranslateModule.forRoot(),
    NgxPaginationModule,
    BootstrapModalModule,
    ModalModule.forRoot(),
  ],
  declarations: [
    AppComponent,
    LayoutComponent,
    PageNotFoundComponent
    // TranslatePipe
  ],
  providers: [HttpRequestService, LayoutBusiness, LayoutService, FileUpload, AuthGuard, AuthService, LoaderService, SharedModule, MojsBurstButtonAnimation],
  bootstrap: [AppComponent]
})
export class AppModule { }
