import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { InvitationComponent } from './component/invitation.component';

export const invitationRoutes: Routes = [
  {
    path: '',
    component: InvitationComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(invitationRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class InvitationRoutingModule { } 
