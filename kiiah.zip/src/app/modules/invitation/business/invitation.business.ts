import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { InvitationService } from '../service/invitation.service'

@Injectable()
export class InvitationBusiness {

    constructor(public invitationService: InvitationService, public router: Router) { }

    getListAPI(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.getListApi(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getInvitationStudio(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.getInvitationStudio(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    invitationSave(addWishData: any, url: string) {
        var invitationFormData = {
            "invitation_studio": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.apiSaveInivitation(JSON.stringify(invitationFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    invitationSaveVideo(addWishData: any, url: string) {
        var invitationFormData = {
            "invitation_studio": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.apiSaveInivitation(addWishData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    sendVideo(videoData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.sendVideo(videoData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    previewObject(options: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.invitationService.previewObject(options, url)
            .subscribe((result: any) => {
                activeProject.next(result)
            },
            (error: any) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}