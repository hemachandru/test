import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InvitationRoutingModule } from './invitation.routing';
import { ClickOutsideModule } from 'ng-click-outside';
import {Autosize} from 'angular2-autosize';

import { InvitationComponent } from './component/invitation.component';
import { InvitationStudioComponent } from './component/invitation-studio/invitationstudio.component';
import { InvitationEditComponent } from './component/invitation-edit/invitationedit.component';
import { InvitationSuccessComponent } from './component/invitation-success/invitationsuccess.component';
import { ProgressBarModule } from "ngx-progress-bar";

import { SlimScrollModule } from 'ng2-slimscroll';

import { InvitationBusiness } from './business/invitation.business';
import { InvitationService } from './service/invitation.service';

import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { SharedModule } from '../share/translate-shared.module';

const SWIPER_CONFIG: SwiperConfigInterface = {
    scrollbar: null,
    observer: true,
    spaceBetween: 65,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    breakpoints: {
        // when window width is <= 320px
        320: {
            slidesPerView: 1,
            spaceBetween: 35
        },
        // when window width is <= 480px
        480: {
            slidesPerView: 1,
            spaceBetween: 50
        },
        // when window width is <= 600px
        600: {
            slidesPerView: 1,
            spaceBetween: 65
        }
    }
};
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        InvitationRoutingModule,
        SwiperModule.forRoot(SWIPER_CONFIG),
        ClickOutsideModule,
        SlimScrollModule,
        ProgressBarModule,
        SharedModule
    ],
    declarations: [
        InvitationComponent,
        InvitationStudioComponent,
        InvitationEditComponent,
        //Autosize,
        InvitationSuccessComponent
    ],
    providers: [InvitationBusiness, InvitationService, SharedModule]
})
export class InvitationModule {
    public config: SwiperConfigInterface = {
        scrollbar: null,
        observer: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        breakpoints: {
            // when window width is <= 320px
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            },
            // when window width is <= 480px
            480: {
                slidesPerView: 1,
                spaceBetween: 20
            }
        }
    };
}

