import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { InvitationBusiness } from '../../business/invitation.business';


@Component({
  selector: 'invitation-success',
  templateUrl: './invitationsuccess.component.html',
  styleUrls: ['./invitationsuccess.component.scss']
})


export class InvitationSuccessComponent implements OnInit , OnDestroy{

  public paypal = true;

  public invType: string;

  constructor(private router: Router, private route: ActivatedRoute, private _location: Location, private invitationBusiness: InvitationBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    this.route.params.subscribe(params => {
      this.invType = params['type'];
    });
  }

  ngOnInit() {
    //this.getUserInformation();
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }
  goBack() {
    this._location.back();
  }

  redirectTo(event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let ShareBool = localStorage.getItem("shareWishOrCreateWish");
    if (ShareBool == "false"){
     this.mojsBurstButtonAnimation.setTimeOut_Animation('/invitationedit',this);
    }
    else{
      this.mojsBurstButtonAnimation.setTimeOut_Animation('/wishlist-invitation',this);
    }
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}