import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Renderer, AfterViewInit, TemplateRef, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { InvitationBusiness } from '../../business/invitation.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { LayoutBusiness } from '../../../layout/business/layout.business';

@Component({
    selector: 'invitation-edit',
    templateUrl: './invitationedit.component.html',
    styleUrls: ['./invitationedit.component.scss']
})

export class InvitationEditComponent implements OnInit, AfterViewInit, OnDestroy {
    
    @ViewChild('viewDesc') public viewDesc: TemplateRef<any>;
    dialog: DialogRef<any>;

    public someProperty: any;
    public invitationStudio: any;
    public videoP: boolean = false;
    public audioP: boolean = false;
    public isMobile: any;
    private fullDescription: any;
    public buttonshare: boolean = false;
    public buttonnext: boolean = false;
    public nextVia: any;
    public read_more: any;
    public read_more_hide : any;

    constructor(private router: Router, private _location: Location, private invitationBusiness: InvitationBusiness, private render: Renderer,  overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private layoutBusiness: LayoutBusiness, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
        overlay.defaultViewContainer = vcRef;
        
        this.invitationStudio = {
            frame_url: "",
            invitation: {

            },
            media: "",
            message: "",
            type: ""
        };
    }

    ngOnInit() {
        //nextVia
        let invitation_Via = sessionStorage.getItem('invitation_Via');
        // if (invitation_Via == 'share'){
        //     this.nextVia = 'block';
        // }else{
        //     this.nextVia = 'none';
        // }

        this.loaderService.display(true);
        this.isMobile = this.detectMobile();
        this.mojsBurstButtonAnimation.intializeMojs();
        this.someProperty = true;
        document.getElementById('image_without_frame').style.display = 'none';
        document.getElementById('image_with_frame').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        this.getInvitationStudio();
        this.thankyouStudio();
        
    }

    async thankyouStudio() {
        localStorage.getItem("shareWishOrCreateWish") == "true" ? this.buttonnext =true : this.buttonnext =false;
      }

    detectMobile() {
        if (navigator.userAgent.match(/Android/i)
            || navigator.userAgent.match(/webOS/i)
            || navigator.userAgent.match(/iPhone/i)
            || navigator.userAgent.match(/iPad/i)
            || navigator.userAgent.match(/iPod/i)
            || navigator.userAgent.match(/BlackBerry/i)
            || navigator.userAgent.match(/Windows Phone/i)
        ) {
            return true;
        }
        else {
            return false;
        }
    }

    async getInvitationStudio() {
        let self = this;
        let resList = await this.invitationBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
            console.log(result);
            if (result.response) {
                console.log("frame_url image ----", result.message.frame_url);
                console.log("media image ----", result.message.media);
                this.invitationStudio = result.message;
                if (result.message.type == "video") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewVideo = document.getElementById('preview_video');
                    previewVideo.setAttribute('src', result.message.media);
                    previewVideo.addEventListener('ended', this.myHandler(self), false);
                    previewVideo.addEventListener('pause', this.myHandlerPause(self), false);
                    document.getElementById('preview_video').style.display = 'block';
                    document.getElementById('play--icon').style.display = 'block';
                } else if (result.message.type == "audio") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewAudio = document.getElementById('preview_audio');
                    previewAudio.setAttribute('src', result.message.media);
                    previewAudio.addEventListener('ended', this.myHandlerAudio(self), false);
                    document.getElementById('preview_audio').style.display = 'block';
                    document.getElementById('preview_audio1').style.display = 'block';
                    document.getElementById('audio--play--icon').style.display = 'block';
                } else {
                    document.getElementById('image_without_frame').style.display = 'none';
                    document.getElementById('image_with_frame').style.display = "block";
                }
            } else {
                //console.log("error----", result.message)
            }
            var showChar = 150;
            if (this.invitationStudio.invitation.description.length > showChar) {
                this.read_more_hide = 'none';
                this.read_more = this.invitationStudio.invitation.description.substr(0, showChar);
            }else{
                this.read_more_hide ='block';
            }
            
        },
            (error) => {
                //console.log(error);
            });
    }

    myHandler(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                let videoTag: any = document.getElementById('preview_video');
                videoTag.webkitExitFullscreen();
                //videoTag.mozCancelFullScreen();
            }
            that.videoP = false;
            document.getElementById('pause--icon').style.display = 'none';
            document.getElementById('play--icon').style.display = 'block';
        }
    }

    myHandlerPause(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                that.videoP = false;
                document.getElementById('pause--icon').style.display = 'none';
                document.getElementById('play--icon').style.display = 'block';
            }

        }
    }

    myHandlerAudio(that: any) {
        return (event: any) => {
            that.audioP = false;
            document.getElementById('audio--pause--icon').style.display = 'none';
            document.getElementById('audio--play--icon').style.display = 'block';
        }
    }

    ngAfterViewInit() {
        document.getElementById("loadingDiv").style.display = "none";
    }

    playVideo() {
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'block';
        this.videoP = true;
        previewVideo.play();

    }

    stopVideo() {
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('play--icon').style.display = 'block';
        this.videoP = false;
        previewVideo.pause();
    }

    playAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'block';
        this.audioP = true;
        previewVideo.play();

    }

    stopAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'block';
        this.audioP = false;
        previewVideo.pause();
    }

    gotoInvitation(event:any) {
        let wishState =  'editInvitation';
        sessionStorage.setItem('wishState', wishState);

        this.mojsBurstButtonAnimation.createMojsStyle(event);
        if (!this.videoP && !this.audioP) {
            this.mojsBurstButtonAnimation.setTimeOut_Animation('/myinvitation/edit',this);
            
        }
    }
    gotoShare(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        this.mojsBurstButtonAnimation.setTimeOut_Animation('/share-login',this);
        
    }

    async gotoNext(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        let resList = await this.layoutBusiness.getThankyouStudio('thankyou_studios/thankyou_studio_present').subscribe((result) => {
            if (result.response) {
              this.router.navigate(['/thankyoustudioedit']);
            } else {
              this.router.navigate(['/thankyoustudio/edit']);
            }
            this.onClose();
          },
            (error) => {
              this.mojsBurstButtonAnimation.resetMojsStyle(document);
              console.log(error);
            })
    }

    goBack() {
        if (!this.videoP && !this.audioP) {
            this._location.back();
        }
    }

    viewDescription(value: any) {
        this.fullDescription = value;
        return this.modal.open(this.viewDesc, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
          .then(dialog => {
            this.dialog = dialog;
          })
      }
      onClose() {
        this.dialog.close();
      }

      ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      }

}