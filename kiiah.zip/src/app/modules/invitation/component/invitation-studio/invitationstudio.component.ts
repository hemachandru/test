import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Renderer, AfterViewInit, TemplateRef, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import * as AWS from 'aws-sdk';
import { InvitationBusiness } from '../../business/invitation.business';
import { FileUpload } from '../../../../utility/fileUpload';
import { baseURL, TEMP_BUCKET_ACCESS_KEY, TEMP_BUCKET_SECRET_KEY, TEMP_BUCKET_NAME } from '../../../../config/constant';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

declare var MediaRecorder: any;
var WEBCAM = require("./../../../../../assets/js/webcam.js");
var WEBCAM2 = require("./../../../../../assets/js/webcam.js");
var WEBCAM3 = require("./../../../../../assets/js/webcam.js");
var i_increment = 0;
var idx = 0;
var j_increment = 0;
var onetimeRun = true;
var timerCount = 0;
@Component({
    selector: 'invitation-studio',
    templateUrl: './invitationstudio.component.html',
    styleUrls: ['./invitationstudio.component.scss']
})

export class InvitationStudioComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('viewDesc') public viewDesc: TemplateRef<any>;
    dialog: DialogRef<any>;

    private awsOptions = {
        accessKeyId: TEMP_BUCKET_ACCESS_KEY,
        secretAccessKey: TEMP_BUCKET_SECRET_KEY
    };

    private s3 = new AWS.S3(this.awsOptions);

    public someProperty: any;
    public showNextPage: any;
    public StudioTitle: any;
    public pageShowId: any;
    public wasClicked = false;
    public descriptionList: any;
    public invitationValue: any;
    public dropdownList: any;
    public saveStudio: any;
    public error = true;
    public maxFileSize: any = 'hidden';
    // public unSupportedVideo: any = 'hidden';
    // public maxFileSizeVideo: any = 'hidden';
    // public maxDurationVideo: any = 'hidden';
    public myFile: any;
    public base64textString: any;
    public previewImg: any = null;
    public frameList: any;
    public recordOption: any;
    public invitationType: any;
    public videoUrl: any;
    public audioUrl: any;
    public videoFormat: any;
    public audioFormat: any;
    public mediaRecorder: any;
    public mediaRecorderAudio: any;
    public recordedBlobs: any;
    public recordedBlobsAudio: any;
    public gumVideo: any;
    public isSecureOrigin: any;
    public constraints: any;
    public btnText: string;
    public btnTextAudio: string;
    public btnVideoPlayback: string;
    public btnAudioPlayback: string;
    public videoFileName: string;
    public audioFileName: string;
    public photoText: string;
    public photoOptions: any;
    public photoTaken: boolean = false;
    public audioOptions: any;
    public recorder: any;
    public isMobile: any;
    public validateMessage: any;
    public previewImgPhoto: any = null;
    public changeVideo: boolean = true;
    public changeAudio: boolean = true;
    public videoRec: boolean = true;
    public audioRec: boolean = true;
    public videoP: boolean = false;
    public audioP: boolean = false;
    public videoR: boolean = false;
    public audioR: boolean = false;
    public photoC: boolean = false;
    public progressValue = 0;
    public progressValuePercentage = this.progressValue + "%";
    public videoDurationTime = 0;
    public setInt: any;
    public videoTimer: any;
    public audioDurationTime = 0;
    public setIntAudio: any;
    public audioTimer: any;
    public stopRecorFlag = 0;
    public foldername: any;
    public mobileVideoUploadURL: any;
    public s3SetInt: any;
    public timerInt: any;
    public flash_photo_first: boolean = true;
    public flash_video_first: boolean = true;
    public flash_audio_first: boolean = true;
    public showElementArray: string[];
    public elements: any;
    public dynamicFrameLoader: boolean = false;
    public isEdit: boolean = false;
    public descriptionValue: any = "";
    public changePlayVideo: boolean = true;
    public invFromType: string;
    private read_more = '';
    private fullDescription: any;
    private IconDisplayNone: any = "none";    
    private default_drop_show: any ;
    private select_drop_show: any;
    public maxFileSizeDiv: any;
    private txtAreaScrol: any;
    private mrgn_desDrop: any;
    public txtAreaHight: any;
    public txtAreaStySmall: string = 'block';
    public txtAreaStyLarge: string = 'none';
    public txtAreaStySmall_AddClass: any;
    public txtAreaPosition: any;
    //public txtAreaLargePosition: any;
    public txtAreaTop: any;
    public btnLargeTop: string = '60px';
    public textAreaDescriptionShow: any
    public invitationPresentOrNot: any;
    public filterTrueArray: any;
    public keynum : any;
    public txtAreaDynamicScale: any;    
    public charPadding : any;
    //invitation image bool
    public displayInvitationStatic: any;
    public displayInvitationDynamic: any;
    public drpInvitationContent: any;
    public drpInvitationColor: any;
    public logBtnPaddingTop = "0";

    public drpInvitationContentHidepen = "none";
    public drpInvitationContentHideselect = "block";
    public displayDropdownArea = "block";
    public txtDynamicAreaStyleLarge = "none";
    public txtStaticAreaStyleLarge = "block";

    constructor(private router: Router, private _location: Location, private invitationBusiness: InvitationBusiness, private fileUpload: FileUpload, private render: Renderer, private route: ActivatedRoute, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
        overlay.defaultViewContainer = vcRef;
        this.mojsBurstButtonAnimation.intializeMojs();
        this.route.params.subscribe(params => {
            console.log("from----", params['type']);
            this.invFromType = params['type'];
        });

        this.showNextPage = 2;

        this.invitationValue = {
            frame_id: "",
            title: "",
            type: "",
            description: "",
            description_only: "",
            image_attributes: {
                avatar: {
                    content_type: "",
                    filename: "",
                    file_data: ""
                }
            },
            video_attributes: {
                avatar: {
                    content_type: "",
                    filename: "",
                    file_data: ""
                }
            },
            audio_attributes: {
                audio: {
                    content_type: "",
                    filename: "",
                    file_data: ""
                }
            }

        }

    }

    ngOnInit() {
        this.drpInvitationContent = 'select or pen your invitation';
        this.drpInvitationColor = '#ff3504';

        this.drpInvitationContentHidepen = "none";
        this.drpInvitationContentHideselect = "block";

        this.pageShowId = 2;
        this.default_drop_show = 'block';
        this.maxFileSizeDiv = "none";
        sessionStorage.setItem('invitationFrame', "false");
        let wishStateGet =  sessionStorage.getItem('wishState');
        if(wishStateGet == 'editInvitation'){
          //alert(wishStateGet);
        //   this.txtAreaHight = '65px';
        //   this.txtAreaScrol = 'auto';
        //   this.mrgn_desDrop = '23px';
        }else{
          //alert(wishStateGet);
        //   this.txtAreaHight = '28px';
        //   this.txtAreaScrol = 'hidden';
        //   this.mrgn_desDrop = '-50px';
        }

        this.loaderService.display(true);
        var that = this;
        var fixed = document.getElementById('loadingDiv');
        fixed.addEventListener('touchmove', function (e) {
            e.preventDefault();
        }, false);

        this.previewImg = null;
        this.previewImgPhoto = null;
        this.isMobile = this.detectMobile();
        this.StudioTitle = 'Add Photo & Frame';
        this.getDescriptionList();
        // this.getFrameList();
        this.constraints = {
            audio: true,
            video: true
        };
        this.photoOptions = {
            audio: false,
            video: true
        };
        this.audioOptions = {
            audio: true,
            video: false
        };
        this.btnText = "Start Video Recording";
        this.btnTextAudio = "Start Audio Recording";
        this.btnVideoPlayback = "Playback";
        this.btnAudioPlayback = "Playback";
        this.photoText = "Webcam";

        this.showElementArray = [
            "default_img",
            "camera_video",
            "preview_video",
            "preview_video_mobile",
            "play--icon",
            "camera_photo",
            "preview_audio",
            "preview_audio1",
            "preview_photo",
            "camera_flash",
            "camera_flash_photo",
            "camera_flash_audio"
        ];

        document.getElementById('camera_video').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('preview_video_mobile').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('camera_photo').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        document.getElementById('preview_photo').style.display = 'none';

        document.getElementById('progressBarShow').style.display = 'none';
        this.progressValue = 0;

        this.progressValuePercentage = this.progressValue + "%";
        document.getElementById('camera_flash').style.display = 'none';
        document.getElementById('camera_flash_photo').style.display = 'none';
        document.getElementById('camera_flash_audio').style.display = 'none';

        document.getElementById('validateMessage').style.display = 'none';
        this.loaderService.display(false);
        this.getInvitationStudio();
        
    }

    ngAfterViewInit() {
        document.getElementById("loadingDiv").style.display = "none";
    }

    generateQuickGuid() {
        return Math.random().toString(36).substring(2, 15) +
            Math.random().toString(36).substring(2, 15);
    }

    onClickedOutside3(e: Event) {
        var drop = document.getElementById("invitationDropdownCheck");
        if (drop.classList.contains('active')) {
            drop.classList.remove('active');
            this.wasClicked = false;
        }else{
            this.drpInvitationContent = 'select or pen your invitation';
            this.drpInvitationColor = '#ff3504';
            this.drpInvitationContentHidepen = "none";
            this.drpInvitationContentHideselect = "block";
        }

        // let drpDwn = document.getElementById("invitationDropdownCheck").className;
        // console.log("content : ",this.invitationValue.description);
        // if (this.invitationValue.description === '') {
            
        //     this.logBtnPaddingTop = "1";
        //     this.dropdownList = 'visible';
        //     this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_true';
        //     this.txtAreaStySmall = 'block';
        //     this.txtAreaStyLarge = 'none';
        //     this.txtAreaPosition = 'absolute';
        //     this.txtAreaTop = '38px auto';
        //     this.charPadding = "1";

        // } else {

        //     this.dropdownList = 'hidden';
        //     this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_false';
        //     this.txtAreaStySmall = 'none';
        //     this.txtAreaStyLarge = 'block';
        //     this.txtAreaPosition = 'relative';
        //     this.txtAreaTop = '0 auto';
        //     this.btnLargeTop = '30px';
        //     this.charPadding = "0";

        // }
    }

    showTextAreaNew(){
        this.logBtnPaddingTop = "0";
        document.getElementById("description").focus();
        // this.txtAreaHight = '65px';
        // this.txtAreaScrol = 'auto';
        // this.mrgn_desDrop = '23px';
        this.txtAreaStySmall = 'none';
        this.txtAreaStyLarge = 'block';
        this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_false';
        this.dropdownList = 'hidden';
        this.txtAreaPosition = 'relative';
        this.txtAreaTop = '0 auto';
        this.btnLargeTop = '30px';
        this.charPadding = "0";
        //margin-top: 30px;
    }

    detectMobile() {
        if (navigator.userAgent.match(/Android/i)
            || navigator.userAgent.match(/webOS/i)
            || navigator.userAgent.match(/iPhone/i)
            || navigator.userAgent.match(/iPad/i)
            || navigator.userAgent.match(/iPod/i)
            || navigator.userAgent.match(/BlackBerry/i)
            || navigator.userAgent.match(/Windows Phone/i)
        ) {
            return true;
        }
        else {
            return false;
        }
    }

    onClick() {
        let drpDwn = document.getElementById("invitationDropdownCheck").className;    
        if(drpDwn == 'wrapper-dropdown'){
          this.drpInvitationContent = 'pen your personal invitation';
          this.drpInvitationColor= '#333';
          this.drpInvitationContentHidepen = "block";
          this.drpInvitationContentHideselect = "none";
        }else{
          this.drpInvitationContent = 'select or pen your invitation';
          this.drpInvitationColor = '#ff3504';
          this.drpInvitationContentHidepen = "none";
          this.drpInvitationContentHideselect = "block";
        }

        this.default_drop_show ='none';
        this.select_drop_show ='block';
        this.wasClicked = !this.wasClicked;
    }
    getDescription(value: any) {
        this.logBtnPaddingTop = "0";

        this.invitationValue.description = value;
        document.getElementById("description").focus();
        // this.txtAreaHight = '65px';
        // this.txtAreaScrol = 'auto';
        // this.mrgn_desDrop = '23px';
        this.txtAreaStySmall = 'none';
        this.txtAreaStyLarge = 'block';
        this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_false';
        this.dropdownList = 'hidden';
        this.txtAreaPosition = 'relative';
        this.txtAreaTop = '0 auto';
        this.btnLargeTop = '30px';
        this.charPadding = "0";
        //margin-top: 30px;
    }

    clearDropdown() {
        this.dropdownList = 'hidden';
    }

    onKeydownTextarea(e: Event){
        let target = e.target || e.srcElement || e.currentTarget;
         
        let self =this;
         if(window.event) {
          self.keynum = e.srcElement.clientHeight; 
          }
    
          if(self.keynum >=197) {
            self.txtAreaDynamicScale = '1';
          }else {
            self.txtAreaDynamicScale = '0';
          }    
      }
      
    showDropdown() {
        if (this.invitationValue.description != '') {
            this.dropdownList = 'hidden';
            this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_false';
            this.txtAreaStySmall = 'none';
            this.txtAreaStyLarge = 'block';
            this.txtAreaPosition = 'relative';
            this.txtAreaTop = '0 auto';
            this.btnLargeTop = '30px';
            this.charPadding = "0";
        } else {
            this.logBtnPaddingTop = "1";
            this.dropdownList = 'visible';
            this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_true';
            this.txtAreaStySmall = 'block';
            this.txtAreaStyLarge = 'none';
            this.txtAreaPosition = 'absolute';
            this.txtAreaTop = '38px auto';
            this.charPadding = "1";
        }
    }

    handleSuccess(that: any) {
        return (stream: any) => {
            //recordButton.disabled = false;
            //console.log('getUserMedia() got stream: ', stream);
            (<any>window).stream = stream;
            //console.log(that);
            document.getElementById('camera_video').style.display = 'block';
            document.getElementById('preview_video').style.display = 'none';
            document.getElementById('camera_photo').style.display = 'none';
            document.getElementById('preview_photo').style.display = 'none';
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "";
            errorTag.style.display = "none";
            if (window.URL) {
                that.gumVideo.src = window.URL.createObjectURL(stream);
            } else {
                that.gumVideo.src = stream;
            }
        }
    }

    handleError(that: any) {
        return (error: any) => {
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "Oops! Please connect to your video/audio device";
            errorTag.style.display = "block";
            document.getElementById('camera_video').style.display = 'none';
            that.error = false;
            var element = document.getElementById("play_btn");
            element.className += " not-allowed";
            var element2 = document.getElementById("record_btn");
            element2.className += " not-allowed";
            //console.log('navigator.getUserMedia error: ', error);
        }
    }
    callNext(event: any) {
        this.textAreaDescriptionShow = '';
        let pageDebugger = this.showNextPage;
        let PageNext = pageDebugger + 1;
        if(PageNext === 5){
            if( this.invitationValue.description == ""){
                return;
            }
         }
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        this.loaderService.display(true);
        setTimeout(() => { 
            this.mojsBurstButtonAnimation.resetMojsStyle(document);
            this.loaderService.display(false);
            this.callNextCode();
          }, this.mojsBurstButtonAnimation.timeOutValue);
    }
    callNextCode() {
        if (!this.videoP && !this.audioP && !this.videoR && !this.audioR) {
           
            if (this.showNextPage < 6) {
                /* For slider image */
                if (this.showNextPage === 3) {
                    this.logBtnPaddingTop = "1";

                    var sliderId = document.querySelector('.swiper-slide-active').id;
                    if(sliderId != this.invitationValue.frame_id)
                       // this.invitationValue.description_only = false;  checkcondition
                    this.invitationValue.frame_id = sliderId;
                }
                this.recordOption = '';
                this.showNextPage = this.showNextPage + 1;
                // if (!this.recordOption) {
                //   this.showNextPage = this.showNextPage + 1;
                // } else {
                //   this.recordOption = '';
                // }
            }
            let errorTag = document.getElementById('validateMessage');
            if (errorTag.textContent != "") {
                errorTag.textContent = "";
                errorTag.style.display = "none";
            }

            if (this.showNextPage === 2) {
                if (!this.isMobile) {
                    let takePictureTag = document.getElementById('photoText');
                    if (takePictureTag.textContent === "Take Picture") {
                        takePictureTag.textContent = "Webcam";
                        this.photoC = false;
                        document.getElementById('camera_photo').style.display = 'none';
                        document.getElementById('camera_flash_photo').style.display = 'none';
                        this.photoText = "Webcam";
                    }
                }
            }

            if (this.showNextPage === 4) {
                if (this.isEdit) {
                    this.invitationValue.description = this.descriptionValue;
                    this.dropdownList = 'hidden';
                }
            }
            this.showText(this.showNextPage);
            if (this.showNextPage === 5) {
                this.logBtnPaddingTop = "0";
                if(this.invitationValue.description == ""){
                    return;
                }else{
                    if (this.invitationType === 'video') {
                        if (!this.videoUrl) {
                            this.invitationType = '';
                        }
                    } else if (this.invitationType === 'audio') {
                        if (!this.audioUrl) {
                            this.invitationType = '';
                        }
                    }
                    var showChar = 150;
                    if (this.invitationValue.description.length > showChar) {
                        this.read_more = this.invitationValue.description.substr(0, showChar);
                    }
                }
            }

        }
    }

    callVideoNext() {
        if (this.showNextPage < 6) {
            this.showNextPage = this.showNextPage + 2;
        }
        this.showText(this.showNextPage);
    }

    RecordingOption(value: any, iType: any) {
        this.recordOption = value;
        this.invitationType = iType;
        if (this.recordOption == 'true') {
            this.StudioTitle = 'Add Voice Recording';
            if (!this.isMobile) {
                this.AudioRecording();
            }
        } else if (this.recordOption == 'false') {
            this.StudioTitle = 'Add Video Recording';
            if (!this.isMobile) {
                this.VideoRecording();
            }
        }
    }

    VideoRecording() {
        let self = this;
        if (this.showNextPage == 3) {
            if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                document.getElementById('preview_video').style.display = 'none';
                document.getElementById('play--icon').style.display = 'none';
                document.getElementById('camera_photo').style.display = 'none';
                document.getElementById('preview_audio').style.display = 'none';
                document.getElementById('preview_audio1').style.display = 'none';
                document.getElementById('preview_photo').style.display = 'none';
                this.gumVideo = document.getElementById("camera_video");
                navigator.mediaDevices.getUserMedia(this.constraints).
                    then(this.handleSuccess(self)).catch(this.handleError(self));
            } else {
                document.getElementById('camera_flash').style.display = 'block';
                document.getElementById('camera_flash_photo').style.display = 'none';
                let frameElement = document.getElementById('frame_content');
                WEBCAM.reset();
                WEBCAM.init();
                WEBCAM.set({
                    width: 265,
                    height: 178,
                    image_format: 'jpeg',
                    jpeg_quality: 90,
                    uploadFormId: '#uploadForm',
                    uploadFieldName: "upload_file[filename]"
                });
                WEBCAM.attach('#camera_flash');
            }
        }
    }

    RecordVideo() {
        this.toggleRecording();
    }

    RecordAudio() {
        this.toggleAudioRecording();
    }

    PlayVideo(event: any) {
        if (!this.videoRec) {
            this.togglePlaying();
        }

    }

    PlayAudio() {
        if (!this.audioRec) {
            this.toggleAudioPlaying();
        }
    }

    handleAudioSuccess(that: any) {
        return (stream: any) => {
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "";
            errorTag.style.display = "none";
            (<any>window).audioStream = stream;
        }
    }


    handleAudioError(that: any) {
        return (error: any) => {
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "Oops! Please connect to your video/audio device";
            errorTag.style.display = "block";
            this.error = false;
            if (this.error == false) {
                var recordBut = <HTMLInputElement>document.getElementById("recordButton");
                var playBut = <HTMLInputElement>document.getElementById("playButton");
                recordBut.disabled = true;
                playBut.disabled = true;
            }
            if (recordBut.disabled == true || playBut.disabled == true) {
                document.getElementById("record_audio_btn").style.pointerEvents = "none";
                document.getElementById("audio_play_btn").style.pointerEvents = "none";
            }
            else {
                document.getElementById("record_audio_btn").style.cursor = "pointer";
                document.getElementById("audio_play_btn").style.cursor = "pointer";
            }
        }
    }

    AudioRecording() {
        let self = this;
        if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
            navigator.mediaDevices.getUserMedia(this.audioOptions).
                then(this.handleAudioSuccess(self)).catch(this.handleAudioError(self));
        } else {
            document.getElementById('camera_flash').style.display = 'none';
            document.getElementById('camera_flash_photo').style.display = 'none';
            document.getElementById('camera_flash_audio').style.display = 'block';
            WEBCAM3.reset();
            WEBCAM3.init();
            WEBCAM3.set({
                width: 265,
                height: 178,
                image_format: 'jpeg',
                jpeg_quality: 90
            });
            WEBCAM3.attach('#camera_flash_audio');
        }
    }

    showText(pageId: any) {
        if (pageId == 5) {
            this.saveStudio = true;
            this.textAreaDescriptionShow = 'textAreaDescriptionShow';
            
        } else {
            this.saveStudio = false;
        }
        if (pageId == 2) {
            this.StudioTitle = 'Add Photo & Frame';
            this.pageShowId = pageId;
            this.someProperty = false;
        }
        else if (pageId == 3) {
            this.StudioTitle = 'Add Voice or Video Recording';
            this.someProperty = true;
            this.pageShowId = pageId;
        }
        else if (pageId == 4) {
            this.StudioTitle = 'Add Text Note';
            this.someProperty = true;
            this.pageShowId = pageId;
        }
        else if (pageId == 5) {
            this.StudioTitle = 'Review Invitation';
            this.someProperty = true;
            this.pageShowId = pageId;
        }
    }

    goBack() {

        if (!this.videoP && !this.audioP && !this.videoR && !this.audioR) {
            if (this.showNextPage > 2) {
                if (!this.recordOption) {
                    var oldValue = this.showNextPage;
                    this.showNextPage = this.showNextPage - 1;
                    if (oldValue == 3 && this.showNextPage !== 3) {
                        //console.log("stop web media....");
                    }
                } else {
                    this.recordOption = '';
                }

            } else if (this.showNextPage == 2) {
                this._location.back();
            }
            let errorTag = document.getElementById('validateMessage');
            if (errorTag.textContent != "") {
                errorTag.textContent = "";
                errorTag.style.display = "none";
            }

            this.showText(this.showNextPage);
        }
    }

    /* For Image upload */
    fileChange(event: any) {
        let fileList: FileList = event.target.files;
        let file: File = fileList[0];

        if (fileList && file) {
            if (file.size <= 6291456) {
                this.maxFileSize = 'none';
                this.maxFileSizeDiv = 'none';
                this.myFile = file;
                this.invitationType = 'image';
                /* For Base64 Image convert */
                var reader = new FileReader();
                reader.onload = this._handleReaderLoaded.bind(this, this.myFile);
                reader.readAsBinaryString(file);
            } else {
                this.maxFileSize = 'visible';
                this.maxFileSizeDiv = 'block';
            }
        }

    }

    moveObject(sendOptions: any) {
        let resList = this.invitationBusiness.previewObject(sendOptions, 'invitation_studios/preview').subscribe((result: any) => {
            this.invitationValue.description_only = false;
            document.getElementById("loadingDiv").style.display = "none";
            document.getElementById('progressBarShow').style.display = 'none';
            this.progressValue = 0;
            this.progressValuePercentage = this.progressValue + "%";
            this.videoUrl = result.data.key;
            document.getElementById('default_img').style.display = 'none';
            document.getElementById('preview_video_mobile').style.display = 'block';
            var previewVideo = document.getElementById('preview_video_mobile');
            //previewVideo.setAttribute('src', result.data.video_url); // For s3 bucketURL
            previewVideo.setAttribute('src', this.mobileVideoUploadURL);

            var self = this;
            previewVideo.addEventListener('ended', this.myHandler(self), false);
            previewVideo.addEventListener('pause', this.myHandlerPause(self), false);
            document.getElementById("loadingDiv").style.display = "none";
            let getFormat = result.data.key.split(".");
            this.videoFormat = getFormat[1];

            this.videoRec = false;
        },
            (error: any) => {
                this.videoUrl = "";
                document.getElementById("loadingDiv").style.display = "none";
                //console.log(error);
                document.getElementById('progressBarShow').style.display = 'none';
                this.progressValue = 0;
                this.progressValuePercentage = this.progressValue + "%";
            });
    }

    /* For Video upload */
    async fileChangeVideo(event: any) {

        let fileList: FileList = event.target.files;
        let file: File = fileList[0];

        this.mobileVideoUploadURL = URL.createObjectURL(file);
        let duration = 0;

        // let formData: FormData = new FormData();
        // formData.append('filename', file.name);
        // formData.append("file_data", file);

        document.getElementById("loadingDiv").style.display = "block";
        let self = this;

        // self.invitationType = 'video';
        // var params: any = { Bucket: TEMP_BUCKET_NAME, Key: file.name, Body: file };
        // let that = self;
        // self.s3.upload(params).on('httpUploadProgress', function (evt) {
        //     let percentage = (evt.loaded * 100) / evt.total;
        //     let roundValue = Math.round(percentage);
        //     //console.log("check this....", that.progressValue);
        //     console.log("Uploaded :: " + ((evt.loaded * 100) / evt.total) + '%');
        //     that.progressValue = roundValue;
        //     that.progressValuePercentage = that.progressValue + "%";
        //     document.getElementById('progressBarShow').style.display = 'block';
        // }).send(function (err: any, data: any) {
        //     console.log("error----", err);
        //     console.log(data);
        //     if (data) {
        //         let sendOptions = {
        //             bucket: data.Bucket,
        //             key: data.Key
        //         };
        //         that.moveObject(sendOptions);
        //     }
        // });

        let videoElement = <HTMLVideoElement>document.getElementById("duration_preview_video");
        videoElement.src = this.mobileVideoUploadURL;
        videoElement.onloadedmetadata = function () {
            duration = videoElement.duration;

            let errorTag = document.getElementById('validateMessage');

            if (file.size > 104857600) {
                errorTag.textContent = "The file size can not exceed 100MB.";
                errorTag.style.display = "block";
                document.getElementById("loadingDiv").style.display = "none";
            } else {
                if (Math.round(duration) == 0) {
                    errorTag.textContent = "This file cannot support to upload.";
                    errorTag.style.display = "block";
                    document.getElementById("loadingDiv").style.display = "none";
                } else {
                    if (Math.round(duration) > 30) {
                        errorTag.textContent = "The duration can not exceed 30 sec.";
                        errorTag.style.display = "block";
                        document.getElementById("loadingDiv").style.display = "none";
                    } else {
                        errorTag.textContent = "";
                        errorTag.style.display = "none";
                        self.invitationType = 'video';
                        //console.log("aws options....", self.awsOptions);
                        //console.log("aws bucket....", TEMP_BUCKET_NAME);
                        var params: any = { Bucket: TEMP_BUCKET_NAME, Key: file.name, Body: file };
                        let that = self;
                        self.s3.upload(params).on('httpUploadProgress', function (evt) {
                            let percentage = (evt.loaded * 100) / evt.total;
                            let roundValue = Math.round(percentage);
                            //console.log("Uploaded :: " + ((evt.loaded * 100) / evt.total) + '%');
                            that.progressValue = roundValue;
                            that.progressValuePercentage = that.progressValue + "%";
                            document.getElementById('progressBarShow').style.display = 'block';
                        }).send(function (err: any, data: any) {
                            //console.log("error----", err);
                            //console.log(data);
                            if (data) {
                                let sendOptions = {
                                    bucket: data.Bucket,
                                    key: data.Key
                                };
                                that.moveObject(sendOptions);
                            }
                        });
                    }
                }
            }
        };

    }

    async fileChangeAudio(event: any) {
        document.getElementById("loadingDiv").style.display = "block";

        this.invitationType = 'audio';

        let fileList: FileList = event.target.files;
        let file: File = fileList[0];

        let formData: FormData = new FormData();
        formData.append('filename', file.name);
        formData.append("file_data", file);
    }

    /* For Base64 Image convert */
    _handleReaderLoaded(fileData: any, readerEvt: any) {
        var binaryString = readerEvt.target.result;
        this.invitationValue.description_only = false;
        this.base64textString = btoa(binaryString);
        this.displayInvitationStatic = 'none';
        this.previewImg = "data:" + fileData.type + ";base64," + this.base64textString;
        document.getElementById('default_img').style.display = 'block';
        document.getElementById('camera_video').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('camera_photo').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        document.getElementById('preview_photo').style.display = 'none';
        document.getElementById('preview_video_mobile').style.display = 'none';
    }

    /* End Image upload */


    async getInvitationStudio() {
        let resList = await this.invitationBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
            if(result.response == false){
                this.displayInvitationStatic = 'block';
                this.invitationPresentOrNot = 'notpresent';
                sessionStorage.setItem('invitationFrame', "false");
                this.getFrameList();
            }else{
                this.previewImg = result.message.invitation.img_url;                
                this.displayInvitationStatic = 'none';
                this.invitationPresentOrNot = 'present';
                var fid = result.message.invitation.frame_id;
                console.log('Frame Id : ', fid);
                sessionStorage.setItem('invitationFrame', fid);
                this.getFrameList();
            }
            
            if (result.response) {
                this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_false';
                this.txtAreaStySmall = 'none';
                this.txtAreaStyLarge = 'block';
                this.txtAreaPosition = 'relative';
                this.txtAreaTop = '0 auto';
                this.btnLargeTop = '30px';
                this.charPadding = "0";

                this.isEdit = true;
                this.descriptionValue = result.message.invitation.description;
                this.invitationValue = {
                    frame_id: result.message.invitation.frame_id,
                    title: "",
                    description_only: true,
                    type: result.message.type,
                    description: "",
                    image_attributes: {
                        avatar: {
                            content_type: "",
                            filename: "",
                            file_data: ""
                        }
                    },
                    video_attributes: {
                        avatar: {
                            content_type: "",
                            filename: "",
                            file_data: ""
                        }
                    },
                    audio_attributes: {
                        audio: {
                            content_type: "",
                            filename: "",
                            file_data: ""
                        }
                    }

                }
            } else {
                this.txtAreaStySmall_AddClass = 'txtAreaStySmall_AddClass_true';
                this.txtAreaStySmall = 'block';
                this.txtAreaStyLarge = 'none';
                this.txtAreaPosition = 'absolute';
                this.txtAreaTop = '38px auto';
                this.charPadding = "0";
                this.btnLargeTop = '--';
                this.isEdit = false;
            }
        },
            (error) => {
                //console.log(error);
            });
    }


    async getDescriptionList() {
        let resList = await this.invitationBusiness.getListAPI('get_dropdown').subscribe((result) => {
            if (result.response) {
                if (result.data.length > 1) {
                    this.descriptionList = result.data[1].dropdownvalue;
                } else {
                    this.dropdownList = 'hidden';
                }
                console.log(result.data[1].dropdownvalue);
            }
        },
            (error) => {
                //console.log(error);
            });
    }

    async getFrameList() {
        let fid : any;
        let getFrameID = sessionStorage.getItem('invitationFrame');
        if(getFrameID == 'false'){
            fid = 1;
        }else{
            fid = getFrameID;
        }

        let resList = await this.invitationBusiness.getListAPI('get_frames').subscribe((result) => {            
            if (result.response) {
                let trueData = [];
                let falseData = [];
                //console.log('total frames : ', result.data.length);
                for(let i = 0; i < result.data.length; i++){
                    //console.log('Result set : ',result.data[i].id);
                    if(result.data[i].id >= fid){
                       let trueArray = { "id": result.data[i].id, "frameImage": result.data[i].image.avatar.url};                       
                       trueData.push(trueArray);
                    }else{
                        //console.log('correct')
                        let falseArray = { "id": result.data[i].id, "frameImage": result.data[i].image.avatar.url};
                        falseData.push(falseArray);
                    }
                    //console.log(trueData);

                    var finalArray = trueData.concat(falseData);
                    this.filterTrueArray = finalArray; //trueData
                }
                this.frameList = result.data;
                this.dynamicFrameLoader = true;
            }
        },
        (error) => {
                //console.log(error);
        });
    }

    moveVideoObject(sendOptions: any) {
        let resList = this.invitationBusiness.previewObject(sendOptions, 'invitation_studios/preview').subscribe((result: any) => {
            this.invitationValue.description_only = false;
            document.getElementById('progressBarShow').style.display = 'none';
            this.progressValue = 0;
            this.progressValuePercentage = this.progressValue + "%";
            this.videoUrl = result.data.key;
            var previewVideo = document.getElementById('preview_video');
            previewVideo.setAttribute('src', result.data.video_url); // For s3 bucketURL
            document.getElementById('default_img').style.display = 'none';
            document.getElementById('camera_video').style.display = 'none';
            document.getElementById('preview_video').style.display = 'block';
            var self = this;
            previewVideo.addEventListener('ended', this.myHandler(self), false);
            document.getElementById("loadingDiv").style.display = "none";
            let getFormat = result.data.key.split(".");
            this.videoFormat = getFormat[1];
        },
            (error: any) => {
                this.videoUrl = "";
                document.getElementById("loadingDiv").style.display = "none";
                document.getElementById('progressBarShow').style.display = 'none';
                this.progressValue = 0;
                this.progressValuePercentage = this.progressValue + "%";
            });
    }

    moveAudioObject(sendOptions: any) {
        let resList = this.invitationBusiness.previewObject(sendOptions, 'invitation_studios/preview').subscribe((result: any) => {
            this.invitationValue.description_only = false;
            document.getElementById('progressBarShow').style.display = 'none';
            this.progressValue = 0;
            this.progressValuePercentage = this.progressValue + "%";

            document.getElementById('default_img').style.display = 'none';
            document.getElementById('camera_video').style.display = 'none';
            document.getElementById('preview_video').style.display = 'none';

            document.getElementById("loadingDiv").style.display = "none";
            let getFormat = result.data.key.split(".");
            this.audioFormat = getFormat[1];

            this.audioUrl = result.data.key;
            var previewAudio = document.getElementById('preview_audio');
            previewAudio.setAttribute('src', result.data.video_url); // For s3 bucketURL
            document.getElementById('preview_audio1').style.display = 'block';
            document.getElementById('preview_audio').style.display = 'block';
            var self = this;
            previewAudio.addEventListener('ended', this.myHandlerAudio(self), false);
            document.getElementById("loadingDiv").style.display = "none";
        },
            (error: any) => {
                this.audioUrl = "";
                document.getElementById("loadingDiv").style.display = "none";
                document.getElementById('progressBarShow').style.display = 'none';
                this.progressValue = 0;
                this.progressValuePercentage = this.progressValue + "%";
            });
    }

    async sendVideo() {
        document.getElementById("loadingDiv").style.display = "block";

        var blob = new Blob(this.recordedBlobs, { type: 'video/webm' });//recordRTC instanceof Blob ? recordRTC : recordRTC.blob;
        var fileType = blob.type.split('/')[0] || 'audio';
        var fileName = (Math.random() * 1000).toString().replace('.', '');

        if (fileType === 'audio') {
            fileName += '.' + (!!(<any>navigator).mozGetUserMedia ? 'ogg' : 'wav');
        } else if (fileType === 'mp4') {
            fileName += '.mp4';
        } else {
            fileName += '.webm';
        }

        this.videoFileName = fileName;

        var params: any = { Bucket: TEMP_BUCKET_NAME, Key: fileName, Body: blob };
        let that = this;
        this.s3.upload(params).on('httpUploadProgress', function (evt) {
            let percentage = (evt.loaded * 100) / evt.total;
            let roundValue = Math.round(percentage);
            that.progressValue = roundValue;
            that.progressValuePercentage = that.progressValue + "%";
            document.getElementById('progressBarShow').style.display = 'block';
        }).send(function (err: any, data: any) {
            if (data) {
                let sendOptions = {
                    bucket: data.Bucket,
                    key: data.Key
                };
                that.moveVideoObject(sendOptions);
            }
        });
    }

    async sendAudio() {
        document.getElementById("loadingDiv").style.display = "block";
        var blob = new Blob(this.recordedBlobsAudio, { type: 'audio/webm' });//recordRTC instanceof Blob ? recordRTC : recordRTC.blob;
        var fileName = (Math.random() * 1000).toString().replace('.', '');
        fileName += '.webm';
        this.audioFileName = fileName;

        var params: any = { Bucket: TEMP_BUCKET_NAME, Key: fileName, Body: blob };
        let that = this;
        this.s3.upload(params).on('httpUploadProgress', function (evt) {
            let percentage = (evt.loaded * 100) / evt.total;
            let roundValue = Math.round(percentage);
            that.progressValue = roundValue;
            that.progressValuePercentage = that.progressValue + "%";
            document.getElementById('progressBarShow').style.display = 'block';
        }).send(function (err: any, data: any) {
            if (data) {
                let sendOptions = {
                    bucket: data.Bucket,
                    key: data.Key
                };
                that.moveAudioObject(sendOptions);
            }
        });
    }

    myHandler(that: any) {
        return (event: any) => {
            if (this.isMobile) {
                let videoTag: any = document.getElementById('preview_video_mobile');
                videoTag.webkitExitFullscreen();
                //document.mozCancelFullScreen();
            }
            that.changePlayVideo = true;
            that.videoP = false;
            that.btnVideoPlayback = "Playback";
        }
    }

    myHandlerPause(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                that.videoP = false;
                that.changePlayVideo = true;
            }
        }
    }

    myHandlerAudio(that: any) {
        return (event: any) => {
            that.audioP = false;
            that.btnAudioPlayback = "Playback";
        }
    }

    randomString(length: any) {
        var result = '';
        var temp = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        for (var i = length; i > 0; --i) result += temp[Math.round(Math.random() * (temp.length - 1))];
        return result;
    }

    async saveInvitation(invitationData: any, event:any) {
        debugger
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        document.getElementById("loadingDiv").style.display = "block";
        if (this.invitationType == 'video') {
            if (this.videoUrl) {
                this.invitationValue.type = 'video';
                this.invitationValue.video_attributes = {
                    avatar: {
                        "filename": this.videoUrl,
                        "content_type": "video/" + this.videoFormat,
                        "file_data": this.videoUrl
                    }
                }

                let resList = await this.invitationBusiness.invitationSave(this.invitationValue, 'invitation_studios').subscribe((result) => {
                    if (result) {
                        if (result.response) {
                            this.videoUrl = '';
                            this.audioUrl = '';
                            document.getElementById("loadingDiv").style.display = "none";

                            this.router.navigate(['invitationsuccess/' + this.invFromType]);
                        }
                    } else {
                        document.getElementById("loadingDiv").style.display = "none";
                    }
                },
                    (error) => {
                        document.getElementById("loadingDiv").style.display = "none";

                    });
            }

        } else if (this.invitationType == 'audio') {
            if (this.audioUrl) {
                this.invitationValue.type = 'audio';
                this.invitationValue.audio_attributes = {
                    audio: {
                        "filename": this.audioUrl,
                        "content_type": "audio/" + this.audioFormat,
                        "file_data": this.audioUrl
                    }
                }

                let resList = await this.invitationBusiness.invitationSave(this.invitationValue, 'invitation_studios').subscribe((result) => {
                    if (result) {
                        if (result.response) {
                            this.videoUrl = '';
                            this.audioUrl = '';
                            document.getElementById("loadingDiv").style.display = "none";

                            this.router.navigate(['invitationsuccess/' + this.invFromType]);
                        }
                    } else {
                        document.getElementById("loadingDiv").style.display = "none";
                    }
                },
                    (error) => {
                        document.getElementById("loadingDiv").style.display = "none";

                    });
            }

        } else {
            if (this.myFile || this.photoTaken) {
                if (this.photoTaken) {
                    this.invitationValue.type = 'image';
                    let tempURL = this.base64textString.toLowerCase();
                    let extension;

                    let xtempURL = tempURL.split(";");
                    let ytempURL = xtempURL[0];

                    if (ytempURL.indexOf("png") !== -1)
                        extension = "png"
                    else if (ytempURL.indexOf("jpg") !== -1 || ytempURL.indexOf("jpeg") !== -1)
                        extension = "jpg"
                    else
                        extension = "jpg"

                    let photoFilename = this.randomString(10) + "." + extension;

                    this.invitationValue.image_attributes = {
                        avatar: {
                            "content_type": "image/" + extension,
                            "filename": photoFilename,
                            "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")
                        }
                    }
                } else {
                    this.invitationValue.type = 'image';
                    this.invitationValue.image_attributes = {
                        avatar: {
                            "content_type": this.myFile.type,
                            "filename": this.myFile.name,
                            "file_data": this.base64textString
                        }
                    }
                }
            } else {
                this.invitationValue.type = 'image';
                let defaultImageTag = document.getElementById("defaultImg");
                var c: any = document.getElementById("drawCanvasDefaultImg");
                var ctx = c.getContext("2d");
                ctx.drawImage(defaultImageTag, 0, 0, c.width, c.height);
                this.base64textString = c.toDataURL('image/jpeg', 1.0);
                let tempURL = this.base64textString.toLowerCase();
                let extension;

                let xtempURL = tempURL.split(";");
                let ytempURL = xtempURL[0];

                if (ytempURL.indexOf("png") !== -1)
                    extension = "png"
                else if (ytempURL.indexOf("jpg") !== -1 || ytempURL.indexOf("jpeg") !== -1)
                    extension = "jpg"
                else
                    extension = "jpg"

                let photoFilename = this.randomString(10) + "." + extension;

                this.invitationValue.image_attributes = {
                    avatar: {
                        "content_type": "image/" + extension,
                        "filename": photoFilename,
                        "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")
                    }
                }

            }

            let resList = await this.invitationBusiness.invitationSave(invitationData, 'invitation_studios').subscribe((result) => {
                if (result) {
                    if (result.response) {
                        document.getElementById("loadingDiv").style.display = "none";
                        this.videoUrl = '';
                        this.audioUrl = '';
                        localStorage.setItem("inviteImage", result.message.image);
                        this.router.navigate(['invitationsuccess/' + this.invFromType]);
                    }
                } else {
                    document.getElementById("loadingDiv").style.display = "none";
                }
            },
                (error) => {
                    document.getElementById("loadingDiv").style.display = "none";
                });
        }

    }

    toggleRecording() {
        if (!this.videoP) {
            var recordButton = document.getElementById("record_btn");
            if (recordButton.textContent === 'Start Video Recording') {
                if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                    this.btnText = "Stop Video Recording";
                    document.getElementById('camera_video').style.display = 'block';
                    document.getElementById('preview_video').style.display = 'none';
                    document.getElementById('play--icon').style.display = 'none';
                    document.getElementById('camera_photo').style.display = 'none';
                    document.getElementById('preview_audio').style.display = 'none';
                    document.getElementById('preview_audio1').style.display = 'none';
                    document.getElementById('preview_photo').style.display = 'none';
                    this.startRecording();
                } else {
                    if (!WEBCAM.params.cam_error) {
                        this.btnText = "Stop Video Recording";
                        this.foldername = this.generateQuickGuid();
                        document.getElementById('camera_flash').style.display = 'block';
                        this.videoRec = true;
                        this.videoR = true;
                        this.videoDurationTime = 30;
                        this.changeVideo = false;
                        this.invitationValue.description_only = false;
                        this.startRecordingFlash();
                    }
                }
            } else {
                if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                    this.stopRecording();
                } else {
                    this.stopRecordingFlash();
                }
                this.btnText = "Start Video Recording";
            }
        }
    }

    toggleAudioRecording() {
        if (!this.audioP) {
            var recordAudioButton = document.getElementById("record_audio_btn");
            if (recordAudioButton.textContent === 'Start Audio Recording') {
                if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                    this.btnTextAudio = "Stop Audio Recording";
                    document.getElementById('camera_video').style.display = 'none';
                    document.getElementById('preview_video').style.display = 'none';
                    document.getElementById('play--icon').style.display = 'none';
                    document.getElementById('camera_photo').style.display = 'none';
                    document.getElementById('preview_audio').style.display = 'none';
                    document.getElementById('preview_audio1').style.display = 'block';
                    document.getElementById('preview_photo').style.display = 'none';
                    this.startAudioRecording();
                } else {
                    if (!WEBCAM3.params.audio_error) {
                        this.btnTextAudio = "Stop Audio Recording";
                        this.foldername = this.generateQuickGuid();
                        this.changeAudio = false;
                        this.audioRec = true;
                        this.audioR = true;
                        this.audioDurationTime = 30;
                        this.invitationValue.description_only = false;
                        this.startAudioRecordingFlash();
                    }
                }
            } else {
                if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                    document.getElementById('camera_video').style.display = 'none';
                    document.getElementById('preview_video').style.display = 'none';
                    document.getElementById('play--icon').style.display = 'none';
                    document.getElementById('camera_photo').style.display = 'none';
                    document.getElementById('preview_audio').style.display = 'none';
                    document.getElementById('preview_audio1').style.display = 'block';
                    document.getElementById('preview_photo').style.display = 'none';
                    this.stopAudioRecording();
                } else {
                    this.stopAudioRecordingFlash();
                }
                this.btnTextAudio = "Start Audio Recording";
            }
        }
    }

    togglePlaying() {
        var playButton = document.getElementById("play_btn");
        if (playButton.textContent === 'Playback') {
            this.btnVideoPlayback = "Stop";
            this.playVideo();
        } else {
            this.stopVideo();
            this.btnVideoPlayback = "Playback";
        }
    }

    toggleAudioPlaying() {
        var playButton = document.getElementById("audio_play_btn");
        if (playButton.textContent === 'Playback') {
            this.btnAudioPlayback = "Stop";
            this.playAudio();
        } else {
            this.stopAudio();
            this.btnAudioPlayback = "Playback";
        }
    }

    playVideo() {
        if (this.isMobile) {
            var previewVideoMobile: any = <HTMLInputElement>document.getElementById('preview_video_mobile');           
            if (previewVideoMobile.paused) {
                this.videoP = true;
                this.changePlayVideo = false;                
                previewVideoMobile.play();
            }
            else {
                this.videoP = false;
                this.changePlayVideo = true;
                previewVideoMobile.pause();
            }
        } else {
            var previewVideo: any = document.getElementById('preview_video');
            if (previewVideo.paused) {
                this.videoP = true;
                this.changePlayVideo = false;
                previewVideo.play();
            }
            else {
                this.videoP = false;
                this.changePlayVideo = true;
                previewVideo.pause();
            }
        }
    }

    stopVideo() {
        if (this.isMobile) {
            var previewVideoMobile: any = document.getElementById('preview_video_mobile');
            if (previewVideoMobile.paused) {
                this.videoP = true;
                this.changePlayVideo = false;
                previewVideoMobile.play();
            }
            else {
                this.videoP = false;
                this.changePlayVideo = true;
                previewVideoMobile.pause();
            }
        } else {
            var previewVideo: any = document.getElementById('preview_video');
            if (previewVideo.paused) {
                this.videoP = true;
                this.changePlayVideo = false;
                previewVideo.play();
            }
            else {
                this.videoP = false;
                this.changePlayVideo = true;
                previewVideo.pause();
            }
        }
    }

    playAudio() {
        var previewAudio: any = document.getElementById('preview_audio');
        if (previewAudio.paused) {
            this.audioP = true;
            previewAudio.play();
        }
        else {
            this.audioP = false;
            previewAudio.pause();
        }
    }


    stopAudio() {
        var previewAudio: any = document.getElementById('preview_audio');
        if (previewAudio.paused) {
            this.audioP = true;
            previewAudio.play();
        }
        else {
            this.audioP = false;
            previewAudio.pause();
        }
    }

    base64toBlob(base64Str: any) {
        var byteCharacters = atob(base64Str.replace(/^data:image\/(png|jpeg|jpg);base64,/, ''));
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters
                .charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], {
            type: undefined
        });

        return blob;
    }


    startRecordingFlash() {

        i_increment++;
        idx++;
        let that = this;

        if (onetimeRun) {
            this.timerInt = setInterval(() => {
                timerCount += 1;
                if (this.videoDurationTime < 10)
                    this.videoTimer = "00:0" + this.videoDurationTime;
                else
                    this.videoTimer = "00:" + this.videoDurationTime;

                document.getElementById('videoTimer').style.display = "block";

                if (this.videoDurationTime == 0) {
                    clearInterval(this.timerInt);
                    document.getElementById('videoTimer').style.display = "none";
                    this.stopRecorFlag = 1;
                } else {
                    this.videoDurationTime -= 1;
                }
            }, 1000);
            onetimeRun = false;
        }

        WEBCAM.snap(function (data_uri: any) {
            let blobFlash = that.base64toBlob(data_uri);
            var params: any = { Bucket: TEMP_BUCKET_NAME, Key: that.foldername + "/" + "capture" + i_increment + ".jpg", Body: blobFlash };
            that.s3.upload(params).on('httpUploadProgress', function (evt: any) {
                //console.log("uploading...", evt);
            }).send(function (err: any, data: any) {
                j_increment++;
            });
        });

        if (timerCount === 30) {
            this.stopRecorFlag = 1;
        }
        if (this.stopRecorFlag == 0) {
            if (idx == 1) {
                WEBCAM.record(30000);
            }
            setTimeout(function () {
                that.startRecordingFlash();
            }, 1);
        }
        else {
            WEBCAM.stop();//Recording Stopping
            this.changeVideo = true;
            document.getElementById("loadingDiv").style.display = "block";
            document.getElementById('default_img').style.display = 'none';
            document.getElementById('camera_flash').style.display = 'none';
            document.getElementById('camera_flash_photo').style.display = 'none';

            this.btnText = "Start Video Recording";

            clearInterval(this.timerInt);

            document.getElementById('videoTimer').style.display = "none";

            this.videoRec = false;
            this.videoR = false;

            this.s3SetInt = setInterval(() => {
                if (idx == j_increment) {
                    clearInterval(this.s3SetInt);
                    let offsetValue = 1
                    if (timerCount > 15) {
                        offsetValue = 2;
                    }
                    let fps = (idx / (timerCount + offsetValue)).toFixed(2);
                    WEBCAM.send(baseURL + 'invitation_studios/get_video_shot?folder=' + this.foldername + '&file_count=' + idx + '&fps=' + fps + '&Authorization=' + localStorage.getItem("token"));
                    idx = 0;
                    i_increment = 0;
                    j_increment = 0;
                    let reqInt = setInterval(() => {
                        let temp = WEBCAM.params.returnUrl;
                        //console.log(temp);
                        if (temp) {
                            clearInterval(reqInt);
                            let jsonResult = JSON.parse(temp);
                            this.videoUrl = jsonResult.message.video_url;
                            //console.log("this jsonResult.....", jsonResult);
                            var previewVideo = document.getElementById('preview_video');
                            //previewVideo.setAttribute('src', result.data.video_url); // For s3 bucketURL
                            previewVideo.setAttribute('src', jsonResult.message.video_url);
                            document.getElementById('default_img').style.display = 'none';
                            document.getElementById('preview_video').style.display = 'block';
                            var self = this;
                            previewVideo.addEventListener('ended', this.myHandler(self), false);
                            let getFormat = jsonResult.message.video_url.split(".");
                            this.videoFormat = getFormat[1];
                            WEBCAM.setReturnUrl('');
                            document.getElementById("loadingDiv").style.display = "none";
                        }
                    }, 500);
                    this.stopRecorFlag = 0;
                    onetimeRun = true;
                    timerCount = 0;
                }
            }, 1000);

            return false;
        }
    }

    startRecording() {
        this.changeVideo = false;
        let self = this;
        this.videoRec = true;
        this.videoR = true;
        this.recordedBlobs = [];
        this.videoDurationTime = 30;
        var options = { mimeType: 'video/webm;codecs=vp9' };
        if (!MediaRecorder.isTypeSupported(options.mimeType)) {
            //console.log(options.mimeType + ' is not Supported');
            options = { mimeType: 'video/webm;codecs=vp8' };
            if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                //console.log(options.mimeType + ' is not Supported');
                options = { mimeType: 'video/webm' };
                if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                    //console.log(options.mimeType + ' is not Supported');
                    options = { mimeType: '' };
                }
            }
        }
        try {
            this.mediaRecorder = new MediaRecorder((<any>window).stream, options);
        } catch (e) {
            //console.error('Exception while creating MediaRecorder: ' + e);
            //console.error('Exception while creating MediaRecorder: ' + e + '. mimeType: ' + options.mimeType);
            return;
        }
        //console.log('Created MediaRecorder', this.mediaRecorder, 'with options', options);
        //recordButton.textContent = 'Stop Recording';
        //playButton.disabled = true;
        //downloadButton.disabled = true;
        this.setInt = setInterval(() => {
            if (this.videoDurationTime < 10)
                this.videoTimer = "00:0" + this.videoDurationTime;
            else
                this.videoTimer = "00:" + this.videoDurationTime;

            document.getElementById('videoTimer').style.display = "block";

            if (this.videoDurationTime == 0) {
                clearInterval(this.setInt);
                document.getElementById('videoTimer').style.display = "none";
                this.toggleRecording();
            } else {
                this.videoDurationTime -= 1;
            }
        }, 1000);
        this.invitationValue.description_only = false;
        this.mediaRecorder.onstop = this.handleStop;
        this.mediaRecorder.ondataavailable = this.handleDataAvailable(self);
        this.mediaRecorder.start(10); // collect 10ms of data
        //console.log('MediaRecorder started', this.mediaRecorder);
    }

    handleStop(event: any) {
        //console.log('Recorder stopped: ', event);
    }

    handleStopAudio(event: any) {
        //console.log('Audio Recorder stopped: ', event);
    }

    handleDataAvailable(that: any) {
        return (event: any) => {
            if (event.data && event.data.size > 0) {
                that.recordedBlobs.push(event.data);
            }
        }
    }

    handleDataAvailableAudio(that: any) {
        return (event: any) => {
            if (event.data && event.data.size > 0) {
                that.recordedBlobsAudio.push(event.data);
            }
        }
    }

    stopRecording() {
        clearInterval(this.setInt);
        document.getElementById('videoTimer').style.display = "none";
        document.getElementById('camera_video').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('camera_photo').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        document.getElementById('preview_photo').style.display = 'none';
        this.changeVideo = true;
        this.mediaRecorder.stop();
        // if ((<any>window).stream) {
        //     (<any>window).stream.getAudioTracks().forEach(function (track: any) {
        //         console.log("track0", track);
        //         track.stop();
        //     });

        //     (<any>window).stream.getVideoTracks().forEach(function (track: any) {
        //         console.log("track1", track);
        //         track.stop();
        //     });

        //     (<any>window).stream = null;
        // }
        this.videoRec = false;
        this.videoR = false;
        //console.log('Recorded Blobs: ', this.recordedBlobs);
        this.sendVideo();
    }

    stopRecordingFlash() {
        this.stopRecorFlag = 1;
    }

    startAudioRecordingFlash() {
        this.setIntAudio = setInterval(() => {
            if (this.audioDurationTime < 10)
                this.audioTimer = "00:0" + this.audioDurationTime;
            else
                this.audioTimer = "00:" + this.audioDurationTime;

            document.getElementById('audioTimer').style.display = "block";

            if (this.audioDurationTime == 0) {
                clearInterval(this.setIntAudio);
                document.getElementById('audioTimer').style.display = "none";
                this.toggleAudioRecording();
            } else {
                this.audioDurationTime -= 1;
            }
        }, 1000);

        WEBCAM3.record(30000);
    }

    startAudioRecording() {
        this.changeAudio = false;
        let self = this;
        this.audioRec = true;
        this.audioR = true;
        this.recordedBlobsAudio = [];
        this.audioDurationTime = 30;
        //let audioRecOptions = { mimeType: 'audio/webm' };
        try {
            //this.mediaRecorderAudio = new MediaRecorder((<any>window).audioStream, audioRecOptions);
            this.mediaRecorderAudio = new MediaRecorder((<any>window).audioStream);
        } catch (e) {
            //console.error('Audio Exception while creating MediaRecorder: ' + e);
            return;
        }
        //console.log('Audio Created MediaRecorder', this.mediaRecorderAudio);
        this.setIntAudio = setInterval(() => {
            if (this.audioDurationTime < 10)
                this.audioTimer = "00:0" + this.audioDurationTime;
            else
                this.audioTimer = "00:" + this.audioDurationTime;

            document.getElementById('audioTimer').style.display = "block";

            if (this.audioDurationTime == 0) {
                clearInterval(this.setIntAudio);
                document.getElementById('audioTimer').style.display = "none";
                this.toggleAudioRecording();
            } else {
                this.audioDurationTime -= 1;
            }
        }, 1000);
        this.invitationValue.description_only = false;
        this.mediaRecorderAudio.onstop = this.handleStopAudio;
        this.mediaRecorderAudio.ondataavailable = this.handleDataAvailableAudio(self);
        this.mediaRecorderAudio.start(10); // collect 10ms of data
        //console.log('Audio MediaRecorder started', this.mediaRecorderAudio);
    }

    stopAudioRecordingFlash() {
        clearInterval(this.setIntAudio);
        document.getElementById('audioTimer').style.display = "none";
        WEBCAM3.stop();
        document.getElementById("loadingDiv").style.display = "block";
        WEBCAM3.send(baseURL + 'invitation_studios/preview_audio?folder=' + this.foldername + '&Authorization=' + localStorage.getItem("token"));
        let reqInt = setInterval(() => {
            let temp = WEBCAM3.params.returnUrl;
            if (temp) {
                clearInterval(reqInt);
                let jsonResult = JSON.parse(temp);
                this.audioUrl = jsonResult.message.audio_url;
                //console.log("this jsonResult.....", jsonResult);
                document.getElementById("camera_flash_audio").style.display = "none";
                document.getElementById("camera_flash_audio").style.zIndex = "100";
                var previewAudio = document.getElementById('preview_audio');
                previewAudio.setAttribute('src', jsonResult.message.audio_url); // For s3 bucketURL
                document.getElementById('preview_audio1').style.display = 'block';
                document.getElementById('preview_audio').style.display = 'block';
                var self = this;
                previewAudio.addEventListener('ended', this.myHandlerAudio(self), false);
                let getFormat = jsonResult.message.audio_url.split(".");
                this.audioFormat = getFormat[1];
                WEBCAM3.setReturnUrl('');
                document.getElementById("loadingDiv").style.display = "none";
            }
        }, 500);
        this.changeAudio = true;
        this.audioRec = false;
        this.audioR = false;

    }

    stopAudioRecording() {
        clearInterval(this.setIntAudio);
        document.getElementById('audioTimer').style.display = "none";
        this.changeAudio = true;
        this.mediaRecorderAudio.stop();
        this.audioRec = false;
        this.audioR = false;
        //console.log('Audio Recorded Blobs: ', this.recordedBlobsAudio);
        this.sendAudio();
    }


    handlePhotoSuccess(that: any) {
        return (stream: any) => {
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "";
            errorTag.style.display = "none";
            //console.log('photo getUserMedia() got stream: ', stream);
            (<any>window).photoStream = stream;
            document.getElementById('camera_photo').style.display = 'block';
            var photoDiv: any = document.getElementById('camera_photo');
            if (window.URL) {
                photoDiv.src = window.URL.createObjectURL(stream);
            } else {
                photoDiv.src = stream;
            }
            document.getElementById("photoText").textContent = "Take Picture";
            that.photoText = "Take Picture";
            that.photoTaken = false;
            document.getElementById("loadingDiv").style.display = "none";

        }
    }

    handlePhotoError(that: any) {
        return (error: any) => {
            that.photoC = true;
            let errorTag = document.getElementById('validateMessage');
            errorTag.textContent = "Oops! Please connect to your video/audio device";
            errorTag.style.display = "block";
            document.getElementById('camera_photo').style.display = 'none';
            //this.error = false;
            // if (this.error == false) {
            //     var element = document.getElementById("play_btn");
            //     element.className += " not-allowed";
            //     var element2 = document.getElementById("record_btn");
            //     element2.className += " not-allowed";
            // }
            //console.log('Photo navigator.getUserMedia error: ', error);
            document.getElementById("loadingDiv").style.display = "none";

        }
    }

    takePicture() {
        var photoButton = document.getElementById("photoText");

        if (photoButton.textContent === 'Webcam') {

            if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                document.getElementById("loadingDiv").style.display = "block";
                document.getElementById('preview_photo').style.display = 'none';
                //document.getElementById('camera_photo').style.display = 'block';
                this.initializePhoto();
            } else {
                document.getElementById('camera_flash').style.display = 'none';
                document.getElementById('camera_flash_photo').style.display = 'block';
                //if (this.flash_photo_first) {
                //WEBCAM.setSWFLocation('./flash/webcam.swf');
                WEBCAM2.reset();
                WEBCAM2.init();
                WEBCAM2.set({
                    width: 265,
                    height: 178,
                    image_format: 'jpeg',
                    jpeg_quality: 90
                });
                WEBCAM2.attach('#camera_flash_photo');

                //this.flash_photo_first = false;
                //}

                //document.getElementById("photoText").textContent = "Take Picture";
                //this.photoText = "Take Picture";
                this.photoTaken = false;

                setTimeout(function () {
                    if (!WEBCAM2.params.cam_error) {
                        this.photoC = true;
                        document.getElementById("photoText").textContent = "Take Picture";
                        this.photoText = "Take Picture";
                    }
                }, 2000);
            }
        } else if (photoButton.textContent === "Take Picture") {
            this.photoC = false;
            this.invitationValue.description_only = false;
            if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
                document.getElementById('camera_photo').style.display = 'none';
                this.capturePhoto();
            } else {
                let self = this;
                if (!WEBCAM2.params.cam_error) {
                    WEBCAM2.snap(function (data_uri: any) {
                        //console.log(data_uri);
                        self.base64textString = data_uri;
                        this.displayInvitationStatic = 'none';
                        self.previewImg = data_uri;
                        document.getElementById('camera_flash_photo').style.display = 'none';
                        document.getElementById('camera_flash').style.display = 'none';
                        self.photoText = "Webcam";
                        document.getElementById("photoText").textContent = "Webcam";
                        self.photoTaken = true;
                        self.invitationType = 'image';
                    });
                }
            }
        }
    }

    initializePhoto() {
        let self = this;
        this.photoC = true;
        navigator.mediaDevices.getUserMedia(this.photoOptions).
            then(this.handlePhotoSuccess(self)).catch(this.handlePhotoError(self));
    }

    capturePhoto() {
        //console.log("image capture area....");
        var video = document.getElementById("camera_photo");
        var canvas: any = document.getElementById("drawCanvas");
        var ctx = canvas.getContext("2d");
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        var dataURL = canvas.toDataURL('image/jpeg', 1.0);
        //console.log(dataURL);
        this.previewImgPhoto = dataURL;
        document.getElementById('preview_photo').style.display = 'block';
        this.base64textString = dataURL;
        this.photoText = "Webcam";
        document.getElementById("photoText").textContent = "Webcam";
        this.photoTaken = true;
        this.invitationType = 'image';
        (<any>window).photoStream.getTracks()[0].stop();
    }



    loadingShow() {
        document.getElementById("loadingDiv").style.display = "block";
    }

    loadingHide() {
        document.getElementById("loadingDiv").style.display = "none";
    }

    showElement(element: string[]) {
        //console.log(element);
    }


  viewDescription(value: any) {
    this.fullDescription = value;
    return this.modal.open(this.viewDesc, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}