import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import {Autosize} from 'angular2-autosize';

import { LayoutComponent } from './component/layout.component';
import { TranslateModule, TranslateService } from "ng2-translate";
import { LayoutBusiness } from './business/layout.business';
import { LayoutService } from './service/layout.service';
import { SharedModule } from '../share/translate-shared.module';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    //SharedModule
  ],
  declarations: [
    LayoutComponent,

  ],
  providers: [LayoutBusiness, LayoutService, SharedModule],
  exports: []
})
export class LayoutModule { }