import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class LayoutService {

    constructor(private httpRequest: HttpRequestService) {

    }

    userLogout(url: string) {
        return this.httpRequest.deleteHttpRequestWithToken(url);
    }

    getInvitationStudio(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    getThankyouStudio(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiGetInfo(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }
    
}