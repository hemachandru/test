import { Component, OnInit, ElementRef, Renderer, Input } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, ActivatedRoute, Event as NavigationEvent } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import { ISlimScrollOptions } from 'ng2-slimscroll';
//import { SidebarModule } from 'ng-sidebar';

import { LayoutBusiness } from '../business/layout.business';
import { LoaderService } from '../../../utility/helper.service';
// import { TranslateService} from '../../../utility/translation';
import { SharedModule} from '../../share/translate-shared.module';


@Component({
  selector: 'app-dashboard',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
  // host: {
  //   '(window:resize)': 'onResize($event)'
  // }
})


export class LayoutComponent implements OnInit {
  public opts: ISlimScrollOptions;
  public classname: boolean;
  public activeURL: string;
  private _opened: boolean = false;
  public isopen: boolean = false;
  public isopen2: boolean = false;
  public isToken: any;
  public userIn: any = false;
  public supportedLanguages: any[];
  public supportedLangs: any[];
  public currentLang: any;

  public publicUserValue:any;
  public publicUser:boolean = false;
  public privateUserValue:any;
  public privateUser:boolean = false;

  private _toggleSidebar() {
    this._opened = !this._opened;
  }

  public paypalAccount: any = true;
  public wishId: any;

  public profileInfo: any;
  public displayValue: any;

  constructor(private el: ElementRef, private renderer: Renderer, private route:ActivatedRoute, private router: Router, private layoutBusiness: LayoutBusiness,
    private translate: TranslateService, private loaderService: LoaderService, private shared: SharedModule) {

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.isToken = localStorage.token ? localStorage.token : 'null';
        this.userIn = this.isToken == 'null' ? false : true;
        this.activeURL = event.url;
        this.wishId = localStorage.getItem('wishIds');
        let editWish = '/addwish/' + this.wishId;
        let viewWish = '/userwish/' + this.wishId;
        if (this.activeURL == "/wishlist-thankyou-new" || this.activeURL == "/thankyoustudioedit" || this.activeURL == "/invitationedit" || this.activeURL == "/wishlist-invitation-new" || this.activeURL == "/invitationsuccess/edit" || this.activeURL == "/invitationsuccess/share" || this.activeURL == "/userwish" || this.activeURL == "/myinvitation/edit" || this.activeURL == "/myinvitation/share" || this.activeURL == "/addwish" || this.activeURL == "/wishsuccess" || this.activeURL == editWish || this.activeURL == viewWish || this.activeURL == "/thankyoustudio/edit" || this.activeURL == "/thankyoustudio/share" || this.activeURL == "/thankyoustudio-success/edit" || this.activeURL == "/thankyoustudio-success/share") {
          document.body.classList.add('no__background');
        } else {
          document.body.classList.remove('no__background');
        }

        if(this.activeURL == "/thankyou-message"){
            //this.displayValue = "none";
            document.body.classList.add('no__background');
        }else{
          this.displayValue = ""
        }

        //userName [for using social signup]
        //email password  [for email logn]
        this.publicUserValue = localStorage.userName ? localStorage.userName : 'null';
        this.privateUserValue = localStorage.email ? localStorage.email : 'null';
        
        this.publicUser = this.publicUserValue == 'null' ? false : true;
        this.privateUser = this.privateUserValue == 'null' ? false : true;
        //publicUser  privateUser
        
        if(this.activeURL == '/wellwishes-studio' || this.activeURL == '/contactus' || this.activeURL == '/addwish' || this.activeURL == '/myinvitation/edit' || this.activeURL == '/thankyoustudio/edit'){
          var element = document.getElementById("html");
          element.classList.add("myStyleWellWishes");
        }else{
          var element = document.getElementById("html");
          element.classList.add("NotmyStyleWellWishes");
        }

        if(this.userIn){
          if(this.activeURL == '/socialsignup' || this.activeURL == '/login' || this.activeURL == '/'){
            this.router.navigate(['/userwish']);
          }
        }
      }
    });


  }

  ngOnInit() {
    //hai
    var aaa = document.getElementById('hai');
    console.log('geted value : ',aaa);

    this.loaderService.display(true);
    this.isToken = localStorage.getItem("token");
    this.userIn = this.isToken == 'null' ? false : true;
    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    this.supportedLangs = [
      { display: 'English', value: 'en' },
      { display: 'French', value: 'fr' }
    ];

    let language = localStorage.getItem('lang');
    var DefLang = (language == undefined || language == "null") ? "en" : language;
    this.loaderService.display(false);
    this.selectLang(DefLang);
  }

  clickCheckLogo(){
    //console.log('hai');
    this.isToken = localStorage.token ? localStorage.token : 'null';
    this.userIn = this.isToken == 'null' ? false : true;
    //console.log(this.userIn);
    if(this.userIn){
      this.router.navigate(['/userwish']);
    }else{
      this.router.navigate(['/socialsignup']);   
    }
  }
    // let chkToken = localStorage.getItem("token");
    // if(chkToken == "" || chkToken == null){
    //   this.router.navigate(['/userwish']);
    // }else{
    //   this.router.navigate(['/userwish']);
    // }


  isCurrentLang(lang: string) {
    return lang === this.translate.currentLang;
  }

  selectLang(lang: string) {
    localStorage.removeItem("lang");
    localStorage.setItem('lang', lang);
    let language = localStorage.getItem('lang');
    this.shared.test(language);
    this.currentLang = language;
    console.log("language",this.currentLang)
  }

  isIn = false;   // store state
  toggleState() { // click handler
    let bool = this.isIn;
    this.isIn = bool === false ? true : false;
  }

  menuRedirect(urlName: any) {
    //console.log(urlName);
    if(urlName == '/addwish'){
      let wishState = 'addNew';
      sessionStorage.setItem('wishState', wishState);
      console.log(urlName);
    }
    //document.getElementById("loadingDiv").style.display="block";
    //this.loaderService.display(true);
    sessionStorage.removeItem('isSessionMyAccount');
    this.router.navigate([urlName]);
    this.onClose();
  }
  subRedirect(urlName: any) {
    //this.loaderService.display(true);
    this.router.navigate([urlName]);
    this.onClose();
    this.onSidebar2Close();
  }

  async invitationStudio() {
    let invitation_Via = "menu";
    let resList = await this.layoutBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
      localStorage.setItem("shareWishOrCreateWish","false");
      //console.log(result);
      if (result.response) {
        //console.log(result.message)
        this.router.navigate(['/invitationedit']);
      } else {
        this.router.navigate(['/myinvitation/edit']);
        localStorage.setItem("invitation_Via",invitation_Via);
      }

      this.onClose();
      this.onSidebar2Close();

    },
      (error) => {
        console.log(error);
        this.onClose();
        this.onSidebar2Close();
      });
  }

  async thankyouStudio() {
    let resList = await this.layoutBusiness.getThankyouStudio('thankyou_studios/thankyou_studio_present').subscribe((result) => {
      localStorage.setItem("shareWishOrCreateWish","false");
      if (result.response) {
        this.router.navigate(['/thankyoustudioedit']);
      } else {
        this.router.navigate(['/thankyoustudio/edit']);
      }
      this.onClose();
      this.onSidebar2Close();

    },
      (error) => {
        console.log(error);
        this.onClose();
        this.onSidebar2Close();
      });
  }

  async loginOut() {
    //chandru
    let userKey = await this.layoutBusiness.logout('user/logout');
    this.userIn = false;
    localStorage.clear();
    sessionStorage.clear();
    this.router.navigate(['/']);
    this.onClose();
  }
  menuOpen() {
    this.isopen2 = true;
    document.getElementsByClassName('sidebar2')[0].classList.toggle('collapsed')
  }
  onSidebar2Close() {
    this.isopen2 = false;
    document.getElementsByClassName('sidebar2')[0].classList.toggle('collapsed')
  }
  // public onResize(event: any) {
  //   console.log("Window resize here....");
  // }

  //changeLang() {
    //this.translate.use(lang);
    //this.translate.use('fr');
  //}
  toggled() {
    this.isopen = true;
    document.getElementsByClassName('sidebar')[0].classList.toggle('collapsed');

  }
  onClose() {
    setTimeout(() => {
      this.isopen = false;
    }, 1000);
    document.getElementsByClassName('sidebar')[0].classList.toggle('collapsed');
    //this.loaderService.display(false);
  }
  onTerms() {
    this.onClose();
    this.router.navigate(['/termsandconditions'])
  }
  onPrivacy() {
    this.onClose();
    this.router.navigate(['/privacypolicy']);
  }
  onTerms2() {
    this.onSidebar2Close();
    this.onClose();
    this.router.navigate(['/termsandconditions'])
  }
  onPrivacy2() {
    this.onSidebar2Close();
    this.onClose();
    this.router.navigate(['/privacypolicy']);
  }
  onTermsFooter() {
    this.router.navigate(['/termsandconditions'])
  }
  onPrivacyFooter() {
    this.router.navigate(['/privacypolicy']);
  }

  async shareWishList() {
    let resList = await this.layoutBusiness.APIGetOnly('user/profile').subscribe((result) => {
      if (result.response) {
        this.profileInfo = result.data.profile;
        if (result.data.profile.paypal_name) {
          this.getUserInformation(this.profileInfo);
        } else {
          let display_style_account = "false";
          sessionStorage.setItem('display_style_account', display_style_account);
          let display_style_payment = "true";
          sessionStorage.setItem('display_style_payment', display_style_payment);

          this.router.navigate(['share-notification']);
        }
      }
    },
      (error) => {
        console.log(error);

      });

      this.onClose();
      this.onSidebar2Close();
  }


  async getUserInformation(accountInfo: any) {   

      let first_name = accountInfo.first_name;
      let last_name = accountInfo.last_name;
      let full_name = accountInfo.full_name;
      let dob = accountInfo.dob;
      let phone = accountInfo.phone;
      let address = accountInfo.address;
      let city = accountInfo.city;
      let post_code = accountInfo.post_code;
      let email = accountInfo.email;
      let currency_id = accountInfo.currency_id;
      let paypal_name = accountInfo.paypal_name;
      let country = accountInfo.country;

      if (first_name == null || last_name == null || full_name == null || dob == null || phone == null || address == null || city == null || post_code == null || email == null || currency_id == null || paypal_name == null || country == null) {
        let isSessionMyAccount = "true";
        sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);

        let display_style_account = "true";
        sessionStorage.setItem('display_style_account', display_style_account);
        let display_style_payment = "false";
        sessionStorage.setItem('display_style_payment', display_style_payment);

        this.router.navigate(['share-notification']);

        //this.router.navigate(['myaccount']);
       
      } else {
        let isSessionMyAccount = "false";
        sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);
        //this.router.navigate(['share-login']);
        this.invitationStudio();
       
      }
  }
  
  /* End Share Flow */
}