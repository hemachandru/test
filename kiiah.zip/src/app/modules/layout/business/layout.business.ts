import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { LayoutService } from '../service/layout.service'

@Injectable()
export class LayoutBusiness {

    constructor(private layoutService: LayoutService, private router: Router) {
    }


    logout(url: string) {

        this.layoutService.userLogout(url)
            .subscribe((result) => {
                console.log('response value : ',result.response);
                if (result.response) {
                    console.log('true');
                    localStorage.clear();
                    this.router.navigate(['/']);
                } else {
                    alert(result.message)
                }
            },
            (error) => {
                console.log(error);
            });

    }

    getInvitationStudio(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.layoutService.getInvitationStudio(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getThankyouStudio(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.layoutService.getInvitationStudio(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    APIGetOnly(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.layoutService.apiGetInfo(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}