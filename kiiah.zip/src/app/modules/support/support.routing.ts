import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SupportComponent } from './component/support.component';

export const supportRoutes: Routes = [
  {
    path: '',
    component: SupportComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(supportRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class SupportRoutingModule { } 
