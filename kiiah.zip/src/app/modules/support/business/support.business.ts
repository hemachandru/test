import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { SupportService } from '../service/support.service'

@Injectable()
export class SupportBusiness {
    public token: string;


    constructor(public supportService: SupportService, public router: Router) {
    }

    getFAQList(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.supportService.apiFaqList(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    saveContactUs(contactData: any, url: string) {
        var formData = {
            "contact_us": contactData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.supportService.apiSaveContactUs(JSON.stringify(formData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}