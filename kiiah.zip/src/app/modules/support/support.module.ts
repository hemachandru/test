import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';

import { SupportComponent } from './component/support.component';
import { ContactUsComponent } from './component/contactus/contact.component';
import { FAQComponent } from './component/faq/faq.component';
import { TermsComponent } from './component/terms/terms.component';
import { PrivacyComponent } from './component/privacy/privacy.component';

import { SupportRoutingModule } from './support.routing';

import { SupportBusiness } from './business/support.business';
import { SupportService } from './service/support.service';
import { SharedModule } from '../share/translate-shared.module';


@NgModule({
  imports: [
    CommonModule,
    SupportRoutingModule,
    FormsModule,
    NgxPaginationModule,
    SharedModule
  ],
  declarations: [
    SupportComponent,
    ContactUsComponent,
    FAQComponent,
    TermsComponent,
    PrivacyComponent
  ],
  providers: [SupportBusiness, SupportService, SharedModule]
})
export class SupportModule { }

