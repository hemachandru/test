import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class SupportService {

    constructor(private httpRequest: HttpRequestService) {

    }

    apiFaqList(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiSaveContactUs(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    } 
}