import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './support.component.html',
    styleUrls: ['./support.component.scss']
})

export class SupportComponent implements OnInit {
    public activeURL: string;
    public createWish = true;
    public wishId: any;

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}