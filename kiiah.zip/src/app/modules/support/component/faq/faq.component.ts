import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SupportBusiness } from '../../business/support.business';

@Component({
  selector: 'faq-page',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})

export class FAQComponent implements OnInit {
  public FaqList: any;
  public faqQuestion: string;
  public faqAns: string;

  constructor(private router: Router, private _location: Location, private route: ActivatedRoute, private supportBusiness: SupportBusiness, private loaderService:LoaderService) {
    this.FaqList = [];
    // for (let i = 1; i <= 100; i++) {
    //   this.collection.push(`item ${i}`);
    // }
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.getFAQList();
    this.loaderService.display(false);
  }

  async getFAQList() {
    let resList = await this.supportBusiness.getFAQList('faqs').subscribe((result) => {
      if (result.response) {
        if (result.data.length > 0) {
          this.FaqList = result.data;
          this.faqQuestion = result.data[0].question;
          this.faqAns = result.data[0].answer;
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }

  getFAQAnswser(item: any) {
    //console.log(item);
    this.faqQuestion = item.question;
    this.faqAns = item.answer;
  }


}