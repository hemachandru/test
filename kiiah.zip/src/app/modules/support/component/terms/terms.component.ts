import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'terms',
    templateUrl: './terms.component.html',
    styleUrls: ['./terms.component.scss']
})

export class TermsComponent implements OnInit {

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
    }

    ngOnInit() {

    }
}