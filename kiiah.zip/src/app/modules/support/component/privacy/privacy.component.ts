import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    selector: 'privacy-policy',
    templateUrl: './privacy.component.html',
    styleUrls: ['./privacy.component.scss']
})

export class PrivacyComponent implements OnInit {

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
    }

    ngOnInit() {

    }
}