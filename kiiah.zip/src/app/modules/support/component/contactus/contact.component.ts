import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { LoaderService,MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SupportBusiness } from '../../business/support.business';

@Component({
  selector: 'contact-us',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})

export class ContactUsComponent implements OnInit {

  public ContactValue: any;
  public invalidEmail: any;
  public requiredField: boolean = false;
  public offocusBool: boolean = false;
  public emailErrorMessageCheck: string = 'your_email_pls';
  public emailErrorMessageColor: string = '#4b4b4b';

  constructor(private router: Router, private _location: Location, private supportBusiness: SupportBusiness, private loaderService: LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    this.ContactValue = {
      email: '',
      message: ''
    }    
  }

  ngOnInit() {  
    this.loaderService.display(true); 
    document.getElementById("loadingDiv").style.display="none";
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
   //this.loaderService.display(false);
  }

  focusFunction(){
    this.offocusBool = true;
  }
  focusFunctionOut(param:any){
   if(param == ""){
    this.offocusBool = false;
  }
  }


  onBlurMethod(val: any) {
    if (val != "") {
      console.log('Email not empty');
      if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.emailErrorMessageCheck = 'your_email_pls';
        this.emailErrorMessageColor = '#4b4b4b';
      } else {
        this.emailErrorMessageCheck = 'Email_isinvalid';
        this.emailErrorMessageColor = '#ff3504';
      }
    }else {
      this.emailErrorMessageCheck = 'Email_Required';
      this.emailErrorMessageColor = '#ff3504';
    }
    // if (val != "") {
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.invalidEmail = 'none';
    //     this.emailPlaceholder ='block'
    //     this.requiredEmail = 'none';
    //     console.log('emailPlaceholder');
    //   } else {
    //     this.invalidEmail = 'block';
    //     this.emailPlaceholder ='none';
    //     this.requiredEmail = 'none';
    //     console.log('invalidEmail');
    //   }
    // }else{
    //   this.invalidEmail = 'none';
    //   this.emailPlaceholder ='none';
    //   this.requiredEmail = 'block';
    //   console.log('requiredEmail');
    // }
  }

  async saveContactInfo(contactUsData: any, event:any) {
    debugger;
    if(contactUsData.email.trim() != "" && contactUsData.email.trim() != ""){
      let emailBoolean =  this.validateEmail(contactUsData.email.trim())
    if(!emailBoolean) return;
    }else{
     this.requiredField = true;
     return;
    }
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let resList = await this.supportBusiness.saveContactUs(contactUsData, 'contact_us').subscribe((result) => {
      console.log(result);
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
      if (result.response) {
        if( localStorage.getItem("token") ) {
          this.router.navigate(['/userwish']);
        }else{
          this.router.navigate(['/']);
        }
        //this.router.navigate(['wish', result.data.id]);
      }
    },
      (error) => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        console.log(error);
      });
  }


  /** Email validation Function */
  validateEmail(val: any) {
    if (val != "") {
      if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        ContactUsComponent.prototype.invalidEmail = 'hidden';
        return true;
      } else {
        ContactUsComponent.prototype.invalidEmail = 'visible';
        return false;
      }
    }
  }

}