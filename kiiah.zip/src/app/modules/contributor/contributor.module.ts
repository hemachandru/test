import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
//import { NgxPaginationModule } from 'ngx-pagination';
import { SlimScrollModule } from 'ng2-slimscroll';
import { ClickOutsideModule } from 'ng-click-outside';

import { ContributorComponent } from './component/contributor.component';
import { WishescontributorComponent } from './component/wishes-contributor/wishes-contributor.component';
import { MyWishesComponent } from './component/mywishes/mywishes.component';
import { ContributorRoutingModule } from './contributor.routing';

import { ContributorBusiness } from './business/contributor.business';
import { ContributorService } from './service/contributor.service';
import { SharedModule } from '../share/translate-shared.module';
import { WishListBusiness } from '../userwish/business/wish.business';
import { WishService } from '../userwish/service/wish.service';
import { UtilityModule } from '../../utility/utility.module';

@NgModule({
  imports: [
    CommonModule,
    ContributorRoutingModule,
    FormsModule,
    SlimScrollModule,
    ClickOutsideModule,
    SharedModule,
    UtilityModule
  ],
  declarations: [
    ContributorComponent,
    WishescontributorComponent,
    MyWishesComponent
    
  ],
  providers: [ContributorBusiness, ContributorService, SharedModule, WishListBusiness, WishService]
})
export class ContributorModule { }

