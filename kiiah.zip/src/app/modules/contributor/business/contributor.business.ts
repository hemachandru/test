import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { ContributorService } from '../service/contributor.service'

@Injectable()
export class ContributorBusiness {

    constructor(public contributorService: ContributorService, public router: Router) {
    }

    getApiWishList(data: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.contributorService.apiWishGroupList(data, url).subscribe((result) => {
            activeProject.next(result)
        },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    putWishDetails(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.contributorService.apiWishList(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getFullFillAmount(data: any, url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.contributorService.apiFullFillAmount(data, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getProfileInfo(data: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.contributorService.apiSecureUserData(data, url).subscribe((result) => {
            activeProject.next(result)
        },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }
}

