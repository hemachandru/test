import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ContributorComponent } from './component/contributor.component';

export const contributorRoutes: Routes = [
  {
    path: '',
    component: ContributorComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(contributorRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ContributorRoutingModule { } 
