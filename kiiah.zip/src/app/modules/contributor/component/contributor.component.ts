import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute, Params } from '@angular/router';

@Component({
    templateUrl: './contributor.component.html',
    styleUrls: ['./contributor.component.scss']
})

export class ContributorComponent implements OnInit {
    public activeURL: string;
    public wishId: any;
    public userkey: any;

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute, private activeRoute: ActivatedRoute,) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });

        this.route.queryParams.subscribe(params => {
            this.userkey = params['key']; // (+) converts string 'id' to a number              
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}