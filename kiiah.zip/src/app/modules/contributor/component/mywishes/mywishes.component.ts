import { Observable } from 'rxjs/Observable';
import { Component, OnInit, TemplateRef, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';


import { ContributorBusiness } from '../../business/contributor.business';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
  selector: 'mywishes',
  templateUrl: './mywishes.component.html',
  styleUrls: ['./mywishes.component.scss']
})

export class MyWishesComponent implements OnInit, OnDestroy {
  public opts: ISlimScrollOptions;
  private MyWishList: Array<any>;
  private WishListInfo: any;
  private userName: any;
  private fullDescription: any;
  private WishId: any;
  private imgUrl: any;
  private secretUseId: any;

  @ViewChild('viewDescription') public changepwd: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private router: Router, private _location: Location, private activeRoute: ActivatedRoute, private contributorBusiness: ContributorBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, public pageLocation: PlatformLocation, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    overlay.defaultViewContainer = vcRef;

    pageLocation.onPopState(() => {
      if (this.dialog) {
        this.onClose();
      }
    });

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.WishListInfo = {
      title: ''
    }

    this.activeRoute.queryParams.subscribe(params => {
      this.secretUseId = params['key'];
      //this.WishId = params['id'];
      if (this.secretUseId) {
        this.getWishList(this.secretUseId);
      }else{
        
      }
      // if (this.WishId) {
      //   this.getWishView(this.WishId);
      // }
    });

    this.userName = localStorage.getItem('userName');
    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

    this.loaderService.display(false);

  }

  async getWishList(keyData: any) {
    let self = this;
    var DataKey = { "id": keyData };   
    let resList = await this.contributorBusiness.getApiWishList(DataKey, 'wishes/wish_lists').subscribe((result) => {
      var resultData = result.data;
      if (resultData.length > 0) {
        if (!this.WishId) {
          this.WishListInfo = resultData[0];
          this.WishId = this.WishListInfo.id;
          this.imgUrl = this.WishListInfo.image_url ? this.WishListInfo.image_url : 'not';
        }
        var showChar = 150;
        let wishlist: any = [];

        resultData.forEach(function (value: any) {

          value.read_more = '';
          if (value.description.length > showChar) {
            var trimvalue = value.description.substr(0, showChar);
            value.read_more = trimvalue;
            wishlist.push(value);
          } else {
            wishlist.push(value);
          }
        });

        this.MyWishList = wishlist;
      } else {
        this.WishListInfo = false;
      }      
    },
      (error) => {
        console.log(error);
      });
  }
  async getWishView(wishId: any) {
    let contributeWishId = {
      "id": wishId
    }
    //document.getElementById("loadingDiv").style.display = "block";
    let resList = await this.contributorBusiness.getApiWishList(contributeWishId, 'wishes/show_wish').subscribe((result) => {
      if (result.response) {
        this.WishListInfo = result.data;
        this.imgUrl = this.WishListInfo.image_url ? this.WishListInfo.image_url : 'not';
        // this.userWish = 'yes';
      }
    },
      (error) => {
        console.log(error);
        //document.getElementById("loadingDiv").style.display = "none";
      });
  }

  viewDescriptionPopup(value: any) {
    this.fullDescription = value;
    return this.modal.open(this.changepwd, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }

  goToContribute(wishInfo: any, event:any) {   
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    var contributeWishes = {
      contribute_wish_id: wishInfo.id,
      contribute_wish_title: wishInfo.title,
      contribute_user_key: this.secretUseId,
      contribute_wish_img: wishInfo.image_url,
      contribute_currency_code: wishInfo.currency[2],
      contribute_currency_symbole: wishInfo.currency[1]
    }
    localStorage.setItem('contribute_wish_values', JSON.stringify(contributeWishes));
    this.mojsBurstButtonAnimation.setTimeOut_Animation('wishes-contributor',this);
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}