import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { ContributorBusiness } from '../../business/contributor.business';

const Amounts = [
  { id: 10.00, value: '10.00', flag: false },
  { id: 25.00, value: '25.00', flag: true },
  { id: 45.00, value: '45.00', flag: false },
  { id: 75.00, value: '75.00', flag: false },
  { id: 100.00, value: '100.00', flag: false }
];

@Component({
  selector: 'wishes-contributor',
  templateUrl: './wishes-contributor.component.html',
  styleUrls: ['./wishes-contributor.component.scss']
})



export class WishescontributorComponent implements OnInit, OnDestroy {

  public contributeValues: any;

  private dropdownList: string = 'visible';
  private currencyClicked: boolean = false;
  private wasWishClicked: boolean = false;
  private delay: boolean = false;
  private wishCurrencyAmount: any;
  private selectedAmount: boolean = false;
  private validateMessage: boolean = false;
  private wishValues: any;
  private secureKey: any;
  private userDetails: any;
  private imgUrl: boolean = false;
  private contributeWishes: any;
  public profileImageCheckStatic: string = 'none';
  public profileImageCheckDynamic: string = 'none';

  constructor(private router: Router, private _location: Location, private contributorBusiness: ContributorBusiness, private activeRoute: ActivatedRoute, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    this.userDetails = {
      full_name: '',
      image_url: ''
    }
    this.contributeWishes = {
      contribute_pp_email: ''
    }
  }

  ngOnInit() {
    this.profileImageCheckStatic = "none";
    this.profileImageCheckDynamic = "none";

    //this.wishCurrencyAmount = 'pls enter contribution amount';
    this.loaderService.display(true);
    let wishDetails = localStorage.getItem('contribute_wish_values');
    this.wishValues = JSON.parse(wishDetails);
    //console.log(this.wishValues);
    this.getWishDetails();
    this.mojsBurstButtonAnimation.intializeMojs();
    if (this.wishValues.contribute_user_key) {
      this.getUserProfile(this.wishValues.contribute_user_key);
    }

  }

  async getWishDetails() {
    let wishId = {
      "wish_id": this.wishValues.contribute_wish_id
    }
    let resList = await this.contributorBusiness.getFullFillAmount(wishId, 'wishes/wish_fullfill_amount').subscribe((result) => {
      if (result.response) {
        //console.log(result.data);
        this.contributeValues = result.data.amounts;
      }
    },
      (error) => {
        console.log(error);
      });
  }

  async getUserProfile(userKey: any) {
    let userId = {
      "secure_link": userKey
    }
    let resList = await this.contributorBusiness.getProfileInfo(userId, 'user/secure_link').subscribe((result) => {
      //console.log('Profile Image : ',result.data);
      if (result.response) {
        this.userDetails = result.data;
        this.imgUrl = result.data.image_url ? true : false;
        let ppEmail = result.data.pp_email ? result.data.pp_email : null;
        localStorage.setItem("paypalEmail", ppEmail);
        //console.log(this.imgUrl); profileImageCheckDynamic
        if(this.imgUrl == true){
          this.profileImageCheckStatic ="none";
          this.profileImageCheckDynamic ="block";
        }else{
          this.profileImageCheckStatic ="block";
          this.profileImageCheckDynamic ="none";
        }
        // console.log(this.profileImageCheck);
      }
    },
      (error) => {
        console.log(error);
      });
  }


  onCurrencyClick() {
    this.delay = true;
    this.currencyClicked = !this.currencyClicked;
    this.wasWishClicked = false;
  }

  onClickedOutside(e: Event) {
    var drop = document.getElementById("currencyvalue");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.currencyClicked = false;
    }
  }

  getCurrencyValue(value: any) {
    this.wishCurrencyAmount = value.value;
    this.selectedAmount = true;
  }
  clearDropdown() {
    this.dropdownList = 'hidden';
  }
  makeContribure(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    if (this.wishCurrencyAmount) {
      localStorage.setItem("contribure_amount", this.wishCurrencyAmount);
      this.mojsBurstButtonAnimation.setTimeOut_Animation('cardpayment',this);
    } else {
      this.validateMessage = true;
    }
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}