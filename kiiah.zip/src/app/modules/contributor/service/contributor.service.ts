import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class ContributorService {

    constructor(private httpRequest: HttpRequestService) {

    }
    apiWishList(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiFullFillAmount(data: any, url: any) {
        return this.httpRequest.postHttpRequest(data, url);
    }

    apiWishGroupList(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }
    apiSecureUserData(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }
}