import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class ThankyouStudioService {

    constructor(private httpRequest: HttpRequestService) {

    }

    getListApi(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    getInvitationStudio(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }
   
    apiSaveInivitation(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    }

    sendVideo(data: any, url: string) {
        return this.httpRequest.postHttpRequestMultipart(data, url);
    }

    previewObject(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    }
    
}