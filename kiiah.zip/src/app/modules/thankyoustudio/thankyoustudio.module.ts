import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ThankyouRoutingModule } from './thankyoustudio.routing';
import { ClickOutsideModule } from 'ng-click-outside';
import {Autosize} from 'angular2-autosize';

import { ThankyouComponent } from './component/thankyou.component';
import { ThankyouStudioComponent } from './component/thankyoustudio/thankyoustudio.component';
import { ThankyouStudioSuccessComponent } from './component/thankyoustudio-success/thankyoustudiosuccess.component';
import { ThankyouStudioEditComponent } from './component/thankyoustudio-edit/thankyoustudioedit.component';

import { ProgressBarModule } from "ngx-progress-bar";

import { SlimScrollModule } from 'ng2-slimscroll';

import { ThankyouStudioBusiness } from './business/thankyoustudio.business';
import { ThankyouStudioService } from './service/thankyoustudio.service';

import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { SharedModule } from '../share/translate-shared.module';

const SWIPER_CONFIG: SwiperConfigInterface = {
    scrollbar: null,
    observer: true,
    spaceBetween: 65,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    breakpoints: {
        // when window width is <= 320px
        320: {
            slidesPerView: 1,
            spaceBetween: 35
        },
        // when window width is <= 480px
        480: {
            slidesPerView: 1,
            spaceBetween: 50
        },
        // when window width is <= 600px
        600: {
            slidesPerView: 1,
            spaceBetween: 65
        }
    }
};
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ThankyouRoutingModule,
        SwiperModule.forRoot(SWIPER_CONFIG),
        ClickOutsideModule,
        SlimScrollModule,
        ProgressBarModule,
        SharedModule
    ],
    declarations: [
        ThankyouComponent,
        ThankyouStudioComponent,
        ThankyouStudioSuccessComponent,
        ThankyouStudioEditComponent
        //Autosize
    ],
    providers: [ThankyouStudioBusiness, ThankyouStudioService, SharedModule]
})
export class ThankyouStudioModule {
    public config: SwiperConfigInterface = {
        scrollbar: null,
        observer: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        breakpoints: {
            // when window width is <= 320px
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            },
            // when window width is <= 480px
            480: {
                slidesPerView: 1,
                spaceBetween: 20
            }
        }
    };
}

