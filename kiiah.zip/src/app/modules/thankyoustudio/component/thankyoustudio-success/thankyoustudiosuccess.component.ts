import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { ThankyouStudioBusiness } from '../../business/thankyoustudio.business';


@Component({
  selector: 'thankyoustudio-success',
  templateUrl: './thankyoustudiosuccess.component.html',
  styleUrls: ['./thankyoustudiosuccess.component.scss']
})


export class ThankyouStudioSuccessComponent implements OnInit, OnDestroy {
  public paypal = true;
  public thankType: string;

  constructor(private router: Router, private route: ActivatedRoute, private _location: Location, private thankyoustudioBusiness: ThankyouStudioBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    this.route.params.subscribe(params => {
      this.thankType = params['type'];
    });
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
    //this.getUserInformation();
  }
  goBack() {
    this._location.back();
  }
  redirectTo(event: any) {
    // if (url == 'share') {
    //   if (this.paypal) {
    //     this.router.navigate(['share-login']);
    //   }
    //   else {
    //     this.router.navigate(['share-notification']);
    //   }
    // } else {
    //   this.router.navigate([url]);
    // }
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    if (this.thankType == "share")
      this.mojsBurstButtonAnimation.setTimeOut_Animation('/wishlist-thankyou',this);
    else
      this.mojsBurstButtonAnimation.setTimeOut_Animation('/thankyoustudioedit',this);

  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}