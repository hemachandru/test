import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Renderer, AfterViewInit, TemplateRef, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { ThankyouStudioBusiness } from '../../business/thankyoustudio.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'thankyou-studio-edit',
    templateUrl: './thankyoustudioedit.component.html',
    styleUrls: ['./thankyoustudioedit.component.scss']
})

export class ThankyouStudioEditComponent implements OnInit, AfterViewInit, OnDestroy {

    @ViewChild('viewDesc') public viewDesc: TemplateRef<any>;
    dialog: DialogRef<any>;
    
    public someProperty: any;
    public invitationStudio: any;
    public videoP: boolean = false;
    public audioP: boolean = false;
    public isMobile: any;
    private fullDescription: any;
    public shareButtonHide_Show: boolean = false;
    public read_more: any;
    public read_more_hide : any;

    constructor(private router: Router, private _location: Location, private thankyouStudioBusiness: ThankyouStudioBusiness, private render: Renderer, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
        overlay.defaultViewContainer = vcRef;
        
        this.invitationStudio = {
            frame_url: "",
            thankyou_msg: {

            },
            media: "",
            message: "",
            type: ""
        }

        localStorage.getItem("shareWishOrCreateWish") == "true" ? this.shareButtonHide_Show =true : this.shareButtonHide_Show =false;
    }

    ngOnInit() {
        this.loaderService.display(true);
        this.isMobile = this.detectMobile();
        this.mojsBurstButtonAnimation.intializeMojs();
        this.someProperty = true;
        document.getElementById('image_without_frame').style.display = 'none';
        document.getElementById('image_with_frame').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        this.loaderService.display(false);
        this.getInvitationStudio();
    }
    gotoShare(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        this.mojsBurstButtonAnimation.setTimeOut_Animation('/share-login',this);
    }

    detectMobile() {
        if (navigator.userAgent.match(/Android/i)
            || navigator.userAgent.match(/webOS/i)
            || navigator.userAgent.match(/iPhone/i)
            || navigator.userAgent.match(/iPad/i)
            || navigator.userAgent.match(/iPod/i)
            || navigator.userAgent.match(/BlackBerry/i)
            || navigator.userAgent.match(/Windows Phone/i)
        ) {
            return true;
        }
        else {
            return false;
        }
    }

    async getInvitationStudio() {
        let self = this;
        let resList = await this.thankyouStudioBusiness.getInvitationStudio('thankyou_studios/thankyou_studio_present').subscribe((result) => {
            if (result.response) {
                //console.log("success----", result.message);
                this.invitationStudio = result.message;
                if (result.message.type == "video") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewVideo = document.getElementById('preview_video');
                    previewVideo.setAttribute('src', result.message.media);
                    previewVideo.addEventListener('ended', this.myHandler(self), false);
                    previewVideo.addEventListener('pause', this.myHandlerPause(self), false);
                    document.getElementById('preview_video').style.display = 'block';
                    document.getElementById('play--icon').style.display = 'block';
                } else if (result.message.type == "audio") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewAudio = document.getElementById('preview_audio');
                    previewAudio.setAttribute('src', result.message.media);
                    previewAudio.addEventListener('ended', this.myHandlerAudio(self), false);
                    document.getElementById('preview_audio').style.display = 'block';
                    document.getElementById('preview_audio1').style.display = 'block';
                    document.getElementById('audio--play--icon').style.display = 'block';
                } else {
                    document.getElementById('image_without_frame').style.display = 'none';
                    document.getElementById('image_with_frame').style.display = "block";
                }
            } else {
                //console.log("error----", result.message)
            }
            var showChar = 150;
            if (this.invitationStudio.thankyou_msg.description.length > showChar) {
                this.read_more_hide = 'none';
                this.read_more = this.invitationStudio.thankyou_msg.description.substr(0, showChar);
            }else{
                this.read_more_hide ='block';
            }
        },
            (error) => {
                //console.log(error);
            });
    }

    myHandler(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                let videoTag: any = document.getElementById('preview_video');
                videoTag.webkitExitFullscreen();
                //videoTag.mozCancelFullScreen();
            }
            that.videoP = false;
            document.getElementById('pause--icon').style.display = 'none';
            document.getElementById('play--icon').style.display = 'block';
        }
    }

    myHandlerPause(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                that.videoP = false;
                document.getElementById('pause--icon').style.display = 'none';
                document.getElementById('play--icon').style.display = 'block';
            }

        }
    }

    myHandlerAudio(that: any) {
        return (event: any) => {
            that.audioP = false;
            document.getElementById('audio--pause--icon').style.display = 'none';
            document.getElementById('audio--play--icon').style.display = 'block';
        }
    }

    ngAfterViewInit() {
        document.getElementById("loadingDiv").style.display = "none";
    }

    playVideo() {
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'block';
        this.videoP = true;
        previewVideo.play();

    }

    stopVideo() {
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('play--icon').style.display = 'block';
        this.videoP = false;
        previewVideo.pause();
    }

    playAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'block';
        this.audioP = true;
        previewVideo.play();

    }

    stopAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'block';
        this.audioP = false;
        previewVideo.pause();
    }

    gotoInvitation(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        if (!this.videoP && !this.audioP) {
            this.mojsBurstButtonAnimation.setTimeOut_Animation('/thankyoustudio/edit',this);
        }

    }

    goBack() {
        if (!this.videoP && !this.audioP) {
            this._location.back();
        }
    }

    viewDescription(value: any) {
        this.fullDescription = value;
        return this.modal.open(this.viewDesc, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
          .then(dialog => {
            this.dialog = dialog;
          })
      }
      onClose() {
        this.dialog.close();
      }

      ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      }

}