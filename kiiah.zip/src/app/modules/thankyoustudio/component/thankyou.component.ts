import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './thankyou.component.html',
    styleUrls: ['./thankyou.component.scss']
})

export class ThankyouComponent implements OnInit {
    public activeURL: string;
    public thankType: string;

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });

        this.route.params.subscribe(params => {
            this.thankType = params['type'];
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}