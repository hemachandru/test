import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { ThankyouStudioService } from '../service/thankyoustudio.service'

@Injectable()
export class ThankyouStudioBusiness {

    constructor(public thankyoustudioService: ThankyouStudioService, public router: Router) { }

    getListAPI(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.getListApi(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getInvitationStudio(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.getInvitationStudio(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    invitationSave(addWishData: any, url: string) {
        var invitationFormData = {
            "thankyou_studio": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.apiSaveInivitation(JSON.stringify(invitationFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    invitationSaveVideo(addWishData: any, url: string) {
        var invitationFormData = {
            "thankyou_studio": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.apiSaveInivitation(addWishData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    sendVideo(videoData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.sendVideo(videoData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    previewObject(options: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.thankyoustudioService.previewObject(options, url)
            .subscribe((result: any) => {
                activeProject.next(result)
            },
            (error: any) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}