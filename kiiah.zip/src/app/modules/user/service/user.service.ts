import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class UserService {

    constructor(private httpRequest: HttpRequestService) {

    }

    apiGet(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiUpdateUser(data: any, url: string) {
        return this.httpRequest.putHttpRequest(data, url);
    }

    apiGetCurrency(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }
    apiGetOnly(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }
    apiDelete(url: string) {
        return this.httpRequest.deleteHttpRequestWithToken(url);
    }        
    APISpecial(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data,url);
    }
}