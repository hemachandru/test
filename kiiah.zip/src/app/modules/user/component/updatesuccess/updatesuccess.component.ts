import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'update-success',
  templateUrl: './updatesuccess.component.html',
  styleUrls: ['./updatesuccess.component.scss']
})
export class UserUpdateSuccessComponent implements OnInit ,OnDestroy {
  public resetMailId: any;
  public getEmailValueSession: any;
  
  constructor(private router: Router, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    this.mojsBurstButtonAnimation.intializeMojs();
  }

  ngOnInit() {
    this.getEmailValueSession =  sessionStorage.getItem('profileEmailGet');
  }

  btnDone(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);   
    //this.router.navigate(['myaccount']);
    //isSessionMyAccount
    let sesValue = sessionStorage.getItem('isSessionMyAccount');
    if(sesValue == "true"){
      this.mojsBurstButtonAnimation.setTimeOut_Animation('userwish',this); 
    }else{
      this.mojsBurstButtonAnimation.setTimeOut_Animation('myaccount',this);
    }
  }

  goBack() {
    this._location.back();
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}