import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
//import { FileUpload } from '../../../../utility/fileUpload';
//import { Camera } from 'cordova-plugin-camera';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { COUNTRY_LIST } from './mycountry';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { UserBusiness } from '../../business/user.business';
import { DEFAULT_IMAGE_URL } from '../../../../config/constant';
var WEBCAM4 = require("./../../../../../assets/js/webcam.js");
import { SharedModule } from '../../../share/translate-shared.module';

declare var jquery: any;
declare var $: any;

const country = [
  { name: 'India', code: 'IN' },
  { name: 'malesiya', code: 'ME' },
  { name: 'Singpore', code: 'SN' }
];

@Component({
  selector: 'my-account',
  templateUrl: './myaccount.component.html',
  styleUrls: ['./myaccount.component.scss']
})

export class MyAccountComponent implements OnInit, OnDestroy {

  private countryList = country;
  private currencyList: any;
  public myAccount: any;
  public invalidPassword: any;
  public maxFileSize: any;
  public video: any;
  public myFile: any;
  public profileData: any;
  private base64textString: String = "";
  public previewImg: any;

  private dropdownList: string = 'visible';
  private currencyClicked: boolean = false;
  private wasWishClicked: boolean = false;
  private delay: boolean = false;
  private wishCurrencyType: any;
  private changePassword: any;
  private passwordMissmatch = 'hidden';

  private photoTaken: any;
  private photoC: any;
  private photoText: any;
  private photoOptions: any;
  private isMobile: any;
  private currencyId: any;

  public fileExtension: any;
  public fileExtensionError: any;

  // public hiddenchangePassword: any = [];
  public c: any;
  public df: any;
  public hiddenchangeword: any;
  private currey_id: any;

  private countryClicked: boolean = false;
  private userCountryName: any;
  private countryCode: any;
  private country_withCode: any = [];
  private isCountry: any;
  public searchText:any="";
  public countrySearch: any =[];
  public matches: any;

  public staticProfileImage:string="none";
  public dynamicProfileImage:string="none";

  public errorMsgPass: string = "none";
  public errorMsgCPass: string = "none";
  public reqMsgPass:string = "block";
  public reqMsgCPass:string = "block";
  public requiredobj: any;
  public errorClass: boolean = false;
  public errorClassLastName: boolean = false;
  public errorClassDOB:boolean = false;
  public errorClassPhone: boolean = false;
  public errorClassAddress: boolean = false;
  public errorClassCity: boolean = false;
  public errorClassPincode:boolean =false;
  public errorShow:boolean = false;

  @ViewChild('changepwd') public changepwd: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private Shared: SharedModule, private router: Router, private _location: Location, private userBusiness: UserBusiness, private pageLocation: PlatformLocation, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    overlay.defaultViewContainer = vcRef;
    this.myAccount = {
      email: '',
      first_name: '',
      last_name: '',
      image_url: '',
      currency_id: '',
      paypal_name: '',
      dob: '',
      phone: '',
      address: '',
      city: '',
      post_code: '',
      country: ''
    }
    this.profileData = {
      user: {
        first_name: '',
        last_name: '',
        currency_id: '',
        paypal_name: '',
        dob: '',
        phone: '',
        address: '',
        city: '',
        post_code: '',
        country: '',
        avatar: {
          content_type: '',
          filename: '',
          file_data: ''
        }
      }

    }


    this.changePassword = {
      password: '',
      confirm_password: ''
    }
    this.photoOptions = {
      audio: false,
      video: true
    };
    this.photoText = "Webcam";

    pageLocation.onPopState(() => {
      if (this.dialog) {
        this.onClose();
      }
    });



  }

  onPassKeyUp(val: any) {
    console.log("Password",val)
    if(val == ""){
      this.reqMsgPass = 'none';
      this.errorMsgPass = 'block';
    }else{
      this.reqMsgPass = 'block';
      this.errorMsgPass = 'none';
    }
  }
  onPassConKeyUp(val: any) {
    console.log("Confirm Password",val);
    if(val == ""){
      this.reqMsgCPass = 'none';
      this.errorMsgCPass = 'block';
    }else{
      this.reqMsgCPass = 'block';
      this.errorMsgCPass = 'none';
    }
  }

  onKeyUp(val: any) {
    if (val == "") {
      this.passwordMissmatch = 'hidden';
      this.invalidPassword = 'hidden';
    }
  }

  onKeyUpInput(eventValue: any, requiredField:any) {
    if(requiredField == "firstname"){
      if(eventValue == ""){
        this.errorClass = true;
        this.requiredobj.firstname = "FirstName Required"
      }else{
        this.requiredobj.firstname = "First Name"
        this.errorClass = false;
      }
    }else if(requiredField == "lastname"){
      if(eventValue == ""){
        this.errorClassLastName = true;
        this.requiredobj.lastname = "Last Name Required"
      }else{
        this.requiredobj.lastname = "Last Name"
        this.errorClassLastName = false;
      }
    }
    else if(requiredField == "dob"){
      let dateBool = this.isValidDate(eventValue);
      if(eventValue == ""){
        this.errorClassDOB = true;
        this.requiredobj.dob = "DOB Required" //chandru
      }
      else if(!dateBool){
        this.errorClassDOB = true;
        //this.requiredobj.dob = "InValid Date Format - DD-MM-YYYY"
        this.requiredobj.dob = "InValid Date Format"
        //this.myAccount.dob = '';

      }
      else{
        this.requiredobj.dob = "DOB Required"
        this.errorClassDOB = false;
      }
    }
    else if(requiredField == "phonenumber"){
      if(eventValue == ""){
        this.errorClassPhone = true;
        this.requiredobj.phonenumber = "Phone Required"
      } else if(eventValue.length != 10 || typeof parseInt(eventValue) === "string"){
        this.errorClassPhone = true;
        this.requiredobj.phonenumber = "10 Digits Number only"
      }
      else{
        this.requiredobj.phonenumber = "Phone Number"
        this.errorClassPhone = false;
      }
    }
    else if(requiredField == "address"){
      if(eventValue == ""){
        this.errorClassAddress = true;
        this.requiredobj.address = "Address Required"
      }else{
        this.requiredobj.address = "Address"
        this.errorClassAddress = false;
      }
    }
    else if(requiredField == "city"){
      if(eventValue == ""){
        this.errorClassCity = true;
        this.requiredobj.city = "City Required"
      }else{
        this.requiredobj.city = "City"
        this.errorClassCity = false;
      }
    }
    else if(requiredField == "pincode"){
      if(eventValue == ""){
        this.errorClassPincode = true;
        this.requiredobj.pincode = "Pincode Required"
      } else if(eventValue.length > 6 || typeof parseInt(eventValue) === "string"){
        this.errorClassPincode = true;
        this.requiredobj.pincode = "5 Digits Number only"
      }
      else{
        this.requiredobj.pincode = "Pincode"
        this.errorClassPincode = false;
      }
    }
  }

  clickCloseDob(){
    this.errorClassDOB = false;
    this.requiredobj.dob = "DOB - DD-MM-YYYY"
  }

  isValidDate(date: any)
  {
      this.matches = /^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/.exec(date);
      if (this.matches == null) return false;
      let d = this.matches[1];
      let m = this.matches[2];
      let y = this.matches[3];
      var composedDate = new Date(d, m, y);
      return true
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.getUserInformation();
    this.maxFileSize = 'hidden';
    this.invalidPassword = 'hidden';
    this.fileExtensionError = 'hidden';
    this.wishCurrencyType = "Gift Currency";

    this.isMobile = this.detectMobile();
    this.userCountryName = 'Select Country';
    //this.getCurrencyList();
    this.requiredobj = {
      "firstname": "First Name",
      "lastname": "Last Name",
      "dob": "DOB - DD-MM-YYYY",
      "phonenumber": "Phone Number",
      "address": "Address",
      "city": "City",
      "pincode": "Pincode"
    }
  }

  loadCountryList() {
    for (var index = 0; index < COUNTRY_LIST.length; index++) {
      this.country_withCode.push({ "name": COUNTRY_LIST[index].name, "code": COUNTRY_LIST[index].code });
      this.countrySearch = this.country_withCode;
      if (this.isCountry == COUNTRY_LIST[index].code) {
        this.getCountryCode(COUNTRY_LIST[index]);
      }
    }
    //console.log(this.country_withCode);

  }

  goBack() {
    //this._location.back();
    this.router.navigate(['/userwish']);
  }

  public hiddenchangePassword: string = '';
  public hiddenchangePasswordHash: string = '';

  myMethod(item: any) {
    this.hiddenchangePassword = this.hiddenchangePassword.concat(item.key);
    this.changePassword.password = this.hiddenchangePassword;
    let hashPassword = '';
    for (let c = 0; c < this.hiddenchangePassword.length; c++) {
      this.hiddenchangePassword[c].replace(this.hiddenchangePassword[c], '*');
      //console.log(this.hiddenchangePassword[c]);
      // df[1].value=df[1].value.replace(df[1].value.charAt(c),'*');
    }
  }

  async getUserInformation() {
    let resList = await this.userBusiness.getUser('user/show').subscribe((result) => {
      if (result.response) {
        this.myAccount = result.data;
        console.log(result.data.email);
        let getEmailUser = result.data.email;
        sessionStorage.setItem('profileEmailGet', getEmailUser);
        let userName = result.data.first_name ? result.data.first_name : '';
        localStorage.setItem('userName', userName);
        this.currey_id = result.data.currency_id;
        this.isCountry = result.data.country ? result.data.country : null;
        if(result.data.image_url == null || result.data.image_url == ""){
          //let imgPathUrl = DEFAULT_IMAGE_URL;  ../../../../../assets/images/contributor-profile.png
          let imgPathUrl = '';
          //this.previewImg = imgPathUrl;
          this.staticProfileImage = 'block';
          this.dynamicProfileImage = 'none';
        }else{
          this.previewImg = result.data.image_url;
          this.staticProfileImage = 'none';
          this.dynamicProfileImage = 'block';
        }
      }
      this.loadCountryList();
      this.getCurrencyList();
    },
      (error) => {
        console.log(error);
      });
  }

  async getCurrencyList() {
    let self = this;
    let resList = await this.userBusiness.getAPICurrencyList('currency').subscribe((result) => {
      if (result.response) {
        if (result.data.length == 0) {
          self.clearDropdown();
        } else {
          self.currencyList = result.data;
          if (self.currey_id) {
            self.currencyList.forEach(function (value: any) {
              if (self.currey_id == value.id) {
                self.getCurrencyValue(value);
              }
            });
          }

        }
      }
    },
      (error) => {
        console.log(error);
      });
  }
  clearDropdown() {
    this.dropdownList = 'hidden';
  }
  onCurrencyClick() {
    this.delay = true;
    this.currencyClicked = !this.currencyClicked;
    this.wasWishClicked = false;
  }

 

  onCountryClick() {
    let emailValue = (<HTMLInputElement>document.getElementById('searchValue')).value;
    this.delay = true;
    this.countryClicked = !this.countryClicked;
    this.wasWishClicked = false;
  }

  testChange(){
    this.countryClicked = false;
  }
  
  onFilterEmail(enterText:any){
    if(enterText){
      let filterResult = this.countrySearch.filter((emailName: any) => {
          return emailName.name.toLowerCase().indexOf(enterText.toLowerCase()) == 0;
      });
      if(filterResult.length > 0){
          this.country_withCode = filterResult;
      }else{
          this.country_withCode = filterResult;  
      }
  }else{
    this.country_withCode = this.countrySearch;  
  }
  }


  onClickedOutside(e: Event) {
    var drop = document.getElementById("currencyvalue");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.currencyClicked = false;
    }
  }

  onClickedOutside2(e: Event) {
    var drop = document.getElementById("countryCode");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.wasWishClicked = false;
    }
  }

  getCurrencyValue(value: any) {
    this.wishCurrencyType = value.name;
    this.currencyId = value.id;
    // this.currencySymbol = value.currency_symbol;
    // this.currencyCode = value.code;
  }

  getCountryCode(value: any) {
    this.userCountryName = value.name;
    this.countryCode = value.code;
  }

  async updatePassword(newPassword: any,event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    if (newPassword.password) {
      this.validatePassword(newPassword.password);
    } 
    if (newPassword.password && newPassword.confirm_password) {

      if (newPassword.password == newPassword.confirm_password) {
        let userData = {
          user: {
            password: newPassword.password
          }
        }
        let resList = await this.userBusiness.UpdateUserProfile(userData, 'user/update').subscribe((result) => {
          if (result.response) {
            this.onClose();
            this.changePassword = {
              password: '',
              confirm_password: ''
            }
          }
        },
          (error) => {
            console.log(error);
          });
      } else {
        this.passwordMissmatch = 'visible';
      }
    }else{
      if(newPassword.password == ""){
        this.reqMsgPass = 'none';
        this.errorMsgPass = 'block';
      }else if(newPassword.confirm_password == ""){
        this.reqMsgCPass = 'none';
        this.errorMsgCPass = 'block';
      }
    }
  }

  async saveContactInfo(contactUsData: any, event:any) {
    //console.log(contactUsData);
    if( !this.countryCode || !this.currencyId || !contactUsData.first_name || !contactUsData.last_name || !contactUsData.dob ||  !contactUsData.phone || !contactUsData.address || !contactUsData.city || !contactUsData.post_code){
      this.errorShow = true;
      return;
    }
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.profileData.user = {
      first_name: contactUsData.first_name,
      last_name: contactUsData.last_name,
      currency_id: this.currencyId,
      paypal_name: contactUsData.paypal_name,
      dob: contactUsData.dob,
      //dob: '10-10-1995',
      phone: contactUsData.phone,
      address: contactUsData.address,
      city: contactUsData.city,
      post_code: contactUsData.post_code,
      country: this.countryCode
    }
console.log(this.profileData.user);
    if (this.photoTaken) {
      let tempURL = this.base64textString.toLowerCase();
      let extension;

      if (tempURL.indexOf("png") !== -1)
        extension = "png"
      else if (tempURL.indexOf("jpg") !== -1 || tempURL.indexOf("jpeg") !== -1)
        extension = "jpg"
      else
        extension = "png"

      let photoFilename = this.randomString(10) + "." + extension;
      this.profileData.user.avatar = {
        "content_type": "image/" + extension,
        "filename": photoFilename,
        "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")

      }
    }
    else {
      if (this.myFile) {
        this.profileData.user.avatar = {
          "content_type": this.myFile.type,
          "filename": this.myFile.name,
          "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")
        }

      } else {
        this.profileData.user.avatar = null;
      }

    }

    //console.log(this.profileData);
    let resList = await this.userBusiness.UpdateUserProfile(this.profileData, 'user/update').subscribe((result) => {
      //console.log(result);
      if (result.response) {
        //this.getUserInformation();
        this.router.navigate(['updatesuccess']);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  /** Password validation Function */
  validatePassword(val: any) {
    if (val != "") {
      if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
        this.invalidPassword = 'hidden';
        // this.invalidNotePassword = 'none';
      } else {
        this.invalidPassword = 'visible';
        //this.invalidNotePassword = 'block';
      }
    }
  }

  isInArray(array: any, word: any) {
    return array.indexOf(word.toLowerCase()) > -1;
  }

  /* For Image upload */
  fileChange(event: any) {
    //this.takePicture();
    let fileList: FileList = event.target.files;
    let file: File = fileList[0];
    var photoname = file.name;
    var allowedExtensions = ["jpg", "jpeg", "png", "JPG", "JPEG"];
    this.fileExtension = photoname.split('.').pop();

    if (fileList && file) {
      if (this.isInArray(allowedExtensions, this.fileExtension)) {
        this.fileExtensionError = 'hidden';
        if (file.size <= 6291456) {
          this.maxFileSize = 'hidden';
          this.myFile = file;
          console.log(this.myFile);
          /* For Base64 Image convert */
          var reader = new FileReader();
          reader.onload = this._handleReaderLoaded.bind(this, this.myFile);
          //reader.readAsBinaryString(file);
          reader.readAsDataURL(file);

        } else {
          this.maxFileSize = 'visible';
        }
      }
      else {
        this.fileExtensionError = 'visible';
      }
    }
  }

  /* For Base64 Image convert */
  _handleReaderLoaded(fileData: any, readerEvt: any) {
console.log(fileData)
    //console.log(readerEvt)
    var binaryString = readerEvt.target.result;
    this.base64textString = readerEvt.target.result;    
    this.staticProfileImage ="none";
    this.dynamicProfileImage ="block";
    
    this.previewImg = readerEvt.target.result
    //console.log(this.previewImg);
  }

  /* End Image upload */
  onChangePwd() {
    return this.modal.open(this.changepwd, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }

  /* Capture Images */

  handlePhotoSuccess(that: any) {
    return (stream: any) => {
      document.getElementById('previewCameraImg').style.display = 'none';
      //console.log('photo getUserMedia() got stream: ', stream);
      (<any>window).stream = stream;
      document.getElementById('camera_photo_wish').style.display = 'block';
      var photoDiv: any = document.getElementById('camera_photo_wish');
      let errorTag = document.getElementById('validateMessage');
      errorTag.textContent = "";
      errorTag.style.display = "none";
      if (window.URL) {
        photoDiv.src = window.URL.createObjectURL(stream);
      } else {
        photoDiv.src = stream;
      }
      that.photoText = "Take Picture";
      //console.log("phototext---", document.getElementById('photoText'));
      document.getElementById('photoText').textContent = "Take Picture";
      that.photoTaken = false;
      document.getElementById("loadingDiv").style.display = "none";

    }
  }

  handlePhotoError(that: any) {
    return (error: any) => {
      that.photoC = false;
      //console.log('Photo navigator.getUserMedia error: ', error);
      document.getElementById("loadingDiv").style.display = "none";
      let errorTag = document.getElementById('validateMessage');
      errorTag.textContent = "Oops! Please connect to your video/audio device";
      errorTag.style.display = "block";
    }
  }

  randomString(length: any) {
    var result = '';
    var temp = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (var i = length; i > 0; --i) result += temp[Math.round(Math.random() * (temp.length - 1))];
    return result;
  }

  takePicture() {
    var photoButton = document.getElementById("photoText");
    if (photoButton.textContent === 'Webcam') {
      if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
        document.getElementById("loadingDiv").style.display = "block";
        //document.getElementById('camera_photo_wish').style.display = 'block';
        this.initializePhoto();
      } else {
        document.getElementById('camera_flash_photo').style.display = 'block';
        let parentDiv = document.getElementById("user_image");
        WEBCAM4.reset();
        WEBCAM4.init();
        WEBCAM4.set({
          width: parentDiv.offsetWidth,
          height: parentDiv.offsetHeight,
          image_format: 'jpeg',
          jpeg_quality: 90
        });
        WEBCAM4.attach('#camera_flash_photo');
        this.photoTaken = false;

        setTimeout(function () {
          if (!WEBCAM4.params.cam_error) {
            document.getElementById("photoText").textContent = "Take Picture";
            this.photoText = "Take Picture";
            this.photoC = true;
            document.getElementById('previewCameraImg').style.display = 'none';
          }
        }, 2000);
      }

    } else if (photoButton.textContent === "Take Picture") {
      this.photoC = false;
      if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
        document.getElementById('camera_photo_wish').style.display = 'none';
        this.capturePhoto();
      } else {
        let self = this;
        if (!WEBCAM4.params.cam_error) {
          WEBCAM4.snap(function (data_uri: any) {
            //console.log(data_uri);
            self.base64textString = data_uri;
            self.previewImg = data_uri;
            document.getElementById('camera_flash_photo').style.display = 'none';
            self.photoText = "Webcam";
            document.getElementById("photoText").textContent = "Webcam";
            self.photoTaken = true;
            document.getElementById('previewCameraImg').style.display = 'block';
          });
        }
      }
    }
  }

  initializePhoto() {
    let self = this;
    this.photoC = true;
    navigator.mediaDevices.getUserMedia(this.photoOptions).
      then(this.handlePhotoSuccess(self)).catch(this.handlePhotoError(self));
  }

  capturePhoto() {
    //console.log("image capture area....");
    var video = document.getElementById("camera_photo_wish");
    var canvas: any = document.getElementById("drawCanvas");
    var ctx = canvas.getContext("2d");
    canvas.width = 150;
    canvas.height = 150;

    ctx.drawImage(video, 0, 0, 150, 113);
    //ctx.drawImage(video, 0, 0);    
    var dataURL = canvas.toDataURL();
    document.getElementById('previewCameraImg').style.display = 'block';
    this.previewImg = dataURL;
    this.base64textString = dataURL;
    document.getElementById('photoText').textContent = "Webcam";
    this.photoText = "Webcam";
    this.photoTaken = true;
    (<any>window).stream.getTracks()[0].stop();
  }
  detectMobile() {
    if (navigator.userAgent.match(/Android/i)
      || navigator.userAgent.match(/webOS/i)
      || navigator.userAgent.match(/iPhone/i)
      || navigator.userAgent.match(/iPad/i)
      || navigator.userAgent.match(/iPod/i)
      || navigator.userAgent.match(/BlackBerry/i)
      || navigator.userAgent.match(/Windows Phone/i)
    ) {
      return true;
    }
    else {
      return false;
    }
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

  /* End Capture images */

}