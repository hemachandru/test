import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { UserBusiness } from '../../business/user.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'message-view',
  templateUrl: './message-view.component.html',
  styleUrls: ['./message-view.component.scss']
})
export class MessageViewComponent implements OnInit ,OnDestroy {
  private messageId: any;
  private messageInfo: any;
  private msgDesFileName: any;

  constructor(private router: Router, private _location: Location, private activeRoute: ActivatedRoute, private userBusiness: UserBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    this.messageInfo = {
      audio_url: '',
      date: '',
      email: '',
      image_url: '',
      message: '',
      name: '',
      video_url: '',
      wish_image_url: ''
    }
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    var GetId = this.activeRoute.params.subscribe(params => {
      this.messageId = +params['id'];
    });
    if (this.messageId) {
      this.viewMessageInfo(this.messageId);
    }else{
      this.loaderService.display(false);
    }

  }
  goBack() {
    this._location.back();
  }

  async viewMessageInfo(id: any) {

    let resList = await this.userBusiness.getAPI('contributors/' + id).subscribe((result) => {
      if (result.response) {
        //console.log(result.message);
        let msgLen = result.message.message;
        //console.log(msgLen.length);
        if(msgLen.length < 22){
          this.msgDesFileName = msgLen;
        }else{
          //console.log('greater');
          this.msgDesFileName = msgLen.substr(0, 22);
        }
        this.messageInfo = result.message;
      }
    },
      (error) => {
        console.log(error);
      });
  }

  async deleteMessage(id: any, event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);    
    let resList = await this.userBusiness.DeleteAPI('contributors/' + this.messageId).subscribe((result) => {
      if (result.response) {
        console.log(result);
        this.router.navigate(['message-centre']);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}