import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
var RecordRTC = require('recordrtc');

import { UserBusiness } from '../../business/user.business';

@Component({
  selector: 'my-profile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.scss']
})

export class MyProfileComponent implements OnInit {
  public login: any;
  public video: any;
  public stream: any;
  public recordRTC: any;
  

  constructor(private router: Router, private userBusiness: UserBusiness) {
    this.video = [];
  }

  ngOnInit() {
    let video: HTMLVideoElement = this.video.nativeElement;
    // video.muted = false;
    // video.controls = true;
    // video.autoplay = false;
  }

  async socialLogins(LoginType: string) {
    //let userKey = await this.userBusiness.loginSocialAccount(LoginType);
  }

  // startRecording() {
  //   let mediaConstraints = {
  //     video: {
  //       mandatory: {
  //         minWidth: 1280,
  //         minHeight: 720
  //       }
  //     }, audio: true
  //   };
  //   navigator.mediaDevices
  //     .getUserMedia(mediaConstraints)
  //     .then(this.successCallback.bind(this));
  // }
  // successCallback(stream: MediaStream) {
  //   var options = {
  //     mimeType: 'video/webm', // or video/webm\;codecs=h264 or video/webm\;codecs=vp9
  //     audioBitsPerSecond: 128000,
  //     videoBitsPerSecond: 128000,
  //     bitsPerSecond: 128000 // if this line is provided, skip above two
  //   };
  //   this.stream = stream;
  //   this.recordRTC = RecordRTC(stream, options);
  //   this.recordRTC.startRecording();
  //   let video: HTMLVideoElement = this.video.nativeElement;
  //   video.src = window.URL.createObjectURL(stream);
  //   this.toggleControls();
  // }

  // toggleControls() {
  //   let video: HTMLVideoElement = this.video.nativeElement;
  //   video.muted = !video.muted;
  //   video.controls = !video.controls;
  //   video.autoplay = !video.autoplay;
  // }

  // stopRecording() {
  //   let recordRTC = this.recordRTC;
  //   recordRTC.stopRecording(this.processVideo.bind(this));
  //   let stream = this.stream;
  //   //stream.getAudioTracks().forEach(track => track.stop());
  //   //stream.getVideoTracks().forEach(track => track.stop());
  // }
  // processVideo(audioVideoWebMURL: any) {
  //   let video: HTMLVideoElement = this.video.nativeElement;
  //   let recordRTC = this.recordRTC;
  //   video.src = audioVideoWebMURL;
  //   this.toggleControls();
  //   var recordedBlob = recordRTC.getBlob();
  //   recordRTC.getDataURL(function (dataURL: any) { });
  // }

  // download() {
  //   this.recordRTC.save('video.webm');
  // }

}