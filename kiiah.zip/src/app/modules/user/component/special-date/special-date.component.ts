import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { UserBusiness } from '../../business/user.business';

@Component({
  selector: 'special-date',
  templateUrl: './special-date.component.html',
  styleUrls: ['./special-date.component.scss']
})

export class SpecialDateComponent implements OnInit, OnDestroy {

  public SpecialDateList: any;
  constructor(private router: Router, private _location: Location, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private userBusiness:UserBusiness) {
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.getUserInformation();
    this.loaderService.display(false);
  }

  async getUserInformation() {
    let resList = await this.userBusiness.GetSpecialDate('', 'wishes/get_specialdates').subscribe((result) => {
      if (result.response) {
        this.SpecialDateList = result.data.special_dates;
      }
    },
      (error) => {
        console.log(error);
      });
  }

  goBack() {
    this._location.back();    
  }

  EndSpecialDate(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('/',this);
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}