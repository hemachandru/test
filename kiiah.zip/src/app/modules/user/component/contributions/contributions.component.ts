import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { UserBusiness } from '../../business/user.business';

@Component({
  selector: 'contributions',
  templateUrl: './contributions.component.html',
  styleUrls: ['./contributions.component.scss']
})
export class ContributionsComponent implements OnInit, OnDestroy {

  private myContributionList: any;
  private totalAmount:any;
  private recordLength: any;
  constructor(private router: Router, private _location: Location, private loaderService: LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private userBusiness: UserBusiness) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.getUserContribution();
  }

  printPage(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    setTimeout(() => {
      window.print();      
    }, this.mojsBurstButtonAnimation.timeOutValue);
  }

  ngOnDestroy() {
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

  async getUserContribution() {
    let resList = await this.userBusiness.getUser('contributors/wish_contributors').subscribe((result) => {
      //console.log(result.length);
      
      if (result.response.length != 0) {
        this.myContributionList = result.message.contributors;
        this.recordLength = this.myContributionList.length;
        let amount = 0;
        this.myContributionList.forEach(function (value: any) {
          //if(result.message.name != null && result.message.name != ""){
            amount = amount + value.amount;
         // }
        });
        let testAmt = amount.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, "$1,");
        this.totalAmount = testAmt;
      }else{
        this.recordLength = this.myContributionList.length;
      }
      console.log(this.recordLength);

    },
      (error) => {
        console.log(error);
      });
  }
}