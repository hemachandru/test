import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './user.component.html',
    styleUrls: ['./user.component.scss']
})

export class UserComponent implements OnInit {
    public activeURL: string;
    private msgId: any;
    
   
    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });
        this.route.params.subscribe(params => {
            this.msgId = +params['id'];
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}