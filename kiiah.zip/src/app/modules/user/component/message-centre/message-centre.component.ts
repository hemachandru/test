import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { UserBusiness } from '../../business/user.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

//slim scroll
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
  selector: 'message-centre',
  templateUrl: './message-centre.component.html',
  styleUrls: ['./message-centre.component.scss']
})
export class MessageCentreComponent implements OnInit {
  private messageList: any;
  private messageLength: boolean = false;
  private messageList_Length: any;
  private messageList_Video:any;
  private messageList_Audio:any;

  //slim scroll
  public opts: ISlimScrollOptions;

  constructor(private router: Router, private _location: Location, private userBusiness: UserBusiness, private loaderService: LoaderService) {
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.getMessageList();

    //slim scroll
    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

  }

  messageview(id: any) {
    this.router.navigate(['message-view', id]);
  }

  async getMessageList() {
    let resultData: any = [];
    let resList = await this.userBusiness.getAPI('contributors/message_center').subscribe((result) => {
      let resultData = result.message.contributors;
      console.log(resultData.length);
      if (resultData.length > 0) {
        var showChar = 150;
        let messgeList: any = [];
       
        resultData.forEach(function (value: any) {
          //console.log(value.message.length);
          if (value.message != null && value.message != "") {
            //console.log('true',value.message);
            console.log(value);
            if (value.message.length > showChar) {
              var trimvalue = value.message.substr(0, showChar);
              value.message = trimvalue + '...';
              messgeList.push(value);
            }else{
              messgeList.push(value);
            }
          } else {
           // messgeList.push(value);
          }
          //console.log(messgeList.length);
        });
        this.messageList = messgeList
        this.messageLength = true;
        this.messageList_Length = messgeList.length
        //console.log(this.messageList);
      } else {
        this.messageLength = false;
        this.messageList_Length = resultData.length;
      }
    },
      (error) => {
        console.log(error);
      });
  }

}