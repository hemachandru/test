import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserRoutingModule } from './user.routing';
import { SlimScrollModule } from 'ng2-slimscroll';
import { ClickOutsideModule } from 'ng-click-outside';

import { UserComponent } from './component/user.component';
import { MyAccountComponent } from './component/myaccount/myaccount.component';
import { MyProfileComponent } from './component/myprofile/myprofile.component';
import { MessageCentreComponent } from './component/message-centre/message-centre.component';
import { MessageViewComponent } from './component/message-view/message-view.component';
import { ContributionsComponent } from './component/contributions/contributions.component';
import { SpecialDateComponent } from './component/special-date/special-date.component';
import { UserUpdateSuccessComponent } from './component/updatesuccess/updatesuccess.component';
import { UserBusiness } from './business/user.business';
import { UserService } from './service/user.service';
import { SharedModule } from '../share/translate-shared.module';
import { UtilityModule } from '../../utility/utility.module';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    UserRoutingModule,
    SlimScrollModule,
    ClickOutsideModule,
    SharedModule,
    UtilityModule
  ],
  declarations: [
    UserComponent,
    MyAccountComponent,
    MyProfileComponent,
    MessageCentreComponent,
    MessageViewComponent,
    SpecialDateComponent,
    ContributionsComponent,
    UserUpdateSuccessComponent
  ],
  providers: [UserBusiness, UserService, SharedModule]
})
export class UserModule { }

