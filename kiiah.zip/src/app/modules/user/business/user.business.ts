import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { UserService } from '../service/user.service'

@Injectable()
export class UserBusiness {

    constructor(public userService: UserService, public router: Router) {

    }

    getUser(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.apiGet(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    UpdateUserProfile(data: any, url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.apiUpdateUser(data, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getAPICurrencyList(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.apiGetCurrency(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getAPI(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.apiGetOnly(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    DeleteAPI(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.apiDelete(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    GetSpecialDate(data: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.userService.APISpecial(data, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}