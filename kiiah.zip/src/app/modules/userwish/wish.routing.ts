import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WishComponent } from './component/wish.component';

export const wishRoutes: Routes = [
  {
    path: '',
    component: WishComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(wishRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class WishRoutingModule { } 
