import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class WishService {

    constructor(private httpRequest: HttpRequestService) {

    }

    apiGetList(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiAddNewWish(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    }

    apiGetWishDetails(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiDeleteWish(url: string) {
        return this.httpRequest.deleteHttpRequestWithToken(url);
    }

    apiUpdateWish(data: any, url: string) {
        return this.httpRequest.putHttpRequest(data, url);
    }

    apiuserdetail(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

}