import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SlimScrollModule } from 'ng2-slimscroll';
import { ClickOutsideModule } from 'ng-click-outside';
//import {Autosize} from 'angular2-autosize';
//import {Autosize} from 'ng-autosize';

import { OnlyNumber } from './component/addwish/onlynumber.directive';
import { WishComponent } from './component/wish.component';

import { WishTypeComponent } from './component/wishtype/wishtype.component';
import { UserWishComponent } from './component/userwish/userwish.component';
import { WishSuccessComponent } from './component/wish-success/wishsuccess.component';
import { AddWishComponent } from './component/addwish/addwish.component';
import { FirstWishComponent } from './component/firstwish/firstwish.component';
import { UtilityModule } from '../../utility/utility.module';

import { WishRoutingModule } from './wish.routing';
import { MyDatePickerModule } from 'mydatepicker';

import { WishListBusiness } from './business/wish.business';
import { WishService } from './service/wish.service';
import { SharedModule } from '../share/translate-shared.module';
import { PaymentBusiness } from '../payment/business/payment.business';
import { PaymentService } from '../payment/service/payment.service';
import { LayoutBusiness } from '../layout/business/layout.business';
import { LayoutService } from '../layout/service/layout.service';


@NgModule({
  imports: [
    CommonModule,
    WishRoutingModule,
    FormsModule,
    MyDatePickerModule,
    SlimScrollModule,
    ClickOutsideModule,
    UtilityModule,
    SharedModule
  ],
  declarations: [
    WishComponent,
    WishTypeComponent,
    UserWishComponent,    
    AddWishComponent,
    WishSuccessComponent,
   // Autosize,
    OnlyNumber,
    FirstWishComponent
  ],
  providers: [WishListBusiness, WishService, SharedModule, PaymentBusiness, PaymentService, LayoutBusiness, LayoutService]
})
export class WishModule { }

