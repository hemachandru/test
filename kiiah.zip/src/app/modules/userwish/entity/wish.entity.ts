export interface userWish {
    wish_type_id: string;
    title: string;
    description: string;
    value: string;
    image_attributes: any;
}



