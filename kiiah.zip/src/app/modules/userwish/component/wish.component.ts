import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './wish.component.html',
    styleUrls: ['./wish.component.scss']
})

export class WishComponent implements OnInit {
    public activeURL: string;
    public createWish = true;
    public wishId: any;

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });

        this.route.params.subscribe(params => {
            this.wishId = +params['id']; // (+) converts string 'id' to a number
            localStorage.setItem('wishIds', this.wishId);
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}