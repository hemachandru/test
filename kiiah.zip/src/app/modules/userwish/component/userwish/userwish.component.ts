import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, EventEmitter, ViewChild, AfterViewInit, OnDestroy, TemplateRef, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
import { WishTypeComponent } from '../wishtype/wishtype.component';
import { WishListBusiness } from '../../business/wish.business';

import { LayoutBusiness } from '../../../layout/business/layout.business';
import { PaymentBusiness } from '../../../payment/business/payment.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
  selector: 'user-wish',
  templateUrl: './userwish.component.html',
  styleUrls: ['./userwish.component.scss']
})

//@ViewChild('description') textDesc;

export class UserWishComponent implements OnInit, AfterViewInit, OnDestroy {
  public opts: ISlimScrollOptions;
  public userWish: any = null;
  public listItem: boolean = false;
  public btnLabel: string;
  public titleHeader: string;
  public wishlist: any;
  //public showNextPage: any;
  public WishDetails: any;
  public WishId: any;
  public userName: any;
  public paypalAccount: any = true;
  public imgUrl: any;
  public userProfileInfo: any;
  public WishDetails_Total: any;
  public WishDetail_Percentage: any;
  public WishDetail_Total_Value: any;

  public progress_display_style_click: any;
  public progress_display_style_load: any;

  public WishDetail_Percentage_W: any;
  public WishDetail_Total_Value_W: any;
  public CurrencySymbol: any;
  public CurrencyCountryCode: any;
//CurrencySymbol CurrencyCountryCode

  @ViewChild('changepwd') public changepwd: TemplateRef<any>;
  @ViewChild('confirmDelete') public confirmDelete: TemplateRef<any>;
  dialog: DialogRef<any>;

  public createWish = true;
  //public wishlist: any;
  public listCount: boolean = false;
  public paypal = false;
  private MyWishList: Array<any>;
  public fullDescription: any;
  //private userName: any;
  public profileInfo: any;
  private amtChk: any;
  private deleteWishId: any;
  private deleteWishStatus: boolean = true;

  constructor(private router: Router, private _location: Location, private wishlistBusiness: WishListBusiness, private route: ActivatedRoute,
    private loaderService: LoaderService, private paymentBusiness: PaymentBusiness, private layoutBusiness: LayoutBusiness,
    private mojsBurstButtonAnimation: MojsBurstButtonAnimation, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, public pageLocation: PlatformLocation) {
    //this.showNextPage = 0;
    localStorage.setItem("shareWishOrCreateWish", "false");
    overlay.defaultViewContainer = vcRef;

    pageLocation.onPopState(() => {
      if (this.dialog) {
        this.onClose();
      }
    });
  }

  public myFocusTriggeringEventEmitter = new EventEmitter<boolean>();

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.WishDetails = {
      id: '',
      date: '',
      description: '',
      secure_link: '',
      value: '',
      wish_type: '',
      title: '',
      status: ''
    }
    this.progress_display_style_click = 'none';
    this.progress_display_style_load = 'block';

    this.btnLabel = 'Add Wish';
    var GetId = this.route.params.subscribe(params => {
      this.WishId = +params['id'];
    });
    this.loaderService.display(false);

    this.userName = localStorage.getItem('userName');
    var fixed = document.getElementById('loadingDiv');

    fixed.addEventListener('touchmove', function (e) {
      e.preventDefault();
    }, false);


    this.loaderService.display(true);

    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

    // this.getWishAPI();
    this.getWishList();
    this.getUserInfo();
  }
  ngAfterViewInit() {
    document.getElementById("loadingDiv").style.display = "none";
  }

  goBack() {
    this._location.back();
  }


  createNewWish(event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('addwish', this);
  }

  async getWishDetails(wishId: any) {
    this.progress_display_style_click = 'block';
    this.progress_display_style_load = 'none';
    let self = this;
    document.getElementById("loadingDiv").style.display = "block";
    let resList = await this.wishlistBusiness.putWishDetails('wishes/' + wishId).subscribe((result) => {
      //console.log(result.data);
      if (result.response) {
        var amtResutData = result.data.amount_paid;
        let amountTotal = "0";
        let amountTotal_int = parseInt(amountTotal);
        let amountPercentage;
        let finalPercent;
        var notVal = amtResutData.length;
        if(notVal == 0){
          this.progress_display_style_click = 'none';
          this.progress_display_style_load = 'none';
        }
        amtResutData.forEach(function (amtvalue: any) {
          var amtType = typeof amtvalue.amount;
          if (amtType == 'number') {
            amountTotal_int
            amountTotal_int = amtvalue.amount + amountTotal_int;
            amountPercentage = Math.round((amountTotal_int / result.data.value) * 100);

            if(amountPercentage > 100){
              let per = 100;
              finalPercent = per + "%";
            }else{
              finalPercent = amountPercentage + "%";
            }
            self.WishDetails_Total = amountTotal_int;
            self.WishDetail_Percentage = finalPercent;
            //alert('Not Null value %')
          } else {
            amountTotal_int = 0;
            finalPercent = "0%";
            self.WishDetails_Total = amountTotal_int;
            self.WishDetail_Percentage = finalPercent;
            //alert('Null value %')
          }
          
          // console.log('-----------');
          //  console.log(amountTotal_int);
          //  console.log(finalPercent);
        });
        var num = result.data.value;
        if(num == null || num == ""){
          var n = num;
        }else{
          var n = num.toFixed(2);
        }
        

        self.WishDetail_Total_Value = n;
        //result.data.value
        this.WishDetails = result.data;
        this.imgUrl = this.WishDetails.image_url ? this.WishDetails.image_url : 'not';
        this.userWish = 'yes';
        document.getElementById("loadingDiv").style.display = "none";
        localStorage.setItem('wishTypeId', result.data.wish_type_id);
        localStorage.setItem('selectedWishDate', result.data.date);
      }
    },
      (error) => {
        console.log(error);
        document.getElementById("loadingDiv").style.display = "none";
      });
  }

  async deleteWish(wishId: any, event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let resList = await this.wishlistBusiness.deleteDetails('wishes/' + wishId).subscribe((result) => {
      if (result.response) {
        this.deleteWishStatus = true;       
        this.getWishList();
        this.onClose();
      } else {
        this.deleteWishStatus = false;
      }
    },
      (error) => {
        console.log(error);
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      });
  }

  editWish(Id: any, event: any) {
    let wishState = 'editWish';
    sessionStorage.setItem('wishState', wishState);
    //alert('hai');
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('addwish', this, Id);
  }

  async shareWishList(event: any) {
    let invitation_Via = "share";
    localStorage.setItem("invitation_Via",invitation_Via);
    this.mojsBurstButtonAnimation.createMojsStyle(event);

      if (this.userProfileInfo) {
        localStorage.setItem("shareWishOrCreateWish", "true");
        
        if (this.userProfileInfo.paypal_name) {          
          this.getUserInformation(this.userProfileInfo);
        } else {
          //this.router.navigate(['payment-type']);

          let display_style_account = "false";
          sessionStorage.setItem('display_style_account', display_style_account);
          let display_style_payment = "true";
          sessionStorage.setItem('display_style_payment', display_style_payment);

          this.router.navigate(['share-notification']);
        }
      }
    
  }

  async getUserInformation(accountInfo: any) {
    console.log(accountInfo);
    let first_name = accountInfo.first_name;
    let last_name = accountInfo.last_name;
    let full_name = accountInfo.full_name;
    let dob = accountInfo.dob;
    let phone = accountInfo.phone;
    let address = accountInfo.address;
    let city = accountInfo.city;
    let post_code = accountInfo.post_code;
    let email = accountInfo.email;
    let currency_id = accountInfo.currency_id;
    let paypal_name = accountInfo.paypal_name;
    let country = accountInfo.country;

    if (first_name == null || last_name == null || full_name == null || dob == null || phone == null || address == null || city == null || post_code == null || email == null || currency_id == null || paypal_name == null || country == null) {
      let isSessionMyAccount = "true";
      sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);

      let display_style_account = "true";
      sessionStorage.setItem('display_style_account', display_style_account);
      let display_style_payment = "false";
      sessionStorage.setItem('display_style_payment', display_style_payment);

      this.router.navigate(['share-notification']);

      //this.router.navigate(['myaccount']);
      // alert('null');
    } else {
      let isSessionMyAccount = "false";
      sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);
      //this.router.navigate(['share-login']);
      this.invitationStudio();
      //alert('not null');
    }
  }

  async invitationStudio() {
    let resList = await this.layoutBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
      if (result.response) {
        //console.log(result.message)
        this.router.navigate(['/wishlist-invitation']);
      } else {
        this.router.navigate(['/myinvitation/edit']);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  ngOnDestroy() {
    //this.loaderService.display(false);
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

  /* For Wish list Only */

  async getUserInfo() {
    let resList = await this.wishlistBusiness.getUserdetail('user/profile').subscribe((result) => {
      //console.log(result.data);
      if (result.response) {
        this.userProfileInfo = result.data.profile;
        let userName = result.data.profile.full_name ? result.data.profile.full_name : '';
        localStorage.setItem('userName', userName);
      }
      this.userName = localStorage.getItem('userName');
      //result.data.profile.currency_id
      let curId = result.data.profile.currency_id;
      sessionStorage.setItem('curId', curId);
      this.getCurrencyList();
    },
      (error) => {
        console.log(error);
      });
  }

  async getCurrencyList() {
    let currency_id = sessionStorage.getItem('curId');
    console.log(currency_id)
    console.log('---------------------------------------------------');
    let self = this;
    let resList = await this.wishlistBusiness.APIGetOnly('currency').subscribe((result) => {
        //console.log(result.data); //id   code    currency_symbol   name
        for(let i = 0; i<result.data.length; i++){
          //console.log('Index : ',i,'--Currency Id : ',result.data[i].id,'--Currency Name : ',result.data[i].name);
          if(currency_id == result.data[i].id){
            //console.log(i,' : True : ',  result.data[i].id);
            //CurrencySymbol CurrencyCountryCode
            this.CurrencySymbol = result.data[i].currency_symbol;
            this.CurrencyCountryCode = result.data[i].code;
          }
          //else{
            //console.log(i,' : False : ',  result.data[i].id);
          //}
        }
    },
      (error) => {
        console.log(error);
      });
  }

  async getWishList() {
    //alert('wish');
    let self = this;
    let resList = await this.wishlistBusiness.APIGetOnly('wishes').subscribe((result) => {
      var resultData = result.data;

      if (resultData.length > 0) {
       // console.log('----- ',resultData[0]);
        
        let amtResutDataF = resultData[0].amount_paid.length;
        let amountTotalF = "0";
        let amountTotalF_int = parseInt(amountTotalF);
        let amountPercentageF;
        let finalPercentF;
        let amtTypeF;
        
        for(var i = 0 ; i<amtResutDataF ; i++){
         // debugger;
          amtTypeF = typeof resultData[0].amount_paid[i].amount;
          if (amtTypeF == 'number') {
            amountTotalF_int
            amountTotalF_int = resultData[0].amount_paid[i].amount + amountTotalF_int;
            amountPercentageF = Math.round((amountTotalF_int / resultData[0].value) * 100);
              if(amountPercentageF > 100){
                let per = 100;
                finalPercentF = per + "%";
              }else{
                finalPercentF = amountPercentageF + "%";
              }

            this.WishDetail_Percentage_W =  finalPercentF;
            this.WishDetail_Total_Value_W = amountTotalF_int;                   

          }
          else{
            amountTotalF_int = 0;
            finalPercentF = "0%";

            this.WishDetail_Percentage_W =  finalPercentF;
            this.WishDetail_Total_Value_W = amountTotalF_int;          
            
          }
          
        }
        

        var showChar = 150;
        let wishlist: any = [];

        resultData.forEach(function (value: any) {

          var amtResutData = value.amount_paid;
          let amountTotal = "0";
          let amountTotal_int = parseInt(amountTotal);
          let amountPercentage;
          let finalPercent;
          let amtType;
          //console.log(parseInt(amountTotal));
          //console.log("-----------",typeof amountTotal_int);
          amtResutData.forEach(function (amtvalue: any) {
            amtType = typeof amtvalue.amount;
            if (amtType == 'number') {
              amountTotal_int
              amountTotal_int = amtvalue.amount + amountTotal_int;
              amountPercentage = Math.round((amountTotal_int / value.value) * 100);
                  if(amountPercentage > 100){
                    let per = 100;
                    finalPercent = per + "%";
                  }else{
                    finalPercent = amountPercentage + "%";
                  }
              self.WishDetails_Total = amountTotal_int;
              self.WishDetail_Percentage = finalPercent;
            } else {
              amountTotal_int = 0;
              finalPercent = "0%";
              self.WishDetails_Total = amountTotal_int;
              self.WishDetail_Percentage = finalPercent;
            }
          });
 
          value.read_more = '';
          if (value.description.length > showChar) {
            var trimvalue = value.description.substr(0, showChar);

            //this.amtChk = "block";
            
            //let finalPercent = amountPercentage + "%";
            
            value['percentage'] = finalPercent;
            value['total'] = amountTotal_int;
            value.read_more = trimvalue;
            wishlist.push(value);
          } else {
            //this.amtChk = "none";
            amountPercentage = Math.round((amountTotal_int / value.value) * 100);
            //let finalPercent = amountPercentage + "%";
            if(amountPercentage > 100){
              let per = 100;
              finalPercent = per + "%";
            }else{
              finalPercent = amountPercentage + "%";
            }
            value['percentage'] = finalPercent;
            value['total'] = amountTotal_int;
            wishlist.push(value);
          }
          
          //console.log(value);
        });
        //console.log("myDetails",wishlist[0]);
        var num = wishlist[0].value;

        if(num == null || num == ""){
          var n = num;
        }else{
          var n = num.toFixed(2);
        }

        self.WishDetail_Total_Value = n;
        //self.WishDetail_Percentage = wishlist[0].percentage;

        this.WishDetails = wishlist[0];
        this.titleHeader = 'My Wishlist';
        this.imgUrl = this.WishDetails.image_url ? this.WishDetails.image_url : 'not';        
        this.userWish = 'yes';

        this.MyWishList = wishlist;
        this.listCount = true;
      } else {
        // this.userWish = 'no';          
        this.router.navigate(['firstwish']);
      }
      document.getElementById("loadingDiv").style.display = "none";
    },
      (error) => {
        console.log(error);
      });
  }

  viewDescription(value: any) {
    this.fullDescription = value;
    return this.modal.open(this.changepwd, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }

  addwish() {
    this.router.navigate(['addwish']);
  }

  confirmDeleteWindow(id: any, event: any) { 
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.deleteWishId = id;
    return this.modal.open(this.confirmDelete, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }

  /* End End */

}