import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, EventEmitter, TemplateRef, ViewChild, ViewContainerRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
import { WishTypeComponent } from '../wishtype/wishtype.component';
import { WishListBusiness } from '../../business/wish.business';
import { FileUpload } from '../../../../utility/fileUpload'

import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

var WEBCAM4 = require("./../../../../../assets/js/webcam.js");
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SharedModule } from '../../../share/translate-shared.module';

import { NgClass } from '@angular/common';

const Amounts = [
  { id: 10.00, value: '10.00', code: 'CDN' },
  { id: 25.00, value: '25.00', code: 'CDN' },
  { id: 45.00, value: '45.00', code: 'CDN' },
  { id: 75.00, value: '75.00', code: 'CDN' },
  { id: 100.00, value: '100.00', code: 'CDN' }
];

@Component({
  selector: 'add-wish',
  templateUrl: './addwish.component.html',
  styleUrls: ['./addwish.component.scss']
})


export class AddWishComponent implements OnInit, OnDestroy {

  @ViewChild('viewDesc') public viewDesc: TemplateRef<any>;
  dialog: DialogRef<any>;

  public chkSelectCountrySelect: any;
  public cursorChecker: any;
  public WishDescription = false;
  public NextWish = 'addwish';
  public showNextPage: any;
  public btnLabel: string;
  public titleLabel: string;

  public chkSelect: any;
  public wishlist: any;
  public wasClicked = false;
  public wishTitle: any;
  public dropdownList: string = 'visible';
  public wishValue: string;
  public wishCurrencyType: string;
  public currencyList: any;
  public wishValues = Amounts;
  public descriptionList: any;
  public currencyClicked = false;
  public wasWishClicked = false;

  public maxFileSize: any = 'hidden';
  public myFile: any;
  public base64textString: any;
  public previewImg: any = null;

  public WishId: any;
  public validateMessage: any;

  public opts: ISlimScrollOptions;
  public delay = false;
  public fileExtension: any;
  public fileExtensionError: any;
  public userName: any;

  public photoText: string;
  public photoOptions: any;
  public photoTaken: boolean = false;
  public isMobile: any;

  public wishDesclable: any;
  public previewCameraImg: boolean = false;

  public photoC: boolean = false;
  public currencySymbol: any = "$";
  public currencyCode: any = "CDN";
  private read_more = '';
  private fullDescription: any;
  public pay_currency_id: any;
  private selectedCurrency: boolean = false;
  private selectedWishValue: boolean = false;

  private countryDisable: boolean = true
  private isValid: boolean = true;
  private display_style = 'block';
  private txt_display_style = 'none';
  public currency_display = 'block'
  private txt_error_msg_country_select_once:any;
  private txtAreaHight: any;
  private txtAreaScrol: any;
  private mrgn_desDrop: any;
  public amtValidClr: string = '#666666';

  //textarea dropdown start
  public defaultTextareaDrp  = 'block';
  public selectTextareaDrp  = 'none';
  public charaterMax: any;
  //tedtarea dropdown end
  public convertedMoney: any;
  public txtCurrencyClr = '#666666';
  public txtCurrencyLabel  = 'none';

  public keynum : any;
  public lines = 1;
  public twolines = 1;
  public txtAreaDynamicScale : any;
  public zindexCheck: any;
  public zindexCheckHigh: any;

  public drpDescriptionnew: any;
  public drpDescriptionColor: any;
  public drpZindex:any;

  public drpWishAmountnew: any;
  public drpWishAmountColor: any;

  public drpWishCountrynew: any;
  public drpWishCountryColor: any;
  public drpWishCountryZIndexClass: any;

  public myEditDescClass:any;
  public myEditClassDesc:any;

  public autoFocus = "false";

  constructor(private router: Router, private _location: Location, private wishlistBusiness: WishListBusiness, private fileUpload: FileUpload, private route: ActivatedRoute, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private pageLocation: PlatformLocation, private Shared: SharedModule, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService: LoaderService) {
    overlay.defaultViewContainer = vcRef;

    this.wishlist = {
      currency: '',
      description: '',
      title: '',
      value: '',
      date: '',
      wish_type_id: '',
      image_attributes: {
        avatar: {
          content_type: '',
          filename: '',
          file_data: ''
        }
      }
    }
    pageLocation.onPopState(() => {
      if (this.dialog) {
        this.onClose();
      }
    });
  }

  public myFocusTriggeringEventEmitter = new EventEmitter<boolean>();

  ngOnInit() {
    this.zindexCheck = '1';
    
    this.drpDescriptionnew = 'select or write wish description';
    this.drpDescriptionColor = '#ff3504';
    this.drpZindex = '0';

    this.drpWishCountrynew = 'select or enter gift currency';
    this.drpWishCountryColor = '#ff3504';

    this.drpWishAmountnew = 'select or enter approx gift price';
    this.drpWishAmountColor = '#ff3504';

    let wishStateGet =  sessionStorage.getItem('wishState');
    if(wishStateGet == 'addNew'){
      //alert(wishStateGet);
      // this.txtAreaHight = '28px';
      // this.txtAreaScrol = 'hidden';
      // this.mrgn_desDrop = '-50px';
    }else{
      //alert(wishStateGet);
      // this.txtAreaHight = '65px';
      // this.txtAreaScrol = 'auto';
      // this.mrgn_desDrop = '-30px';
    }
    
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    var fixed = document.getElementById('loadingDiv');

    fixed.addEventListener('touchmove', function (e) {

      e.preventDefault();

    }, false);
    this.isMobile = this.detectMobile();
    this.getUserInfo();
    this.getDescriptionList();

    this.showNextPage = 1;
    this.btnLabel = 'next';
    this.titleLabel = 'Create A Wish';
    this.wishValue = 'give your wish an approx price';
    //this.wishCurrencyType = "select gift currency (1st time only)";
    this.wishDesclable = 'tell everyone about your wish';

    var GetId = this.route.params.subscribe(params => {
      this.WishId = +params['id'];
    });

    if (this.WishId) {
      this.getEditWishInfo(this.WishId);
      //localStorage.setItem('wishTypeId', '');
    } else {
      localStorage.setItem('wishTypeId', '');
      localStorage.setItem('selectedWishDate', 'null');
    }
    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    this.photoOptions = {
      audio: false,
      video: true
    };
    this.photoText = "Webcam";

    this.userName = localStorage.getItem('userName');
    this.loaderService.display(false);
    //this.pay_currency_id = 0;
  }


  onKeydownTextarea(e: Event){
    let target = e.target || e.srcElement || e.currentTarget;
     
    let self =this;
     if(window.event) {
      self.keynum = e.srcElement.clientHeight; 
      }

      if(self.keynum >=167) {
        self.txtAreaDynamicScale = '1';
      }else {
        self.txtAreaDynamicScale = '0';
      }    
  }


  onClickedOutside(e: Event) {
    var drop = document.getElementById("currencyvalue");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.currencyClicked = false;
    }else{
      this.drpWishCountrynew = 'select gift currency (1st time only)';
      this.drpWishCountryColor= '#ff3504';
      this.drpWishCountryZIndexClass = '1';
    }
  }
  onClickedOutside2(e: Event) {
    var drop = document.getElementById("wishvalue");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.wasWishClicked = false;
    }else{
      this.drpWishAmountnew = 'select or enter approx gift price';
      this.drpWishAmountColor = '#ff3504';
    }
  }
  onClickedOutside3(e: Event) {
    var drop = document.getElementById("wishDescriptionDropDown");
    this.myEditClassDesc = 0;
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.myEditClassDesc = 1;
      this.wasClicked = false;
    }else{
      this.drpDescriptionnew = 'select or write wish description';
      this.drpDescriptionColor = '#ff3504';
      this.drpZindex = '0';
    }
  }
  wishValidation(showId: any) {
    if (showId == 1) {
     // console.log('calender_icon');
      if (this.wishlist.wish_type_id != '') {
        this.validateMessage = '';
        this.showNextPage = this.showNextPage + 1;
      } else {
        this.validateMessage = 'pls, select wish occasion';
      }
    } else if (showId == 2) {
      this.zindexCheck = '0';
      this.validateMessage = '';
      this.showNextPage = this.showNextPage + 1;
    } else if (showId == 3) {

      let test = sessionStorage.getItem('CountryName');
      this.wishCurrencyType = test;

      if (typeof this.wishlist.description != 'undefined' && this.wishlist.description != '') {
        this.validateMessage = '';
        this.showNextPage = this.showNextPage + 1;
        //alert('hai description : '+ this.wishlist.description);
      } else {
       // alert('hai description : '+ this.wishlist.description);
       // this.validateMessage = 'enter any wish descriptions';
      }
    } else if (showId == 4) {
      
      var num = this.wishlist.value;
      var n = parseFloat(num).toFixed(2);
      this.convertedMoney = n; 
      console.log(this.convertedMoney);

      if (typeof this.wishlist.value != 'undefined' && this.wishlist.value != "") {
        this.validateMessage = '';
        this.showNextPage = this.showNextPage + 1;
      } else {
        this.amtValidClr = 'red';
      }
      var showChar = 150;
      if (this.wishlist.description.length > showChar) {
        this.read_more = this.wishlist.description.substr(0, showChar);
      }
    }
  }

  callNextWish(event: any) {
    this.zindexCheck = '1';
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.isValid = false;
    
    if (this.showNextPage == 2) {
      this.myEditDescClass = 1;
      let ss = sessionStorage.getItem('wishState');
      //myEditClassDesc
      if(this.myEditDescClass == 1 && ss == 'editWish'){
        this.myEditClassDesc = 1;
      }else{
        this.myEditClassDesc = 0;
      }
    }else{
      this.myEditDescClass = 0;
    }

    if (this.showNextPage < 5) {
      setTimeout(() => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        this.wishValidation(this.showNextPage);
      }, this.mojsBurstButtonAnimation.timeOutValue);
    }

    if (this.showNextPage == 5) {
      this.btnLabel = 'save wish';
    } else {
      this.btnLabel = 'next';
    }

    if (this.showNextPage === 3) {
      if (!this.isMobile) {
        let takePictureTag = document.getElementById('photoText');
        if (takePictureTag.textContent === "Take Picture") {
          this.photoC = false;
          takePictureTag.textContent = "Webcam";
          document.getElementById('camera_photo_wish').style.display = 'none';
          document.getElementById('camera_flash_photo').style.display = 'none';
          document.getElementById('previewCameraImg').style.display = 'block';
          this.photoText = "Webcam";
        }
      }
    }
  }


  goBack() {
    this.zindexCheck = '1';
    
    this.validateMessage = '';
    if (this.showNextPage === 4 || this.showNextPage === 3) {
      this.drpWishCountryZIndexClass = '0';
      this.zindexCheck = '1';
    }else{
      //this.zindexCheck = '0';
    }

    if (this.showNextPage === 2) {
      if (!this.isMobile) {
        let takePictureTag = document.getElementById('photoText');
        if (takePictureTag.textContent === "Take Picture") {
          this.photoC = false;
          takePictureTag.textContent = "Webcam";
          document.getElementById('camera_photo_wish').style.display = 'none';
          document.getElementById('camera_flash_photo').style.display = 'none';
          document.getElementById('previewCameraImg').style.display = 'block';
          this.photoText = "Webcam";
        }
      }
    }

    if (this.showNextPage == 1) {
      this._location.back();
      //this.router.navigate(['userwish']);
    } else if (this.showNextPage <= 5) {
      this.showNextPage = this.showNextPage - 1;
      this.btnLabel = this.showNextPage == 5 ? 'save wish' : 'next';

    }

    // else {
    //   this.btnLabel = 'next';
    // }
  }

  async getUserInfo() {
    let resList = await this.wishlistBusiness.APIGetOnly('user/profile').subscribe((result) => {
      //console.log(result);
      if (result.response) {
        if (result.data.profile.currency_id) {
          this.pay_currency_id = result.data.profile.currency_id;
          let curId = result.data.profile.currency_id;
          localStorage.setItem('currency_id', curId);
        }
        if (result.data.profile.full_name != null) {
          let userName = result.data.profile.full_name;
          localStorage.setItem('userName', userName);
        }
        this.userName = localStorage.getItem('userName');
      }
      this.getCurrencyList();
    },
      (error) => {
        console.log(error);
      });
    //alert('end first...!');
  }

  async getCurrencyList() {
    let currency_id = localStorage.getItem('currency_id');
    let self = this;
    let resList = await this.wishlistBusiness.APIGetOnly('currency').subscribe((result) => {
      if (result.response) {
        if (result.data.length == 0) {
          self.clearDropdown();
        }
        //console.log(result.data);
        self.currencyList = result.data;
        if (currency_id) {
          this.chkSelectCountrySelect = 'selected';
          this.cursorChecker = 'pointer';
          self.currencyList.forEach(function (value: any) {
            if (currency_id == value.id) {
              self.getCurrencyValue(value);
            }
          });
        } else {
          this.cursorChecker = 'not-allowed';
          this.chkSelectCountrySelect = 'no_select';
          this.countryDisable = false;
        }
        //alert(this.chkSelectCountrySelect);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  async getDescriptionList() {
    let resList = await this.wishlistBusiness.APIGetOnly('get_dropdown').subscribe((result) => {
      if (result.response) {
        console.log(result.data);
        if (result.data.length > 1) {
          this.descriptionList = result.data[0].dropdownvalue;
        } else {
          this.dropdownList = 'hidden';
          this.zindexCheck = '1';
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }

  randomString(length: any) {
    var result = '';
    var temp = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (var i = length; i > 0; --i) result += temp[Math.round(Math.random() * (temp.length - 1))];
    return result;
  }

  async saveWishList(wishListData: any, event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    document.getElementById("loadingDiv").style.display = "block";

    if (this.photoTaken) {
      let tempURL = this.base64textString.toLowerCase();
      let extension;

      if (tempURL.indexOf("png") !== -1)
        extension = "png"
      else if (tempURL.indexOf("jpg") !== -1 || tempURL.indexOf("jpeg") !== -1)
        extension = "jpg"
      else
        extension = "png"

      let photoFilename = this.randomString(10) + "." + extension;
      this.wishlist.image_attributes = {
        avatar: {
          "content_type": "image/" + extension,
          "filename": photoFilename,
          "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")
        }
      }
    }
    else {
      if (this.myFile) {
        this.wishlist.image_attributes = {
          avatar: {
            "content_type": this.myFile.type,
            "filename": this.myFile.name,
            "file_data": this.base64textString.replace(/^data:image\/[a-z]+;base64,/, "")
          }
        }
      } else {
        this.wishlist.image_attributes = {
          avatar: null
        };
      }

    }

    if (this.WishId) {
      let resList = await this.wishlistBusiness.updateWishList(wishListData, 'wishes/' + this.WishId).subscribe((result) => {
        if (result.response) {
          //this.router.navigate(['userwish', result.data.id]);
          this.router.navigate(['wishsuccess']);
          document.getElementById("loadingDiv").style.display = "none";
        }
      },
        (error) => {
          console.log(error);
          this.mojsBurstButtonAnimation.resetMojsStyle(document);
          document.getElementById("loadingDiv").style.display = "none";

        });
    } else {
      let resList = await this.wishlistBusiness.saveNewWishList(wishListData, 'wishes').subscribe((result) => {
        if (result.response) {
          //this.router.navigate(['userwish', result.data.id]);
          this.router.navigate(['wishsuccess']);
          document.getElementById("loadingDiv").style.display = "none";


        }
      },
        (error) => {
          console.log(error);
          this.mojsBurstButtonAnimation.resetMojsStyle(document);
          document.getElementById("loadingDiv").style.display = "none";

        });
    }
  }

  getName(wishName: any) {
    this.wishlist.wish_type_id = wishName.id;
    this.wishlist.title = wishName.name;
    this.wishTitle = wishName.name;
    this.validateMessage = '';
  }

  getWishDate(wishDate: any) {
    this.wishlist.date = wishDate.formatted
    //console.log('hai : ', this.wishlist.date);
  }

  onClick() {
    let drpDwn = document.getElementById("wishDescriptionDropDown").className;
    
    if(drpDwn == "wrapper-dropdown"){
      console.log('true');
      this.myEditClassDesc = 1;
    }else{
      console.log('false');
      this.myEditClassDesc = 0;
    }
    // let drpDwnAct = document.getElementById("active").className;
    // alert(drpDwnAct);

    if(drpDwn == 'wrapper-dropdown'){
      this.drpDescriptionnew = 'tell everyone about your wish';
      this.drpDescriptionColor= '#333';
      this.drpZindex = '1';
    }else{
      this.drpDescriptionnew = 'select or write wish description';
      this.drpDescriptionColor = '#ff3504';
      this.drpZindex = '0';
    }
    this.wasClicked = !this.wasClicked;
  }
  onCurrencyClick() {
    //alert('hai');
    let drpDwnCountry = document.getElementById("currencyvalue").className;
    console.log('--',drpDwnCountry)
    if(drpDwnCountry == 'wrapper-dropdown'){
      this.drpWishCountrynew = 'select gift currency (1st time only)';
      this.drpWishCountryColor= '#333';
      this.drpWishCountryZIndexClass = '1';
    }else{
      this.drpWishCountrynew = 'select or enter gift currency';
      this.drpWishCountryColor = '#ff3504';
      this.drpWishCountryZIndexClass = '0';
    }
    
    let currency_id = localStorage.getItem('currency_id');
    if (currency_id == null) {
      this.delay = true;
      this.currencyClicked = !this.currencyClicked;
      this.wasWishClicked = false;
      this.txt_error_msg_country_select_once = "";
    }else{
      this.txt_error_msg_country_select_once = "If you change gift currency means use my account";
    }
  }
  onWishClick() {
    let drpDwn = document.getElementById("wishvalue").className;    
        
    var myNoSelect = <HTMLInputElement>document.getElementById('UnCheckedSelecter');
    var myNoSelectGet = myNoSelect.textContent;

    if (myNoSelectGet == 'no_select') {
      this.cursorChecker = 'not-allowed';
    } else {
      this.wasWishClicked = !this.wasWishClicked;
      this.currencyClicked = false;
      this.cursorChecker = 'pointer';
      
      if(drpDwn == 'wrapper-dropdown'){
        this.drpWishAmountnew = 'give your wish an approx price';
        this.drpWishAmountColor= '#333';
      }else{
        this.drpWishAmountnew = 'select or enter approx gift price';
        this.drpWishAmountColor = '#ff3504';
      }

    }
    // this.wasWishClicked = !this.wasWishClicked;
    // this.currencyClicked = false;
  }

  textAreaShowList(){
    document.getElementById("description").focus();
    this.dropdownList = 'hidden';
    this.autoFocus = 'true';
    this.zindexCheck = '1';
    this.defaultTextareaDrp = 'none';
    this.selectTextareaDrp = 'block';
  }

  getDescription(value: any) {
    this.wishlist.description = value;
    document.getElementById("description").focus();
    // public defaultTextareaDrp: any;
    // public selectTextareaDrp: any;
    this.dropdownList = 'hidden'
    this.zindexCheck = '1';
    this.defaultTextareaDrp = 'none';
    this.selectTextareaDrp = 'block';
  }

  // onKeydown(event: any) {
  //   console.log(event);
  // }

  clearDropdown() {
    this.dropdownList = 'hidden';
    this.zindexCheck = '1';
  }
  showDropdown() {
    if (typeof this.wishlist.description == 'undefined' || this.wishlist.description == '') {
      this.dropdownList = 'visible';
      this.zindexCheck = '0';
      this.defaultTextareaDrp = 'block';
      this.selectTextareaDrp = 'none';
    } else {
      this.dropdownList = 'hidden';
      this.zindexCheck = '1';
      this.defaultTextareaDrp = 'none';
      this.selectTextareaDrp = 'block';
    }
  }

  showDropdownBlur() {
    if (typeof this.wishlist.description == 'undefined' || this.wishlist.description == '') {
      this.dropdownList = 'visible';
      this.zindexCheck = '0';
      this.defaultTextareaDrp = 'block';
      this.selectTextareaDrp = 'none';
    } else {
      this.dropdownList = 'hidden';
      this.zindexCheck = '1';
      this.defaultTextareaDrp = 'none';
      this.selectTextareaDrp = 'block';
    }
  }


  getWishValue(value: any) {
    //alert('dropdown : '+ value);
    this.wishValue = value;
    this.wishlist.value = value;
    this.selectedWishValue = true;
  }

  checkOthervalue() {
    //[ngStyle]="{ 'color': 'red', 'font-size': font_size, 'background-color': background_color }"
    //[ngStyle]="{ 'color': 'red'}"
    this.wishlist.value = '';
    this.display_style = 'none';
    this.txt_display_style = 'block';
  }

  checkOthervalueClose() {
    this.wishlist.value = '';
    //this.wishValue = 'give your wish an approx price';
    this.display_style = 'block';
    this.txt_display_style = 'none';
    this.drpWishAmountnew = 'select or enter approx gift price';
    this.drpWishAmountColor = '#ff3504';
  }

  onKeyClick(){
    this.txtCurrencyClr = '#666666';
    this.txtCurrencyLabel = 'none';
  }

  onKeyUpee(evt: any){
   // var charCode = evt; chandru
   if(evt == ""){
    this.txtCurrencyClr = '#666666';
    (<HTMLInputElement> document.getElementById("btnCurrencyChkBtn")).disabled = true;
   }

   this.txtCurrencyClr = '#666666';
    var ex = /^[0-9]+(\.[0-9]{1,2})?$/;    
    if(ex.test(evt)==false){
      this.txtCurrencyClr = '#ff3504';
      (<HTMLInputElement> document.getElementById("btnCurrencyChkBtn")).disabled = true;
      this.txtCurrencyLabel = 'block';
      //console.log('invalid');
     }else{
      this.txtCurrencyClr = '#666666';
      (<HTMLInputElement> document.getElementById("btnCurrencyChkBtn")).disabled = false;
      this.txtCurrencyLabel = 'none';
      //console.log('valid');
     }
  }

  getCurrencyValue(value: any) {
    let countryName = value.name;
    sessionStorage.setItem('CountryName', countryName);
    this.currencySymbol = value.currency_symbol;
    this.currencyCode = value.code;
    this.wishlist.currency = value.id;
    this.selectedCurrency = true;
    this.chkSelectCountrySelect = 'selected';
    this.cursorChecker = 'pointer';
    this.wishCurrencyType = value.name;
    this.currency_display = "none";
  }
  isInArray(array: any, word: any) {
    return array.indexOf(word.toLowerCase()) > -1;
  }
  /* For Image upload */
  fileChange(event: any) {
    this.isValid = false;
    let fileList: FileList = event.target.files;
    let file: File = fileList[0];
    var photoname = file.name;
    var allowedExtensions = ["jpg", "jpeg", "png", "JPG", "JPEG"];
    this.fileExtension = photoname.split('.').pop();

    if (fileList && file) {
      if (this.isInArray(allowedExtensions, this.fileExtension)) {
        this.fileExtensionError = 'hidden';
        if (file.size <= 6291456) {
          this.maxFileSize = 'hidden';
          this.myFile = file;

          /* For Base64 Image convert */
          var reader = new FileReader();
          reader.onload = this._handleReaderLoaded.bind(this, this.myFile);
          //reader.readAsBinaryString(file);
          reader.readAsDataURL(file);

        } else {
          this.maxFileSize = 'visible';
        }
      }
      else {
        this.fileExtensionError = 'visible';
      }
    }
  }

  /* For Base64 Image convert */
  _handleReaderLoaded(fileData: any, readerEvt: any) {
    //console.log(fileData)
    //console.log(readerEvt)
    var binaryString = readerEvt.target.result;
    this.base64textString = readerEvt.target.result;
    this.previewImg = readerEvt.target.result
    //console.log(this.previewImg);
  }

  /* End Image upload */



  /* Edit wish Info */
  async getEditWishInfo(wishid: any) {
    let resList = await this.wishlistBusiness.APIGetOnly('wishes/' + wishid).subscribe((result) => {
     // console.log('Result Data: ',result.data.description); 
      if(result.data.description == "" || result.data.description == null){
        this.defaultTextareaDrp = 'block';
        this.selectTextareaDrp = 'none';
      }else{
        this.defaultTextareaDrp = 'none';
        this.selectTextareaDrp = 'block';
      }

      if (result.response) {
        this.wishlist = result.data;
        this.previewImg = this.wishlist.image_url;
        this.wishDesclable = '';
        this.selectedWishValue = true;
        var num = result.data.value;
        var n = num.toFixed(2);
        this.wishValue = n; 
        localStorage.setItem('wishTypeId', result.data.wish_type_id);
        localStorage.setItem('selectedWishDate', result.data.date);
        this.clearDropdown();
      }
    },
      (error) => {
        console.log(error);
      });
  }

  handlePhotoSuccess(that: any) {
    return (stream: any) => {
      document.getElementById('previewCameraImg').style.display = 'none';
      //console.log('photo getUserMedia() got stream: ', stream);
      (<any>window).stream = stream;
      document.getElementById('camera_photo_wish').style.display = 'block';
      var photoDiv: any = document.getElementById('camera_photo_wish');
      let errorTag = document.getElementById('validateMessage');
      errorTag.textContent = "";
      errorTag.style.display = "none";
      if (window.URL) {
        photoDiv.src = window.URL.createObjectURL(stream);
      } else {
        photoDiv.src = stream;
      }
      that.photoText = "Take Picture";
      document.getElementById('photoText').textContent = "Take Picture";
      that.photoTaken = false;
      document.getElementById("loadingDiv").style.display = "none";

    }
  }

  handlePhotoError(that: any) {
    return (error: any) => {
      that.photoC = false;
      console.log('Photo navigator.getUserMedia error: ', error);
      document.getElementById("loadingDiv").style.display = "none";
      let errorTag = document.getElementById('validateMessage');
      errorTag.textContent = "Oops! Please connect to your video/audio device";
      errorTag.style.display = "block";
    }
  }

  takePicture() {
    this.isValid = true;
    //alert('takePicture'+ this.isValid);
    var photoButton = document.getElementById("photoText");
    if (photoButton.textContent === 'Webcam') {
      if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
        document.getElementById("loadingDiv").style.display = "block";
        document.getElementById('camera_flash_photo').style.display = 'block';
        this.initializePhoto();
      } else {
        document.getElementById('camera_flash_photo').style.display = 'block';
        let parentDiv = document.getElementById("user_image");
        WEBCAM4.reset();
        WEBCAM4.init();
        WEBCAM4.set({
          width: parentDiv.offsetWidth,
          height: parentDiv.offsetHeight,
          image_format: 'jpeg',
          jpeg_quality: 90
        });
        WEBCAM4.attach('#camera_flash_photo');
        this.photoTaken = false;

        setTimeout(function () {
          if (!WEBCAM4.params.cam_error) {
            document.getElementById("photoText").textContent = "Take Picture";
            this.photoText = "Take Picture";
            this.photoC = true;
            document.getElementById('previewCameraImg').style.display = 'none';
          }
        }, 2000);
      }

    } else if (photoButton.textContent === "Take Picture") {
      this.photoC = false;
      if (navigator.getUserMedia || (<any>navigator).mozGetUserMedia) {
        document.getElementById('camera_photo_wish').style.display = 'none';
        this.capturePhoto();
      } else {
        let self = this;
        if (!WEBCAM4.params.cam_error) {
          WEBCAM4.snap(function (data_uri: any) {
            //console.log(data_uri);
            self.base64textString = data_uri;
            self.previewImg = data_uri;
            document.getElementById('camera_flash_photo').style.display = 'none';
            self.photoText = "Webcam";
            document.getElementById("photoText").textContent = "Webcam";
            self.photoTaken = true;
            document.getElementById('previewCameraImg').style.display = 'block';
          });
        }
      }
    }
  }

  initializePhoto() {
    let self = this;
    this.photoC = true;
    navigator.mediaDevices.getUserMedia(this.photoOptions).
      then(this.handlePhotoSuccess(self)).catch(this.handlePhotoError(self));
  }

  capturePhoto() {
    console.log("image capture area....");
    document.getElementById('drawCanvas').style.display = 'none';
    var video = document.getElementById("camera_photo_wish");
    var user_img = document.getElementById("user_image");
    var positionInfo = user_img.getBoundingClientRect();
    var height = positionInfo.height;
    var width = positionInfo.width;
    var canvas: any = document.getElementById("drawCanvas");
    var ctx = canvas.getContext("2d");
    canvas.width = 410;
    canvas.height = 270;
    ctx.drawImage(video, 0, 0, 410, 270);
    // console.log("video.offsetWidth", width);
    // console.log("video.offsetHeight", height);
    var dataURL = canvas.toDataURL();

    //console.log(dataURL);
    document.getElementById('previewCameraImg').style.display = 'block';
    this.previewImg = dataURL;
    this.base64textString = dataURL;
    document.getElementById('photoText').textContent = "Webcam";
    this.photoText = "Webcam";
    this.photoTaken = true;
    (<any>window).stream.getTracks()[0].stop();
  }
  detectMobile() {
    if (navigator.userAgent.match(/Android/i)
      || navigator.userAgent.match(/webOS/i)
      || navigator.userAgent.match(/iPhone/i)
      || navigator.userAgent.match(/iPad/i)
      || navigator.userAgent.match(/iPod/i)
      || navigator.userAgent.match(/BlackBerry/i)
      || navigator.userAgent.match(/Windows Phone/i)
    ) {
      return true;
    }
    else {
      return false;
    }
  }


  viewDescription(value: any) {
    this.fullDescription = value;
    return this.modal.open(this.viewDesc, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }

  ngOnDestroy() {
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }


}
