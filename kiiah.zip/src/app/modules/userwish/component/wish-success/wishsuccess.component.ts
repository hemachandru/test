import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'wish-success',
  templateUrl: './wishsuccess.component.html',
  styleUrls: ['./wishsuccess.component.scss']
})


export class WishSuccessComponent implements OnInit ,OnDestroy{

  constructor(private router: Router, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    document.getElementById("loadingDiv").style.display = "none";
  }

  ngOnInit() {
    //this.getUserInformation();
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }
  goBack() {
    this._location.back();
  }
  mywishlist(event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('userwish',this);
  }
  
  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}