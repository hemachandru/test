//import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Output, EventEmitter, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { IMyOptions, IMySelector, IMyDateModel, IMyInputFieldChanged, MyDatePicker } from 'mydatepicker';
import { WishListBusiness } from '../../business/wish.business';
import { LoaderService } from '../../../../utility/helper.service';

@Component({
  selector: 'wish-type',
  templateUrl: './wishtype.component.html',
  styleUrls: ['./wishtype.component.scss']
})
export class WishTypeComponent implements OnInit, AfterViewInit {

  public date = new Date();
  private myDatePickerNormalOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'yyyy-mm-dd',
    firstDayOfWeek: 'su',
    height: 'auto',
    width: '100%',
    selectionTxtFontSize: '12px',
    minYear: 1900,
    //disableUntil: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() - 1 },    
    inline: false,
    sunHighlight: false,
    showTodayBtn: false,
    dayLabels: { su: 'S', mo: 'M', tu: 'T', we: 'W', th: 'T', fr: 'F', sa: 'S' }
  };

  public WishTypeList: any;
  public model: any;
  private selector: number = 0;
  public activeImg: any;
  public activeId: any;
  public calendarPicker: boolean = false;
  public selectedDate: any;
  public currentDate: any;

  @Output() wishTypeClick = new EventEmitter();
  @Output() onDateChange = new EventEmitter();
  //@ViewChild('mydp') mydp: MyDatePicker;

  constructor(private router: Router, private _location: Location, private wishlistBusiness: WishListBusiness, private elRef: ElementRef, private loaderService: LoaderService) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.getWishList();
    this.calendarPicker = false;
    this.activeId = localStorage.getItem('wishTypeId');
    this.selectedDate = localStorage.getItem('selectedWishDate');
    if(this.selectedDate == "null" ) {
      this.currentDate = new Date();
    }else{
      this.currentDate = new Date(this.selectedDate);
    }
    let FullYear = this.currentDate.getFullYear();
    let FullMonth = this.currentDate.getMonth() + 1
    let FullDay = this.currentDate.getDate()
    this.model = { date: { year: FullYear, month: FullMonth, day: FullDay } }
    
    if (this.activeId) {
      this.activeImg = true;
    }
    if (this.selectedDate!='null') {
      this.calendarPicker = true;
    }
    var fixed = document.getElementById('loadingDiv');
    fixed.addEventListener('touchmove', function (e) {
    e.preventDefault();
    }, false);
  }
  ngAfterViewInit() {
    document.getElementById("loadingDiv").style.display = "none";
  }
  goBack() {
    this._location.back();
  }

  onDateChanged(selectDate: any) {
    this.onDateChange.emit(selectDate);
    this.calendarPicker = true;
  }

  async getWishList() {
    let resList = await this.wishlistBusiness.getWishType('wish_types/list').subscribe((result) => {
      if (result.response) {
        this.loaderService.display(false);
        this.WishTypeList = result.data;
        this.activeId = localStorage.getItem('wishTypeId');
        document.getElementById("loadingDiv").style.display = "none";
        if (this.activeId) {
          this.activeImg = true;
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }

  getWishName(typeDetails: any) {
    this.wishTypeClick.emit(typeDetails);
    localStorage.setItem('wishTypeId', typeDetails.id);
    this.activeImg = true;
    this.activeId = typeDetails.id;
    this.calendarPicker = false;
    // if (!typeDetails.ask_date) {
    //   this.calendarPicker = false;
    // }
  }

  toggleSelector(event: any, dateType: any): void {
    event.stopPropagation();
    if (dateType) {
      this.selector++;
    }
  }


} 