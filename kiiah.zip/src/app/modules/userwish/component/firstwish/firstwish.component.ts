import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Input, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'first-wish',
  templateUrl: './firstwish.component.html',
  styleUrls: ['./firstwish.component.scss']
})

export class FirstWishComponent implements OnInit ,OnDestroy{
 
  constructor(private router: Router, private _location: Location, private route: ActivatedRoute, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
 
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }

  goBack() {
    this._location.back();
  }
  addNewWish(event:any) {
    let wishState = 'addNew';
    sessionStorage.setItem('wishState', wishState);
    this.mojsBurstButtonAnimation.createMojsStyle(event);   
    this.mojsBurstButtonAnimation.setTimeOut_Animation('addwish',this);
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}
