import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

//import { Login, SignUp, PasswordReset } from './../entity/login.entity';
import { WishService } from '../service/wish.service'

@Injectable()
export class WishListBusiness {

    constructor(public wishlistService: WishService, public router: Router) { }

    APIGetOnly(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiGetList(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getWishType(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiGetList(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    saveNewWishList(addWishData: any, url: string) {
        var wishFormData = {
            "wish": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiAddNewWish(JSON.stringify(wishFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    putWishDetails(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiGetWishDetails(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    deleteDetails(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiDeleteWish(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }
    
    updateWishList(addWishData: any, url: string) {
        var wishFormData = {
            "wish": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiUpdateWish(JSON.stringify(wishFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }


     getUserdetail(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wishlistService.apiuserdetail(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }
}