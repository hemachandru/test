import { NgModule, Directive } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ShareComponent } from './component/share.component';

import { ShareRoutingModule } from './share.routing';
import { InviteeListComponent } from './component/invitee-list/invitee-list.component';
import { SecureLinkComponent } from './component/secure-link/secure-link.component';
import { ShareNotificationComponent } from './component/share-notification/share-notification.component';
import { WishlistSharedComponent } from './component/wishlist-shared/wishlist-shared.component';
import { ShareLoginComponent } from './component/share-login/share-login.component';
import { WishListInvitationComponent } from './component/wishlist-invitation/wishlist-invitation.component';
import { WishListInvitationNewComponent } from './component/wishlist-invitation-new/wishlist-invitation-new.component';
import { WishListThankyouComponent } from './component/wishlist-thankyou/wishlist-thankyou.component';
import { WishListThankyouNewComponent } from './component/wishlist-thankyou-new/wishlist-thankyou-new.component';
import { ShareEmailImportComponent } from './component/email-import/email-import.component';
import { ShareImportComponent } from './component/share-import/share-import.component';
import { ShareBusiness } from './business/share.business';
import { ShareService } from './service/share.service';
import { SlimScrollModule } from 'ng2-slimscroll';

import { UtilityModule } from '../../utility/utility.module';
import { socialAuthentication } from '../../utility/socialAuth';

import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { SharedModule } from '../share/translate-shared.module';
import { CeiboShare } from 'ng2-social-share';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { WishListBusiness } from '../userwish/business/wish.business';
import { WishService } from '../userwish/service/wish.service';
import { LayoutBusiness } from '../layout/business/layout.business';
import { LayoutService } from '../layout/service/layout.service';

export declare class FacebookParams {
    u: string;
}

const SWIPER_CONFIG: SwiperConfigInterface = {
    scrollbar: null,
    observer: true,
    spaceBetween: 65,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    breakpoints: {
        // when window width is <= 320px
        320: {
            slidesPerView: 1,
            spaceBetween: 35
        },
        // when window width is <= 480px
        480: {
            slidesPerView: 1,
            spaceBetween: 50
        },
        // when window width is <= 600px
        600: {
            slidesPerView: 1,
            spaceBetween: 65
        }
    }
};

@NgModule({
    imports: [
        CommonModule,
        ShareRoutingModule,
        SwiperModule.forRoot(SWIPER_CONFIG),
        FormsModule,
        SlimScrollModule,
        //Ng2UiAuthModule.forRoot(MyAuthConfig),
        UtilityModule,
        SharedModule
    ],
    declarations: [
        ShareComponent,
        InviteeListComponent,
        SecureLinkComponent,
        ShareNotificationComponent,
        WishlistSharedComponent,
        ShareLoginComponent,
        WishListInvitationComponent,
        WishListInvitationNewComponent,
        WishListThankyouComponent,
        WishListThankyouNewComponent,
        ShareEmailImportComponent,
        ShareImportComponent,
        CeiboShare
    ],
    schemas:[CUSTOM_ELEMENTS_SCHEMA],
    providers: [ShareBusiness, ShareService, socialAuthentication, SharedModule, WishListBusiness, WishService, LayoutBusiness, LayoutService]
})
export class ShareModule { }

