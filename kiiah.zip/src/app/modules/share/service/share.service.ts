import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class ShareService {

    constructor(private httpRequest: HttpRequestService) {

    }

    getInvitationStudio(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    getThankyouStudio(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiFaqList(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    apiSaveContactUs(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    } 
    apiSaveEmailList(data:any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    }
    getIAPISecureLink(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }
}