import { NgModule, ModuleWithProviders, OnInit  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule, Http } from '@angular/http';
import { TranslateModule, TranslateService, TranslateLoader, TranslateStaticLoader } from 'ng2-translate';
import {Autosize} from 'angular2-autosize';
//import {Autosize} from 'ng-autosize';

@NgModule({
    imports: [
        CommonModule,
        HttpModule    
    ],
    exports: [
        CommonModule,
        TranslateModule,
        Autosize
    ],
    declarations: [
        Autosize    
    ],
    
})
export class SharedModule  {
    constructor(private translate: TranslateService) {     
        var  userLang = translate.getBrowserLang();    
        translate.setDefaultLang('en');
        
    }
    test(params: string){
        this.translate.use(params);
    }
}

