import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Directive, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { WishListBusiness } from '../../../userwish/business/wish.business';
import { SITE_URL } from '../../../../config/constant';
import { LayoutBusiness } from '../../../layout/business/layout.business';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'share-login',
  templateUrl: './share-login.component.html',
  styleUrls: ['./share-login.component.scss'],
})


export class ShareLoginComponent implements OnInit ,OnDestroy{
  public login: any;
  public repoUrl: string;
  private WishId: any;
  public scretKey: any;
  public shareBool: boolean = false;
  public langBool: any;
 

  constructor(private router: Router, private activeRoute: ActivatedRoute, private wishlistBusiness: WishListBusiness, private layoutBusiness: LayoutBusiness, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    
  }
async invitationStudio() {
  let resList = await this.layoutBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
    if (result.response) {
      //console.log(result.message)
      this.thankyouStudio();
    } else {
      localStorage.setItem("shareWishOrCreateWish","true");
      this.router.navigate(['/myinvitation/edit']);
    }
  },
    (error) => {
      console.log(error);
    });
}

async thankyouStudio() {
  let resList = await this.layoutBusiness.getThankyouStudio('thankyou_studios/thankyou_studio_present').subscribe((result) => {
    if (!result.response) {
      localStorage.setItem("shareWishOrCreateWish","true");
      this.router.navigate(['/thankyoustudio/edit']);
    }
  },
    (error) => {
      console.log(error);
    });
}

async getUserInfo() {
  let resList = await this.wishlistBusiness.getUserdetail('user/profile').subscribe((result) => {
    if (result.response) {
      this.repoUrl = SITE_URL + "/mywishes?key=" + result.data.profile.secret;
    }
  },
    (error) => {
      console.log(error);
    });
}

ngOnInit() {
  this.loaderService.display(true);
  this.mojsBurstButtonAnimation.intializeMojs();
  this.getUserInfo();
  this.invitationStudio();
  this.login = localStorage.getItem("lang")
  console.log(this.login)
}
goBack() {
  this._location.back();
}

gotoEmail(event:any) {
  this.mojsBurstButtonAnimation.createMojsStyle(event);
  this.mojsBurstButtonAnimation.setTimeOut_Animation('/invitee-list',this);
}
shareSecureLink(event: any) {
  this.mojsBurstButtonAnimation.createMojsStyle(event);
  this.mojsBurstButtonAnimation.setTimeOut_Animation('/secure-link',this);
}

mojsAnimationTrigger(event:any) {
  this.mojsBurstButtonAnimation.createMojsStyle(event);
}

ngOnDestroy(){
  this.mojsBurstButtonAnimation.resetMojsStyle(document);
}


}