import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ShareBusiness } from '../../business/share.business';
import { WishListBusiness } from '../../../userwish/business/wish.business';
import { SITE_URL } from '../../../../config/constant';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
@Component({
    selector: 'email-import',
    templateUrl: './email-import.component.html',
    styleUrls: ['./email-import.component.scss']
})

export class ShareEmailImportComponent implements OnInit, OnDestroy {

    public contactList: Array<Object> = [];
    public opts: ISlimScrollOptions;
    public allContactList: any;
    public errorBoolean: boolean = false;
    public scretKey: any;
    public selectAllFlag:boolean =true;
    public searchText:any="";
    public contactListTemp: Array<Object> = [];

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute, private _location: Location, private _sb: ShareBusiness, private wishlistBusiness: WishListBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    }

    async getUserInfo() {
        let resList = await this.wishlistBusiness.getUserdetail('user/profile').subscribe((result) => {
          if (result.response) {
            this.scretKey = result.data.profile.secret ;
          }     
        },
          (error) => {
            console.log(error);
          });
      }

    ngOnInit() {
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.intializeMojs();
        this.opts = {
            position: 'right',
            barBackground: 'rgb(173, 181, 189)',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }

        this.contactList = JSON.parse(localStorage.getItem("contactList"));
        console.log("this.contactList", this.contactList);
        this.loaderService.display(false);
        this.getUserInfo();

    }

    //chandru
    toggleSelect = function (event: any) {
        this.allContactList = event.target.checked;
        this.contactList.forEach(function (item: any) {
            item.selected = event.target.checked;
        });
    }

    addMoreContact(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        localStorage.setItem("contactList", JSON.stringify(this.contactList));
        this.mojsBurstButtonAnimation.setTimeOut_Animation('invitee-list',this);
    }
    removeEmailList(indexId: any) {
        var removeContactList = this.contactList.splice(indexId, 1);
        localStorage.setItem("contactList", JSON.stringify(removeContactList));
    }
    async shareEmails(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        var selectedContactList = new Array();
        this.contactList.forEach(function (item: any) {
            if (item.selected) {
                selectedContactList.push(item.email);
            }
        });
        this.errorBoolean = (selectedContactList.length == 0 ) ? true : false;
        if( selectedContactList.length == 0 ) return;
        localStorage.setItem("sharedCount", JSON.stringify(selectedContactList.length));
        var EmailArray = {
                           "recipients": selectedContactList, 
                            "user": this.scretKey, 
                            "url": SITE_URL+"/mywishes"
                         }
        
        await this._sb.sendEmailList(EmailArray, 'wishes/share/email').subscribe((result) => {
              var resultData = result.response;
              if (resultData) {
                this.router.navigate(['shared-success']);
              } 
            },
              (error) => {
                console.log(error);
              });
        
    }
    goBack() {
        this._location.back();
    }

    //chandru
    onFilterEmail(enterText:any){
        if(enterText){
            let filterResult = this.contactList.filter((emailName: any) => {
                return emailName.email.toLowerCase().indexOf(enterText.toLowerCase()) > -1;
            });
            this.allContactList = false;
            if(filterResult.length >0){
                this.selectAllFlag =true;
                this.contactList = filterResult;
                //this.toggleSelect1();
            }else{
                this.selectAllFlag =false;
                this.contactList = filterResult;  
                //this.toggleSelect1();
            }
        }else{
            this.selectAllFlag =true;
          //  this.toggleSelect1();
            this.contactList = JSON.parse(localStorage.getItem("contactList"));
        }
       
    }

    // toggleSelect1 = function () {
    //     this.contactList.forEach(function (item: any) {
    //         item.selected = false;
    //     });
    // }

    ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      }
}