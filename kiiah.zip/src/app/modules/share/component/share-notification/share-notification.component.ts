import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef ,OnDestroy} from '@angular/core';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
    selector: 'share-notification',
    templateUrl: './share-notification.component.html',
    styleUrls: ['./share-notification.component.scss']
})

export class ShareNotificationComponent implements OnInit, OnDestroy {

    private display_style_payment = '';
    private display_style_account = '';

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    }

    ngOnInit() {
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.intializeMojs();
        this.loaderService.display(false);
    }
    PaymentPage(event:any){
        let dis_pay = sessionStorage.getItem('display_style_account');
        if(dis_pay == 'true'){
            this.router.navigate(['myaccount']);
        }else{
            this.mojsBurstButtonAnimation.createMojsStyle(event);
            this.mojsBurstButtonAnimation.setTimeOut_Animation('payment-type',this);
        }
        
    }


    goBack() {
        this._location.back();
    }

    ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
    }
}