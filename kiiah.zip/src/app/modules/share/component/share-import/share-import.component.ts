import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { ShareBusiness } from '../../business/share.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'share-import',
  templateUrl: './share-import.component.html',
  styleUrls: ['./share-import.component.scss']
})
export class ShareImportComponent implements OnInit, OnDestroy {
  public shareCount: any;
  constructor(private router: Router, private _location: Location, private shareBusiness: ShareBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.shareCount = JSON.parse(localStorage.getItem("sharedCount"));
    this.loaderService.display(false);
  }
  
  goBack() {
    this._location.back();
  }

  async checkInvitationStudio(event: any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('wishlist-shared',this);
// =======
//     this.mojsBurstButtonAnimation.createMojsStyle(event);
//     let resList = await this.shareBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
//       if (result.response) {
//         this.router.navigate(['/wishlist-invitation']);
//       } else {
//         this.router.navigate(['/wishlist-invitation-new']);
//       }
//     },
//       (error) => {
//         console.log(error);
//       });
// >>>>>>> Stashed changes
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}