import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'wishlist-thankyou-new',
  templateUrl: './wishlist-thankyou-new.component.html',
  styleUrls: ['./wishlist-thankyou-new.component.scss']
})


export class WishListThankyouNewComponent implements OnInit, OnDestroy {

  constructor(private router: Router, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    document.getElementById("loadingDiv").style.display = "none";
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
    //this.getUserInformation();
  }

  gotoMyWishlist(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('userwish',this);
  }

  gotoThankyou(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('/thankyoustudio/share',this);
  }

  goBack() {
    this._location.back();
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}