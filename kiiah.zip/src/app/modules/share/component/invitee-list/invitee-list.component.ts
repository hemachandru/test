import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { ShareBusiness } from '../../business/share.business';
import { socialAuthentication } from '../../../../utility/socialAuth';
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
    selector: 'invitee-list',
    templateUrl: './invitee-list.component.html',
    styleUrls: ['./invitee-list.component.scss']
})

export class InviteeListComponent implements OnInit, OnDestroy {
    public opts: ISlimScrollOptions;
    public invalidEmail: any;
    public emailList: Array<Object> = [];
    public shareEmail: any;
    public emailContactList: Array<Object> = [];

    constructor(private router: Router, private shareBusiness: ShareBusiness, private socialAuth: socialAuthentication, private _location: Location, private loaderService: LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    }

    ngOnInit() {
        this.loaderService.display(true);
        this.opts = {
            position: 'right',
            barBackground: 'rgb(173, 181, 189)',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.invalidEmail = 'hidden';
        this.shareEmail = {
            email: ''
        }

        var allContactList = JSON.parse(localStorage.getItem("contactList"));
        if (allContactList != null && allContactList.length > 0) {
            this.emailContactList = allContactList;
        }
        var myEmails = JSON.parse(localStorage.getItem("myEmails"));
        if (myEmails != null && myEmails.length > 0) {
            this.emailList = myEmails;
        }
        this.mojsBurstButtonAnimation.intializeMojs();
        this.loaderService.display(false);
    }
    goBack() {
        this._location.back();
    }

    addEmail(event: any) {
        if (event.keyCode == 13) {
            this.addNewEmail(event.target.value);
        }
    }

    removeEmailList(indexId: any) {
        this.emailList.splice(indexId, 1);
        localStorage.setItem("myEmails", JSON.stringify(this.emailList));
    }
    addNewEmail(value: any) {
        if (value != "") {
            if (value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
                this.invalidEmail = 'hidden';
                this.emailList.push({
                    email: value,
                    selected: false
                });
                this.shareEmail.email = '';
            } else {
                this.invalidEmail = 'visible';
            }
        }
    }



    async importContact(LoginType: string) {
        let self = this;        
        let resetMessage = await this.socialAuth.loginSocialAccount(LoginType).subscribe((result) => {
            document.getElementById("loadingDiv").style.display = "none";
            if (result._body) {
                let res = JSON.parse(result._body);
                if (res.response) {
                    let emailList = res.data.contact_list;
                    if (LoginType == 'yahoo') {
                        emailList.forEach(function (item: any) {
                            let newValue = {
                                email: item[0].value,
                                selected: false
                            }
                            self.emailContactList.push(newValue);
                        });
                    } else {
                        emailList.forEach(function (item: any) {
                            this.emailContactList.push({
                                email: item,
                                selected: false,
                            });
                        });
                    }
                    this.listContacts();
                } else {
                    //document.getElementById("loadingDiv").style.display = "none";
                    console.log(res.message);
                }
            }
            if (result.message) {
                document.getElementById("loadingDiv").style.display = "none";
            }
        },
            (error) => {
                console.warn(error);
                document.getElementById("loadingDiv").style.display = "none";

            });
    }


    async googleAuth(LoginType: string, authType: any) {

        let resetMessage = await this.socialAuth.googleAccountAuth(LoginType, authType).subscribe((result) => {
            document.getElementById("loadingDiv").style.display = "none";
            if (result._body) {
                let res = JSON.parse(result._body);
                if (res.response) {
                    let emailList = res.data.contact_list;
                    let self = this;
                    emailList.forEach(function (item: any) {
                        self.emailContactList.push({
                            email: item,
                            selected: false,
                        });
                    });
                    this.listContacts();
                }
            }
            if (result.message) {
                document.getElementById("loadingDiv").style.display = "none";
            }
        },
            (error) => {
                console.log(error);
                document.getElementById("loadingDiv").style.display = "none";

            });

    }

    listContacts(flagValue?:string ,event?:any) {
        if(flagValue == 'true'){
            this.mojsBurstButtonAnimation.createMojsStyle(event);
        }
        var email = this.emailContactList.concat(this.emailList);

        //For remove dublicate emails

        var obj = {};

        for (var i = 0, len = email.length; i < len; i++) {
            //obj[email[i]['email']] = email[i];
            obj[email[i]['email']] = email[i]["selected"] ? email[i]:obj[email[i]['email']] !== undefined ? obj[email[i]['email']] : email[i];
        }

        var unique = new Array();
        for (var key in obj) {
            unique.push(obj[key]);
        }
        localStorage.setItem("myEmails", JSON.stringify(this.emailList));
        localStorage.setItem("contactList", JSON.stringify(unique));
        this.mojsBurstButtonAnimation.setTimeOut_Animation('email-import',this);
    }

    ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      }
}