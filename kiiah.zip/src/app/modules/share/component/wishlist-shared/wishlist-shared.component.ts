import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef, OnDestroy } from '@angular/core';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
@Component({
    selector: 'wishlist-shared',
    templateUrl: './wishlist-shared.component.html',
    styleUrls: ['./wishlist-shared.component.scss']
})

export class WishlistSharedComponent implements OnInit, OnDestroy {
    public usermail:any;

    constructor(private router: Router, private _location: Location, private el: ElementRef, private route: ActivatedRoute, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
    }
      goShare(event:any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        this.mojsBurstButtonAnimation.setTimeOut_Animation('/share-login',this);
      }
      
  goBack() {
   this._location.back();
  }
    ngOnInit() {
      this.loaderService.display(true);
      this.mojsBurstButtonAnimation.intializeMojs();
     this.usermail = localStorage.getItem('email'); 
     this.loaderService.display(false);
    }

    ngOnDestroy(){
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
    }
   
}