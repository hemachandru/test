import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';


@Component({
  selector: 'wishlist-invitation-new',
  templateUrl: './wishlist-invitation-new.component.html',
  styleUrls: ['./wishlist-invitation-new.component.scss']
})


export class WishListInvitationNewComponent implements OnInit, OnDestroy  {

  constructor(private router: Router, private _location: Location, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    document.getElementById("loadingDiv").style.display = "none";
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
    //this.getUserInformation();
  }

  gotoMyWishlist(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('userwish',this);
  }

  gotoInvitation(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('/myinvitation/share',this);
  }

  goBack() {
    this._location.back();
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}