import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef, OnDestroy } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

import { ShareBusiness } from '../../business/share.business';
import { SITE_URL } from '../../../../config/constant';

@Component({
    selector: 'secure-link',
    templateUrl: './secure-link.component.html',
    styleUrls: ['./secure-link.component.scss']
})

export class SecureLinkComponent implements OnInit, OnDestroy {
    private link_name: any;


    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute, private _location: Location, private shareBusiness: ShareBusiness, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {

    }

    ngOnInit() {
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.intializeMojs();
        this.getSecureLinkInfo();
    }

    async getSecureLinkInfo() {
        let resList = await this.shareBusiness.getSecureLink('user/profile').subscribe((result) => {
            if (result.response) {
                let value = result.data.profile.secret;
                if (value) {
                    this.link_name = SITE_URL + "/mywishes?key=" + value;
                }
            }
        },
            (error) => {
                console.log(error);
                //document.getElementById("loadingDiv").style.display = "none";
            });
    }

    goBack() {
        this._location.back();
    }

    // copyLink(cppyLink: any, event: any) {
    copyLink(cppyLink: any,event: any) {
        console.log(event);
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        var copyTextarea = (<HTMLInputElement>document.getElementById('link_name'));
         copyTextarea.select();
        //copyTextarea.setSelectionRange(0, 9999)
        //alert(copyTextarea);
        try {
            setTimeout(() => {
                this.mojsBurstButtonAnimation.resetMojsStyle(document);
                var successful = document.execCommand('copy');
                // var successful = document.queryCommandSupported('copy');
                this.loaderService.display(false);
               // alert(successful);
            }, this.mojsBurstButtonAnimation.timeOutValue);
        } catch (err) {
            console.log('Oops, unable to copy');
        }
    }

    ngOnDestroy(){
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
      }

}