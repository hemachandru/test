import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef, Renderer, OnDestroy } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Location, PlatformLocation } from '@angular/common';
import { ShareBusiness } from '../../business/share.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { WishListBusiness } from '../../../userwish/business/wish.business';

import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'wishlist-thankyou',
    templateUrl: './wishlist-thankyou.component.html',
    styleUrls: ['./wishlist-thankyou.component.scss']
})

export class WishListThankyouComponent implements OnInit, OnDestroy {
    public someProperty: any;
    public invitationStudio: any;
    public videoP: boolean = false;
    public audioP: boolean = false;
    public isMobile: any;
    public read_more: any;
    public fullDescription: any;
    public full_para : any;
    public half_para : any;
    public read_more_hide_Full : any;
    public read_more_hide_half : any;
    
    @ViewChild('changepwd') public changepwd: TemplateRef<any>;
    dialog: DialogRef<any>;

    constructor(private router: Router, private _location: Location, private shareBusiness: ShareBusiness, private render: Renderer, private wishlistBusiness: WishListBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService: LoaderService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, public pageLocation: PlatformLocation) {

        this.invitationStudio = {
            frame_url: "",
            thankyou_msg: {

            },
            media: "",
            message: "",
            type: ""
        }

        overlay.defaultViewContainer = vcRef;

        pageLocation.onPopState(() => {
            if (this.dialog) {
                this.onClose();
            }
        });
    }

    ngOnInit() {
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.intializeMojs();
        this.isMobile = this.detectMobile();

        this.someProperty = true;
        document.getElementById('image_without_frame').style.display = 'none';
        document.getElementById('image_with_frame').style.display = 'none';
        document.getElementById('preview_video').style.display = 'none';
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('preview_audio').style.display = 'none';
        document.getElementById('preview_audio1').style.display = 'none';
        this.loaderService.display(false);
        this.getThankyouStudio();
    }

    detectMobile() {
        if (navigator.userAgent.match(/Android/i)
            || navigator.userAgent.match(/webOS/i)
            || navigator.userAgent.match(/iPhone/i)
            || navigator.userAgent.match(/iPad/i)
            || navigator.userAgent.match(/iPod/i)
            || navigator.userAgent.match(/BlackBerry/i)
            || navigator.userAgent.match(/Windows Phone/i)
        ) {
            return true;
        }
        else {
            return false;
        }
    }

    async getThankyouStudio() {
        let self = this;
        let resList = await this.shareBusiness.getThankyouStudio('thankyou_studios/thankyou_studio_present').subscribe((result) => {
            if (result.response) {
                this.invitationStudio = result.message;
                if (result.message.type == "video") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewVideo = document.getElementById('preview_video');
                    previewVideo.setAttribute('src', result.message.media);
                    previewVideo.addEventListener('ended', this.myHandler(self), false);
                    previewVideo.addEventListener('pause', this.myHandlerPause(self), false);
                    document.getElementById('preview_video').style.display = 'block';
                    document.getElementById('play--icon').style.display = 'block';
                } else if (result.message.type == "audio") {
                    document.getElementById('image_without_frame').style.display = 'block';
                    document.getElementById('image_with_frame').style.display = 'none';
                    var previewAudio = document.getElementById('preview_audio');
                    previewAudio.setAttribute('src', result.message.media);
                    previewAudio.addEventListener('ended', this.myHandlerAudio(self), false);
                    document.getElementById('preview_audio').style.display = 'block';
                    document.getElementById('preview_audio1').style.display = 'block';
                    document.getElementById('audio--play--icon').style.display = 'block';
                } else {
                    document.getElementById('image_without_frame').style.display = 'none';
                    document.getElementById('image_with_frame').style.display = "block";
                }
                var showChar = 150;
                // full_para   half_para
                //alert(this.invitationStudio.thankyou_msg.description.length);
                if (this.invitationStudio.thankyou_msg.description.length > showChar) {
                    this.half_para = 'block';
                    this.full_para = 'none';
                    this.read_more = 'block';
                    this.read_more_hide_half = this.invitationStudio.thankyou_msg.description.substr(0, showChar);
                }else{
                    this.read_more_hide_Full = this.invitationStudio.thankyou_msg.description;
                    this.half_para = 'none';
                    this.full_para = 'block';
                    this.read_more = 'none';
                }

            } else {
                //console.log("error----", result.message)
            }
        },
            (error) => {
                //console.log(error);
            });
    }

    myHandler(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                let videoTag: any = document.getElementById('preview_video');
                videoTag.webkitExitFullscreen();
                //videoTag.mozCancelFullScreen();
            }
            that.videoP = false;
            document.getElementById('pause--icon').style.display = 'none';
            document.getElementById('play--icon').style.display = 'block';
        }
    }

    myHandlerPause(that: any) {
        return (event: any) => {
            if (that.isMobile) {
                that.videoP = false;
                document.getElementById('pause--icon').style.display = 'none';
                document.getElementById('play--icon').style.display = 'block';
            }

        }
    }

    myHandlerAudio(that: any) {
        return (event: any) => {
            that.audioP = false;
            document.getElementById('audio--pause--icon').style.display = 'none';
            document.getElementById('audio--play--icon').style.display = 'block';
        }
    }

    ngAfterViewInit() {
        document.getElementById("loadingDiv").style.display = "none";
    }

    playVideo() {
        //alert('hai');
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('play--icon').style.display = 'none';
        document.getElementById('pause--icon').style.display = 'block';
        this.videoP = true;
        // alert('Play video : '+this.videoP);
        previewVideo.play();        
    }

    stopVideo() {
        var previewVideo: any = document.getElementById('preview_video');
        document.getElementById('pause--icon').style.display = 'none';
        document.getElementById('play--icon').style.display = 'block';
        this.videoP = false;
        //alert('Pause video : '+this.videoP);
        previewVideo.pause();
    }

    playAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--play--icon').style.display = 'none';
        document.getElementById('audio--pause--icon').style.display = 'block';
        this.audioP = true;
        previewVideo.play();

    }

    stopAudio() {
        var previewVideo: any = document.getElementById('preview_audio');
        document.getElementById('audio--pause--icon').style.display = 'none';
        document.getElementById('audio--play--icon').style.display = 'block';
        this.audioP = false;
        previewVideo.pause();
    }

    share(event: any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        //this.getUserInfo();
        this.router.navigate(['share-login']);
    }

    async getUserInfo() {
        let resList = await this.wishlistBusiness.APIGetOnly('user/profile').subscribe((result) => {

            let first_name = result.data.profile.first_name;
            let last_name = result.data.profile.last_name;
            let full_name = result.data.profile.full_name;
            let dob = result.data.profile.dob;
            let phone = result.data.profile.phone;
            let address = result.data.profile.address;
            let city = result.data.profile.city;
            let post_code = result.data.profile.post_code;
            let email = result.data.profile.email;
            let currency_id = result.data.profile.currency_id;
            let paypal_name = result.data.profile.paypal_name;
            let country = result.data.profile.country;

            if (first_name == null || last_name == null || full_name == null || dob == null || phone == null || address == null || city == null || post_code == null || email == null || currency_id == null || paypal_name == null || country == null) {
                let isSessionMyAccount = "true";
                sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);
                this.router.navigate(['myaccount']);
                // alert('null');
            } else {
                let isSessionMyAccount = "false";
                sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);
                this.router.navigate(['share-login']);
                //alert('not null');
            }

        },
            (error) => {
                console.log(error);
            });
    }

    gotoThankyou(event: any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        if (!this.videoP && !this.audioP) {
            this.mojsBurstButtonAnimation.setTimeOut_Animation('/thankyoustudio/share', this);
        }
    }

    goBack() {
        if (!this.videoP && !this.audioP) {
            this._location.back();
        }
    }

    ngOnDestroy() {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
    }

    viewDescription(value: any) {
        this.fullDescription = value;
        return this.modal.open(this.changepwd, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog model_change_password' }, BSModalContext))
          .then(dialog => {
            this.dialog = dialog;
          })
    }

    onClose() {
        this.dialog.close();
    }
}