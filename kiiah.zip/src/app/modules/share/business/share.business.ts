import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';
import { AuthService } from 'ng2-ui-auth';
import { ShareService } from '../service/share.service';
import { baseURL } from '../../../config/constant';
import { socialAuthentication } from '../../../utility/socialAuth';



@Injectable()
export class ShareBusiness {
  public token: string;

  constructor(public shareService: ShareService, public router: Router, private socialauth: socialAuthentication) {
  }

  getInvitationStudio(url: string) {
    let activeProject: ReplaySubject<any> = new ReplaySubject(1);
    this.shareService.getInvitationStudio(url)
      .subscribe((result) => {
        activeProject.next(result)
      },
      (error) => {
        activeProject.next(error);
      });
    return activeProject;
  }

  sendEmailList(data: any, url: string) {
    let activeProject: ReplaySubject<any> = new ReplaySubject(1);
    this.shareService.apiSaveEmailList(data, url).subscribe((result) => {
        activeProject.next(result)
    },
        (error) => {
            activeProject.next(error);
        });
    return activeProject;
}

  getThankyouStudio(url: string) {

    let activeProject: ReplaySubject<any> = new ReplaySubject(1);
    this.shareService.getThankyouStudio(url)
      .subscribe((result) => {
        activeProject.next(result)
      },
      (error) => {
        activeProject.next(error);
      });
    return activeProject;
  }

  googleAccountAuth(LoginType: string, authType: any) {
    return this.socialauth.googleAccountAuth(LoginType, authType);
  }

  getSecureLink(url: string) {
    let activeProject: ReplaySubject<any> = new ReplaySubject(1);
    this.shareService.getIAPISecureLink(url)
      .subscribe((result) => {
        activeProject.next(result)
      },
      (error) => {
        activeProject.next(error);
      });
    return activeProject;
  }

}