import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
//import { NgxPaginationModule } from 'ngx-pagination';

import { WellwishesComponent } from './component/well-wishes.component';
import { ThankyouMessageComponent } from './component/thankyou-message/thankyou-message.component';
import { WellwishesStudioComponent } from './component/wellwishes-studio/wellwishes-studio.component';
import { MessageSentComponent } from './component/message-sent/message-sent.component';
import { WellwishesRoutingModule } from './well-wishes.routing';

import { WellwishesBusiness } from './business/well-wishes.business';
import { WellwishesService } from './service/well-wishes.service';

import { ClickOutsideModule } from 'ng-click-outside';
import { ProgressBarModule } from "ngx-progress-bar";
import { SharedModule } from '../share/translate-shared.module';
import { UtilityModule } from '../../utility/utility.module';

@NgModule({
  imports: [
    CommonModule,
    WellwishesRoutingModule,
    FormsModule,
    SharedModule,
    ClickOutsideModule,
    ProgressBarModule,
    UtilityModule
  ],
  declarations: [
    WellwishesComponent,
    ThankyouMessageComponent,
    WellwishesStudioComponent,
    MessageSentComponent

  ],
  providers: [WellwishesBusiness, WellwishesService, SharedModule]
})
export class WellwishesModule {
 
}

