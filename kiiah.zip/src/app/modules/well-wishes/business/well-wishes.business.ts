import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { WellwishesService } from '../service/well-wishes.service'

@Injectable()

export class WellwishesBusiness {

    constructor(public wellwishesService: WellwishesService, public router: Router) { }

    getListAPI(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.getListApi(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getInvitationStudio(url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.getInvitationStudio(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    wellwishSave(addWishData: any, url: string) {
        let contributerId = localStorage.getItem('contributer_id');     
        var invitationFormData = {
            "wellwish_studio": addWishData,
            "contributor": { 
                "id": contributerId //contributerId
            },
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.apiSaveInivitation(JSON.stringify(invitationFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    invitationSaveVideo(addWishData: any, url: string) {
        var invitationFormData = {
            "invitation_studio": addWishData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.apiSaveInivitation(addWishData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    sendVideo(videoData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.sendVideo(videoData, url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    previewObject(options: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.previewObject(options, url)
            .subscribe((result: any) => {
                activeProject.next(result)
            },
            (error: any) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    wellwishAPI(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.wellwishesService.getWellWishAPI(url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}