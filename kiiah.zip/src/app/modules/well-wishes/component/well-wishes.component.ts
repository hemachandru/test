import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './well-wishes.component.html',
    styleUrls: ['./well-wishes.component.scss']
})

export class WellwishesComponent implements OnInit {
    public activeURL: string;
    

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });
    }

    ngOnInit() {
        document.getElementById("toggle").style.display = "block";
    }
}