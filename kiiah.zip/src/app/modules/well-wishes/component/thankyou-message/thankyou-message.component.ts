import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { WellwishesBusiness } from '../../business/well-wishes.business';

@Component({
  selector: 'thankyou-message',
  templateUrl: './thankyou-message.component.html',
  styleUrls: ['./thankyou-message.component.scss']
})

export class ThankyouMessageComponent implements OnInit, OnDestroy {



  constructor(private router: Router, private _location: Location, private wellwishesBusiness: WellwishesBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService: LoaderService) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }
  goToWellwish(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('wellwishes-studio',this);
  }
  goToExit(event:any) {
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('/',this);
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}