import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WellwishesComponent } from './component/well-wishes.component';

export const wellwishesRoutes: Routes = [
  {
    path: '',
    component: WellwishesComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(wellwishesRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class WellwishesRoutingModule { } 
