import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';

import { PaymentService } from '../service/payment.service'

@Injectable()
export class PaymentBusiness {
    public token: string;

    constructor(public paymentService: PaymentService, public router: Router) {
    }

    getApi(url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.paymentService.apiGetData(url).subscribe((result) => {
            activeProject.next(result)
        },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }


    postApiPaymentData(paymentData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.paymentService.makePayment(JSON.stringify(paymentData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    paypalLoginAuth(paymentData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.paymentService.ApiPaypalAuth(JSON.stringify(paymentData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    getSecureUserData(paymentData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.paymentService.getUserInfo(JSON.stringify(paymentData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

}