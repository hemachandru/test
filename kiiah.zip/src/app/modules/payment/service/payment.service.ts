import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class PaymentService {

    constructor(private httpRequest: HttpRequestService) {

    }

    apiGetData(url: string) {
        return this.httpRequest.getHttpRequest(url);
    }

    makePayment(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }

    ApiPaypalAuth(data: any, url: string) {
        return this.httpRequest.postHttpRequest(data, url);
    }
    getUserInfo(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }
}