import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PaymentComponent } from './component/payment.component';

export const paymentRoutes: Routes = [
  {
    path: '',
    component: PaymentComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(paymentRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class PaymentRoutingModule { } 
