import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
//import { NgxPaginationModule } from 'ngx-pagination';
import { ClickOutsideModule } from 'ng-click-outside';
import { PaymentComponent } from './component/payment.component';
import { PaymentTypeComponent } from './component/payment-type/payment-type.component';
import { CardPaymentComponent } from './component/card-payment/card-payment.component';
import { PayLoginSuccessComponent } from './component/paypal-login-success/payauth-success.component';
import { paypalSuccessComponent } from './component/paypalsuccess/paypalsuccess.component';

import { PaymentRoutingModule } from './payment.routing';

import { PaymentBusiness } from './business/payment.business';
import { PaymentService } from './service/payment.service';

import { LayoutBusiness } from '../layout/business/layout.business';
import { LayoutService } from '../layout/service/layout.service';
import { SharedModule } from '../share/translate-shared.module';
import { UtilityModule } from '../../utility/utility.module';
import { SlimScrollModule } from 'ng2-slimscroll';

@NgModule({
  imports: [
    CommonModule,
    PaymentRoutingModule,
    FormsModule,
    ClickOutsideModule,
    SharedModule,
    UtilityModule,
    SlimScrollModule
  ],
  declarations: [
    PaymentComponent,
    PaymentTypeComponent,
    CardPaymentComponent,
    PayLoginSuccessComponent,
    paypalSuccessComponent
  ],

  providers: [PaymentBusiness, PaymentService, LayoutBusiness, LayoutService, SharedModule]
})
export class PaymentModule { }

