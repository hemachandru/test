import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { PaymentBusiness } from '../../business/payment.business';
import { PAYPAL_AUTH_ID, SITE_URL } from '../../../../config/constant';
import { LayoutBusiness } from '../../../layout/business/layout.business';

declare var paypal: any;

@Component({
  selector: 'payment-type',
  templateUrl: './payment-type.component.html',
  styleUrls: ['./payment-type.component.scss']
})

export class PaymentTypeComponent implements OnInit, OnDestroy {
  public paypalSuccessCode: any;
  private paypalValidate: boolean = false;
  private profileInfo: any;
  private payPalWelcomeBool: boolean = false;
  private payPalAccountName:any;

  constructor(private router: Router, private _location: Location, private paymentBusiness: PaymentBusiness, private route: ActivatedRoute, private layoutBusiness: LayoutBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService: LoaderService) {
    // this.paypalSuccessCode = localStorage.getItem("pp_success_auth_code");
    // if (this.paypalSuccessCode) {
    //   this.paypalVerification(this.paypalSuccessCode);
    // }
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    // this.route.queryParams.subscribe(params => {
    //   this.paypalSuccessCode = params['code']; // (+) converts string 'id' to a number      
    // });
    this.paypalAuth();
    this.loaderService.display(false);
    this.profileData();
  }

  // async paypalVerification(successData: any) {
  //   let paySucessData = {
  //     "code": successData
  //   }

  //   let resList = await this.paymentBusiness.paypalLoginAuth(paySucessData, 'auth/paypal').subscribe((result) => {
  //     if (result.response) {
  //       console.log(result);
  //       //window.close();        
  //     }
  //   },
  //     (error) => {
  //       console.log(error);
  //     });
  // }


  goBack() {
    //this._location.back();
    this.router.navigate(['userwish']);
  }

  async sharePage(event: any) {
    localStorage.setItem("shareWishOrCreateWish", "true");
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let resList = await this.paymentBusiness.getApi('user/profile').subscribe((result) => {
      if (result.response) {       
        this.profileInfo = result.data.profile;

        if (result.data.profile.paypal_name) {          
          this.getUserInformation(this.profileInfo);
        } else {          

          let display_style_account = "false";
          sessionStorage.setItem('display_style_account', display_style_account);
          let display_style_payment = "true";
          sessionStorage.setItem('display_style_payment', display_style_payment);
          this.router.navigate(['share-notification']);
        }

      }
    },
      (error) => {
        console.log(error);

      });
  }
  async profileData(){
    let resList = await this.paymentBusiness.getApi('user/profile').subscribe((result) => {
      if (result.response) {       
        this.profileInfo = result.data.profile;
        if (result.data.profile.paypal_name) {          
          this.payPalAccountName = result.data.profile.paypal_name;
          this.payPalWelcomeBool = true;
        }else{
          this.payPalWelcomeBool = false;
        }
      }
    },
      (error) => {
        console.log(error);

      });

  }
  async getUserInformation(accountInfo: any) {

    let first_name = accountInfo.first_name;
    let last_name = accountInfo.last_name;
    let full_name = accountInfo.full_name;
    let dob = accountInfo.dob;
    let phone = accountInfo.phone;
    let address = accountInfo.address;
    let city = accountInfo.city;
    let post_code = accountInfo.post_code;
    let email = accountInfo.email;
    let currency_id = accountInfo.currency_id;
    let paypal_name = accountInfo.paypal_name;
    let country = accountInfo.country;

    if (first_name == null || last_name == null || full_name == null || dob == null || phone == null || address == null || city == null || post_code == null || email == null || currency_id == null || paypal_name == null || country == null) {
      let isSessionMyAccount = "true";
      sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);

      let display_style_account = "true";
      sessionStorage.setItem('display_style_account', display_style_account);
      let display_style_payment = "false";
      sessionStorage.setItem('display_style_payment', display_style_payment);

      this.router.navigate(['share-notification']);

    } else {
      let isSessionMyAccount = "false";
      sessionStorage.setItem('isSessionMyAccount', isSessionMyAccount);
      //this.router.navigate(['share-login']);
      this.invitationStudio();

    }
  }


  async invitationStudio() {
    localStorage.setItem("shareWishOrCreateWish", "true");
    let resList = await this.layoutBusiness.getInvitationStudio('invitation_studios/invitation_studio_present').subscribe((result) => {
      if (result.response) {
        this.router.navigate(['/wishlist-invitation']);
      } else {
        this.router.navigate(['/myinvitation/edit']);
      }
    },
      (error) => {
        console.log(error);
      });
  }
  
  paypalAuth() {
    paypal.use(["login"], function (login: any) {
      login.render({
        "appid": PAYPAL_AUTH_ID,
        "authend": "sandbox",
        "scopes": "openid profile email",
        "containerid": "myContainer",
        "locale": "en-us",
        "returnurl": SITE_URL+"/payment-type"
      });
    });

  }
  paypalAuthEvent() {
    this.paypalValidate = false;
    let click: any = document.getElementById('myContainer').children[0];
    click.click();
  }

  ngOnDestroy() {
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }


}