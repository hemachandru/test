import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';

import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute } from '@angular/router';

@Component({
    templateUrl: './payment.component.html',
    styleUrls: ['./payment.component.scss']
})

export class PaymentComponent implements OnInit {
    public activeURL: string;
    public paypalSuccessCode: any;
    public successId: any;

    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {        
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;
            }
        });

        this.route.queryParams.subscribe(params => {           
            this.paypalSuccessCode = params['code']; // (+) converts string 'id' to a number 
            console.log("pp_success_auth_code====>", this.paypalSuccessCode);
        });

        this.route.params.subscribe(params => {
            this.successId = +params['id'];
        });
    }

    ngOnInit() {
        document.getElementById("navHeader").style.display = "block";
    }
}