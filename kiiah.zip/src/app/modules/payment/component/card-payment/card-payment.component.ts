import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { PaymentBusiness } from '../../business/payment.business';
import { PAYPAL_AUTH_ID, SITE_URL } from '../../../../config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';

import { COUNTRY_LIST } from './mycountry';

declare var jquery: any;
declare var $: any;

declare var braintree: any;
declare var paypal: any;

const country = [
  { name: 'India', code: 'IN' },
  { name: 'malesiya', code: 'ME' },
  { name: 'Singpore', code: 'SN' }
];

@Component({
  selector: 'card-payment',
  templateUrl: './card-payment.component.html',
  styleUrls: ['./card-payment.component.scss']
})

export class CardPaymentComponent implements OnInit, OnDestroy {

  private countryList = country;
  private paymentInfo: any;
  private invalidEmail = 'hidden';
  private billingInfo: any;
  public creditdata: boolean = true;
  public payMode: boolean = false;
  private clientToken: any;
  private cardInfo: any;
  private paymentAmount: any;
  private clientToken1: any;
  private customerInfo: any;
  private paypal_success_data: any;
  private paymentBtn: boolean = false;
  private cardSuccessData: any;
  private ppEmail: any;
  private contribute_wish_info: any;
  private country_withCode: any = []; 
  public checkBoolPaybal: boolean = false;;
  public opts: ISlimScrollOptions;
  
  //dropdown
  private wasWishClicked: boolean = false;
  private delay: boolean = false;
  private countryClicked: boolean = false;
  private userCountryName: any;
  private countryCode: any;
  private txt_display_selectCountry = 'block';
  //private contryCodeValText : any;
  //dropdown
  //private contribute_wishId: any;
  public searchText:any="";
  public countrySearch: any = [];

  constructor(private router: Router, private _location: Location, private paymentBusiness: PaymentBusiness, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {

    this.customerInfo = {
      first_name: '',
      last_name: '',
      email: '',
      phone_no: '',
      address1: '',
      address2: '',
      city_name: '',
      post_code: '',
      country: ''
    }
    this.cardInfo = {
      card_number: '',
      cvv_number: '',
      expiration_date: ''
    }
    this.contribute_wish_info = {
      contribute_wish_id: ''
    }

  }

  testChange(){
    this.countryClicked = false;
  }

      onFilterEmail(enterText:any){
        if(enterText){
          let filterResult = this.countrySearch.filter((emailName: any) => {
          return emailName.name.toLowerCase().indexOf(enterText.toLowerCase()) == 0;
        });
        if(filterResult.length > 0){
         this.country_withCode = filterResult;
        }else{
         this.country_withCode = filterResult;  
        }
        }else{
          this.country_withCode = this.countrySearch;  
        }
      }

  ngOnInit() {
    var asd = document.getElementById("pay_card");
    this.loaderService.display(true);
    
    for (var index = 0; index < COUNTRY_LIST.length; index++) {
      this.country_withCode.push({ "name": COUNTRY_LIST[index].name, "code": COUNTRY_LIST[index].code });
      this.countrySearch = this.country_withCode;   
    }

    this.mojsBurstButtonAnimation.intializeMojs();
    let getamount = localStorage.getItem('contribure_amount');
    let wishDetails = localStorage.getItem('contribute_wish_values');
    this.contribute_wish_info = JSON.parse(wishDetails);

    this.ppEmail = localStorage.getItem('paypalEmail');

    this.paymentAmount = +getamount;

    this.getToken();
    //this.myPaypal();   
    document.getElementById("pay_card").style.display = 'block';
    document.getElementById("pay_paypal").style.display = 'none';

    this.opts = {
      position: 'right',
      barBackground: '#30a6fd',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    
  }
  
 loadDivMindtree(){
  // alert('hai');
   let element = document.getElementById("card-number");
   let myBodyElements = element.getElementsByTagName("iframe")[0];
   
   myBodyElements.style.backgroundColor = 'red';
   
   //document.getElementById("card-number").style.backgroundColor = 'red';
 }

  //dropdown   
  onCountryClick() {
    this.delay = true;
    this.countryClicked = !this.countryClicked;
    this.wasWishClicked = false;
  }
  getCountryCode(value: any) {
    this.txt_display_selectCountry = 'none';
    this.userCountryName = value.name;
    this.countryCode = value.code;
    //this.contryCodeValText = value.code;
    this.customerInfo.country = value.code;
    //console.log(this.countryCode); 
  }
  //dropdown

  paymodeType(type: any) {
    this.paymentBtn = false;
    if (type == 'paypal') {
      this.payMode = true;
      document.getElementById("pay_card").style.display = 'none';
      document.getElementById("pay_paypal").style.display = 'block';
    } else {
      this.payMode = false;
      document.getElementById("pay_card").style.display = 'block';
      document.getElementById("pay_paypal").style.display = 'none';
    }
  }


  // myPaypal() {
  //   let self = this;    
  //   paypal.Button.render({
  //     env: 'sandbox',
  //     client: {
  //       // production: 'Af50nd9nSO89ulqq4KrlEtJMF8i4MHvDQRrZTDitcWIBmVOrFOZceiRyDMLzgf_5fM49DMcR2gt9itLj',
  //       sandbox: 'Af50nd9nSO89ulqq4KrlEtJMF8i4MHvDQRrZTDitcWIBmVOrFOZceiRyDMLzgf_5fM49DMcR2gt9itLj'
  //     },
  //     commit: true,
  //     payment: function (data: any, actions: any) {
  //       return actions.payment.create({
  //         payment: {
  //           transactions: [
  //             {
  //               amount: { total: self.paymentAmount, currency: 'USD' }
  //             }
  //           ]
  //         }
  //       })
  //     },
  //     onAuthorize: function (data: any, actions: any) {
  //       return actions.payment.execute().then(function (payment: any) {
  //         // TODO
  //         self.paymentBtn = true;
  //         console.log(payment);
  //         self.paypal_success_data = payment;
  //       })
  //     }
  //   }, '#paypal-button');   
  // }


  async getToken() {
    let self = this;
    let resList = await this.paymentBusiness.getApi('checkouts/new').subscribe((result) => {
      if (result.response) {
        self.clientToken = result.message.client_token;
        self.creditPaymentMode(self.clientToken);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  creditPaymentMode(clientId: any) {
    let self = this;
    var form = document.querySelector('#my-sample-form');
    var submit = document.querySelector('input[type="submit"]');

    braintree.client.create({
      authorization: clientId
    }, function (err: any, clientInstance: any) {
      if (err) {
        console.error(err);
        return;
      }

      // Create input fields and add text styles  
      braintree.hostedFields.create({
        client: clientInstance,
        styles: {
          'input': {
            'color': '#282c37',
            'font-size': '16px',
            'transition': 'color 0.1s',
            'line-height': '3',
             'padding-bottom' : '10px'
          },
          // Style the text of an invalid input
          'input.invalid': {
            'color': '#E53A40'
          },
          // placeholder styles need to be individually adjusted
          '::-webkit-input-placeholder': {
            'color': 'rgba(0,0,0,0.6)'
          },
          ':-moz-placeholder': {
            'color': 'rgba(0,0,0,0.6)'
          },
          '::-moz-placeholder': {
            'color': 'rgba(0,0,0,0.6)'
          },
          ':-ms-input-placeholder': {
            'color': 'rgba(0,0,0,0.6)'
          }

        },
        // Add information for individual fields
        fields: {
          number: {
            selector: '#card-number',
            placeholder: '1111 1111 1111 1111'
          },
          cvv: {
            selector: '#cvv',
            placeholder: '123',
            type: 'password'
          },
          expirationDate: {
            selector: '#expiration-date',
            placeholder: '10 / 2019'
          }
        }
        
      }, function (err: any, hostedFieldsInstance: any) {
        if (err) {
          console.error(err);
          return;
        }

        // mindtree custom style start  * in mind tree ui this is only way to manage
        let cardNumber = document.getElementById("card-number");
        // console.log(cardNumber.className);

        let cardNumberBodyElements = cardNumber.getElementsByTagName("iframe")[0];
        cardNumberBodyElements.style.position = 'absolute';
        cardNumberBodyElements.style.top = '10px';
        cardNumberBodyElements.style.left = '8px';

        let expDate = document.getElementById("expiration-date");
        let expDateBodyElements = expDate.getElementsByTagName("iframe")[0];
        expDateBodyElements.style.position = 'absolute';
        expDateBodyElements.style.top = '0px';
        expDateBodyElements.style.left = '8px';

        let cardCVnumber = document.getElementById("cvv");
        let cardCVnumberBodyElements = cardCVnumber.getElementsByTagName("iframe")[0];
        cardCVnumberBodyElements.style.position = 'absolute';
        cardCVnumberBodyElements.style.top = '0px';
        cardCVnumberBodyElements.style.left = '8px';
        // mindtree custom style start


        hostedFieldsInstance.on('validityChange', function (event: any) {
          // Check if all fields are valid, then show submit button
          var formValid = Object.keys(event.fields).every(function (key) {
            return event.fields[key].isValid;
          });

          if (formValid) {
            $('#button-pay').addClass('show-button');
          } else {
            $('#button-pay').removeClass('show-button');
          }
        });

        submit.addEventListener('click', function (event) {
          event.preventDefault();

          hostedFieldsInstance.tokenize(function (err: any, payload: any) {
            if (err) {
              console.error(err);
              return;
            }
            self.paymentBtn = true;
            console.log(payload);
            self.cardSuccessData = payload.nonce;
            document.getElementById('button-pay').style.display = 'none';
            // This is where you would submit payload.nonce to your server
            //alert('Submit your nonce to your server here!');
          });
        }, false);
      });
    });

   // this.loadDivMindtree();
  }

  async paypalPayment(addressInfo: any, event:any) {
    let paypalObj = {"FirstName": addressInfo.first_name, "LastName": addressInfo.last_name, "phone": addressInfo.phone_no, "email": addressInfo.email}
    let checkBool = this.checkProperties(paypalObj);
   if(!checkBool) { 
     this.checkBoolPaybal = true; 
     return true; 
    }
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let wishCreater = {
      email: this.ppEmail,
      wishId: this.contribute_wish_info.contribute_wish_id
    }
    let paymentData = {
      "amount": this.paymentAmount,
      "wish_details": wishCreater,
      "returnurl": SITE_URL + "/paypalsuccess/1",
      "cancelurl": SITE_URL + "/paypalsuccess/0",

    };
    //console.log( localStorage.setItem('contribute_wish_values', JSON.stringify(contributeWishes)););
    localStorage.setItem('contributer_address', JSON.stringify(addressInfo));
    let resList = await this.paymentBusiness.postApiPaymentData(paymentData, 'checkouts/paypal_transaction').subscribe((result) => {
      if (result.response) {
        console.log(result);
        // window.open(result.message.url, "_self");
        window.open(result.message.url + '&expType=redirect', "_self", "top=100,left=500,width=600,height=600");
       
      } else {
        console.log(result);
      }
    },
      (error) => {
        console.log(error);
      });
  }


    checkProperties(obj: any) {
      if( obj.email.trim() != ""  &&  obj.FirstName.trim() != ""  && obj.LastName.trim() !="" &&  obj.phone.trim() != ""){
        return true;
      }else{
        return false;
      } 
    }

  async creditcardPayment(addressInfo: any, event:any) {
    //console.log(customerInfo); 
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let wishCreater = {
      wishId: this.contribute_wish_info.contribute_wish_id
    }

    let paymentData = {
      "payments": {
        "amount": this.paymentAmount,
        "nounce": this.cardSuccessData
      },
      "wish_details": wishCreater,
      "card_details": addressInfo
    }
    console.log(addressInfo);

    let resList = await this.paymentBusiness.postApiPaymentData(paymentData, 'checkouts').subscribe((result) => {
      if (result.response) {
        console.log(result);
        this.updateContributeInfo(addressInfo);
      }
    },
      (error) => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        console.log(error);
      });
  }

  async updateContributeInfo(address: any) {
    let contributerData = {
      "contributor": address,
      "wish": this.contribute_wish_info.contribute_wish_id,
      "user": this.contribute_wish_info.contribute_user_key,
      "amount": this.paymentAmount 
    }
    let resList = await this.paymentBusiness.postApiPaymentData(contributerData, 'contributors/contributor_create').subscribe((result) => {
      if (result.response) {
        console.log(result);
        let contributerId = result.data.contributor.id;
        localStorage.setItem("contributer_id", contributerId);
        this.router.navigate(['thankyou-message']);
      }
    },
      (error) => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        console.log(error);
      });
  }

  paypalBtnClick() {
    let click: any = document.getElementsByClassName('paypal-button paypal-button-number-0')[0];
    click.click();
  }

  onClickedOutside2(e: Event) {
    var drop = document.getElementById("countryCode");
    if (drop.classList.contains('active')) {
      drop.classList.remove('active');
      this.wasWishClicked = false;
    }
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}