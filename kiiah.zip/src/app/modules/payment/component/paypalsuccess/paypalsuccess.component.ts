import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { PaymentBusiness } from '../../business/payment.business';
//import { PAYPAL_AUTH_ID, SITE_URL } from '../../../../config/constant';

declare var paypal: any;

@Component({
  selector: 'paypal-success-component',
  templateUrl: './paypalsuccess.component.html',
  styleUrls: ['./paypalsuccess.component.scss']
})

export class paypalSuccessComponent implements OnInit {
  public paypalSuccessCode: any;
  public contribute_info: any;
  public contribute_wish_info: any;
  public successId: any;
  private payAmount: any;

  constructor(private router: Router, private _location: Location, private paymentBusiness: PaymentBusiness, private route: ActivatedRoute, private loaderService:LoaderService) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    let addressDetails = localStorage.getItem('contributer_address');
    this.contribute_info = JSON.parse(addressDetails);
    let wishDetails = localStorage.getItem('contribute_wish_values');
    this.contribute_wish_info = JSON.parse(wishDetails);

    this.payAmount = localStorage.getItem('contribure_amount');

    this.route.params.subscribe(params => {
      this.successId = +params['id'];
    });
    
    if (this.successId == 1) {
      this.updateContributeInfo();
      //this.router.navigate(['thankyou-message']);
    } else if (this.successId == 0) {
      this.loaderService.display(false);
      console.log("Payment Transaction Unsuccessfull");
    }
  }

  async updateContributeInfo() {
    let contributerData = {
      "contributor": this.contribute_info,
      "wish": this.contribute_wish_info.contribute_wish_id,
      "user": this.contribute_wish_info.contribute_user_key,
      "amount": this.payAmount
    }
    let resList = await this.paymentBusiness.postApiPaymentData(contributerData, 'contributors/contributor_create').subscribe((result) => {
      if (result.response) {
        console.log(result);
        let contributerId = result.data.contributor.id;
        localStorage.setItem("contributer_id", contributerId);
        this.router.navigate(['thankyou-message']);     
      }
    },
      (error) => {
        console.log(error);
      });
  }


}