import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { PaymentBusiness } from '../../business/payment.business';
//import { PAYPAL_AUTH_ID, SITE_URL } from '../../../../config/constant';

declare var paypal: any;

@Component({
  selector: 'paypal-login-success',
  templateUrl: './payauth-success.component.html',
  styleUrls: ['./payauth-success.component.scss']
})

export class PayLoginSuccessComponent implements OnInit {
  public paypalSuccessCode: any;
  //public contribute_info: any;
  //public contribute_wish_info: any;

  constructor(private router: Router, private _location: Location, private paymentBusiness: PaymentBusiness, private route: ActivatedRoute, private loaderService:LoaderService) {

  }

  ngOnInit() {

    // let addressDetails = localStorage.getItem('contribute_wish_values');
    // this.contribute_info = JSON.parse(addressDetails);
    // let wishDetails = localStorage.getItem('contribute_wish_values');
    //this.contribute_wish_info = JSON.parse(wishDetails);
    
    this.route.queryParams.subscribe(params => {
      this.paypalSuccessCode = params['code']; // (+) converts string 'id' to a number
      //console.log("Success Code ==> 2" + this.paypalSuccessCode);
    });

    if (this.paypalSuccessCode) {
      this.UpdatepaypalAccount(this.paypalSuccessCode);

    }else{
      this.loaderService.display(false);
    }
  }

  async UpdatepaypalAccount(successData: any) {
    let paySucessData = {
      "code": successData
    }
    let resList = await this.paymentBusiness.paypalLoginAuth(paySucessData, 'auth/paypal').subscribe((result) => {
      if (result.response) {
        console.log(result);                   
      }
      window.close();
    },
      (error) => {
        console.log(error);
      });
  }  


}