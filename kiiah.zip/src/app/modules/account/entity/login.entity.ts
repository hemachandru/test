export interface Login {
    email: string; 
    password: string;
}

export interface SignUp {
    email: string; 
    password: string;
    password_confirmation: string;
}

export interface PasswordReset {
    email: string;
}
