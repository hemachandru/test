import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/Rx';
import { Router } from '@angular/router';
import { AuthService } from 'ng2-ui-auth';

import { Login, SignUp, PasswordReset } from './../entity/login.entity';
import { LoginService } from '../service/login.service'

@Injectable()
export class LoginBusiness {
    public token: string;


    constructor(public loginService: LoginService, public router: Router, private auth: AuthService) {
        var fixed = document.getElementById('loadingDiv');

        fixed.addEventListener('touchmove', function (e) {

            e.preventDefault();

        }, false);
    }

    login(login: Login, url: string) {

        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.loginService.userAuthentication(JSON.stringify(login), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;

    }

    RegisterFrom(signupData: SignUp, url: string) {
        var userFormData = {
            "user": signupData
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.loginService.newUserRegister(JSON.stringify(userFormData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    loginSocialAccount(accountType: string) {
        document.getElementById("loadingDiv").style.display = "block";
        this.auth.authenticate(accountType)
            .subscribe((result: any) => {
                let res = JSON.parse(result._body);
                if (res.response) {
                    localStorage.setItem('token', res.data.auth_token);
                    let userName = res.data.username ? res.data.username : '';
                    localStorage.setItem('userName', userName);
                    this.router.navigate(['userwish']);
                } else {
                    document.getElementById("loadingDiv").style.display = "none";
                    console.log(res.message);
                }
                if (result.message) {
                    document.getElementById("loadingDiv").style.display = "none";
                }
            },
            (error) => {
                console.log(error);
                document.getElementById("loadingDiv").style.display = "none";

            });
    }

    googleAccountAuth(accountType: string, typeParam: any) {
        document.getElementById("loadingDiv").style.display = "block";
        var userData = {
            loginType: typeParam
        }
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.auth.authenticate(accountType, userData)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }


    logout(url: string) {

        this.loginService.userLogout(url)
            .subscribe((result) => {
                //console.log("Result Success");
                if (result.response) {
                    localStorage.clear();
                    this.router.navigate(['/']);
                } else {
                    console.log(result.message)
                }
            },
            (error) => {
                console.log(error);
            });

    }

    forgetPassword(resetData: SignUp, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.loginService.forgetPasswordService(JSON.stringify(resetData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }

    postAPIData(resetData: any, url: string) {
        let activeProject: ReplaySubject<any> = new ReplaySubject(1);
        this.loginService.getPostData(JSON.stringify(resetData), url)
            .subscribe((result) => {
                activeProject.next(result)
            },
            (error) => {
                activeProject.next(error);
            });
        return activeProject;
    }
}