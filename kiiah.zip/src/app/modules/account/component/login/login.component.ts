import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { TranslateService } from 'ng2-translate';
import { Login } from '../../entity/login.entity';
import { LoginBusiness } from '../../business/login.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SharedModule } from '../../../share/translate-shared.module';

@Component({
  selector: 'login-page',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public login: any;
  
  public invalidEmail: any;
  public invalidEmailPlaceholder: any;
  //public requiredEmail: any;
  public requiredEmail:string = 'none';
  
  public emailErrorMessageCheck: string = 'your_email_pls';
  public emailErrorMessageColor: string = '#5e5e5e';

  public passwordErrorMessageCheck: string = 'your_password_pls';
  public passwordErrorMessageColor: string = '#5e5e5e';
  
  public invalidPassPlaceholder: any;
  public requiredPass:string = 'none';
  //public requiredPass: any;
  public invalidPassword: any;

  public validateUser: any;
  public vaidateMessage: any;
  public passwordValue = true;
  public rememberMe: boolean = (localStorage.getItem("rememberMe") == "true") ? true : false;
  public loading: any;
  public invalidPasswordAuth: boolean = false;
  public placeholderNone:any;
  public errorNone:any;

  constructor(private router: Router, private loginBusiness: LoginBusiness, private _location: Location, private translate: TranslateService, private loaderService: LoaderService, private Shared: SharedModule, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
  }

  ngOnInit() {

    this.loaderService.display(true);
    var fixed = document.getElementById('loadingDiv');
    fixed.addEventListener('touchmove', function (e) {
      e.preventDefault();
    }, false);
    this.invalidEmail = 'none';
    this.login = {
      email: this.rememberMe ? localStorage.getItem("email") : '',
      password: this.rememberMe ? localStorage.getItem("password") : '',
    }
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }
  getRememberme(remembermeValue: any) {
    localStorage.setItem("rememberMe", remembermeValue)
  }

  forgetPasswordCall() {
    this.router.navigate(['forgetpassword']);
  }
  signUpCall() {
    this.router.navigate(['socialsignup']);
  }
  async loginFormSubmit(loginData: Login, event: any) {
    this.invalidPasswordAuth = false;
    event.preventDefault();
    this.loaderService.display(true);
    if (localStorage.getItem("rememberMe") == "true") {
      localStorage.setItem("email", loginData.email)
      localStorage.setItem("password", loginData.password)
    }
    if (loginData.email != '' && loginData.password != '') {
      this.mojsBurstButtonAnimation.createMojsStyle(event);
      
      let userData = {
        email:  loginData.email.trim(),
        password: loginData.password
      }

      let resetMessage = await this.loginBusiness.login(userData, 'user/login').subscribe((result) => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        this.loaderService.display(false);
        if (result.response) {
          localStorage.setItem('token', result.data.auth_token);
          this.router.navigate(['userwish']);
        }
        if (!result.response) {
          this.invalidPasswordAuth = true;
          this.vaidateMessage = result.message;

        }
      },
        (error) => {
          console.log(error);
          this.loaderService.display(false);
        });
    }
  }

  clickClosePlacePass(){
    // this.requiredPass = 'none';
    // this.invalidPassPlaceholder = 'block';
    // this.invalidPassword = 'none';
    this.passwordErrorMessageCheck = 'your_password_pls';
    this.passwordErrorMessageColor = '#5e5e5e';
  }

  clickClosePlaceEmail(){
    // this.requiredEmail = 'none';
    // this.invalidEmailPlaceholder = 'block';
    // this.invalidEmail = 'none';
    this.emailErrorMessageCheck = 'your_email_pls';
    this.emailErrorMessageColor = '#5e5e5e';
  }

  goBack() {
    this._location.back();
  }
  onKeyUp(val: any) {
    //var autoFillPass = document.getElementById('password');
    //var autoFillPass = (<HTMLInputElement>document.getElementById("password")).value;
    // if (val != "") {
    //   console.log('Email not empty');
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.emailErrorMessageCheck = 'your_email_pls';
    //     this.emailErrorMessageColor = '#5e5e5e';
    //   } else {
    //     this.emailErrorMessageCheck = 'Email_isinvalid';
    //     this.emailErrorMessageColor = '#ff3504';
    //   }
    // }else {
    //   this.emailErrorMessageCheck = 'Email_Required';
    //   this.emailErrorMessageColor = '#ff3504';
    // }

  }

  onBlurMethod(val: any) {
    if (val != "") {
      console.log('Email not empty');
      if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        console.log('Email valid');
        this.emailErrorMessageCheck = 'your_email_pls';
        this.emailErrorMessageColor = '#5e5e5e';
      } else {
        console.log('Email not valid');
        this.emailErrorMessageCheck = 'Email_isinvalid';
        this.emailErrorMessageColor = '#ff3504';
      }
    }else {
      console.log('Email empty');
      this.emailErrorMessageCheck = 'Email_Required';
      this.emailErrorMessageColor = '#ff3504';
    }
  }

  onKeyUpPass(val: any) {
    // if (val != "") {
    //   if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
    //     this.passwordErrorMessageCheck = 'your_password_pls';
    //     this.passwordErrorMessageColor = '#5e5e5e';
    //     this.passwordValue = true;
    //   } else {
    //     this.passwordValue = false;
    //     this.passwordErrorMessageCheck = 'Password_invalid';
    //     this.passwordErrorMessageColor = '#ff3504';
    //   }
    // }else{
    //     this.passwordErrorMessageCheck = 'Password_required';
    //     this.passwordErrorMessageColor = '#ff3504';
    // }
  }

  validatePassword(val: any) {
    if (val != "") {
      if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
        // this.invalidPassword = 'none';
        // this.invalidPassPlaceholder ='block'
        // this.requiredPass = 'none';
        this.passwordErrorMessageCheck = 'your_password_pls';
        this.passwordErrorMessageColor = '#5e5e5e';
        this.passwordValue = true;
      } else {
        this.passwordValue = false;
        this.passwordErrorMessageCheck = 'Password_invalid';
        this.passwordErrorMessageColor = '#ff3504';
        // this.invalidPassword = 'block';
        // this.invalidPassPlaceholder ='none';
        // this.requiredPass = 'none';
      }
    }else{
      this.passwordErrorMessageCheck = 'Password_required';
      this.passwordErrorMessageColor = '#ff3504';
      // this.invalidPassword = 'none';
      // this.invalidPassPlaceholder ='none';
      // this.requiredPass = 'block';
    }
  }

  changeLang() {
    //this.translate.use(lang);
    this.translate.use('fr');
  }

}