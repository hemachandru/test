import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { socialAuthentication } from '../../../../utility/socialAuth';
import { LayoutComponent } from '../../../layout/component/layout.component';
import { TranslateService } from 'ng2-translate';
import { SharedModule } from '../../../share/translate-shared.module';
@Component({
  selector: 'social-login',
  templateUrl: './sociallogin.component.html',
  styleUrls: ['./sociallogin.component.scss']
})
export class SocialLoginComponent implements OnInit, OnDestroy {
  public login: any;
  public langBool: any;
  public myLangu: any;
  constructor(private router: Router, private socialAuth: socialAuthentication, private translate: TranslateService, private Shared: SharedModule, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
    let language = localStorage.getItem('lang');
    //console.log("first",language)

    // var interval = setInterval(() => {
    //   this.langScript();
    // }, 1000);

    //lang_change
    // var myLanguage = document.getElementById("lang_change").textContent;
    // alert('myLanguage : '+myLanguage);

    //french-lang [ngClass]="{{myLangu}}"

    // this.translate.addLangs(['en']);
    // this.translate.setDefaultLang('en');
    // this.translate.use('en');
    //this.shared.test('fr');
    // 
    // var DefLang = (language == undefined || language == "null") ? "en" : language;
    // this.Shared.test(language);
  }

//   langScript(){
//     let getValue = document.getElementById("lang_change");
//     let textBool = (getValue.textContent) ? true : false;
//     if(textBool){
//     if(getValue.textContent == 'Login'){
//       this.myLangu ='';
//     }else{
//       this.myLangu ='french-lang';
//     }
//   }
//  }

  async socialLogins(LoginType: string, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let timeoutId = setTimeout(() => {
      document.getElementById("loadingDiv").style.display = "none";
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
      this.socialLoginsCode(LoginType, event);
    }, this.mojsBurstButtonAnimation.timeOutValue);
  }

  async socialLoginsCode(LoginType: string, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    let resetMessage = await this.socialAuth.loginSocialAccount(LoginType).subscribe((result) => {
      if (result._body) {
        let res = JSON.parse(result._body);
        if (res.response) {
          localStorage.setItem('token', res.data.auth_token);
          let userName = res.data.username ? res.data.username : '';
          localStorage.setItem('userName', userName);
          this.router.navigate(['userwish']);
        } else {
          document.getElementById("loadingDiv").style.display = "none";
          console.log(res.message);
        }
      }
      if (result.message) {
        document.getElementById("loadingDiv").style.display = "none";
      }
    },
      (error) => {
        console.warn(error);
        document.getElementById("loadingDiv").style.display = "none";

      });
  }

  emailLogin(event: any) {
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('signin', this);
  }

  async googleAuth(LoginType: string, authType: any, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let timeoutId = setTimeout(() => {
      document.getElementById("loadingDiv").style.display = "none";
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
      this.googleAuthCode(LoginType, authType, event);
    }, this.mojsBurstButtonAnimation.timeOutValue);
  }

  async googleAuthCode(LoginType: string, authType: any, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    let resetMessage = await this.socialAuth.googleAccountAuth(LoginType, authType).subscribe((result) => {
      if (result._body) {
        let res = JSON.parse(result._body);
        if (res.response) {
          localStorage.setItem('token', res.data.auth_token);
          let userName = res.data.username ? res.data.username : '';
          localStorage.setItem('userName', userName);
          this.router.navigate(['userwish']);
        } else {
          document.getElementById("loadingDiv").style.display = "none";
          console.log(res.message);
        }
      }
      if (result.message) {
        document.getElementById("loadingDiv").style.display = "none";
      }
    },
      (error) => {
        console.log(error);
        document.getElementById("loadingDiv").style.display = "none";

      });
  }
  ngOnDestroy() {
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}