import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { SignUp } from '../../entity/login.entity';
import { LoginBusiness } from '../../business/login.business';

@Component({
  selector: 'signup-page',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignUpComponent implements OnInit {
  public signup: any;

  public invalidEmail: any;
  public emailPlaceholder: any;
  public requiredEmail:string = 'none';

  public invalidPassword: any;
  public FpassPlaceholder: any;
  public requiredFPass:string = 'none';

  public RpassPlaceholder: any;
  public requiredRPass:string = 'none';

  public emailErrorMessageCheck: string = 'your_email_pls';
  public emailErrorMessageColor: string = '#5e5e5e';

  public passwordErrorMessageCheck: string = 'your_password_pls';
  public passwordErrorMessageColor: string = '#5e5e5e';

  public RpasswordErrorMessageCheck: string = 'sorry_again_pls';
  public RpasswordErrorMessageColor: string = '#5e5e5e';

  public errorMessages: any;

  public InvalidUser: boolean = false;
  public invalidNotePassword: any;
  public invalidConfirmPassword: any;
  public validateUser: any;
  public vaidateMessage: any;
  public cpassword = true;
  private burst: any;
  private isPasswordMisMatch: boolean = false;
  private pwdClr : any;
  constructor(private router: Router, private loginBusiness: LoginBusiness, private _location: Location, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
  }

  ngOnInit() {
    //passwordnot
    let passChk = sessionStorage.getItem('passwordnot');
    if(passChk == 'passwordnot'){
      this.passwordErrorMessageCheck = 'password_again_pls';
      this.passwordErrorMessageColor = '#ff3504';

      this.RpasswordErrorMessageCheck = 'repeat_password';
      this.RpasswordErrorMessageColor = '#ff3504';
    }else{
      this.passwordErrorMessageCheck = 'your_password_pls';
      this.passwordErrorMessageColor = '#5e5e5e';
      
      this.RpasswordErrorMessageCheck = 'sorry_again_pls';
      this.RpasswordErrorMessageColor = '#5e5e5e';
    }

    this.loaderService.display(true);
    var fixed = document.getElementById('loadingDiv');

    fixed.addEventListener('touchmove', function (e) {

      e.preventDefault();

    }, false);
    this.signup = {
      email: '',
      password: '',
      password_confirmation: ''
    }
    this.mojsBurstButtonAnimation.intializeMojs();

    if (localStorage.getItem('Email_id')) {
      this.isPasswordMisMatch = true;
      this.signup = {
        email: localStorage.getItem('Email_id'),
        password: '',
        password_confirmation: ''
      }
    }
    this.loaderService.display(false);
  }

  loginInCall() {
    this.router.navigate(['login']);
  }

  onSupport() {
    this.router.navigate(['support']);
  }

  async RegisterFormSubmit(RegisterData: SignUp, event: any) {

    sessionStorage.removeItem('passwordnot');
    let passChk = sessionStorage.getItem('passwordnot');
    console.log(passChk);
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    if (RegisterData.password !== RegisterData.password_confirmation) {
      localStorage.setItem('Email_id', RegisterData.email);
      // this.mojsBurstButtonAnimation.setTimeOut_Animation('response',this,2);
      this.errorMessages = "Ooops passwords entered did not match !";
      return false;
    }
    if (!this.validatePassword(RegisterData.password)) {
      // this.mojsBurstButtonAnimation.setTimeOut_Animation('response',this,1);
      this.errorMessages = "Ooops.. Password should be 8 characters length, 1 uppercase, 1 lowercase, one special character";
      return false;
    }

    if (RegisterData.email != '' && RegisterData.password != '' && RegisterData.password_confirmation != '') {
      document.getElementById("loadingDiv").style.display = "block";
      localStorage.removeItem('Email_id');
      let resetMessage = await this.loginBusiness.RegisterFrom(RegisterData, 'user/registration').subscribe((result) => {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        if (result) {
          document.getElementById("loadingDiv").style.display = "none";

          if (result.errors) {
            this.vaidateMessage = result.errors.email[0];
            //console.log(result.response);
            if(result.response == false){
              //has already been taken 
              // this.mojsBurstButtonAnimation.setTimeOut_Animation('response',this,3);
              this.errorMessages = "Ooops Email has already been taken!";
              return false;
            }
          }
          if (result.response) {
            localStorage.setItem('resetMail', RegisterData.email);
            this.router.navigate(['resetsuccess'], { queryParams: { signup: 1 } });
          }
        }

      },
        (error) => {
          console.warn(error);
          this.mojsBurstButtonAnimation.resetMojsStyle(document);
          document.getElementById("loadingDiv").style.display = "none";

        });
    }
  }

  clickEmail(){
    // this.requiredEmail = 'none';
    // this.emailPlaceholder = 'block';
    // this.invalidEmail = 'none';
    this.emailErrorMessageCheck = 'your_email_pls';
    this.emailErrorMessageColor = '#5e5e5e';
  }

  clickPass(){
    let passChk = sessionStorage.getItem('passwordnot');
    if(passChk == 'passwordnot'){
      this.passwordErrorMessageCheck = 'password_again_pls';
      this.passwordErrorMessageColor = '#ff3504';
    }else{
      this.passwordErrorMessageCheck = 'your_password_pls';
      this.passwordErrorMessageColor = '#5e5e5e';
    }
  }

  clickRePass(){
    let passChk = sessionStorage.getItem('passwordnot');
    if(passChk == 'passwordnot'){
      this.RpasswordErrorMessageCheck = 'repeat_password';
      this.RpasswordErrorMessageColor = '#ff3504';
    }else{
      this.RpasswordErrorMessageCheck = 'sorry_again_pls';
      this.RpasswordErrorMessageColor = '#5e5e5e';
    }
  }

  goBack() {
    this._location.back();
  }
  /* For Form validation */
  onKeyUp(val: any) {
    // if (val == "") {
    //   this.invalidEmail = 'hidden';
    // }
    // if (val != "") {
    //   console.log('Email not empty');
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.emailErrorMessageCheck = 'your_email_pls';
    //     this.emailErrorMessageColor = '#5e5e5e';
    //   } else {
    //     this.emailErrorMessageCheck = 'Email_isinvalid';
    //     this.emailErrorMessageColor = '#ff3504';
    //   }
    // }else {
    //   this.emailErrorMessageCheck = 'Email_Required';
    //   this.emailErrorMessageColor = '#ff3504';
    // }
  }
  onKeyUpPass(val: any) {
    if (val == "") {
      this.invalidPassword = 'hidden';
    }
  }
  onKeyUpCPass(val: any) {
    if (val == "") {
      this.invalidConfirmPassword = 'hidden';
    }
  }
  /** Email validation Function */
  onBlurMethod(val: any) {
    if (val != "") {
      console.log('Email not empty');
      if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.emailErrorMessageCheck = 'your_email_pls';
        this.emailErrorMessageColor = '#5e5e5e';
      } else {
        this.emailErrorMessageCheck = 'Email_isinvalid';
        this.emailErrorMessageColor = '#ff3504';
      }
    }else {
      this.emailErrorMessageCheck = 'Email_Required';
      this.emailErrorMessageColor = '#ff3504';
    }
    // if (val != "") {
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.invalidEmail = 'none';
    //     this.emailPlaceholder ='block'
    //     this.requiredEmail = 'none';
    //     console.log('emailPlaceholder');
    //   } else {
    //     this.invalidEmail = 'block';
    //     this.emailPlaceholder ='none';
    //     this.requiredEmail = 'none';
    //     console.log('invalidEmail');
    //   }
    // }else{
    //   this.invalidEmail = 'none';
    //   this.emailPlaceholder ='none';
    //   this.requiredEmail = 'block';
    //   console.log('requiredEmail');
    // }
  }

  onFPass(val: any){
    if (val != "") {
      if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
        this.passwordErrorMessageCheck = 'your_password_pls';
        this.passwordErrorMessageColor = '#5e5e5e';
      } 
      // else {
      //   this.passwordErrorMessageCheck = 'Password_invalid';
      //   this.passwordErrorMessageColor = '#ff3504';
      // }
    }else{
        this.passwordErrorMessageCheck = 'Password_required';
        this.passwordErrorMessageColor = '#ff3504';
    }
    // if (val == "") {
    //    this.requiredFPass = 'block';
    //    this.FpassPlaceholder = 'none';
    //   //console.log('Empty',val);
    // }else{
    //    this.requiredFPass = 'none';
    //    this.FpassPlaceholder = 'block';
    //   //console.log('not empty',val);
    // }
  }

  onRPass(val: any){
    if (val != "") {
      if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
        this.RpasswordErrorMessageCheck = 'sorry_again_pls';
        this.RpasswordErrorMessageColor = '#5e5e5e';
      } else {
        this.RpasswordErrorMessageCheck = 'sorry_again_pls';
        this.RpasswordErrorMessageColor = '#ff3504';
      }
    }else{
        this.RpasswordErrorMessageCheck = 'sorry_again_pls';
        this.RpasswordErrorMessageColor = '#ff3504';
    }
    // if (val == "") {
    //    this.requiredRPass = 'block';
    //    this.RpassPlaceholder = 'none';
    //   //console.log('Empty',val);
    // }else{
    //    this.requiredRPass = 'none';
    //    this.RpassPlaceholder = 'block';
    //   //console.log('not empty',val);
    // }
  }
  /** Password validation Function */
  validatePassword(val: any) {
    if (val != "") {
      if (val.match(/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/)) {
        return true;
      } else {
        return false;
      }
    }
  }

  validateConfirmPassword(val: any, passwordText: any) {

    if (val.trim() != "") {

      if (val == passwordText) {
        this.cpassword = true;
        this.invalidConfirmPassword = 'none';
      } else {
        this.cpassword = false;
        this.invalidConfirmPassword = 'block';
      }
    } else {
      this.invalidConfirmPassword = 'none';
    }
  }

}