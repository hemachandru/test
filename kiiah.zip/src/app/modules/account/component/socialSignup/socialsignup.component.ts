import { Observable } from 'rxjs/Observable';
import { Component, OnInit ,OnDestroy} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';
import { socialAuthentication } from '../../../../utility/socialAuth';


@Component({
  selector: 'social-signup',
  templateUrl: './socialsignup.component.html',
  styleUrls: ['./socialsignup.component.scss']
})
export class SocialSignupComponent implements OnInit,OnDestroy {
  public login: any;

  constructor(private router: Router, private socialAuth: socialAuthentication, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {
    //clear all sesssion and local storage
    //localStorage.clear();
    //sessionStorage.clear();
    //email
    //password
    //token
  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.loaderService.display(false);
  }

  loginInCall() {
    this.router.navigate(['login']);
  }
  
  async socialLogins(LoginType: string, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let timeoutId = setTimeout(() => {
      document.getElementById("loadingDiv").style.display = "none";
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
      this.socialLoginsCode(LoginType);
    }, this.mojsBurstButtonAnimation.timeOutValue);
  }

  async socialLoginsCode(LoginType: string) {
    document.getElementById("loadingDiv").style.display = "block";
    let resetMessage = await this.socialAuth.loginSocialAccount(LoginType).subscribe((result) => {

      if (result._body) {
        let res = JSON.parse(result._body);
        if (res.response) {
          localStorage.setItem('token', res.data.auth_token);
          let userName = res.data.username ? res.data.username : '';
          localStorage.setItem('userName', userName);
          this.router.navigate(['userwish']);
        } else {
          document.getElementById("loadingDiv").style.display = "none";
          console.log(res.message);
        }
      }
      if (result.message) {
        document.getElementById("loadingDiv").style.display = "none";
      }
    },
      (error) => {
        console.warn(error);
        document.getElementById("loadingDiv").style.display = "none";

      });
  }

  emailSignup(event:any) {
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('signup',this);
  }

  async googleAuth(LoginType: string, authType: any, event: any) {
    document.getElementById("loadingDiv").style.display = "block";
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    let timeoutId = setTimeout(() => {
      document.getElementById("loadingDiv").style.display = "none";
      this.mojsBurstButtonAnimation.resetMojsStyle(document);
      this.googleAuthCode(LoginType, authType);
    }, this.mojsBurstButtonAnimation.timeOutValue);
  }

  async googleAuthCode(LoginType: string, authType: any) {
    document.getElementById("loadingDiv").style.display = "block";
    let resetMessage = await this.socialAuth.googleAccountAuth(LoginType, authType).subscribe((result) => {

      if (result._body) {
        let res = JSON.parse(result._body);
        if (res.response) {
          localStorage.setItem('token', res.data.auth_token);
          let userName = res.data.username ? res.data.username : '';
          localStorage.setItem('userName', userName);
          this.router.navigate(['userwish']);
        } else {
          document.getElementById("loadingDiv").style.display = "none";
          console.log(res.message);
        }
      }
      if (result.message) {
        document.getElementById("loadingDiv").style.display = "none";
      }
    },
      (error) => {
        console.log(error);
        document.getElementById("loadingDiv").style.display = "none";

      });
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }

}