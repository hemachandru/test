import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
    selector: 'response-msg',
    templateUrl: 'response-message.component.html',
    styleUrls: ['./response-message.component.scss']
})

export class ResponseMsgComponent implements OnInit, OnDestroy {
    private responseId: any;
    constructor(private location: Location, private activeRoute: ActivatedRoute, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService: LoaderService) { }

    ngOnInit() {
        this.loaderService.display(true);
        this.mojsBurstButtonAnimation.intializeMojs();
        var GetId = this.activeRoute.params.subscribe(params => {
            this.responseId = +params['res_id'];
        });
        this.loaderService.display(false);
    }

    btnClose(event: any) {
        this.mojsBurstButtonAnimation.createMojsStyle(event);
        this.loaderService.display(true);
        let timeoutId = setTimeout(() => {
            this.loaderService.display(false);
            this.location.back();
            this.mojsBurstButtonAnimation.resetMojsStyle(document);
        }, this.mojsBurstButtonAnimation.timeOutValue);
    }

    ngOnDestroy() {
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
    }

}