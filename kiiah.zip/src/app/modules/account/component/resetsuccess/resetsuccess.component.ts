import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { LoginBusiness } from '../../business/login.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'reset-success',
  templateUrl: './resetsuccess.component.html',
  styleUrls: ['./resetsuccess.component.scss']
})
export class RestSuccessComponent implements OnInit ,OnDestroy {
  public resetMailId: any;
  private queryParams: any;
  private showMessage: any;


  constructor(private router: Router, private _location: Location, private activeRoute: ActivatedRoute, private loginBusiness: LoginBusiness, private mojsBurstButtonAnimation: MojsBurstButtonAnimation, private loaderService:LoaderService) {

  }

  ngOnInit() {
    this.loaderService.display(true);
    this.mojsBurstButtonAnimation.intializeMojs();
    this.resetMailId = localStorage.getItem('resetMail');

    var GetId = this.activeRoute.queryParams.subscribe(params => {
      this.queryParams = params;
    });
    if (this.queryParams.key) {
      this.verifyEmail(this.queryParams.key);
    }
    else if (this.queryParams.signup) {
      this.showMessage = 'signup';
      this.loaderService.display(false);
    }
    else if (this.queryParams.reset) {
      this.showMessage = 'reset';
      this.loaderService.display(false);
    }
  }

  btnClose(event:any) {
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('/',this);
  }
  async verifyEmail(key: any) {
    let token = {
      "token": key
    }
    let resList = await this.loginBusiness.postAPIData(token, 'user/confirm_email').subscribe((result) => {
      if (result.response) {
        this.showMessage = 'email';
      } else {
        this.showMessage = 'error';
      }
    },
      (error) => {
        console.log(error);
        //document.getElementById("loadingDiv").style.display = "none";
      });
  }
  goBack() {
    this._location.back();
  }
  goToLogin(event:any) {
    event.preventDefault();
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.mojsBurstButtonAnimation.setTimeOut_Animation('signin',this);
  }

  ngOnDestroy(){
    this.mojsBurstButtonAnimation.resetMojsStyle(document);
  }
}