import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent, ActivatedRoute, Params } from '@angular/router';

@Component({
    templateUrl: './account.component.html',
    styleUrls: ['./account.component.scss']
})

export class AccountComponent implements OnInit {
    public activeURL: string;
    private responseId: number;
    private successParam: any;
    
    constructor(private router: Router, private el: ElementRef, private route: ActivatedRoute) {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.activeURL = event.url;                
            }
        });

        this.route.params.subscribe(params => {
            this.responseId = +params['res_id']; // (+) converts string 'id' to a number

        });
       
        this.route.queryParams.subscribe(params => {
            this.successParam = params;           
        });        
    }

    public createWish = true;

    ngOnInit() {   
        document.getElementById("navHeader").style.display = "block";     
    }
}