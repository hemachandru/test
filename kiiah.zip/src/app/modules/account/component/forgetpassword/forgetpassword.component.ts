import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { PasswordReset } from '../../entity/login.entity';
import { LoginBusiness } from '../../business/login.business';
import { LoaderService, MojsBurstButtonAnimation } from '../../../../utility/helper.service';

@Component({
  selector: 'password-reset',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.scss']
})
export class PasswordRestComponent implements OnInit {
  public PasswordReset: any;
  
  public invalidEmail: any;
  public emailPlaceholder: any;
  public requiredEmail:string = 'hidden';

  public InvalidUser: boolean = false;
  public validateUser: any;
  public vaidateMessage: any;
  password_valid = false;

  public emailErrorMessageCheck: string = 'your_email_pls';
  public emailErrorMessageColor: string = '#5e5e5e';

  constructor(private router: Router, private loginBusiness: LoginBusiness, private _location: Location, private loaderService:LoaderService, private mojsBurstButtonAnimation: MojsBurstButtonAnimation) {
  }

  ngOnInit() {
    this.loaderService.display(true);
    var fixed = document.getElementById('loadingDiv');
    this.mojsBurstButtonAnimation.intializeMojs();
    fixed.addEventListener('touchmove', function (e) {

      e.preventDefault();

    }, false);
    this.PasswordReset = {
      email: ''
    }
    this.loaderService.display(false);
  }

  onSupport() {
    //this.router.navigate(['support']);
  }

  async passwordResetSubmit(resetData: any, event: any) { 
    this.mojsBurstButtonAnimation.createMojsStyle(event);
    this.vaidateMessage = '';
    if (resetData.email != '') {
      document.getElementById("loadingDiv").style.display = "block";
      let resetMessage = await this.loginBusiness.forgetPassword(resetData, 'user/forgot_password').subscribe((result) => {
        
        this.mojsBurstButtonAnimation.resetMojsStyle(document);
        if (result) {
          document.getElementById("loadingDiv").style.display = "none";
          this.validateUser = result.response;
          this.vaidateMessage = result.message;
          localStorage.setItem("resetMail", this.PasswordReset.email);
        }
        if (result.response) {          
          this.router.navigate(['resetsuccess'], { queryParams: { reset: 1 } });
        }else{
          console.log('invalid', resetData.email);
          //this.email = ''
          // this.invalidEmail = 'visible';
           this.emailPlaceholder ='hidden';
          // this.requiredEmail = 'hidden';
        }

      },
        (error) => {
          console.log(error);
          this.mojsBurstButtonAnimation.resetMojsStyle(document);
          document.getElementById("loadingDiv").style.display = "none";
        });

    }
  }

  clickClosePlace(){
    // this.requiredEmail = 'hidden';
    // this.invalidEmail = 'hidden';
    // this.emailPlaceholder = 'visible';
    this.vaidateMessage = '';
    this.emailErrorMessageCheck = 'your_email_pls';
    this.emailErrorMessageColor = '#5e5e5e';
  }

  goBack() {
    this._location.back();
  }

  onBlurMethod(value: any) {
    // this.vaidateMessage = '';
    // if (value != "") {
    //   if (value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.password_valid = true;
    //   } else {
    //     this.password_valid = false;
    //   }
    // }
    this.vaidateMessage = '';
    // if (value != "") {
    //   console.log('Email not empty');
    //   if (value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.emailErrorMessageCheck = 'your_email_pls';
    //     this.emailErrorMessageColor = '#5e5e5e';
    //   } else {
    //     this.emailErrorMessageCheck = 'Email_isinvalid';
    //     this.emailErrorMessageColor = '#ff3504';
    //   }
    // }else {
    //   this.emailErrorMessageCheck = 'Email_Required';
    //   this.emailErrorMessageColor = '#ff3504';
    // }
  }
  onKeyUp(val: any) {
    // if (val == "") {
    //   this.invalidEmail = 'hidden';
    // }
    this.vaidateMessage = '';
    // if (val != "") {
    //   console.log('Email not empty');
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.emailErrorMessageCheck = 'your_email_pls';
    //     this.emailErrorMessageColor = '#5e5e5e';
    //   } else {
    //     this.emailErrorMessageCheck = 'Email_isinvalid';
    //     this.emailErrorMessageColor = '#ff3504';
    //   }
    // }else {
    //   this.emailErrorMessageCheck = 'Email_Required';
    //   this.emailErrorMessageColor = '#ff3504';
    // }
  }
  onBlurEmail(val: any) { 
    this.vaidateMessage = '';
    if (val != "") {
      console.log('Email not empty');
      if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.emailErrorMessageCheck = 'your_email_pls';
        this.emailErrorMessageColor = '#5e5e5e';
      } else {
        this.emailErrorMessageCheck = 'Email_isinvalid';
        this.emailErrorMessageColor = '#ff3504';
      }
    }else {
      this.emailErrorMessageCheck = 'Email_Required';
      this.emailErrorMessageColor = '#ff3504';
    }

    // if (val != "") {
    //   if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
    //     this.password_valid = true;
    //     this.invalidEmail = 'hidden';
    //     this.emailPlaceholder ='visible'
    //     this.requiredEmail = 'hidden';
    //   } else {
    //     this.password_valid = false;
    //     this.invalidEmail = 'visible';
    //     this.emailPlaceholder ='hidden';
    //     this.requiredEmail = 'hidden';
    //   }
    // }else{
    //   this.invalidEmail = 'hidden';
    //   this.emailPlaceholder ='hidden';
    //   this.requiredEmail = 'visible';
    // }
  }
}