import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from 'ng2-translate';
import { EqualValidator } from './validator/equal-validator.directive';

import { AccountComponent } from './component/account.component';
import { LoginComponent } from './component/login/login.component';
import { SocialLoginComponent } from './component/socialLogin/sociallogin.component';
import { SignUpComponent } from './component/signup/signup.component';
import { SocialSignupComponent } from './component/socialSignup/socialsignup.component';
import { PasswordRestComponent } from './component/forgetpassword/forgetpassword.component';
import { RestSuccessComponent } from './component/resetsuccess/resetsuccess.component';
import { ResponseMsgComponent } from "./component/response-message/response-message.component";

import { LoginBusiness } from './business/login.business';
import { LoginService } from './service/login.service';

import { AccountRoutingModule } from './account.routing';
import { UtilityModule } from '../../utility/utility.module';
import { socialAuthentication } from '../../utility/socialAuth';
import { SharedModule } from '../share/translate-shared.module';

@NgModule({
  imports: [
    CommonModule,
    AccountRoutingModule,
    FormsModule,
    //TranslateModule.forRoot(),
    UtilityModule,
    SharedModule
  ],
  declarations: [
    AccountComponent,
    SocialLoginComponent,
    LoginComponent,
    SignUpComponent,
    SocialSignupComponent,
    PasswordRestComponent,
    RestSuccessComponent,
    EqualValidator,
    ResponseMsgComponent

  ],
  providers: [LoginBusiness, LoginService, socialAuthentication, SharedModule],
  exports: [EqualValidator]
})
export class AccountModule { }

