import { Injectable } from '@angular/core';

import { HttpRequestService } from '../../../service/http-request.service';


@Injectable()
export class LoginService {

    constructor(private httpRequest: HttpRequestService) {

    }

    userAuthentication(data: any, url: string) {
        return this.httpRequest.putHttpRequestWithoutToken(data, url);
    }

    newUserRegister(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }

    userLogout(url: string) {
        return this.httpRequest.deleteHttpRequestWithToken(url);
    }

    forgetPasswordService(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }
    getPostData(data: any, url: string) {
        return this.httpRequest.postHttpRequestWithoutToken(data, url);
    }

}