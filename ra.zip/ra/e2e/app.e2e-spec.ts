import { RaPage } from './app.po';

describe('ra App', function() {
  let page: RaPage;

  beforeEach(() => {
    page = new RaPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
