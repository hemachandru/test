import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeroesComponent }      from './heroes/heroes.component';
import { NotfoundComponent } from './notfound/notfound.component';

import {StarsModule} from "./stars/stars.module"

const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'heroes', component: HeroesComponent },
      {path:"",loadChildren:"./stars/stars.module#StarsModule"}
    ]
  },{ path: '**', component: NotfoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})

export class AppRoutingModule { }
