import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ranjith',
  templateUrl: './ranjith.component.html',
  styleUrls: ['./ranjith.component.css']
})
export class RanjithComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
