import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chandru',
  templateUrl: './chandru.component.html',
  styleUrls: ['./chandru.component.css']
})
export class ChandruComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
