import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
 
import { StarsComponent } from './stars/stars.component'
import { RanjithComponent } from './ranjith/ranjith.component'
import { ChandruComponent } from './chandru/chandru.component'

import { StarNotfoundComponent } from './star-notfound/star-notfound.component'

const routes: Routes = [
  {
    path: '',
    component:StarsComponent , 
    children:[ 
      {path:"", redirectTo:"ranjith",pathMatch: 'full'},
      {path:"ranjith", component:RanjithComponent},
      {path:"chandru", component:ChandruComponent},
      {
        path:"**",
        component:StarNotfoundComponent
      } 
    ]
  },
  

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})

export class StarsRoutingModule { }
