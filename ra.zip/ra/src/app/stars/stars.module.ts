import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StarsRoutingModule } from "./stars-routing.module";

import { StarsComponent } from './stars/stars.component';
import { RanjithComponent } from './ranjith/ranjith.component';
import { ChandruComponent } from './chandru/chandru.component';
import { StarNotfoundComponent } from './star-notfound/star-notfound.component';
import { UserComponent } from './user/user.component'

@NgModule({
  imports: [
    CommonModule,
    StarsRoutingModule
  ],
  declarations: [StarsComponent, RanjithComponent, ChandruComponent, StarNotfoundComponent, UserComponent]
})
export class StarsModule { }
