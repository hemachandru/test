import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { debug } from 'util';


@Component({
  selector: 'app-star-notfound',
  templateUrl: './star-notfound.component.html',
  styleUrls: ['./star-notfound.component.css']
})
export class StarNotfoundComponent implements OnInit {
  public name:any;

  constructor(private route: ActivatedRoute) {
    
    this.route.url.subscribe((url)=> { this.name=url; console.log(url)});
    console.log(this.name)

    console.log(this.route.snapshot.fragment)
   }

  ngOnInit( ) {
  }

}
