import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { Config } from '../../config/constant';
import { Login, Register, Token } from '../models/user';
// import { AuthService } from '../services/auth.service';
import { AuthService } from '../services/auth.service';
import { ApiUrl,AppLocalStorageKeys } from '../../../environments/environment';

@Injectable()

export class AuthBusiness {
  private apiUrl = ApiUrl;

  constructor(private authService: AuthService) { }
  //SignUp

  login(login: Login) {
    let url = this.apiUrl.LOGIN;
    // let headers = this.config.APIKey;
    return this.authService.authServicePostMethod(login, url).map(res => {
      // localStorage.setItem('authToken', res.token);
      if (res.token) {
        localStorage.setItem(AppLocalStorageKeys.AUTH_Token, res.token);
        localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID, res.contactId);
        localStorage.setItem(AppLocalStorageKeys.USER_CHANNEL_STATUS, res.channelStatusId);
        localStorage.setItem(AppLocalStorageKeys.CHANNEL_ID, res.channelId);

      }
      return res
    });
  }

  forgetPasswordBusiness(forgetPass: Login) {
    let url = this.apiUrl.FORGETPASSWORD;
    // let headers = this.config.APIKey;
    return this.authService.authServicePostMethod(forgetPass, url).map(res => {
      return res;
    });
  }

  resetPasswordTokenCheckBusiness(Tokenkey) {
    let url = this.apiUrl.RESETPASSWORD;
    // let headers = this.config.APIKey;
    return this.authService.resetPasswordTokenCheckService(Tokenkey, url).map(res => {
      return res
    });
  }

  resetPasswordBusiness(userId, passValue) {
    let url = this.apiUrl.RESETPASSWORDUPDATE;
    let apiUrl = url + "/" + userId;
    // console.log('API URL : ',apiUrl);
    // let apiUrl = url+"/24";
    // let headers = this.config.APIKey;
    return this.authService.authServicePostMethod(passValue, apiUrl).map(res => {
      return res
    });
  }

  register(data: any) {
    const url = this.apiUrl.SIGNUP;
    // const headers = this.config.APIKey;
    return this.authService.authServicePostMethod(data, url).map(res => {
      return res;
    });
  }

  isEmailRegisterd(data: any) {
    const url = this.apiUrl.CHECK_EMAIL;
    return this.authService.getHttpRequestWithDataMethod(data, url).map(res => {
      return res;
    });
  }

  verifyValidUserBusiness(key) {
    let url = this.apiUrl.VERIFYUSER;
    // let headers = this.config.APIKey;
    return this.authService.verifyValidUserBusiness(key, url).map(res => {
      if (res.token) {
        localStorage.setItem(AppLocalStorageKeys.AUTH_Token, res.token);
        localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID, res.contactId);
        localStorage.setItem(AppLocalStorageKeys.USER_CHANNEL_STATUS, res.channelStatusId);
      }
      return res
    });
  }

  resendEmail() {
    const url = this.apiUrl.RESENDEMAIL;
    return this.authService.resendEmail(url).map(res => {
      return res;
    });
  }

  changeAndResendEmail(email: string) {
    const url = this.apiUrl.CHANGEANDRESENDEMAIL;
    return this.authService.changeAndResendEmail(email, url).map(res => {
      return res;
    });
  }
}
