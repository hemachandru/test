import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod, Request } from '@angular/http';
import { Observable } from 'rxjs/Observable';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';

import { environment, ApiUrl, AppLocalStorageKeys } from '../../../environments/environment';

import { selector } from 'rxjs/operator/publish';
import { HttpParams } from '@angular/common/http';

@Injectable()
export class HttpRequestService {
  private headers: Headers;
  private Environment = environment;
  private config = ApiUrl;

  constructor(private http: Http, private router: Router) {
    this.headers = new Headers();
  }

  getHttpRequestWithoutTokenWithData(data: string, url: string) {
    let params = url + "/" + data
    var self = this;
    // let APP_key = localStorage.getItem("appToken");
    let APP_key = localStorage.getItem(AppLocalStorageKeys.APP_Token);
    debugger;
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);
    return self.http.get(self.Environment.baseURL + params, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  getHttpRequestWithoutTokenQueryString(data: string, param: any, url: string) {
    let params = url + "/" + data + "?" + param
    var self = this;
    let APP_key = localStorage.getItem(AppLocalStorageKeys.APP_Token);
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);
    return self.http.get(self.Environment.baseURL + params, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  // Trade Information
  getHttpRequestWithQueryString(param: any, url: string) {
    let params = url + "?" + param
    var self = this;
    let APP_key = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);
    return self.http.get(self.Environment.baseURL + params, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  getHttpRequestWithSubQueryString(httpParams: HttpParams, url: string) {

    let params = url + "?" + httpParams.toString();

    var self = this;
    let APP_key = localStorage.getItem("authToken");
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);

    return self.http.get(self.Environment.baseURL + params, {
      headers: self.headers,
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
     * GET Http Request without token
     * Common service to handle PUT Http Request
     *
     * @param {string} url - Get request end point URL.
     *
     * @return {Observable}
     */
  getHttpRequestWithoutToken(url: string) {
    var self = this;
    let APP_key = localStorage.getItem(AppLocalStorageKeys.APP_Token);
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);
    return self.http.get(self.Environment.baseURL + url, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
 * POST Http Request without token
 * Common service to handle PUT Http Request
 *
 * @param {string} url - POST request with end point URL.
 * @param {string} data - POST request with data.
 *
 * @return {Observable}
 */
  postHttpRequestAPPToken(data: string, url: string) {
    var self = this;

    this.headers.set('Content-Type', 'application/json');
    return self.http.post(self.Environment.baseURL + url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
 * POST Http Request without token
 * Common service to handle PUT Http Request
 *
 * @param {string} url - POST request with end point URL.
 * @param {string} data - POST request with data.
 *
 * @return {Observable}
 */
  postHttpRequestWithoutToken(data: string, url: string) {
    var self = this;
    let APP_key = localStorage.getItem(AppLocalStorageKeys.APP_Token);

    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', APP_key);
    return self.http.post(self.Environment.baseURL + url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
   * PUT Http Request without token
   * Common service to handle PUT Http Request
   *
   * @param {string} url - PUT request with end point URL.
   * @param {string} data - PUt request with data.
   *
   * @return {Observable}
   */
  putHttpRequestWithoutToken(data: string, url: string) {
    this.headers.set('Content-Type', 'application/json');
    var self = this;
    return self.http.put(self.Environment.baseURL + url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);

  }

  /**
   * GET Http Request with token
   * Common service to handle PUT Http Request
   *
   * @param {string} url - Get request end point URL.
   *
   * @return {Observable}
   */

  getHttpRequest(url: string) {
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', localStorage.getItem(AppLocalStorageKeys.AUTH_Token));
    var self = this;
    return self.http.get(self.Environment.baseURL + url, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
   * POST Http Request with token

  getHttpRequest(url: string): Observable<Response> {
      this.headers.set('Content-Type', 'application/json');
      let self = this;
      const options = new RequestOptions({
          method: RequestMethod.Get,
          url: self.config.getAppURL() + url,
          headers: this.headers
      });
       return self.http.get(self.config.getAppURL() + url, {
          headers: self.headers
      })
  }


  /**
   * POST Http Request without token
   * Common service to handle PUT Http Request
   *
   * @param {string} url - POST request with end point URL.
   * @param {string} data - POST request with data.
   *
   * @return {Observable}
   */

  postHttpRequest(data: string, url: string) {
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', localStorage.getItem(AppLocalStorageKeys.AUTH_Token));
    var self = this;
    return self.http.post(self.Environment.baseURL + url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }

  /**
   * PUT Http Request with token
   * Common service to handle PUT Http Request
   *
   * @param {string} url - PUT request with end point URL.
   * @param {string} data - PUT request with data.
   *
   * @return {Observable}
   */
  putHttpRequest(data: string, url: string) {
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', localStorage.getItem(AppLocalStorageKeys.AUTH_Token));
    var self = this;
    return self.http.put(self.Environment.baseURL + url, data, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);

  }

  /**
   * errorResponse
   * Common method to handle error response
   *
   * @param {Response} error
   *
   * @return {Observable}
   */
  private errorResponse(error: Response) {
    return Observable.of(error.json() || null);
  }

  /**
   * successResponse
   * Common method to handle success response
   *
   * @param {Response} error
   *
   * @return {Observable}
   */
  private successResponse(result: Response) {
    return (<any>result)._body === '' ? {} : result.json();
  }

  getHttpRequestWithData(data: string, url: string) {
    let params = url + "/" + data
    var self = this;
    this.headers.set('Content-Type', 'application/json');
    this.headers.set('Authorization', localStorage.getItem(AppLocalStorageKeys.AUTH_Token));
    return self.http.get(self.Environment.baseURL + params, {
      headers: self.headers
    })
      .map(self.successResponse)
      .catch(self.errorResponse);
  }
}
