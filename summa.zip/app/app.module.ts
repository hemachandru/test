import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { APP_BASE_HREF } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MyDatePickerModule } from 'mydatepicker';
import { ModalModule } from 'angular2-modal';
import { BootstrapModalModule } from 'angular2-modal/plugins/bootstrap';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { SlimScrollModule } from 'ng2-slimscroll';
import { NgPipesModule } from 'ng-pipes';
//import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { LayoutModule } from './modules/layout/layout.module';
import { SharedServiceModule } from "./shared/shared-service-module/shared-service.module";
import { LayoutComponent } from './modules/layout/component/layout.component';
//import { LoginComponent } from './modules/account/component/login/login.component';
//import { RegisterComponent } from './modules/account/component/registration/register.component';
//import { ForgotpasswordComponent } from './modules/account/component/forgotpassword/forgotpassword.component';
import { EqualValidator } from './modules/account/validator/equal-validator.directive';
// import { LogoutComponent } from './modules/logout/logout.component';
// import { TermsComponent } from './modules/termsandconditions/component/terms.component';
import { PageNotFoundComponent } from './component/not-found.component';
import { SupportComponent } from './modules/support/component/support.component';
import { FormBuilderComponent } from './modules/formbuilder/formbuilder.component';
import { EmailPasswordLinkComponent } from './modules/account/component/emailpasswordlinkloader/emailpasswordlink.component';
import { TourNgBootstrapModule } from './shared/tour/plugin/ng-bootstrap/ng-bootstrap.module';
import { HttpRequestService } from './service/http-request.service';
import { PipeModule } from './shared/shared-pipe/pipe.module';
import { ChangePasswordComponent } from './modules/account/component/resetpassword/resetpassword.component';
import { AuthGuard } from './service/auth-guard.service';
import { AuthService } from './service/auth.service';
import { PortalForgotpasswordComponent } from './modules/account/component/portal-forgotpassword/portal-forgotpassword.component';
import { AppForgotpasswordComponent } from './modules/account/component/app-forgotpassword/app-forgotpassword.component';
import { PortalLoginComponent } from './modules/account/component/portal-login/portal-login.component';
import { AppLoginComponent } from './modules/account/component/app-login/app-login.component';
import { PortalRegisterComponent } from './modules/account/component/portal-registration/portal-register.component';
import { AppRegisterComponent } from './modules/account/component/app-registration/app-register.component';
import { SharedLoginModule } from './modules/account/component/shared/shared.module';
import { LoaderService } from './shared/shared-loader/shared-loader.service';

@NgModule({
  declarations: [
    AppComponent,
    EqualValidator,
    PageNotFoundComponent,
    // LogoutComponent,
    SupportComponent,
    // TermsComponent,
    PageNotFoundComponent,
    FormBuilderComponent,
    EmailPasswordLinkComponent,
    ChangePasswordComponent,
     PortalLoginComponent,
    AppLoginComponent,
    PortalRegisterComponent,
    AppRegisterComponent,
	PortalForgotpasswordComponent,
    AppForgotpasswordComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule,
    LayoutModule,
    AppRoutingModule,
    MyDatePickerModule,
    SharedServiceModule.forRoot(),
    TourNgBootstrapModule.forRoot(),
    ModalModule.forRoot(),
    BootstrapModalModule,
    Ng2PageScrollModule.forRoot(),
    SlimScrollModule,
    NgPipesModule,
    PipeModule,
    //BrowserAnimationsModule,
    SharedLoginModule
  ],
  exports:[],
  providers: [HttpRequestService,LoaderService,AuthGuard,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }