﻿
export class InfoEntity {
    id: number;
    info: string;
}

export class Config {
    //baseURL = "http://192.168.1.20:9090/";
    //baseURL = "http://192.168.1.199:8080/";
    //baseURL = "https://192.168.1.20:9091/";
    // baseURL = "http://localhost:10942/";
    baseURL = "https://test-api-sailcannabis.outsourcelive.com/";

    APIKey = "5x2l6y1V95Plyn88dEhj7WDAOI21MNAW46qZyJSrfB7";
    FormBuilder_Domain = "https://mvctech-form-uat.azurewebsites.net/";

    userdetailUrl = "api/User/Info";

    SignUp = "api/Patients/v2/SignUp";
    getLogo = "api/User/GetLogo";

    updateClinicUrl = "api/Clinics/UpdateClinic";

    notificationCount = "api/User/GetMessagesCount/";

    getPatientList = "api/User/GetMyPatientList/";

    getNotificationMessage = "api/User/GetMessages/";

    updateNotificationStatus = "api/User/UpdateMessage/";

    getLpOrdersUrl = "api/User/GetLPOrders/";

    getAllDocumentUrl = "api/User/GetAllMedicalDocuments/";

    updateMedicalDocStatus = "api/User/UpdateMedicalDocStatus/";

    documentStatus = "'LPSVTP','NVR','VR','FWTLP','LPACP'";

    documentAcceptStatus = "'VR','LPACP'";

    //documentAcceptStatus="NoStatus";

    getMedicalDocument = "api/User/GetMedicalDocument/";

    getPatientByPatientId = "api/Patients/GetPatientByPatientId/";

    getProductList = "api/LP/GetProductList/";

    addOrModifiyOrder = "api/LP/AddOrModifyOrder";


    GetClinicSchedularPage = "api/Clinics/GetClinicSchedularPage/";

    Clinic_Id = "86";
    clinicId = "86";

    Client_Id = "M20V17C03DD21";

    grant_PassType = "password";

    grant_RefreshTokenType = "refresh_token";

    authErrorText = "Unauthorized";

    userInfoUrl = "api/User/Info";

    updateLpData = "api/LP/UpdateLP";

    addorUpdateUserAddressUrl = "api/User/AddorUpdateUserAddress";

    productListUrl = "api/LP/GetProductList";

    settingUrl = "api/User/GetMasterInfo";

    add_UpdateLpProductUrl = "api/LP/AddorModifyProduct";

    getRecentMedicalDocument = "api/User/GetRecentMedicalDocuments/";

    getCannabisLog = "api/Patients/GetCurrentCannabisLog/";

    getUpcomingOrPreviousAppointments = "api/User/GetUpcomingOrPreviousAppointments/";

    VerifyPatientPerms = "api/Clinics/VerifyPatientPerms";

    getFavouriteStrains = "api/User/GetFavouriteStrains/";

    GetTasks = "api/User/GetTasks/";

    AddOrUpdateTask = "api/User/AddOrUpdateTask";

    updateConsultationRequest = "api/User/UpdateConsultationRequest";

    lpMedicalDocumentList = "api/User/GetAllMedicalDocuments/";

    lpCount = "api/Providers/GetCountofLPRequestsNewMDs/";

    lpVerify = "api/User/UpdateMedicalDocStatus";

    getMedicalDocumentLP = "api/User/GetMedicalDocument/";

    postMedicalDocumentLP = "api/Providers/CreateMedicalDocument";

    getUserUpdateLoginResponse = "api/Patients/GetUserUpdateLoginResponse";
    getMedicalDocumentExpiry = "api/Patients/GetMedicalDocumentExpiry";
    CompleteTask = "api/User/CompleteTask";
    SearchClinics = "api/Patients/SearchClinics";
    CreateORUpdateProfile = "api/Patients/CreateORUpdateProfile";
    getALlDocument = "api/User/GetDocumentsInformation";
    getClientUpdates = "api/Patients/GetPatientUpdates/";
    uploadDocument = "api/User/UploadDocument";
    deleteDocument = "api/User/DeleteDocument";
    downloadDocument = "api/User/DownloadDocument";
    changePasswordUrl = "api/User/ChangePassword";
    getLicenseProducers = "api/LP/GetLicenseProducers";
    getProductDetails = "api/User/GetProductDetails/";
    addOrRemoveFavouriteStrains = "api/User/AddOrRemoveFavouriteStrains";
    getConsultationRequests = "api/User/GetConsultationRequests";
    getClinicProvincesCities = "api/Patients/GetClinicProvincesCities";
    getClinicByClinicId = "api/Clinics/GetClinicByClinicId";
    getAllClinicAppointmentReasons = "api/Clinics/AppointmentReasons/GetAllClinicAppointmentReasons/";
    getProvidersByClinic = "api/Patients/GetProvidersByClinic/";
    addormodifyAppointmentUrl = 'api/User/AddOrModifyAppointment';
    cancelAppointment = "api/User/CancelAppointment/";
    AddUpdateClinicAppointmentReasons = "api/Clinics/AppointmentReasons/AddUpdate";
    getAllUpcomingOrPreviousAppointments = "api/User/GetAllUpcomingOrPreviousAppointments/";
    insertConferenceStatus = "api/Patients/InsertConferenceStatus";
    getVideoRoomLink = "api/User/GetVideoRoomLink/opentok/";
    createVideoChatRoom = "api/User/CreateVideoChatRoom";
    endVideoCall = "api/User/EndVideoCall/";
    getVideoCallStatus = "api/User/GetVideoCallStatus/";
    updatePatientProviderConnectedStatus = "api/Patients/UpdatePatientProviderConnectedStatus";
    enableMyAppointmentTurnEmail = "api/User/EnableMyAppointmentTurnEmail";

    sendappoinmentemai:"api/User/SendMyAppointmentTurnEmail";

    updateProviderURL = "api/Providers/UpdateProvider";
    joinNowGet = "api/User/GetVideoRoomLink"

insertConferenceRoom = "api/User/CreateVideoChatRoom";

cancelledQueue = "api/User/UpdateQueuedAppointmentStatus";

    resetPasswordUrl = "api/User/ResetPassword";

    invalidUserName = "UserName Does Not Exists."

    invalidUserEmail = "UserEmail Does Not Exists."

    validateSessionUrl = "api/User/ValidateResetPwdToken";

    passwordRecoveryLink = "Password recovery link sent to your email.";

    linkExpired = "Link expired please try again";

    accountLocked = "The user account has been locked out.";

    passwordSucessReset = "Password Update Succesfully.";

    lastThreePassword = "security feature: last 3 passwords don’t match";

    verficationPhysician = "Verification request has been sent to physician.";

    requestDeclined = "Client request has been declined.";

    invalid_credentials = "invalid credentials";

    Incomplete = "Incomplete";

    updateUserProfileUrl = "api/User/v2/UpdateUserProfile";

    updatedLoginResponse = "api/Patients/GetUserUpdateLoginResponse";

    inValidUrl = "InvalidUrl";

    sendforverification = "Send for Verification";

    decline = "Decline";

    Verificationdeclined = "Verification Declined";

    Verificationrequested = "Verification Requested";

    Verificationapproved = "Verification Approved";

    Orderhasbeenplacedsuccessfully = "Order has been placed successfully.";

    currentPassword = "Current password does not match";

    maximageuploadsize = "Max file size 2MB";

    imagemandatory = "Image Mandatory";

    userProfileStatus = "User profile have changed successfully."

    emailalreadyexist = "The entered email is already registered with us. Please try with the other";

    currentCannabisLog = "api/Patients/GetCurrentCannabisLog/";

    getAllCannabisLog = "api/Patients/GetCannabisLog/";

    getTopRatedStrain = "api/Patients/GetTopRatedStrains/";

    getProductsUsedByPatient = "api/Patients/GetProductsUsedByPatient/";

    noData = "No Data";

    getMasterData = "api/User/GetMasterInfo";
    consultationRequest = "You have a consultation request pending to be approved. Please Wait until that one is finished.";
    upcomingAppointment = "You already have a booked appointment. Please cancel your current appointment or wait until its done.";
    alreadyRegisterWithClinic = "You are registered with a clinic.";
    getPatientClinics = "api/User/SearchPatients";
    invalidPassword = "Invalid Password Format"

    addOrUpdateCannabisLog = "api/Patients/AddOrUpdateCannabisLog";

    requestdeclinedLpUser = "Request Declined";

    verificationrequest = "Verification Request";

    documentStatusFWTLP = "'FWTLP'";

    stockAvailability = "Stock Availability";

    profileType = "Profile Type";

    invalidDate = "Jan  1st, 0001";
    minDateTime = -62135616600000;

    emptyDate = "N/A";

    invalid_username_email_credentials = "";
    invalid_username_credentials = "";
    invalid_password_credentials = "";
    logout = "api/Patients/UpdateUserExperience";
    maxCharacter25 = "Maximum 25 characters";

    clinicAllPatient = "api/User/SearchPatients";

    addPatientSpecialNotes = "api/Clinics/AddPatientSpecialNotes";

    getClinicsStage = "api/Clinics/GetClinicStages/";

    getPatientStage = "api/Patients/GetPatientStage/"

    addUpdateClinicPhases = "api/Clinics/AddUpdateStages";

    addUpdateClinicReferredByOptions = "api/Clinics/AddUpdateReferredByTypes";

    getReferredOptions = "api/Patients/GetReferredByTypes/"

    activateDeactivateProviders = "api/Clinics/ActivateOrDeactivateProvider";

    addUpdatePatient = "api/Clinics/AddUpdatePatientStage";

    patientsSearchClinics = "api/Patients/SearchClinics";

    providerByClinicId = "api/Patients/GetProvidersByClinic/";

    sendOrReferOutPatient = "api/Clinics/ReferPatient";

    send_Out = "Send Out";

    refer_Out = "Refer Out";

    getPhysicianHistory = "api/Patients/GetPhysicianHistory/";

    getPatientVitals = "api/Patients/GetPatientVitals/";

    addPatientVitals = "api/Patients/AddPatientVitals";

    getPatientAllNotes = "api/Providers/GetPatientAllNotes/";

    addorModifyProviderNote = "api/Providers/AddorModifyProviderNote";

    updatePatientMedicalNotes = "api/Patients/UpdatePatientMedicalNotes";

    pendingGetPatientReferrals = "api/Clinics/GetPatientReferrals/";
    Client_Id_strain = "";
    Lp_Id = "28";

    FLOWER = "FLOWER";
    OIL = "OIL";
    CAPSULE = "CAPSULE";
    MILLED = "MILLED";

    FLOWERS = "FLOWER";
    OILS = "OIL";
    CAPSULES = "CAPSULE";
    MILLEDS = "MILLED";

    GetCannabisLog_all = "api/Patients/GetCannabisLog/";
    patientsRole = "patients";
    getMedDocRecomendation = "api/Providers/MedDocRecomendation/";

    SendProductRequestEmailToLP = "api/LP/SendProductRequestEmailToLP";

    sendCannabisLogViaEmail = "api/Patients/SendCannabisLogViaEmail/";

    telemedRequestList = "api/User/GetQueuedAppointments";

    guestClient_Id_strain = "S20T17C03DD21";


    maxDocumentUploadSize = "Max file size 20MB";

    formatNotSupported = "UnSupported file format please use the following formats";

    uploadDocFormats: any[] = ["jpeg", "gif", "png", "bmp", "txt", "pdf", "jpg", "doc", "docx"];

    uploadSucess = "Document upload sucessfully..!"

    uploadUnSucess = "Document cannot be upload please try again..!"

    noStrain = "No strain(s) found"

    basedOnConditionStrainList = "Please select any on the three above."

    basedOnConditionNoStrainList = "Based on your search criteria there is no recommended strains.please contact the clinic."

    maxCharacter20 = "Maximum 20 characters";

    findyourstrain = "Find your strain"

    noChangesMadeUpateNotification = "No change has been made so update action can't be done."

    favoriteStrain = "you will be taken to strain finder to create a favorite strain"

    constructor() { }

    getBaseURL() {
        return this.baseURL;
    }

    GetForms() {
        return this.FormBuilder_Domain;
    }
}

export const additionalInfo: InfoEntity[] = [
    // Additional info for appointment menu icon
    { id: 0, info: 'Lorem0 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for profile menu icon
    { id: 1, info: 'Lorem1 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for clinics menu icon
    { id: 2, info: 'Lorem2 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for suppliers menu icon
    { id: 3, info: 'Lorem3 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for Cannabis log menu icon
    { id: 4, info: 'Lorem4 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for Strain finder icon
    { id: 5, info: 'Lorem5 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for Info center menu icon
    { id: 6, info: 'Lorem6 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for Document menu icon
    { id: 7, info: 'Lorem7 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for Upcoming appointment
    { id: 8, info: 'Lorem8 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for My Tasks
    { id: 9, info: 'Lorem9 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for My Favourite Strain  
    { id: 10, info: 'Lorem10 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for My Cannabis log  
    { id: 11, info: 'Lorem11 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' },
    // Additional info for My Info centre
    { id: 12, info: 'Lorem12 ipsum dolor sit amet, consectetur adipiscing elit. Duis rhoncus ligula nec dignissim pharetra. Maecenas laoreet tortor tellus, rhoncus vestibulum nisi sagittis ut.' }
];