import { Injectable } from '@angular/core';

@Injectable()
export class PrintService {


    printFile(innerContents: string, productOrMedicalDocFlag: string) {
        let popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
        popupWinindow.document.open();
        if (productOrMedicalDocFlag == "productList") {
            popupWinindow.document.write('<html><head><style></style> </head><body onload="window.print()">' + innerContents + '</html>');
        } else if (productOrMedicalDocFlag == "medicalDocument") {
            popupWinindow.document.write('<html><head><style>@media print{.view-doc-wrapper{width: 400px;margin: 0 auto;display: block;} modal-cont{font-weight: 600;color: #505050;} input.txt-box {width: 40px;padding: 0 5px;text-align: center;color: #aaa;}.spacing-txtbox{color: #aaa;margin-left: 7px;}textarea.txt-area{width: 100%;    resize: none;padding: 6px;text-align: left;}.view-area{border: 2px solid #aaa;text-align: left;padding: 20px 30px;} .medi-span{text-transform: uppercase; font-size: 13px;} .medi-spanDate{float:right;}} @media screen{.view-doc-wrapper{width: 400px;margin: 0 auto;display: block;} modal-cont{font-weight: 600;color: #505050;} input.txt-box {width: 40px;padding: 0 5px;text-align: center;color: #aaa;}.spacing-txtbox{color: #aaa;margin-left: 7px;}textarea.txt-area{width: 100%;    resize: none;padding: 6px;text-align: left;}.view-area{border: 2px solid #aaa;text-align: left;padding: 20px 30px;} .medi-span{text-transform: uppercase; font-size: 13px;} .medi-spanDate{float:right;}}</style> </head><body onload="window.print()">' + innerContents + '</html>');
        } else if (productOrMedicalDocFlag == "medicalDocumentprint"){



            popupWinindow.document.write('<html><head><style>@media print{.container-wrapper{padding: 2%; .inner-header{padding: 0 0 15px 10px; margin-top: 0; border-bottom: 1px solid #000; margin-bottom: 20px; font-size: 22px; text-transform: uppercase;  font-weight: 600; } .cancel-btn{padding: 2px 10px;  font-size: 10px; line-height: normal; vertical-align: middle;}} .personalinfo{height: 435px; padding: 1%; .pesonal-infolabel{font-size: 12px; } .label-color{color: red;} .label-info-Center{margin-left: 15px;} .info-center-select{width: 200px; border-radius: 5px !important; } .inner-heading-margin-top{margin-top: 17px; } .margin-left-button{margin-left: 2px; } .profile-btn-group{text-align: center; margin-top: 15px; button{padding: 2px 10px; font-size: 10px; line-height: normal; vertical-align: middle; } } .register-date{.mydp{width: 100% !important; } } .personal-info-container{margin-bottom: 20px; } .mydp .inputnoteditable, .mydp .monthlabel, .mydp .yearlabel{font-family:"Helvetica Neue", Helvetica !important}}</style> </head><body onload="window.print()">' + innerContents + '</html>');


        } else {
            popupWinindow.document.write('<html><head><style>@media print{ img{display: block;margin: auto;width: 50%;} } @media screen{ img{display: block;margin: auto;width: 50%;} }</style> </head><body onload="window.print()">' + innerContents + '</html>');
        }
        popupWinindow.document.close();
    }
}