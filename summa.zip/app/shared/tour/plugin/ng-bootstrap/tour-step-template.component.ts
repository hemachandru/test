import { TourService } from '../../tour.service';
import { TourStepTemplateService } from './tour-step-template.service';
import { Component, TemplateRef, ViewChild, AfterViewInit, ViewEncapsulation } from '@angular/core';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'tour-step-template',
  styleUrls: ['./style.css'],
  template: `<template #tourStep let-step="step">
              <p class="tour-step-title">{{step?.title}}</p>
              <p class="tour-step-content" 
              [ngClass]="{'last_msg': !tourService.hasNext(step) }">
                {{step?.content}}
              </p>             
             </template>
             <div class="tour-step-navigation">
                <button *ngIf="tourService.isTourOn()" class="btn btn-sm btn-default btn-left" (click)="tourService.prev()"></button>
                <button *ngIf="tourService.isTourOn()" class="btn btn-sm btn-default btn-right" (click)="tourService.next()"></button>
             </div>
             <div *ngIf="(tourService.isTourOn() && tourService.isMobileView() && !tourService.isSlider()) 
             || (tourService.isTourOn() && !tourService.isMobileView()) " class="backdrop"></div>`,
})
export class TourStepTemplateComponent implements AfterViewInit {
  @ViewChild('tourStep', { read: TemplateRef }) public tourStepTemplate: TemplateRef<any>;

  constructor(private tourStepTemplateService: TourStepTemplateService, public tourService: TourService) {}

  public ngAfterViewInit(): void {
    this.tourStepTemplateService.template = this.tourStepTemplate;
  }
}

// *ngIf="tourService.hasNext(step)" [ngClass]="{'last_msg': !tourService.hasNext(step) }"
// <div tourAnchor="config.route" class="last_msg"></div>  