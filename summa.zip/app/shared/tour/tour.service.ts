import { Hotkey, HotkeysService } from 'angular2-hotkeys';
import { TourAnchorDirective } from './tour-anchor.directive';
import { IStepOption } from './tour.service';
import { Injectable,Output,EventEmitter } from '@angular/core';
import { Router, UrlSegment } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { mergeStatic } from 'rxjs/operator/merge';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import { map } from 'rxjs/operator/map';


export interface IStepOption {
  stepId?: string;
  anchorId?: string;
  title?: string;
  content?: string;
  route?: string | UrlSegment[];
  nextStep?: number | string;
  prevStep?: number | string;
  placement?: 'above' | 'below' | 'after' | 'before' | 'left' | 'right';
  preventScrolling?: boolean;
}

export interface backdropOption {
  backdrop?: boolean;
}

export enum TourState {
  OFF,
  ON,
  PAUSED,
}

@Injectable()
export class TourService {

  public showbackDrop$: Subject<backdropOption> = new Subject();
  public stepShow$: Subject<IStepOption> = new Subject();
  public stepHide$: Subject<IStepOption> = new Subject();
  public initialize$: Subject<IStepOption[]> = new Subject();
  public start$: Subject<IStepOption> = new Subject();
  public end$: Subject<any> = new Subject();
  public pause$: Subject<IStepOption> = new Subject();
  public resume$: Subject<IStepOption> = new Subject();
  public anchorRegister$: Subject<string> = new Subject();
  public anchorUnregister$: Subject<string> = new Subject();
  public events$: Observable<{ name: string, value: any }> = mergeStatic(
    map.bind(this.showbackDrop$)((value: any) => ({ name: 'showbackDrop', value })),
    map.bind(this.stepShow$)((value: any) => ({ name: 'stepShow', value })),
    map.bind(this.stepHide$)((value: any) => ({ name: 'stepHide', value })),
    map.bind(this.initialize$)((value: any) => ({ name: 'initialize', value })),
    map.bind(this.start$)((value: any) => ({ name: 'start', value })),
    map.bind(this.end$)((value: any) => ({ name: 'end', value })),
    map.bind(this.pause$)((value: any) => ({ name: 'pause', value })),
    map.bind(this.resume$)((value: any) => ({ name: 'resume', value })),
    map.bind(this.anchorRegister$)((value: any) => ({ name: 'anchorRegister', value })),
    map.bind(this.anchorUnregister$)((value: any) => ({ name: 'anchorUnregister', value })),
  );

  //To broadcasding current step to parant component
  public currentSteps_Broadcase: BehaviorSubject<IStepOption> = new BehaviorSubject<IStepOption>(0);
  public previousCallback: Subject<any> = new Subject();
  public nextCallback: Subject<any> = new Subject();
  public steps: IStepOption[];
  public currentStep: IStepOption;

  public anchors: { [anchorId: string]: TourAnchorDirective } = {};
  private status: TourState = TourState.OFF;
  private hotkeys: Hotkey[] = [new Hotkey(
    'esc',
    event => {
      this.end();
      return true;
    },
  ), new Hotkey(
    'right',
    event => {
      if (this.hasNext(this.currentStep)) {
        this.next();
      }
      return true;
    },
  ), new Hotkey(
    'left',
    event => {
      if (this.hasPrev(this.currentStep)) {
        this.prev();
      }
      return true;
    },
  )];

  constructor(private router: Router, private hotkeyService: HotkeysService) { }

  public initialize(steps: IStepOption[], stepDefaults?: IStepOption): void {
    if (steps && steps.length > 0) {
      this.steps = steps.map(step => Object.assign({}, stepDefaults, step));
      this.initialize$.next(steps);
      this.status = TourState.OFF;
    }
  }

  public isTourOn():boolean{
    if(this.status === 1){ return true} 
    return false;
  }

  public isMobileView():boolean{
    if(window.screen.width <= 991){
       return true;
    }
    return false;
  }

  public isSumalMobileView():number{
    if(window.screen.width <= 525 && this.isSlider() ){
       return -1;
    }
    return 1000;
  }

  public isSlider():boolean{
    if(this.currentStep != undefined){
       if(0 < parseInt(this.currentStep.stepId) && parseInt(this.currentStep.stepId) < 9){
        return true;
       }
    }
    return false;
  }

  public currentstep(): IStepOption {
    return this.currentStep;
  }

 public hasNextfortemp(){
    return this.currentStep !== undefined || this.steps.indexOf(this.currentStep) < this.steps.length - 1;
  }

  public start(): void {
    this.startAt(0);
  }

  public startAt(stepId: number | string): void {
    this.goToStep(this.loadStep(stepId));
    this.start$.next();
    this.status = TourState.ON;
    this.setHotkeys();
  }

  public end(): void {
    this.status = TourState.OFF;
    this.hideStep(this.currentStep);
    this.currentStep = undefined;
    this.end$.next();
    this.removeHotkeys();
    this.currentSteps_Broadcase.next(false);
  }

  public pause(): void {
    this.hideStep(this.currentStep);
    this.pause$.next();
    this.status = TourState.PAUSED;
    this.setHotkeys();
  }

  public resume(): void {
    this.showStep(this.currentStep);
    this.resume$.next();
    this.status = TourState.ON;
    this.removeHotkeys();
  }

  public toggle(pause?: boolean): void {
    if (pause) {
      if (this.currentStep) {
        this.pause();
      } else {
        this.resume();
      }
    } else {
      if (this.currentStep) {
        this.end();
      } else {
        this.start();
      }
    }
  }

  public next(): void {
    this.goToStep(this.loadStep(this.currentStep.nextStep || this.steps.indexOf(this.currentStep) + 1));
  }

  public hasNext(step: IStepOption): boolean {
    return step.nextStep !== undefined || this.steps.indexOf(step) < this.steps.length - 1;
  }

  public prev(): void {
    if(this.steps.indexOf(this.currentStep) > 0){
      this.previousCallback.next(false);
      this.goToStep(this.loadStep(this.currentStep.prevStep || this.steps.indexOf(this.currentStep) - 1));
    }else{
      this.previousCallback.next(true);
      this.end();
    }
  }

  public hasPrev(step: IStepOption): boolean {
    if(this.steps.indexOf(step) < (this.steps.length - 1)){
      return step.prevStep !== undefined || this.steps.indexOf(step) > 0;
    }else{
      this.end();
    }
  }

  public goto(stepId: number | string): void {
    this.goToStep(this.loadStep(stepId));
  }

  //register all anchor tags
  public register(anchorId: string, anchor: TourAnchorDirective): void {
    try{
      if (!this.anchors[anchorId]) {
        this.anchors[anchorId] = anchor;
        this.anchorRegister$.next(anchorId);
      }
    }catch(e){
      console.log("Catched exception in register method in tour service",e);
    }
  }

  public unregister(anchorId: string): void {
    delete this.anchors[anchorId];
    this.anchorUnregister$.next(anchorId);
  }

  /**
   * Configures hot keys for controlling the tour with the keyboard
   */
  private setHotkeys(): void {
    this.hotkeyService.add(this.hotkeys);
  }

  private removeHotkeys(): void {
    this.hotkeyService.remove(this.hotkeys);
  }

  private goToStep(step: IStepOption): void {
    if (!step) {
      this.nextCallback.next(true);
      this.end();
      return;
    }
    this.nextCallback.next(false);
    let navigatePromise: Promise<boolean> = new Promise(resolve => resolve(true));
    if (step.route !== undefined && typeof (step.route) === 'string') {
      navigatePromise = this.router.navigateByUrl(step.route);
    } else if (step.route && Array.isArray(step.route)) {
      navigatePromise = this.router.navigate(step.route);
    }
    navigatePromise.then(navigated => {
      if (navigated !== false) {
        this.setCurrentStep(step);
      }
    });

  }

  private loadStep(stepId: number | string): IStepOption {
    if (typeof (stepId) === 'number') {
      return this.steps[stepId];
    } else {
      return this.steps.find(step => step.stepId === stepId);
    }
  }

  private setCurrentStep(step: IStepOption): void {
    if (this.currentStep) {
      this.hideStep(this.currentStep);
    }
    this.currentStep = step;
    this.showStep(this.currentStep);
  }

  private showStep(step: IStepOption): void {
    const anchor = this.anchors[step.anchorId];
    if (!anchor) {
       this.end();
      return;
    }
    this.currentSteps_Broadcase.next(step);
    anchor.showTourStep(step);
    this.stepShow$.next(step);
  }

  private hideStep(step: IStepOption): void {
    const anchor = this.anchors[step.anchorId];
    if (!anchor) {
      return;
    }
    anchor.hideTourStep();
    this.stepHide$.next(step);
  }
}