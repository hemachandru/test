import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptionsArgs, RequestOptions, URLSearchParams, RequestMethod, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { Config } from '../../config/constant';

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    private getAuthorizationCode = true;
    public APIKey: string;
    constructor(private config: Config, private http: Http, private router: Router) {
        this.headers = new Headers();
    }

    /**
     * GET Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequestWithoutToken(url: string) {
        this.headers = new Headers();
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.get(self.config.getBaseURL() + url, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);
    }

    /**
     * POST Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequestWithoutToken(data: string, url: string) {
        this.headers = new Headers();
        this.headers.set('Content-Type', 'application/x-www-form-urlencoded');
        var self = this;
        return self.http.post(self.config.getBaseURL() + url, data, {
            headers: self.headers
        });
    }

    /**
     * PUT Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUt request with data.
     * 
     * @return {Observable}
     */
    putHttpRequestWithoutToken(data: string, url: string) {
        this.headers = new Headers();
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.put(self.config.getBaseURL() + url, data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);

    }
    /**
     * GET Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */

    public getHttpRequest(url: string, formurl?: boolean, headers?: string[], search?: URLSearchParams) {

        this.headers = new Headers();
        let requestHeaders:any;

        if (headers != null) {
            for (var index = 0; index < headers.length; index++) {
                this.headers.set(headers[index], headers[index + 1]);
                index++;
            }
            requestHeaders = this.headers;
        }

        let finalURL = (formurl ? this.config.GetForms() + url : this.config.getBaseURL() + url);
        
        return this.request(finalURL, { method: RequestMethod.Get },null,null,requestHeaders)
            .map((response: Response) => response);
    }

    /**
     * This service only for documentDownload Part.
     * @param url 
     * @param search 
     */
    public getHttpDocumentDownload(url: string, search?: URLSearchParams) {
        this.headers = new Headers();
        return this.request(this.config.getBaseURL() + url, { method: RequestMethod.Get }, "", "blob")
            .map((response: Response) => response);
    }

    /**
     * POST Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */

    public postHttpRequest(data: string, url: string) {
        this.headers = new Headers();
        return this.request(this.config.getBaseURL() + url, { method: RequestMethod.Post }, data)
            .map((response: Response) => response);
    }

    /**
    * PUT Http Request with token 
    * Common service to handle PUT Http Request
    * 
    * @param {string} url - PUT request with end point URL.
    * @param {string} data - PUT request with data.
    * 
    * @return {Observable}
    */

    public putHttpRequest(data: string, url: string) {
        this.headers = new Headers();
        return this.request(this.config.getBaseURL() + url, { method: RequestMethod.Put }, data)
            .map((response: Response) => response);
    }

    /**
     * PUT Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUT request with data.
     * 
     * @return {Observable}
     */
    public putHttpWithoutData(url: string, data: any) {
        this.headers = new Headers();
        return this.request(this.config.getBaseURL() + url, { method: RequestMethod.Put }, data)
            .map((response: Response) => response);
    }

    private request(url: string, options: RequestOptionsArgs, data?: Object, contentTypeOnOff?: string, presetHeaders?: Headers): Observable<Response> 
    {
        options.headers = new Headers();

        if(presetHeaders != null){
            options.headers = presetHeaders;
        }
        else{
            options.headers.append("Authorization", 'Bearer ' + localStorage.getItem("token"));
        }
        
        if ((options.method === RequestMethod.Post || options.method === RequestMethod.Put) && contentTypeOnOff === undefined) {
            options.headers.append("Content-Type", "application/json");
        } else if (options.method === RequestMethod.Get && contentTypeOnOff === "blob") {
            options.responseType = ResponseContentType.Blob;
        }
        if (data) {
            options.body = data;
        }

        // TODO write specs for the refresh logic
        // TODO refactor
        return this.http.request(url, options).catch((error: any) => {
            /**
             * During exception occur check status is 401 then authorization code is expired,so using refresh token regenerate new authorization code then re call the failed service 
             * load the webpage.
             */
            if (error.status === 401) {
                if (this.getAuthorizationCode) {
                    this.getAuthorizationCode = false;
                    let urls: string = url;
                    options.headers = new Headers();
                    options.headers.append("Authorization", 'Bearer ' + localStorage.getItem("token"));

                    if ((options.method === RequestMethod.Post || options.method === RequestMethod.Put) && contentTypeOnOff === undefined) {
                        options.headers.append("Content-Type", "application/json");
                    } else if (options.method === RequestMethod.Get && contentTypeOnOff === "blob") {
                        options.responseType = ResponseContentType.Blob;
                    }

                    if (data) {
                        options.body = data;
                    }
                    let opionsData: RequestOptionsArgs = options;
                    let newData: string = JSON.stringify(data);
                    let contentTypeOnOffDetail: string = JSON.stringify(data);
                    var body = 'grant_type=' + encodeURIComponent(this.config.grant_RefreshTokenType) + '&client_id=' + encodeURIComponent(this.config.Client_Id)
                        + '&refresh_token=' + encodeURIComponent(localStorage.getItem('refresh_token'));

                    return this.postHttpRequestWithoutToken(body, 'api/token').flatMap((response: any) => {
                        let dataValue = response.json();
                        localStorage.setItem('token', dataValue.access_token);
                        localStorage.setItem('refresh_token', dataValue.refresh_token);
                        this.getAuthorizationCode = true;
                        return this.request(urls, opionsData, newData, contentTypeOnOffDetail);
                    }).catch((err: any) => {
                        if (err.status == 400) {
                            sessionStorage.clear();
                            localStorage.clear();
                            this.router.navigate(["portal-login"])
                            return Observable.empty();
                        }
                    });
                } else {
                    return this.request(url, options, data, contentTypeOnOff);
                }
            } else {
                return Observable.throw(error);
            }
        });
    }

    /**
     * errorResponse 
     * Common method to handle error response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private errorResponse(error: Response) {

        return Observable.throw(error.json() || null);
    }

    /**
     * successResponse 
     * Common method to handle success response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private successResponse(result: Response) {
        return result.json() || null;
    }

    /**
     * this service get the new Authorization code using  refresh token during current authorization expired.
     * @param url 
     */
    getHttpRequestForAuth(url: string) {
        this.headers = new Headers();
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.get(self.config.getBaseURL() + url, {
            headers: self.headers
        });
    }

    /**
     * this request use only for upload file.
     * @param data 
     * @param url 
     */
    public postHttpRequest_Upload_Doc_Image(data: any, url: string) {
        this.headers = new Headers();
        return this.request(this.config.getBaseURL() + url, { method: RequestMethod.Post }, data, "uploadImage")
            .map((response: Response) => response);
    }
}