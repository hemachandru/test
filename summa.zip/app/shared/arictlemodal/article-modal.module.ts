import { NgModule }       from '@angular/core';
import { CommonModule }       from '@angular/common';

import { ArticleModalComponent } from './article-modal.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ArticleModalComponent
  ],
  providers: [ ],
  exports: [ ArticleModalComponent ]
})
export class ArticleModalModule {}