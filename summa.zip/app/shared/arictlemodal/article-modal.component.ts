import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
  selector: 'article-modal',
  templateUrl: './article-modal.component.html'
})
export class ArticleModalComponent implements OnInit, CloseGuard{

  dialog: DialogRef<any>;

  @Input() options: any;  

  @ViewChild('infoCentreRef') public infoCentreRef: TemplateRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() { }

  /**
   * Generic function to show additional information while clicking icon
   * 
   * @param {Number} id in which info need to show while clicking 
   */
  onClick(event: Event) {
      this.modal.open(this.infoCentreRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-infocentre-cls' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      })
  }
  close() {
    this.dialog.close();
  }
}