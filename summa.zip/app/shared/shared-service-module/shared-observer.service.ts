import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SharedObserverService {
    private sharedObserver = new BehaviorSubject(true);
    private sharedInfoObserver = new BehaviorSubject(true);
    private individualPatientObserver = new BehaviorSubject(true);
    public eventReceiver$: Observable<any>;
    public profileEventReceiver$: Observable<any>;
    public individualPatientReceiver$: Observable<any>;

    constructor() { 
        this.eventReceiver$ = this.sharedObserver.asObservable();
        this.profileEventReceiver$ = this.sharedInfoObserver.asObservable();
        this.individualPatientReceiver$ = this.individualPatientObserver.asObservable();
    }

    sendEventToSubscriber(event: any) {
        this.sharedObserver.next(event);
    }

    sendProfileInfoToSubsciber(event: any) {
        this.sharedInfoObserver.next(event);
    }

    sendindividualPatientSubscriber(individualPatientData: any){
     this.individualPatientObserver.next(individualPatientData);
    }
}