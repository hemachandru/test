import { NgModule, ModuleWithProviders } from '@angular/core';

import { SharedObserverService } from './shared-observer.service';
import { LoaderService } from '../shared-loader/shared-loader.service';

@NgModule({})
export class SharedServiceModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedServiceModule,
            providers: [
                SharedObserverService, 
                LoaderService
            ]
        };
    }
}
