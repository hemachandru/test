import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector: 'circluar-info',
    templateUrl: './circular-info.component.html',
    styleUrls: ['./circular-info.component.scss']
})

export class CircularInfoComponent {

    @Input() btnName: string;
    @Input() listObj: any;

    @Output() onBtnClick = new EventEmitter();

    constructor() {
        
    }

    onClick(event: any) {
        this.onBtnClick.emit(event);
    }
}