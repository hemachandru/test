export interface AppListEntity {
    id: number;
    f_name: string;
    l_name: string;
    dateandtime: string;
    reason: string;
    apptype: string;
}
export interface UpdateAppList {
    Consultation_Request_Id: number;
    Consultation_Status_Id: number;
    Declined_Notes: string;

}