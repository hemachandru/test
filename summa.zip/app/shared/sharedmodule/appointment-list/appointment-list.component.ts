import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import { Component, EventEmitter, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, ElementRef, Renderer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { PlatformLocation } from '@angular/common';

import { ClinicService } from "../../../modules/clinic/service/clinic.service";
import { ClinicBusiness } from "../../../modules/clinic/business/clinic.business";
import { HttpRequestService } from '../../shared-service/http-request.service';
import { LoaderService } from '../../shared-loader/shared-loader.service';
import { SharedObserverService } from '../../shared-service-module/shared-observer.service';
import { Config } from "../../../config/constant";
import { AppListEntity, UpdateAppList } from './entity/applist-entity';

@Component({
	selector: 'appointmentrequest-list',
	templateUrl: './appointment-list.component.html',
	styleUrls: ['./appointment-list.component.scss']
})

export class AppointmentRequestListComponent implements OnInit {
	@ViewChild('viewStrainInfo') public viewStrainInfo: TemplateRef<any>;
	@ViewChild('declineRequest') public declineRequest: TemplateRef<any>; 
	dialog: DialogRef<any>;
	@Input() lists: AppListEntity[];
	@Output() onCloseClick = new EventEmitter();
	data: UpdateAppList;
	constructor(private config: Config, private completerService: CompleterService, private router: Router, private renderer: Renderer, private _cb: ClinicBusiness, private _cs: ClinicService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _ls: LoaderService, private _sos: SharedObserverService, private location: PlatformLocation) {
		overlay.defaultViewContainer = vcRef;
	}

	ngOnInit() { }

	onAccept(applist_id: any, event: any) {
		var target = event.target || event.srcElement || event.currentTarget;
		var idAttr = target.attributes.id;
		this.data = {
			Consultation_Request_Id: applist_id,
			Consultation_Status_Id: idAttr.nodeValue,
			Declined_Notes: ""
		}
		this._cb.updateRequests(this.data).subscribe(res => { })
		return this.modal.open(this.viewStrainInfo, overlayConfigFactory({ dialogClass: 'modal-dialog modal-center' }, BSModalContext)).then(dialog => {
			this.dialog = dialog;
			//this.close();
		});
	}
	onDecline(applist_id: any, event: any) {
		var target = event.target || event.srcElement || event.currentTarget;
		var idAttr = target.attributes.id;
		this.data = {
			Consultation_Request_Id: applist_id,
			Consultation_Status_Id: idAttr.nodeValue,
			Declined_Notes: ""
		}
		this._cb.updateRequests(this.data).subscribe(res => { })
		return this.modal.open(this.declineRequest, overlayConfigFactory({ dialogClass: 'modal-dialog modal-center' }, BSModalContext)).then(dialog => {
			this.dialog = dialog;
			//this.close();
		});
	}
	viewAppoinment() {
		this.dialog.close();
		this.router.navigate(['/profile/patient-view']);
	}
	dialogClosed(event: any) {
		this.onCloseClick.emit(event);
		this.dialog.close();
	}

}
