import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
//import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
//import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
//import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
//import { EditEntity } from '../supplier-entity/edit.entity';

export interface EditEntity {
    uname: string,
    password: string,
    confirmpassword: string,
    clinicname: string,
    description: string,
    website: string,
    cliniclogo: any,
    address: string,
    town: string,
    postal: string,
    country: string,
    phone: string,
    fax: string,
    fname: string,
    lname: string,
    email: string
}

@Component({
    selector: 'admin-info-form',
    templateUrl: './admin-info.component.html',
    styleUrls: ['./admin-info.component.scss']
})
export class AdminInfoFormComponent implements OnInit {
    //editvalues: EditEntity;
    // @ViewChild('successsave') public successsave: TemplateRef<any>;
    // @ViewChild('fileInput') public myFileInput: ElementRef;
    // dialog: DialogRef<any>;
    @Input() value: EditEntity;

    @Output() onSaveClick = new EventEmitter();
    @Output() onCancelClick = new EventEmitter();
    @Output() onFileChange = new EventEmitter();

    change = false;
    cliniclogo: any;
    constructor() {
        this.value = {
            uname: '',
            password: '',
            confirmpassword: '',
            clinicname: '',
            description: '',
            website: '',
            cliniclogo: '',
            address: '',
            town: '',
            postal: '',
            country: 'CANADA',
            phone: '',
            fax: '',
            fname: '',
            lname: '',
            email: ''
        }
    }
    ngOnInit() {
        
    }
    onChange(event: any) {
        if (event.target.files && event.target.files[0]) {
            let file = event.target.files[0] || event.target.files;
            this.onFileChange.emit(file);
        }
    }
    onCancel(event: Event) {
        //this.router.navigate(['/suppliers/add-supplier']);
        this.onCancelClick.emit(event);
        console.log(event);
    }
    onSave(value: any) {
        // return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
        //     .then(dialog => {
        //         this.dialog = dialog;
        //     })
        this.onSaveClick.emit(value);
    }
    // onClose() {
    //     this.dialog.close();
    // }
}
