export interface DocumentListEntity {
    id: number;
    f_name: string;
    f_date: string;
    author: string;
    isDeletable: boolean;
}