import { Component, OnInit, Inject, TemplateRef, Input, Output, EventEmitter, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { DocumentListEntity } from './entity/document.entity';

@Component({
    selector: 'list-medical',
    templateUrl: './document.component.html',
    styleUrls: ['./document.component.scss']
})

export class DocumentComponent {

    @Input() lists: DocumentListEntity[];
    @Output() onOpenDocument = new EventEmitter();

    constructor() {

    }
    onDocument(docID: number) {
        this.onOpenDocument.emit(docID);
    }
}