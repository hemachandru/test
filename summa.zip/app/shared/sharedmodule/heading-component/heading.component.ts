import { Component, Input, OnInit, ElementRef } from '@angular/core';
@Component({
    selector: "app-heading",
    template: `
           <h1 class="app-header">{{heading}}</h1>
    `,
    styles: [`
        .app-header {
            font-size: 22px;
            font-weight: 600;
            margin: 0;
            padding: 0 0 15px 10px;
            min-height: 0;
            border-bottom: 1px solid #000;
            margin-bottom: 15px !important;
            text-transform: uppercase;
        }
    `]
})

export class HeadingComponent implements OnInit {
    @Input() heading: any;
    ngOnInit() {

    }
}