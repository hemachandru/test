import { Component, Input, Output, EventEmitter } from "@angular/core";
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
    selector: 'list-layout',
    templateUrl: './listing-layout.component.html',
    styleUrls: ['./listing-layout.component.scss']
})

export class ListingLayout {
    @Input() circleInfoBtnName: string;
    @Input() btnName: string;
    @Input() listObject: any;
    @Output() onBtnClick = new EventEmitter();
    @Output() onCircleBtnClick = new EventEmitter();

    options: ISlimScrollOptions;

    constructor() {
        this.options = {
            position: 'right',
            barBackground: '#4f4f4f',
            gridBackground: '#b6b6b6',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        };
    }
    /**
     * Add button click event
     * @param event 
     */
    onButtonClick(event: Event) {
        this.onBtnClick.emit(event);
    }

    onCircleBtn(event: Event) {
        this.onCircleBtnClick.emit(event);

    }
}