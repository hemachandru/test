import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Http, Response, Headers } from '@angular/http';
import { SlimScrollModule } from 'ng2-slimscroll';

import { ListingLayout } from "./listing-layout.component";
import { CircularInfoComponent } from "./circular-info.component";
import { HeadingComponent } from "./heading-component/heading.component";
import { UpdateComponent } from "./update-component/update-component";
import { AddClinicComponent } from "./add-clinic/add-clinic.component";
import { DocumentComponent } from './document/document.component';
import { AdminInfoFormComponent } from "./admin-info/admin-info.component";
import { LayoutComponent } from "../../modules/layout/component/layout.component";
import { AppointmentRequestListComponent } from "./appointment-list/appointment-list.component";
@NgModule({
    imports: [
        CommonModule,
        SlimScrollModule,
        FormsModule
    ],
    declarations: [
        ListingLayout,
        CircularInfoComponent,
        HeadingComponent,
        UpdateComponent,
        AddClinicComponent,
        DocumentComponent,
        AdminInfoFormComponent,
        AppointmentRequestListComponent
    ],
    providers: [],
    exports: [
        ListingLayout,
        CircularInfoComponent,
        HeadingComponent,
        UpdateComponent,
        AddClinicComponent,
        DocumentComponent,
        AdminInfoFormComponent,
        AppointmentRequestListComponent
    ]
})

export class SharedModule { }