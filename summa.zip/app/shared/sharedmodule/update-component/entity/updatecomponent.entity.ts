export interface UpdateProductName {
    strain: string
}