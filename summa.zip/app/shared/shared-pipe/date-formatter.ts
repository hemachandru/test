import {Pipe, PipeTransform} from '@angular/core';
import * as moment from "moment";
import { Config } from '../../config/constant';

@Pipe({
    name: 'customDate'
})

export class DateFormatter implements PipeTransform {
  formatDateOrTime :any;
  constructor(private config:Config){
  }
  transform(value: string, arg1:any): string {
   var arg=arg1?arg1:'';
   //this.formatDate = moment(value,arg).format('dddd MMMM Do, YYYY');
    if(arg == 'notRailwayTimeConvertion'){
     let  timeArr: any = value.split(':');
     var date = new Date().setHours(timeArr[0], timeArr[1], timeArr[2])
    }
    arg == 'timeConversion'? this.formatDateOrTime = moment(value).format('LT') : arg == 'notRailwayTimeConvertion'? this.formatDateOrTime = moment(date).format("hh:mm a") : this.formatDateOrTime = moment(value).format('MMM  Do, YYYY');

    return value ?this.formatDateOrTime == this.config.invalidDate? this.config.emptyDate  : this.formatDateOrTime  : this.config.emptyDate;
  }
} 

