import { NgModule }      from '@angular/core';
import { DateFormatter } from './date-formatter';

 @NgModule({
     imports:        [],
     declarations:   [DateFormatter],
     exports:        [DateFormatter],
 })

 export class PipeModule {

 } 