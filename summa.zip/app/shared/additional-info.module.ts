import { NgModule }       from '@angular/core';
import { CommonModule }       from '@angular/common';

import { AdditionalInfoComponent } from './additional-info.component'

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    AdditionalInfoComponent
  ],
  providers: [ ],
  exports: [ AdditionalInfoComponent ]
})
export class AdditionalInfoModule {}