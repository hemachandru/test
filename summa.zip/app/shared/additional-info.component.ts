import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
  selector: 'additional-info',
  //template: `<button (click)="onClick()">Alert</button>`
  templateUrl: './additional-info.component.html',
  styleUrls: ['./additional-info.component.scss']
})
export class AdditionalInfoComponent implements OnInit, CloseGuard{

  dialog: DialogRef<any>;

  @Input() info: string;
  @Input() color: string;

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() { }

  /**
   * Generic function to show additional information while clicking icon
   * 
   * @param {Number} id in which info need to show while clicking 
   */
  onClick(event: Event) {
    event.stopPropagation();
    event.preventDefault();
    if(this.info) {
      this.modal.open(this.templateRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      })
    }    
  }
  close() {
    this.dialog.close();
  }
}