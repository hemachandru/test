import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { Config } from '../config/constant';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class HttpRequestService {
    private headers: Headers;

    constructor(private http: Http, private config: Config) {
        this.headers = new Headers();
    }

    /**
     * GET Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequestWithoutToken(url: string) {
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.get(self.config.getBaseURL() + url, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);
    }

    /**
     * POST Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequestWithoutToken(data: string, url: string) {
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.post(self.config.getBaseURL() + url, data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);
    }

    /**
     * PUT Http Request without token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUt request with data.
     * 
     * @return {Observable}
     */
    putHttpRequestWithoutToken(data: string, url: string) {
        this.headers.set('Content-Type', 'application/json');
        var self = this;
        return self.http.put(self.config.getBaseURL() + url, data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);

    }
    /**
     * GET Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - Get request end point URL.
     * 
     * @return {Observable}
     */
    getHttpRequest(url: string) {
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.get(self.config.getBaseURL() + url, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);
    }

    /**
     * POST Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */
    postHttpRequest(data: string, url: string) {
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.post(self.config.getBaseURL() + url, data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);
    }

    /**
     * PUT Http Request with token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - PUT request with end point URL.
     * @param {string} data - PUT request with data.
     * 
     * @return {Observable}
     */
    putHttpRequest(data: string, url: string) {
        this.headers.set('Content-Type', 'application/json');
        this.headers.set('Authorization', 'Bearer ' + localStorage.getItem("token"));
        var self = this;
        return self.http.put(self.config.getBaseURL() + url, data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse);

    }

    /**
     * errorResponse 
     * Common method to handle error response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private errorResponse(error: Response) {
        return Observable.throw(error.json() || null);
    }

    /**
     * successResponse 
     * Common method to handle success response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private successResponse(result: Response) {
        return result.json() || null;
    }
}