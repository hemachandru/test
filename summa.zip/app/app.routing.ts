import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './service/auth-guard.service';
import { LayoutComponent } from './modules/layout/component/layout.component';
//import { LayoutModule } from './modules/layout/layout.module';
//import { LoginComponent } from './modules/account/component/login/login.component';
//import { RegisterComponent } from './modules/account/component/registration/register.component';
//import { ForgotpasswordComponent } from './modules/account/component/forgotpassword/forgotpassword.component';
//import { TermsComponent } from './modules/termsandconditions/component/terms.component';
import { PageNotFoundComponent } from './component/not-found.component';
import { LogoutComponent } from './modules/account/component/logout/logout.component';
import { SupportComponent } from './modules/support/component/support.component';
import { FormBuilderComponent } from './modules/formbuilder/formbuilder.component';
import { EmailPasswordLinkComponent } from './modules/account/component/emailpasswordlinkloader/emailpasswordlink.component';
import { ChangePasswordComponent } from './modules/account/component/resetpassword/resetpassword.component';
import { PortalLoginComponent } from './modules/account/component/portal-login/portal-login.component';
import { AppLoginComponent } from './modules/account/component/app-login/app-login.component';
import { PortalRegisterComponent } from './modules/account/component/portal-registration/portal-register.component';
import { AppRegisterComponent } from './modules/account/component/app-registration/app-register.component';

import { PortalForgotpasswordComponent } from './modules/account/component/portal-forgotpassword/portal-forgotpassword.component';
import { AppForgotpasswordComponent } from './modules/account/component/app-forgotpassword/app-forgotpassword.component';

export const routes: Routes = [
    {
        path: '',
        redirectTo: '/portal-login',
        pathMatch: 'full'
    },
   {
        path: 'portal-login',
        component: PortalLoginComponent
    },
    
    {
        path: 'portal-registration',
        component: PortalRegisterComponent
    },
   
    {
        path: 'portal-forgotpassword',
        component: PortalForgotpasswordComponent
    },
    

    {
        path: 'logout',
        component: LogoutComponent
    },
    {
        path: 'formbuilder',
        component: FormBuilderComponent
    },
    {
        path: 'support',
        component: SupportComponent,
        canActivate: [AuthGuard]
    },
    {
		path: 'emailpasswordlink/:uid/:id',
		component: EmailPasswordLinkComponent
	},
    {
		path: 'loginresetpassword',
		component: ChangePasswordComponent
	},
    {
        path: '',
        component: LayoutComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Home'
        },
        children: [
            {
                path: 'dashboard',
                loadChildren: './modules/dashboard/dashboard.module#DashboardModule',
                canActivateChild: [AuthGuard]
            },
            {
                path: 'appointment',
                loadChildren: './modules/clinic/clinic.module#ClinicModule',
            },
            {
                path: 'profile',
                loadChildren: './modules/user/user.module#UserModule',
                canActivateChild: [AuthGuard]
           
            },
            {
                path: 'clinics',
                loadChildren: './modules/clinic/clinic.module#ClinicModule',
            },
            {
                path: 'suppliers',
                loadChildren: './modules/drug/drug.module#DrugModule',
            },
            {
                path: 'record',
                loadChildren: './modules/record/record.module#RecordModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'strain-finder',
                loadChildren: './modules/drug/drug.module#DrugModule',
            },
            {
                path: 'info-center',
                loadChildren: './modules/article/article.module#ArticleModule',
            },
            {
                path: 'documents',
                loadChildren: './modules/record/record.module#RecordModule',
            },
            {
                path: 'messages',
                loadChildren: './modules/dashboard/messagenotification/messagenotification.module#MessageNotificationModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'lp-request',
                loadChildren: './modules/record/record.module#RecordModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'ordertracking',
                loadChildren: './modules/ordertracking/ordertracking.module#OrderTrackingModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'ordertracking/:id',
                loadChildren: './modules/ordertracking/ordertracking.module#OrderTrackingModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'clients',
                loadChildren: './modules/client/client.module#ClientModule',
                canActivateChild: [AuthGuard]

            },
            {
                path: 'client',
                loadChildren: './modules/client/client.module#ClientModule',
                
            },
            {
                path: 'addtag-superadmin',
                loadChildren: './modules/add-tag-super-admin/add-tag.module#AddTagModule',
            },
            {
                path: 'Adminreport',
                loadChildren: './modules/reports/report.module#AdminModule',
            }
        ]
    },
    { path: '**', component: PageNotFoundComponent }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }


