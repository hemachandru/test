import {Inject, Component } from '@angular/core';
import {Subscription} from 'rxjs';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, NavigationEnd,ActivatedRoute } from "@angular/router";
import '../assets/css/styles.scss';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  
  constructor(private router: Router,@Inject(DOCUMENT) private document: any) {
    console.log('calling...!');
    router.events.subscribe(e => {
    if(e instanceof NavigationEnd)
     var redirectUrl=e.url;
      if(localStorage.getItem('token')){
       redirectUrl == "/portal-login" ?  this.router.navigate(['dashboard']) :'';
    }
  });
  
  }     
}