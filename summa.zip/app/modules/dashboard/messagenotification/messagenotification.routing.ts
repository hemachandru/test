import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {MessageNotificationComponent} from './component/messagenotification.component';

const messagenotificationRoutes: Routes = [
  { path: '',  component: MessageNotificationComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(messagenotificationRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class MessageNotificationRoutingModule { }
