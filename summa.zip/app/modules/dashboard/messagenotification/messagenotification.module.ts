import { NgModule } from '@angular/core';

import { MessageNotificationComponent } from './component/messagenotification.component';
import { CommonModule } from '@angular/common';

import { MessageNotificationRoutingModule } from './messagenotification.routing';
import { PipeModule } from '../../../shared/shared-pipe/pipe.module';
import { LayoutComponent } from "../../layout/component/layout.component";

@NgModule({
  imports: [
    MessageNotificationRoutingModule,
    CommonModule,
    PipeModule
  ],
  declarations: [
    MessageNotificationComponent
  ],
  providers: []
})
export class MessageNotificationModule { }