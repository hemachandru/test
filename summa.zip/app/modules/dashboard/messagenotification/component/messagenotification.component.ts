import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { Dashboardbusiness } from '../../business/dashboard.business';
import { DashboardService } from '../../service/dashboard.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { LayoutComponent } from "../../../layout/component/layout.component";

@Component({
	templateUrl: './messagenotification.component.html',
	styleUrls: ['./messagenotification.component.scss'],

	providers: [Dashboardbusiness, DashboardService, Config, HttpRequestService, LoginBusiness, LoginService]
})

export class MessageNotificationComponent implements OnInit {

	constructor(private layoutComponent: LayoutComponent, private config: Config, private loginBusiness: LoginBusiness, private router: Router, private dashboardbusiness: Dashboardbusiness, private dashboardService: DashboardService, private httpRequestService: HttpRequestService) { }
	notificationData: any;
	individualNotificationData: any;
	showId = false;
	highlightedDiv: number;
	notificationDetail: any;
	removeColor: boolean = true;

	ngOnInit() {
		this.initService();
	}

	/* Toggle Div to show the message inbox */
	backtoinbox(data: any) {
		this.showId = false;
		this.notificationViewDetail();
		this.router.navigate(['/messages']);
	}

	/* Binding message to Description section*/
	showMessage(newValue: number, data: any, mobileView: boolean) {
		let readMessage = document.getElementById('notifitext' + newValue);
		this.highlightedDiv = newValue;
		this.individualNotificationData = data;
		mobileView ? this.showId = !this.showId : this.showId = false;
		if (!data.Msg_Read && readMessage.classList.contains('unread-message')) {
			this.layoutComponent.showSpinner(true);
			//Update notification status depends on message Id
			this.dashboardbusiness.updateNotificationMessageStatus(newValue).subscribe(response => {
				readMessage.classList.add('read-message');
				readMessage.classList.remove('unread-message');
            this.layoutComponent.showSpinner(false);
			}, (err) => {
				if (mobileView) {
					this.showId = false;
				}
				readMessage.classList.add('unread-message');
				readMessage.classList.remove('read-message');
				this.layoutComponent.showSpinner(false);
				console.log("MessageNotificationComponent dashboardbusiness updateNotificationMessageStatus error: ", err);

			});
		}
	}

	initService() {
		if (localStorage.getItem('token')) {
			this.notificationDetail = [];
			this.highlightedDiv = 1;
			this.notificationViewDetail();
		} else {
			this.layoutComponent.showSpinner(false);
			this.router.navigate(['portal-login']);
		}
	}

	notificationViewDetail() {
		//fetch the notiication detail
		this.layoutComponent.showSpinner(true);
		this.dashboardbusiness.getNotificationDetail().subscribe(response => {
			this.notificationDetail = response;
			this.individualNotificationData = this.notificationDetail[0];
			this.highlightedDiv=this.notificationDetail[0].Msg_Id;
			// if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
			 
			// }else{
			// //this.showMessage(this.individualNotificationData.Msg_Id,this.individualNotificationData,true);	
			// }
			this.layoutComponent.showSpinner(false);
		}, (err) => {
			this.layoutComponent.showSpinner(false);
			console.log("MessageNotificationComponent dashboardbusiness getNotificationDetail error: ", err);
		});
	}

}