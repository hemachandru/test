
import { ComponentFactory, ComponentRef, ComponentFactoryResolver, Injector, Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { PlatformLocation } from '@angular/common';
import { Subscription } from "rxjs/Subscription";

import { Dashboardbusiness } from '../business/dashboard.business';
import { DashboardService } from '../service/dashboard.service';
import { Config } from '../../../config/constant';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { RecordService } from '../../record/component/service/record.service';
import { RecordBusiness } from '../../record/component/business/record.business';
import { LoginBusiness } from '../../account/component/business/login.business';
import { LoginService } from '../../account/component/service/login.service';
import { TaskComponent } from "../../task/component/task.component";
import { LayoutComponent } from "../../layout/component/layout.component";
import { ProfileComplete } from "../entity/profilecomplete.entity";
import { SharedObserverService } from "../../../shared/shared-service-module/shared-observer.service";
import { MedicationComponent } from "./medication.component";
import { UserBusinessService } from '../../user/business/user.business';
import { ClinicBusiness } from "../../clinic/business/clinic.business";
import { OpenTokComponent } from "../../opentok/component/opentok.component";

export class UpcomingAppt {
  appt_date: string;
  appt_type: string;
  Appointment_Id: number;
  Clinic_Id: number;
  Provider_Id: number;
  Patient_Id: number;
  Provider_First_Name: string
}

@Component({
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],

  providers: [],

})

export class DashboardComponent implements OnInit, OnDestroy {

  //Complete-Profile-Start-
  public isUpcomingApptEmpty: boolean = false;
  public isUpcomingApptClinicEmpty: boolean = false;
  public accesstoLprequest: boolean;
  public lprequestzero: any = false;
  public lprequestseven: any = false;
  private webRTCObserver: Subscription;
  private apiKey: string;
  private sessionId: string;
  private token: string;
  public isPatientsUpdatesEmpty: boolean = false;

  public slideone = true;
  public slidetwo = false;
  public slidethree = false;
  public slidefour = false;
  public slideonebottom = true;
  public slidetwobottom = false;
  public slidethreebottom = false;
  public slidefourbottom = false;
  public slidebuttontwo = false;
  public slidesix = false;
  public slideheader = true;
  public progreebar = true;
  public slidelasttwo = false;
  public slidelastthree = false;
  public slidelastfour = false;
  public ValidCurrentUser: string;
  public userDetail: any = {};
  public unreadNotificationCount: number;
  public newPatientRequest: any;
  public notificationFlag: boolean = false;
  private intervalId: any;
  private clientUpdates: any;
  private individualClientUpdate: any;
  private expiryDate: string;
  public upcomingAppt: UpcomingAppt;
  public primaryPhoneNumber1: any = [];
  public completeProfileEntity: ProfileComplete;
  public masterInfoData: any;
  public medicalConditions: any;
  public medications: any;
  public medicationsDropDownNumber: any;
  public htmlContent: any = {};
  public medicationCurrentlyTakingVlaue: any;
  public medicationObject: any;
  public existingMedicalCodition: boolean = false;
  public previousCondition: string = '';
  public previoustherapiesCondition: string = '';
  public previoustherapiesConditionDesc: string = '';
  public previousConditionDesc: string = '';
  private tempMedicalConditions: any = [];
  private tempTherapieConditions: any = [];
  public previousConditionChecked: boolean = false;
  public previoustherapiesConditionChecked: boolean = false;
  public unSubscribeMaster: any = {};
  private tempMedicationDetail: any = [];
  public lpTrueFalseData: boolean;
  private completeProfileStatus: boolean = false;
  private isValidPrescription: boolean = false;
  public upcomingApptointments: any = [];
  public lpRequests: any = [];
  public patientpendingverfications: any = [];
  public PatientsUpdates: any = [];
  private patientupdatedetail: any;
  private videoConferenceId: number;
  private doctorName: string;
  private patientName: string;
  private showHideNoteUserProfile: boolean = false;
  public mask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
  // public connection = new RTCMultiConnection();
  private providerNote: string;
  private apptData: any;
  public tempValue: any = [];
  public btnlist: any = [];
  private isExpiryPrescription: boolean = false;
  private isUserConnected: boolean;
  private tempApptData: any;
  private content: string;
  private appointmentId: number;
  private videoCallStatusId: any;
  private providerName: string;
  public patientAddress: any;
  //patient
  highlightedDiv: number;
  public opts: ISlimScrollOptions;

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  @ViewChild('joinnowref') public joinnowref: TemplateRef<any>;
  @ViewChild('clientview') public clientview: TemplateRef<any>;
  @ViewChild('task') private task: TaskComponent;
  @ViewChild('patientview') public patientview: TemplateRef<any>;
  @ViewChild('joinnowpopup') public joinnowpopup: TemplateRef<any>;
  @ViewChild('lprequestpermission') public lprequestpermission: TemplateRef<any>;
  @ViewChild('alertRef') public alertRef: TemplateRef<any>;
  @ViewChild('appointmentPatientTemRef') public appointmentPatientTemRef: TemplateRef<any>;
  @ViewChild('appointmentEndedRef') public appointmentEndedRef: TemplateRef<any>;
  @ViewChild(OpenTokComponent) openTok: OpenTokComponent;

  dialog: DialogRef<any>;
  dialogAppt: DialogRef<any>;
  dialogApptEnd: DialogRef<any>;

  @ViewChild('toAddMedication', { read: ViewContainerRef }) toAddMedication: ViewContainerRef;
  private componentRef: ComponentRef<any>;

  constructor(private userBusinessService: UserBusinessService, private location: PlatformLocation, injector: Injector, private resolver: ComponentFactoryResolver, private sanitizer: DomSanitizer, private _sos: SharedObserverService, private layoutComponent: LayoutComponent, private config: Config, private loginBusiness: LoginBusiness, private recordBusiness: RecordBusiness, private httpRequestService: HttpRequestService, private dashboardService: DashboardService, private dashboardbusiness: Dashboardbusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _cb: ClinicBusiness) {
    overlay.defaultViewContainer = vcRef;
    this.isUserConnected = false;
  }

  ngOnInit() {
    this.upcomingAppt = {
      appt_date: '',
      appt_type: '',
      Appointment_Id: 0,
      Clinic_Id: 0,
      Provider_Id: 0,
      Patient_Id: 0,
      Provider_First_Name: ''
    }
    this.previousConditionChecked = false;
    this.previoustherapiesConditionChecked = false;
    this.completeProfileEntity = {
      primaryPhoneNumber: {},
      alternativePhoneNumber: {},
      height: '',
      weight: '',
      gender: '',
      existingOrPreviousCondition: [],
      medicalConditionSeeking: {},
      medicalTherapiesCondition: [],
      previoustherapiesCondition: '',
      previoustherapiesConditionDesc: '',
      previousCondition: '',
      previousConditionDesc: ''
    }
    this.initService();

    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

  }

  completeprofile(divparams: string): void {
    if (divparams == "slideone") {
      this.slideone = false;
      this.slidetwo = true;
      this.slideonebottom = false;
      this.slidetwobottom = true;
      this.slidethreebottom = false;
      this.slidefourbottom = false;
      this.slidebuttontwo = true;
      this.slidelasttwo = true;
      this.slidelastthree = false;
      this.slidelastfour = false;
    } else if (divparams == "slidetwo") {
      this.slideone = false;
      this.slidetwo = false;
      this.slidethree = true;
      this.slideonebottom = false;
      this.slidetwobottom = false;
      this.slidethreebottom = true;
      this.slidefourbottom = false;
      this.slidebuttontwo = true;
      this.slidelasttwo = false;
      this.slidelastthree = true;
      this.slidelastfour = false;
    }
    else if (divparams == "slidethree") {
      this.slideone = false;
      this.slidetwo = false;
      this.slidethree = false;
      this.slidefour = true;
      this.slideonebottom = false;
      this.slidetwobottom = false;
      this.slidethreebottom = false;
      this.slidefourbottom = true;
      this.slidebuttontwo = true;
      this.slidelasttwo = false;
      this.slidelastthree = false;
      this.slidelastfour = true;
    }
    else if (divparams == "slidefour") {
      this.slideone = false;
      this.slidetwo = false;
      this.slidethree = false;
      this.slidefour = false;
      this.slideonebottom = false;
      this.slidetwobottom = false;
      this.slidethreebottom = false;
      this.slidefourbottom = false;
      this.slidebuttontwo = false;
      this.slidesix = true;
      this.slideheader = false;
      this.progreebar = false;
      this.slidelasttwo = false;
      this.slidelastthree = false;
      this.slidelastfour = false;
    }

  }

  reverseslide(divparams: string): void {
    if (divparams == "slidelasttwo") {
      this.slideone = true;
      this.slidetwo = false;
      this.slidethree = false;
      this.slidefour = false;
      this.slideonebottom = true;
      this.slidetwobottom = false;
      this.slidethreebottom = false;
      this.slidefourbottom = false;
      this.slidebuttontwo = false;
      this.slidelasttwo = false;
      this.slidelastthree = false;
      this.slidelastfour = false;
    }
    if (divparams == "slidelastthree") {
      this.slideone = false;
      this.slidetwo = true;
      this.slidethree = false;
      this.slidefour = false;
      this.slideonebottom = false;
      this.slidetwobottom = false;
      this.slidethreebottom = true;
      this.slidefourbottom = false;
      this.slidebuttontwo = true;
      this.slidelasttwo = true;
      this.slidelastthree = false;
      this.slidelastfour = false;
    }
    if (divparams == "slidelastfour") {
      this.slideone = false;
      this.slidetwo = false;
      this.slidethree = true;
      this.slidefour = false;
      this.slideonebottom = false;
      this.slidetwobottom = false;
      this.slidethreebottom = true;
      this.slidefourbottom = false;
      this.slidebuttontwo = true;
      this.slidelasttwo = false;
      this.slidelastthree = true;
      this.slidelastfour = false;
    }
  }

  dashboardPopUp(individualClientUpdateDetail: any) {
    this.individualClientUpdate = [];
    this.individualClientUpdate = individualClientUpdateDetail;
    return this.modal.open(this.clientview, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dashboard-document model-dashboard' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      });
  }

  initService() {

    if (localStorage.getItem('token')) {
      this.layoutComponent.showSpinner(true);
      this.individualClientUpdate = [];
      this.newPatientRequest = [];
      this.clientUpdates = [];
      //fetch the user details
      this.dashboardbusiness.getUserDetail().subscribe(userData => {
        this.userDetail = userData;
        if (!userData.Is_User_Account_Locked && userData.Authenticated && userData.LP_Login_Data) {
          localStorage.setItem('currentUser', "LpUser");
        } else if (!userData.Is_User_Account_Locked && userData.Authenticated && userData.Patient_Login_Data) {
          localStorage.setItem('currentUser', "PatientUser");
        }
        this.ValidCurrentUser = localStorage.getItem('currentUser');

        localStorage.setItem('userRole', userData.User_Role);
        localStorage.setItem('client_id', this.config.Client_Id);

        if (this.ValidCurrentUser == "PatientUser") {
          localStorage.setItem('mvcUserId', userData.Patient_Login_Data.Patient_ID);
          localStorage.setItem('clinicId', '0');
          userData.Patient_Login_Data.Profile_Status == "Incomplete" ? this.completeProfileStatus = true : this.completeProfileStatus = false;
          //service return full master detail
          localStorage.setItem('userRatingValue', userData.Patient_Login_Data.UserExperienceRating);

          if (new Date(userData.Patient_Login_Data.MedDocExpiryDate).getTime() != this.config.minDateTime) {
            this.expiryDate = userData.Patient_Login_Data.MedDocExpiryDate;
            this.isValidPrescription = true;
          }

          this._sos.eventReceiver$.subscribe(res => {
            if (res != true) {
              this.masterInfoData = res;
              this.medicalConditions = res.MedicalConditions;
              this.medications = res.Medications;
              if (this.medicalConditions) {
                for (var index = 0; index < this.medicalConditions.length; index++) {
                  this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
                  this.tempTherapieConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
                }
              }
            }
          });


          // get client update details 
          this.recordBusiness.getClientUpdateDetail().subscribe(data => {
            this.clientUpdates = data;
          })
          this.task.loadTaskList();
        } else if (this.ValidCurrentUser == "LpUser") {
          localStorage.setItem('mvcUserId', userData.LP_Login_Data.LP_Id);
          localStorage.setItem('lpFirstName', userData.LP_Login_Data.LP_First_Name);
          localStorage.setItem('lpLastName', userData.LP_Login_Data.LP_Last_Name);
          localStorage.setItem('lpStoreName', userData.LP_Login_Data.Store_Name);
          localStorage.setItem('clinicId', '0');
          // get client update details 
          this.recordBusiness.getClientUpdateDetail().subscribe(data => {
            this.clientUpdates = data;
          })
          //Get the lastest client Update.
          this.recordBusiness.getAllMedicalDocumentByRange().subscribe(data => {
            this.newPatientRequest = data;
          })
        } else if (this.ValidCurrentUser == "ClinicsUser") {
          localStorage.setItem('mvcUser_Id', userData.Clinic_Login_Data.Clinic_ID);
          localStorage.setItem('mvcUserId', userData.Clinic_Login_Data.Clinic_ID);
          localStorage.setItem('clinicId', userData.Clinic_Login_Data.Clinic_ID);
          localStorage.setItem('clinic-clinic-Id', userData.Clinic_Login_Data.Clinic_ID);
          var premissionData = userData.Clinic_Login_Data.MVCUser_Permissions;
          var premissionData_array = premissionData.map((item: any) => {
            return item.MVCUser_Permission;
          })
          localStorage.setItem("premissionData_array", premissionData_array);
          localStorage.setItem('clinic_clinic_Id', userData.Clinic_Login_Data.Clinic_ID);
          this.task.loadTaskList();

        } else if (this.ValidCurrentUser == "DoctorUser") {
          localStorage.setItem('mvcUser_Id', userData.Provider_Login_Data.Provider_Id);
          localStorage.setItem('clinicId', userData.Provider_Login_Data.Clinic_Id);
          localStorage.setItem('mvcUserId', userData.Provider_Login_Data.Provider_Id);
          localStorage.setItem('clinicId', userData.Provider_Login_Data.Clinic_Id);
          var premissionData = userData.Provider_Login_Data.MVCUser_Permissions;
          var premissionData_array = premissionData.map((item: any) => {
            return item.MVCUser_Permission;
          })
          localStorage.setItem("premissionData_array", premissionData_array);
          localStorage.setItem('clinic_clinic_Id', userData.Provider_Login_Data.Clinic_ID);
          this.task.loadTaskList();

        } else if (this.ValidCurrentUser == "EducatorUser") {
          localStorage.setItem('mvcUser_Id', userData.Provider_Login_Data.Provider_Id);
          localStorage.setItem('clinicId', userData.Provider_Login_Data.Clinic_Id);
          localStorage.setItem('mvcUserId', userData.Provider_Login_Data.Provider_Id);
          localStorage.setItem('clinic-clinic-Id', userData.Provider_Login_Data.Clinic_Id);
          localStorage.setItem('Provider_First_Name', userData.Provider_Login_Data.Provider_First_Name);
          localStorage.setItem('Provider_Last_Name', userData.Provider_Login_Data.Provider_Last_Name);
          var premissionData = userData.Provider_Login_Data.MVCUser_Permissions;
          var premissionData_array = premissionData.map((item: any) => {
            return item.MVCUser_Permission;
          })
          localStorage.setItem("premissionData_array", premissionData_array);
          localStorage.setItem('clinic_clinic_Id', userData.Provider_Login_Data.Clinic_Id);
          this.task.loadTaskList();

        } else {
          this.ValidCurrentUser = "PatientUser";
        }

        Observable.forkJoin(
          //Get the getUnreadNotificationCount
          this.dashboardbusiness.getUnreadNotificationCount(userData),
        ).subscribe(data => {
          this.unreadNotificationCount = data[0].UnreadMessageCount;
          this.unreadNotificationCount > 0 ? this.notificationFlag = true : this.notificationFlag = false;
          this.layoutComponent.showSpinner(false);
          //here every 1 min call the getUnreadNotificationCount and update the unreaded notification value
          this.intervalId = setInterval(() => {
            this.dashboardbusiness.getUnreadNotificationCount(userData).subscribe(res => {

              this.unreadNotificationCount = res.UnreadMessageCount;
              this.unreadNotificationCount > 0 ? this.notificationFlag = true : this.notificationFlag = false;

            }, (err) => {
              this.layoutComponent.showSpinner(false);
              console.error("DashboardComponent dashboardbusiness getUnreadNotificationCount setInterval ", err);
              clearInterval(this.intervalId);
            })
          }, 1000 * 60 * 10);

        }, (err) => {
          this.layoutComponent.showSpinner(false);
          console.error("DashboardComponent Observable forkJoin ", err)
        });

        if (this.ValidCurrentUser == "PatientUser") {
          this.getUpcomingAppt(this.userDetail);
        }
        else if (this.ValidCurrentUser == "ClinicsUser" || this.ValidCurrentUser == "DoctorUser" || this.ValidCurrentUser == "EducatorUser") {
          this.getUpcomingApptclinics(this.userDetail);
          this.getlprequests();
          this.getPatientverfication();
          this.getPatientsUpdates();
        }

      }, (err) => {
        this.layoutComponent.showSpinner(false);
        if (err.status == 401) {
          localStorage.clear();
          this.router.navigate(['portal-login']);
        }
        console.error("DashboardComponent dashboardbusiness getUserDetail ", err)
      });
      if (localStorage.getItem('registerportal') && localStorage.getItem('registerportal') == 'true') {
        //during signup patient i set this in localStorage.
        localStorage.removeItem('registerportal');
        this.layoutComponent.beginInterview();
      }
    } else {
      this.layoutComponent.showSpinner(false);
      this.router.navigate(['portal-login']);
    }
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
    clearInterval(this.videoCallStatusId);
  }
  getUpcomingAppt(data: object) {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getUpcomingAppointments(data)
      .subscribe(res => {
        if (res.length > 0) {
          //let data = res.reverse();
          //this.upcomingAppt = data[0];

          this.upcomingAppt = {
            appt_date: res[0].Appointment_EndDate,
            appt_type: res[0].Appointment_Type,
            Appointment_Id: res[0].Appointment_Id,
            Clinic_Id: res[0].Clinic.Clinic_Id,
            Provider_Id: res[0].Provider_Id,
            Patient_Id: res[0].Patient_Id,
            Provider_First_Name: res[0].Provider_First_Name
          }
          this.isUpcomingApptEmpty = false;
        } else {
          this.isUpcomingApptEmpty = true;
        }
        this.layoutComponent.showSpinner(false);
      })

  }

  getUpcomingApptclinics(data: object) {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getUpcomingAppointments(data)
      .subscribe(res => {
        if (res.length > 0) {

          this.upcomingApptointments = res
          this.isUpcomingApptClinicEmpty = false;
        } else {
          this.isUpcomingApptClinicEmpty = true;
          console.log(this.isUpcomingApptClinicEmpty);
        }
        this.layoutComponent.showSpinner(false);
      })

  }

  getAllUpcomingApptClinics() {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getAllUpcomingOrPreviousAppointments()
      .subscribe(res => {
        if (res.length > 0) {

          this.upcomingApptointments = res
          this.isUpcomingApptClinicEmpty = false;
        } else {
          this.isUpcomingApptClinicEmpty = true;
          console.log(this.isUpcomingApptClinicEmpty);
        }
        this.layoutComponent.showSpinner(false);
      })
  }

  getlprequests() {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getLpRequests()
      .subscribe(res => {
        if (res.length > 0) {

          this.lpRequests = res
          this.isUpcomingApptEmpty = false;
        } else {
          this.isUpcomingApptEmpty = true;
          console.log(this.isUpcomingApptEmpty);
        }
        this.layoutComponent.showSpinner(false);
      })

  }

  getPatientsUpdates() {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getPatientsUpdates()
      .subscribe(res => {
        if (res.length > 0) {
          this.PatientsUpdates = res
          this.isPatientsUpdatesEmpty = false;
        } else {
          this.isPatientsUpdatesEmpty = true;
          console.log(this.isPatientsUpdatesEmpty);
        }
        this.layoutComponent.showSpinner(false);
      });
  }

  getPatientverfication() {
    this.layoutComponent.showSpinner(true);
    this.dashboardbusiness.getPatientverfications()
      .subscribe(res => {
        if (res.length > 0) {
          this.patientpendingverfications = res;
        }
        this.layoutComponent.showSpinner(false);
      })
  }

  lpRequestRedirect() {
    if (this.ValidCurrentUser == "ClinicsUser") {
      this.router.navigate(['/profile/lp-request']);
    }
    else {

      this.dashboardbusiness.getUserDetail().subscribe(res => {

        res.Provider_Login_Data.MVCUser_Permissions.filter((item: any) => {
          if (item.MVCUser_Permission == 0) {
            this.lprequestzero = true;
          }
          else if (item.MVCUser_Permission == 7) {
            this.lprequestseven = true;
          }
          else {
            this.lprequestzero = false;
            this.lprequestseven = false;
          }
        })

        if (this.lprequestzero && this.lprequestseven) {
          this.router.navigate(['/profile/lp-request']);
        }
        else {
          return this.modal.open(this.lprequestpermission, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dashboard-document' }, BSModalContext))
            .then(dialog => {
              this.dialog = dialog;
              //this.close();
            });
          // alert("Permission Restricted");

        }

      })
    }
  }

  onJoinNow(appt: any) {
    let self = this;
    self.doctorName = appt.Provider_First_Name;
    self.appointmentId = appt.Appointment_Id;
    this.insertConferenceStatus(appt, true);
  }
  callDisconnected(event: any) {
    let self = this;
    return this.modal.open(this.appointmentPatientTemRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
      .then(dialog => {
        this.dialogAppt = dialog;
        return dialog.result.then(res => {
          if (res) {
            this.openTok.disconnectWithOutEvent();
            self.dialog.close();
          }
        })
      })
  }
  onAppointmentCall(val: boolean) {
    this.dialogAppt.close(val);
  }
  subStreamCreated(event: Event) {
    this.isUserConnected = true;
  }

  publisherJoined(event: any) {
    this.videoCallStatus(this, true);
  }
  clinicPublisherJoined(event: any) {
    this.videoCallStatus(this, false);
  }

  videoCallStatus(self: any, isPatient: boolean) {
    this.videoCallStatusId = setInterval(() => {
      self._cb.getVideoCallStatus(self.appointmentId).subscribe((res: any) => {
        if (res.Response_Code == 2 && res.CallEnded) {
          self.openTok.disconnectWithOutEvent();
          self.dialog.close();
          clearInterval(self.videoCallStatusId);
          return self.modal.open(self.appointmentEndedRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then((dialog: any) => {
              self.dialogApptEnd = dialog;
              return dialog.result.then((res: any) => {
                if (isPatient) {
                  this.getUpcomingAppt(this.userDetail);
                  return;
                }
                this.getAllUpcomingApptClinics();
              })
            })
        }
      })
    }, 60000);
  }

  closeApptEnd() {
    this.dialogApptEnd.close();
  }
  clinicCallDisconnected(event: Event) {
    let self = this;
    return this.modal.open(this.appointmentPatientTemRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
      .then(dialog => {
        this.dialogAppt = dialog;
        return dialog.result.then(res => {
          if (res) {
            this.openTok.disconnectWithOutEvent();
            self.dialog.close();
          }
        })
      })
  }
  insertConferenceStatus(appt: any, isPatient: boolean) {
    this.layoutComponent.showSpinner(true);
    let param = {
      Appt_Id: appt.Appointment_Id,
      Clinic_ID: appt.Clinic_Id,
      Provider_ID: appt.Provider_Id,
      Patient_ID: appt.Patient_Id,
      Patient_Joined: isPatient,
      Provider_Joined: !isPatient
    };
    this._cb.insertConferenceStatus(param).subscribe(res => {
      this.layoutComponent.showSpinner(false);
      if (res.Response_Code == 1 || appt.Clinic.Clinic_Id <= 0 || appt.Provider_Id <= 0 || appt.Patient_Id <= 0) {
        this.getVideoLink(appt, isPatient);
      }
    })
  }

  getVideoLink(appt: any, isPatient: boolean) {
    let self = this;
    this.layoutComponent.showSpinner(true);
    this._cb.getVideoRoomLink(appt.Appointment_Id).subscribe(res => {
      this.layoutComponent.showSpinner(false);
      if (res.hasOwnProperty("Room_Link") && res.Room_Link != null) {
        this.videoConferenceId = res.Video_Conference_Id;
        this.apiKey = res.Api_Key;
        this.sessionId = res.Room_Link;
        this.token = res.Token;
        if (isPatient) {
          console.log('patient');
          return this.modal.open(this.joinnowref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
              this.dialog = dialog;
              setTimeout(function () {
                self.openTok.initializeSession();
              }, 10);
              return dialog.result.then(res => {
                if (this.isUserConnected) {
                  this.endVideoCall(this.videoConferenceId);
                  this.getUpcomingAppt(this.userDetail);
                }
                this.openTok.disconnectWithOutEvent();
                if (this.videoCallStatusId) {
                  clearInterval(this.videoCallStatusId);
                }
              });
            });
        } else if (!isPatient) {
          console.log('clinic');
          return this.modal.open(this.joinnowpopup, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
              this.dialog = dialog;
              setTimeout(function () {
                self.openTok.initializeSession();
              }, 10);
              if (appt.Notification) {
                this.sendEmailToUser(appt.Appointment_Id);
              }
              return dialog.result.then(res => {
                if (this.isUserConnected) {
                  this.endVideoCall(this.videoConferenceId);
                  this.showHideNoteUserProfile = false;
                  this.getAllUpcomingApptClinics();
                }
                this.openTok.disconnectWithOutEvent();
                if (this.videoCallStatusId) {
                  clearInterval(this.videoCallStatusId);
                }
              });
            });
        }
        return false;
      }
      let params = {
        Appt_Id: appt.Appointment_Id
      }
      this.layoutComponent.showSpinner(true);
      this._cb.createVideoChatRoom(params).subscribe(res => {
        this.layoutComponent.showSpinner(false);
        if (res == "Success") {
          this.getVideoLink(appt, isPatient);
        } else if (res == "Not user turn") {
          let str = "Please wait till your scheduled Appointment time occurs."
          this.showAlertMsg(str);
        } else if (res == "Appointment is in past") {
          let str = "The Scheduled Appointment time has been ended. Please contact the Clinic."
          this.showAlertMsg(str);
        } else if (res == "Invalid appointment id") {
          let str = "Incorrect Appointment Schedule. Please contact the Clinic."
          this.showAlertMsg(str);
        } else {
          let str = "An unexpected error occur. Please contact the Clinic."
          this.showAlertMsg(str);
        }
      })
    })
  }

  onClose() {
    let self = this;
    return this.modal.open(this.appointmentPatientTemRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
      .then(dialog => {
        this.dialogAppt = dialog;
        return dialog.result.then(res => {
          if (res) {
            self.dialog.close(true);
          }
        })
      })
  }

  endVideoCall(conf_id: any) {
    if (conf_id) {
      this._cb.endVideoCall(conf_id).subscribe(res => {
        if (res == "Success") {
          console.log('Disconnected!!');
        }
      })
    }
  }

  closewindow() {
    this.dialog.close();
    this.router.navigate(['dashboard']);
  }

  onNavigateToPolicy() {
    this.dialog.close();
    this.router.navigate(['support']);
  }

  //patient
  patientPopUp(details: any) {
    //this.patientupdatedetail = [];
    this.patientupdatedetail = details;
    return this.modal.open(this.patientview, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dashboard-document' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      });
  }
  onJoinNowAppt(appt: any) {
    this.tempApptData = appt;
    this.patientName = appt.Patient_First_Name;
    this.providerName = appt.Provider_First_Name;
    appt.Clinic_Id = appt.Clinic.Clinic_Id;
    this.appointmentId = appt.Appointment_Id;
    this.insertConferenceStatus(appt, false);
  }
  clinicSubStreamCreated() {
    this.isUserConnected = true;

    this._cb.updatePatientProviderConnectedStatus(this.tempApptData.Appointment_Id).subscribe(res => {
      if (res.Response_Code == 1) {
        this.showHideNoteUserProfile = true;
        this.apptData = this.tempApptData;
        console.log('User connected successfully');
      }
    });
  }
  sendEmailToUser(appt_id: number) {
    this._cb.enableMyAppointmentTurnEmail(appt_id).subscribe(res => {
      console.log(res);
    })
  }
  addProviderNote(appt: any) {
    if (this.providerNote.trim() != '') {
      let params = {
        Patient_ID: appt.Patient_Id,
        Provider_ID: appt.Provider_Id,
        Provider_First_Name: appt.Provider_First_Name,
        Provider_Last_Name: appt.Provider_Last_Name,
        Note_Text: this.providerNote
      }
      this._cb.addorModifyProviderNote(params).subscribe(res => {
        console.log(res);
        if (res == 'True') {
          this.providerNote = "";
        }
      })
    }
  }

  addNotes() {
    this.addProviderNote(this.apptData);
  }

  // onAdminClick(newValue: number) {
  //   console.log("this.highlightedDiv", newValue, this.highlightedDiv )
  //   this.highlightedDiv = newValue;
  //   console.log("this.highlightedDiv", newValue, this.highlightedDiv )
  //   this.router.navigate(['/profile/clinicsadmin']);
  // }
  onUpdateClinic(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/clinics/admin/edit-clinic/0']);
    }, 200);
  }
  onSetAppointment(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/profile/set-appointment']);
    }, 200);
  }
  onReports(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/Adminreport']);
    }, 200);
  }
  onUser(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/clinics/admin/permission']);
    }, 200);
  }

  // getMedicalDocumentExpiry() {
  //   this.dashboardbusiness.getMedicalDocumentExpiry().subscribe(res => {
  //     this.expiryDate = res;
  //   })
  // }

  onPhase(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/clinics/admin/phases']);
    }, 200);
  }
  onReferredBy(newValue: number) {
    this.highlightedDiv = newValue;
    setTimeout(() => {
      this.router.navigate(['/clinics/admin/referred-by-options']);
    }, 200);
  }


  oncompleteprofile() {
    this.completeProfileEntity = {
      primaryPhoneNumber: '',
      alternativePhoneNumber: {},
      height: '',
      weight: '',
      gender: '',
      existingOrPreviousCondition: [],
      medicalConditionSeeking: {},
      medicalTherapiesCondition: [],
      previoustherapiesCondition: '',
      previoustherapiesConditionDesc: '',
      previousCondition: '',
      previousConditionDesc: ''
    }

    let userInfo = this.userDetail;
    this.completeProfileEntity.primaryPhoneNumber = userInfo.Patient_Login_Data.Phone;
    let medicalData = this.userDetail.Patient_Login_Data.MedicalConditions;
    let therapieData = this.userDetail.Patient_Login_Data.Therapies;
    let medicationsData = this.userDetail.Patient_Login_Data.Medications;
    if (this.userDetail.Patient_Login_Data.Address_List.length > 0) {
      this.patientAddress = this.userDetail.Patient_Login_Data.Address_List[0].User_Address, this.userDetail.Patient_Login_Data.Address_List[0].City, this.userDetail.Patient_Login_Data.Address_List[0].Province, this.userDetail.Patient_Login_Data.Address_List[0].Country;
    }
    else {
      this.patientAddress = "";
    }

    let jsonMedicalData = [];
    let jsonTherapieData = [];
    let jsonMedicationsData = [];
    let medicationsDataOnOffFlag: boolean = true;
    let therapieDataOnOffFlag: boolean = true;
    this.tempMedicalConditions = [];
    this.tempTherapieConditions = [];
    this.medicationsDropDownNumber = 0;
    this.tempMedicationDetail = [];
    jsonMedicalData = medicalData != "" ? medicalData.split(",") : "";
    jsonTherapieData = therapieData != "" ? therapieData.split(",") : "";
    jsonMedicationsData = medicationsData != "" ? medicationsData.split(",") : "";

    this.completeProfileEntity.height = userInfo.Patient_Login_Data.Height;
    this.completeProfileEntity.weight = userInfo.Patient_Login_Data.Weight;
    this.completeProfileEntity.gender = userInfo.Patient_Login_Data.Gender;
    if (this.medicalConditions) {
      if (jsonMedicalData == "") {
        for (var index = 0; index < this.medicalConditions.length; index++) {
          this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
        }
      } else {
        let lastMedicationData = jsonMedicalData[jsonMedicalData.length - 1];
        for (var index = 0; index < this.medicalConditions.length; index++) {
          if (medicationsDataOnOffFlag && lastMedicationData == this.medicalConditions[index].Title) {
            medicationsDataOnOffFlag = false;
          }
          if (jsonMedicalData.indexOf(this.medicalConditions[index].Title) != -1) {
            this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": true });
            this.tempMedicalConditions[index].Checked = true;
            this.completeProfileEntity.existingOrPreviousCondition[index] = this.medicalConditions[index].Title;
          } else {
            this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
            this.tempMedicalConditions[index].Checked = false;
          }
        }
        if (medicationsDataOnOffFlag) {
          this.completeProfileEntity.previousCondition = "true";
          this.completeProfileEntity.previousConditionDesc = lastMedicationData;
        }

      }

      if (jsonTherapieData == "") {
        for (var index = 0; index < this.medicalConditions.length; index++) {
          this.tempTherapieConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
        }
      } else {
        let lastTherapieDataData = jsonTherapieData[jsonTherapieData.length - 1];
        for (var index = 0; index < this.medicalConditions.length; index++) {
          if (therapieDataOnOffFlag && lastTherapieDataData == this.medicalConditions[index].Title) {
            therapieDataOnOffFlag = false;
          }
          if (jsonTherapieData.indexOf(this.medicalConditions[index].Title) != -1) {
            this.tempTherapieConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": true });
            this.tempTherapieConditions[index].Checked = true;
            this.completeProfileEntity.medicalTherapiesCondition[index] = this.medicalConditions[index].Title;
          } else {
            this.tempTherapieConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
            this.tempTherapieConditions[index].Checked = false;
          }
        }
        if (therapieDataOnOffFlag) {
          this.completeProfileEntity.previoustherapiesCondition = "true";
          this.completeProfileEntity.previoustherapiesConditionDesc = lastTherapieDataData;
        }
      }
      console.log("this.tempMedicalConditions" + this.tempMedicalConditions);
    }

    if (jsonMedicationsData != "") {
      for (let jsonMedicationsDetail of jsonMedicationsData) {
        let dropDownCount = ++this.medicationsDropDownNumber;
        console.log("dropDownCount" + dropDownCount);
        this.medicationObject = {
          medicationCurrentlyTakingVlaue: dropDownCount,
          medicationSelectedValue: jsonMedicationsDetail
        }
        this.tempMedicationDetail.push({ "medicationObject": this.medicationObject });
      }
    } else {
      this.medicationObject = {
        medicationCurrentlyTakingVlaue: ++this.medicationsDropDownNumber,
        medicationSelectedValue: ""
      }
      this.tempMedicationDetail.push({ "medicationObject": this.medicationObject });
    }
    return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-register profileModal' }, BSModalContext)).then(dialog => {
      this.dialog = dialog;
      //this.close();
    });
  }

  saveProfileCompletion(formData: any) {
    this.layoutComponent.showSpinner(true);
    console.log(formData);
    let medicationData = [];
    let filterMedicationDetailResult = this.tempMedicationDetail.filter((responseData: any) => {
      return responseData.medicationObject.medicationSelectedValue != "";
    });
    if ((!formData.primaryPhoneNumber[0] || !formData.primaryPhoneNumber[1] || !formData.primaryPhoneNumber[2]) && formData.gender == "" && formData.height == "" && formData.weight == "" && formData.existingOrPreviousCondition.length == 0 &&
      formData.medicalTherapiesCondition.length == 0 && filterMedicationDetailResult.length == 0 && formData.previousCondition == "" && formData.previousConditionDesc == "" && formData.previoustherapiesCondition == "" && formData.previoustherapiesConditionDesc == "") {
      this.dialog.close();
      return false;
    }
    (this.completeProfileEntity.previousCondition == "true" && this.completeProfileEntity.previousConditionDesc != "") ? formData.existingOrPreviousCondition.push(this.completeProfileEntity.previousConditionDesc.length > 75 ? this.completeProfileEntity.previousConditionDesc.substring(0, 75) : this.completeProfileEntity.previousConditionDesc) : "";
    (this.completeProfileEntity.previoustherapiesCondition == "true" && this.completeProfileEntity.previoustherapiesConditionDesc != "") ? formData.medicalTherapiesCondition.push(this.completeProfileEntity.previoustherapiesConditionDesc.length > 75 ? this.completeProfileEntity.previoustherapiesConditionDesc.substring(0, 75) : this.completeProfileEntity.previoustherapiesConditionDesc) : "";
    let filterExistingOrPreviousConditionResult = formData.existingOrPreviousCondition.filter((responseData: any) => {
      return responseData != "";
    });
    let filterMedicalTherapiesConditionResult = formData.medicalTherapiesCondition.filter((responseData: any) => {
      return responseData != "";
    });
    for (let filterMedicationDetail of filterMedicationDetailResult) {
      if (medicationData.indexOf(filterMedicationDetail.medicationObject.medicationSelectedValue) == -1) {
        medicationData.push(filterMedicationDetail.medicationObject.medicationSelectedValue);
      }
    }
    this.userBusinessService.saveOrModifyCompleteProfile(formData, this.userDetail, filterExistingOrPreviousConditionResult, filterMedicalTherapiesConditionResult, medicationData).subscribe(res => {
      this.loginBusiness.getUserDetail().subscribe(res1 => {
        res1.Patient_Login_Data.Profile_Status == "Incomplete" ? this.completeProfileStatus = true : this.completeProfileStatus = false;
        res.Response_Code == 1 ? this.dialog.close() : '';
        this.layoutComponent.showSpinner(false);
        this.userDetail = res1;
      })
    }, (err) => {
      console.log("userBusinessService saveOrModifyCompleteProfile", err);
    });
  }


  addAnother(evnt: any) {
    let dropDownCount = ++this.medicationsDropDownNumber;
    console.log("dropDownCount" + dropDownCount);
    this.medicationObject = {
      medicationCurrentlyTakingVlaue: dropDownCount,
      medicationSelectedValue: ""
    }
    this.tempMedicationDetail.push({ "medicationObject": this.medicationObject });
  }

  checkOnckeckConditon(checkOrUncheck: number, medicationCondition: string) {

    if (!this.tempMedicalConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.completeProfileEntity.existingOrPreviousCondition[checkOrUncheck] = medicationCondition;
      this.tempMedicalConditions[checkOrUncheck].Checked = true;
    } else if (this.tempMedicalConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.completeProfileEntity.existingOrPreviousCondition[checkOrUncheck] = "";
      this.tempMedicalConditions[checkOrUncheck].Checked = false;
    } else {
      this.previousConditionChecked ? this.previousConditionChecked = false : this.previousConditionChecked = true;
      !this.previousConditionChecked ? this.completeProfileEntity.previousCondition = "" : "";
      !this.previousConditionChecked ? this.completeProfileEntity.previousConditionDesc = "" : "";
    }
  }

  therapiesConditon(checkOrUncheck: number, medicationCondition: string) {

    if (!this.tempTherapieConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.completeProfileEntity.medicalTherapiesCondition[checkOrUncheck] = medicationCondition;
      this.tempTherapieConditions[checkOrUncheck].Checked = true;
    } else if (this.tempTherapieConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.completeProfileEntity.medicalTherapiesCondition[checkOrUncheck] = "";
      this.tempTherapieConditions[checkOrUncheck].Checked = false;
    } else {
      this.previoustherapiesConditionChecked ? this.previoustherapiesConditionChecked = false : this.previoustherapiesConditionChecked = true;
      !this.previoustherapiesConditionChecked ? this.completeProfileEntity.previoustherapiesCondition = "" : "";
      !this.previoustherapiesConditionChecked ? this.completeProfileEntity.previoustherapiesConditionDesc = "" : "";
    }
  }

  medicationcloseEvent(value: any) {

    // document.getElementById("medicationIndex"+value.data).remove();
    // this.tempMedicationDetail.push({ "medicationObject": this.medicationObject });

    for (var index = 0; index < this.tempMedicationDetail.length; index++) {
      if (this.tempMedicationDetail[index].medicationObject.medicationCurrentlyTakingVlaue == Number(value.data)) {
        this.tempMedicationDetail.splice(Number(index), 1);
        //document.getElementById("medicationIndex"+value.data).remove();
      }
    }
    console.log("oiii" + value.data);
  }

  onSelectMedication(value: any) {
    this.tempValue = value.selectdata;
    if (this.tempMedicationDetail.indexOf(value.selectdata) == -1 && value.selectdata != "") {
      this.tempMedicationDetail.push(value.selectdata);
    }
  }
  showAlertMsg(value: string) {
    this.content = value;
    this.modal.open(this.alertRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  closeAlert() {
    this.dialog.close();
  }
}