import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { Dashboardbusiness  } from '../business/dashboard.business';
import { LayoutComponent } from "../../layout/component/layout.component";
@Component({
    selector: 'cannabis-log',
    templateUrl: './cannabis-log.component.html',
    styleUrls: ['./cannabis-log.component.scss']
})
export class CannabisLogComponent implements OnInit {
    public updatedDate: string;
    private isEmpty: boolean = false;
    constructor(private layoutComponent:LayoutComponent, private _db: Dashboardbusiness ) { }

    ngOnInit() { 
        this.layoutComponent.showSpinner(true);
        // TODO: Need to add condition if res is empty
        this._db.getCannabisLogList(parseInt(localStorage.getItem('mvcUserId')))
        .subscribe(res => {
            this.layoutComponent.showSpinner(false);
            if(res === null) {
                this.isEmpty = true;
                return false;
            }
        this.isEmpty = false; 
        this.updatedDate = res.Updated_Date;
        })
    }


}