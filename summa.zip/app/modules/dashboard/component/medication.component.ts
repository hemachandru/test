import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { SharedObserverService } from "../../../shared/shared-service-module/shared-observer.service";
import { ProfileComplete } from "../entity/profilecomplete.entity";

@Component({
  selector: 'medication-list',
  templateUrl: './medication.component.html',
  styleUrls: ['./medication.component.scss'],
  providers: []
})

export class MedicationComponent implements OnInit, OnDestroy {
  public selectlist: any = [];

  public medications: any;
  public completeProfileEntity: ProfileComplete;
  private unsubscribe: any;
  @Input() medicationDropDownValue: any;
  @Input() addanotherListview: any;
  // @Output() medicationclose = new EventEmitter();
  @Output() selectMedication = new EventEmitter();
  constructor(private _sos: SharedObserverService, ) {
    this.unsubscribe = this._sos.eventReceiver$.subscribe(res => {
      this.medications = res.Medications;
      console.log("this.medications",this.medications);
    });
  }

  ngOnInit() {

  }

  medicationcloseEvent(item: any, list: any) {
    debugger;
    this.addanotherListview.splice(this.addanotherListview.indexOf(item), 1);
    
    if (this.selectlist.length == 0) {
      list.Title = 0;
    }
  }

  onSelectMedication(selectData: any, evt: any) {
    if (this.selectlist.indexOf(selectData) == -1) {
      this.selectlist.push(selectData);
    }
    let event = {
      event: evt,
      selectdata: selectData,
      addanotherList: this.selectlist
    }
    this.selectMedication.emit(event);
  }

  ngOnDestroy() {
    this.unsubscribe ? this.unsubscribe.unsubscribe : '';
  }
}