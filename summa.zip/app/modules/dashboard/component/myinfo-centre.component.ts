import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

export class InfoCentre {
  imgURL: string;
  title: string;
}

const MYINFOCENTRE: InfoCentre[] = [
  { imgURL: require('../../../../assets/images/article1.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article2.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article3.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article2.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article1.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article3.jpg'), title: 'Article title' },
  { imgURL: require('../../../../assets/images/article2.jpg'), title: 'Article title' }
];

@Component({
    selector: 'myinfo-centre',
    templateUrl: './myinfo-centre.component.html',
    styleUrls: ['./myinfo-centre.component.scss']
})
export class MyInfoCentreComponent implements OnInit {
  
    protected favInfoCentre: InfoCentre[] = MYINFOCENTRE;
 
    constructor() { }

    ngOnInit() { }

}