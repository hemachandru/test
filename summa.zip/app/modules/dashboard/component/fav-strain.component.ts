import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
 import { LayoutComponent } from "../../layout/component/layout.component";
import { Dashboardbusiness } from '../business/dashboard.business';
import { DrugBusinessService } from "../../drug/business/drug.business";
import { SharedObserverService } from "../../../shared/shared-service-module/shared-observer.service";
import { Config } from '../../../config/constant';

export class Strain {
  imgURL: string;
  name: string;
  Product_Id: number
}

// const STRAINS: Strain[] = [
//   { imgURL: require('../../../../assets/images/strain.jpg'), name: 'Mr. Nice' },
//   { imgURL: require('../../../../assets/images/strain1.jpg'), name: 'Narco' },
//   { imgURL: require('../../../../assets/images/crop.jpg'), name: 'Bombasto' },
//   { imgURL: require('../../../../assets/images/strain.jpg'), name: 'Narco' },
//   { imgURL: require('../../../../assets/images/crop.jpg'), name: 'Narco' }
// ];

@Component({
  selector: 'fav-strain',
  templateUrl: './fav-strain.component.html',
  styleUrls: ['./fav-strain.component.scss']
})
export class FavStrainComponent implements OnInit {
  public strains: Strain[];
  private strainDetail: any = {};
  private masterInfo: any;
  private favoriteStrainText:any=this.config.favoriteStrain
  @ViewChild('viewStrainInfo') public viewStrainInfo: TemplateRef<any>;
   @ViewChild('confirmGo') public confirmGo: TemplateRef<any>;
	dialog: DialogRef<any>;

  constructor(private config:Config, private _dbs: DrugBusinessService, private _sos: SharedObserverService, private layoutComponent:LayoutComponent,private _db: Dashboardbusiness,  overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router) {

  }

  ngOnInit() {
    this.strains = [];

    this.init();
    this._sos.eventReceiver$.subscribe(res => {
      if(res == true) {
        return false;
      }
      this.masterInfo = res;
    })
  }

 viewStrain(){		
		return this.modal.open(this.viewStrainInfo, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
      		this.dialog = dialog;
    });
	}

  confirmationGo() {
      return this.modal.open(this.confirmGo, overlayConfigFactory({ dialogClass: 'modal-dialog model-strainfinder' }, BSModalContext)).then(dialog => {
      		this.dialog = dialog;
    });
  }

  modalConfirmationCancel(){
    this.dialog.close();
  }

  modalConfirmationOk(){
    this.dialog.close();
    this.router.navigate(['/strain-finder/strain']);
  }


  init() {
    this.layoutComponent.showSpinner(true);
    this._db.getFavoriteStrains()
      .subscribe(res => {
        if(res) {
          this.strains = [];
          for(let i=0; i<res.length; i++) {
            let imgUrlPath=(res[i].Product_Img_Url == null || res[i].Product_Img_Url == "") ? '' : "data:image/jpeg;base64," + res[i].Product_Img_Url;
            this.strains.push({
              imgURL: imgUrlPath,
              name: res[i].Product_Name,
              Product_Id: res[i].Product_Id
            })
            
          }
           this.layoutComponent.showSpinner(false);
        }else{
           this.layoutComponent.showSpinner(false);
        }
      })
  }

  addToFavouriteStrain(event: any) {
    event.thisData.layoutComponent.showSpinner(false);
    let isAddOrRemove = !event.isFav; 
    this._dbs.addOrRemoveFavoriteStrain(event.id, isAddOrRemove).subscribe(res => {
      this.strainDetail.IsFavourite = isAddOrRemove;
      this.init();
    })
  }

  getStrainDetail(value: any) {
    let data = {
      product_id: value.Product_Id
    }
    this._dbs.getStrainDetail(data, this.masterInfo.ProductTypes).subscribe(res => {
      this.strainDetail = res;
      return this.modal.open(this.viewStrainInfo, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
          this.dialog = dialog;
      });
    })
  }

  close(event:any) {
    this.dialog.close();    
    event.layoutComponent.showSpinner(false);
  }
}