export interface ProfileComplete {
    primaryPhoneNumber :{},
    alternativePhoneNumber :{},
    height :string,
    weight :string,
    gender :string,
    existingOrPreviousCondition :{},
    medicalConditionSeeking :{},
    medicalTherapiesCondition :{},
    previoustherapiesCondition: string,
    previoustherapiesConditionDesc: string,
    previousCondition:string,
    previousConditionDesc: string

}