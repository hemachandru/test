import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
// import { RefreshTokenhandlerService } from '../../../core/refresh-token-handler-service';

import { Config } from '../../../config/constant';
@Injectable()
export class DashboardService {
    constructor( private httpRequestService: HttpRequestService, private config: Config) {

    }
    
    //get the Login User Detail
    getUserDetail() {
        return this.httpRequestService.getHttpRequest(this.config.userdetailUrl);
    }
    //Get the getUnreadNotificationCount
    getUnreadNotificationCount(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }
    //latest request client detail
    getNewClientRequest(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }
    //fetch notification full detail
    getNotificationDetail(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

    //Update Notification status depend on messageid.
    updateNotificationMessageStatus(url: string) {
        return this.httpRequestService.putHttpWithoutData(url, null);
    }
    /**
     * Get cannabis log list 
     * @param {string} url API end point 
     * @return {Observable}
     */
    getCannabisLog(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }
    /**
     * Get Upcoming Appointment
     * @param {string} url API end point 
     * @return {Observable}
     */
    getUpcomingAppointments(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

/**
   * Get LP Request
   * @param url API end point 
   */
    getLpRequests(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

    getPatientsUpdates(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

      /**
   * Get Patient pending verfication
   * @param url API end point 
   */
    getPatientverfications(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }


    /**
     * Get Favorite Strains 
     * @param {string} url API end point 
     * @return {Observable}
     */
    getFavoriteStrains (url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

    /**
     * getMedicalDocumentExpiry(param)
     * 
     * Get medical document expiry details
     * 
     * @param {string} url - API end point url
     * @return {Observable}
     */
    getMedicalDocumentExpiry(url: string) {
        return this.httpRequestService.getHttpRequest(url);
    }

    /**
     * @method insertConferenceStatus(param1, param2)
     * 
     * @param {any} data - Request Object to insert conference status
     * @param {string} url - API end point url
     * @return {Observable}
     * @desc Insert Conference status before initiating video call.
     */
    // insertConferenceStatus(data: any, url: string) {
    //     return this.httpRequestService.postHttpRequest(data, url);
    // }

    /**
     * @method getVideoRoomLink(param) 
     * 
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Get video room link id to initiate the video call using WebRTC plugin.
     */    
    // getVideoRoomLink(url: string) {
    //     return this.httpRequestService.getHttpRequest(url);
    // }

    /**
     * @method createVideoChatRomm(param1,params2) 
     * 
     * @param requestParams Request parameter to create video chat room
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Create video room to initiate the video call between two parties using WebRTC plugin. 
     */
    // createVideoChatRomm(requestParams: any, url: string) {
    //     return this.httpRequestService.postHttpRequest(requestParams, url);
    // }

    /**
     * @method endVideoCall(param)
     * 
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Create Log entry while video call is ended
     */
    // endVideoCall(url: string) {
    //     return this.httpRequestService.getHttpRequest(url);
    // }
}