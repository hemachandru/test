import { NgModule }       from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SlimScrollModule } from 'ng2-slimscroll';



import { DashboardComponent } from './component/dashboard.component';
import { FavStrainComponent } from './component/fav-strain.component';
import { CannabisLogComponent } from './component/cannabis-log.component';
import { MyInfoCentreComponent } from './component/myinfo-centre.component';
import { MessageNotificationModule } from './messagenotification/messagenotification.module';
import { TaskModule } from '../task/task.module';
import { TextMaskModule } from 'angular2-text-mask';

import { DashboardRoutingModule } from './dashboard.routing';
import { OnlyNumber } from '../../shared/integer-validation.directive';
import { ArticleModalModule } from '../../shared/arictlemodal/article-modal.module';
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { StrainSharedModule } from "../drug/component/shared/strain-shared.module";
import { LoaderService } from '../../shared/shared-loader/shared-loader.service';
import { MedicationComponent } from './component/medication.component';
import { DrugBusinessService } from "../drug/business/drug.business";
import { DrugService } from "../drug/service/drug.service";
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";
import { UserBusinessService } from '../user/business/user.business';
import { UserService } from '../user/service/user.service';
import { Dashboardbusiness } from './business/dashboard.business';
import { DashboardService } from './service/dashboard.service';
import { Config } from '../../config/constant';
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { RecordService } from '../record/component/service/record.service';
import { RecordBusiness } from '../record/component/business/record.business';
import { LoginBusiness } from '../account/component/business/login.business';
import { LoginService } from '../account/component/service/login.service';
import { ClinicBusiness } from '../clinic/business/clinic.business';
import { ClinicService } from '../clinic/service/clinic.service';
import { OpenTokModule } from "../opentok/opentok.module";

@NgModule({
  imports: [
    PipeModule,
    CommonModule,
    DashboardRoutingModule,
    TaskModule,
    FormsModule,
    ArticleModalModule,
    MessageNotificationModule,
    StrainSharedModule,
    SharedServiceModule,
    SlimScrollModule,
    TextMaskModule,
    OpenTokModule
  ],
  entryComponents: [MedicationComponent],
  declarations: [
    DashboardComponent,
    FavStrainComponent,
    CannabisLogComponent,
    MyInfoCentreComponent,
    OnlyNumber,
    MedicationComponent
  ],

  providers: [
    LoaderService, 
    DrugService, 
    DrugBusinessService,
    UserBusinessService,
    UserService,
    Dashboardbusiness,
    DashboardService,
    Config,
    HttpRequestService,
    RecordService,
    RecordBusiness,
    LoginBusiness,
    LoginService,
    ClinicBusiness,
    ClinicService
  ]
})
export class DashboardModule {}