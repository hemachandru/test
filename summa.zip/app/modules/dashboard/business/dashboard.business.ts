import { Injectable, Component } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { DashboardService } from '../service/dashboard.service';
import { Config } from '../../../config/constant';

@Injectable()
export class Dashboardbusiness {
  constructor(private httpRequestService: HttpRequestService, private dashboardService: DashboardService, private config: Config) {
  }

  getUserDetail() {
    if (localStorage.getItem('profileUpdateStatusCode') === 'true') {//get the updated Login User Detail
      this.dashboardService.getUserDetail().map(response => {
        localStorage.setItem('profileUpdateStatusCode', 'false');
        return response.json();
      });
    } else {  //get the Login User Detail
      return this.dashboardService.getUserDetail().map(response => response.json());
    }
  }

  //Get the getUnreadNotificationCount
  getUnreadNotificationCount(userDetail: any) {
    var url = this.config.notificationCount + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/' + localStorage.getItem('clinicId');
    return this.dashboardService.getUnreadNotificationCount(url).map(response => response.json());
  }

  //latest request client detail
  getNewClientRequest(userDetail: any) {
    var url = this.config.getPatientList + userDetail.User_Role + '/' + userDetail.LP_Login_Data.LP_Id + '/0';
    return this.dashboardService.getNewClientRequest(url).map(response => response.json());
  }

  //fetch notification full detail
  getNotificationDetail() {
    var url = this.config.getNotificationMessage + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/' + localStorage.getItem('clinicId');
    return this.dashboardService.getNotificationDetail(url).map(response => response.json());
  }

  //Update Notification status depend on messageid.
  updateNotificationMessageStatus(messageId: number) {
    var url = this.config.updateNotificationStatus + messageId;
    return this.dashboardService.updateNotificationMessageStatus(url).map(response => response.json());
  }

  /**
   * Get cannabis log - last updated log
   * 
   * @return Observerable
   */
  getCannabisLogList(userId: number) {
    let url = this.config.getCannabisLog + userId;
    return this.dashboardService.getCannabisLog(url).map(response => response.json());
  }

  /**
   * Get user upcoming appointment
   * 
   * @return Observerable
   */
  getUpcomingAppointments(userInfo: any) {
    let url = this.config.getUpcomingOrPreviousAppointments + userInfo.User_Role + '/' + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('clinicId') + '/' + 0;
    return this.dashboardService.getUpcomingAppointments(url).map(response => response.json());
  }

  /**
   * Get all user upcoming appointment
   * 
   * @return Observerable
   */
  getAllUpcomingOrPreviousAppointments() {       
    let url = this.config.getAllUpcomingOrPreviousAppointments + localStorage.getItem('clinicId') +"/0";
    return this.dashboardService.getUpcomingAppointments(url).map(res => res.json());
  }
  
  /**
     * Get user LP Request
     * 
     * @return Observerable
     */
  getLpRequests() {
    let url = this.config.getAllDocumentUrl + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/' + + localStorage.getItem('ClinicId') + '/' + "'LPSVTP'";
    return this.dashboardService.getLpRequests(url).map(response => response.json());
  }

  getPatientsUpdates() {
      let url = this.config.getClientUpdates + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole');
      return this.dashboardService.getPatientsUpdates(url).map(response => response.json());
  }

  /**
     * Get Patient verfications
     * 
     * @return Observerable
     */
  getPatientverfications() {
    let url = this.config.getAllDocumentUrl + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/' + + localStorage.getItem('ClinicId') + '/' + "'EDCR'";
    return this.dashboardService.getPatientverfications(url).map(response => response.json());
  }

  /**
   * Get favorite Strains
   * 
   * @return Observerable
   */
  getFavoriteStrains() {
    let url = this.config.getFavouriteStrains + localStorage.getItem('userRole') + '/' + localStorage.getItem('mvcUserId');
    return this.dashboardService.getFavoriteStrains(url).map(response => response.json());
  }

  getMedicalDocumentExpiry() {
    let url = this.config.getMedicalDocumentExpiry + '/' + localStorage.getItem('mvcUserId');
    return this.dashboardService.getMedicalDocumentExpiry(url).map(res => res.json());
  }

  /**
   * @method insertConferenceStatus(param)
   * 
   * @param {any} data - Request data to insert conference status 
   * @return {Observable} By applying a function to each item
   * @desc Insert Conference status before initiating video call.
   */
  // insertConferenceStatus(data: any) {
  //   let url = this.config.insertConferenceStatus;
  //   let params = {
  //     "APNOTIFY_ID": 0,
  //     "Appt_ID": data.Appt_Id, //1771,
  //     "Clinic_ID": data.Clinic_ID, // 86,
  //     "Provider_ID": data.Provider_ID, // 97,
  //     "Patient_ID": data.Patient_ID, // 352,
  //     "Patient_Joined": data.Patient_Joined, // true if patient has joined,
  //     "Provider_Notified": false,
  //     "Provider_Joined": data.Provider_Joined, // true if provider has joined
  //   }

  //   return this.dashboardService.insertConferenceStatus(params, url).map(res => res.json());
  // }

  /**
   * @method getVideoRoomLink(param)
   * 
   * @param {number} appt_id - Appointment id to get video room link id.
   * @return {Observable} .map() By applying a function to each item
   * @desc Get video room link id to initiate the video call using WebRTC plugin.
   */
  // getVideoRoomLink(appt_id: number) {
  //   let url = this.config.getVideoRoomLink + appt_id;

  //   return this.dashboardService.getVideoRoomLink(url).map(res => res.json());
  // }

  /**
   * @method createVideoChatRomm(param) 
   * 
   * @param data Request parameter to create video chat room
   * @return {Observable} .map() By applying a function to each item
   * @desc Create video room to initiate the video call between two parties using WebRTC plugin. 
   */
  // createVideoChatRoom(data: any) {
  //   let url = this.config.createVideoChatRoom;
  //   let params = {
  //     "Appt_Id": data.Appt_Id, // 1771,
  //     "Room_Link": "videConfernceBWPaPr" + data.Appt_Id, // "appt id",
  //     "Room_Link_Created_By": localStorage.getItem('userRole'), // "Patients" or "Clinics"
  //   }

  //   return this.dashboardService.createVideoChatRomm(params, url).map(res => res.json());
  // }

  /**
   * @method endVideoCall(param)
   * 
   * @param {number} videoConferenceId Video conference id to end video call
   * @return {Observable} .map() By applying a function to each item
   * @desc Create Log entry while video call is ended
   */
  // endVideoCall(videoConferenceId: number) {
  //   let url = this.config.endVideoCall + videoConferenceId;
    
  //   return this.dashboardService.endVideoCall(url).map(res => res.json());
  // }

}