import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';

@Component({
    selector: 'sidemenu-list',
    templateUrl: './formbuilder.component.html'
})

export class FormBuilderComponent {
    constructor(overlay: Overlay, vcRef: ViewContainerRef, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit(): void {
       window.open('https://mvctech-form-uat.azurewebsites.net/Account/Login?ReturnUrl=%2fFormBuilder','_blank'); 
    } 

  

}