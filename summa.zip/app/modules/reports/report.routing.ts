import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminReportComponent } from './component/adminreport/view-adminreport.component';

const AdminReportRoutes: Routes = [
  {
    path: '',
    component: AdminReportComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(AdminReportRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AdminReportModule { }