import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';

const orderData = [
  {
    "id": 1,
    "orderDate": "01/01/2017",
    "onregisterPatient": 1
  },
  {
    "id": 2,
    "orderDate": "01/02/2017",
    "onregisterPatient": 2
  },
  {
    "id": 3,
    "orderDate": "01/03/2017",
    "onregisterPatient": 3
  },
  {
    "id": 4,
    "orderDate": "02/04/2017",
    "onregisterPatient": 4
  },
  {
    "id": 5,
    "orderDate": "03/04/2017",
    "onregisterPatient": 5
  },
  {
    "id": 6,
    "orderDate": "01/05/2017",
    "onregisterPatient": 6
  },
  {
    "id": 7,
    "orderDate": "01/06/2017",
    "onregisterPatient": 7
  },
  {
    "id": 8,
    "orderDate": "01/07/2017",
    "onregisterPatient": 8
  },
  {
    "id": 9,
    "orderDate": "02/07/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "03/07/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "04/07/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "07/07/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "08/08/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "09/10/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "10/10/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "11/10/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "12/10/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "13/10/2017",
    "onregisterPatient": 1
  },
  {
    "id": 9,
    "orderDate": "14/10/2017",
    "onregisterPatient": 1
  }

];

@Component({
  templateUrl: './view-adminreport.component.html',
  styleUrls: ['./view-adminreport.component.scss']
})



export class AdminReportComponent implements OnInit {
  public idate: any;
  public date = new Date();
  public reportTable: boolean;
  public orderDataReport = orderData;
  public opts: ISlimScrollOptions;
  public user: any;
  private selectOption: any;
  public selectLanguage: any;
  public ValidCurrentUser: string;
  private myDatePickerNormalOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'mm/dd/yyyy',
    firstDayOfWeek: 'mo',
    height: '25px',
    selectionTxtFontSize: '12px',
    indicateInvalidDate: true,
    editableMonthAndYear: true,
    minYear: 1900,
    maxYear: this.date.getUTCFullYear(),
    disableSince: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() + 1 },
    componentDisabled: false,
    showClearDateBtn: false,
    showSelectorArrow: true,
    showInputField: true,
    openSelectorOnInputClick: true,
    inline: false,
    editableDateField: false,
    disableHeaderButtons: true,
    inputAutoFill: false,
    showWeekNumbers: false
  };
  constructor(private router: Router, private _location: Location) {
  }
  ngOnInit() {
    var currentUser = localStorage.getItem('currentUser');
    this.ValidCurrentUser = currentUser;
    this.reportTable = false;
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '0',
      gridWidth: '0',
      gridMargin: '1px 0',
    }
    this.user = {
      newpassword: "",
      dobStart: "",
      dobEnds: ""

    }
  }
  searchreport() {
    this.reportTable = true;
  }
  backtoMain() {
    this.reportTable = false;
  }
  onBack() {
    this._location.back();
  }
}