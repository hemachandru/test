import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Http, Response, Headers } from '@angular/http';
import { SlimScrollModule } from 'ng2-slimscroll';

import { AdminReportComponent } from './component/adminreport/view-adminreport.component';
import { AdminReportModule } from './report.routing';
import { MyDatePickerModule } from 'mydatepicker';
import { SharedModule } from "../../shared/sharedmodule/shared.module";
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";


@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        SlimScrollModule,
        AdminReportModule,
        MyDatePickerModule,
        SharedModule,
        SharedServiceModule
    ],
    declarations: [
        AdminReportComponent
    ],
    providers: []
})
export class AdminModule { }