import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { HttpRequestService } from '../../../shared/shared-service/http-request.service';

@Injectable()
export class ClinicService {
    constructor(private _hrs: HttpRequestService) {

    }
    getClinicsList(url: string, params: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     * Get Upcoming Appointment
     * @param url API end point 
     */
    getUpcomingAppointments(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getConsultationRequest(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getClinicProvincesCities(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getClinicByClinicId(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getAppointmentReasons(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getProvidersByClinic(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    addOrModifyAppointment(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

    cancelAppointment(url: string) {
        return this._hrs.getHttpRequest(url);
    }


    GetClinicSchedularPage(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    GetUpcomingOrPreviousAppointments(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    VerifyPatientPerms(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    GetPatientByPatientId(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    addOrModifyPhases(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

    addOrModifyReferredByOption(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

    getClinicStages(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    getReferredByOptions(url: string) {
        return this._hrs.getHttpRequest(url);
    }


    getAppoinmentReqList(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    updateAppRequests(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    updateClinic(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    updateProvider(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    getMyPatientList(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    activateDeactivateProviders(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

    //Appointment Requests

    // getAppoinmentReqList(url: string) {
    //     return this._hrs.getHttpRequest(url);
    // }
    // updateAppRequests(data: any, url: string) {
    //     return this._hrs.putHttpRequest(data, url);

    // }

    getAppoinmentReqList(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    joinnowGet(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    updateAppRequests(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    /**
     * @method insertConferenceStatus(param1, param2)
     * 
     * @param {any} data - Request Object to insert conference status
     * @param {string} url - API end point url
     * @return {Observable}
     * @desc Insert Conference status before initiating video call.
     */
    insertConferenceStatus(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

     insertConferenceRoom(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

     cancelledQueue(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    /**
     * @method telemedRequest(param1, param2)
     * 
     * @param {any} data - Request Object to insert conference status
     * @param {string} url - API end point url
     * @return {Observable}
     * @desc Insert Conference status before initiating video call.
     */
    telemedRequest(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

sendappoinmentemail(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    /**
     * @method getVideoRoomLink(param) 
     * 
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Get video room link id to initiate the video call using WebRTC plugin.
     */    
    getVideoRoomLink(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * @method getVideoCallStatus(param) 
     * 
     * @param url API end point url
     * @return {Observable} 
     * @desc Get video call status to disconnect it after specific period of time
     */
    getVideoCallStatus(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    
    /**
     * @method createVideoChatRomm(param1,params2) 
     * 
     * @param requestParams Request parameter to create video chat room
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Create video room to initiate the video call between two parties using WebRTC plugin. 
     */
    createVideoChatRomm(requestParams: any, url: string) {
        return this._hrs.postHttpRequest(requestParams, url);
    }

    /**
     * @method endVideoCall(param)
     * 
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Create Log entry while video call is ended
     */
    endVideoCall(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * @method updatePatientProviderConnectedStatus()
     * 
     * @param {Object} data Request parameter to update the connected status 
     * @param {string} url API end point url
     * @return {Observable} .map() By applying a function to each item
     * @desc Update the status when patient and provider both are connected in video call
     */
    updatePatientProviderConnectedStatus(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    /**
     * @method enableMyAppointmentTurnEmail()
     * 
     * @param {Object} data Request parameter to enable email 
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Enable/Send my appointment turn email
     */
    enableMyAppointmentTurnEmail(data: any, url: string) {
        return this._hrs.putHttpRequest(data, url);
    }

    /**
     * @method addorModifyProviderNote()
     * 
     * @param {Object} data Request parameter to add provider note
     * @param {string} url API end point url
     * @return {Observable} 
     * @desc Add provider note at the time of video call.
     */
    addorModifyProviderNote(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }

    getMedicalDocuments(url:string){
        return this._hrs.getHttpRequest(url);        
    }

    getMedicalDocument(url:string){
        return this._hrs.getHttpRequest(url);
    }

}