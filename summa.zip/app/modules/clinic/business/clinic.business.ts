import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { ClinicService } from "../service/clinic.service";
import { Config } from "../../../config/constant";

@Injectable()
export class ClinicBusiness {
    private editApptObserver = new BehaviorSubject(false);
    public editApptReceiver$: Observable<any>;

    private editApptIdObserver = new BehaviorSubject(0);
    public editApptIdReceiver$: Observable<any>;

    private editApptFlagObserver = new BehaviorSubject(false);
    public editApptFlagReceiver$: Observable<any>;

    constructor(private config: Config, private _cs: ClinicService) {
        this.editApptReceiver$ = this.editApptObserver.asObservable();
        this.editApptIdReceiver$ = this.editApptIdObserver.asObservable();
        this.editApptFlagReceiver$ = this.editApptFlagObserver.asObservable();
    }
    sendEditApptEvent(event: any) {
        this.editApptObserver.next(event);
    }

    sendEditApptIdEvent(event: any) {
        this.editApptIdObserver.next(event);
    }

    sendEditApptFlagEvent(event: any) {
        this.editApptFlagObserver.next(event);
    }

    getClinicsList(data: any) {
        let url = this.config.SearchClinics;
        let params: any = {
            Search_Code: data.code || 0,
            Province_Name: null,
            City_Name: data.cities || null,
            Clinic_Name: data.clinicName || null,
            Allowed_Appointment_Types: data.id ? data.id : 0,
            IncludeOscar: true,
            ParentClinicID: null,
            ParentClinicName: "",
            ShowOnlySearchable: true
        };

        return this._cs.getClinicsList(url, params).map(res => {
            let result = [];

            for (let data of res.json()) {
                if (data.Clinic_Logo_URL) {
                    let logo_url = "data:image/jpeg;base64," + data.Clinic_Logo_URL;
                    data.Clinic_Logo_URL = logo_url;
                }
                result.push(data);
            }
            return result;
        });
    }

    getConsultationRequest() {
        let url = this.config.getConsultationRequests + "/" + localStorage.getItem('userRole') + "/" + localStorage.getItem('mvcUserId') + "/0/0";
        return this._cs.getConsultationRequest(url).map(res => {
            let resultObj = res.json();

            for (var index = 0; index < resultObj.length; index++) {
                if (resultObj[index].Consultation_Request_Status) {
                    if (resultObj[index].Consultation_Request_Status == "Waiting For Approval") {
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        });
    }

    /**
     * Get user upcoming appointment
     * 
     * @return Observerable
     */
    getUpcomingAppointments() {
        let url = this.config.getUpcomingOrPreviousAppointments + localStorage.getItem('userRole') + '/' + localStorage.getItem('mvcUserId') + '/' + 0 + '/' + 0;
        return this._cs.getUpcomingAppointments(url).map(response => {
            let resultObj = response.json();

            if (resultObj.length == 0) {
                return false;
            }

            if (resultObj.length > 0) {
                return true;
            }
        });
    }

    getUpcomingAppointmentList() {
        let url = this.config.getUpcomingOrPreviousAppointments + localStorage.getItem('userRole') + '/' + localStorage.getItem('mvcUserId') + '/' + 0 + '/' + 0;
        return this._cs.getUpcomingAppointments(url).map(response => {
            let resultObj = response.json();

            if (resultObj.length == 0) {
                return false;
            }

            if (resultObj.length > 0) {

                for (var index = 0; index < resultObj.length; index++) {
                    if (resultObj[index].Clinic.Clinic_Logo_URL) {
                        let logo_url = "data:image/jpeg;base64," + resultObj[index].Clinic.Clinic_Logo_URL;
                        resultObj[index].Clinic.Clinic_Logo_URL = logo_url;
                    }
                }
                return resultObj;
            }
        });
    }

    getClinicProvincesCities() {
        let url = this.config.getClinicProvincesCities;
        return this._cs.getClinicProvincesCities(url).map(res => {
            let arrObj = res.json();
            let resultObj: any = [];

            for (let index = 0; index < arrObj.length; index++) {
                if (arrObj[index].cities.length > 0) {
                    resultObj.push(...arrObj[index].cities);
                }
            }

            return resultObj;
        })
    }

    getClinicByClinicId(id: number) {
        let url = this.config.getClinicByClinicId + '/' + id;
        return this._cs.getClinicByClinicId(url).map(res => {
            let resultSet = res.json();
            if (resultSet.Clinic_Logo_URL && resultSet.Clinic_Logo_URL.trim() != "" && resultSet.Clinic_Logo_URL.indexOf("data:image") < 0) {
                resultSet.Clinic_Logo_URL = "data:image/png;base64," + resultSet.Clinic_Logo_URL;
            }

            return resultSet;
        });
    }

    getAppointmentReasons(id: number) {
        let url = this.config.getAllClinicAppointmentReasons + id;
        return this._cs.getAppointmentReasons(url).map(res => res.json());
    }

    getProvidersByClinic(id: number) {
        let url = this.config.getProvidersByClinic + id;
        return this._cs.getProvidersByClinic(url).map(res => res.json());
    }

    addOrModifyAppointment(data: any) {
        let url = this.config.addormodifyAppointmentUrl;
        let params: any = {
            "Patient_Id": data.patient_id,
            "Provider_Id": data.provider_id,
            "Clinic_Id": data.clinic_id,
            "Appointment_Date_Only": data.appt_date,// "2017-07-07",//
            "Appointment_EndDate": data.appt_end_date,//"2017-07-07",//
            "Appt_Start_Time": data.appt_start_time, //"15:00:00",//
            "Appt_End_Time": data.appt_end_time, //"15:30:00",//
            "Reason": data.reason,
            "Status": "PBA",
            "User_Role": data.user_role,
            "Created_By_UserName": data.user_name,
            "Notes": "",
            "Appointment_Type": data.type,
            "Appt_ID": data.AppId || 0,
            "NewAppointment": data.editAppFlag,
            "ColsultationRequired": true,
            "CurrentPhysicianID": 0,
            "CurrentClinicID": 0,
            "NewPhysician": false,
            "IntakeID": data.intake_id,
            "ReasonID": data.car_id,
            "IsBookUnverified": false,
            "Event_Pid": 0,
            "Event_Length": 0,
            "Rec_Type": null,
            "Rec_Pattern": null,
            "CheckedInStatus": 0,
            "start_date": data.appt_date+" "+data.appt_start_time, //"2017-07-07",//
            "end_date": data.appt_end_date+" "+data.appt_end_time, //"2017-07-07",//
            "CurrentView": null
        }
         return this._cs.addOrModifyAppointment(params, url).map(res => res.json());
    }

    cancelAppointment(appt_id: number) {
        let url = this.config.cancelAppointment + appt_id;
        return this._cs.cancelAppointment(url).map(res => res.json());
    }


    GetClinicSchedularPage() {
        let url = this.config.GetClinicSchedularPage + "/" + localStorage.getItem('clinicId');
        return this._cs.GetClinicSchedularPage(url).map(res => res.json());
    }

    GetUpcomingOrPreviousAppointments() {
        let url = this.config.getUpcomingOrPreviousAppointments + "/" + localStorage.getItem('user_role') + "/" + localStorage.getItem('mvcUserId') + "/" + localStorage.getItem('clinic_clinic_Id') + "/0";
        return this._cs.GetUpcomingOrPreviousAppointments(url).map(res => res.json());
    }

    GetUpcomingOrPreviousAppointmentsSingle(dropVal: any) {
        let url = this.config.getUpcomingOrPreviousAppointments + "/" + localStorage.getItem('user_role') + "/" + dropVal + "/" + localStorage.getItem('clinic_clinic_Id') + "/0";
        //let url = this.config.getUpcomingOrPreviousAppointments + "/"+ localStorage.getItem('user_role') +"/"+ localStorage.getItem('mvcUserId') +"/"+ localStorage.getItem('clinic-clinic-Id') +"/1";
        return this._cs.GetUpcomingOrPreviousAppointments(url).map(res => res.json());
    }

    VerifyPatientPerms() {
        let url = this.config.VerifyPatientPerms + "/" + localStorage.getItem('clinic-clinic-Id');
        return this._cs.VerifyPatientPerms(url).map(res => res.json());
    }

    GetPatientByPatientId(valuePatient: any) {
        let url = this.config.getPatientByPatientId + "/" + valuePatient;
        return this._cs.GetPatientByPatientId(url).map(res => res.json());
    }


    getApptRequests() {
        let url = this.config.getConsultationRequests + "/" + localStorage.getItem('userRole') + "/" + localStorage.getItem('mvcUserId') + "/86/0";
        return this._cs.getAppoinmentReqList(url).map(res => res.json());
    }
    updateRequests(data: any) {
        let url = this.config.updateConsultationRequest;
        let reqPara = {
            "Consultation_Request_Id": data.Consultation_Request_Id,
            "Consultation_Status_Id": data.Consultation_Status_Id,
            "Declined_Notes": data.Declined_Notes
        }
        return this._cs.updateAppRequests(reqPara, url).map(res => res.json());
    }

    /**
     * @method insertConferenceStatus(param)
     * 
     * @param {any} data - Request data to insert conference status 
     * @return {Observable} By applying a function to each item
     * @desc Insert Conference status before initiating video call.
     */
    insertConferenceStatus(data: any) {
        let url = this.config.insertConferenceStatus;
        let params = {
            "APNOTIFY_ID": 0,
            "Appt_ID": data.Appt_Id, //1771,
            "Clinic_ID": data.Clinic_ID, // 86,
            "Provider_ID": data.Provider_ID, // 97,
            "Patient_ID": data.Patient_ID, // 352,
            "Patient_Joined": data.Patient_Joined, // true if patient has joined,
            "Provider_Notified": false,
            "Provider_Joined": data.Provider_Joined, // true if provider has joined
        }

        return this._cs.insertConferenceStatus(params, url).map(res => res.json());
    }

    insertConferenceRoom(data: any) {
        let url = this.config.insertConferenceRoom;
        let params = {
            "Appt_Id": 0,
            "Queue_Id": data.Queue_Id,
            "Room_Link": "",
            "Room_Link_Created_By": data.Room_Link_Created_By,
            "Plugin": "opentok"
        }

        return this._cs.insertConferenceRoom(params, url).map(res => res.json());
    }

    telemedRequestItems(data: any) {
        let url = this.config.telemedRequestList;
        let params = {
            "Clinic_Id": data.Clinic_Id,
        }

        return this._cs.telemedRequest(params, url).map(res => res.json());
    }

    Sendappoinmentemail(data: any) {
        let url = this.config.sendappoinmentemai;
        let params = {
            "AppointmentId": data.AppointmentId,
            "QueueId": data.QueueId
        }
        return this._cs.sendappoinmentemail(params, url).map(res => res.json());
    }

    cancelledQueue(data: any) {
        let url = this.config.cancelledQueue;
        let params = {
            "Queue_Id": data.Queue_Id,
            "Status": "CRPFQ",
        }

        return this._cs.cancelledQueue(params, url).map(res => res.json());
    }

    /**
     * @method getVideoRoomLink(param)
     * 
     * @param {number} appt_id - Appointment id to get video room link id.
     * @return {Observable} .map() By applying a function to each item
     * @desc Get video room link id to initiate the video call using WebRTC plugin.
     */
    getVideoRoomLink(appt_id: number) {
        let url = this.config.getVideoRoomLink + appt_id + '/' + 0;

        return this._cs.getVideoRoomLink(url).map(res => res.json());
    }

    /**
     * @method getVideoCallStatus(param)
     * 
     * @param appt_id 
     * 
     * @desc Get video call status to disconnect it after specific period of time
     */
    getVideoCallStatus(appt_id: number) {
        let url = this.config.getVideoCallStatus + appt_id;

        return this._cs.getVideoCallStatus(url).map(res => res.json());
    }

    /**
     * @method createVideoChatRomm(param) 
     * 
     * @param data Request parameter to create video chat room
     * @return {Observable} .map() By applying a function to each item
     * @desc Create video room to initiate the video call between two parties using WebRTC plugin. 
     */
    createVideoChatRoom(data: any) {
        let url = this.config.createVideoChatRoom;
        let params = {
            "Appt_Id": data.Appt_Id, // 1771,
            //"Room_Link": "videConfernceBWPaPr" + data.Appt_Id, // "appt id",
            "Room_Link": "", // "appt id",
            "Room_Link_Created_By": localStorage.getItem('userRole'), // "Patients" or "Clinics"
            "Plugin": "opentok"
        }

        return this._cs.createVideoChatRomm(params, url).map(res => res.json());
    }

    /**
     * @method endVideoCall(param)
     * 
     * @param {number} videoConferenceId Video conference id to end video call
     * @return {Observable} .map() By applying a function to each item
     * @desc Create Log entry while video call is ended
     */
    endVideoCall(videoConferenceId: number) {
        let url = this.config.endVideoCall + videoConferenceId;

        return this._cs.endVideoCall(url).map(res => res.json());
    }

    joinNowget(data: any) {
        let url = this.config.joinNowGet + "/" + "opentok" + "/" + 0 + "/" + data;
        return this._cs.joinnowGet(url).map(res => res.json());
    }

    /**
     * @method updatePatientProviderConnectedStatus()
     * 
     * @param {number} appt_id Appointment ID to update the connected status
     * @return {Observable} .map() By applying a function to each item
     * @desc Update the status when patient and provider both are connected in video call
     */
    updatePatientProviderConnectedStatus(appt_id: number) {
        let url = this.config.updatePatientProviderConnectedStatus;
        let params = {
            "Appt_ID": appt_id, //1776,
            "Patient_Provider_Connected": true
        }

        return this._cs.updatePatientProviderConnectedStatus(params, url).map(res => res.json());
    }

    updatePatientProviderConnectedStatusclinics(Queue_Id: number) {
        let url = this.config.updatePatientProviderConnectedStatus;
        let params = {
            "Appt_ID": 0, //1776,
            "Queue_Id": Queue_Id,
            "Patient_Provider_Connected": true
        }

        return this._cs.updatePatientProviderConnectedStatus(params, url).map(res => res.json());
    }


    /**
     * @method enableMyAppointmentTurnEmail()
     * 
     * @param {Object} appt_id Appointment ID to enable email 
     * @return {Observable} .map() By applying a function to each item
     * @desc Enable/Send my appointment turn email
     */
    enableMyAppointmentTurnEmail(appt_id: number) {
        let url = this.config.enableMyAppointmentTurnEmail;
        let params = {
            "AppointmentId": appt_id //105
        }

        return this._cs.enableMyAppointmentTurnEmail(params, url).map(res => res.json());
    }

    /**
     * @method addorModifyProviderNote()
     * 
     * @param {Object} data Request parameters to add provider note
     * @return {Observable} .map() By applying a function to each item
     * @desc Add provider note at the time of video call.
     */
    addorModifyProviderNote(data: any) {
        let url = this.config.addorModifyProviderNote;
        let params: any = {
            "New_Note": true,
            "Note_Id": 0,
            "Patient_Id": data.Patient_ID,//294,
            "Provider_Id": data.Provider_ID,//96,
            "Provider_First_Name": data.Provider_First_Name,// "Saanthasheelan",
            "Provider_Last_Name": data.Provider_Last_Name,//"SS",
            "Note_Subject": null,
            "Note_Text": data.Note_Text,// "Need to analyse health condition",
            //"Created_Date_Time": "2017-06-30T18:11:33.8189656+05:30"
        }

        return this._cs.addorModifyProviderNote(params, url).map(res => res.json());
    }

    UpdateClinic(clinicData: any) {
        let url = this.config.updateClinicUrl;
        let objClinic: any = {
            "Clinic_ID": clinicData.Clinic_ID,
            "ParentClinic_ID": clinicData.ParentClinic_ID,
            "ParentClinicUserName": clinicData.ParentClinicUserName,
            "Clinic_User_Name": clinicData.Clinic_User_Name,
            "Clinic_Name": clinicData.Clinic_Name,
            "Clinic_Logo_URL": clinicData.Clinic_Logo_URL,
            "WebSite_Link": clinicData.WebSite_Link,
            "TimeSlot_First_Visit": clinicData.TimeSlot_First_Visit,
            "TimeSlot_Follow_Up": clinicData.TimeSlot_Follow_Up,
            "Payment_Status": clinicData.Payment_Status,
            "Access_Clinic_Patient": clinicData.Access_Clinic_Patient,
            "Address": clinicData.Address,
            "Admin_First_Name": clinicData.Admin_First_Name,
            "Admin_Last_Name": clinicData.Admin_Last_Name,
            "Profile_Status": clinicData.Profile_Status,
            "Email": clinicData.Email,
            "Allowed_Appointment_Types": clinicData.Allowed_Appointment_Types,
            "Clinic_Description": clinicData.Clinic_Description,
            "MVCUser_Permissions": clinicData.MVCUser_Permissions,
            "Verify_Patients": clinicData.Verify_Patients,
            "Book_Unverified_Patients": clinicData.Book_Unverified_Patients,
            "Clinic_Searchable": clinicData.Clinic_Searchable,
            "BookingWithUs": clinicData.BookingWithUs,
            "PriceRange": clinicData.PriceRange
        }
        return this._cs.updateClinic(objClinic, url).map(res => res.json());
    }

    UpdateProvider(providerData: any, role: string) {
        let url = this.config.updateProviderURL + "/" + role;
        let objProvider: any = {
            "Provider_Id": providerData.Provider_Id,
            "Clinic_Id": providerData.Clinic_Id,
            "Clinic_Name": providerData.Clinic_Name,
            "Provider_First_Name": providerData.Provider_First_Name,
            "Provider_Last_Name": providerData.Provider_Last_Name,
            "Provider_UserName": providerData.Provider_UserName,
            "Provider_Type": providerData.Provider_Type,
            "Provider_Status": providerData.Provider_Status,
            "Provider_License_No": providerData.Provider_License_No,
            "Gender": providerData.Gender,
            "Email": providerData.Email,
            "Profile_Status": providerData.Profile_Status,
            "Appt_Days_Allowed": providerData.Appt_Days_Allowed,
            "Appt_Allow_SameDay_Booking": providerData.Appt_Allow_SameDay_Booking,
            "Appt_Hours_Ahead_Booking": providerData.Appt_Hours_Ahead_Booking,
            "Provider_Position": providerData.Provider_Position,
            "address": providerData.address,
            "ProviderClinicRelations": providerData.ProviderClinicRelations,
            "Communication_Permissions": providerData.Communication_Permissions,
            "MVCUser_Permissions": providerData.MVCUser_Permissions,
            "BillingRequired": providerData.BillingRequired,
            "BillingNumber": providerData.BillingNumber,
            "BillingType": providerData.BillingType
        }
        return this._cs.updateProvider(objProvider, url).map(res => res.json());
    }

    getMyPatientList(role: string, mvcid: number, clinicid: number) {
        return this._cs.getMyPatientList(this.config.getPatientList + role + '/' + mvcid + '/' + clinicid)
            .map(response => response.json());
    }

    activateDeactivateProviders(request: any) {
        let url = this.config.activateDeactivateProviders;
        let req: any = {
            "Clinic_Id": request.Clinic_Id,
            "Provider_Id": request.Provider_Id,
            "Provider_UserName": request.Provider_UserName,
            "User_Role": request.User_Role,
            "Update_Status_Id": request.Update_Status_Id
        }
        return this._cs.activateDeactivateProviders(req, url).map(res => res.json());
    }

    addClinicPhases(Clinic_Stage_ID: number, Stage_TXT: string, Description: string) {
        let reqParam: object = {
            "Clinic_Stage_ID": Clinic_Stage_ID,
            "Clinic_ID": localStorage.getItem('clinic-clinic-Id'),
            "Stage_TXT": Stage_TXT,
            "Description": Description,
            "Created_Date": "",
            "Edited_Date": "",
            "IsDeleted": false
        }
        return this._cs.addOrModifyPhases(JSON.stringify(reqParam), this.config.addUpdateClinicPhases).map(res => res.json());
    }

    deleteClinicPhases(Clinic_Stage_ID: number, Stage_TXT: string, Description: string) {
        let reqParam: object = {
            "Clinic_Stage_ID": Clinic_Stage_ID,
            "Clinic_ID": localStorage.getItem('clinic-clinic-Id'),
            "Stage_TXT": Stage_TXT,
            "Description": Description,
            "Created_Date": "",
            "Edited_Date": "",
            "IsDeleted": true
        }
        return this._cs.addOrModifyPhases(JSON.stringify(reqParam), this.config.addUpdateClinicPhases).map(res => res.json());
    }

    addReferredByOptions(Referred_By_Id: number, Referred_By_Type: string, RequireMoreInfo: boolean, MoreInfo_Label: string, MoreInfo_Value: string) {
        let reqParam: object = {
            "Referred_By_Id": Referred_By_Id,
            "Referred_By_Type": Referred_By_Type,
            "Clinic_ID": localStorage.getItem('clinic-clinic-Id'),
            "RequireMoreInfo": RequireMoreInfo,
            "MoreInfo_Label": MoreInfo_Label,
            "MoreInfo_Value": MoreInfo_Value,
            "IsDeleted": false
        }
        return this._cs.addOrModifyReferredByOption(JSON.stringify(reqParam), this.config.addUpdateClinicReferredByOptions).map(res => res.json());
    }

    deleteReferredByOptions(Referred_By_Id: number, Referred_By_Type: string, RequireMoreInfo: boolean, MoreInfo_Label: string, MoreInfo_Value: string) {
        let reqParam: object = {
            "Referred_By_Id": Referred_By_Id,
            "Referred_By_Type": Referred_By_Type,
            "Clinic_ID": localStorage.getItem('clinic-clinic-Id'),
            "RequireMoreInfo": RequireMoreInfo,
            "MoreInfo_Label": MoreInfo_Label,
            "MoreInfo_Value": MoreInfo_Value,
            "IsDeleted": true
        }
        return this._cs.addOrModifyReferredByOption(JSON.stringify(reqParam), this.config.addUpdateClinicReferredByOptions).map(res => res.json());
    }

    getClinicStages() {
        let url = this.config.getClinicsStage + localStorage.getItem('clinic-clinic-Id') + "/true"
        return this._cs.getClinicStages(url).map(res => res.json());
    }

    getReferredByOptions() {
        let url = this.config.getReferredOptions + localStorage.getItem('clinic-clinic-Id') + "/false"
        return this._cs.getReferredByOptions(url).map(res => res.json());
    }

    /*     saveAddUpdatePatientStage(previousPatientStage: any, selectedclientStage: any, patientId: any, clientId: any) {
        let reqParam: object = {
            "Patient_Stage_ID": previousPatientStage ? previousPatientStage.Patient_Stage_ID : 0,
            "Patient_ID": previousPatientStage ? previousPatientStage.Patient_ID == 0 ? patientId : previousPatientStage.Patient_ID : patientId,
            "Clinic_ID": previousPatientStage ? previousPatientStage.Clinic_ID == 0 ? clientId : previousPatientStage.Clinic_ID : clientId,
            "Stage_ID": selectedclientStage ? selectedclientStage[0].Clinic_Stage_ID : 0,
            "Stage_TXT": selectedclientStage ? selectedclientStage[0].Stage_TXT : '',
            "Assigned_Date": ""
        }
        return this._cs.saveAddUpdatePatientStage(JSON.stringify(reqParam), this._config.addUpdatePatient).map(res => res.json());
    } */

    getMedicalDocuments(mvcUserID : number, role:string, clinicID:number, docstatus:string){
        let url = this.config.getAllDocumentUrl + mvcUserID + '/' + role + '/' + clinicID + '/' + docstatus;
        return this._cs.getMedicalDocuments(url).map(response=>response.json());       
       }

       getMedicalDocument(medicalDocId:number){
        let url = this.config.getMedicalDocument + medicalDocId;
        return this._cs.getMedicalDocument(url).map(response => response.json());
       }
}