import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SlimScrollModule } from 'ng2-slimscroll';
import { Ng2CompleterModule } from "ng2-completer";
import { CalendarComponent } from "ap-angular2-fullcalendar/src/calendar/calendar";

import { ClinicComponent } from './component/clinic/clinic.component';
import { MyDatePickerModule } from 'mydatepicker';
import { SharedModule } from "../../shared/sharedmodule/shared.module";
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";

import { ClinicRoutingModule } from './clinic.routing';
import { AppointmentComponent } from './component/appointment/component/appointment.component';
import { AppNotRegisteredComponent } from './component/appointment/component/notregistered/appointment-notregistered.component';
import { ViewAppoinment } from './component/appointment/component/view-appoinment.component';
import { AdminClinicsComponent } from "./component/admin-clinics/admin-clinics.component";
import { AdminAddClinicComponent } from "./component/admin-clinics/add-clinic/add-clinic.component";
import { AdminEditClinicComponent } from "./component/admin-clinics/edit-clinic/edit-clinic.component";
import { AdminAddProviderComponent } from "./component/admin-clinics/add-provider/add-provider.component";
import { AdminEditProviderComponent } from "./component/admin-clinics/edit-provider/edit-provider.component";
import { AdminProviderLayoutComponent } from "./component/admin-clinics/provider-layout/provider-layout.component";
import { MedicalDocumentsComponent } from "./component/admin-clinics/medical-documents/medical-documents.component";
import { SupplierRegistrationComponent } from './component/admin-clinics/medical-documents/supplierregister/supplier-register.component';
import { AddClinicInfoComponent } from './component/admin-clinics/clinic-profile/add-clinic-info.component';
import { EditClinicInfoComponent } from './component/admin-clinics/clinic-profile/edit-clinic-info.component';
import { AdminResetPasswordComponent } from "./component/admin-clinics/reset-password/reset-password.component";
import { ViewProviderComponent } from "./component/admin-clinics/view-provider/view-provider.component";
import { PermissionComponent } from "./component/admin-clinics/permission/permission.component";
import { PhasesComponent } from "./component/admin-clinics/phases/phases.component";
import { AddPhasesComponent } from './component/admin-clinics/phases/add-phases/add-phases.component';
import { ReferredByOptionsComponent } from "./component/admin-clinics/referred-by-options/referred-by-options.component";
import { AddReferredByOptionsComponent } from './component/admin-clinics/referred-by-options/add-referred-by-options/add-referred-by-options.component';
import { AppointmentRequestComponent } from './component/admin-appointment/appointment-request/appointment-request.component';
import { ScheduleClinicComponent } from './component/schedule-clinic/schedule-clinic.component';
import { ScheduleComponent } from './component/schedule-clinic/schedule/schedule.component';
import { ViewScheduleAppoinment } from './component/schedule-clinic/view-all/view-all.component';
import { TelemedRequestComponent } from './component/schedule-clinic/telemedrequest/telemedrequest.component';
import { ClinicService } from "./service/clinic.service";
import { ClinicBusiness } from "./business/clinic.business";
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { LoaderService } from '../../shared/shared-loader/shared-loader.service';
import { Config } from "../../config/constant";
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { TextMaskModule } from 'angular2-text-mask';
import { PrintService } from "../../shared/shared-util/shared-print-service";
import { MedicalComponentModel } from '../../../app/modules/record/component/shared/medical-componentmodel';

import { OpenTokModule } from "../opentok/opentok.module";

@NgModule({
  imports: [
    ClinicRoutingModule,
    MyDatePickerModule,
    FormsModule,
    CommonModule,
    SlimScrollModule,
    Ng2CompleterModule,
    SharedServiceModule,
    SharedModule,
    TextMaskModule,
    MedicalComponentModel,
    PipeModule,
    OpenTokModule
  ],
  declarations: [
    ClinicComponent,
    AppointmentComponent,
    AppNotRegisteredComponent,
    ViewAppoinment,
    AdminClinicsComponent,
    AdminAddClinicComponent,
    AdminEditClinicComponent,
    AdminAddProviderComponent,
    AdminEditProviderComponent,
    AdminProviderLayoutComponent,
    MedicalDocumentsComponent,
    SupplierRegistrationComponent,
    AddClinicInfoComponent,
    EditClinicInfoComponent,
    AdminResetPasswordComponent,
    ViewProviderComponent,
    TelemedRequestComponent,
    PermissionComponent,
    PhasesComponent,
    AddPhasesComponent,
    ReferredByOptionsComponent,
    AddReferredByOptionsComponent,
    ScheduleClinicComponent,
    ScheduleComponent,
    ViewScheduleAppoinment,
    AppointmentRequestComponent,
    ScheduleClinicComponent,
    CalendarComponent
  ],
  providers: [
    HttpRequestService,
    Config,
    ClinicBusiness,
    ClinicService,
    PrintService
  ]
})
export class ClinicModule { }