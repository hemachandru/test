export interface Appointment {
    reason: string;
    type: string;
}