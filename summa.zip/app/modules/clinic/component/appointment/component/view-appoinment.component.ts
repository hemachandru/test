import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Subscription } from "rxjs/Subscription";

import { ClinicBusiness } from "../../../business/clinic.business";
import { LoaderService } from '../../../../../shared/shared-loader/shared-loader.service';
import { OpenTokComponent } from '../../../../opentok/component/opentok.component';

@Component({
  selector: "viewappoinment",
  templateUrl: './view-appoinment.component.html',
  styleUrls: ['./view-appoinment.component.scss']
})
export class ViewAppoinment implements OnInit, OnDestroy {
  @ViewChild('joinnowref') public joinnowref: TemplateRef<any>;
  @ViewChild('cancelref') public cancelref: TemplateRef<any>;
  @ViewChild('alertRef') public alertRef: TemplateRef<any>;
  @ViewChild('appointmentTemRef') public appointmentTemRef: TemplateRef<any>;
  @ViewChild('appointmentEndedRef') public appointmentEndedRef: TemplateRef<any>;  
  @ViewChild(OpenTokComponent) openTok: OpenTokComponent;
  dialog: DialogRef<any>;
  dialogAppt: DialogRef<any>;
  dialogApptEnd: DialogRef<any>;
  private apptList: any = [];
  private appt_id: string;
  private videoConferenceId: number;
  private doctorName: any;
  private webRTCObserver: Subscription;
  private apiKey: string;
  private sessionId: string;
  private token: string;
  private isUserConnected: boolean;
  private content: string;
  private appointmentId: number;
  private videoCallStatusId: any;

  constructor(private _cb: ClinicBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _ls: LoaderService) {
    overlay.defaultViewContainer = vcRef;
    this.isUserConnected = false;
  }
  ngOnInit() {
    this.getUpcomingAppt();
  }
  onBookAppointment() {
    this._cb.sendEditApptEvent(false);
    this._cb.sendEditApptIdEvent(0);
    this._cb.sendEditApptFlagEvent(false);
    let id = localStorage.app_clinic_id || 0;
    this.router.navigate(['clinics/appointment', id]);
  }
  onEditorReschedule(app_Id: any) {
    let id = localStorage.app_clinic_id || 0;
    this._cb.sendEditApptEvent(true);
    this._cb.sendEditApptIdEvent(app_Id);
    this._cb.sendEditApptFlagEvent(true);
    this.router.navigate(['clinics/appointment', id]);
  }
  onJoinNow(appt: any) {
    this.doctorName = appt.Provider_First_Name;
    this.appointmentId = appt.Appointment_Id;
    this.insertConferenceStatus(appt);    
  }
  callDisconnected(event: Event) {
    console.log(event);
    this.onClose();
  }

  subStreamCreated(event: Event) {
    this.isUserConnected = true;
  }

  publisherJoined(event: any) {
    let self = this;
    this.videoCallStatusId = setInterval(() => {
      self._cb.getVideoCallStatus(self.appointmentId).subscribe(res => {
        if(res.Response_Code == 2 && res.CallEnded) {
          self.openTok.disconnectWithOutEvent();
          self.dialog.close();
          clearInterval(self.videoCallStatusId);
          return self.modal.open(self.appointmentEndedRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
              self.dialogApptEnd = dialog;
              return dialog.result.then(res => {
                this.getUpcomingAppt();
              });              
            })
        }
      })
    }, 60000)
    
  }
  closeApptEnd() {
    this.dialogApptEnd.close();
  }

  insertConferenceStatus(appt: any) {
    this._ls.display(true);
    let param = {
      Appt_Id: appt.Appointment_Id,
      Clinic_ID: appt.Clinic.Clinic_Id,
      Provider_ID: appt.Provider_Id,
      Patient_ID: appt.Patient_Id,
      Patient_Joined: true,
      Provider_Joined: false
    };
    this._cb.insertConferenceStatus(param).subscribe(res => {
      this._ls.display(false);
      if (res.Response_Code == 1 || appt.Clinic.Clinic_Id<=0 || appt.Provider_Id<=0 || appt.Patient_Id<=0) {
        this.getVideoLink(appt);
      }
    })
  }

  getVideoLink(appt: any) {
    this._ls.display(true);
    this._cb.getVideoRoomLink(appt.Appointment_Id).subscribe(res => {
      let self = this;
      this._ls.display(false);
      if (res.hasOwnProperty("Room_Link") && res.Room_Link != null) {
        this.apiKey = res.Api_Key;
        this.sessionId = res.Room_Link;
        this.token = res.Token;
        this.videoConferenceId = res.Video_Conference_Id;
        if(res.Room_Link != null) {
          return this.modal.open(this.joinnowref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
          .then(dialog => {
            this.dialog = dialog;
            setTimeout(function() {
                self.openTok.initializeSession();  
            }, 10);
            return dialog.result.then(res => {
              if (this.isUserConnected) {
                this.endVideoCall(this.videoConferenceId);
                this.getUpcomingAppt();
              } 
              this.openTok.disconnectWithOutEvent();
              if(this.videoCallStatusId) {
                clearInterval(this.videoCallStatusId);
              } 
            });
          });
        }
        return false;
      }
      let params = {
        Appt_Id: appt.Appointment_Id
      }
      this._ls.display(true);
      this._cb.createVideoChatRoom(params).subscribe(res => {
        this._ls.display(false);
        if (res == "Success") {
          this.getVideoLink(appt);
        } else if (res == "Not user turn") {
            let str = "Please wait till your scheduled Appointment time occurs."
            this.showAlertMsg(str);
        } else if (res == "Appointment is in past") {
            let str = "The Scheduled Appointment time has been ended. Please contact the Clinic."
            this.showAlertMsg(str);
        } else if (res == "Invalid appointment id") {
            let str = "Incorrect Appointment Schedule. Please contact the Clinic."
            this.showAlertMsg(str);
        } else {
            let str = "An unexpected error occur. Please contact the Clinic."
            this.showAlertMsg(str);
        }
      })
    })
  }
  onClose() {
    this.dialog.close(true);
  }
  endVideoCall(conf_id: number) {
    if (conf_id) {
      this._cb.endVideoCall(conf_id).subscribe(res => {
        if (res == "Success") {
          console.log('Appt. Ended!!');
        }
      })
    }
  }
  onCancel(id: string) {
    this.appt_id = id;
    return this.modal.open(this.cancelref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onCancelClose() {
    this.dialog.close();
  }

  getUpcomingAppt() {
    this._ls.display(true);
    this.apptList = [];
    this._cb.getUpcomingAppointmentList().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.apptList = res;
      } else {
        this.apptList = [];
      }
    })
  }

  cancelAppointment() {
    this._ls.display(true);
    this._cb.cancelAppointment(parseInt(this.appt_id)).subscribe(res => {
      this.onCancelClose();
      this.getUpcomingAppt();
    })
  }
  showAlertMsg(value: string) {
      this.content = value;
      this.modal.open(this.alertRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
          .then(dialog => {
          this.dialog = dialog;
          })
  }
  closeAlert() {
      this.dialog.close();
  }
  ngOnDestroy() {
    if (this.webRTCObserver) {
      this.webRTCObserver.unsubscribe();
    }

    if (this.videoCallStatusId) {
      clearInterval(this.videoCallStatusId);
    }    
  }
}