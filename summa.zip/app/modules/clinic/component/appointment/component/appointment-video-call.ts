import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

//import { ClinicBusiness } from "../../../business/clinic.business";

declare const RTCMultiConnection: any;
declare const getMediaElement: any;
declare const document: any;
declare const window: any;
declare const URL: any;
declare const attachMediaStream: any;

//@Injectable()
export class VideoAppointment {
    private isAudioMute: boolean = false;
    private isVideoMute: boolean = false;
    private webRTCUserConnectedObserver = new BehaviorSubject(false);
    public webRTCUserConnected$: Observable<any>;

    constructor() {
        //this.webRTCUserConnected$ = this.webRTCUserConnectedObserver.asObservable();
    }

    sendUserConnectedEvent(event: any) {
        this.webRTCUserConnectedObserver.next(event);
    }

    onUserConnected() {
        return this.webRTCUserConnectedObserver.asObservable();
    }

    initiateVideoCall(roomId: string, RTCinstance: any, modalInstance: any) {
        let self = this;
        let connection = RTCinstance;
        let dialog = modalInstance;
        // var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
        // var isIE = !!document.documentMode;
        // var isPluginRTC = isSafari || isIE;


        // *** Plugin.EveryWhere.js [BEGIN]
        var Plugin: any = {};
        window.onPluginRTCInitialized = function (pluginRTCObject: any) {
            Plugin = pluginRTCObject;
            MediaStreamTrack = Plugin.MediaStreamTrack;
            RTCPeerConnection = Plugin.RTCPeerConnection;
            RTCIceCandidate = Plugin.RTCIceCandidate;
            RTCSessionDescription = Plugin.RTCSessionDescription;
        };
        if (!!window.PluginRTC) window.onPluginRTCInitialized(window.PluginRTC);


        var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
        var isIE = !!document.documentMode;
        var isPluginRTC = isSafari || isIE;
        // ......................................................
        // .......................UI Code........................
        // ......................................................
        // document.getElementById('open-room').onclick = function () {
        //   connection.open("test", function () {
        //   });
        // };
        // document.getElementById('join-room').onclick = function () {
        //   connection.checkPresence("test", function (isRoomExists: boolean) {
        //     if (isRoomExists) {
        //       connection.join("test");
        //       return;
        //     }
        //     connection.join("open");
        //   });
        // };

        // ......................................................
        // ..................RTCMultiConnection Code.............
        // ......................................................
        //self.connection = new RTCMultiConnection();

        // connection.trickleIce = false;
        connection.processSdp = function (sdp: any) { return sdp; };
        // by default, socket.io server is assumed to be deployed on your own URL
        //connection.socketURL = 'https://192.168.1.100:8197/';
        // comment-out below line if you do not have your own socket.io server
        //connection.socketURL = 'https://rtcmulticonnection.herokuapp.com:443/';
        connection.socketURL = 'https://sail-webrtc.ihorsetechnologies.com/';

        connection.socketMessageEvent = 'video-conference-demo';
        connection.session = {
            audio: true,
            video: true
        };
        connection.sdpConstraints.mandatory = {
            OfferToReceiveAudio: true,
            OfferToReceiveVideo: true
        };
        connection.localVideosContainer = document.getElementById('local-videos-container');
        connection.remoteVideosContainer = document.getElementById('remote-videos-container');
        connection.onstream = function (event: any) {
            var continer = (event.type == "local") ? "localVideosContainer" : "remoteVideosContainer";
            if (isPluginRTC) {
                var mediaElement = document.createElement("videos-container");
                var mediaElement = event.mediaElement;
                window.myevent = event;
                console.log(mediaElement);

                // var body = (document.body || document.documentElement);
                // body.insertBefore(mediaElement, body.firstChild);

                setTimeout(function () {
                    //Plugin.attachMediaStream(mediaElement, event.stream);
                    attachMediaStream(mediaElement, event.stream);
                    connection[continer].appendChild(mediaElement);
                    mediaElement.id = event.streamid;
                }, 3000);
            } else {
                var width = connection[continer].clientWidth;
                var options = {
                    title: event.userid,
                    buttons: [''],
                    onStopped: function () {
                        dialog.close(true);
                        connection.attachStreams.forEach(function (localStream: any) {
                            localStream.stop();
                        });

                        document.getElementById("remote-videos-container").innerHTML = "";

                        connection.closeSocket();
                    },
                    onMuted: function (type: any) {
                        connection.streamEvents[event.streamid].stream.mute(type);
                    },
                    onUnMuted: function (type: any) {
                        connection.streamEvents[event.streamid].stream.unmute(type);
                    },
                    width: width,
                    showOnMouseEnter: false
                }
                if (event.type == "remote") {
                    options.buttons = ['full-screen', 'mute-audio', 'stop'];
                }
                let mediaElement = getMediaElement(event.mediaElement, options);
                connection[continer].appendChild(mediaElement);
                setTimeout(function () {
                    mediaElement.media.play();
                }, 5000);
                mediaElement.id = event.streamid;
            }

            let connectedUser = connection.getAllParticipants().length;
            if(connectedUser > 0) {
                self.sendUserConnectedEvent(true);
                //self.emitter.emit();
            }
        };
        connection.onstreamended = function (event: any) {
            var mediaElement = document.getElementById(event.streamid);
            if (mediaElement) {
                mediaElement.parentNode.removeChild(mediaElement);
            }
        };

        // if local or remote stream is muted
        connection.onmute = function (e: any) {
            if (e.session.audio && !e.session.video) {
                e.mediaElement.muted = true;
                return;
            }
            e.mediaElement.pause();
        };

        // if local or remote stream is unmuted
        connection.onunmute = function (e: any) {
            if (e.session.audio && !e.session.video) {
                e.mediaElement.muted = false;
                return;
            }
            e.mediaElement.play();
        };
        
        connection.checkPresence(roomId, function (isRoomExists: boolean) {
            if (isRoomExists) {
                connection.join(roomId);
                return;
            }
            connection.open(roomId, function () {
                console.log("test connected");
            });
        });
    }
}