import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, ActivatedRoute, Params, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Subscription } from "rxjs/Subscription";

import { LayoutComponent } from "../../../../layout/component/layout.component";

import { Appointment } from '../entity/appointment.entity';
import { MyDatePicker } from 'mydatepicker';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';

import { ClinicBusiness } from "../../../business/clinic.business";
import { SharedObserverService } from '../../../../../shared/shared-service-module/shared-observer.service';
import { LoaderService } from '../../../../../shared/shared-loader/shared-loader.service';
import { Config } from "../../../../../config/constant";

const time_slot_15_min = [
  { id: 1, value: "12.00 AM", time: "00:00:00", disable: false },
  { id: 2, value: "12.15 AM", time: "00:15:00", disable: false },
  { id: 3, value: "12.30 AM", time: "00:30:00", disable: false },
  { id: 4, value: "12.45 AM", time: "00:45:00", disable: false },

  { id: 5, value: "01.00 AM", time: "01:00:00", disable: false },
  { id: 6, value: "01.15 AM", time: "01:15:00", disable: false },
  { id: 7, value: "01.30 AM", time: "01:30:00", disable: false },
  { id: 8, value: "01.45 AM", time: "01:45:00", disable: false },

  { id: 9, value: "02.00 AM", time: "02:00:00", disable: false },
  { id: 10, value: "02.15 AM", time: "02:15:00", disable: false },
  { id: 11, value: "02.30 AM", time: "02:30:00", disable: false },
  { id: 12, value: "02.45 AM", time: "02:45:00", disable: false },

  { id: 13, value: "03.00 AM", time: "03:00:00", disable: false },
  { id: 14, value: "03.15 AM", time: "03:15:00", disable: false },
  { id: 15, value: "03.30 AM", time: "03:30:00", disable: false },
  { id: 16, value: "03.45 AM", time: "03:45:00", disable: false },

  { id: 17, value: "04.00 AM", time: "04:00:00", disable: false },
  { id: 18, value: "04.15 AM", time: "04:15:00", disable: false },
  { id: 19, value: "04.30 AM", time: "04:30:00", disable: false },
  { id: 20, value: "04.45 AM", time: "04:45:00", disable: false },

  { id: 21, value: "05.00 AM", time: "05:00:00", disable: false },
  { id: 22, value: "05.15 AM", time: "05:15:00", disable: false },
  { id: 23, value: "05.30 AM", time: "05:30:00", disable: false },
  { id: 24, value: "05.45 AM", time: "05:45:00", disable: false },

  { id: 25, value: "06.00 AM", time: "06:00:00", disable: false },
  { id: 26, value: "06.15 AM", time: "06:15:00", disable: false },
  { id: 27, value: "06.30 AM", time: "06:30:00", disable: false },
  { id: 28, value: "06.45 AM", time: "06:45:00", disable: false },

  { id: 29, value: "07.00 AM", time: "07:00:00", disable: false },
  { id: 30, value: "07.15 AM", time: "07:15:00", disable: false },
  { id: 31, value: "07.30 AM", time: "07:30:00", disable: false },
  { id: 32, value: "07.45 AM", time: "07:45:00", disable: false },

  { id: 33, value: "08.00 AM", time: "08:00:00", disable: false },
  { id: 34, value: "08.15 AM", time: "08:15:00", disable: false },
  { id: 35, value: "08.30 AM", time: "08:30:00", disable: false },
  { id: 36, value: "08.45 AM", time: "08:45:00", disable: false },

  { id: 37, value: "09.00 AM", time: "09:00:00", disable: false },
  { id: 38, value: "09.15 AM", time: "09:15:00", disable: false },
  { id: 39, value: "09.30 AM", time: "09:30:00", disable: false },
  { id: 40, value: "09.45 AM", time: "09:45:00", disable: false },

  { id: 41, value: "10.00 AM", time: "10:00:00", disable: false },
  { id: 42, value: "10.15 AM", time: "10:15:00", disable: false },
  { id: 43, value: "10.30 AM", time: "10:30:00", disable: false },
  { id: 44, value: "10.45 AM", time: "10:45:00", disable: false },

  { id: 45, value: "11.00 AM", time: "11:00:00", disable: false },
  { id: 46, value: "11.15 AM", time: "11:15:00", disable: false },
  { id: 47, value: "11.30 AM", time: "11:30:00", disable: false },
  { id: 48, value: "11.45 AM", time: "11:45:00", disable: false },

  { id: 49, value: "12.00 PM", time: "12:00:00", disable: false },
  { id: 50, value: "12.15 PM", time: "12:15:00", disable: false },
  { id: 51, value: "12.30 PM", time: "12:30:00", disable: false },
  { id: 52, value: "12.45 PM", time: "12:45:00", disable: false },

  { id: 53, value: "01.00 PM", time: "13:00:00", disable: false },
  { id: 54, value: "01.15 PM", time: "13:15:00", disable: false },
  { id: 55, value: "01.30 PM", time: "13:30:00", disable: false },
  { id: 56, value: "01.45 PM", time: "13:45:00", disable: false },

  { id: 57, value: "02.00 PM", time: "14:00:00", disable: false },
  { id: 58, value: "02.15 PM", time: "14:15:00", disable: false },
  { id: 59, value: "02.30 PM", time: "14:30:00", disable: false },
  { id: 60, value: "02.45 PM", time: "14:45:00", disable: false },

  { id: 61, value: "03.00 PM", time: "15:00:00", disable: false },
  { id: 62, value: "03.15 PM", time: "15:15:00", disable: false },
  { id: 63, value: "03.30 PM", time: "15:30:00", disable: false },
  { id: 64, value: "03.45 PM", time: "15:45:00", disable: false },

  { id: 65, value: "04.00 PM", time: "16:00:00", disable: false },
  { id: 66, value: "04.15 PM", time: "16:15:00", disable: false },
  { id: 67, value: "04.30 PM", time: "16:30:00", disable: false },
  { id: 68, value: "04.45 PM", time: "16:45:00", disable: false },

  { id: 69, value: "05.00 PM", time: "17:00:00", disable: false },
  { id: 70, value: "05.15 PM", time: "17:15:00", disable: false },
  { id: 71, value: "05.30 PM", time: "17:30:00", disable: false },
  { id: 72, value: "05.45 PM", time: "17:45:00", disable: false },

  { id: 73, value: "06.00 PM", time: "18:00:00", disable: false },
  { id: 74, value: "06.15 PM", time: "18:15:00", disable: false },
  { id: 75, value: "06.30 PM", time: "18:30:00", disable: false },
  { id: 76, value: "06.45 PM", time: "18:45:00", disable: false },

  { id: 77, value: "07.00 PM", time: "19:00:00", disable: false },
  { id: 78, value: "07.15 PM", time: "19:15:00", disable: false },
  { id: 79, value: "07.30 PM", time: "19:30:00", disable: false },
  { id: 80, value: "07.45 PM", time: "19:45:00", disable: false },

  { id: 81, value: "08.00 PM", time: "20:00:00", disable: false },
  { id: 82, value: "08.15 PM", time: "20:15:00", disable: false },
  { id: 83, value: "08.30 PM", time: "20:30:00", disable: false },
  { id: 84, value: "08.45 PM", time: "20:45:00", disable: false },

  { id: 85, value: "09.00 PM", time: "21:00:00", disable: false },
  { id: 86, value: "09.15 PM", time: "21:15:00", disable: false },
  { id: 87, value: "09.30 PM", time: "21:30:00", disable: false },
  { id: 88, value: "09.45 PM", time: "21:45:00", disable: false },

  { id: 89, value: "10.00 PM", time: "22:00:00", disable: false },
  { id: 90, value: "10.15 PM", time: "22:15:00", disable: false },
  { id: 91, value: "10.30 PM", time: "22:30:00", disable: false },
  { id: 92, value: "10.45 PM", time: "22:45:00", disable: false },

  { id: 93, value: "11.00 PM", time: "23:00:00", disable: false },
  { id: 94, value: "11.15 PM", time: "23:15:00", disable: false },
  { id: 95, value: "11.30 PM", time: "23:30:00", disable: false },
  { id: 96, value: "11.45 PM", time: "23:45:00", disable: false },

]


@Component({
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit, OnDestroy {
  public personOpacity: any;
  public dateOpacity: any;
  appointment: Appointment;
  public opts: ISlimScrollOptions;
  public date = new Date();
  highlightedDiv: number;
  highlightedDateDiv: number;
  private clinicDetails: any = {};
  private listOfReason: any = [];
  private providerList: any = [];
  private clinicId: number;
  private schedule: any = {};
  private selectedDate: any = {};
  private userDetails: any = {};
  private profileObserver: Subscription;
  private editApptObserver: Subscription;
  private editApptIdObserver: Subscription;
  private editApptFlagObserver: Subscription;
  private isEditableFlag: boolean = false;
  private editAppId: number = 0;
  private editAppFlag: boolean = true;
  //private timeSlot = time_slot_30_min;
  private timeSlot = time_slot_15_min;
  private content: string;
  private isApptError: boolean = false;

  public slotArray: any;
  public mincount: any;
  public hourcount: any;
  public timecount: any;
  public min: any;
  public hour: any;
  public x: any;

  public startslotAM: any;
  public startslotPM: any;
  public endslotAM: any;
  public endslotPM: any;

  public today1: any;
  public dd: any;
  public mm: any;
  public yyyy: any;
  public n: any;
  public o: any;
  public today: any;
  public printTimeSlotAM: any = [];
  public printTimeSlotPM: any = [];
  public combineTimeSlot: any =[];

  public fromTime: any;
  public toTime: any;

  public optionAM: any = "0";
  public optionPM: any = "0";

  /**Date picker options */
  private myDatePickerInlineOptions: IMyOptions = {
    inline: true,
    showWeekNumbers: false,
    sunHighlight: false,
    showTodayBtn: false,
    yearSelector : true;
    //yearSelector: false,
    monthLabels: { 1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June', 7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December' },
    selectionTxtFontSize: '9px',
    firstDayOfWeek: 'su',
    minYear: 1900,
    disableUntil: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() - 1 }
  };

  @ViewChild('successref') public successref: TemplateRef<any>;
  @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private config: Config, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private route: ActivatedRoute, private el: ElementRef, private _cb: ClinicBusiness, private _sos: SharedObserverService, private _ls: LoaderService, private layoutComponent: LayoutComponent) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {

    let today = new Date();
    this.appointment = {
      reason: '',
      type: ''
    }

    this.schedule = {
      start_time: '',
      end_time: '',
      date: {
        date: {
          year: today.getFullYear(),
          month: today.getMonth() + 1,
          day: today.getDate()
        }
      },
      provider_id: 0,
      timeslot: '',
      patient_id: 0,
      clinic_id: 0,
      appt_date: '',
      appt_end_date: '',
      appt_start_time: '',
      appt_end_time: '',
      reason: '',
      user_role: '',
      user_name: '',
      type: '',
      intake_id: 0
    }
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    this.route.params.subscribe((params: Params) => {
      if (params['clinic_id']) {
        let id = params['clinic_id'];
        this.clinicId = parseInt(id);
        this.schedule.clinic_id = this.clinicId;
        this.getClinicDetail(this.clinicId);
        this.getApptReason(this.clinicId);
      }
    });

    this.profileObserver = this._sos.profileEventReceiver$.subscribe(res => {
      if (res == true) {
        return false;
      }
      this.schedule.patient_id = res.Patient_Login_Data.Patient_ID;
      this.schedule.user_role = res.User_Role;
      this.schedule.user_name = res.Patient_Login_Data.Patient_User_Name;
      this.schedule.intake_id = res.Patient_Login_Data.Recent_Intake_Form_ID;
    });

    this.editApptObserver = this._cb.editApptReceiver$.subscribe(res => {
      this.isEditableFlag = false;
      if (res) {
        this.isEditableFlag = res;
        return;
      }
      this.getUpcomingAppointment();
    })

    this.editApptFlagObserver = this._cb.editApptFlagReceiver$.subscribe(res => {
      if (res == true) {
        this.editAppFlag = res;
        this.editApptIdObserver = this._cb.editApptIdReceiver$.subscribe(res1 => {
          if (res1 > 0) {
            this.editAppId = res1;
          } else {
            this.editAppId = 0;
          }
        });
      } else {
        this.editAppFlag = false;
      }
    });

  }

  onInputFieldChanged(value: IMyInputFieldChanged) {
    this.selectedDate = value.value;

    //alert('changed date : ' + value.value);

    // this.printTimeSlotAM = [];
    // this.printTimeSlotPM = [];

    this.today1 = new Date();
    this.dd = this.today1.getDate();
    this.mm = this.today1.getMonth() + 1;
    this.yyyy = this.today1.getFullYear();
    this.n = this.mm.toString().length;
    if (this.n === 1) {
      this.mm = "0" + this.mm;
    }
    this.o = this.dd.toString().length;
    if (this.o === 1) {
      this.dd = "0" + this.dd;
    }
    this.today = this.yyyy + "-" + this.mm + "-" + this.dd;

    this.x = new Date();
    this.hour = this.x.getHours();
    this.min = this.x.getMinutes();
    this.hourcount = this.hour * 4;
    this.mincount = this.min / 15;

    this.startslotAM = this.timeSlot[31].id;
    this.endslotAM = this.timeSlot[46].id;

    this.startslotPM = this.timeSlot[47].id;
    this.endslotPM = this.timeSlot[78].id;

    //alert(this.timeSlot[48].value +"--"+ this.timeSlot[79].value);  46

    if (value.value == this.today) {
      this.timecount = Math.floor(this.mincount) + this.hourcount + 1;

      //alert('same day : '+this.timecount);
      this.printTimeSlotAM = [];
      this.printTimeSlotPM = [];
      this.combineTimeSlot = [];
      for (let i = parseInt(this.timecount); i <= 96; i++) {
        if (i >= parseInt(this.startslotAM) && i <= parseInt(this.endslotAM)) {
          this.printTimeSlotAM.push(this.timeSlot[i]);
        }
      }

      for (let i = parseInt(this.timecount); i <= 96; i++) {
        if (i >= parseInt(this.startslotPM) && i <= parseInt(this.endslotPM)) {
          this.printTimeSlotPM.push(this.timeSlot[i]);
        }
      }
     this.combineTimeSlot = this.printTimeSlotAM.concat(this.printTimeSlotPM); 

      // =======
      //       this.optionAM="0";
      //       this.optionPM="0";
      // //alert('changed date : ' + value.value);
      // >>>>>>> develop

    } else {
      this.printTimeSlotAM = [];
      this.printTimeSlotPM = [];
       this.combineTimeSlot = [];

      this.timecount = 0;
      for (let i = parseInt(this.timecount); i <= 96; i++) {
        if (i >= parseInt(this.startslotAM) && i <= parseInt(this.endslotAM)) {
          this.printTimeSlotAM.push(this.timeSlot[i]);
        }
      }

      for (let i = parseInt(this.timecount); i <= 96; i++) {
        if (i >= parseInt(this.startslotPM) && i <= parseInt(this.endslotPM)) {
          this.printTimeSlotPM.push(this.timeSlot[i]);
        }
      }
      this.combineTimeSlot = this.printTimeSlotAM.concat(this.printTimeSlotPM); 

    }
    this.schedule.appt_date = value.value;
    this.schedule.appt_end_date = value.value;
    // =======
    //         this.today = this.yyyy + "-" + this.mm + "-" + this.dd;

    //         this.x = new Date();
    //             this.hour = this.x.getHours();
    //             this.min = this.x.getMinutes();
    //             this.hourcount = this.hour * 4;
    //             this.mincount = this.min / 15;

    //             this.startslotAM = this.timeSlot[31].id;
    //             this.endslotAM = this.timeSlot[46].id;

    //             // this.startslotAM = this.timeSlot[77].id;
    //             // this.endslotAM = this.timeSlot[90].id;

    //             this.startslotPM = this.timeSlot[47].id;
    //             this.endslotPM = this.timeSlot[78].id;

    //             //alert(this.timeSlot[48].value +"--"+ this.timeSlot[79].value);

    //          if(value.value == this.today){
    //             this.timecount = Math.floor(this.mincount) + this.hourcount + 1;

    //            // alert('same day : '+ this.timecount +'---'+ (parseInt(this.timecount)-5));
    //            this.printTimeSlotAM = [];
    //            this.printTimeSlotPM = [];

    //             for (let i = parseInt(this.timecount); i <= 96; i++) {
    //                 if (i >= parseInt(this.startslotAM) && i <= parseInt(this.endslotAM)) {
    //                     this.printTimeSlotAM.push(this.timeSlot[i]);
    //                    // console.log(this.timeSlot[i])
    //                 }
    //             }

    //             for (let i = parseInt(this.timecount); i <= 96; i++) {
    //                 if (i >= parseInt(this.startslotPM) && i <= parseInt(this.endslotPM)) {
    //                     this.printTimeSlotPM.push(this.timeSlot[i]);
    //                 }
    //             }

    //          }else{
    //              this.printTimeSlotAM =[];
    //             this.printTimeSlotPM =[];

    //              this.timecount = 0;
    //             for (let i = parseInt(this.timecount); i <= 96; i++) {
    //                 if (i >= parseInt(this.startslotAM) && i <= parseInt(this.endslotAM)) {
    //                     this.printTimeSlotAM.push(this.timeSlot[i]);
    //                 }
    //             }

    //             for (let i = parseInt(this.timecount); i <= 96; i++) {
    //                 if (i >= parseInt(this.startslotPM) && i <= parseInt(this.endslotPM)) {
    //                     this.printTimeSlotPM.push(this.timeSlot[i]);
    //                 }
    //             }

    //          }
    //       this.schedule.appt_date = value.value;
    //       this.schedule.appt_end_date = value.value;
    // >>>>>>> develop
  }



  optionAMChanged(event: any) {
    this.optionPM = "0";
    //alert(event);
  }

  optionPMChanged(event: any) {
    this.optionAM = "0";
    //alert(event);
  }

  onSuccessAppointment(valueTimeAM: any, valueTimePM: any) {
    if (this.isEditableFlag) {
      this.onSuccess(valueTimeAM, valueTimePM);
    } else {
      this.getUpcomingAppointment1(valueTimeAM, valueTimePM);
    }
  }

  //onSuccess(value: any) {
  onSuccess(valueTimeAM: any, valueTimePM: any) {
    this._ls.display(true);
    let minu = '00';
    var am = valueTimeAM;
    var pm = valueTimePM;
    var AMres = am.split(":");
    var PMres = pm.split(":");

    if (valueTimeAM == '0' && valueTimePM == '0') {
      alert('Select Time');
      this._ls.display(false);
      return false;
    }


    if (valueTimeAM != '0') {
      let AMminAdd = parseInt(AMres[1]) + 15;
      let AMtimeAdd = parseInt(AMres[0]) + 1;
      if (AMminAdd < 60) {
        this.fromTime = valueTimeAM;
        this.toTime = AMres[0] + ":" + AMminAdd + ":" + AMres[2];
      } else {
        this.fromTime = valueTimeAM;
        this.toTime = AMtimeAdd + ":" + minu + ":" + AMres[2];
      }
      this.schedule.appt_start_time = this.fromTime;
      this.schedule.appt_end_time = this.toTime;
    }

    // if (valueTimePM != '0') {
    //   let PMminAdd = parseInt(PMres[1]) + 15;
    //   let PMtimeAdd = parseInt(PMres[0]) + 1;
    //   if (PMminAdd < 60) {
    //     this.fromTime = valueTimePM;
    //     this.toTime = PMres[0] + ":" + PMminAdd + ":" + PMres[2];
    //   } else {
    //     this.fromTime = valueTimePM;
    //     this.toTime = PMtimeAdd + ":" + minu + ":" + PMres[2];
    //   }
    //   this.schedule.appt_start_time = this.fromTime;
    //   this.schedule.appt_end_time = this.toTime;
    // }
    if (this.editAppFlag && this.editAppId > 0) {
      this.schedule.AppId = this.editAppId;
      this.schedule.editAppFlag = false;
      this.appointmentService();
    } else {
      this.schedule.AppId = 0;
      this.schedule.editAppFlag = true;
      this.appointmentService();
    }
  }

  modelPop() {
    return this.modal.open(this.successref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
      .catch((res: any) => {
        console.log('sample:' + res)
      })
  }
  // onSelectionChange(opt: any) {
  //     this.timeSlot = this.resetTimeSlot(this.timeSlot);
  //     let arr = this.timeSlot.find((res) => {
  //         return res.id == parseInt(opt);
  //     })
  //     //arr.disable = true;
  //     let nextIndex = this.timeSlot.indexOf(arr);
  //     this.timeSlot[nextIndex].disable = true;
  //     this.timeSlot[nextIndex + 1].disable = true;
  //     this.schedule.appt_start_time = this.timeSlot[nextIndex].time;
  //     this.schedule.appt_end_time = this.timeSlot[nextIndex + 1].time;      
  // }



  resetTimeSlot(values: any) {
    for (let key of values) {
      key.disable = false;
    }
    return values;
  }

  onClose() {
    this.dialog.close();
  }

  bookAppointment() {
    this.dialog.close();
    setTimeout(() => {
      this.router.navigate(['clinics/appointment']);
    }, 500);
  }

  viewAppointments() {
    this.dialog.close();

    setTimeout(() => {
      this.router.navigate(['clinics/viewappointments']);
    }, 500);
  }

  onReasonType(val: any) {
    let obj: any = {};
    if (val != '') {
      obj = this.listOfReason.find((res: any) => {
        return val == res.CAR_ID;
      })
      console.log(this.schedule.reason);
      this.schedule.reason = obj.Reason_TXT;
      this.schedule.car_id = obj.CAR_ID;
      return false;
    }

    //this.schedule.reason = val;    
  }

  onAppointmentType(val: any) {
    if (this.appointment.reason != "") {
      this.personOpacity = "-1";
      this.schedule.type = val;
      this.getProviders(this.clinicId);
    }

  }

  onProviderSelect(newValue: number) {
    this.dateOpacity = "-1";
    if (this.highlightedDiv === newValue) {
      this.highlightedDiv = 0;

    }
    else {
      this.highlightedDiv = newValue;
      this.schedule.provider_id = newValue;
    }
  }

  onDateSelect(newValue: number) {
    if (this.highlightedDateDiv === newValue) {
      this.highlightedDateDiv = 0;

    }
    else {
      this.highlightedDateDiv = newValue;
    }
  }

  getClinicDetail(id: number) {
    this._ls.display(true);
    this._cb.getClinicByClinicId(id).subscribe(res => {
      this.clinicDetails = res;
      this._ls.display(false);
    })
  }

  getApptReason(id: number) {
    this._ls.display(true);
    this._cb.getAppointmentReasons(id).subscribe(res => {
      this.listOfReason = res;
      this._ls.display(false);
    })
  }

  getProviders(id: number) {
    this._ls.display(true);
    this._cb.getProvidersByClinic(id).subscribe(res => {
      this.providerList = res;
      this._ls.display(false);
    })
  }
  getUpcomingAppointment() {
    this._ls.display(true);
    this._cb.getUpcomingAppointments().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.upcomingAppointment, false);
        return false;
      }

      this.getConsultationRequest();
    })
  }

  getConsultationRequest() {
    this._ls.display(true);
    this._cb.getConsultationRequest().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.consultationRequest, false);
        return false;
      }
    })
  }

  getUpcomingAppointment1(valueTimeAM: any, valueTimePM: any) {
    this._ls.display(true);
    this._cb.getUpcomingAppointments().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.upcomingAppointment, false);
        return false;
      }

      this.getConsultationRequest1(valueTimeAM, valueTimePM);
    })
  }

  getConsultationRequest1(valueTimeAM: any, valueTimePM: any) {
    this._ls.display(true);
    this._cb.getConsultationRequest().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.consultationRequest, false);
        return false;
      }
      this.onSuccess(valueTimeAM, valueTimePM);
    });
  }

  appointmentService() {
    this._cb.addOrModifyAppointment(this.schedule).subscribe(res => {
      this._ls.display(false);
      if (res.Response_Code == 1) {
        this.layoutComponent.changeUrl();
        localStorage.setItem('app_clinic_id', this.schedule.clinic_id);
        setTimeout(() => {
          this.modelPop();
        }, 2000);
      } else {
        if (res.Response_Msg == null) {
          let msg = "Invalid appointment date or time";
          this.showAlertMsg(msg, true);
          return;
        }
        this.showAlertMsg(res.Response_Msg, true);
      }
    })
  }

  showAlertMsg(value: string, isApptError: boolean) {
    this.content = value;
    this.isApptError = isApptError;
    this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }

  close(val: boolean) {
    this.dialog.close();
    if (!val) {
      let self = this;
      setTimeout(function () {
        self.router.navigate(['/clinics/viewappointments']);
      }, 500);
    }
  }

  ngOnDestroy() {
    this.profileObserver ? this.profileObserver.unsubscribe() : '';
    this.editApptObserver ? this.editApptObserver.unsubscribe() : '';
    this.editApptIdObserver ? this.editApptIdObserver.unsubscribe() : '';
    this.editApptFlagObserver ? this.editApptFlagObserver.unsubscribe() : '';
  }
}