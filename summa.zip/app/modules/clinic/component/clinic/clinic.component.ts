import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, ElementRef, Renderer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { ClinicService } from "../../service/clinic.service";
import { ClinicBusiness } from "../../business/clinic.business";
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';
import { SharedObserverService } from '../../../../shared/shared-service-module/shared-observer.service';
import { Config } from "../../../../config/constant";

const clinicdata = [
  {
    "id": 1,
    "clinicaddress": "Lift Resource Centre,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$20 - $100"
  },
  {
    "id": 2,
    "clinicaddress": "Canna Clinic,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit.Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$200 - $100"
  },
  {
    "id": 3,
    "clinicaddress": "Readytogo Clinic,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$10 - $50"
  },
  {
    "id": 4,
    "clinicaddress": "Lift Resource Centre,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$50 - $100"
  },
  {
    "id": 5,
    "clinicaddress": "Canna Clinic,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$100 - $150"
  },
  {
    "id": 6,
    "clinicaddress": "Readytogo Clinic,3526 Something Rd.W, Mississauga, ON",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  }
];


const searchdata = [
  {
    "id": 1,
    "country": "Toronto",

  },
  {
    "id": 2,
    "country": "Mississauga",

  },
  {
    "id": 3,
    "country": "Oakville",

  },
  {
    "id": 4,
    "country": "Markham",

  },
  {
    "id": 4,
    "country": "Milton",

  }
];

@Component({
  templateUrl: './clinic.component.html',
  styleUrls: ['./clinic.component.scss'],
  providers: []
})


export class ClinicComponent implements OnInit, OnDestroy {
  activecss: boolean = false;
  dialog: DialogRef<any>;
  private clinicDetails: any = [];
  public resultValue: any;
  public opts: ISlimScrollOptions;
  highlightedDiv: number;
  private isLoaded: boolean = false;
  private isEmpty: boolean = false;
  protected dataService: CompleterData;
  private clearSearchInput: boolean = false;
  private selectedFilter: any = {};
  private appointmentType: string;
  private content: string;
  private userdetails: any;
  private profileOvbserver: Subscription;
  private searchClinicName: any;
  private searchFlagOnOff = false;
  private searchLimitFlagOnOff = false;
  private searchLocationFlagOnOff = false;
  private searchClinicNameLimitFlagOnOff = false;

  @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;

  constructor(private config: Config, private completerService: CompleterService, private router: Router, private renderer: Renderer, private _cb: ClinicBusiness, private _cs: ClinicService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _ls: LoaderService, private _sos: SharedObserverService) {
    overlay.defaultViewContainer = vcRef;
    this.resultValue = [];
    this.clinicDetails = [];
  }
  ngOnInit() {
    this.clearSearchInput = true;
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    this.highlightedDiv = 0;
    this.selectedFilter = {
      cities: ''
    };

    this.getClinicProvincesCities();
    this.onLoadClinicList(this.selectedFilter);

    /**
     * Subscriber for Profile info
     */
    this.profileOvbserver = this._sos.profileEventReceiver$.subscribe(res => {
      this.userdetails = res.Patient_Login_Data;
    })
  }

  onClinicView(id: any) {
    // this.activecss=true;
    this.isLoaded = false;
    this.highlightedDiv = id;
    this.resultValue = this.clinicDetails.find(function (res: any) {
      return res.Clinic_ID == id;
    });
    this.isLoaded = true;
  }
  onBookAppointment(clinidId: string) {
    let user_clinic_id = this.userdetails.Patient_Provider_Relation.ObjProvider.Clinic_Id;

    if (parseInt(user_clinic_id) === 0) {
      this.router.navigate(['clinics/appointment', clinidId]);
      return false;
    }

    if (parseInt(user_clinic_id) !== 0 && parseInt(user_clinic_id) !== parseInt(clinidId)) {
      this.showAlertMsg(this.config.alreadyRegisterWithClinic);
      return false;
    }
    this.getUpcomingAppointment(clinidId);
  }

  public listClick(newValue: number, event: any) {
    event.preventDefault();
    if (this.highlightedDiv === newValue) {
      this.highlightedDiv = 0;
    }
    else {
      this.highlightedDiv = newValue;
    }
  }

  onEnter(enterValue: string) {
    if (enterValue.trim().length == 0 && !this.searchFlagOnOff) {
      return false;
    }
    if (enterValue.trim().length >= 3) {
      this.searchClinicNameLimitFlagOnOff=true;
      this.searchFlagOnOff = true;
      this.selectedFilter.clinicName = enterValue;
      this.selectedFilter.code = 4;
      this.onLoadClinicList(this.selectedFilter);
    } else {
      this.selectedFilter.clinicName = null;
      this.selectedFilter.code = 4;
      if (enterValue.trim().length == 0 && this.searchFlagOnOff && this.searchClinicNameLimitFlagOnOff) {
        this.searchClinicNameLimitFlagOnOff=false;
        this.searchFlagOnOff = false;
        this.onLoadClinicList(this.selectedFilter)
      }

    }

  }

  onLoadClinicList(data: any) {
    this._ls.display(true);
    this.clinicDetails = [];
    this._cb.getClinicsList(data).subscribe(res => {
      this._ls.display(false);
      if (res.length == 0) {
        this.isEmpty = true;
        this.resultValue = {};
        this.clinicDetails = [];
        this.highlightedDiv = 0;
        return false;
      }
      this.isEmpty = false;
      this.isLoaded = true;
      this.clinicDetails = res;
      this.resultValue = res[0];
      this.highlightedDiv = res[0].Clinic_ID;
    })
  }
  getUpcomingAppointment(id: string) {
    this._ls.display(true);
    this._cb.getUpcomingAppointments().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.upcomingAppointment);
        return false;
      }

      this.getConsultationRequest(id);
    })
  }

  getConsultationRequest(clinicId: string) {
    this._ls.display(true);
    this._cb.getConsultationRequest().subscribe(res => {
      this._ls.display(false);
      if (res) {
        this.showAlertMsg(this.config.consultationRequest);
        return false;
      }

      this.router.navigate(['clinics/appointment', clinicId]);
    })
  }

  getClinicProvincesCities() {
    this._ls.display(true);
    this._cb.getClinicProvincesCities().subscribe(res => {
      this.dataService = res;
    })
  }

  onSelectName(event: any) {
    if ((event.trim().length == 0 && !this.searchLocationFlagOnOff) || event == null) {
      return false;
    }
    if (event.trim().length >= 3) {
      this.searchLimitFlagOnOff = true;
      this.searchLocationFlagOnOff = true;
      this.selectedFilter.cities = event;
      this.selectedFilter.code = 4;
      this.onLoadClinicList(this.selectedFilter);
    } else {
      this.selectedFilter.cities = null;
      this.selectedFilter.code = 4;
      this.searchLocationFlagOnOff = true;
      if (event.trim().length == 0 && this.searchLocationFlagOnOff && this.searchLimitFlagOnOff) {
        this.searchLimitFlagOnOff = false;
        this.searchLocationFlagOnOff = false;
        this.onLoadClinicList(this.selectedFilter);
      }
    }
  }

  onSelectionChange(id: string) {
    this.selectedFilter.id = parseInt(id);
    this.selectedFilter.code = 4;
    this.onLoadClinicList(this.selectedFilter);
  }

  showAlertMsg(value: string) {
    this.content = value;
    this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }

  close() {
    this.dialog.close();
  }

  ngOnDestroy() {
    this.profileOvbserver.unsubscribe();
  }


}