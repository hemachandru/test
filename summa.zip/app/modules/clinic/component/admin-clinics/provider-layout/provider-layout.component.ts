import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector: 'provider-layout',
    templateUrl: './provider-layout.component.html',
    styleUrls: ['./provider-layout.component.scss']
})

export class AdminProviderLayoutComponent implements OnInit {
    provider: any;
    newProvider: boolean = true;

    @Input() value: any;
    @Input() isEditPage: boolean;

    @Output() onSaveClick = new EventEmitter();
    @Output() onCloseClick = new EventEmitter();

    constructor(private router: Router) {
        this.value = {
             Provider_Id: 0,
            Clinic_Id: 0,
            Clinic_Name:'',
            Provider_First_Name:'',        
            Provider_Last_Name:'',
            Provider_UserName:'',        
            Provider_Type:'',        
            Provider_Status:'',
            Provider_License_No:'',        
            Gender: '',        
            Email:'',        
            Profile_Status: '',
            Appt_Days_Allowed:0,        
            Appt_Allow_SameDay_Booking:false,
            Appt_Hours_Ahead_Booking:0,        
            Provider_Position:'',        
            address:{},        
            ProviderClinicRelations:[],        
            Communication_Permissions:[],        
            MVCUser_Permissions:[],        
            BillingRequired:false,        
            BillingNumber:'',        
            BillingType:0,


            Password:'',
            ConfirmPassword:''
        }
    }

    ngOnInit() {

        if (this.value.Provider_Id > 0) { this.newProvider = false; }

    }

    onCancel(value: any) {
        this.onCloseClick.emit(value);
        //this.router.navigate(['/clinics/add-clinic']);
    }
    onSave(value: any) {
        this.onSaveClick.emit(value);
        //this.router.navigate(['/clinics/add-clinic']);
    }
}