import { Component, OnInit, Input, Output, EventEmitter, ViewContainerRef, ViewChild, TemplateRef, ElementRef } from "@angular/core";
import { Overlay, overlayConfigFactory, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router } from "@angular/router";
import { Location } from "@angular/common";
import { DocumentListEntity } from './entity/document.entity';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ClinicBusiness } from '../../../business/clinic.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { Config } from '../../../../../config/constant';
import { PrintService } from "../../../../../shared/shared-util/shared-print-service";
import { RecordBusiness } from '../../../../record/component/business/record.business';
import { RecordService } from '../../../../record/component/service/record.service';

@Component({
    selector: 'medical-documents',
    templateUrl: './medical-documents.component.html',
    styleUrls: ['./medical-documents.component.scss'],
    providers: [RecordBusiness, RecordService]
})

export class MedicalDocumentsComponent implements OnInit {

    public docList: DocumentListEntity[];
    public opts: ISlimScrollOptions;
    medicalDocumentDetail: any;
    dialog: DialogRef<any>;
    @ViewChild('viweDocRef') public viweDocRef: TemplateRef<any>;

    constructor(private router: Router, private location: Location, private clinicBusiness: ClinicBusiness, private layoutComponent: LayoutComponent,
        private printService: PrintService, private config: Config, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {

        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }

        this.GetPatientMedicalDocuments();
    }

    GetPatientMedicalDocuments() {

        this.layoutComponent.showSpinner(true);

        this.clinicBusiness.getMedicalDocuments(Number(localStorage.getItem("clinicIndividualPatientId")), "Patients", 0, "NoStatus").subscribe(res => {

            this.docList = res;
            this.layoutComponent.showSpinner(false);

        }, (err) => {

            alert(err);
            this.layoutComponent.showSpinner(false);
        })
    }

    onOpen(event: Event) {
        //this.router.navigate(['clinics/admin/register']);

        this.layoutComponent.showSpinner(true);
        this.clinicBusiness.getMedicalDocument(Number(event)).subscribe(response => {
            this.layoutComponent.showSpinner(false);
            this.medicalDocumentDetail = response;
            this.onViewDocument(event);
        }, (err) => {
            this.layoutComponent.showSpinner(false);

        });
    }

    onViewDocument(event: Event) {
        return this.modal.open(this.viweDocRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-medicalDocument' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    printOptionMedicalDoc(event: any) {
        let headerMecialDocument = document.getElementById('headerMecialDocument').innerHTML;
        let diagnosishtml = document.getElementById('diagnosishtml').innerHTML;
        let suggestionshtml = document.getElementById('suggestionshtml').innerHTML;
        let marijuanaValue = (<HTMLInputElement>document.getElementById('marijuanaValue')).value;
        let PeriodValue = (<HTMLInputElement>document.getElementById('PeriodValue')).value;
        let thcValue = (<HTMLInputElement>document.getElementById('thcValue')).value;
        let cbdValue = (<HTMLInputElement>document.getElementById('cbdValue')).value;
        let period_of_Use = (<HTMLInputElement>document.getElementById('Period_of_Use')).innerHTML;
        
    
        let innerFullHtml = "<section class='view-doc-wrapper'>" +
        "<header >"+
         headerMecialDocument+
        "</header> <div class='view-area'>"+
        " <p class='modal-cont'>Daily quantity of marijuana to be used by the patient:</p>"+
        "<p><input type='text' value="+marijuanaValue+" readonly class='txt-box'/><span class='spacing-txtbox'> gram/day</span></p>"+
        "<p class='modal-cont'> The Period of Use Is</p>"+
        "<p><input type='text' value="+PeriodValue+"  readonly class='txt-box'/> <span class='spacing-txtbox'>" +period_of_Use+"</span></p>"+
        "<p class='modal-cont'> Diagnosis Comments</p><p>"+
        diagnosishtml+
        "</p><p class='modal-cont'> Suggestions Only</p>"+
        "<p><input type='text' readonly value="+thcValue+" class='txt-box'/> THC (%)</p> "+
        "<p><input type='text'  readonly value="+cbdValue+" class='txt-box'/> CBD (%)</p>"+
        "<p class='modal-cont'> Notes and/or Restrictions</p>"+
        "<textarea  class='txt-area' rows='3'>"+suggestionshtml+"</textarea></div></section>"
    
        this.printService.printFile(innerFullHtml, 'medicalDocument');
    }

    onModelClose(event: any) {
        this.dialog.close();
    }

    close() {
        this.dialog.close();
    }

    onCancel() {
        this.location.back();
    }
}