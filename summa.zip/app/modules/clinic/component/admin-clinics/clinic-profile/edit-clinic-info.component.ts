import { Component, TemplateRef, ViewChild, ViewContainerRef, ElementRef, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Location } from '@angular/common';

@Component({
    templateUrl: './edit-clinic-info.component.html'
})

export class EditClinicInfoComponent implements OnInit {
    dataObj: any;
    public ValidCurrentUser: string;

    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;

    constructor(private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        this.dataObj = {
            uname: 'Sample',
            password: 'Welcome1!',
            confirmpassword: 'Welcome1!',
            clinicname: 'Sample',
            description: 'Sample',
            website: 'Sample',
            cliniclogo: '',
            address: 'Sample',
            town: 'Sample',
            postal: 'Sample',
            country: 'CANADA',
            phone: 'Sample',
            fax: 'Sample',
            fname: 'Sample',
            lname: 'Sample',
            email: 'Sample@gmail.com'
        }
    }
    ngOnInit() {
        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;
    }
    onSave(value: any) {
        console.log(value);
        //this.router.navigate(['clinics/edit-clinic/1']);
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onCancel(event: Event) {
        console.log(event);
        if (this.ValidCurrentUser == "ClinicsUser") {
            this._location.back();
        }
        else {
            this.router.navigate(['clinics/admin/edit-clinic/1']);
        }
    }
    onChange(file: any) {
        console.log(file);
    }
    onClose() {
        this.dialog.close();
    }
}
