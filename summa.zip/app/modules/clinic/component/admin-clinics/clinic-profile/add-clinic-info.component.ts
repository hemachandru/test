import { Component, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from "@angular/core";
import { Router } from "@angular/router";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    templateUrl: './add-clinic-info.component.html'
})

export class AddClinicInfoComponent {
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    
    constructor (overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        
    }
    onSave (value: any) {
        console.log(value);
        //this.router.navigate(['clinics/add-clinic']);
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onCancel (event: Event) {
        console.log(event);
        this.router.navigate(['clinics/admin/add-clinic']);
    }
    onChange (file: any) {
        console.log(file);
    }
    onClose() {
        this.dialog.close();
    }
}
