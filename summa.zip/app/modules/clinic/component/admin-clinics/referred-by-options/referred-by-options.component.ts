import { Observable } from 'rxjs/Observable';
import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { AddReferredByOptionsComponent } from './add-referred-by-options/add-referred-by-options.component';
import { ReferredByOptions } from './entity/ReferredByOptions.entity';
import { ClinicBusiness } from '../../../business/clinic.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { ISlimScrollOptions } from 'ng2-slimscroll';
//import { SelectedAppointmentReason } from './entity/AppointmentReason.entity';

@Component({
    templateUrl: './referred-by-options.component.html',
    styleUrls: ["./referred-by-options.component.scss"]
})


export class ReferredByOptionsComponent implements OnInit {


    //public searchlabels = searchdata;
   // @Output() onButtonClk = new EventEmitter<any>();
    public ReferredByOptions: ReferredByOptions[];
    public onButtonClick = new EventEmitter <any>();
    public options: ISlimScrollOptions;
    public flag:boolean;
    private _value : string;
    SelectedPhase :ReferredByOptions[];
    public get value() : string {
        return this._value;
    }
    public set value(v : string) {       this._value = v;
    }

    constructor(private layoutComponent:LayoutComponent,private router: Router, private _location: Location ,private ClinicBusiness:ClinicBusiness, private completerService: CompleterService) {
         /* this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0'
                                    }; */
    }
    ngOnInit() {
        this.layoutComponent.showSpinner(true);
         this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0',

                                    };



        this.ClinicBusiness.getReferredByOptions().subscribe(res=>{
            this.ReferredByOptions=res;
        });
        this.layoutComponent.showSpinner(false);


    }

    onViewReferredByOption(Referred_By_Id:number) {
        this.ReferredByOptions.forEach(RByOption => {
           if (RByOption.Referred_By_Id == Referred_By_Id){
        sessionStorage.setItem("SelectedReferredByOptions", JSON.stringify(RByOption));
        }
     });
       this.layoutComponent.showSpinner(true);

        this.router.navigate(['/clinics/admin/add-referred-by-options']);
    }


    onBack() {
        this._location.back();
    }

     onAddReferredByOption() {
       this.layoutComponent.showSpinner(true);
       sessionStorage.removeItem("SelectedReferredByOptions");
       this.router.navigate(['/clinics/admin/add-referred-by-options']);
    }



}