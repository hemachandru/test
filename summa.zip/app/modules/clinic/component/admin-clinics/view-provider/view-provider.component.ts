import { Component, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from "@angular/core";
import { Router } from "@angular/router";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ClinicBusiness } from '../../../business/clinic.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { PrintService } from "../../../../../shared/shared-util/shared-print-service";

@Component({
    templateUrl: './view-provider.component.html',
    styleUrls: ['./view-provider.component.scss']
})

export class ViewProviderComponent {
    @ViewChild('deactivate') public deactivate: TemplateRef<any>;
    @ViewChild('response') public response: TemplateRef<any>;
    dialog: DialogRef<any>;
    options: ISlimScrollOptions;
    lstProviders: any = [];
    lstPatients: any = [];
    selectedProvider: any ={};
    hasPatients:boolean = false;
    responseMessage:string="";
    successful:boolean=false;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private clinicbusiness: ClinicBusiness
        , private layoutComponent: LayoutComponent,private printService: PrintService) {

        sessionStorage.removeItem("SelectedProviderToEdit");
        this.options = {
            position: 'left',
            barBackground: '#4f4f4f',
            gridBackground: '#b6b6b6',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        };
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {

        this.layoutComponent.showSpinner(true);
        this.lstProviders = [];
        this.lstPatients = [];
        this.selectedProvider = {};
        this.clinicbusiness.getProvidersByClinic(parseInt(localStorage.getItem("clinicId"))).subscribe(res => {
            this.lstProviders = res;
            this.layoutComponent.showSpinner(false);
        },(err) => {this.layoutComponent.showSpinner(false);});
    }

    onDeactivate(value: any) {
        this.layoutComponent.showSpinner(true);        
        this.clinicbusiness.getMyPatientList("Providers", value.Provider_Id, parseInt(localStorage.getItem("clinicId"))).subscribe(res => {
           if(res && res.length > 0) {this.hasPatients = true;} else {this.hasPatients = false;}
           this.lstPatients = res;
           this.selectedProvider = value;
           this.onDeactivateModal();
           this.layoutComponent.showSpinner(false);
        },(err) => {this.layoutComponent.showSpinner(false);});
    }

    onDeactivateModal(){
         return this.modal.open(this.deactivate, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-deactivate' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    onEdit(provider: any) {

        sessionStorage.setItem("SelectedProviderToEdit", JSON.stringify(provider));
        this.router.navigate(['clinics/admin/edit-provider', provider.Provider_Id]);
    }

    onClose() {
        this.dialog.close();
    }

    onPrintPatients(){
        let header = this.selectedProvider.Provider_First_Name + " " + this.selectedProvider.Provider_Last_Name + " - Patient List";
        let patientList = document.getElementById('patientList').innerHTML;
        let html = "<header>" + header + "</header><br/><br/>" + patientList;
        this.printService.printFile(html, 'productList');
    }

    OnConfirmDeactivate(){
        this.layoutComponent.showSpinner(true);
        let request = {
            Clinic_Id: parseInt(localStorage.getItem("clinicId")),
            Provider_Id: this.selectedProvider.Provider_Id,
            Provider_UserName: this.selectedProvider.Provider_UserName,
            User_Role: this.selectedProvider.Provider_Type == "Physician" || this.selectedProvider.Provider_Type == "Educator" ? "Providers" : "Staff",
            Update_Status_Id: 1
        }
        this.clinicbusiness.activateDeactivateProviders(request).subscribe(res => {
            this.onClose();
            if(res && res.Response_Code){
                if(res.Response_Code == 4){
                    this.successful = true;
                    this.responseMessage = "The user is deactivated successfully.";

                    var index = this.lstProviders.indexOf(this.selectedProvider, 0);
                    if (index > -1) {
                    this.lstProviders.splice(index, 1);
                    }

                    this.selectedProvider = null;
                    this.onResponseModal();
                    this.layoutComponent.showSpinner(false);
                }
                else{
                    this.successful = false;
                    this.responseMessage = "Something went wrong, please try again.";
                    this.onResponseModal();
                    this.layoutComponent.showSpinner(false);
                }
            }
            else{
                this.successful = false;
                this.responseMessage = "Something went wrong, please try again.";
                this.onResponseModal();
                this.layoutComponent.showSpinner(false);
            }            
        },(err) => {
            this.successful = false;
            this.responseMessage = "Something went wrong, please try again.";
            this.onResponseModal();
            this.layoutComponent.showSpinner(false);
        });
    }

    onResponseModal(){
        return this.modal.open(this.response, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-deactivate' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    onResponseClose(){
        if(this.successful == true){
            this.onClose();
        }
        else{
            this.onDeactivate(this.selectedProvider);
        }
    }
}
