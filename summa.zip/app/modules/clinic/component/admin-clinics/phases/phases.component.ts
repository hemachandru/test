import { Observable } from 'rxjs/Observable';
import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { AddPhasesComponent } from './add-phases/add-phases.component';
import { Phases } from './entity/Phases.entity';
import { ClinicBusiness } from '../../../business/clinic.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { ISlimScrollOptions } from 'ng2-slimscroll';
//import { SelectedAppointmentReason } from './entity/AppointmentReason.entity';

@Component({
    templateUrl: './phases.component.html',
    styleUrls: ["./phases.component.scss"]
})


export class PhasesComponent implements OnInit {


    //public searchlabels = searchdata;
   // @Output() onButtonClk = new EventEmitter<any>();
    public Phases: Phases[];
    public onButtonClick = new EventEmitter <any>();
    public options: ISlimScrollOptions;
    public flag:boolean;
    private _value : string;
    SelectedPhase :Phases[];
    public get value() : string {
        return this._value;
    }
    public set value(v : string) {       this._value = v;
    }

    constructor(private layoutComponent:LayoutComponent,private router: Router, private _location: Location ,private ClinicBusiness:ClinicBusiness, private completerService: CompleterService) {
         /* this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0'
                                    }; */
    }
    ngOnInit() {
        this.layoutComponent.showSpinner(true);
         this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0',

                                    };



        this.ClinicBusiness.getClinicStages().subscribe(res=>{
            this.Phases=res;
        });
        this.layoutComponent.showSpinner(false);


    }

    onViewPhase(Clinic_Stage_ID:number) {
        this.Phases.forEach(Phase => {
           if (Phase.Clinic_Stage_ID == Clinic_Stage_ID){
        sessionStorage.setItem("SelectedPhase", JSON.stringify(Phase));
        }
     });
       this.layoutComponent.showSpinner(true);

        this.router.navigate(['/clinics/admin/add-phases']);
    }


    onBack() {
        this._location.back();
    }

     onAddPhases() {
       this.layoutComponent.showSpinner(true);
       sessionStorage.removeItem("SelectedPhase");
       this.router.navigate(['/clinics/admin/add-phases']);
    }



}