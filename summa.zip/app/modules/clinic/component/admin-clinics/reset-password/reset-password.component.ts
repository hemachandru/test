import { Component, OnInit, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from "@angular/core";
import { Router } from "@angular/router";
import { Location } from "@angular/common";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import {LoginBusiness} from "../../../../account/component/business/login.business";

@Component({
    selector: 'reset-password',
    templateUrl: './reset-password.component.html',
    styleUrls: ['./reset-password.component.scss']
})

export class AdminResetPasswordComponent implements OnInit{
    public ValidCurrentUser: string;
    public oldPassword:string;
    public newPassword:string;
    public confirmPassword:string;
    public canChangePassword:Boolean = false;
    public errorValue:string="";
    responseMessage:string="";
    successful:boolean=false;
    @ViewChild('response') public response: TemplateRef<any>;
    dialog: DialogRef<any>;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef
        , private location: Location, private loginbussiness:LoginBusiness) {
        
            overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {

        this.ValidCurrentUser = localStorage.getItem('currentUser');
        

    }

    onCancel (value: any) {
        this.location.back();
    }
    onConfirm (value: any) {
        this.location.back();
    }

    onChangePassword(value:any){

        let data = {
            newpassword:this.newPassword,
            oldpassword:this.oldPassword,
            username: localStorage.getItem("login_Username")
        };

        this.loginbussiness.changePassword(data,"",false).subscribe(res => {
            if(res.Response_Code == 1){
                this.successful = true;
                this.responseMessage = "The password is changed successfully.";
                this.onResponseModal();
            }
            else{
                this.errorValue = res.Response_Message;
                this.successful = false;
                this.responseMessage = "Something went wrong, please try again.";
                this.onResponseModal();
            }
        }, (err) => {
            this.successful = false;
            this.responseMessage = "Something went wrong, please try again.";
            this.onResponseModal();
        });
    }

    validatePassword(){
        
        this.canChangePassword = false;
        this.errorValue = "";

        if(this.oldPassword && this.oldPassword.trim() == "")
            this.errorValue = "Please type in your old password!";
        else if(this.newPassword && this.newPassword.trim() == "")
            this.errorValue = "Please type in your new password!";
        else if(this.confirmPassword && this.confirmPassword.trim() == "")
            this.errorValue = "Please retype your new password in confirm field";
        else if(this.newPassword && this.confirmPassword && this.newPassword.trim() != this.confirmPassword.trim())
            this.errorValue = "Passwords do not match!";
        else if (this.newPassword && !this.newPassword.trim().match(/^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/))
            this.errorValue = "Password must be at least 8 characters long, must include at least one uppercase, one special character, and one digit.";

        if(this.oldPassword && this.newPassword && this.confirmPassword && this.errorValue == "")
            this.canChangePassword = true;

    }

    onResponseModal(){
        return this.modal.open(this.response, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-deactivate' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    onResponseClose(){
        this.dialog.close();
        if(this.successful == true){
            this.location.back();
        }
    }
}