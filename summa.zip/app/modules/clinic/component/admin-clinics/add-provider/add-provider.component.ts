import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Router } from "@angular/router";
import { Location } from "@angular/common";

@Component({
    selector: 'add-provider',
    templateUrl: './add-provider.component.html',
    styleUrls: ['./add-provider.component.scss']
})

export class AdminAddProviderComponent implements OnInit{
    provider: any;
    editable: boolean = false;

    constructor(private router: Router, private location: Location) {
        
    }

    ngOnInit() {

    }

    onCancel (value: any) {
        //this.router.navigate(['/clinics/add-clinic']);
        this.location.back();
    }
    onSave (value: any) {
        console.log(value);
        //this.router.navigate(['/clinics/add-clinic']);
        this.location.back();
    }
}