import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

const listObjecta = [
    {
        id: 0,
        url: require('../../../../../assets/images/clinic-app.png'),
        title: 'Lift resource centre'
    },
    {
        id: 1,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 2,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 3,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 4,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 5,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 6,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 7,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 8,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 9,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 10,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 11,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 12,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 13,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 14,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 15,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 16,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 17,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 18,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 19,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 20,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    },
    {
        id: 21,
        url: require('../../../../../assets/images/clinic-app.png'), 
        title: 'Lift resource'
    }
]

@Component({
    selector: 'admin-landing',
    templateUrl: './admin-clinics.component.html'
})

export class AdminClinicsComponent implements OnInit{
    listArry: any;
    constructor(private router: Router) {
        this.listArry = listObjecta;
        //console.log('listObjecta');
    }

    ngOnInit() {
        // this.listArry = listObjecta;
        // console.log('listObjecta');
    }

    onViewAdmin(event: any) {
        this.router.navigate(['clinics/admin/edit-clinic', event.id]);
    }

    onAddAdmin(event: Event) {
        this.router.navigate(['clinics/admin/add-clinic']); 
    }
}
