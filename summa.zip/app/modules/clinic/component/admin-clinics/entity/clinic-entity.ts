export class Clinic {
         Clinic_ID: number;
         ParentClinic_ID: number;
         ParentClinicUserName:string;
         Clinic_User_Name:string;        
         Clinic_Name:string;
         Clinic_Logo_URL:string;        
         WebSite_Link:string;        
         TimeSlot_First_Visit:number;
         TimeSlot_Follow_Up:number;        
         Payment_Status: boolean;        
         Access_Clinic_Patient:boolean;        
         Address: Address;
         Admin_First_Name:string;        
         Admin_Last_Name:string;        
         Profile_Status:string;        
         Email:string;        
         Allowed_Appointment_Types:number;        
         Clinic_Description:string;        
         MVCUser_Permissions:{};        
         Verify_Patients:boolean;        
         Book_Unverified_Patients:boolean;        
         Clinic_Searchable:boolean;        
         BookingWithUs:string;        
         PriceRange:string;
}

 export class Address{

      Address_Id:number;
         User_Address:string;
         City :string;
         Postal_Code:string;
         Province:string;
         Country:string;
         Work_Phone:string;
         Home_Phone:string;
         Cell_Phone:string;
         Fax:string;
         Address_Type:string;
         Longitude:string;
         Latitude:string;
} 