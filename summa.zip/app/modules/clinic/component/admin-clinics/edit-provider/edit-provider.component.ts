import { Component, OnInit, Input, Output, EventEmitter,TemplateRef, ViewChild, ViewContainerRef, ElementRef } from "@angular/core";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router } from "@angular/router";
import { ClinicBusiness } from '../../../business/clinic.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";

@Component({
    selector: 'edit-provider',
    templateUrl: './edit-provider.component.html',
    styleUrls: ['./edit-provider.component.scss']
})

export class AdminEditProviderComponent implements OnInit{
    provider: any;
    editable: boolean = true;
    @ViewChild('response') public response: TemplateRef<any>;
    dialog: DialogRef<any>;
    responseMessage:string="";
    successful:boolean=false;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, 
                private router: Router, private clinicbusiness: ClinicBusiness, private layoutComponent: LayoutComponent) {

        this.provider = JSON.parse(sessionStorage.getItem("SelectedProviderToEdit"));
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {

    }

    onCancel (value: any) {
        this.router.navigate(['/clinics/admin/view-provider']);
    }
    onSave (value: any) {

        this.layoutComponent.showSpinner(true);
        
        this.clinicbusiness.UpdateProvider(value,localStorage.getItem("userRole")).subscribe(res => {
            this.layoutComponent.showSpinner(false);
            if(res && res.Response_Code && res.Response_Code == 2){
                this.responseMessage = "The user's profile is successfully updated.";
                this.successful = true;
                this.onResponseModal();
            }
            else {
                this.responseMessage = "Something went wrong, please try again.";
                this.successful = false;
                this.onResponseModal();
            }
        }, (err) => { 
            this.layoutComponent.showSpinner(false);
            this.successful = false;
            this.responseMessage = "Something went wrong, please try again.";
            this.onResponseModal();
         });
    }

    onResponseModal(){
        return this.modal.open(this.response, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-deactivate' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    onClose() {
        this.dialog.close();
        if(this.successful == true){
        this.router.navigate(['/clinics/admin/view-provider']);
        }
    }
}