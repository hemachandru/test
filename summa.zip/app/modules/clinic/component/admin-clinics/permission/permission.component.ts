import { Component, OnInit } from "@angular/core";
import { Location } from "@angular/common";

@Component({
    templateUrl: './permission.component.html',
    styleUrls: ['./permission.component.scss']
})

export class PermissionComponent implements OnInit {
    public ValidCurrentUser: string;
    constructor(private location: Location) {

    }
    ngOnInit() {
        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;
    }
    onSave() {
        this.location.back();
    }
    onCancel() {
        this.location.back();
    }
}