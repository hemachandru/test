import { Component, OnInit, Input, Output, EventEmitter, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from "@angular/core";
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router } from "@angular/router";
import { Location } from '@angular/common';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Config } from '../../../../../config/constant';
import { ClinicBusiness } from '../../../business/clinic.business';
import { Clinic } from '../entity/clinic-entity';
import { Address } from '../entity/clinic-entity';
import { LayoutComponent } from "../../../../layout/component/layout.component";

@Component({
    selector: 'edit-clinic',
    templateUrl: './edit-clinic.component.html',
    styleUrls: ['./edit-clinic.component.scss'],
    providers: [Config, ClinicBusiness]
})

export class AdminEditClinicComponent implements OnInit {
    public ClinicObj: Clinic;
    public ValidCurrentUser: string;
    overlayColor: string = 'rgba(255,255,255,0.5)';
    imageSrc: string = '';
    imageLoaded: boolean = false;
    iconColor: any;
    loaded: boolean = false;
    filesize = true;
    invalidFile: any;
    updateImage: any;
    dragging: boolean = false;
    activeColor: string = 'green';
    baseColor: string = '#ccc';
    private maxImageSizeText: string = this.config.maximageuploadsize;
    public opts: ISlimScrollOptions;
    public phoneMask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];
    public emailMask = [/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/];
    public postalMask = [/[A-Za-z]/, /\d/, /[A-Za-z]/, ' ', /\d/, /[A-Za-z]/, /\d/];
    public digitsMask = [/\d/, /\d/, /\d/];
    responseMsg: string = "";
    successful: boolean = false;
    dialog: DialogRef<any>;
    @ViewChild('updateResponse') public updateResponse: TemplateRef<any>;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef
        , private router: Router, private _location: Location, private _cb: ClinicBusiness, private config: Config, private layoutComponent: LayoutComponent) {

        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;
        this.ClinicObj = new Clinic();
        this.ClinicObj.Address = new Address();

        this.getClinic();

        this.opts = {
            position: 'left',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
    }
    onCancel() {
        this._location.back();
    }

    onSave(objUpdated: any) {

        this.layoutComponent.showSpinner(true);
        objUpdated.Clinic_Logo_URL = this.imageSrc;
        this._cb.UpdateClinic(objUpdated).subscribe(res => {
            this.successful = false;
            this.responseMsg = "Something went wrong, please try again.";
            if (res && res.Response_Code) {
                if (res.Response_Code == 2) {
                    this.successful = true;
                    this.responseMsg = res.Response_Msg;
                }
            }
            this.onResponseModal();
            this.layoutComponent.showSpinner(false);
        }, (err) => {
            this.successful = false;
            this.responseMsg = "Something went wrong, please try again.";
            this.onResponseModal();
            this.layoutComponent.showSpinner(false);
        });
    }

    getClinic() {
        this.layoutComponent.showSpinner(true);
        this._cb.getClinicByClinicId(parseInt(localStorage.getItem('clinicId')))
            .subscribe(res => {
                this.ClinicObj = res;
                this.imageSrc = res.Clinic_Logo_URL ? res.Clinic_Logo_URL : '';
                this.layoutComponent.showSpinner(false);
            });
    }

    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e: any) {
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file) {
            return;
        }
        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }
        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }

    _handleReaderLoaded(e: any) {
        var value = e.total;
        if (value > 2097152) // 2 mb for bytes.
        {
            this.filesize = false;
            AdminEditClinicComponent.prototype.invalidFile = 'block';
        }
        else {
            this.filesize = true;
            AdminEditClinicComponent.prototype.invalidFile = 'none';
            var reader = e.target;
            this.imageSrc = reader.result;
            this.loaded = true;
        }
    }

    handleDragEnter() {
        this.dragging = true;
    }

    handleDragLeave() {
        this.dragging = false;
    }

    handleDrop(e: any) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }

    onResponseModal() {
        return this.modal.open(this.updateResponse, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-deactivate' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    onCloseMsg() {
        this.dialog.close();
    }
}