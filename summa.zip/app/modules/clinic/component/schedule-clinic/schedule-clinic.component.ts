import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';

import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';

import { ClinicBusiness } from '../../business/clinic.business';
import * as moment from "moment";
import { LayoutComponent } from "../../../layout/component/layout.component";
import { Dashboardbusiness } from '../../../dashboard/business/dashboard.business';
declare var selectProviderScheduler: any;
declare var scheduler: any;
//declare var moment: any;
@Component({
    selector: 'schedule-clinic',
    templateUrl: './schedule-clinic.component.html',
    styleUrls: ['./schedule-clinic.component.scss']
})


export class ScheduleClinicComponent implements OnInit {
    @ViewChild('schedule') public schedule: TemplateRef<any>;
    dialog: DialogRef<any>;
    options: ISlimScrollOptions;
    public ValidCurrentUser: string;
    public date = new Date();
    public providerList: any;
    public appointmentList: any;
    public clinicData: any;
    public clinicListData: any;
    @ViewChild('successref') public successref: TemplateRef<any>;


    /**Datepicker */
    private myDatePickerInlineOptions: IMyOptions = {
        inline: true,
        showWeekNumbers: false,
        sunHighlight: false,
        showTodayBtn: false,
        monthLabels: { 1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June', 7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December' },
        selectionTxtFontSize: '9px',
        firstDayOfWeek: 'su',
        disableUntil: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() - 1 }
    };

    public calendarOptions: Object = {
        weekends: true,
        droppable: true,
        height: 400,
        defaultView: 'agendaDay',
        allDaySlot: false,
        allDayText: true,
        slotDuration: '00:30:00',
        slotLabelFormat: 'h(:mm)a',
        slotLabelInterval: '00:30:00',
        snapDuration: '00:30:00',
        scrollTime: '00:00:00',
        minTime: "00:00:00",
        maxTime: "24:00:00",
        slotEventOverlap: true,
        contentHeight: '300',
        allDay: false,
        editable: true,
        header: {
            left: 'title',
            center: false,
            right: false
        },
        events: [
            {
                title: 'Check Up with Patient D',
                start: moment().add(2, 'h'),
                end: moment().add(2, 'h'),
                allDay: false,
                backgroundColor: '#6dc69e',
                borderColor: '#6dc69e',
            },
            {
                title: 'Online Appointment with Patient X',
                start: moment().subtract(4, 'h'),
                end: moment().subtract(4, 'h'),
                allDay: false,
                backgroundColor: '#0092c7',
                borderColor: '#0092c7'
            },
            {
                title: 'Check Up with Patient F',
                start: moment().add(5, 'h'),
                end: moment().add(5, 'h'),
                allDay: false,
                backgroundColor: '#6dc69e',
                borderColor: '#6dc69e'
            }
        ]
    };
    constructor(private router: Router, private dashboardbusiness: Dashboardbusiness, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _cb: ClinicBusiness, private layoutComponent: LayoutComponent) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        this.layoutComponent.showSpinner(true);
        this._cb.GetClinicSchedularPage().subscribe(res => {
            //console.log(res.providerList[0].Provider_Id);
            this.providerList = res.providerList;
            this.layoutComponent.showSpinner(false);
        })
        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;

        this._cb.GetClinicSchedularPage().subscribe(res => {
            //console.log(res.providerList[0].Provider_Id);
            this.providerList = res.providerList;

            //alert(res.providerList[0].Provider_Id);
        })

        this.dashboardbusiness.getUserDetail().subscribe(res => {
            if (res.Provider_Login_Data) {
                this.clinicListData = res.Provider_Login_Data.ProviderClinicRelations;
            } else if (res.Clinic_Login_Data) {
                let tempClinicListData: any = [];
                tempClinicListData.push({ "Clinic_ID": res.Clinic_Login_Data.Clinic_ID, "Clinic_Name": res.Clinic_Login_Data.Clinic_Name });
                this.clinicListData = tempClinicListData;
            }
        });

        scheduler.config.xml_date = "%Y-%m-%d %H:%i";

        //var cal = scheduler.calendars.AttachMiniCalendar();
        //cal.Navigation = true;
        scheduler.config.show_loading = true;
        scheduler.config.first_hour = 8;//the minimum value of the hour scale
        scheduler.config.last_hour = 20;//the maximum value of the hour scale
        scheduler.config.time_step = 15;//the scale interval for the time selector in the lightbox
        scheduler.config.limit_time_select = true;//sets max and min values for the time selector in the lightbox to the values of the last_hour and first_hour options
        // Scheduler.Config.event_duration // to do appointment dureation
        //Scheduler.Lightbox.Items.Add()
        scheduler.config.multi_day = true;
        scheduler.config.hour_size_px = 184;
        // Scheduler.config.full_day = true;
        scheduler.config.auto_end_date = true;
        scheduler.config.separate_short_events = true;
        scheduler.config.drag_move = false;
        scheduler.config.drag_resize = false;
        scheduler.config.details_on_dblclick = true;
        scheduler.config.details_on_create = true;
        scheduler.init('scheduler_here', new Date(), "day");

    }

    register() {
        return this.modal.open(this.successref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
            .catch((res: any) => {
                console.log('sample:' + res)
            })
    }
    closeDialog() {
        this.dialog.close();
    }

    onChange(dropVal: any) {
        //alert(dropVal);
        this._cb.GetUpcomingOrPreviousAppointmentsSingle(dropVal).subscribe(data => {
            let appoDate = new Date('2017-07-20T00:00:00');      //data[0].Appointment_Date_Only
            let today = new Date();

            var td = today.getDate();
            var tm = today.getMonth() + 1;
            var ty = today.getFullYear();
            var crDate = ty + "-" + tm + "-" + td;
            var ad = appoDate.getDate();
            var am = appoDate.getMonth() + 1;
            var ay = appoDate.getFullYear();
            if(data.length != 0)
            {
                for(let i=0;i<=data.length;i++){
                    let appointmentDate = new Date(data[i].Appointment_Date_Only);
                    var ad = appointmentDate.getDate();
                    var am = appointmentDate.getMonth() + 1;
                    var ay = appointmentDate.getFullYear();
                    var appDate = ty + "-" + tm + "-" + td;
                    
                    if(crDate == appDate){
                        console.log('Time : ',data[i].Appointment_StartTime,'Iteration : ',i);
                    }
                    //console.log('Date : ',appDate,'Iteration : ',i);
                }
            }
            // if(appoDate === today){
            //     console.log('same', appoDate,'today',today);
            // }else{
            //     console.log('not same', appoDate,'today',today);
            // }

            //this.appointmentList = data;
        })
    }

    onScheduleAppt(value: any) {
        sessionStorage.setItem('providerId', value);
        this.router.navigate(["clinics/schedule"])
    }
    onViewAll() {
        //console.log(localStorage.getItem('mvcUserId'));
        this.router.navigate(["clinics/schedule-view"])
    }
    telemedRequest() {
        this.router.navigate(["clinics/telemedrequest-view"])
    }
}