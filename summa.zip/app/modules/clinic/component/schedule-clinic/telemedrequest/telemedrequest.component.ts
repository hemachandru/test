import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Location } from '@angular/common';
import { Subscription } from "rxjs/Subscription";
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { ClinicBusiness } from '../../../business/clinic.business';
import { LoginBusiness } from '../../../../account/component/business/login.business';
import { OpenTokComponent } from '../../../../opentok/component/opentok.component';

@Component({
    selector: "telemedrequest",
    templateUrl: './telemedrequest.component.html',
    styleUrls: ['./telemedrequest.component.scss']
})
export class TelemedRequestComponent implements OnInit, OnDestroy {
    public queueId: any;
    @ViewChild('joinnowref') public joinnowref: TemplateRef<any>;
    @ViewChild('cancelref') public cancelref: TemplateRef<any>;
    @ViewChild('alertRef') public alertRef: TemplateRef<any>;
    @ViewChild(OpenTokComponent) openTok: OpenTokComponent;

    dialog: DialogRef<any>;
    public telemedRequestList: any = [];
    public opts: ISlimScrollOptions;
    public appointmentList: any;
    public uRole: any;
    public providerList: any;
    public dropVal: any;
    private videoConferenceId: number;
    private patientName: any;
    private providerNote: string;
    private webRTCObserver: Subscription;
    private showHideNoteUserProfile: boolean = false;
    private apptData: any;
    private tempApptData: any;
    private changedValue: any;
    private apiKey: string;
    private sessionId: string;
    private token: string;
    private isUserConnected: boolean = false;
    private content: string;
    private providerName: string;

    constructor(private layoutComponent: LayoutComponent, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _lb: LoginBusiness, private _cb: ClinicBusiness) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.layoutComponent.showSpinner(true);
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.getQueueList();

    }

    getQueueList() {
        var clinicId = localStorage.getItem('clinicId');
        let param = {
            Clinic_Id: clinicId
        };
        this._cb.telemedRequestItems(param).subscribe(res => {
            this.telemedRequestList = res;
            this.layoutComponent.showSpinner(false);
        },(err)=>{
            this.layoutComponent.showSpinner(false);
        })
    }
    callDisconnected(event: Event) {
        this.onClose();
    }

    onJoinNow(appt: any) {
        this.queueId = appt.Queue_Id;
        this.patientName = appt.Patient_First_Name;
        this.providerName = appt.Provider_First_Name;


        if (appt.Notification == true) {

            let param = {
                AppointmentId: 0,
                QueueId: this.queueId
            };
            this._cb.Sendappoinmentemail(param).subscribe(res => {
                console.log(res.Response_Code);
            })
        }

        this._cb.joinNowget(this.queueId).subscribe(res => {
            // if (res.Room_Link != null) {
            // this.insertConferenceRoom(appt);
            this.getVideoLink(appt);
            // }
        })


    }

    subStreamCreated(event: Event) {
        this.isUserConnected = true;

        this._cb.updatePatientProviderConnectedStatusclinics(this.tempApptData.Queue_Id).subscribe(res => {
            if (res.Response_Code == 1) {
                this.showHideNoteUserProfile = true;
                this.apptData = this.tempApptData;
                console.log('User connected successfully');
            }
        });
    }

    removeList() {
        debugger;
        let param = {
            Queue_Id: this.queueId,
            Status: "CRPFQ"
        };
        this._cb.cancelledQueue(param).subscribe(res => {
            if (res.Response_Code == 1) {
                this.dialog.close();
                this.getQueueList();

            }
        })
    }


    getVideoLink(appt: any) {
        this.layoutComponent.showSpinner(true);
        this._cb.joinNowget(appt.Queue_Id).subscribe(res => {
            let self = this;
            if (res.hasOwnProperty("Room_Link") && res.Room_Link != null) {
                //super.initiateVideoCall(res.Room_Link, this.connection, dialog);
                this.apiKey = res.Api_Key;
                this.sessionId = res.Room_Link;
                this.token = res.Token;
                this.videoConferenceId = res.Video_Conference_Id;
                if (this.apiKey) {
                    return this.modal.open(this.joinnowref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
                        .then(dialog => {
                            this.dialog = dialog;
                            this.layoutComponent.showSpinner(false);
                            setTimeout(function () {
                                self.openTok.initializeSession();
                            }, 10);
                            return dialog.result.then(res => {
                                if (this.isUserConnected) {
                                    this.endVideoCall(this.videoConferenceId);
                                    this.showHideNoteUserProfile = false;
                                }
                                this.openTok.disconnectWithOutEvent();
                            })
                        })
                }
                return false;
            }
            
            let params = {
                Appt_Id: 0,
                Queue_Id: appt.Queue_Id,
                Room_Link: appt.Room_Link,
                Room_Link_Created_By: localStorage.getItem('userRole'),
                Plugin: "opentok"
            }
            this._cb.insertConferenceRoom(params).subscribe(res => {
                if (res == "Success") {
                    this.getVideoLink(appt);
                } else if (res == "Not user turn") {
                    this.showAlertMsg(res);
                } else if (res == "Appointment is in past") {
                    this.showAlertMsg(res);
                } else if (res == "Invalid appointment id") {
                    this.showAlertMsg(res);
                } else {
                    this.showAlertMsg(res);
                }
                this.layoutComponent.showSpinner(false);
            },(err)=>{
                this.layoutComponent.showSpinner(false);
            });
        },(err) =>{
            this.layoutComponent.showSpinner(false);
        });
    }

    onClose() {
        this.dialog.close(true);
    }

    endVideoCall(conf_id: number) {
        if (conf_id) {
            this._cb.endVideoCall(conf_id).subscribe(res => {
                if (res == "Success") {
                    console.log('Appt. Ended');
                }
            })
        }
    }

    showAlertMsg(value: string) {
        this.content = value;
        this.modal.open(this.alertRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    onCancel(data: any) {
        debugger;
        this.queueId = data.Queue_Id;
        return this.modal.open(this.cancelref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    onCancelClose() {
        this.dialog.close();
    }

    onBack() {
        this._location.back();
    }

    ngOnDestroy() {

    }

}