import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';

import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';

import { ClinicBusiness } from '../../../business/clinic.business';

@Component({
    selector: 'schedule',
    templateUrl: './schedule.component.html',
    styleUrls: ['./schedule.component.scss']
})

export class ScheduleComponent implements OnInit {
    @ViewChild('schedule') public schedule: TemplateRef<any>;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    options: ISlimScrollOptions;
    public ValidCurrentUser: string;
    public date = new Date();
    private schedules: any = {};
    private selectedDate: any = {};

    public patientList: any;
    public reasonsList: any;
    public providerList: any;

    public timeDisabled: boolean;

    public slotArray: any;
    public mincount: any;
    public hourcount: any;
    public timecount: any;
    public min: any;
    public hour: any;
    public x: any;
    public startslot: any;
    public endslot: any;

    public today1: any;
    public dd: any;
    public mm: any;
    public yyyy: any;
    public n: any;
    public o: any;
    public today: any;

    public printTimeSlot: any = [];

    /**Datepicker */
    private myDatePickerNormalOptions: IMyOptions = {
        inline: true,
        width: '200px',
        showWeekNumbers: false,
        sunHighlight: false,
        showTodayBtn: false,
        monthLabels: { 1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June', 7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December' },
        selectionTxtFontSize: '9px',
        firstDayOfWeek: 'su',
        disableUntil: { year: this.date.getFullYear(), month: this.date.getMonth() + 1, day: this.date.getDate() - 1 }
    };

    constructor(private router: Router, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _cb: ClinicBusiness) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {

        let today = new Date();
        this.schedules = {
            date: {
                date: {
                    year: today.getFullYear(),
                    month: today.getMonth() + 1,
                    day: today.getDate()
                }
            }
        }

        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;


        //_cb
        //PatientList   reasonsList    providerList
        this._cb.GetClinicSchedularPage().subscribe(res => {
            this.patientList = res.PatientList;
            this.reasonsList = res.reasonsList;
            this.providerList = res.providerList;
        })


        this.slotArray = [
            "12:00 00", "12:30 00",
            "01:00 00", "01:30 00",
            "02:00 00", "02:30 00",
            "03:00 00", "03:30 00",
            "04:00 00", "04:30 00",
            "05:00 00", "05:30 00",
            "06:00 00", "06:30 00",
            "07:00 00", "07:30 00",
            "08:00 00", "08:30 00",
            "09:00 00", "09:30 00",
            "10:00 00", "10:30 00",
            "11:00 00", "11:30 00",
            "12:00 00", "12:30 00",
            "13:00 00", "13:30 00",
            "14:00 00", "14:30 00",
            "15:00 00", "15:30 00",
            "16:00 00", "16:30 00",
            "17:00 00", "17:30 00",
            "18:00 00", "18:30 00",
            "19:00 00", "19:30 00",
            "20:00 00", "20:30 00",
            "21:00 00", "21:30 00",
            "22:00:00", "22:30:00",
            "23:00:00", "23:30:00"
        ];



        this.x = new Date();
        this.hour = this.x.getHours();
        this.min = this.x.getMinutes();
        this.timecount = 0;
        this.hourcount = this.hour * 2;
        this.mincount = this.min / 30;
        this.timecount = Math.floor(this.mincount) + this.hourcount + 1;

        var startslot = "12:00:00";
        var endslot = "23:30:00";
        this.printTimeSlot = [];
        
        for (let i = parseInt(this.timecount); i < 48; i++) {
            if (i >= parseInt(this.slotArray.indexOf(startslot)) && i <= parseInt(this.slotArray.indexOf(endslot))) {
                //console.log(this.slotArray[i]);
                this.printTimeSlot.push(this.slotArray[i]);
            }
        }
        console.log(this.printTimeSlot);
    }

    onInputFieldChanged(value: IMyInputFieldChanged) {
        this.selectedDate = value.value;

         this.today1 = new Date();
         this.dd = this.today1.getDate();
         this.mm = this.today1.getMonth() + 1;
         this.yyyy = this.today1.getFullYear();
         this.n = this.mm.toString().length;
         if (this.n === 1) {
             this.mm = "0" + this.mm;
         }
         this.o = this.dd.toString().length;
         if (this.o === 1) {
             this.dd = "0" + this.dd;
         }
         this.today = this.yyyy + "-" + this.mm + "-" + this.dd;

         if(value.value == this.today){
             //console.log('same');
              this.slotArray = [
                           "12:00 00", "12:30 00",
            "01:00 00", "01:30 00",
            "02:00 00", "02:30 00",
            "03:00 00", "03:30 00",
            "04:00 00", "04:30 00",
            "05:00 00", "05:30 00",
            "06:00 00", "06:30 00",
            "07:00 00", "07:30 00",
            "08:00 00", "08:30 00",
            "09:00 00", "09:30 00",
            "10:00 00", "10:30 00",
            "11:00 00", "11:30 00",
            "12:00 00", "12:30 00",
            "13:00 00", "13:30 00",
            "14:00 00", "14:30 00",
            "15:00 00", "15:30 00",
            "16:00 00", "16:30 00",
            "17:00 00", "17:30 00",
            "18:00 00", "18:30 00",
            "19:00 00", "19:30 00",
            "20:00 00", "20:30 00",
            "21:00 00", "21:30 00",
            "22:00:00", "22:30:00",
            "23:00:00", "23:30:00"
                         ];

             
             
             this.x = new Date();
             this.hour = this.x.getHours();
             this.min = this.x.getMinutes();
             this.timecount = 0;
             this.hourcount = this.hour * 2;
             this.mincount = this.min / 30;
             this.timecount = Math.floor(this.mincount) + this.hourcount + 1;

             var startslot = "12:00:00";
        var endslot = "23:30:00";
             for (let i = parseInt(this.timecount); i < 48; i++) {
                 if (i >= parseInt(this.slotArray.indexOf(startslot)) && i <= parseInt(this.slotArray.indexOf(endslot))) {
                    this.printTimeSlot.push(this.slotArray[i]);
                 }
             }
         }else{
             //console.log('not same');
            var startslot = "12:00:00";
            var endslot = "23:30:00";
             for (var i = 0; i < 48; i++) {
                 if (i >= parseInt(this.slotArray.indexOf(startslot)) && i <= parseInt(this.slotArray.indexOf(endslot))) {
                     this.printTimeSlot.push(this.slotArray[i]);
                 }
             }
         }
        //console.log(value.value,'today',this.today);

        //this.selectedDate = value;
    }

    onBack() {
        this._location.back();
    }
    onBookAppointment(valuePatient: any, valueReason: any, valueType: any, valueTime: any) {
        //this._location.back();
        console.log(valuePatient, valueReason, valueType, valueTime);

        this._cb.VerifyPatientPerms().subscribe(result => {
            //console.log(result.Verify_Patients, result.Book_Unverified_Patients); 
            if (result.Verify_Patients == true && result.Book_Unverified_Patients == false) {
                this._cb.GetPatientByPatientId(valuePatient).subscribe(patRes => {
                    console.log('patient by patient id : ', patRes);
                    if (patRes.patient_info.Verified_By_Provider_ID <= 0) {
                        alert('Unable to add Appointment. Please verify the Patient before adding the Appointment.');
                    } else {
                        alert('allow appointment');
                    }
                })
            } else {
                alert('allow appointment');
            }
        })

    }
    onClose() {
        this.dialog.close();
    }

}