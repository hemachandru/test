import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Location } from '@angular/common';
import { Subscription } from "rxjs/Subscription";

import { ClinicBusiness } from '../../../business/clinic.business';
import { LoginBusiness } from '../../../../account/component/business/login.business';
import { OpenTokComponent } from '../../../../opentok/component/opentok.component';
import { LoaderService } from '../../../../../shared/shared-loader/shared-loader.service';

@Component({
    selector: "viewappoinment",
    templateUrl: './view-all.component.html',
    styleUrls: ['./view-all.component.scss']
})
export class ViewScheduleAppoinment implements OnInit, OnDestroy {
    @ViewChild('joinnowref') public joinnowref: TemplateRef<any>;
    @ViewChild('cancelref') public cancelref: TemplateRef<any>;
    @ViewChild('alertRef') public alertRef: TemplateRef<any>;
    @ViewChild('appointmentClinicTemRef') public appointmentClinicTemRef: TemplateRef<any>;
    @ViewChild('appointmentEndedRef') public appointmentEndedRef: TemplateRef<any>; 
    @ViewChild(OpenTokComponent) openTok: OpenTokComponent;

    dialog: DialogRef<any>;
    dialogAppt: DialogRef<any>;
    dialogApptEnd: DialogRef<any>;

    public appointmentList: any;
    public uRole: any;
    public providerList: any;
    public dropVal: any;
    private videoConferenceId: number;
    private doctorName: any;
    private providerNote: string;
    private webRTCObserver: Subscription;
    private showHideNoteUserProfile: boolean = false;
    private apptData: any;
    private tempApptData: any;
    private changedValue: any;
    private apiKey: string;
    private sessionId: string;
    private token: string;
    private isUserConnected: boolean = false;
    private content: string;
    private appointmentId: number;
    private videoCallStatusId: any;
    private providerName: string;

    constructor(private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _lb: LoginBusiness, private _cb: ClinicBusiness, private _ls: LoaderService) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        this._lb.getUserDetail().subscribe(data => {
            localStorage.setItem('user_role', data.User_Role);
            //console.log(data.User_Role);
            this.uRole = data.User_Role;

            if (data.User_Role == 'Providers') {
                this._cb.GetUpcomingOrPreviousAppointments().subscribe(data => {
                    console.log('mmmmmssss', data[0].Appointment_Date_Only)
                    this.appointmentList = data;
                    //Clinics 86 86 0
                    //api/User/GetUpcomingOrPreviousAppointments/Patients/294/86/1
                })
            }

            this._cb.GetClinicSchedularPage().subscribe(res => {
                //console.log(res.providerList[0].Provider_Id);
                this.providerList = res.providerList;
            })
        })

    }

    onChange(dropVal: any) {
        //alert(dropVal);
        this.changedValue = dropVal;
        this._cb.GetUpcomingOrPreviousAppointmentsSingle(dropVal).subscribe(data => {
            this.appointmentList = data;
        })
    }

    onEditorReschedule() {
        this.router.navigate(['clinics/schedule']);
    }

    onJoinNow(appt: any) {
        this.tempApptData = appt;
        this.doctorName = appt.Provider_First_Name;
        this.appointmentId = appt.Appointment_Id;
        this.providerName = appt.Provider_First_Name;
        if (appt.Notification) {
            this.sendEmailToUser(appt.Appointment_Id);
        }
        this.insertConferenceStatus(appt);
    }

    sendEmailToUser(appt_id: number) {
        this._cb.enableMyAppointmentTurnEmail(appt_id).subscribe(res => {
            console.log(res);
        })
    }

    callDisconnected(event: any) {
        let self = this;
        return this.modal.open(this.appointmentClinicTemRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
                this.dialogAppt = dialog;
                return dialog.result.then(res => {
                    if (res) {
                        self.openTok.disconnectWithOutEvent();
                        self.dialog.close();
                    }
                })
            })
    }
    onAppointmentCall(val: boolean) {
        this.dialogAppt.close(val);
    }
    subStreamCreated(event: Event) {
        this.isUserConnected = true;

        this._cb.updatePatientProviderConnectedStatus(this.tempApptData.Appointment_Id).subscribe(res => {
            if (res.Response_Code == 1) {
                this.showHideNoteUserProfile = true;
                this.apptData = this.tempApptData;
                console.log('User connected successfully');
            }
        });
    }
    publisherJoined(event: any) {
        let self = this;
        this.videoCallStatusId = setInterval(() => {
            self._cb.getVideoCallStatus(self.appointmentId).subscribe(res => {
                if(res.Response_Code == 2 && res.CallEnded) {
                    self.openTok.disconnectWithOutEvent();
                    self.dialog.close();
                    clearInterval(self.videoCallStatusId);
                    return self.modal.open(self.appointmentEndedRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
                    .then(dialog => {
                        self.dialogApptEnd = dialog;
                        return dialog.result.then(res => {
                            this.onChange(this.changedValue);
                        });              
                    })
                }
            })
        }, 60000)
    
    }
    closeApptEnd() {
        this.dialogApptEnd.close();
    }
    insertConferenceStatus(appt: any) {
        this._ls.display(true);
        let param = {
            Appt_Id: appt.Appointment_Id,
            Clinic_ID: appt.Clinic.Clinic_Id,
            Provider_ID: appt.Provider_Id,
            Patient_ID: appt.Patient_Id,
            Patient_Joined: false,
            Provider_Joined: true
        };
        this._cb.insertConferenceStatus(param).subscribe(res => {
            this._ls.display(false);
            if (res.Response_Code == 1 || appt.Clinic.Clinic_Id<=0 || appt.Provider_Id<=0 || appt.Patient_Id<=0) {
                this.getVideoLink(appt);
            }
        })
    }

    getVideoLink(appt: any) {
        this._ls.display(true);
        this._cb.getVideoRoomLink(appt.Appointment_Id).subscribe(res => {
            let self = this;
            this._ls.display(false);
            if (res.hasOwnProperty("Room_Link") && res.Room_Link != null) {
                //super.initiateVideoCall(res.Room_Link, this.connection, dialog);
                this.apiKey = res.Api_Key;
                this.sessionId = res.Room_Link;
                this.token = res.Token;
                this.videoConferenceId = res.Video_Conference_Id;
                if (this.apiKey) {
                    return this.modal.open(this.joinnowref, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
                        .then(dialog => {
                            this.dialog = dialog;
                            setTimeout(function () {
                                self.openTok.initializeSession();
                            }, 10);
                            return dialog.result.then(res => {
                                if (this.isUserConnected) {
                                    this.endVideoCall(this.videoConferenceId);
                                    this.onChange(this.changedValue);
                                    this.showHideNoteUserProfile = false;
                                } 
                                this.openTok.disconnectWithOutEvent();
                                if(this.videoCallStatusId) {
                                    clearInterval(this.videoCallStatusId);
                                }
                            })
                        })
                }
                return false;
            }
            let params = {
                Appt_Id: appt.Appointment_Id
            }
            this._ls.display(true);
            this._cb.createVideoChatRoom(params).subscribe(res => {
                this._ls.display(false);
                if (res == "Success") {
                    this.getVideoLink(appt);
                } else if (res == "Not user turn") {
                    let str = "Please wait till your scheduled Appointment time occurs."
                    this.showAlertMsg(str);
                } else if (res == "Appointment is in past") {
                    let str = "The Scheduled Appointment time has been ended. Please contact the Clinic."
                    this.showAlertMsg(str);
                } else if (res == "Invalid appointment id") {
                    let str = "Incorrect Appointment Schedule. Please contact the Clinic."
                    this.showAlertMsg(str);
                } else {
                    let str = "An unexpected error occur. Please contact the Clinic."
                    this.showAlertMsg(str);
                }
            })
        })
    }

    onClose() {
        let self = this;
        return this.modal.open(this.appointmentClinicTemRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext)) 
        .then(dialog => {
          this.dialogAppt = dialog;    
          return dialog.result.then(res => {
            if(res) {
              self.dialog.close(true);
            }
          })
        })
    }

    endVideoCall(conf_id: number) {
        if (conf_id) {
            this._cb.endVideoCall(conf_id).subscribe(res => {
                if (res == "Success") {
                    console.log('Appt. Ended');
                }
            })
        }
    }

    addProviderNote(appt: any) {
        if (this.providerNote.trim() != '') {
            let params = {
                Patient_ID: appt.Patient_Id,
                Provider_ID: appt.Provider_Id,
                Provider_First_Name: appt.Provider_First_Name,
                Provider_Last_Name: appt.Provider_Last_Name,
                Note_Text: this.providerNote
            }
            this._cb.addorModifyProviderNote(params).subscribe(res => {
                console.log(res);
                if (res == 'True') {
                    this.providerNote = "";
                }
            })
        }
    }

    addNotes() {
        this.addProviderNote(this.apptData);
    }

    onCancel() {
        return this.modal.open(this.cancelref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onCancelClose() {
        this.dialog.close();
    }
    onBack() {
        this._location.back();
    }

    ngOnDestroy() {
        if(this.videoCallStatusId) {
            clearInterval(this.videoCallStatusId);
        }
    }
    showAlertMsg(value: string) {
        this.content = value;
        this.modal.open(this.alertRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    closeAlert() {
        this.dialog.close();
    }
}