export interface ClinicPhasesInterface {
    Clinic_Stage_ID: number,
    Clinic_ID: number,
    Stage_TXT: string,
    Description: string,
    Created_Date: string,
    Edited_Date: string,
    IsDeleted: boolean,
}
