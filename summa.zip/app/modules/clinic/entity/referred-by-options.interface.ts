export interface ReferredByOptionsInterface {
    Referred_By_Id: number,
    Referred_By_Type: string,
    Clinic_ID: number,
    RequireMoreInfo: boolean,
    MoreInfo_Label: string,
    MoreInfo_Value: string,
    IsDeleted: boolean,
}