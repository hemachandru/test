import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ClinicComponent } from './component/clinic/clinic.component';
import { AppointmentComponent } from './component/appointment/component/appointment.component';
import { AppNotRegisteredComponent } from './component/appointment/component/notregistered/appointment-notregistered.component';
import { ViewAppoinment } from './component/appointment/component/view-appoinment.component';
import { AdminClinicsComponent } from "./component/admin-clinics/admin-clinics.component";
import { AdminAddClinicComponent } from "./component/admin-clinics/add-clinic/add-clinic.component";
import { AdminEditClinicComponent } from "./component/admin-clinics/edit-clinic/edit-clinic.component";
import { AdminAddProviderComponent } from "./component/admin-clinics/add-provider/add-provider.component";
import { AdminEditProviderComponent } from "./component/admin-clinics/edit-provider/edit-provider.component";
import { MedicalDocumentsComponent } from "./component/admin-clinics/medical-documents/medical-documents.component";
import { SupplierRegistrationComponent } from './component/admin-clinics/medical-documents/supplierregister/supplier-register.component';
import { AddClinicInfoComponent } from './component/admin-clinics/clinic-profile/add-clinic-info.component';
import { EditClinicInfoComponent } from './component/admin-clinics/clinic-profile/edit-clinic-info.component';
import { AdminResetPasswordComponent } from "./component/admin-clinics/reset-password/reset-password.component";
import { ViewProviderComponent } from "./component/admin-clinics/view-provider/view-provider.component";
import { PermissionComponent } from "./component/admin-clinics/permission/permission.component";
import { PhasesComponent } from "./component/admin-clinics/phases/phases.component";
import { AddPhasesComponent } from './component/admin-clinics/phases/add-phases/add-phases.component';
import { ReferredByOptionsComponent } from "./component/admin-clinics/referred-by-options/referred-by-options.component";
import { AddReferredByOptionsComponent } from './component/admin-clinics/referred-by-options/add-referred-by-options/add-referred-by-options.component';
import { AppointmentRequestComponent } from "./component/admin-appointment/appointment-request/appointment-request.component";
import { ScheduleClinicComponent } from './component/schedule-clinic/schedule-clinic.component';
import { ScheduleComponent } from './component/schedule-clinic/schedule/schedule.component';
import { ViewScheduleAppoinment } from './component/schedule-clinic/view-all/view-all.component';
import { TelemedRequestComponent } from './component/schedule-clinic/telemedrequest/telemedrequest.component';

const clinicRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: ClinicComponent,
      },
      {
        path: 'appointment/:clinic_id',
        component: AppointmentComponent,
      },
      {
        path: 'appointmentrequest',
        component: AppointmentRequestComponent,
      },
      {
        path: 'notregistered',
        component: AppNotRegisteredComponent,
      },
      {
        path: 'viewappointments',
        component: ViewAppoinment,
      },
      {
        path: 'schedule-clinic',
        component: ScheduleClinicComponent,
      },
      {
        path: 'schedule',
        component: ScheduleComponent,
      },
      {
        path: 'schedule-view',
        component: ViewScheduleAppoinment,
      },
       {
        path: 'telemedrequest-view',
        component: TelemedRequestComponent,
      },
      {
        path: 'admin',
        children: [
          {
            path: '',
            component: AdminClinicsComponent
          },
          {
            path: 'add-clinic',
            component: AdminAddClinicComponent
          },
          {
            path: 'edit-clinic/:id',
            component: AdminEditClinicComponent
          },
          {
            path: 'add-provider',
            component: AdminAddProviderComponent
          },
          {
            path: 'edit-provider/:id',
            component: AdminEditProviderComponent
          },
          {
            path: 'medical-documents',
            component: MedicalDocumentsComponent
          },
          {
            path: 'permission',
            component: PermissionComponent
          },
          {
              path: 'phases',
              component: PhasesComponent
          },
          {
              path: 'add-phases',
              component: AddPhasesComponent
          },
          {
              path: 'referred-by-options',
              component: ReferredByOptionsComponent
          },
          {
              path: 'add-referred-by-options',
              component: AddReferredByOptionsComponent
          },
          {
            path: 'register',
            component: SupplierRegistrationComponent
          },
          {
            path: 'add-clinic-info',
            component: AddClinicInfoComponent
          },
          {
            path: 'add-clinic-info',
            component: AddClinicInfoComponent
          },
          {
            path: 'edit-clinic-info',
            component: EditClinicInfoComponent
          },
          {
            path: 'reset-password',
            component: AdminResetPasswordComponent
          },
          {
            path: 'view-provider',
            component: ViewProviderComponent
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(clinicRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ClinicRoutingModule { }
