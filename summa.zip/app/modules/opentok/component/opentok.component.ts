import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

declare const OT: any;

@Component({
    selector: 'opentok-video',
    templateUrl: './opentok.component.html',
    styleUrls: ['./opentok.component.scss']
})

export class OpenTokComponent implements OnInit {
    private publisher: any;
    private subscriber: any;
    private session: any;
    private isUnMute: boolean = true;
    private isMaximize: boolean = false;

    @Input() apiKey: any;
    @Input() sessionId: any;
    @Input() token: any;
    @Input() pubName: string;

    @Output() disconnect = new EventEmitter();
    @Output() streamsCreated = new EventEmitter();
    @Output() pubJoined = new EventEmitter();

    constructor() { }

    ngOnInit() { }  

    initializeSession() {
        this.session = OT.initSession(this.apiKey, this.sessionId);

        // Subscribe to a newly created stream
        this.session.on('streamCreated', (event: any) => {
            let subscriberOptions = {
                insertMode: 'append',
                width: '100%',
                height: '100%',
                style: {
                    audioLevelDisplayMode: 'off',
                    buttonDisplayMode: 'off',
                    nameDisplayMode: "off"
                }
            };
            this.subscriber = this.session.subscribe(event.stream, 'subscriber', subscriberOptions, (error: any) => {
                if (error) {
                    console.log('There was an error publishing: ', error.name, error.message);
                }
                this.streamsCreated.emit(event.stream);
            });
        });

        this.session.on('sessionDisconnected', (event: any) => {
            console.log(event);
            this.session.off();
            if(this.subscriber) {
                this.subscriber.destroy();
            }            
            //this.session.unpublish(this.publisher);
        });
        this.session.on("streamDestroyed", (event: any) => {
            event.preventDefault();
            console.log("destroyed");
        });

        // Connect to the session
        this.session.connect(this.token, (error: any) => {
            // If the connection is successful, initialize a publisher and publish to the session
            if (!error) {
                var publisherOptions = {
                    resolution: '640x480',
                    insertMode: 'append',
                    name: this.pubName || '',
                    frameRate: 15,
                    audioBitrate: 10000,
                    width: '100%',
                    height: '100%',
                    publishAudio: true,
                    publishVideo: true,
                    style: {audioLevelDisplayMode: 'off',
                            buttonDisplayMode: 'off'}
                };
                this.publisher = OT.initPublisher('publisher', publisherOptions, (error: any) => {
                    if (error) {
                        console.log('There was an error initializing the publisher: ', error.name, error.message);
                        return;
                    }
                    console.log(this.publisher);
                    this.session.publish(this.publisher, (error: any) => {
                        if (error) {
                            console.log('There was an error publishing: ', error.name, error.message);
                        }
                        this.pubJoined.emit(this.publisher);
                    });
                });
            } else {
                console.log('There was an error connecting to the session: ', error.name, error.message);
            }
        });
    }
    private muteAndUnmute() {
        this.isUnMute = !this.isUnMute
        this.publisher.publishAudio(this.isUnMute);
    }

    private disconnectCall() {        
        //this.session.disconnect();
        this.disconnect.emit(this.session);        
    }

    disconnectWithOutEvent() {
        this.session.disconnect();
    }

    private minMaxScreen(event: Event) {
        this.isMaximize = !this.isMaximize;

        if(this.isMaximize) {
            document.getElementsByClassName('modal-dialog-joinnow')[0].classList.add('active');
            document.getElementsByClassName('join-body')[0].classList.add("zoom-view");
            document.getElementsByClassName('modal-dialog-joinnow')[0].classList.add("opacity-0");
            document.getElementsByClassName('join-body')[0].classList.add("opacity-0");
            setTimeout(function() {
                document.getElementsByClassName('modal-dialog-joinnow')[0].classList.remove("opacity-0");                
                document.getElementsByClassName('join-body')[0].classList.remove("opacity-0");                
            }, 300);
        } else {
            document.getElementsByClassName('modal-dialog-joinnow')[0].classList.remove('active');
            document.getElementsByClassName('join-body')[0].classList.remove("zoom-view");
        }
        
    }
}