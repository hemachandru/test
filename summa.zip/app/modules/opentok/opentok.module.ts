import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";

import { OpenTokComponent } from './component/opentok.component';

@NgModule({
    imports: [CommonModule],
    exports: [OpenTokComponent],
    declarations: [OpenTokComponent],
    providers: [],
})
export class OpenTokModule { }
