import { NgModule }       from '@angular/core';
import { SlimScrollModule } from 'ng2-slimscroll';
import { CommonModule } from '@angular/common';
import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';

import { ArticleComponent } from './component/article.component';
import { ArticleModalModule } from '../../shared/arictlemodal/article-modal.module';
import { ArticleRoutingModule } from './article.routing';

const SWIPER_CONFIG: SwiperConfigInterface = {
  direction: 'horizontal',
  slidesPerView: '2',
  keyboardControl: true
};

@NgModule({
  imports: [
    CommonModule,
    ArticleRoutingModule,
    ArticleModalModule,
    SlimScrollModule,
    SwiperModule.forRoot(SWIPER_CONFIG)
  ],
  declarations: [
    ArticleComponent    
  ],
  providers: [ ]
})
export class ArticleModule {}