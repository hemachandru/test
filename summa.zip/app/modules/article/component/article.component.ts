import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { SwiperComponent, SwiperConfigInterface } from 'ngx-swiper-wrapper';

import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.scss']
})
export class ArticleComponent implements OnInit {
  options: ISlimScrollOptions;
  items: any;

  public config: SwiperConfigInterface = {
    scrollbar: null,
    observer: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    breakpoints: {
        // when window width is <= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        // when window width is <= 480px
        480: {
          slidesPerView: 1,
          spaceBetween: 20
        }
    }
  };

  constructor() {
    this.options = {
      position: 'right',
      barBackground: '#4f4f4f',
      gridBackground: '#b6b6b6',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.items = [0, 1, 2];
  }

  ngOnInit() { }

  onIndexChange(evt: Event) {
    console.log(evt);
  }

  onPush () {
    this.items.push(3);
  }
}