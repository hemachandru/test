import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {ArticleComponent} from './component/article.component';

const articleRoutes: Routes = [
  { path: '',  component: ArticleComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(articleRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ArticleRoutingModule { }
