import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AddEntity } from '../entity/add.entity';

const updateProductname = [
    {
        "id": 1,
        "strain": "Canopy",
        "className": "product-grey"
    },
    {
        "id": 2,
        "strain": "Canada medical",
        "className": "product-grey"
    },
    {
        "id": 3,
        "strain": "Supreme",
        "className": "product-grey"
    },
    {
        "id": 4,
        "strain": "Dougs Cannabis",
        "className": "product-grey"
    }
];
@Component({
    templateUrl: './view-supplier.component.html',
    styleUrls: ['./view-supplier.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor']
})
export class ViewSupplierComponent implements OnInit {

    activeColor: string = 'green';
    baseColor: string = '#ccc';
    overlayColor: string = 'rgba(255,255,255,0.5)';

    dragging: boolean = false;
    loaded: boolean = false;
    imageLoaded: boolean = false;
    imageSrc: string = '';
    borderColor: any;
    iconColor: any;
    addentity: AddEntity;
    filesize = true;
    invalidFile: any;
    public productdata = updateProductname;

    @ViewChild('addProduct') public addProduct: TemplateRef<any>;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    dialogNew: DialogRef<any>;
    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.addentity = {
            name: 'Banana OG',
            thc: '20',
            cbd: '7',
            desc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.',
            file: '',
            productname: 'Banana OG',
            productthc: '20',
            productcbd: '7',
            productdesc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.'
        }
    }
    onCancelSupplier() {
        this.router.navigate(['/addtag-superadmin']);
    }
    onEdit() {
        this.router.navigate(['/addtag-superadmin/edit-clinic']);
    }
    onAddSupplier() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    onAddNew() {
        this.router.navigate(['/addtag-superadmin/add-view-clinic']);
    }
    onSave() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    _keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
    onClose() {
        this.dialogNew.close();
    }
    onCancel() {
        this.dialog.close();
    }
    onViewAll() {
        this.router.navigate(['/addtag-superadmin/viewall-clinic']);
    }
    //upload image
    handleDragEnter() {
        this.dragging = true;
    }

    handleDragLeave() {
        this.dragging = false;
    }

    handleDrop(e: any) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }

    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e: any) {
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }

        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }

    _handleReaderLoaded(e: any) {
        var reader = e.target;
        this.imageSrc = reader.result;
        this.loaded = true;
    }

    _setActive() {
        this.borderColor = this.activeColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.activeColor;
        }
    }

    _setInactive() {
        this.borderColor = this.baseColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.baseColor;
        }
    }
}