export interface AddEntity {
    name: string,
    thc: string,
    cbd: string,
    file: any,
    desc: string,
    productname: string,
    productthc: string,
    productcbd: string,
    productdesc: string
}