export interface EditEntity {
    uname: string,
    password: string,
    confirmpassword: string,
    clinicname: string,
    description: string,
    website: string,
    cliniclogo: string,
    address: string,
    town: string,
    postal: string,
    country: string,
    phone: string,
    fax: string,
    fname: string,
    lname: string,
    email: string
}