import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

const dataObj = [
    {
        id: 0,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 1,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 2,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Canna Care Docs"
    },
    {
        id: 3,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 4,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 5,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Canna Care Docs"
    },
    {
        id: 6,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 7,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 8,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Canna Care Docs"
    },
    {
        id: 9,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 10,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 11,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Canna Care Docs"
    },
    {
        id: 12,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 13,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 14,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Canna Care Docs"
    },
    {
        id: 15,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 16,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    },
    {
        id: 17,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "Grow Wise"
    },
    {
        id: 18,
        url: require('../../../../assets/images/menu-icon-pateint.png'),
        title: "White Cedar"
    }
]

@Component({
    templateUrl: './add-tag.component.html',
    styleUrls: ['./add-tag.component.scss']
})

export class AddTagComponent implements OnInit {
    data: any;
    constructor(private router: Router) {
        this.data = dataObj;
    }
    ngOnInit() {

    }
    onAddAdmin() {
        this.router.navigate(['/addtag-superadmin/add-admin']);
    }
    onTag(){
        this.router.navigate(['/addtag-superadmin/view-clinic']);
    }
}