import { Component, Input, Output, EventEmitter, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { EditEntity } from '../entity/edit.entity';

@Component({
    templateUrl: './edit-supplier.component.html',
    styleUrls: ['./edit-supplier.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor']
})
export class EditSupplierComponent implements OnInit {
    editvalues: EditEntity;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.editvalues = {
            uname: '',
            password: '',
            confirmpassword: '',
            clinicname: '',
            description: '',
            website: '',
            cliniclogo: '',
            address: '',
            town: '',
            postal: '',
            country: 'CANADA',
            phone: '',
            fax: '',
            fname: '',
            lname: '',
            email: ''
        }
    }
    onCancel(event: Event) {
        this.router.navigate(['/addtag-superadmin/add-admin']);
    }
    onSave() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onClose() {
        this.dialog.close();
    }
}
