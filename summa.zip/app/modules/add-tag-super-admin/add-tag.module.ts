import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Http, Response, Headers } from '@angular/http';
import { SlimScrollModule } from 'ng2-slimscroll';

import { AddTagComponent } from './component/add-tag.component';
import { AddSupplierComponent } from './component/add-supplier/add-supplier.component';
import { EditSupplierComponent } from './component/edit-supplier/edit-supplier.component';
import { AddClinicComponent } from './component/add-view-clinic/add-clinic.component';
import { ViewSupplierComponent } from "./component/view-supplier/view-supplier.component";
import { ViewAllComponent } from './component/view-supplier/viewall-supplier/viewall.component';
import { EditComponent } from "./component/view-supplier/edit-view-supplier/edit-view.component";
import { AddViewClinicComponent } from './component/view-supplier/add-view-clinic/add-clinic.component';
import { AddViewAllClinicComponent } from './component/view-supplier/viewall-supplier/add-view-clinic/add-clinic.component';

import { SharedModule } from "../../shared/sharedmodule/shared.module";

import { AddTagRoutingModule } from './add-tag.routing';



@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        SlimScrollModule,
        AddTagRoutingModule,
        SharedModule
    ],
    declarations: [
        AddTagComponent,
        AddSupplierComponent,
        EditSupplierComponent,
        AddClinicComponent,
        ViewSupplierComponent,
        ViewAllComponent,
        EditComponent,
        AddViewClinicComponent,
        AddViewAllClinicComponent
    ],
    providers: []
})
export class AddTagModule { }