import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddTagComponent } from './component/add-tag.component';
import { AddSupplierComponent } from './component/add-supplier/add-supplier.component';
import { EditSupplierComponent } from './component/edit-supplier/edit-supplier.component';
import { AddClinicComponent } from './component/add-view-clinic/add-clinic.component';
import { ViewSupplierComponent } from "./component/view-supplier/view-supplier.component";
import { ViewAllComponent } from './component/view-supplier/viewall-supplier/viewall.component';
import { EditComponent } from "./component/view-supplier/edit-view-supplier/edit-view.component";
import { AddViewClinicComponent } from './component/view-supplier/add-view-clinic/add-clinic.component';
import { AddViewAllClinicComponent } from './component/view-supplier/viewall-supplier/add-view-clinic/add-clinic.component';

const clientRoutes: Routes = [
  {
    path: '',
    component: AddTagComponent
  },
  {
    path: 'add-admin',
    component: AddSupplierComponent
  },
  {
    path: 'edit-admin',
    component: EditSupplierComponent
  },
  {
    path: 'add-clinic',
    component: AddClinicComponent
  },
  {
    path: 'view-clinic',
    component: ViewSupplierComponent
  },
  {
    path: 'viewall-clinic',
    component: ViewAllComponent
  },
  {
    path: 'edit-clinic',
    component: EditComponent
  },
  {
    path: 'add-view-clinic',
    component: AddViewClinicComponent
  },
  {
    path: 'addview-all-clinic',
    component: AddViewAllClinicComponent
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(clientRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AddTagRoutingModule { }