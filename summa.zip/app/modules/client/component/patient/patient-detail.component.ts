import { Observable } from 'rxjs/Observable';
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { listingentity } from '../../entity/listing.entity';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
  templateUrl: './patient-detail.component.html',
  styleUrls: ['./patient-detail.component.scss']
})

export class PatientComponent implements OnInit {
     @ViewChild('resetpasswordModal') public resetpasswordModal: TemplateRef<any>;
    dialog: DialogRef<any>;
		public invalidPassword: any;
		public user: any;
    newpassword: string = 'DEFUALT';
    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef    ;
    }
  	ngOnInit() {
        this.user = {
            newpassword: '',
            confirmpassword: '',
            
        }
  	}

		 resetPassword() {
      return this.modal.open(this.resetpasswordModal, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog resetPassword-popup' }, BSModalContext))
        .then(dialog => {
            this.dialog = dialog;
            //this.close();
        });
    }
		savedata(){
			 this.router.navigate(['/clients']);
		}
		save() {
				this.dialog.close();
        this.router.navigate(['/clients']);
    }
		closeDialog(){
			this.dialog.close();
		}
}