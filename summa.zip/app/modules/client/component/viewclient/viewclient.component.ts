import { Observable } from 'rxjs/Observable';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef, OnDestroy } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';
import { ClientBusiness } from '../../business/client.business';
import { ClientService } from '../../service/client.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { RecordBusiness } from '../../../record/component/business/record.business';
import { RecordService } from '../../../record/component/service/record.service';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { LayoutComponent } from "../../../layout/component/layout.component";
import { PrintService } from "../../../../shared/shared-util/shared-print-service";
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";
@Component({
    templateUrl: './viewclient.component.html',
    styleUrls: ['./viewclient.component.scss'],
    providers: [ClientBusiness, ClientService, HttpRequestService, Config, RecordBusiness, RecordService, LoginBusiness, LoginService]
})

export class ViewClientComponent implements OnInit, OnDestroy {

    public idate: any;
    public date = new Date();
    public val: boolean;
    private patientId: number = 0;
    private subcription: any;
    private patientDetail: any;
    private strainsDetail: any;
    private lporder: any;
    private strainUnits: string;
    private productId: number;
    private individualProduct: any;
    private todayDate: Object = { date: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() } };
    private patientMedicalDocId: number;
    private indivudalPatientDetail: any;
    public Orderhasbeenplacedsuccessfully: string = this.config.Orderhasbeenplacedsuccessfully;
    public emptyDateText = this.config.emptyDate;
    public medicaldocumentData: any;
    private patientIdDocId: number = 0;
    private patientFullName: string = "";

    @ViewChild('addneworder') public addneworder: TemplateRef<any>;
    @ViewChild('viewMedicalDoc') public viewMedicalDoc: TemplateRef<any>;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    /** For Datepicker Options */
    private myDatePickerNormalOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'dd/mm/yyyy',
        firstDayOfWeek: 'mo',
        height: '25px',
        width: '203px',
        selectionTxtFontSize: '12px',
        indicateInvalidDate: true,
        editableMonthAndYear: true,
        minYear: 1900,
        maxYear: this.date.getUTCFullYear() + 1,
        disableUntil: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() - 1 },
        componentDisabled: true,
        showClearDateBtn: false,
        showSelectorArrow: true,
        showInputField: true,
        openSelectorOnInputClick: true,
        inline: false,
        editableDateField: false,
        disableHeaderButtons: true,
        inputAutoFill: false,
        showWeekNumbers: false
    };

    constructor(private sharedObserverService: SharedObserverService, private printService: PrintService, private layoutComponent: LayoutComponent, private config: Config, private loginBusiness: LoginBusiness, private router: Router, private recordBusiness: RecordBusiness, private clientBusiness: ClientBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private route: ActivatedRoute) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        this.initService();
    }

    onMedicalDocument(event: Event) {
        this.layoutComponent.showSpinner(true);
        //service get the medicalDocument using MedicalId.
        this.recordBusiness.getMedicalDocument(this.patientIdDocId > 0 ? this.patientIdDocId : this.patientMedicalDocId).subscribe(response => {
            this.medicaldocumentData = response;
            if (this.medicaldocumentData) {
                this.onViewDocument(event)
            }
            this.layoutComponent.showSpinner(false);
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.error("ViewClientComponent lpRequestBusiness getMedicalDocument erro  ", err);
        });
    }


    ngOnDestroy() {
        if (this.subcription) {
            this.subcription.unsubscribe();
        }
    }

    onViewDocument(event: Event) {
        return this.modal.open(this.viewMedicalDoc, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    addNewOrder(event: Event) {
        //service get the StrainList depend on LpUser
        this.layoutComponent.showSpinner(true);
        this.recordBusiness.getStrainsList(false).subscribe(response => {
            this.strainsDetail = response;
            this.lporder.clientName = this.patientDetail.patient_info.First_Name + ' ' + this.patientDetail.patient_info.Last_Name;
            this.layoutComponent.showSpinner(false);
            this.addNewOrderModal(event);
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.error("ViewClientComponent lpRequestBusiness getStrainsList erro  ", err);
        });
    }

    addNewOrderModal(event: Event) {
        return this.modal.open(this.addneworder, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog custom-dialog' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    changeUnits(productId: number) {
        this.individualProduct = this.strainsDetail.filter((x: any) => {
            return x.Product_Id === Number(productId);
        });

        if (this.individualProduct) {
            this.strainUnits = this.individualProduct[0].Price_Type;
        }

    }

    orderSubmit(productOrder: any) {
        if (productOrder.clientName && productOrder.product_Id && productOrder.quality && productOrder.orderDate) {
            this.layoutComponent.showSpinner(true);
            let profileType = "";
            let productType ="";
            //service add or update Lpuser order place detail
            this.sharedObserverService.eventReceiver$.subscribe(res => {
                let productProfile: any;
                let productTypeData: any;
                if (res && res.ProductProfiles) {
                    productProfile = res.ProductProfiles.filter((x: any) => {
                        return Number(x.Id) === Number(this.individualProduct[0].Profile);

                    });
                    profileType=productProfile?productProfile[0].Type:"";
                    
                }

                if (res && res.ProductTypes) {
                    productTypeData = res.ProductTypes.filter((x: any) => {
                        return Number(x.Id) === Number(this.individualProduct[0].Product_Type);

                    });
                    productType=productTypeData?productTypeData[0].Type:"";
                }
                
            })
            this.recordBusiness.orderProduct(productOrder, this.individualProduct, this.patientDetail, this.patientMedicalDocId, profileType,productType).subscribe(response => {
                this.individualProduct = {};
                this.strainUnits = '';
                this.lporder = {
                    clientName: '',
                    orderDate: this.todayDate,
                    product_Id: '',
                    quality: '',
                    units: ''
                };
                this.layoutComponent.showSpinner(false);
                this.onClose();
                this.onSaveAlertModel();
            }, (err) => {
                console.error("ViewClientComponent lpRequestBusiness orderProduct  erro  ", err);
            });
        }
    }

    orderCancel() {
        this.lporder = {
            clientName: '',
            orderDate: this.todayDate,
            product_Id: '',
            quality: ''
        };
        this.onClose();
    }

    onClose() {
        this.dialog.close();
    }

    initService() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.patientMedicalDocId = 0;
            this.strainUnits = '';
            this.lporder = {
                clientName: '',
                orderDate: this.todayDate,
                product_Id: '',
                quality: '',
                units: ''
            }

            this.strainsDetail = [];
            this.subcription = this.route.params.subscribe(params => {
                this.patientId = +params['id']; // (+) converts string 'id' to a number
                this.patientIdDocId = +params['patientDocId'];
                this.patientIdDocId ? this.patientIdDocId : this.patientIdDocId = 0;
                console.log("this.patientIdDocId" + this.patientIdDocId);
            });
            if (this.patientId > 0) {
                //service get the patient detail
                this.clientBusiness.getPatientsDetailByPatientId(this.patientId).subscribe(response => {
                    this.patientDetail = response;

                    this.lporder.clientName = this.patientDetail.patient_info.First_Name + ' ' + this.patientDetail.patient_info.Last_Name;
                    this.patientFullName = this.patientDetail.patient_info.First_Name + ' ' + this.patientDetail.patient_info.Last_Name;

                    this.clientBusiness.getIndividualPatientDetail(this.patientId, this.patientIdDocId > 0 ? true : false).subscribe(response => {
                        response[0] ? this.patientMedicalDocId = response[0].Medical_Document_Id : this.patientMedicalDocId = 0;
                        this.indivudalPatientDetail = response[0];
                        this.layoutComponent.showSpinner(false);
                    }, (err) => {
                        this.layoutComponent.showSpinner(false);
                        console.log('viewClientComponent clientBusiness getIndividualPatientDetail ', err);
                    });
                }, (err) => {
                    this.layoutComponent.showSpinner(false);
                    console.log('viewClientComponent clientBusiness getPatientsDetailByPatientId ', err);
                });
            } else {
                this.layoutComponent.showSpinner(false);
            }
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }

    onSaveAlertModel() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    modelClose(event: any) {
        this.dialog.close();
    }
    closePopup(event: any) {
        this.dialog.close();
    }

    printOptionMedicalDoc(event: any) {
        let headerMecialDocument = document.getElementById('headerMecialDocument').innerHTML;
        let diagnosishtml = document.getElementById('diagnosishtml').innerHTML;
        let suggestionshtml = document.getElementById('suggestionshtml').innerHTML;
        let marijuanaValue = (<HTMLInputElement>document.getElementById('marijuanaValue')).value;
        let PeriodValue = (<HTMLInputElement>document.getElementById('PeriodValue')).value;
        let thcValue = (<HTMLInputElement>document.getElementById('thcValue')).value;
        let cbdValue = (<HTMLInputElement>document.getElementById('cbdValue')).value;
        let period_of_Use = (<HTMLInputElement>document.getElementById('Period_of_Use')).innerHTML;


        let innerFullHtml = "<section class='view-doc-wrapper'>" +
            "<header >" +
            headerMecialDocument +
            "</header> <div class='view-area'>" +
            " <p class='modal-cont'>Daily quantity of marijuana to be used by the patient:</p>" +
            "<p><input type='text' value=" + marijuanaValue + " readonly class='txt-box'/><span class='spacing-txtbox'> gram/day</span></p>" +
            "<p class='modal-cont'> The Period of Use Is</p>" +
            "<p><input type='text' value=" + PeriodValue + "  readonly class='txt-box'/> <span class='spacing-txtbox'>" + period_of_Use + "</span></p>" +
            "<p class='modal-cont'>Diagnosis Comments</p><p>" +
            diagnosishtml +
            "</p><p class='modal-cont'> Suggestions Only</p>" +
            "<p><input type='text' readonly value=" + thcValue + " class='txt-box'/> THC (%) " +
            "<input type='text'  readonly value=" + cbdValue + " class='txt-box'/> CBD (%)</p>" +
            "<p class='modal-cont'>Notes and/or Restrictions</p>" +
            "<textarea  class='txt-area' rows='3'>" + suggestionshtml + "</textarea></div></section>"

        this.printService.printFile(innerFullHtml, 'medicalDocument');
    }
} 