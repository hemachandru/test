import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { listingentity } from '../../entity/listing.entity';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';

@Component({
    selector: 'view-listing',
    templateUrl: './listing.component.html' ,
    styleUrls: ['./client.component.scss'],
    providers:[LoginBusiness, LoginService, Config, HttpRequestService]
})

export class ListingComponent {

    @Input() clientOrderData: any;

    public ValidCurrentUser: string;
    public noData=this.config.noData;
    
    constructor(private config:Config,private loginBusiness: LoginBusiness,overlay: Overlay, vcRef: ViewContainerRef, private router: Router, public modal: Modal, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit(): void {
        this.initService();
    } 

    viewList(id: any){
        var currentUser = localStorage.getItem('currentUser');
        if(currentUser == "AdminUser"){
          this.router.navigate(['/clients/patientDetail/Idparams']);
        } else if(currentUser == "LpUser"){
            this.router.navigate(['/clients/client/'+id]);
        }
    }
    
    initService(){
    if(localStorage.getItem('token')){
        var currentUser = localStorage.getItem('currentUser');
        if(currentUser == "PatientUser"){
         this.ValidCurrentUser = currentUser;
        }else if(currentUser == "LpUser"){
        this.ValidCurrentUser = currentUser;
        }else if(currentUser == "AdminUser"){
        this.ValidCurrentUser = currentUser;
        }else if(currentUser == "ClinicsUser"){
        this.ValidCurrentUser = currentUser;
        }else if(currentUser == "DoctorUser"){
        this.ValidCurrentUser = currentUser;
        }else if(currentUser == "EducatorUser"){
        this.ValidCurrentUser = currentUser;
        }
        else{
        this.router.navigate(['dashboard']);
    }
    }else{
	  this.router.navigate(['portal-login']);
    }
    }

}