import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';

import { listingentity } from '../../entity/listing.entity';
import { ClientBusiness } from '../../business/client.business';
import { ClientService } from '../../service/client.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { LayoutComponent } from "../../../layout/component/layout.component";

@Component({
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss'],
  providers: [ClientBusiness, ClientService, Config, HttpRequestService, LoginBusiness, LoginService]
})

export class ClientComponent implements OnInit {
  public orderdata: any;
  public opts: ISlimScrollOptions;
  public placeholder: string;
  public headerName: string;
  public searchStr: string;
  protected dataService: CompleterData;
  public clearSearchInput: boolean = false;
  public tempFilterData: any;
  constructor(private layoutComponent: LayoutComponent, private completerService: CompleterService, private config: Config, private loginBusiness: LoginBusiness, private router: Router, private clientBusiness: ClientBusiness) { }
  ngOnInit() {
    this.initService();
  }

  onClickInputSearch() {
    //this service return the search input related patient details.
    var searchText = 'pati';
    this.orderdata = [];
    this.clientBusiness.getPatientsDetailBySearchInputText(searchText).subscribe(response => {
      this.orderdata = response;
    }, (err) => {
      console.log('ClientComponent clientBusiness getPatientsDetailBySearchInputText ', err);
    });
  }

  initService() {
    if (localStorage.getItem('token')) {
      this.layoutComponent.showSpinner(true);
      this.orderdata = [];
      this.opts = {
        position: 'right',
        barBackground: '#4f4f4f',
        barBorderRadius: '0',
        barWidth: '4',
        gridWidth: '4',
        gridMargin: '1px 0'
      }

      var currentUser = localStorage.getItem('currentUser');
      if (currentUser == "LpUser") {
        this.placeholder = "Search Client name...";
        this.headerName = "CLIENTS";
      } else if (currentUser == "AdminUser") {
        this.placeholder = "Search Patient name...";
        this.headerName = "PATIENTS";
      }
      //this service get the PatientList Deatil for the consern lpuser.
      this.clientBusiness.getMyPatientList().subscribe(response => {
        this.orderdata = response;
        this.tempFilterData = response;
        if (this.orderdata) {
          this.dataService = this.completerService.local(this.orderdata, 'Patient_First_Name,Patient_Last_Name', 'Patient_First_Name,Patient_Last_Name');
        }
        this.layoutComponent.showSpinner(false);
      }, (err) => {
        this.layoutComponent.showSpinner(false);
        console.log('ClientComponent clientBusiness getMyPatientList ', err);
      });
    } else {
      this.layoutComponent.showSpinner(false);
      this.router.navigate(['portal-login']);
    }
  }

  onSelectName(selected: CompleterItem) {
    if (selected) {
      let filterResult = this.tempFilterData.filter((orderData: any) => {
        return (orderData.Patient_First_Name == selected.originalObject.Patient_First_Name) || (orderData.Patient_Last_Name == selected.originalObject.Patient_Last_Name);
      });
      this.orderdata = filterResult;
    }
  }

  onChangeSearchText(event: any) {
    if (!event) {
      this.orderdata = this.tempFilterData;
    }
  }
}