import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ClientComponent } from './component/client/client.component';
import { PatientComponent } from './component/patient/patient-detail.component';
import { ViewClientComponent } from './component/viewclient/viewclient.component';


const clientRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: ClientComponent,
      },
      {
        path: 'client/:id/:patientDocId',
        component: ViewClientComponent,
      }
      ,
      {
        path: 'client/:id',
        component: ViewClientComponent,
      }
      ,
      {
        path: 'patientDetail/:id',
        component: PatientComponent,
      }
      
      // {
      //   path: 'notregistered',
      //   component: AppNotRegisteredComponent,
      // },
      // {
      //   path: 'viewappointments',
      //   component: ViewAppoinment,
      // }
    ],
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(clientRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ClientRoutingModule { }