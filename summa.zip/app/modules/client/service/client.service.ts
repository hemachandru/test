import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';


@Injectable()
export class ClientService {

    constructor(private httpRequestService : HttpRequestService){
    }
    
    //service get the patient detail
    getPatientsDetailByPatientId(url:string){
       return this.httpRequestService.getHttpRequest(url);
    }
    
     //this service get the PatientList Deatil for the consern lpuser.
    getMyPatientList(url :string){
       return this.httpRequestService.getHttpRequest(url);
    }
    
    //this service return the search input related patient details.
    getPatientsDetailBySearchInputText(url :string){
      return this.httpRequestService.getHttpRequest(url);
    }
    //service get the individualPatientDetail
    getIndividualPatientDetail(url :string){
     return this.httpRequestService.getHttpRequest(url);
    }
     
}