import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { ClientService } from '../service/client.service';
import { Config } from '../../../config/constant';

@Injectable()
export class ClientBusiness {

    constructor(private httpRequestService : HttpRequestService,private clientService :ClientService, private config :Config){
    }

    //service get the patient detail
    getPatientsDetailByPatientId(patientId : number){
    return this.clientService.getPatientsDetailByPatientId(this.config.getPatientByPatientId+patientId).map(response=>response.json() );
    }
    //this service get the PatientList Deatil for the consern lpuser.
    getMyPatientList(){
    return this.clientService.getMyPatientList(this.config.getPatientList+localStorage.getItem('userRole')+'/'+localStorage.getItem('mvcUserId')+'/0').map(response=>response.json());
    }
    
    //this service return the search input related patient details.
    getPatientsDetailBySearchInputText(inputSearchText :String){
     return this.clientService.getMyPatientList(this.config.getPatientList+localStorage.getItem('userRole')+'/'+localStorage.getItem('mvcUserId')+'/0/'+inputSearchText+"/true").map(response=>response.json());
    }

    getIndividualPatientDetail(patientId : number, docStatusFlag:boolean){
     console.log("docStatusFlag" +docStatusFlag);
     let docStatus=docStatusFlag?this.config.documentAcceptStatus :this.config.documentStatus;
     return this.clientService.getIndividualPatientDetail(this.config.getAllDocumentUrl+localStorage.getItem('mvcUserId')+'/'+localStorage.getItem('userRole')+'/0/'+docStatus+'/'+patientId).map(response=>response.json());
    
    }
}
         