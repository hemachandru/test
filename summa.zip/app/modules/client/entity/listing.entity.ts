
export interface listingentity {
    id: number;
    name: string,
    patientName:string
    Lastorderdate:string,
    rxdate:string,
    email:string,
    username: string;
    clinic:string;
    strain: string;
}