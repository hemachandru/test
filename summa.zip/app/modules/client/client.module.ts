import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SlimScrollModule } from 'ng2-slimscroll';
//import { MedicalDocumentComponent } from "../record/component/shared/medical-document/medical-document.component";
import { ClientComponent } from './component/client/client.component';
import { PatientComponent } from './component/patient/patient-detail.component';
import { ViewClientComponent } from './component/viewclient/viewclient.component';
import { ListingComponent } from './component/client/listing.component';
import { MyDatePickerModule } from 'mydatepicker';
import { NumberOnlyDirective } from '../../shared/shared-directive/number-only-directive';
import { Ng2CompleterModule } from "ng2-completer"
import { ClientRoutingModule } from './client.routing';
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { PrintService } from "../../shared/shared-util/shared-print-service";
@NgModule({
  imports: [
    ClientRoutingModule,
    MyDatePickerModule,
    FormsModule,
    CommonModule,
    SlimScrollModule,
    PipeModule,
    Ng2CompleterModule
  ],
  declarations: [
    ClientComponent,
    ViewClientComponent,
    ListingComponent,
    PatientComponent,
    NumberOnlyDirective
  ],
  providers: [PrintService]
})
export class ClientModule { }