export interface Register {
    firstname: string; 
    lastname: string;
    dob: string;
    email: string;
    password: string;
    retypepassword: string;
}