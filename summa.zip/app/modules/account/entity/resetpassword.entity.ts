export interface ResetPasswordEntity {
    oldPassword: string; 
    newPassword: string;
    session_Token: string;
    userName: string;
    using_Pwd_Reset_Link: boolean;   
    id: number;
    user_Role: string;
    confirmPassword: string;
}