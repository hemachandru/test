export interface Forgot {
    username: string;
    email: string;
}