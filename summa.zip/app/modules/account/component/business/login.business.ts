import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { LoginService } from '../service/login.service';
import { Config } from '../../../../config/constant';
import * as moment from 'moment';

@Injectable()
export class LoginBusiness {

  public showError: string;
  constructor(private config: Config, private loginService: LoginService, private router: Router) {
  }

  getSiteLogo(data: any) {
    let url = this.config.getLogo;
    let param = {
      "Parent_Clinic_ID": data.id || 0,
      "Site_Url": data.url || ""
    };
    return this.loginService.getLogo(param, url).map(res => res.json());
  }
  //this service for logout
  postLogoutData(data: any) {
    let reqPara = {
      "PatientId": Number(localStorage.getItem('mvcUserId')),
      "UserExperienceRating": data.rating,
      "UserExperienceComment": data.comment
    }
    return this.loginService.getLogoutData(JSON.stringify(reqPara), this.config.logout)
      .map((result => result.json()));
  }

  //this service get the UserAuthorizationCode code.
  getUserAuthorizationCode(data: string) {
    return this.loginService.getUserAuthorizationCode(data).map(response => {
      var data = response.json();
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('refresh_token', data.refresh_token);
    });
  }

  //this service get login user detaill
  getUserDetailWithData(data: string) {
    return this.loginService.getUserDetailWithData(data).map((result => result.json()));
  }

  // Get LoginUserDeatil
  getUserDetail() {
    return this.loginService.getUserDetail(this.config.userInfoUrl).map((result => result.json()));
  }

  changePassword(changeData: any, sessionToken: string, using_Pwd_Reset_Link: boolean) {

    let reqParam = {
      "NewPassword": changeData.newpassword,
      "OldPassword": changeData.oldpassword,
      "Session_Token": sessionToken,
      "UserName": changeData.username,
      "Using_Pwd_Reset_Link": using_Pwd_Reset_Link,
      "id": Number(localStorage.getItem('mvcUserId')),
      "User_Role": localStorage.getItem('userRole')
    }
    return this.loginService.changePassword(JSON.stringify(reqParam), this.config.changePasswordUrl)
      .map((result) => {
        return result.json();
      });
  }

  //this service check given username or email is valid 
  validateUserNameOrEmailDetail(resetData: any, responseCode: number) {
    let reqPara = {
      "Email": resetData.email ? resetData.email : '',
      "Request_Code": responseCode,
      "SecurityAnswer": "",
      "SecurityAnswerRequired": false,
      "UserName": resetData.username ? resetData.username : '',
    }
    return this.loginService.validateUserNameOrEmail(JSON.stringify(reqPara), this.config.resetPasswordUrl)
      .map((result => result.json()));
  }

  registerUser(data: any) {
    let _self = this;
    let url = this.config.SignUp;
    let params = {
      Password: data.retypepassword,
      UserName: data.email,
      FirstName: data.firstname,
      LastName: data.lastname,
      Email: data.email,
      DOB: moment(new Date(data.dob.jsdate)).format('MM/DD/YYYY'),
      URL_Flag: "Original"
    }

    return this.loginService.registerUser(url, params).map(res => {
      let result = res.json();
      if (result) {
        return result;
      }
    });
  }

  //validate reset password email session link is valid or not.
  validateSessionLink(uid: string, id: string) {
    let reqParam = {
      "Id": id,
      "Session_Token": uid
    }
    return this.loginService.validateSessionLink(JSON.stringify(reqParam), this.config.validateSessionUrl).map(res => {
      let response = res.json();
      if (!response.Valid_Session || response.Temp_Password == "") {
        localStorage.setItem('validOrInvalidSession', 'true');
        this.router.navigate(['portal-forgotpassword']);
      } else {
        return response;
      }
    });
  }
  //service to reset forget Password.
  resetPassword(resetPasswordData: any) {
    var reqParam = {
      "NewPassword": resetPasswordData.newPassword,
      "OldPassword": resetPasswordData.oldPassword,
      "Session_Token": resetPasswordData.session_Token,
      "UserName": resetPasswordData.userName,
      "Using_Pwd_Reset_Link": resetPasswordData.using_Pwd_Reset_Link,
      "id": resetPasswordData.id,
      "User_Role": resetPasswordData.user_Role
    }

    return this.loginService.resetPassword(JSON.stringify(reqParam), this.config.changePasswordUrl).map(res => res.json());
  }

  //service reset the password detail if  using first password provide by admin
  changePasswordIncompleteProfile(resetData: any, userDetail: any, validUser: string) {
    let reqParam = {
      UserName: '',
      UserRole: userDetail.User_Role,
      Old_Password: resetData.oldpassword,
      New_Password: resetData.newpassword,
    }
    reqParam.UserName = validUser == 'PatientUser' ? userDetail.Patient_Login_Data.Patient_User_Name : validUser == 'LpUser' ? userDetail.LP_Login_Data.LP_User_Name : ''

    return this.loginService.changePasswordIncompleteProfile(JSON.stringify(reqParam), this.config.updateUserProfileUrl).map(res => res.json());
  }

  // service get the updated user detail once user reset their first login password
  getUpdatedUserDetail(userName: any, userRole: any) {
    let reqParam = {
      "UserName": userName,
      "UserRole": userRole
    }
    return this.loginService.getUpdatedUserDetail(JSON.stringify(reqParam), this.config.updatedLoginResponse).map(res => res.json());
  }

}