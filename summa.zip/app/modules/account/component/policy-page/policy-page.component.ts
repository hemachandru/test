import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AppLoginComponent } from '../app-login/app-login.component';
import { Login } from '../../entity/login.entity';
import { LoginBusiness } from '../business/login.business';
import { LoginService } from '../service/login.service';
import { Config } from '../../../../config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';

const buttonAgree = [
  {
    "id": 1,
    "buttonName": "I AGREE"
  }
];

@Component({
  selector: 'app-policyPage',
  templateUrl: './policy-page.component.html',
  styleUrls: ['./policy-page.component.scss'],
  providers: [AppLoginComponent, LoginBusiness, Config, HttpRequestService, LoginService]
})
export class PolicyPageComponent implements OnInit {

  public btnData = buttonAgree;
  public login: Login;
  private temp: any;
  private spinnerShow: boolean = false;
  public opts: ISlimScrollOptions;
  public device_id : any;

  constructor(private config: Config, private loginBusiness: LoginBusiness, private router: Router, private routeParam: ActivatedRoute, private appLoginComponent: AppLoginComponent) {

    if (localStorage.getItem('currentPage') && localStorage.getItem('usertype')) {
      if (localStorage.getItem('usertype') == "guest" && localStorage.getItem('token')) {
        localStorage.getItem('currentPage') == "guestHomePage" ? this.router.navigate(['guestHome-page']) : '';
      }else if (localStorage.getItem('usertype') == "user" && localStorage.getItem('token')) {
        localStorage.getItem('currentPage') == "reviewStrainpage" ? this.router.navigate(['reviewStrain-page']) : '';
      }
    } else if (sessionStorage.getItem('registerPage') != 'true' && !localStorage.getItem('token') && localStorage.getItem('usertype') == 'user') {
      sessionStorage.setItem('registerPage', 'false');
      sessionStorage.removeItem("registerData");
      this.router.navigate(['home-page']);
    }
  }

  ngOnInit() {

    this.temp = this.routeParam
      .params
      .subscribe(params => {
        var paramValue = params['id'];
      });

    this.opts = {
      position: 'right',
      barBackground: 'rgb(173, 181, 189)',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

  }

  agreeSubmit(event: Event) {
    if (localStorage.getItem('usertype') == 'guest') {
      this.spinnerShow = true;

      document.addEventListener("deviceready", () => {
            var device: any = (<any>window).device;       
          // alert("Cordova version: " + device.cordova + "\n" +
          // "Device model: " + device.model + "\n" +
          // "Device platform: " + device.platform + "\n" +
          // "Device UUID: " + device.uuid + "\n" +
          // "Device version: " + device.version);
          this.device_id = device.uuid;
        })


      this.login = {
        email: this.device_id,
        password: '""',
      }
      let dataObject = {
        data: this.login
      }
      this.appLoginComponent.getAuthrozationCode(dataObject);
      return false;
    } else if (localStorage.getItem('usertype') == 'user') {
      this.spinnerShow = true;
      if (sessionStorage.getItem("registerData")) {
        let registerData = JSON.parse(sessionStorage.getItem('registerData'));
        let response_Code = 0;
        this.loginBusiness.registerUser(registerData).subscribe(res1 => {
          response_Code = res1.Response_Code;
          if (response_Code == 1) {
            localStorage.setItem('patient_id', res1.Response_PatientID);
            let body_params = 'username=' + encodeURIComponent(registerData.email) + '&grant_type=' + encodeURIComponent(this.config.grant_PassType) + '&password=' + encodeURIComponent(registerData.retypepassword) + '&client_id=' + encodeURIComponent(this.config.Client_Id);
            this.loginBusiness.getUserAuthorizationCode(body_params).subscribe(res => {
              localStorage.setItem('currentUser', "PatientUser");
              this.loginBusiness.getUserDetail().subscribe(data => {
                if (!data.Is_User_Account_Locked && data.Authenticated && data.Patient_Login_Data) {
                  localStorage.setItem('patient_id', data.Patient_Login_Data.Patient_ID);
                  localStorage.setItem('mvcUserId', data.Patient_Login_Data.Patient_ID);
                  localStorage.setItem('userRole', data.User_Role);
                  localStorage.setItem('patient_fname', data.Patient_Login_Data.First_Name);
                  localStorage.setItem('patient_lname', data.Patient_Login_Data.Last_Name);
                  localStorage.setItem('intake_id', data.Patient_Login_Data.Recent_Intake_Form_ID);
                  localStorage.setItem('user_name', data.Patient_Login_Data.Patient_User_Name);
                  localStorage.setItem('clinic_id', String(this.config.clinicId));
                  this.spinnerShow = false;
                  if (localStorage.getItem('strainfinder') == 'StrainFinder') {
                    localStorage.setItem('usertype', 'user')
                    sessionStorage.removeItem('registerPage');
                    sessionStorage.removeItem('registerData');
                    this.router.navigate(['reviewStrain-page']);
                  } else {
                    this.router.navigate(['privacy']);
                  }
                }
              }, (err) => {
                this.spinnerShow = false;
                if (err.status == 401 || err.status == 400) {
                  sessionStorage.setItem('registerError', String(true));
                  sessionStorage.setItem('responseCode', String(err.status));
                  this.router.navigate(['app-registration']);
                  return false;
                }
                console.log("loginBusiness getUserAuthorizationCode error" + err);
              });
            }, (err) => {
              this.spinnerShow = false;
              if (err.status == 401 || err.status == 400) {
                sessionStorage.setItem('registerError', String(true));
                sessionStorage.setItem('responseCode', String(err.status));
                this.router.navigate(['app-registration']);
                return false;
              }
              console.log("loginBusiness getUserAuthorizationCode error" + err);
            });
          } else {
            this.spinnerShow = false;
            if (res1.Response_Code == 4) {
              sessionStorage.setItem('registerError', String(true));
              sessionStorage.setItem('responseCode', String(res1.Response_Code));
              this.router.navigate(['app-registration']);
              return false;
            }else if (res1.Response_Code == 2 || res1.Response_Code == 3 || res1.Response_Code == 5 || res1.Response_Code == 12) {
      
              sessionStorage.setItem('registerError', String(true));
              sessionStorage.setItem('responseCode', String(res1.Response_Code));
              sessionStorage.setItem('responseMessage', String(res1.Response_Message));
              this.router.navigate(['app-registration']);
              return false;
            }
          }
        }, (err) => {
          this.spinnerShow = false;
          if (err.status == 400) {
            sessionStorage.setItem('registerError', String(true));
            sessionStorage.setItem('responseCode', String(err.status));
            this.router.navigate(['app-registration']);
            return false;
          }
          console.log("loginBusiness getUserDetail error" + err);
        });
      } else {
        this.spinnerShow = false;
        sessionStorage.setItem('registerPage', 'false');
        this.router.navigate(['app-registration']);
      }

    }
  }
}