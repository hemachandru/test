import { Observable } from 'rxjs/Observable';
import { Component, OnInit, TemplateRef, ViewChild, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { PlatformLocation } from '@angular/common';
import { NgForm } from '@angular/forms';
import { ResetPasswordEntity } from '../../entity/resetpassword.entity';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';
@Component({
    templateUrl: './resetpassword.component.html',
    styleUrls: ["./resetpassword.component.scss"],
    providers: [LoginBusiness, LoginService, Config, HttpRequestService]
})
export class ChangePasswordComponent implements OnInit {

    public invalidPassword: any;
    newpassword: string = 'DEFUALT';
    public newPassword: any;
    public resetPasswordEntity: ResetPasswordEntity;
    public hideOldPassword: boolean;
    public sessionData: any;
    private sessionToken: string;
    private forgetPassworUserId: string;
    private successAlert: boolean = false;
    private infoAlert: boolean = false;
    private errorAlert: boolean = false;
    private showError: any;
    private statusText: string = '';
    public dialog: DialogRef<any>;
    private userDetail: any;
    private profileUpdateText: string = '';
    private validUser = localStorage.getItem('currentUser');
    private forgetorResetPasswordFlag: boolean = false;
    public showLoader: boolean = false;

    @ViewChild('resetPasswordAlertModalRef') public resetPasswordAlertModalRef: TemplateRef<any>;
    @ViewChild('incompleteProfileModelRef') public incompleteProfileModelRef: TemplateRef<any>;
    constructor(private location: PlatformLocation, private loaderService: LoaderService, private router: Router, private loginBusiness: LoginBusiness, private config: Config, public modal: Modal, overlay: Overlay, vcRef: ViewContainerRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.loaderService.status.subscribe((val: boolean) => {
            this.showLoader = val;
        });
        this.loaderService.display(true);
        localStorage.getItem('inCompleteProfile') === 'true' ? this.hideOldPassword = true : this.hideOldPassword = false;
        this.showErrorMessage(false, false, false, '');
        this.resetPasswordEntity = {
            oldPassword: '',
            newPassword: '',
            session_Token: '',
            userName: '',
            using_Pwd_Reset_Link: true,
            id: 0,
            user_Role: '',
            confirmPassword: ''
        }
        if (localStorage.getItem('inCompleteProfile') === 'true') {
            this.forgetorResetPasswordFlag = true;
            this.loginBusiness.getUserDetail().subscribe(res => {
                this.userDetail = res;
                this.loaderService.display(false);
            }, (err) => {
                err.Status == 401 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
                this.loaderService.display(false);
            });
        } else {
            this.forgetorResetPasswordFlag = false;
            this.sessionToken = localStorage.getItem('session_Token');
            this.forgetPassworUserId = localStorage.getItem('forgetPassworUserId');

            if (this.sessionToken && this.forgetPassworUserId) {
                this.loginBusiness.validateSessionLink(this.sessionToken, this.forgetPassworUserId).subscribe(res => {
                    res ? this.resetPasswordEntity = {
                        oldPassword: res.Temp_Password ? res.Temp_Password : '',
                        newPassword: '',
                        session_Token: this.sessionToken,
                        userName: res.UserName,
                        using_Pwd_Reset_Link: true,
                        id: res.Id,
                        user_Role: res.User_Role,
                        confirmPassword: ''
                    } : '';
                    this.loaderService.display(false);
                }, (err) => {
                    this.loaderService.display(false);
                    console.log("loginBusiness validateSessionLink err", err);
                });
            } else {
                this.loaderService.display(false);
                this.router.navigate(['portal-forgotpassword']);
            }
        }
    }
    save(resetData: any, formData: NgForm) {
        this.loaderService.display(true);
        this.successAlert = false;
        this.errorAlert = false;
        this.infoAlert = false;
        this.resetPasswordEntity.newPassword = resetData.newpassword;
        this.loginBusiness.resetPassword(this.resetPasswordEntity).subscribe(res => {
            res.Response_Code == 7 ? this.showErrorMessage(false, true, false, this.config.lastThreePassword) : '';
            res.Response_Code == 6 ? this.showErrorMessage(false, false, true, this.config.currentPassword) : '';
            this.loaderService.display(false);
            if (res.Response_Code == 1) {
                this.sucessAlert();
            }
            formData.resetForm();

        }, (err) => {
            console.log("loginBusiness resetPassword err", err);
            this.loaderService.display(false);
        });

    }
    resetForm() {
    }

    close() {
        this.dialog.close();
        localStorage.setItem('session_Token', "");
        localStorage.setItem('forgetPassworUserId', "");
        this.router.navigate(['portal-login']);
    }

    closeProfile() {
        localStorage.setItem('inCompleteProfile', 'false');
        this.dialog.close();
        this.router.navigate(['dashboard']);
    }

    sucessAlert() {
        return this.modal.open(this.resetPasswordAlertModalRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-view-reset' }, BSModalContext))
            .then(dialog => {
                this.statusText = this.config.passwordSucessReset;
                this.dialog = dialog;
            });
    }

    sucessProfileAlert() {
        return this.modal.open(this.incompleteProfileModelRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-view-reset' }, BSModalContext))
            .then(dialog => {
                this.profileUpdateText = this.config.passwordSucessReset;
                this.dialog = dialog;
            });
    }

    showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
        this.successAlert = succeboolean;
        this.errorAlert = errorboolean;
        this.infoAlert = infoboolean;
        this.showError = errorMessage;
    }

    incompleteProfileReset(resetData: any, formData: NgForm) {
        this.loaderService.display(true);
        this.showErrorMessage(false, false, false, '');
        this.loginBusiness.changePasswordIncompleteProfile(resetData, this.userDetail, this.validUser).subscribe(res => {
            this.loaderService.display(false);
            res.Response_Code == 2 ? this.showErrorMessage(false, false, true, this.config.invalidPassword) : '';
            formData.resetForm();
            res.Response_Code == 4 ? this.sucessProfileAlert() : '';
            res.Response_Code == 5 ? this.showErrorMessage(false, false, true, this.config.currentPassword) : '';
        }, (err) => {
            this.loaderService.display(false);
            console.log("loginBusiness changePasswordIncompleteProfile err", err);
        });

    }

    resetorforgetpassword(resetData: any, formData: NgForm, resetOrForgetPass: boolean) {
        resetOrForgetPass ? this.incompleteProfileReset(resetData, formData) : this.save(resetData, formData);
    }
}