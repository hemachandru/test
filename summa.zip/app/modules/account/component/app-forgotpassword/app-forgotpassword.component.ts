import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
   selector: 'app-forgotpassword',
  templateUrl: './app-forgotpassword.component.html',
  styleUrls: ['./app-forgotpassword.component.scss']
})
export class AppForgotpasswordComponent implements OnInit {
  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;


  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
    
  }

  ngOnInit() {
    
  }
 
    onforgotPassword() {
    //ForgotpasswordComponent.prototype.emailhide = 'hidden';
    this.router.navigate(['/app-login']);
  }


}