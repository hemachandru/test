import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
@Injectable()
export class LoginService {
  constructor(private httpRequestService: HttpRequestService) {

  }
  /**
   * Get Logo url based on site name
   * @param data 
   * @param url 
   */
  getLogo(data: any, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }

  //for Logout
  getLogoutData(data: string, url: string) {
     return this.httpRequestService.postHttpRequest(data, url);
  }
  getUserAuthorizationCode(data: string) {
    return this.httpRequestService.postHttpRequestWithoutToken(data, 'api/token');
  }
  getUserDetailWithData(data: string) {
    return this.httpRequestService.postHttpRequest(data, 'api/User/Login');
  }

  // Get LoginUserDeatil
  getUserDetail(url: string) {
    return this.httpRequestService.getHttpRequest(url);
  }

  //changePassword
  changePassword(data: string, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }

  validateUserNameOrEmail(data: string, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }

  registerUser(url: any, params: any) {
    return this.httpRequestService.postHttpRequest(params, url);
  }

  //validate reset password email session link is valid or not.
  validateSessionLink(data: string, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }

  //service to reset forget Password.
  resetPassword(data: string, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }
  //service reset the password detail if  using first password provide by admin
  changePasswordIncompleteProfile(data: string, url: string) {
    return this.httpRequestService.putHttpRequest(data, url);
  }

  // service get the updated user detail once user reset their first login password
  getUpdatedUserDetail(data: string, url: string) {
    return this.httpRequestService.postHttpRequest(data, url);
  }

}