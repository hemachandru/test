import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { MyDatePicker } from 'mydatepicker'
import { Subscription } from 'rxjs';
import { LoginBusiness } from '../business/login.business';
import { LoginService } from '../service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';



@Component({
  selector: 'app-portal-login',
  templateUrl: './portal-login.component.html',
  styleUrls: ['./portal-login.component.scss'],
  providers: [LoginBusiness, LoginService, HttpRequestService, Config]
})
export class PortalLoginComponent implements OnInit, OnDestroy {
  private successAlert: boolean = false;
  private infoAlert: boolean = false;
  private errorAlert: boolean = false;
  private showError: any;
  public opts: ISlimScrollOptions;
  public spinnerShow: boolean = false;
  private siteLogo: string;

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  ngOnInit() {
    this.opts = {
      position: 'right',
      barBackground: 'rgb(173, 181, 189)'
    }
    //this.getSiteLogo();
  }

  constructor(private loaderService: LoaderService, private config: Config, private loginBusiness: LoginBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    this.loaderService.status.subscribe((val: boolean) => {
    this.spinnerShow = val;
    });
    if(localStorage.getItem('token')){
       this.loaderService.display(true);
    this.userDetail("");
    }
    overlay.defaultViewContainer = vcRef;
  }
  onLogin(value: any) {
    this.showErrorMessage(false, false, false, "");
    value.event.preventDefault();
    if (value.data.email != '' && value.data.password != '') {
      if (value.data.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.loaderService.display(true);
        var body = 'username=' + encodeURIComponent(value.data.email) + '&grant_type=' + encodeURIComponent(this.config.grant_PassType) + '&password=' + encodeURIComponent(value.data.password) + '&client_id=' + encodeURIComponent(this.config.Client_Id);
        //this service get the UserAuthorizationCode code.
        this.loginBusiness.getUserAuthorizationCode(body).subscribe(res => {
        localStorage.setItem('login_Username', value.data.email);
        this.userDetail(value.data.email);
        }, (err) => {
          err.status == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
          this.loaderService.display(false);
          console.log("loginBusiness getUserDetail error" + err);

        });
      }
    }

  }
  onSignup() {
    this.router.navigate(['portal-registration']);
  }
  onForgotpassword() {
    this.router.navigate(['/portal-forgotpassword']);
  }
  onSupport() {
    this.router.navigate(['support']);
  }
  onTerms() {
    return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-register modal-login' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }
  showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
    this.successAlert = succeboolean;
    this.errorAlert = errorboolean;
    this.infoAlert = infoboolean;
    this.showError = errorMessage;
  }

  ngOnDestroy() {

  }
  // getSiteLogo() {
  //   let param = {
  //     id: 0,
  //     url: window.location.origin
  //   }
  //   this.loginBusiness.getSiteLogo(param).subscribe(data => {
  //     console.log(data);
  //     this.siteLogo = data.Logo_Url;
  //   })
  // }
  userDetail(email: string){
    //this service get login user detail
          //this service get login user detail
          this.loginBusiness.getUserDetail().subscribe(data => {
   
            if (!data.Is_User_Account_Locked && data.Authenticated && data.LP_Login_Data) {
  
              localStorage.setItem('currentUser', "LpUser");
              localStorage.setItem('inCompleteProfile', data.LP_Login_Data.Profile_Status === this.config.Incomplete ? 'true' : 'false');
              localStorage.getItem('inCompleteProfile') === 'true' ? this.router.navigate(['loginresetpassword']) : this.router.navigate(['dashboard'])

            } else if (!data.Is_User_Account_Locked && data.Authenticated && data.Patient_Login_Data) {
              localStorage.setItem('currentUser', "PatientUser");
              this.router.navigate(['dashboard']);
            }else if (!data.Is_User_Account_Locked && data.Authenticated && data.Provider_Login_Data && data.Provider_Login_Data.Provider_Type == "Physician") {
              localStorage.setItem('currentUser', "DoctorUser");
              this.router.navigate(['dashboard']);
            }else if (!data.Is_User_Account_Locked && data.Authenticated && data.Provider_Login_Data && data.Provider_Login_Data.Provider_Type == "Educator") {
              localStorage.setItem('currentUser', "EducatorUser");
              this.router.navigate(['dashboard']);
            }else if (!data.Is_User_Account_Locked && data.Authenticated && data.Clinic_Login_Data ) {
              localStorage.setItem('currentUser', "ClinicsUser");
              this.router.navigate(['dashboard']);
            }else if (!data.Is_User_Account_Locked && data.Authenticated && data.Administrator_Login_Data) {
              this.router.navigate(['/clients']);
              localStorage.setItem('currentUser', "AdminUser");
            }
            this.loaderService.display(false);
          }, (err) => {
            if(err.status == 401){
            localStorage.clear();
            this.router.navigate(['portal-login']);
            }
             this.loaderService.display(false);
             console.log("loginBusiness getUserAuthorizationCode error" + err);
          });
  }
}

