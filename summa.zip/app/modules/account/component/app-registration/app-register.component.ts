import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';

import { Register } from '../../entity/register.entity';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';
import { LoginBusiness } from '../business/login.business';
import { Config } from '../../../../config/constant';
import { Location } from '@angular/common';


@Component({
  selector: 'app-register',
  templateUrl: './app-register.component.html',
  styleUrls: ['./app-register.component.scss']
})
export class AppRegisterComponent implements OnInit {
  private successAlert: boolean = false;
  private infoAlert: boolean = false;
  private errorAlert: boolean = false;
  private showError: any;
  public register: Register;
  public clientid: any;
  public backBool: boolean = true;
  public spinnerShow: boolean = false;

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;


  dialog: DialogRef<any>;

  constructor(private _lb: LoginBusiness, private config: Config, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _location: Location) {
    if (localStorage.getItem('strainfinder') == 'StrainFinder' && localStorage.getItem('token')) {
      this.router.navigate(['reviewStrain-page']);
    } else if (localStorage.getItem('strainfinder') == 'StrainFinder') {
      sessionStorage.setItem('registerPage', 'false');
      sessionStorage.removeItem("registerData");
    }
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    if (sessionStorage.getItem('registerError') && sessionStorage.getItem('registerError') == 'true') {
      let responseCode = Number(sessionStorage.getItem('responseCode'));
      responseCode == 401 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
      responseCode == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
      responseCode == 4 ? this.showErrorMessage(false, false, true, this.config.invalid_username_email_credentials) : '';
      if(responseCode == 2 || responseCode == 3 || responseCode == 5 || responseCode == 12){
       this.showErrorMessage(false, false, true, sessionStorage.getItem('responseMessage'));
       sessionStorage.removeItem('responseMessage')
      }
    }
    this.register = {
      firstname: '',
      lastname: '',
      dob: '',
      email: '',
      password: '',
      retypepassword: ''
    }
    this.backBool = true;
  }

  onRegister(registerData: Register) {
    this.showErrorMessage(false, false, false, "");
    this.spinnerShow = true;
    if (registerData.email != '') {
      if (registerData.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        let response_Code = 0;
        if (localStorage.getItem('strainfinder') == 'StrainFinder') {
          localStorage.setItem('usertype', 'user')
          sessionStorage.setItem('registerPage', 'true');
          sessionStorage.setItem("registerData", JSON.stringify(registerData));
          this.router.navigate(['policy-page']);
          return false;
        }

        this._lb.registerUser(registerData).subscribe(res1 => {
          response_Code = res1.Response_Code;
          if (response_Code == 1) {
            localStorage.setItem('patient_id', res1.Response_PatientID);
            let body_params = 'username=' + encodeURIComponent(registerData.email) + '&grant_type=' + encodeURIComponent(this.config.grant_PassType) + '&password=' + encodeURIComponent(registerData.retypepassword) + '&client_id=' + encodeURIComponent(this.config.Client_Id);
            this._lb.getUserAuthorizationCode(body_params).subscribe(res => {
              localStorage.setItem('currentUser', "PatientUser");
              this._lb.getUserDetail().subscribe(data => {
                if (!data.Is_User_Account_Locked && data.Authenticated && data.Patient_Login_Data) {
                  localStorage.setItem('patient_id', data.Patient_Login_Data.Patient_ID);
                  localStorage.setItem('mvcUserId', data.Patient_Login_Data.Patient_ID);
                  localStorage.setItem('userRole', data.User_Role);
                  localStorage.setItem('patient_fname', data.Patient_Login_Data.First_Name);
                  localStorage.setItem('patient_lname', data.Patient_Login_Data.Last_Name);
                  localStorage.setItem('intake_id', data.Patient_Login_Data.Recent_Intake_Form_ID);
                  localStorage.setItem('user_name', data.Patient_Login_Data.Patient_User_Name);
                  localStorage.setItem('clinic_id', String(this.config.clinicId));
                  this.router.navigate(['privacy']);
                  this.spinnerShow = false;
                }
              }, (err) => {
                this.spinnerShow = false;
                err.status == 401 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
                err.status == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
                console.log("loginBusiness getUserAuthorizationCode error" + err);
              });
            }, (err) => {
              this.spinnerShow = false;
              err.status == 401 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
              err.status == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
              console.log("loginBusiness getUserAuthorizationCode error" + err);
            });
          } else {
            this.spinnerShow = false;
            if (res1.Response_Code == 4) {
              this.showErrorMessage(false, false, true, this.config.invalid_username_email_credentials);
              return false;
            } else if (res1.Response_Code == 2 || res1.Response_Code == 3 || res1.Response_Code == 5 || res1.Response_Code == 12) {
              this.showErrorMessage(false, false, true, res1.Response_Message);
              return false;
            }
          }
        }, (err) => {
          this.spinnerShow = false;
          err.status == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
          console.log("loginBusiness getUserDetail error" + err);
        });
      }
      else {
        this.spinnerShow = false;
      }
    }
  }
  backClicked() {
    this._location.back();
  }

  showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
    sessionStorage.removeItem('registerError')
    sessionStorage.removeItem('responseCode')
    sessionStorage.removeItem("registerData");
    sessionStorage.setItem('registerPage', 'false');
    this.successAlert = succeboolean;
    this.errorAlert = errorboolean;
    this.infoAlert = infoboolean;
    this.showError = errorMessage;
  }

}
