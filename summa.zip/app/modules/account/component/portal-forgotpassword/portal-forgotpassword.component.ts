import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { NgForm } from '@angular/forms';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';


@Component({
  selector: 'portal-forgotpassword',
  templateUrl: './portal-forgotpassword.component.html',
  styleUrls: ['./portal-forgotpassword.component.scss'],
  providers: [LoginBusiness, LoginService, Config, HttpRequestService]
})
export class PortalForgotpasswordComponent implements OnInit {
  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private config: Config, private loginBusiness: LoginBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    if(localStorage.getItem('token')){
     this.router.navigate(['dashboard']);
    }
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
   
  }
  onSupport() {
    this.router.navigate(['support']);
  }
  onTerms() {
    return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-register modal-login' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }
  onClose() {
    this.dialog.close();
  }
  onforgotPassword() {
    this.router.navigate(['/portal-login']);
  }
}