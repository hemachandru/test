import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';
import { Register } from '../../entity/register.entity';
import { LoginBusiness } from '../business/login.business';
import { Config } from '../../../../config/constant';

@Component({
  selector: 'portal-register',
  templateUrl: './portal-register.component.html',
  styleUrls: ['./portal-register.component.scss'],

})
export class PortalRegisterComponent implements OnInit {

  /**Slimscroll */
  public opts: ISlimScrollOptions;
  public register: Register;
  private successAlert: boolean = false;
  private infoAlert: boolean = false;
  private errorAlert: boolean = false;
  private showError: any;
  private serverData: any = {};

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _lb: LoginBusiness, private config: Config) {
    overlay.defaultViewContainer = vcRef;
    if (localStorage.getItem('currentUser') == 'PatientUser' && localStorage.getItem('token')) {
      this.router.navigate(['dashboard']);
      return;
    }
  }
  ngOnInit() {
    this.register = {
      firstname: '',
      lastname: '',
      dob: '',
      email: '',
      password: '',
      retypepassword: ''
    }

    this.opts = {
      position: 'right',
      barBackground: 'rgb(173, 181, 189)'
    }
  }

  onRegister(registerData: Register) {
    if (registerData.email != '') {
      if (registerData.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.errorAlert = false;
        this.serverData = registerData;
        return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-register' }, BSModalContext)).then(dialog => {
          this.dialog = dialog;
          //this.close();
        });
      }
      else {
        console.log("Invalid Login");
      }
    }
  }

  onAgree() {
    this._lb.registerUser(this.serverData).subscribe(res => {
      if (res.Response_Code == 1) {
        let body_params = 'username=' + encodeURIComponent(this.serverData.email) + '&grant_type=' + encodeURIComponent(this.config.grant_PassType) + '&password=' + encodeURIComponent(this.serverData.retypepassword) + '&client_id=' + encodeURIComponent(this.config.Client_Id);

        this._lb.getUserAuthorizationCode(body_params).subscribe(res => {
          this.dialog.close();
          localStorage.setItem('login_Username', this.serverData.email);
          localStorage.setItem('currentUser', "PatientUser");
          localStorage.setItem('registerportal', "true");
          setTimeout(() => {
            this.router.navigate(['dashboard']);
          }, 500);
        });
      } else if (res.Response_Code == 2) {
        this.dialog.close();
        this.showError = res.Response_Message;
        this.errorAlert = true;
      } else if (res.Response_Code == 3) {
        this.dialog.close();
        this.showError = res.Response_Message;
        this.errorAlert = true;
      } else if (res.Response_Code == 4) {
        this.dialog.close();
        this.showError = res.Response_Message;
        this.errorAlert = true;
      }
    });

  }


}
