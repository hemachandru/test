import { Component, Input, OnInit, ViewChild, TemplateRef, ViewContainerRef } from '@angular/core';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { SharedObserverService } from '../../../../shared/shared-service-module/shared-observer.service';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';

const btnChangePassword = [
  {
    "id": 1,
    "buttonName": "CHANGE PASSWORD"
  }
];

const btnEmail = [
  {
    "id": 1,
    "buttonName": "CHANGE EMAIL"
  }
];


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  providers: [LoginBusiness, LoginService]
})
export class ProfileComponent {
  public btnPasswordData = btnChangePassword;
  public btnEmailData = btnEmail;

  showDialog = false;

  //changeEmail
  public isGuest: boolean = false;
  private temp: any;
  private userType: any;
  public user: any;
  private successAlert: boolean = false;
  private infoAlert: boolean = false;
  private errorAlert: boolean = false;
  private showError: any;
  public spinnerShow: boolean = false;
  public userEmail: any;
  public userName:any;
  @ViewChild('changePassword') public changePassword: TemplateRef<any>;
  @ViewChild('changeEmail') public changeEmail: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private config: Config, private loginBusiness: LoginBusiness, private router: Router, private routeParam: ActivatedRoute, public modal: Modal, vcRef: ViewContainerRef) {
    this.user = {
      oldpassword: '',
      newpassword: '',
      confirmpassword: '',
      username: ''
    };
    this.userEmail = {
      oldEmail: '',
      newEmail: '',
      confirmEmail: '',
      username: ''
    };
    modal.overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {

      var paramValue = localStorage.getItem('usertype')
      if (paramValue == 'user') {
        var fname = localStorage.getItem('patient_fname').toUpperCase();
        var lname = localStorage.getItem('patient_lname').toUpperCase();
        this.userName = fname + ' ' + lname;
        this.isGuest = true;
      } else if (paramValue == "guest") {
        this.isGuest = false;
        this.userType = "GUEST";
      } else {
        console.log("Unkonwn");
      }

    } else {
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }

  onClose() {
    this.showErrorMessage(false, false, false, "");
    this.dialog.close();
  }

  changePasswordSubmit(event: Event) {
    return this.modal.open(this.changePassword, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog custom-dialog' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.dialog.close();
      });
  }

  resetPassword(formReset: NgForm) {
    this.showErrorMessage(false, false, false, "");
    event.preventDefault();
    formReset.resetForm();

  }

  save(event: Event, model: any, isValid: boolean, formReset: NgForm) {
    this.showErrorMessage(false, false, false, "");
    this.spinnerShow = true;
    event.preventDefault();
    model.username = localStorage.getItem('user_name');
    this.loginBusiness.changePassword(model, "", false).subscribe(res => {
      res.Response_Code == 1 ? this.showErrorMessage(true, false, false, this.config.passwordSucessReset) : '';
      res.Response_Code == 6 ? this.showErrorMessage(false, false, true, this.config.currentPassword) : '';
      res.Response_Code == 7 ? this.showErrorMessage(false, true, false, this.config.lastThreePassword) : '';
      formReset.resetForm();
      this.spinnerShow = false;
    }, (err) => {
      this.spinnerShow = false;
      console.log("ChangePasswordComponent loginBusiness changePassword ", err)
    });
  }

  showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
    this.successAlert = succeboolean;
    this.errorAlert = errorboolean;
    this.infoAlert = infoboolean;
    this.showError = errorMessage;
  }
}