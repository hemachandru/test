import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, AfterViewInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { LoginBusiness } from '../business/login.business';
import { LoginService } from '../service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';


@Component({
  selector: 'app-login',
  templateUrl: './app-login.component.html',
  styleUrls: ['./app-login.component.scss'],
  providers: [LoginBusiness, LoginService, HttpRequestService, Config]
})
export class AppLoginComponent implements OnInit {
  private successAlert: boolean = false;
  private infoAlert: boolean = false;
  private errorAlert: boolean = false;
  private showError: any;
  public opts: ISlimScrollOptions;
  public clientid: any;
  public spinnerShow: boolean = false;
  public userOrGuest: string = "";
  public strainfinder: string = "";

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  ngOnInit() {
    localStorage.setItem('currentUser', "");
    if (localStorage.getItem('strainfinder') == 'StrainFinder') {
      this.spinnerShow = true;
      this.strainfinder = localStorage.getItem('strainfinder');
      this.userOrGuest = localStorage.getItem('usertype');
      if (this.strainfinder == 'StrainFinder' && this.userOrGuest == "guest") {
        this.clientid = this.config.guestClient_Id_strain
      } else {
        this.clientid = this.config.Client_Id
      }

      if (localStorage.getItem('token')) {
        this.userDetail();
      } else {
        this.spinnerShow = false;
      }
    }
    this.opts = {
      position: 'right',
      barBackground: 'rgb(173, 181, 189)'
    }
  }
  constructor(private config: Config, private loginBusiness: LoginBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }
  // onLogin(event: any) {
  //   //console.log(event);
  //   if (event.email != '' && event.password != '') {
  //     if (event.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
  //       this.router.navigate(['consult']);
  //       localStorage.setItem('currentUser', "PatientUser");
  //     }
  //   }
  // }
  onLogin(value: any) {
    this.spinnerShow = true;
    value.event.preventDefault();
    if (value.data.email != '' && value.data.password != '') {
      if (value.data.email.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
        this.getAuthrozationCode(value);
      }
    }
  }

  getAuthrozationCode(value: any) {
    this.strainfinder = localStorage.getItem('strainfinder');
    this.userOrGuest = localStorage.getItem('usertype');
    if (this.strainfinder == 'StrainFinder' && this.userOrGuest == "guest") {
      this.clientid = this.config.guestClient_Id_strain
    } else {
      this.clientid = this.config.Client_Id
    }

    var body = 'username=' + encodeURIComponent(value.data.email) + '&grant_type=' + encodeURIComponent(this.config.grant_PassType) + '&password=' + encodeURIComponent(value.data.password) + '&client_id=' + encodeURIComponent(this.clientid);

    //this service get the UserAuthorizationCode code.
    this.loginBusiness.getUserAuthorizationCode(body).subscribe(res => {
      localStorage.setItem('login_Username', value.data.email);
      this.userDetail();
    }, (err) => {
      this.spinnerShow = false;
      err.status == 400 ? this.showErrorMessage(false, false, true, this.config.invalid_credentials) : '';
      console.log("loginBusiness getUserDetail error" + err);
    });
  }

  
  onSignup() {
    this.router.navigate(['app-registration']);
  }
  onCancel() {
    this.router.navigate(['/app-forgotpassword']);
  }
  showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
    this.successAlert = succeboolean;
    this.errorAlert = errorboolean;
    this.infoAlert = infoboolean;
    this.showError = errorMessage;
  }
  onForgotpassword() {
    this.router.navigate(['/app-forgotpassword']);
  }

  userDetail() {
    //this service get login user detail
    this.loginBusiness.getUserDetail().subscribe(data => {
      if (!data.Is_User_Account_Locked && data.Authenticated && data.Patient_Login_Data) {

        localStorage.setItem('currentUser', "PatientUser");
        localStorage.setItem('patient_id', data.Patient_Login_Data.Patient_ID);
        localStorage.setItem('mvcUserId', data.Patient_Login_Data.Patient_ID);
        localStorage.setItem('user_role', data.User_Role);
        localStorage.setItem('userRole', data.User_Role);
        localStorage.setItem('patient_fname', data.Patient_Login_Data.First_Name);
        localStorage.setItem('patient_lname', data.Patient_Login_Data.Last_Name);
        localStorage.setItem('intake_id', data.Patient_Login_Data.Recent_Intake_Form_ID);
        localStorage.setItem('user_name', data.Patient_Login_Data.Patient_User_Name);
        //let provider = data.Patient_Login_Data.Patient_Provider_Relation;
        //localStorage.setItem('clinic_id', provider ? provider.ObjProvider.Clinic_Id : 0);
        localStorage.setItem('clinic_id', String(this.config.clinicId));
        this.spinnerShow = false;
        if (localStorage.getItem('strainfinder') == 'StrainFinder') {
          this.router.navigate(['reviewStrain-page']);
        } else {
          this.router.navigate(['consult']);
        }
      } else if (this.userOrGuest == "guest" && this.strainfinder == 'StrainFinder') {
        localStorage.setItem('currentUser', "PatientUser");
        localStorage.setItem('patient_id', String(0));
        localStorage.setItem('userRole', "Patients");
        localStorage.setItem('patient_fname', "Guest");
        localStorage.setItem('patient_lname', "User");
        //let provider = data.Patient_Login_Data.Patient_Provider_Relation;
        //localStorage.setItem('clinic_id', provider ? provider.ObjProvider.Clinic_Id : 0);
        localStorage.setItem('clinic_id', String(this.config.clinicId));
        this.spinnerShow = false;
        if (this.strainfinder == 'StrainFinder' && String(this.userOrGuest) == "user") {
          this.router.navigate(['reviewStrain-page']);
        } else if (this.strainfinder == 'StrainFinder' && String(this.userOrGuest) == "guest") {
          this.router.navigate(['guestHome-page']);
        } else {
          this.router.navigate(['consult']);
        }
      }
    }, (err) => {
      this.spinnerShow = false;
      console.log("loginBusiness getUserAuthorizationCode error" + err);
    });
  }

  // openLink() {
  //       let navigator = (<any>window).navigator;
  //       if (typeof navigator !== "undefined" && navigator.app) {
  //           alert("hai");
  //           // Mobile device.
  //           navigator.app.loadUrl('https://test-sail-cannabis.ihorsetechnologies.com/', { openExternal: true });
  //       } else {
  //           // Possible web browser
  //           window.open("https://test-sail-cannabis.ihorsetechnologies.com/", "_blank");
  //       }
  //   }
}