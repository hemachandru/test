import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';;
import { LoginComponent } from "./login/login.component";
import { RegisterComponent } from "./registration/register.component";
import { ForgotpasswordComponent } from "./forgotpassword/forgotpassword.component";
import { Http, Response, Headers } from '@angular/http';
import { MyDatePickerModule } from 'mydatepicker';
import { LoginBusiness } from "../../component/business/login.business";
import { LoginService } from "../../component/service/login.service";
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule,
        MyDatePickerModule
    ],
    declarations: [
        LoginComponent,
        RegisterComponent,
        ForgotpasswordComponent
    ],
    providers: [
        LoginBusiness,
        HttpRequestService,
        Config,
        LoginService, 
        LoaderService
    ],
    exports: [
       LoginComponent,
       RegisterComponent,
       ForgotpasswordComponent
    ]
})

export class SharedLoginModule { }