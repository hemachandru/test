export interface Logout {
    rating: any;
    comment: any;
}