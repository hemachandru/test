import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { NgForm } from '@angular/forms';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';
import { Logout } from './logout.entity';
import { StarRatingComponent } from './rating/rating';
import { LoginBusiness } from '../business/login.business';
import { LoginService } from '../service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
@Component({
    selector: 'log-out',
    templateUrl: './logout.component.html',
    styleUrls: ['./logout.component.scss'],
    providers: [LoginBusiness, LoginService, Config, HttpRequestService]
})
export class LogoutComponent implements OnInit, AfterViewInit {
    public logout: Logout;
    @ViewChild('logoutref') public logoutref: TemplateRef<any>;
    dialog: DialogRef<any>;
    rating = -1;
    rating2 = 2;
    max = 10;
    starcolor = "#ccc";
    readonly = false;
    fillcolor = "#ccc";
    alerthide = false;
    userCurrentRating: any;
    ratingChanged(value: any) {
        setTimeout(() => {
            this.alerthide = false;
            this.logout.rating = value.ratingvalue;
            this.cdr.detectChanges();
        });
    }

    PrintValue() {
    }
    constructor(private location: PlatformLocation, private cdr: ChangeDetectorRef, private loaderService: LoaderService, private router: Router, private loginBusiness: LoginBusiness, private config: Config, public modal: Modal, overlay: Overlay, vcRef: ViewContainerRef) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        this.logout = {
            rating: -1,
            comment: ''
        }
    }
    ngAfterViewInit() {
        this.cdr.detectChanges();
    }
    onLogout() {
        this.userCurrentRating = localStorage.getItem('userRatingValue');
        if (this.userCurrentRating && localStorage.getItem('currentUser') != "LpUser") {
            this.router.navigate(['portal-login']);
            localStorage.clear();
            return false;
        }

        if (localStorage.getItem('currentUser') == "LpUser") {
            this.loaderService.display(true);
            setTimeout(() => {
                localStorage.clear();
                this.loaderService.display(false);
                this.router.navigate(['portal-login']);
            }, 500);
        } else {
            return this.modal.open(this.logoutref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-logout' }, BSModalContext))
                .then(dialog => {
                    this.dialog = dialog;
                })
        }
    }
    onSubmit(resetData: any, formData: NgForm) {
        if (this.logout.rating == -1) {
            this.alerthide = true;
            return false;
        }
        this.loginBusiness.postLogoutData(this.logout).subscribe(res => {
            this.dialog.close();
            setTimeout(() => {
                this.router.navigate(['portal-login']);
                localStorage.clear();
            }, 500);
        }, (err) => {
            this.loaderService.display(false);
        });

    }
    onLogmeout() {
        this.dialog.close();
        setTimeout(() => {
            this.router.navigate(['portal-login']);
            localStorage.clear();
        }, 500);
    }
}