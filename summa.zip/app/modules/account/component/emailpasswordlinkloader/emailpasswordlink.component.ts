import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';

import { Forgot } from '../../entity/forgot.entity';

@Component({
  selector: 'app-login',
  templateUrl: './emailpasswordlink.component.html',
  styleUrls: ['./emailpasswordlink.component.scss'],
  providers: [LoginBusiness, LoginService, Config, HttpRequestService]
})
export class EmailPasswordLinkComponent implements OnInit, OnDestroy {

  private uid: string;
  private id: string;
  private subcription: any;

  constructor(private loginBusiness: LoginBusiness, private route: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    this.subcription = this.route.params.subscribe(params => {
      let idValue = params['id'].split(':');
      let uidValue = params['uid'].split(':');
      this.uid = uidValue[1];
      this.id = idValue[1];
      if (this.uid && this.id) {
        localStorage.setItem('session_Token', this.uid);
        localStorage.setItem('forgetPassworUserId', this.id);
        this.router.navigate(['loginresetpassword']);
      } else {
        this.router.navigate(['portal-login']);
      }
    });
  }

  ngOnDestroy() {
    if (this.subcription) {
      this.subcription.unsubscribe();
    }
  }

}