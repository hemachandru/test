import { Component, OnInit, ElementRef, Renderer, Input } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
  selector: 'privacy',
  templateUrl: './privacy.component.html',
  styleUrls: ['./privacy.component.scss']
  // host: {
  //   '(window:resize)': 'onResize($event)'
  // }
})


export class PrivacyComponent implements OnInit {
  /**Slimscroll */
  public opts: ISlimScrollOptions;
  constructor(private router: Router, private el: ElementRef) { }
  ngOnInit() {

    var isBacktoPrivacy = localStorage.getItem('isBacktoPrivacy');
        if(isBacktoPrivacy == 'privacySuccesspage'){
            this.router.navigate(['consult']);
        }


    this.opts = {
      position: 'right',
      barBackground: 'rgb(173, 181, 189)',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }
  onAgree() {
    //localStorage.setItem('currentUser', "PatientUser");
    setTimeout(() => {
      var stat = 'privacySuccesspage';
        localStorage.setItem('isBacktoPrivacy', stat);
      this.router.navigate(['consult']);
    }, 500);

  }

}