import { Route } from '@angular/router';

import { LoginComponent } from './component/shared/login/login.component';
import { RegisterComponent } from './component/shared/registration/register.component';

export const AccountRoutes: Route[] = [
	{
		path: '',
		component: LoginComponent
	},
	{
		path: '',
		//loadChildren: './account/component/registration/register.module#RegisterModule'
	}
];