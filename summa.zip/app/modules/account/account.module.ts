import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Http, Response, Headers } from '@angular/http';
import { SlimScrollModule } from 'ng2-slimscroll';

import { LoginComponent } from './component/shared/login/login.component';
import { RegisterComponent } from './component/shared/registration/register.component';;
import { ForgotpasswordComponent } from './component/shared/forgotpassword/forgotpassword.component';
import { EqualValidator } from './validator/equal-validator.directive';
import { EmailPasswordLinkComponent } from './component/emailpasswordlinkloader/emailpasswordlink.component';
import { LoaderService } from '../../shared/shared-loader/shared-loader.service';

@NgModule({
    imports: [CommonModule, RouterModule, FormsModule, SlimScrollModule],
    declarations: [LoginComponent, RegisterComponent, ForgotpasswordComponent, EqualValidator, EmailPasswordLinkComponent],
    providers: [LoaderService],
    exports: [LoginComponent, RegisterComponent, ForgotpasswordComponent, EqualValidator, EmailPasswordLinkComponent]
})

export class AuthModule { }
