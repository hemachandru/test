
export class AppointmentList{
          
           Appointment_Id : Number;
         
           Appointment_Date_Only  : DateTime;
         
           Appointment_EndDate :DateTime;
         
           Appointment_StartTime  :String;
         
           Appointment_EndTime  :String;
         
           Patient_First_Name  :String;
         
           Patient_Last_Name  :String;
         
           Provider_First_Name  :String;
         
           Provider_Last_Name  :String;
         
           Appointment_Type  :String;
         
           Appointment_Status  :String;
         
           Appointment_Reason  :String;
         
           Appointment_CreateDateTime  :DateTime;
         
           Provider_Id  :Number;
         
           Patient_Id  :Number;
         
           Reason_TXT  :String;
         
           Cancel_By  :String;
         
           Cancel_Until  :Number;
         
           Provider_Type  :String;
         
           Previous_Appointment_Date :DateTime ;
         
           Clinic: ClinicInfo;  
         
           Notification :Boolean
}


   class ClinicInfo
    {
        
          Clinic_Id :Number;
        
           Clinic_Name  :String;
        
           Clinic_Logo_URL  :String;
        
          Address : [{ Address_Id :number, User_Address :string,
                            City:string, Postal_Code:string,Province :string,
                            Country :string,Work_Phone :string,Home_Phone:string,
                            Cell_Phone: string,Fax:string,Address_Type:string,
                            Longitude:string,Latitude:string,}]; 
    }


