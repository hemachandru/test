export interface ManageSettingInterfcae {
    oldpassword: string; 
    newpassword: string; 
    confirmpassword: string; 
    username: string;
    firstname: string;
    lastname:string;
    email:string;
    phone:string;
    residenceaddress: string;
    residencecity: string;
    residencehomephone: string;
    residenceprovince: string;
    residencecellphone: string;
    residencepostal: string;
    residenceworkphone: string;
    shippingaddress: string;
    shippingcity: string;
    shippinghomephone: string;
    shippingprovince: string;
    shippingcellphone: string;
    shippingpostal: string;
    shippingworkphone: string;

}

export class UserProfile {
    
}