export interface PatientVitalsInterface {
    id: number,
    patient_ID: number,
    bPsys: number,
    bPDia: number,
    heartRate: number,
    respRate:number,
    temperature:number,
    o2Saturation:number,
    created_Date:string,
}
