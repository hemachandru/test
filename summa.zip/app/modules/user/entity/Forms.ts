
export class Forms{
    FieldsCount: number;
    FormID:number;
    Name:string;
}

export class SelectedForms{
    FormID:number;
    Name:string;
    Mandatory:boolean;
    Selected : boolean;
}

