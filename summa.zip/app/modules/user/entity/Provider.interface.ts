  export class Provider {
                Provider_Id :number;  
                Clinic_Id :number;  
                Clinic_Name : string;  
                Provider_First_Name  :string ;       
                Provider_Last_Name :string  ;      
                Provider_UserName :string  ;          
                Provider_Type  :string    ;      
                Provider_Status :string  ;             
                Provider_License_No  :string ;            
                Gender :string ;              
                Email   :string ;            
                Profile_Status  :string;           
                Appt_Days_Allowed   :number;               
                Appt_Allow_SameDay_Booking :boolean;                 
                Appt_Hours_Ahead_Booking :number;                  
                Provider_Position :string ;
                address :[{ Address_Id :number, User_Address :string,
                            City:string, Postal_Code:string,Province :string,
                            Country :string,Work_Phone :string,Home_Phone:string,
                            Cell_Phone: string,Fax:string,Address_Type:string,
                            Longitude:string,Latitude:string,}];  
                
         // List<Provider_Clinic_Relation> ProviderClinicRelations
                ProviderClinicRelations :[{PCR_ID :number, Provider_ID :number,    
                            Clinic_ID:number,ParentClinic_ID :number, 
                            ParentClinicUserName :number,Clinic_Name:string,
                            Relation_Status:boolean,Assigned_Date:Date,     
                            Address :[{ Address_Id :number, User_Address :string,
                            City:string, Postal_Code:string,Province :string,
                            Country :string,Work_Phone :string,Home_Phone:string,
                            Cell_Phone: string,Fax:string,Address_Type:string,
                            Longitude:string,Latitude:string,}],
                            Verify_Patients :boolean,Book_Unverified_Patients :boolean}];
     
         // List<CommunicationPermissionsList> Communication_Permissions   
               Communication_Permissions :[{  CP_Code:Communication_Permissions_enum,
                                              Permission:boolean,Processed :boolean}]; 
          //List<MVCAdmin.MVCUserPermissions> MVCUser_Permissions   
                MVCUser_Permissions:[{MVCUPUR_ID :number,User_ID:string,      
                                      ClinicID:number,MVCUser_Permission:MVCUser_Permissions_enum,
                                      Permission:boolean,Created_Date:Date,      
                                      Deleted :boolean,ProviderID:number}];
            
           BillingRequired :boolean;  
         
           BillingNumber:string;   
         
           BillingType:number;
}

export enum Communication_Permissions_enum {
        APCH = 1,    //Notifications for when an appointment is changed.
        APCN,    //Notifications for when an appointment is canceled.
        APCR,    //Notifications for when an appointment is created.
        APRM,    //Notification for when you have an upcoming appointment.
        CSRQ,    //Notification for when you receive a new consultation request.

        MDAC,    //Notification for when a medical document is accepted by a licensed producer.
        MDCR, //Notification for when a medical document is created.
        MDFW, //Notification for when a medical document is forwarded to a licensed producer.
        MDSV, //Notification for when a medical document is sent for verification.
        PHAS, //Notification for when a patient is assigned to you.
        PRUP, //Notification for when your profile is updated.

        MDDC,    //Notification for when a medical document is declined by a licensed producer.
        MDNV,    //Notification for when a medical document is not verified by a physician.
        MDVR    //Notification for when a medical document is verified by a physician.
}

 export enum MVCUser_Permissions_enum
    {
        MDVRP,
        MVCRPTPD,
        MVCRPTRGLP,
        MVCRPTAPLP,
        MVCRPTPATAPT,
        MVCRPTMDEXP,
        MVCRPTPATTR,
        MDCP,
        MVCRPTPHS
    } 
 

export class PhysicianListForAppReasons{
    physicianID: number;
    selected:boolean;
    physicianName:string;
}
export class EducatorsListForAppReasons{
    EducatorsID: number;
    selected:boolean;
    EducatorsName:string;
}
export class StaffsListForAppReasons{
    StaffsID: number;
    selected:boolean;
    StaffName:string;
}
