export interface ReferoutInterface {
    pR_ID:number
    patientID: number,
    referredByClinicID: number,
    referredByProviderID: number,
    referredToClinicID: number,
    referredToProviderID: number,
    status:string,
    statusUpdatedBy:string,
    reason:string,
    referred_Status:string,
    consultationRequired:boolean
}
