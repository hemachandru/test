export interface ProvidersList {
    Provider_Id:number
    Provider_First_Name: string
    Provider_Last_Name: string
}


export interface ProvinceList {
    Provider_Id:number
    Provider_First_Name: string
    Provider_Last_Name: string
}


export interface RegisterPatientByClinic{
    Email:string;
    FirstName:string;
    Phone:string;
    LastName:string;
    Password:string;
    Province_of_Hin:string;
    SecurityAnswer:string;
    SecurityQuestion:string;
    UserName :string;
    ReferredBy :number;
    ReferredByOtherDesc :string;
    URL_Flag : string;
    ClinicRegisteration: ClinicRegisteration;
}

export interface ClinicRegisteration {
    ClinicID: number;
    ProviderID: number;
}

