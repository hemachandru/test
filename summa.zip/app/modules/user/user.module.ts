import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from './component/user.component';
import { emailSetting } from './component/emailSettings/emailSetting.component';
import { managesetting } from './component/personalinformation/managesetting.component';
import { ChangePasswordComponent } from './component/changepassword/changepassword.component';
import { EmailNotificationComponent } from './component/editnotification/edit-notification.component';
import { EditPersonalInfoComponent } from './component/editpersonalinfo/edit-personalinfo.component';
import { ClinicsAdminComponent } from './component/clinics-administration/clinics-admin.component';
import { SetAppointmentComponent } from './component/clinics-administration/setappointment/set-appointment.component';
import { AdminLPRequestComponent } from './component/user-lp-request/lp-request/lp-request.component';
import { AdminLPRequestListComponent } from './component/user-lp-request/lp-request-list/lp-request-list.component';
import { PatientClinicsComponent } from './component/patient-clinics/patient-clinics.component';
import { PatientListComponent } from './component/patient-clinics/patient-list/patient-list.component';
import { PatientViewComponent } from './component/patient-clinics/patient-view/patient-view.component';
import { PatientRefferalComponent } from './component/patient-clinics/patient-view/patient-referral/patient-referral.component';
import { PatientRegisterComponent } from './component/patient-clinics/patient-view/register-patient/register-patient.component';
import { UserStatusComponent } from './component/user-status/user-status.component';
import { NewMedicalComponent } from './component/patient-clinics/medical-document/medical-document.component';
import { PatientPhaseComponent } from './component/patient-clinics/patient-phase/patient-phase.component';
import { PatientReferComponent } from './component/patient-clinics/patient-referout/patient-referout.component';
import { PatientPhysicianComponent } from './component/patient-clinics/patient-physician/patient-physician.component';
import { PatientVitalsComponent } from './component/patient-clinics/patient-vitals/patient-vitals.component';
import { PatientsPendingDocument } from "./component/user-status/patients-pending-document/patients-pending-document.component";
import { PatientsPendingPhysician } from "./component/user-status/patients-pending-physician/patients-pending-physician.component";
import { PatientsNotesComponent } from "./component/patient-clinics/medical-document/patient-notes/patient-notes.component";
/* import { MedicalDocumentComponent } from "../record/component/shared/medical-document/medical-document.component"; */
import { MedicalComponentModel } from '../../../app/modules/record/component/shared/medical-componentmodel';
import { UserRoutingModule } from './user.routing';
import { SharedModule } from "../../shared/sharedmodule/shared.module";
import { FormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { EqualValidator } from './validator/equal-validator.directive';
import { SlimScrollModule } from 'ng2-slimscroll';
import { MyDatePickerModule } from 'mydatepicker';
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { UserService } from './service/user.service';
import { UserBusinessService } from './business/user.business';
import { Config } from '../../config/constant';
import { LayoutComponent } from "../layout/component/layout.component";
import { SwiperModule } from 'ngx-swiper-wrapper';
import { SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { ClinicService } from "../clinic/service/clinic.service";
import { ClinicBusiness } from "../clinic/business/clinic.business";
import { ClinicModule } from '../clinic/clinic.module';
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { ClientBusiness } from '../client/business/client.business';
import { ClientService } from '../client/service/client.service';
import { Ng2CompleterModule } from "ng2-completer"
import { RecordBusiness } from '../record/component/business/record.business';
import { RecordService } from '../record/component/service/record.service';
import { PrintService } from "../../shared/shared-util/shared-print-service";
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";
import { AddAppointmentReasonComponent } from './component/clinics-administration/setappointment/AddAppointmentReason/Add-AppointmentReason.component';
import {AppointmentHistoryComponent} from './component/patient-clinics/AppointmentHistory/AppointmentHistory.component';

const SWIPER_CONFIG: SwiperConfigInterface = {
  direction: 'horizontal',
  slidesPerView: '1',
  keyboardControl: true
};

@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,
    SlimScrollModule,
    MyDatePickerModule,
    SharedModule,
    TextMaskModule,
    SharedServiceModule,
    SwiperModule.forRoot(SWIPER_CONFIG),
    ClinicModule,
    PipeModule,
    Ng2CompleterModule,
    MedicalComponentModel
  ],
  declarations: [
    UserComponent,
    managesetting,
    emailSetting,
    ChangePasswordComponent,
    EmailNotificationComponent,
    EditPersonalInfoComponent,
    ClinicsAdminComponent,
    EqualValidator,
    SetAppointmentComponent,
    AdminLPRequestComponent,
    AdminLPRequestListComponent,
    PatientClinicsComponent,
    PatientListComponent,
    PatientViewComponent,
    UserStatusComponent,
    PatientsPendingDocument,
    PatientsPendingPhysician,
    NewMedicalComponent,
    PatientRefferalComponent,
    PatientRegisterComponent,
    PatientPhaseComponent,
    PatientReferComponent,
    PatientPhysicianComponent,
    PatientVitalsComponent,
      PatientsNotesComponent,
      AddAppointmentReasonComponent,
      AppointmentHistoryComponent
  ],
  providers: [
    HttpRequestService,
    UserService,
    UserBusinessService,
    Config,
    LayoutComponent,
    ClinicService,
    ClinicBusiness,
    ClientBusiness,
    ClientService,
    RecordBusiness,
    RecordService,
    PrintService
  ],
})
export class UserModule { }