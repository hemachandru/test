import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Provider } from '../entity/Provider.interface';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { UserService } from '../service/user.service';
import { Config } from '../../../config/constant';
import { Forms } from '../entity/Forms';
import { SelectedForms } from '../entity/Forms';

@Injectable()
export class UserBusinessService {

    private observable = new BehaviorSubject(true);
    private selectedItems: any = [];
    // Observable string streams
    profileDetails$ = this.observable.asObservable();

    constructor(private http: Http, private _hrs: HttpRequestService, private _us: UserService, private _config: Config) { }

    getUserInfo() {
        let url = this._config.userdetailUrl;
        return this._us.getUserInfo(url).map(res => res.json());
    }

    registerPatientByClinic(data: any)
    {
        let url = this._config.SignUp;
        let params: object = {
            "Email": data.Email,
            "FirstName": data.FirstName,
            "Phone": data.Phone,
            "LastName": data.LastName,
            "Password": data.Password,
            "Province_of_Hin": data.Province_of_Hin,
            "SecurityAnswer": data.SecurityAnswer,
            "SecurityQuestion": data.SecurityQuestion,
            "UserName": data.UserName,
            "ReferredBy": data.ReferredBy,
            "ReferredByOtherDesc": data.ReferredByOtherDesc,
            "URL_Flag": data.URL_Flag,
            "ClinicRegisteration": {
                "ClinicID": data.ClinicRegisteration[0].ClinicID,
                "ProviderID": data.ClinicRegisteration[0].ProviderID
            }

        }
        return this._us.registerPatientByClinic(params, url).map(res => res.json());
    }


    sendProfileDetails(details: any) {
        this.observable.next(details);
    }

    createOrUpdateProfile(data: any, isNotify: boolean) {
        let url = this._config.CreateORUpdateProfile;
        let params: object = {
            "Patient_ID": data.Patient_ID,
            "Creating_Profile_First_Time": true,
            "Patient_User_Name": data.Patient_User_Name,
            "First_Name": data.First_Name,
            "Last_Name": data.Last_Name,
            "Email": data.Email_Address,
            "LoweredEmail": data.Email_Address,
            "Phone": data.Phone,
            "DOB": data.DOB,
            "Gender": data.Gender,
            "MedicalConditions": data.MedicalConditions,
            "Height": data.Height,
            "Weight": data.Weight,
            "Profile_Status": data.Profile_Status,
            "Address_List": data.Address_List,
            "HIN": data.HIN,
            "NewsLetterSubscription": data.NewsLetterSubscription,
            "Communication_Permissions": {
                "UserName": data.Patient_User_Name,
                "PermissionsList": isNotify ? data.Communication_Permissions.PermissionsList : []
            },
            "ReferredBy": data.ReferredBy,
            "ReferredByOtherDesc": data.ReferredByOtherDesc,
            "ClinicalPatientID": data.ClinicalPatientID,
            "LPRegNo": data.LPRegNo,
            "Experience": null
        }
        return this._us.createOrUpdateProfile(params, url).map(res => res.json());
    }

    getUserUpdateLoginResponse(data: any) {
        let url = this._config.getUserUpdateLoginResponse;
        let params = {
            "UserName": data.user_name,
            "UserRole": data.user_role
        };
        return this._us.getUserUpdateLoginResponse(params, url).map(res => res.json());
    }

    getLpMedicalRequests() {
        let url = this._config.lpMedicalDocumentList + localStorage.getItem('clinicId') + "/" + "Clinics" + "/" + localStorage.getItem('clinicId') + "/'LPSVTP'";
        return this._us.getLpReqList(url).map(res => res.json());
    }
    getLpSignedRequests() {
        let url = this._config.lpMedicalDocumentList + localStorage.getItem('clinicId') + "/" + "Clinics" + "/" + localStorage.getItem('clinicId') + "/'EDCR'";
        console.log("ur;", url);
        return this._us.getLpReqList(url).map(res => res.json());
    }
    getLpReqCount() {
        let url = this._config.lpCount + localStorage.getItem('clinicId') + "/" + localStorage.getItem('mvcUser_Id');
        return this._us.getLpCount(url).map(res => res.json());
    }
    getMedicalDoc(medical_id: any) {
        let url = this._config.getMedicalDocumentLP + medical_id;
        return this._us.getMedicalDocument(url).map(res => res.json());
    }
    postMedicalDoc(data: any) {
        let url = this._config.postMedicalDocumentLP;
        let params: any = {
        }
        return this._us.postMedicalDocument(JSON.stringify(params), url).map(res => res.json());
    }
    updateMedicalDoc(data: any) {
        let url = this._config.lpVerify;
        let params: any = {
            "LP_Id": data.LP_Id,
            "Medical_Doc_Id": data.Medical_Document_Id,
            "Doc_Status": data.Doc_Status,
            "Medical_Doc_Relation_Id": data.Medical_Doc_Relation_Id,
            "Decline_Notes": data.Decline_Notes,
            "Not_Verified_Notes": data.Decline_Notes,
            "Patient_Id": data.Patient_Id,
            "Provider_Id": data.Provider_Id,
            "PatientProductRequests": data.PatientProductRequests,
            "IsPrinted": data.IsPrinted,
            "Provider_LocalIP": null,
            "Provider_ISPIP": null,
            "LP_ComingFrom": null,
            "Provider_Browser": null,
            "Provider_OSVersion": null,
            "Provider_PCAccount": null
        }
        console.log("params", params);
        return this._us.putLpVerified(JSON.stringify(params), url).map(res => res.json());
    }
    lpVerifiedorDeclined(data: any) {
        let url = this._config.lpVerify;
        let params: any = {
            "LP_Id": data.LP_Id,
            "Medical_Doc_Id": data.Medical_Doc_Id,
            "Doc_Status": data.Doc_Status,
            "Medical_Doc_Relation_Id": data.Medical_Doc_Relation_Id,
            "Decline_Notes": data.Decline_Notes,
            "Not_Verified_Notes": data.Decline_Notes,
            "Patient_Id": data.Patient_Id,
            "Provider_Id": data.Provider_Id,
            "PatientProductRequests": data.PatientProductRequests,
            "IsPrinted": data.IsPrinted,
            "Provider_LocalIP": null,
            "Provider_ISPIP": null,
            "LP_ComingFrom": null,
            "Provider_Browser": null,
            "Provider_OSVersion": null,
            "Provider_PCAccount": null
        }
        console.log("url,param,s", url, params);
        return this._us.putLpVerified(JSON.stringify(params), url).map(res => res.json());
    }

    /**
     * for clinic patient tab load the patient details related to this clinic.
     *
     */
    getPatientListForClinic() {
        let param: object = { "SearchCode": 0, "SearchTerm": "", "MVC_UserID": Number(localStorage.getItem('mvcUserId')), "ClinicID": Number(localStorage.getItem('clinic-clinic-Id')), "Role": localStorage.getItem('userRole') };
        return this._us.getPatientListForClinic(JSON.stringify(param), this._config.clinicAllPatient).map(res => res.json());
    }

    /**
     * this service save the user given SpecialNotes text
     * @param params
     * @param url
     */
    saveSpecialNotes(patientId: number, specialNotes: string) {
        let regParam: Object = { "PatientID": patientId, "SpecialNotes": specialNotes };
        return this._us.saveSpecialNotes(JSON.stringify(regParam), this._config.addPatientSpecialNotes).map(res => res.json());
    }

    /**
     *
     * @param params this service used for complete profile patient page add or update user detail
     * @param url
     */
    saveOrModifyCompleteProfile(formData: any, userDetail: any, filterExistingOrPreviousConditionResult: any, filterMedicalTherapiesConditionResult: any, medicationData: any) {
        let incompleteStatus = "Incomplete";

        if (formData.primaryPhoneNumber != "" && formData.gender != "" && formData.height != "" && formData.weight != "" && filterExistingOrPreviousConditionResult.toString() != "" && filterMedicalTherapiesConditionResult.toString() != "" && medicationData.toString() != "") {
            incompleteStatus = "Complete";
        }
        let reqParam: object = {
            "Patient_ID": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Patient_ID : '',
            "Creating_Profile_First_Time": false,
            "Patient_User_Name": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Patient_User_Name : '',
            "First_Name": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.First_Name : '',
            "Last_Name": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Last_Name : '',
            "Email": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Email_Address : '',
            "LoweredEmail": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Email_Address.toLowerCase() : '',
            "Phone": formData.primaryPhoneNumber,
            "DOB": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.DOB : '',
            "Gender": formData.gender,
            "MedicalConditions": filterExistingOrPreviousConditionResult ? filterExistingOrPreviousConditionResult.toString() : '',
            "Height": formData.height,
            "Weight": formData.weight,
            "Profile_Status": incompleteStatus,
            "Address_List": userDetail.Address_List ? userDetail.Address_List : [],
            "HIN": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.HIN : '',
            "Communication_Permissions": {
                "UserName": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Patient_User_Name : '',
            },
            "ReferredBy": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.ReferredBy : 0,
            "ReferredByOtherDesc": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.ReferredByOtherDesc : '',
            "ClinicalPatientID": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.ClinicalPatientID : '',
            "LPRegNo": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.LPRegNo : '',
            "Experience": userDetail.Patient_Login_Data ? userDetail.Patient_Login_Data.Experience : '',
            "Therapies": filterMedicalTherapiesConditionResult ? filterMedicalTherapiesConditionResult.toString() : '',
            "Medications": medicationData ? medicationData.toString() : '',
        }

        return this._us.saveOrModifyCompleteProfile(JSON.stringify(reqParam), this._config.CreateORUpdateProfile).map(res => res.json());
    }
    /**service get the previous patient selected stage
     *
     * @param patientId
     */
    getStageAssigmentToPatient(patientId: number) {
        let url = this._config.getPatientStage + localStorage.getItem('clinic-clinic-Id') + "/" + patientId + "/true"
        return this._us.getStageAssigmentToPatient(url).map(res => res.json());
    }

    /**service get the client related stage
     *
     * @param
     */
    getClinicStages() {
        let url = this._config.getClinicsStage + localStorage.getItem('clinic-clinic-Id') + "/true"
        return this._us.getClinicStages(url).map(res => res.json());
    }

    /**
     * service update or add patient selected phase in clinic patient
     * @param previousPatientStage
     * @param selectedclientStage
     * @param patientId
     * @param clientId
     */
    saveAddUpdatePatientStage(previousPatientStage: any, selectedclientStage: any, patientId: any, clientId: any) {
        let reqParam: object = {
            "Patient_Stage_ID": previousPatientStage ? previousPatientStage.Patient_Stage_ID : 0,
            "Patient_ID": previousPatientStage ? previousPatientStage.Patient_ID == 0 ? patientId : previousPatientStage.Patient_ID : patientId,
            "Clinic_ID": previousPatientStage ? previousPatientStage.Clinic_ID == 0 ? clientId : previousPatientStage.Clinic_ID : clientId,
            "Stage_ID": selectedclientStage ? selectedclientStage[0].Clinic_Stage_ID : 0,
            "Stage_TXT": selectedclientStage ? selectedclientStage[0].Stage_TXT : '',
            "Assigned_Date": "",
            "IsActive": 1
        }
        return this._us.saveAddUpdatePatientStage(JSON.stringify(reqParam), this._config.addUpdatePatient).map(res => res.json());
    }

    /**
     * service get the clinic list
     * @param params
     * @param url
     */
    getListOfClinics() {
        let reqParam: object = {
            "Search_Code": 0,
            "Province_Name": null,
            "City_Name": null,
            "Clinic_Name": null,
            "Allowed_Appointment_Types": 0,
            "IncludeOscar": false,
            "ParentClinicID": 0,
            "ParentClinicName": null,
            "ShowOnlySearchable": false
        }
        return this._us.getListOfClinics(JSON.stringify(reqParam), this._config.patientsSearchClinics).map(res => res.json());
    }

    /**
     * this service get the provider list by clinic id.
     * @param clinicId
     */
    getProviderByClinicId(clinicId: number) {
        return this._us.getProviderByClinicId(this._config.providerByClinicId + clinicId).map(res => res.json());
    }

    /**
     * this service senfOut or refer out patient to another clinic
     * @param params
     * @param url
     */
    addSendOrReferPatient(sendOrRefer: any) {
        let reqParam: object = {
            "PR_ID": sendOrRefer.pR_ID,
            "PatientID": sendOrRefer.patientID,
            "ReferredByClinicID": sendOrRefer.referredByClinicID,
            "ReferredByProviderID": sendOrRefer.referredByProviderID,
            "ReferredToClinicID": sendOrRefer.referredToClinicID,
            "ReferredToProviderID": sendOrRefer.referredToProviderID,
            "Status": sendOrRefer.status,
            "StatusUpdatedBy": sendOrRefer.statusUpdatedBy,
            "Created_Date": "",
            "Edited_Date": "",
            "Reason": sendOrRefer.reason,
            "Referred_Status": sendOrRefer.referred_Status,
            "ConsultationRequired": sendOrRefer.consultationRequired
        }

        return this._us.addSendOrReferPatient(JSON.stringify(reqParam), this._config.sendOrReferOutPatient).map(res => res.json());
    }

    /**
     * this service get the physician History by patient id
     * @param url
     */
    getPhysicianHistory(patientId: number) {
        return this._us.getPhysicianHistory(this._config.getPhysicianHistory + patientId).map(res => res.json());
    }

    /**
     * this service get the PatientVitals detail by patientId
     * @param url
     */
    getPatientVitalsByPatientId(patientId: number) {
        return this._us.getPatientVitalsByPatientId(this._config.getPatientVitals + patientId + "/-1").map(res => res.json());
    }

    /**
     * This service save patientvitals history
     * @param params
     * @param url
     */
    addPatientVitals(patientVitalsData: any) {
        let reqParam: object = {
            "Patient_ID": patientVitalsData.patient_ID,
            "BPsys": patientVitalsData.bPsys,
            "BPDia": patientVitalsData.bPDia,
            "HeartRate": patientVitalsData.heartRate,
            "RespRate": patientVitalsData.respRate,
            "Temperature": patientVitalsData.temperature,
            "O2Saturation": patientVitalsData.o2Saturation
        }
        return this._us.addPatientVitals(JSON.stringify(reqParam), this._config.addPatientVitals).map(res => res.json());
    }

    /**
     * this service get the all the given notes of single patient .
     * @param url
     */
    getAllPatientNotes(patientId: number) {
        return this._us.getAllPatientNotes(this._config.getPatientAllNotes + patientId).map(res => res.json());
    }

    /**
    * this.service add patient relates nots
    * @param params
    * @param url
    */
    addorModifyProviderNote(localPatientId: number, saveNotesText: string, New_Note: boolean) {
        let reqParam: object = {
            "New_Note": New_Note,
            "Note_Id": 0,
            "Patient_Id": localPatientId,
            "Provider_Id": 96,   //Number(localStorage.getItem('mvcUserId')
            "Provider_First_Name": "Saanthasheelan", //(localStorage.getItem('Provider_First_Name')
            "Provider_Last_Name": "SS",   //(localStorage.getItem('Provider_Last_Name')
            "Note_Subject": null,
            "Note_Text": saveNotesText,
            "Created_Date_Time": ""
        }
        return this._us.addorModifyProviderNote(JSON.stringify(reqParam), this._config.addorModifyProviderNote).map(res => res.json());
    }

    updatePatientMedicalNotes(localPatientId: number, medicalHistoryNotes: string, medicationsNotes: string, vitalsNotes: string, miscelleaneousNote: string) {
        let reqParam: object = {

            "PatientId": localPatientId,
            "MedicalHistory": medicalHistoryNotes,
            "Medications": medicationsNotes,
            "Vitals": vitalsNotes,
            "Miscelleaneous": miscelleaneousNote

        }
         return this._us.updatePatientMedicalNotes(JSON.stringify(reqParam), this._config.updatePatientMedicalNotes).map(res => res.json());
    }

    /**
     * this service get the pending patient referrals detail.
     * @param url
     */
    getPendingPatientReferrals(){
        return this._us.getPendingPatientReferrals(this._config.pendingGetPatientReferrals+localStorage.getItem("clinic-clinic-Id")+"/Pending").map(res => res.json());
    }

    /**
     * this service get the Appointment Reason.
     * @param url
     */

    getAllClinicAppointmentReasons() {
        return this._us.getAllClinicAppointmentReasons(this._config.getAllClinicAppointmentReasons + localStorage.getItem("clinic-clinic-Id") ).map(res => res.json());
    }

     AddUpdateClinicAppointmentReasons( CAR_ID :number,Clinic_ID:string,Reason_TXT :string,Description:string,Appointment_Type:string,Book_By: boolean,cost:number,Book_Untill:number,Cancel_By:string,
                                       Cancel_Until: number,Active :boolean,Registration:boolean,Request:boolean,Appointment_TimeSlot:number,Booking_Days:number,Provider_ID:number[],FormIDs:any[],MandatoryIDs:boolean[])
    {

       let reqParam: object = {
            "CAR_ID": CAR_ID,
            "Clinic_ID": Clinic_ID,
            "Reason_TXT": Reason_TXT,
            "Description": Description,
            "Appointment_Type": Appointment_Type,
            "Book_By": Book_By,
            "Book_Untill":Book_Untill,
            "Cancel_By":Cancel_By,
            "cost":cost,
            "Cancel_Until":Cancel_Until,
            "Active" :Active,
            "Registration":Registration,
            "Request":Request,
            "Appointment_TimeSlot":Appointment_TimeSlot,
            "Booking_Days":Booking_Days,
            "ProviderIDs":Provider_ID,
            "FormIDs" : FormIDs,
            "MandatoryIDs" :MandatoryIDs,
            //"FormsList":formList
        }
     return this._us.AddUpdateClinicAppointmentReasons(JSON.stringify(reqParam), this._config.AddUpdateClinicAppointmentReasons).map(res => res.json());

    }

    GetForms(Clinic_ID:string){
        let headers = ["APIKey","5x2l6y1V95Plyn88dEhj7WDAOI21MNAW46qZyJSrfB7"];
           return this._us.GetForms("api/Form/" + Clinic_ID,headers).map(res => res.json());
    }

    GetUpcomingOrPreviousAppointments(){
        //UserRole:string, MVC_User_Id:number,ClinicID:number, HistoryAppointment:string
        return this._us.GetUpcomingOrPreviousAppointments(this._config.getUpcomingOrPreviousAppointments + 'Patients' + '/' + sessionStorage.getItem("clinicIndividualPatientId") + '/' + localStorage.getItem("clinic-clinic-Id") + '/' + localStorage.getItem("HistoryAppointment")).map(res => res.json());
    }

}