import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './component/user.component';
import { managesetting } from './component/personalinformation/managesetting.component';
import { emailSetting } from './component/emailSettings/emailSetting.component';
import { ChangePasswordComponent } from './component/changepassword/changepassword.component';
import { EmailNotificationComponent } from './component/editnotification/edit-notification.component';
import { EditPersonalInfoComponent } from './component/editpersonalinfo/edit-personalinfo.component';
import { ClinicsAdminComponent } from './component/clinics-administration/clinics-admin.component';
import { SetAppointmentComponent } from './component/clinics-administration/setappointment/set-appointment.component';
import { AdminLPRequestComponent } from './component/user-lp-request/lp-request/lp-request.component';
import { PatientClinicsComponent } from './component/patient-clinics/patient-clinics.component';
import { PatientListComponent } from './component/patient-clinics/patient-list/patient-list.component';
import { PatientViewComponent } from './component/patient-clinics/patient-view/patient-view.component';
import { UserStatusComponent } from './component/user-status/user-status.component';
import { NewMedicalComponent } from './component/patient-clinics/medical-document/medical-document.component';
import { PatientRefferalComponent } from './component/patient-clinics/patient-view/patient-referral/patient-referral.component';
import { PatientRegisterComponent } from './component/patient-clinics/patient-view/register-patient/register-patient.component';
import { PatientPhaseComponent } from './component/patient-clinics/patient-phase/patient-phase.component';
import { PatientReferComponent } from './component/patient-clinics/patient-referout/patient-referout.component';
import { PatientsNotesComponent } from "./component/patient-clinics/medical-document/patient-notes/patient-notes.component";
import { PatientPhysicianComponent } from './component/patient-clinics/patient-physician/patient-physician.component';
import { PatientVitalsComponent } from './component/patient-clinics/patient-vitals/patient-vitals.component';
import { AddAppointmentReasonComponent } from './component/clinics-administration/setappointment/AddAppointmentReason/Add-AppointmentReason.component';
import {AppointmentHistoryComponent} from './component/patient-clinics/AppointmentHistory/AppointmentHistory.component';
export const userRotes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: managesetting,
      },
      {
        path: 'emailSetting',
        component: emailSetting
      },
      {
        path: 'ChangePassword',
        component: ChangePasswordComponent
      },
      {
        path: 'emailnotification',
        component: EmailNotificationComponent
      },
      {
        path: 'editpersonalinformation/:id',
        component: EditPersonalInfoComponent
      },
      {
        path: 'clinicsadmin',
        component: ClinicsAdminComponent
      },
      {
        path: 'set-appointment',
        component: SetAppointmentComponent
      },
      {
        path: 'Add-AppointmentReason',
        component: AddAppointmentReasonComponent
      },
      {
        path: 'lp-request',
        component: AdminLPRequestComponent,
      },
      {
        path: 'patient-clinics',
        component: PatientClinicsComponent,
      },
      {
        path: 'patient-list',
        component: PatientListComponent,
      },
      {
        path: 'patient-view/:id',
        component: PatientViewComponent,
      },
      {
        path: 'user-status',
        component: UserStatusComponent,
      },
      {
        path: 'new-medical',
        component: NewMedicalComponent,
      },
      {
        path: 'patient-referral',
        component: PatientRefferalComponent
      },
      {
        path: 'patient-register',
        component: PatientRegisterComponent
      },
      {
        path: 'patient-phase',
        component: PatientPhaseComponent
      },
      {
        path: 'patient-phase/:id',
        component: PatientPhaseComponent
      },
      {
        path: 'patient-refer',
        component: PatientReferComponent
      },
      {
        path: 'patient-refer/:id',
        component: PatientReferComponent
      },
      {
        path: 'patient-notes',
        component: PatientsNotesComponent
      },
      {
        path: 'patient-notes/:id',
        component: PatientsNotesComponent
      },
      {
        path: 'patient-physician',
        component: PatientPhysicianComponent
      },
      {
        path: 'patient-physician/:id',
        component: PatientPhysicianComponent
      },
      {
        path: 'patient-vitals',
        component: PatientVitalsComponent
      },
      {
        path: 'patient-vitals/:id',
        component: PatientVitalsComponent
      },
      {
        path: 'AppointmentHistory/:id',
        component: AppointmentHistoryComponent
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(userRotes)
  ],
  exports: [
    RouterModule
  ]
})
export class UserRoutingModule {

}
