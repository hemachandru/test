import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { Config } from '../../../config/constant';

@Injectable()
export class UserService {
    constructor(private http: Http, private _hrs: HttpRequestService, private _config: Config) { }

    getUserInfo(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    
    registerPatientByClinic(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }
    
    createOrUpdateProfile(params: any, url: string) {
        return this._hrs.putHttpRequest(params, url);
    }

    getLpReqList(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    getLpCount(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    putLpVerified(params: any, url: string) {
        return this._hrs.putHttpRequest(params, url);
    }
    getMedicalDocument(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    postMedicalDocument(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }
    /**
     * for clinic patient tab load the patient details related to this clinic.
     *
     */
    getPatientListForClinic(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     * this service save the user given SpecialNotes text
     * @param params
     * @param url
     */
    saveSpecialNotes(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     *
     * @param params this service used for complete profile patient page add or update user detail
     * @param url
     */
    saveOrModifyCompleteProfile(params: any, url: string) {
        return this._hrs.putHttpRequest(params, url);
    }

    /**service get the previous patient selected stage
     *
     * @param patientId
     */
    getStageAssigmentToPatient(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**service get the client related stage
     *
     * @param patientId
     */
    getClinicStages(url: string) {
        return this._hrs.getHttpRequest(url);
    }


    /**
         * service update or add patient selected phase in clinic patient
         * @param previousPatientStage
         * @param selectedclientStage
         * @param patientId
         * @param clientId
         */
    saveAddUpdatePatientStage(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     * service get the clinic list
     * @param params
     * @param url
     */
    getListOfClinics(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     * this service get the provider list by clinic id.
     * @param clinicId
     */
    getProviderByClinicId(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * this service senfOut or refer out patient to another clinic
     * @param params
     * @param url
     */
    addSendOrReferPatient(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    /**
     * this service get the physician History by patient id
     * @param url
     */
    getPhysicianHistory(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * this service get the PatientVitals detail by patientId
     * @param url
     */
    getPatientVitalsByPatientId(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * This service save patientvitals history
     * @param params
     * @param url
     */
    addPatientVitals(params: any, url: string) {
        return this._hrs.putHttpRequest(params, url);
    }

    /**
     * this service get the all the given notes of single patient .
     * @param url
     */
    getAllPatientNotes(url: string) {
        return this._hrs.getHttpRequest(url);
    }

    /**
     * this.service add patient relates nots
     * @param params
     * @param url
     */
    addorModifyProviderNote(params: any, url: string) {
        return this._hrs.postHttpRequest(params, url);
    }

    updatePatientMedicalNotes(params: any, url: string) {
        return this._hrs.putHttpRequest(params, url);
    }

    /**
     * this service get the pending patient referrals detail.
     * @param url
     */
    getPendingPatientReferrals(url: string) {
        return this._hrs.getHttpRequest(url);
    }
    getUserUpdateLoginResponse(data: any, url: string) {
        return this._hrs.postHttpRequest(data, url);
    }
/// getAllClinicAppointmentReasons
   getAllClinicAppointmentReasons(url:string){
       return this._hrs.getHttpRequest(url);
   }
/// Add or modify Appointment Reason
    AddUpdateClinicAppointmentReasons(params : any ,url:string){
        return this._hrs.postHttpRequest(params, url);
   }
    
   GetForms(url:string,headers:string[]){
    return this._hrs.getHttpRequest(url,true,headers);
   }

    GetUpcomingOrPreviousAppointments(url:string){
       return this._hrs.getHttpRequest(url); 
    }
}