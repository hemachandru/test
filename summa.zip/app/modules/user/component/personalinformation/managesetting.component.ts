import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { Title } from '@angular/platform-browser';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ManageSettingInterfcae } from '../../entity/user.interface';
import { FormsModule } from '@angular/forms';
import { UserBusinessService } from "../../business/user.business";
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

@Component({
  templateUrl: './managesetting.component.html',
  styleUrls: ["./managesetting.component.scss"]
})
export class managesetting implements OnInit {
  public ManageSetting: ManageSettingInterfcae;
  public invalidEmail: any;
  public invalidPassword: any;
  public invalidDob: any;
  public invalidConfirmPassword: any;
  public idate: any;
  public date = new Date();
  public val: boolean;
  private isAddressAvail: boolean = false;

  private userInfo: any;

  @ViewChild('editprofiletemplate') public editprofiletemplate: TemplateRef<any>;
  @ViewChild('editNotification') public editNotification: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private _ubs: UserBusinessService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _ls: LoaderService) {
    overlay.defaultViewContainer = vcRef;
    this.userInfo = {};
  }
  ngOnInit() {
    this.getUserInfo();
  }
  getUserInfo() {
    this._ls.display(true);
    this._ubs.getUserInfo().subscribe(res => {
      this._ls.display(false);
      if(res) {
        this._ubs.sendProfileDetails(res.Patient_Login_Data);
        this.userInfo = Object.assign({}, res.Patient_Login_Data);
        this.isAddressAvail = res.Patient_Login_Data.Address_List.length > 0 ? true : false;
        let address = {};
        if(res.Patient_Login_Data.Address_List.length > 0) {
          address = res.Patient_Login_Data.Address_List[0];
        } else if(res.Patient_Login_Data.Address_List.length == 2) {
          for (let value of res.Patient_Login_Data.Address_List) {
            if(value.Address_Type == "Residence") {
              address = value;
            } else {
              address = value;
            }
          }
        }
        this.userInfo.Address_List = address;
        console.log(this.userInfo);
      }
    })
  }

  editNofication() {
    return this.modal.open(this.editNotification, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
      this.dialog = dialog;
      //this.close();
    });
  }
  editProfileInfo() {
    return this.modal.open(this.editprofiletemplate, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
      this.dialog = dialog;
      //this.close();
    });
  }
  dialogClosed() {
    this.dialog.close();
  }

}