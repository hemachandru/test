import { Component, OnInit, Inject, TemplateRef, Input, Output, EventEmitter, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import {UserBusinessService } from '../../business/user.business';
import { UserService } from '../../service/user.service';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service'
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { LayoutComponent } from "../../../layout/component/layout.component";
@Component({
    templateUrl: './patient-clinics.component.html',
    styleUrls: ['./patient-clinics.component.scss']
})
export class PatientClinicsComponent implements OnInit {
    public patientData: any ;
    public opts: ISlimScrollOptions;
    public ValidCurrentUser:string="";
    public searchStr: string;
	protected dataService: CompleterData;
	public clearSearchInput: boolean = false;
    public tempPatientData: any;
    constructor(private layoutComponent:LayoutComponent,private completerService: CompleterService, private sharedObserverService:SharedObserverService, private router: Router,private loaderService:LoaderService,private userBusinessService:UserBusinessService) { }
    ngOnInit() {
    if (localStorage.getItem('token')) {
     this.layoutComponent.showSpinner(true);
     sessionStorage.removeItem('clinicIndividualPatientId');
     sessionStorage.removeItem('clinicIndividualPatient');
     this.sharedObserverService.sendindividualPatientSubscriber(true);
     this.ValidCurrentUser = localStorage.getItem('currentUser');
     this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
    }
    //this.loaderService.display(true);
    if(this.ValidCurrentUser =="ClinicsUser" || this.ValidCurrentUser =="DoctorUser"  || this.ValidCurrentUser =="EducatorUser" ){
      this.userBusinessService.getPatientListForClinic().subscribe(res=>{
      this.patientData=res;
      this.tempPatientData =res;
      this.patientData ?this.dataService = this.completerService.local(this.patientData, 'Patient_First_Name,Patient_Last_Name', 'Patient_First_Name,Patient_Last_Name'): "";
      //this.loaderService.display(false);
      this.layoutComponent.showSpinner(false);
      },(err)=>{
      console.log("userBusinessService getPatientListForClinic ", err)
      });
    } 
    }else {
      //this.loaderService.display(false);
      this.layoutComponent.showSpinner(false);
      this.router.navigate(['portal-login']);
    }
    }
    onView(event: any) {
        //localStorage.setItem("clinicPatientId",event.patientData.Patient_Id);
        this.sharedObserverService.sendindividualPatientSubscriber(event.patientData);
        this.router.navigate(["/profile/patient-view/"+event.patientData.Patient_Id]);
    }

    onSelectName(selected: CompleterItem) {
		if (selected) {
			let filterResult = this.tempPatientData.filter((orderData: any) => {
				return (orderData.Patient_First_Name == selected.originalObject.Patient_First_Name) && (orderData.Patient_Last_Name == selected.originalObject.Patient_Last_Name);
			});
			this.patientData = filterResult;
		}
	}

	onChangeSearchText(event: any) {
		if (!event) {
			this.patientData = this.tempPatientData;
		}

	}

}