import { Observable } from 'rxjs/Observable';
import { Component, OnInit,TemplateRef, ViewChild,ViewContainerRef, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { SwiperComponent, SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { PlatformLocation } from '@angular/common';

@Component({
    templateUrl: './medical-document.component.html',
    styleUrls: ['./medical-document.component.scss']
})
export class NewMedicalComponent implements OnInit {
    @ViewChild('lpverify') public lpverify: TemplateRef<any>;
    	dialog: DialogRef<any>;
    public eventvalue :any;    

    public config: SwiperConfigInterface = {
        scrollbar: null,
        observer: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        breakpoints: {
            // when window width is <= 320px
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            },
            // when window width is <= 480px
            480: {
                slidesPerView: 1,
                spaceBetween: 20
            }
        }
    };

 constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef,private location: PlatformLocation) {
	    overlay.defaultViewContainer = vcRef;
	}
    ngOnInit() {
         
    }


    onIndexChange(evt: Event) {
     
        console.log(evt);
        this.eventvalue= evt 
        if (this.eventvalue == 2){
               debugger;
            return this.modal.open(this.lpverify, overlayConfigFactory({ dialogClass: 'modal-dialog lp-modal-center' }, BSModalContext)).then(dialog => {
                this.dialog = dialog;
            });
        }
    }

}