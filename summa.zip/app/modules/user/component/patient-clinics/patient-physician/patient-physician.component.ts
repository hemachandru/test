import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { UserBusinessService } from '../../../business/user.business'
import { ReferoutInterface } from '../../../entity/referout.interface';
import { Config } from '../../../../../config/constant';
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
    templateUrl: './patient-physician.component.html',
    styleUrls: ['./patient-physician.component.scss']
})
export class PatientPhysicianComponent implements OnInit {
    public ValidCurrentUser: string = "";
    public subcription: any;
    public unsubscribe: any;
    public localPatientId: number = 0;
    public patientDetail: any;
    public physicianHistory: any;
    public noData:string =this.config.noData;
    public physicianHistoryDataFlag: boolean=false;

    constructor(private sharedObserverService: SharedObserverService, private layoutComponent: LayoutComponent, private config: Config, private userBusinessService: UserBusinessService, private router: Router, private route: ActivatedRoute, private _location: Location) { }
    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.ValidCurrentUser = localStorage.getItem('currentUser');
            this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
                this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
            if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
            } else {
                Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
            }

            if (!sessionStorage.getItem("clinicIndividualPatient")) {
                this.unsubscribe = this.sharedObserverService.individualPatientReceiver$.subscribe(res => {
                    this.patientDetail = res;
                    sessionStorage.setItem("clinicIndividualPatient", JSON.stringify(res));
                });
            } else {
                this.patientDetail = JSON.parse(sessionStorage.getItem("clinicIndividualPatient"));
            }
            this.userBusinessService.getPhysicianHistory(this.localPatientId).subscribe(res => {
            this.physicianHistory = res;
            res.length ==0 ?this.physicianHistoryDataFlag=true: this.physicianHistoryDataFlag=false;
            this.layoutComponent.showSpinner(false);
            }, (err) => {
                console.log("userBusinessService getPhysicianHistory", err);
            })
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }
    onBack() {
        if (this.localPatientId == 0) {
            this._location.back();
        } else {
            this.router.navigate(['profile/patient-view/' + this.localPatientId]);
        }
    }
}