import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { UserBusinessService } from '../../../business/user.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
    templateUrl: './patient-phase.component.html',
    styleUrls: ['./patient-phase.component.scss']
})
export class PatientPhaseComponent implements OnInit {
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    public ValidCurrentUser: string = "";
    public subcription: any;
    public unsubscribe: any;
    public localPatientId: number = 0;
    public patientDetail: any;
    public assigmentToPatient: any;
    public clientStage: any;
    public selectedStage: any;

    constructor(private layoutComponent: LayoutComponent,private userBusinessService: UserBusinessService, private sharedObserverService: SharedObserverService, private route: ActivatedRoute, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    //initializes the page
    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.selectedStage = "";
            this.ValidCurrentUser = localStorage.getItem('currentUser');
            this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
                this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
            if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
            } else {
                Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
            }

            if (!sessionStorage.getItem("clinicIndividualPatient")) {
                this.unsubscribe = this.sharedObserverService.individualPatientReceiver$.subscribe(res => {
                    this.patientDetail = res;
                    sessionStorage.setItem("clinicIndividualPatient", JSON.stringify(res));
                    console.log("clinicIndividualPatient" + sessionStorage.getItem("clinicIndividualPatient"));
                });
            } else {
                this.patientDetail = JSON.parse(sessionStorage.getItem("clinicIndividualPatient"));
            }
            this.userBusinessService.getStageAssigmentToPatient(this.localPatientId).subscribe(response => {
                this.assigmentToPatient = response;
                this.selectedStage = response.Stage_ID == 0 ? "" : response.Stage_ID;
                console.log("this.assigmentToPatient" + this.assigmentToPatient);
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getStageAssigmentToPatient ", err);
            })

            this.userBusinessService.getClinicStages().subscribe(res => {
                this.clientStage = res;
                console.log("this.clientStage" + this.clientStage[0]);
            }, (err) => {
                console.log("userBusinessService getStageAssigmentToPatient ", err);
            });


        } else {
            this.router.navigate(['portal-login']);
        }
    }
    onBack() {
        if (this.localPatientId == 0) {
            this._location.back();
        } else {
            this.router.navigate(['profile/patient-view/' + this.localPatientId]);
        }

    }
    onSave(selectedValue: any) {
        if (selectedValue != "") {
            this.layoutComponent.showSpinner(true);
            let filterResult = this.clientStage.filter((clientStage: any) => {
                return (clientStage.Clinic_Stage_ID == selectedValue);
            });
            this.userBusinessService.saveAddUpdatePatientStage(this.assigmentToPatient, filterResult, this.patientDetail.Patient_Id, this.patientDetail.Clinic_ID).subscribe(res=>{
            if(res.Response_Code == 1){
            this.userBusinessService.getStageAssigmentToPatient(this.localPatientId).subscribe(response => {
                this.assigmentToPatient = response;
                this.selectedStage = response.Stage_ID == 0 ? "" : response.Stage_ID;
                this.layoutComponent.showSpinner(false);
                return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                .then(dialog => {
                    this.dialog = dialog;
                })
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getStageAssigmentToPatient ", err);
            })
            }else{
                this.layoutComponent.showSpinner(false);
            }
        },(err)=>{
            this.layoutComponent.showSpinner(false);
            console.log("userBusinessService saveAddUpdatePatientStage ", err);
            });
        }
    }
    onClose() {
        this.dialog.close();
    }
}