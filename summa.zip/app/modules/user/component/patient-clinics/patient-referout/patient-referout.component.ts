import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { UserBusinessService } from '../../../business/user.business'
import { ReferoutInterface } from '../../../entity/referout.interface';
import { Config } from '../../../../../config/constant';
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
    templateUrl: './patient-referout.component.html',
    styleUrls: ['./patient-referout.component.scss']
})
export class PatientReferComponent implements OnInit {
    @ViewChild('sendcopy') public sendcopy: TemplateRef<any>;
    @ViewChild('sendsuccess') public sendsuccess: TemplateRef<any>;
    @ViewChild('referout') public referout: TemplateRef<any>;
    dialog: DialogRef<any>;
    sendSuccess = false;
    referSuccess = false;

    public ValidCurrentUser: string = "";
    public subcription: any;
    public unsubscribe: any;
    public localPatientId: number = 0;
    public patientDetail: any;
    public clinicList: any;
    public referoutData: ReferoutInterface;
    public disableSelect: boolean = true;
    public referedProviderList: any;

    constructor(private layoutComponent: LayoutComponent, private config: Config, private userBusinessService: UserBusinessService, private route: ActivatedRoute, private sharedObserverService: SharedObserverService, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.sendSuccess = false;
        this.referSuccess = false;
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.ValidCurrentUser = localStorage.getItem('currentUser');
            this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
                this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
            if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
            } else {
                Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
            }

            if (!sessionStorage.getItem("clinicIndividualPatient")) {
                this.unsubscribe = this.sharedObserverService.individualPatientReceiver$.subscribe(res => {
                    this.patientDetail = res;
                    sessionStorage.setItem("clinicIndividualPatient", JSON.stringify(res));
                    console.log("clinicIndividualPatient" + sessionStorage.getItem("clinicIndividualPatient"));
                });
            } else {
                this.patientDetail = JSON.parse(sessionStorage.getItem("clinicIndividualPatient"));
            }
            this.referoutData = {
                pR_ID:0,
                patientID: this.localPatientId,
                referredByClinicID: this.ValidCurrentUser == "ClinicsUser" ? Number(localStorage.getItem('mvcUserId')) : Number(localStorage.getItem('clinic-clinic-Id')),
                referredByProviderID: this.ValidCurrentUser == "ClinicsUser" ? -1 : Number(localStorage.getItem('mvcUserId')),
                referredToClinicID: 0,
                referredToProviderID: -1,
                status: "Pending",
                statusUpdatedBy: this.ValidCurrentUser == "ClinicsUser" ? "Clinics" : this.ValidCurrentUser == "DoctorUser" ? "Physician" : this.ValidCurrentUser == "EducatorUser" ? "Educator" : '',
                reason: "",
                referred_Status: "",
                consultationRequired: false
            }

            this.userBusinessService.getListOfClinics().subscribe(res => {
                let filterResult = res.filter((uniqueData: any) => {
				return Number(localStorage.getItem('clinic-clinic-Id')) != uniqueData.Clinic_ID;
				}); 
                this.clinicList = filterResult;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                console.log("userBusinessService getListOfClinics ", err);
                this.layoutComponent.showSpinner(false);
            });
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }
    onBack() {
        if (this.localPatientId == 0) {
            this._location.back();
        } else {
            this.router.navigate(['profile/patient-view/' + this.localPatientId]);
        }
    }

    onSendOutConfirm(referoutData: any) {
         if (referoutData.referredToClinicID == 0 ||  referoutData.reason.trim() == "") {
            return false;
        }
        this.sendSuccess = false;
        this.referSuccess = false;
        return this.modal.open(this.sendcopy, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                    .then(dialog => {
                        this.dialog = dialog;
                    });
    }

    onSendOut(referoutData: any) {
        this.dialog.close();
        this.layoutComponent.showSpinner(true);
        this.referoutData.referred_Status = this.config.send_Out;
        this.userBusinessService.addSendOrReferPatient(referoutData).subscribe(res => {
            if (res.Response_Code == 1) {
                this.sendSuccess = true;
                this.referSuccess = false;
                this.referoutData = {
                    pR_ID:0,
                    patientID: this.localPatientId,
                    referredByClinicID: this.ValidCurrentUser == "ClinicsUser" ? Number(localStorage.getItem('mvcUserId')) : Number(localStorage.getItem('clinic-clinic-Id')),
                    referredByProviderID: this.ValidCurrentUser == "ClinicsUser" ? -1 : Number(localStorage.getItem('mvcUserId')),
                    referredToClinicID: 0,
                    referredToProviderID: -1,
                    status: "Pending",
                    statusUpdatedBy: this.ValidCurrentUser == "ClinicsUser" ? "Clinics" : this.ValidCurrentUser == "DoctorUser" ? "Physician" : this.ValidCurrentUser == "EducatorUser" ? "Educator" : '',
                    reason: "",
                    referred_Status: "",
                    consultationRequired: false
                }
                this.layoutComponent.showSpinner(false);
                return this.modal.open(this.sendcopy, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                    .then(dialog => {
                        this.dialog = dialog;
                    })
            }
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.log("userBusinessService addSendOrReferPatient", err);
        })
    }

     onReferOutConfirm(referoutData: any) {
        if (referoutData.referredToClinicID == 0 ||  referoutData.reason.trim() == "") {
            return false;
        }
        this.sendSuccess = false;
        this.referSuccess = false;
        return this.modal.open(this.referout, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                    .then(dialog => {
                        this.dialog = dialog;
                    });
    }
    

    onReferOut(referoutData: any) {
        this.dialog.close();
        this.layoutComponent.showSpinner(true);
        this.referoutData.referred_Status = this.config.refer_Out;
        this.userBusinessService.addSendOrReferPatient(referoutData).subscribe(res => {
            if (res.Response_Code == 1) {
                this.sendSuccess = false;
                this.referSuccess = true;
                this.referoutData = {
                    pR_ID: 0,
                    patientID: this.localPatientId,
                    referredByClinicID: this.ValidCurrentUser == "ClinicsUser" ? Number(localStorage.getItem('mvcUserId')) : Number(localStorage.getItem('clinic-clinic-Id')),
                    referredByProviderID: this.ValidCurrentUser == "ClinicsUser" ? -1 : Number(localStorage.getItem('mvcUserId')),
                    referredToClinicID: 0,
                    referredToProviderID: -1,
                    status: "Pending",
                    statusUpdatedBy: this.ValidCurrentUser == "ClinicsUser" ? "Clinics" : this.ValidCurrentUser == "DoctorUser" ? "Physician" : this.ValidCurrentUser == "EducatorUser" ? "Educator" : '',
                    reason: "",
                    referred_Status: "",
                    consultationRequired: false
                }
                this.layoutComponent.showSpinner(false);
                return this.modal.open(this.referout, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                    .then(dialog => {
                        this.dialog = dialog;
                    })
            }
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.log("userBusinessService addSendOrReferPatient", err);
        })
    }
    onClose() {
        this.dialog.close();
    }
    

    selectedClintId(selectedClintId: any) {
        this.layoutComponent.showSpinner(true);
        console.log(selectedClintId);
        if (selectedClintId != 0) {
            this.userBusinessService.getProviderByClinicId(Number(selectedClintId)).subscribe(res => {
                this.referedProviderList = res;
                this.disableSelect = false
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getProviderByClinicId", err);
            })
        } else {
            this.referoutData.referredToProviderID = -1;
            this.disableSelect = true;
            this.layoutComponent.showSpinner(false);
        }
    }
}