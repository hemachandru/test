import { Component, OnInit, Inject, TemplateRef, Input, Output, EventEmitter, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { PatientData } from './entity/patient-list.entity';

@Component({
    selector: 'patient-list',
    templateUrl: './patient-list.component.html',
    styleUrls: ['./patient-list.component.scss']
})
export class PatientListComponent implements OnInit {
    @Output() onButtonClk = new EventEmitter<any>();
    @Input() patientdata: PatientData[];
    constructor() { }
    ngOnInit() { }
    onViewPatient(patientData:any,event: any) {
        let evt={
            patientData:patientData,
            event: event
        }
        this.onButtonClk.emit(evt);
    }
}