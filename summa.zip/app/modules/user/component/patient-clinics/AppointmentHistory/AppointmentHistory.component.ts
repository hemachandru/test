
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { Config } from "../../../../../config/constant";
import { UserBusinessService } from '../../../business/user.business'
import { LayoutComponent } from "../../../../layout/component/layout.component";
import{ClinicBusiness}from '../../../../clinic/business/clinic.business';
import {AppointmentList} from  './../../../entity/AppointmentList';

@Component({
    templateUrl: './AppointmentHistory.component.html',
    styleUrls: ['./AppointmentHistory.component.scss']
})

export class AppointmentHistoryComponent implements OnInit {
 @ViewChild('joinnowref') public joinnowref: TemplateRef<any>;
 @ViewChild('cancelref') public cancelref: TemplateRef<any>;
 dialog: DialogRef<any>;

 constructor (private _cb: ClinicBusiness, public modal: Modal,private route: ActivatedRoute, private userBusinessService:UserBusinessService,private router: Router){};
 public appointmentList : AppointmentList[];
 public upappointmentList : AppointmentList[];
 public subcription: any;
 public localPatientId: number = 0;

ngOnInit() {
     //'Patients', Number(localStorage.getItem('mvcUserId')), Number(localStorage.getItem("clinic-clinic-Id")),'1'
         this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
               // this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
           // if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
           // } else {
          //      Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
         //   }





    }

    onHistory(){
        localStorage.removeItem("HistoryAppointment"); 
        localStorage.setItem("HistoryAppointment","1");
        this.userBusinessService.GetUpcomingOrPreviousAppointments().subscribe(res=>{
                this.appointmentList = res;    
                });

    }

    onUpcoming(){
        localStorage.removeItem("HistoryAppointment");
         localStorage.setItem("HistoryAppointment","0");
         this.userBusinessService.GetUpcomingOrPreviousAppointments().subscribe(res=>{
         this.appointmentList = res;    
                });
    }

 
    onEditorReschedule() {
        
        this.router.navigate(['/clinics/schedule']);
    }
    onJoinNow() {
        return this.modal.open(this.joinnowref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    onClose() {
        this.dialog.close();
    }
    onCancel() {
         return this.modal.open(this.cancelref, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-joinnow' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            }) 
    }
    onCancelClose() {
        this.dialog.close();
    }
    onBack() {
        //this._location.back();
        this.router.navigate(['./profile/patient-view']);
    }
}
