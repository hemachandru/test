import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ClientBusiness } from '../../../../client/business/client.business'
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { Config } from "../../../../../config/constant";
import { UserBusinessService } from '../../../business/user.business'
import { LayoutComponent } from "../../../../layout/component/layout.component";
//import {ViewScheduleAppoinment} from "../../../../../../../../clinic/schedule-clinic/view-all/view-all.component";

@Component({
    templateUrl: './patient-view.component.html',
    styleUrls: ['./patient-view.component.scss']
})
export class PatientViewComponent implements OnInit {

    public localPatientId: number = 0;
    public individualPatientDetail: any;
    public patientDetail: any;
    public unsubscribe: any;
    public emptyData: string = this.config.emptyDate;
    public specialNotes: string = "";
    public subcription: any;
    public ValidCurrentUser: string;
    public assigmentToPatient: any;
    public clientStage: any;
    public patientphase: any;
    constructor(private layoutComponent: LayoutComponent, private route: ActivatedRoute, private userBusinessService: UserBusinessService, private config: Config, private sharedObserverService: SharedObserverService, private router: Router, private clientBusiness: ClientBusiness) { }

    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.ValidCurrentUser = localStorage.getItem('currentUser');
            this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
                this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
            if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
                localStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
            } else {
                Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
            }

            if (!sessionStorage.getItem("clinicIndividualPatient")) {
                this.unsubscribe = this.sharedObserverService.individualPatientReceiver$.subscribe(res => {
                    this.patientDetail = res;
                    sessionStorage.setItem("clinicIndividualPatient", JSON.stringify(res));
                    console.log("clinicIndividualPatient" + sessionStorage.getItem("clinicIndividualPatient"));
                });
            } else {
                this.patientDetail = JSON.parse(sessionStorage.getItem("clinicIndividualPatient"));
            }
            this.clientBusiness.getPatientsDetailByPatientId(this.localPatientId).subscribe(res => {
                this.individualPatientDetail = res;
                this.specialNotes = res.patient_info.SpecialNotes;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                console.log("layoutComponent getPatientsDetailByPatientId", err);
                this.layoutComponent.showSpinner(false);
            });
            this.userBusinessService.getStageAssigmentToPatient(this.localPatientId).subscribe(response => {
                //this.assigmentToPatient = response;
                this.patientphase = response.Stage_ID == 0 ? "" : response.Stage_TXT;
                console.log("this.assigmentToPatient" + this.patientphase);
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getStageAssigmentToPatient ", err);
            });
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }
    onEdit() {
        this.router.navigate(["/profile/editpersonalinformation/"+this.localPatientId]);
    }

    saveSpecialNotes(specialNotesText: string) {
        if (specialNotesText.trim() != "") {
             this.layoutComponent.showSpinner(true);
            this.userBusinessService.saveSpecialNotes(this.localPatientId, specialNotesText).subscribe(res => {
                this.specialNotes = "";
                 this.layoutComponent.showSpinner(false);
            }, (err) => {
                 this.layoutComponent.showSpinner(false);
                console.log("userBusinessService saveSpecialNotes", err);
            });
        } else {
            this.specialNotes = "";
        }
        this.clientBusiness.getPatientsDetailByPatientId(this.localPatientId).subscribe(res => {
                this.individualPatientDetail = res;
                this.specialNotes = res.patient_info.SpecialNotes;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                console.log("layoutComponent getPatientsDetailByPatientId", err);
                this.layoutComponent.showSpinner(false);
            });
    }

    ngOnDestroy() {
        sessionStorage.clear();
        this.unsubscribe ? this.unsubscribe.unsubscribe : '';
    }

    onUpdateClinics() {

    }
}