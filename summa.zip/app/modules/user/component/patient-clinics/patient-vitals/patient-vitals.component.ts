import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent, ActivatedRoute } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Location } from '@angular/common';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { Config } from "../../../../../config/constant";
import { UserBusinessService } from '../../../business/user.business'
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { PatientVitalsInterface } from '../../../entity/patient.vitals.interface';
@Component({
    templateUrl: './patient-vitals.component.html',
    styleUrls: ['./patient-vitals.component.scss']
})
export class PatientVitalsComponent implements OnInit {
    public opts: ISlimScrollOptions;

    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    public ValidCurrentUser: string = "";
    public subcription: any;
    public unsubscribe: any;
    public localPatientId: number = 0;
    public patientDetail: any;
    public patientVitalsHistory: any;
    public patientVitalsHistoryDataFlag: boolean = false;
    public noData: string = this.config.noData;
    public patientVitalsInterface: PatientVitalsInterface;

    constructor(private sharedObserverService: SharedObserverService, private layoutComponent: LayoutComponent, private config: Config, private userBusinessService: UserBusinessService, private route: ActivatedRoute, private _location: Location, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.ValidCurrentUser = localStorage.getItem('currentUser');
            this.subcription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
                this.localPatientId == 0 ? this.router.navigate(['/profile/patient-clinics']) : "";
            });
            if (!sessionStorage.getItem("clinicIndividualPatientId")) {
                sessionStorage.setItem("clinicIndividualPatientId", String(this.localPatientId));
            } else {
                Number(sessionStorage.getItem("clinicIndividualPatientId")) != this.localPatientId ? this.router.navigate(['/profile/patient-clinics']) : "";
            }

            if (!sessionStorage.getItem("clinicIndividualPatient")) {
                this.unsubscribe = this.sharedObserverService.individualPatientReceiver$.subscribe(res => {
                    this.patientDetail = res;
                    sessionStorage.setItem("clinicIndividualPatient", JSON.stringify(res));
                    console.log("clinicIndividualPatient" + sessionStorage.getItem("clinicIndividualPatient"));
                });
            } else {
                this.patientDetail = JSON.parse(sessionStorage.getItem("clinicIndividualPatient"));
            }
            this.patientVitalsInterface = {
                id: 0,
                patient_ID: this.localPatientId,
                bPsys: 0,
                bPDia: 0,
                heartRate: 0,
                respRate: 0,
                temperature: 0,
                o2Saturation: 0,
                created_Date: ''
            }
            this.userBusinessService.getPatientVitalsByPatientId(this.localPatientId).subscribe(res => {
                this.patientVitalsHistory = res
                res.length == 0 ? this.patientVitalsHistoryDataFlag = true : this.patientVitalsHistoryDataFlag = false;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getPatientVitalsByPatientId", err);
            });

        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }
    _keyPress(event: any) {
        const pattern = /[0-9]/;
        let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
    onAddVitals(patientVitalsData: any) {
        this.layoutComponent.showSpinner(true);
        if (patientVitalsData.bPsys == 0 || patientVitalsData.bPDia == 0 || patientVitalsData.heartRate == 0 || patientVitalsData.respRate == 0 || patientVitalsData.temperature == 0 || patientVitalsData.o2Saturation == 0) {
          this.layoutComponent.showSpinner(false);
           return false;
        }
        this.userBusinessService.addPatientVitals(patientVitalsData).subscribe(res => {

            if (res.Response_Code == 1) {
                this.patientVitalsInterface = {
                id: 0,
                patient_ID: this.localPatientId,
                bPsys: 0,
                bPDia: 0,
                heartRate: 0,
                respRate: 0,
                temperature: 0,
                o2Saturation: 0,
                created_Date: ''
            }
             this.userBusinessService.getPatientVitalsByPatientId(this.localPatientId).subscribe(res => {
                this.patientVitalsHistory = res
                res.length == 0 ? this.patientVitalsHistoryDataFlag = true : this.patientVitalsHistoryDataFlag = false;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("userBusinessService getPatientVitalsByPatientId", err);
            })

            this.layoutComponent.showSpinner(false);
                return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
                    .then(dialog => {
                        this.dialog = dialog;
                    })
            }
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.log("userBusinessService addPatientVitals", err);
        });
    }
    onBack() {
        if (this.localPatientId == 0) {
            this._location.back();
        } else {
            this.router.navigate(['profile/patient-view/' + this.localPatientId]);
        }
    }
    onClose() {
        this.dialog.close();
    }
}