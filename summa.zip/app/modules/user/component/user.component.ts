import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  templateUrl: './user.component.html'
})
export class UserComponent implements OnInit {
  constructor() { }
  ngOnInit() { }
}