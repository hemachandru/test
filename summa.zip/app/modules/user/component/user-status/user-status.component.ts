import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, ElementRef, Renderer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../shared/shared-loader/shared-loader.service';
import { SharedObserverService } from '../../../../shared/shared-service-module/shared-observer.service';
import { Config } from "../../../../config/constant";
import { ClinicService } from "../../../clinic/service/clinic.service";
import { ClinicBusiness } from "../../../clinic/business/clinic.business";
@Component({
    selector: 'user-status',
    templateUrl: './user-status.component.html',
    styleUrls: ['./user-status.component.scss']

})

export class UserStatusComponent {
    view1: boolean;
    view2: boolean;
    view3: boolean;
    view4: boolean;

    public opts: ISlimScrollOptions;

    private appointmentList: any = [];
    constructor(private config: Config, private completerService: CompleterService, private router: Router, private renderer: Renderer, private _cb: ClinicBusiness, private _cs: ClinicService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _ls: LoaderService, private _sos: SharedObserverService) {
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.appointmentList = [];
    }
    ngOnInit() {
        this.view1 = true;
        this.onAppointmentRequest();
    }
    onAppointmentRequest() {
        this._ls.display(true);
        this._cb.getApptRequests().subscribe(res => {
            this._ls.display(false);
            this.appointmentList = res;
            if (res.length == 0) {
                return false;
            }
            this.appointmentList = [];
            for (var index = 0; index < res.length; index++) {
                this.appointmentList.push({
                    id: res[index].Consultation_Request_Id,
                    f_name: res[index].Provider_First_Name,
                    l_name: res[index].Provider_Last_Name,
                    dateandtime: res[index].Consultation_Request_Date
                })
            }
        })
    }
    onUpdateReq() {
        this.onAppointmentRequest();
    }
    status1() {
        this.view1 = true;
        this.view2 = false;
        this.view3 = false;
        this.view4 = false;
    }

    status2() {
        this.view2 = true;
        this.view1 = false;
        this.view3 = false;
        this.view4 = false;
    }
    status3() {
        this.view3 = true;
        this.view1 = false;
        this.view2 = false;
        this.view4 = false;
    }
    status4() {
        this.view4 = true;
        this.view1 = false;
        this.view2 = false;
        this.view3 = false;
    }
}

