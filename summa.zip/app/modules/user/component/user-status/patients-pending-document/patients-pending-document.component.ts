import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { PlatformLocation } from '@angular/common';

@Component({
	selector: 'patients-pending-document',
	templateUrl: './patients-pending-document.component.html',
	styleUrls: ['./patients-pending-document.component.scss']
})

export class PatientsPendingDocument implements OnInit {
	@ViewChild('lpverify') public lpverify: TemplateRef<any>;
	dialog: DialogRef<any>;

	constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private location: PlatformLocation) {
		overlay.defaultViewContainer = vcRef;
	}

	ngOnInit() { }

	btnVerify() {
		return this.modal.open(this.lpverify, overlayConfigFactory({ dialogClass: 'modal-dialog lp-modal-center' }, BSModalContext)).then(dialog => {
			this.dialog = dialog;
		});
	}


	dialogClosed() {
		this.dialog.close();
	}

}
