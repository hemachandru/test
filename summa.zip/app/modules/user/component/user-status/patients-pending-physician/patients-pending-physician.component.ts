import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'patients-pending-physician',
    templateUrl: './patients-pending-physician.component.html',
    styleUrls: ['./patients-pending-physician.component.scss']
})

export class PatientsPendingPhysician implements OnInit {
   constructor(){
	}
  

    ngOnInit() { }
}
