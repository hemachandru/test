import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import { Component, EventEmitter, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, ElementRef, Renderer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { UserService } from "../../../service/user.service";
import { UserBusinessService } from "../../../business/user.business";
import { HttpRequestService } from '../../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../../shared/shared-loader/shared-loader.service';
import { SharedObserverService } from '../../../../../shared/shared-service-module/shared-observer.service';
import { Config } from "../../../../../config/constant";
import { LpListEntity, UpdateLpList } from './entity/lplist-entity';
import { RecordService } from '../../../../record/component/service/record.service';
import { RecordBusiness } from '../../../../record/component/business/record.business';
import { PrintService } from "../../../../../shared/shared-util/shared-print-service";

@Component({
	selector: 'lp-request-list',
	templateUrl: './lp-request-list.component.html',
	styleUrls: ['./lp-request-list.component.scss'],
	providers: [RecordService, RecordBusiness, PrintService]
})

export class AdminLPRequestListComponent implements OnInit {
	@ViewChild('lpverify') public lpverify: TemplateRef<any>;
	@ViewChild('lpdecline') public lpdecline: TemplateRef<any>;
	dialog: DialogRef<any>;
	@Input() lists: LpListEntity[];
	@Output() onCloseClick = new EventEmitter();
	dataLp: UpdateLpList;
	userper: any;
	permissionValue: boolean;
	public medicalDocumentDetail: any;
	isMedicalDoc: boolean = true;

	@ViewChild('viweDocRef') public viweDocRef: TemplateRef<any>;
	constructor(private printService: PrintService, private recordBusiness: RecordBusiness, private config: Config, private completerService: CompleterService, private router: Router, private renderer: Renderer, private _ub: UserBusinessService, private _us: UserService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _ls: LoaderService, private _sos: SharedObserverService) {
		overlay.defaultViewContainer = vcRef;
	}
	ngOnInit() {
		this.userper = localStorage.getItem('premissionData_array');
		if ((this.userper.indexOf(0) != "-1" && this.userper.indexOf(7) != "-1")) {
			this.permissionValue = true;
		} else {
			this.permissionValue = false;
		}
	}
	onAccept(applist: any, event: any) {
		if (applist.Medical_Doc_Status == "LPSVTP      ") {
			var target = event.target || event.srcElement || event.currentTarget;
			var idAttr = target.attributes.id;
			var dataLp = {
				LP_Id: applist.LP_Id,
				Medical_Doc_Id: applist.Medical_Document_Id,
				Doc_Status: idAttr.nodeValue,
				Medical_Doc_Relation_Id: applist.Medical_Doc_Relation_Id,
				Decline_Notes: "",
				Not_Verified_Notes: "",
				Patient_Id: applist.Patient_Id,
				Provider_Id: applist.Provider_Id,
				PatientProductRequests: applist.PatientProductRequests,
				IsPrinted: applist.IsPrinted,
				Provider_LocalIP: "null",
				Provider_ISPIP: "null",
				LP_ComingFrom: "null",
				Provider_Browser: "null",
				Provider_OSVersion: "null",
				Provider_PCAccount: "null"
			}
			this._ub.lpVerifiedorDeclined(dataLp).subscribe(res => {
			})
			return this.modal.open(this.lpverify, overlayConfigFactory({ dialogClass: 'modal-dialog lp-modal-center' }, BSModalContext)).then(dialog => {
				this.dialog = dialog;
			});
		}
		else {
			
		}

	}
	onDecline(applist: any, event: any) {
		if (applist.Medical_Doc_Status == "LPSVTP      ") {
			var target = event.target || event.srcElement || event.currentTarget;
			var idAttr = target.attributes.id;
			var dataLp = {
				LP_Id: applist.LP_Id,
				Medical_Document_Id: applist.Medical_Document_Id,
				Doc_Status: idAttr.nodeValue,
				Medical_Doc_Relation_Id: applist.Medical_Doc_Relation_Id,
				Decline_Notes: "",
				Not_Verified_Notes: "",
				Patient_Id: applist.Patient_Id,
				Provider_Id: applist.Provider_Id,
				PatientProductRequests: applist.PatientProductRequests
			}
			this._ub.lpVerifiedorDeclined(dataLp).subscribe(res => {

			})
			return this.modal.open(this.lpdecline, overlayConfigFactory({ dialogClass: 'modal-dialog lp-modal-center' }, BSModalContext)).then(dialog => {
				this.dialog = dialog;
			});
		}
		else {
			target = "MDC"
			var dataLp = {
				LP_Id: applist.LP_Id,
				Medical_Document_Id: applist.Medical_Document_Id,
				Doc_Status: target,
				Medical_Doc_Relation_Id: applist.Medical_Doc_Relation_Id,
				Decline_Notes: "",
				Not_Verified_Notes: "",
				Patient_Id: applist.Patient_Id,
				Provider_Id: applist.Provider_Id,
				PatientProductRequests: applist.PatientProductRequests,
			}
			this._ub.updateMedicalDoc(dataLp).subscribe(res => {
				console.log("dataLp", dataLp);
			})
			return this.modal.open(this.lpdecline, overlayConfigFactory({ dialogClass: 'modal-dialog lp-modal-center' }, BSModalContext)).then(dialog => {
				this.dialog = dialog;
			});
		}
	}

	dialogClosed(event: any) {
		this.onCloseClick.emit(event);
		this.dialog.close();
	}
	onMedicalDocument(event: Event, isMedDoc: boolean, medicalDocumentId: number) {
		this.recordBusiness.getMedicalDocument(medicalDocumentId).subscribe(response => {
			this.medicalDocumentDetail = response;
			this.onViewDocument(event, isMedDoc);
		}, (err) => {
			console.error("RequestList lpRequestBusiness updateMedicalDocStatus sendForVerification  erro  ", err);
		});
	}
	onViewDocument(event: Event, isMedDoc: boolean) {
		this.isMedicalDoc = isMedDoc ? true : false;

		return this.modal.open(this.viweDocRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
			.then(dialog => {
				this.dialog = dialog;
				//this.close();
			});
	}
	onModelClose(event: any) {
		this.dialog.close();
	}
	printOptionMedicalDoc(event: any) {
		let headerMecialDocument = document.getElementById('headerMecialDocument').innerHTML;
		let diagnosishtml = document.getElementById('diagnosishtml').innerHTML;
		let suggestionshtml = document.getElementById('suggestionshtml').innerHTML;
		let marijuanaValue = (<HTMLInputElement>document.getElementById('marijuanaValue')).value;
		let PeriodValue = (<HTMLInputElement>document.getElementById('PeriodValue')).value;
		let thcValue = (<HTMLInputElement>document.getElementById('thcValue')).value;
		let cbdValue = (<HTMLInputElement>document.getElementById('cbdValue')).value;
		let period_of_Use = (<HTMLInputElement>document.getElementById('Period_of_Use')).innerHTML;


		let innerFullHtml = "<section class='view-doc-wrapper'>" +
			"<header >" +
			headerMecialDocument +
			"</header> <div class='view-area'>" +
			" <p class='modal-cont'>Daily quantity of marijuana to be used by the patient:</p>" +
			"<p><input type='text' value=" + marijuanaValue + " readonly class='txt-box'/><span class='spacing-txtbox'> gram/day</span></p>" +
			"<p class='modal-cont'> The Period of Use Is</p>" +
			"<p><input type='text' value=" + PeriodValue + "  readonly class='txt-box'/> <span class='spacing-txtbox'>" + period_of_Use + "</span></p>" +
			"<p class='modal-cont'> Diagnosis Comments</p><p>" +
			diagnosishtml +
			"</p><p class='modal-cont'> Suggestions Only</p>" +
			"<p><input type='text' readonly value=" + thcValue + " class='txt-box'/> THC (%)</p> " +
			"<p><input type='text'  readonly value=" + cbdValue + " class='txt-box'/> CBD (%)</p>" +
			"<p class='modal-cont'> Notes and/or Restrictions</p>" +
			"<textarea  class='txt-area' rows='3'>" + suggestionshtml + "</textarea></div></section>"

		this.printService.printFile(innerFullHtml, 'medicalDocument');
	}
}
