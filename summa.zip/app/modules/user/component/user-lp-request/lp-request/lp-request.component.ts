import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, Output, ElementRef, Renderer } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { UserService } from "../../../service/user.service";
import { UserBusinessService } from "../../../business/user.business";
import { HttpRequestService } from '../../../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../../../shared/shared-loader/shared-loader.service';
import { SharedObserverService } from '../../../../../shared/shared-service-module/shared-observer.service';
import { Config } from "../../../../../config/constant";

@Component({
    selector: 'lprequest',
    templateUrl: './lp-request.component.html',
    styleUrls: ['./lp-request.component.scss']

})

export class AdminLPRequestComponent implements OnInit {
    public opts: ISlimScrollOptions;
    private lpMedicalDocList: any = [];
    private lpSignedList: any = [];
    public lpCount: any;
    public toBeSignedCount: any;
    public validCurrentUser: any;
    constructor(private config: Config, private completerService: CompleterService, private router: Router, private renderer: Renderer, private _ub: UserBusinessService, private _us: UserService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _ls: LoaderService, private _sos: SharedObserverService) {
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.lpMedicalDocList = [];
    }
    ngOnInit() {
        this.lpMedicalDoc();
        this.lpSigned();
        this.totalCount();
        this.validCurrentUser = localStorage.getItem('currentUser');
    }
    lpMedicalDoc() {
        this._ls.display(true);
        this._ub.getLpMedicalRequests().subscribe(res => {
            this._ls.display(false);
            if (res.length == 0) {
                this.lpMedicalDocList = [];
            }
            else {
                this.lpMedicalDocList = res;
            }
        })
    }
    lpSigned() {
        this._ls.display(true);
        this._ub.getLpSignedRequests().subscribe(res => {
            this._ls.display(false);
            if (res.length == 0) {
                this.lpSignedList = [];
            }
            else {
                this.lpSignedList = res;
            }
        })
    }
    totalCount() {
        this._ub.getLpReqCount().subscribe(res => {
            this.lpCount = res.LPRequests_Count;
            this.toBeSignedCount = res.NewMDs_Count;
        })
    }
    onClose() {
        this.lpMedicalDoc();
        this.lpSigned();
    }
}