import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, ViewContainerRef, ViewChild, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ManageSettingInterfcae } from '../../entity/user.interface';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';
import { Subscription } from 'rxjs/Subscription';
import { Location } from '@angular/common';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { SwiperComponent, SwiperConfigInterface } from 'ngx-swiper-wrapper';

import { UserBusinessService } from "../../business/user.business";
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";
import { ClientBusiness } from '../../../client/business/client.business';

export class Permission {
    "CP_ID": number;
    "Communication_Permission"?: string;
    "Description": string;
    "Permission": boolean;
    "checked": boolean;
    "Role"?: string;
}
const CommunicationPermissions: Permission[] = [
    {
        "CP_ID": 1,
        "Communication_Permission": "APCH",
        "Description": "Appointments Changed",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 2,
        "Communication_Permission": "APCN",
        "Description": "Appointments Canceled",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 3,
        "Communication_Permission": "APCR",
        "Description": "Appointments Booked",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 4,
        "Communication_Permission": "APRM",
        "Description": "Appointment Reminders",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 5,
        "Communication_Permission": "CSRQ",
        "Description": "Consultation Request",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 6,
        "Communication_Permission": "MDAC",
        "Description": "Medical Document Accepted",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 7,
        "Communication_Permission": "MDCR",
        "Description": "Medical Document Created",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 10,
        "Communication_Permission": "PHAS",
        // "Description": "Notification for when a patient is assigned to you.",
        "Description": "Physician Assigned",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 11,
        "Communication_Permission": "PRUP",
        "Description": "Profile Updates",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 12,
        "Communication_Permission": "MDDC",
        "Description": "Medical Document Declined By LP",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 13,
        "Communication_Permission": "MDNV",
        "Description": "Medical Document Not Verified By Physician",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 14,
        "Communication_Permission": "MDVR",
        "Description": "Medical Document Verified By Physician",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    }
]




@Component({
    templateUrl: './edit-personalinfo.component.html',
    styleUrls: ["./edit-personalinfo.component.scss"]
})
export class EditPersonalInfoComponent implements OnInit, OnDestroy {
    private mySwiper: SwiperComponent;
    public localPatientId: number = 0;
    private dialog: DialogRef<any>;
    private content: string;
    public user: any;
    public opts: ISlimScrollOptions;
    public idate: any;
    private deepCopyObj: {};
    public date = new Date();
    public mask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

    private tempData: any;
    private patientDetail: any;
    private permissionList: Permission[];
    private tempPermissionList: Permission[];
    private selectedItems: Permission[] = [];
    public index: SwiperComponent;
    public config: SwiperConfigInterface = {
        scrollbar: null,
        observer: true,
        nextButton: '.myswiper-button-next',
        prevButton: '.myswiper-button-prev',
        breakpoints: {
            // when window width is <= 320px
            320: {
                slidesPerView: 1,
                spaceBetween: 10
            },
            // when window width is <= 480px
            480: {
                slidesPerView: 1,
                spaceBetween: 20
            }
        }
    };

    private myDatePickerNormalOptions: IMyOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'mo',
        height: '25px',
        width: '203px',
        selectionTxtFontSize: '12px',
        indicateInvalidDate: true,
        editableMonthAndYear: true,
        minYear: 1900,
        maxYear: this.date.getUTCFullYear(),
        disableSince: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() + 1 },
        componentDisabled: false,
        showClearDateBtn: false,
        showSelectorArrow: true,
        showInputField: true,
        openSelectorOnInputClick: true,
        inline: false,
        alignSelectorRight: true,
        editableDateField: false,
        disableHeaderButtons: true,
        inputAutoFill: false,
        showWeekNumbers: false
    };
    private userDetail: any;
    private provinceList: Array<any> = [];
    private subscription: Subscription;
    private masterObserver: Subscription;

    public medicalConditions: any;
    public existingMedicalCodition: boolean = false;
    public previousCondition: string = '';
    public previousConditionDesc: string = '';
    private tempMedicalConditions: any = [];
    public previousConditionChecked: boolean = false;








    @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;
    constructor(private router: Router, private route: ActivatedRoute, private _ubs: UserBusinessService, private _location: Location, private _ls: LoaderService, private _sos: SharedObserverService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private _cb: ClientBusiness) { 
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.resetValue();
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        
        this.subscription = this.route.params.subscribe(params => {
                this.localPatientId = +params['id']; // (+) converts string 'id' to a number
            });
        
        let result: any = [];
        this.permissionList = CommunicationPermissions;
        this.tempPermissionList = CommunicationPermissions;
        
        this.subscription = this._ubs.profileDetails$.subscribe(userData => {
            if (userData == true) {
                this._ls.display(true);
                
            this._cb.getPatientsDetailByPatientId(this.localPatientId).subscribe(res => {
                    this._ls.display(false);
                    this.fillValue(res.patient_info);
                    this.fillMedConditions(res.patient_info);
                    this.patientDetail = res.patient_info;
                    result = this.patientDetail.Communication_Permissions.map((x: any) => Object.assign({}, x));
                    this.tempData = this.sortArray(result);
                    this.composeObject(result);
              });

                return false;
            }
            this.fillValue(userData);
        });

        this.masterObserver = this._sos.eventReceiver$.subscribe(res => {
            if (res != true) {
                this.provinceList = res.Provinces;
                this.medicalConditions = res.MedicalConditions;
                if (this.medicalConditions) {
                    for (var index = 0; index < this.medicalConditions.length; index++) {
                    this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
                    }
                }
            }
        })
    }
    fillValue(res: any) {
        res.Address_List_object = this.generateAddress(res.Address_List);
        let date = new Date(res.DOB);
        let dateObj = {
            date: {
                year: date.getFullYear(),
                month: date.getMonth() + 1,
                day: date.getDate()
            }
        }
        this.user = {
            Patient_ID: res.Patient_ID,
            Patient_User_Name: res.Patient_User_Name,
            First_Name: res.First_Name,
            Last_Name: res.Last_Name,
            Email_Address: res.Email_Address,
            DOB: res.DOB,
            DateOfBirth: dateObj,
            Phone: res.Phone,
            Height: res.Height,
            Weight: res.Weight,
            Gender: res.Gender,
            R_Address_Id: res.Address_List_object.R_Address_Id,
            R_User_Address: res.Address_List_object.R_User_Address,
            R_City: res.Address_List_object.R_City,
            R_Home_Phone: res.Address_List_object.R_Home_Phone,
            R_Province: res.Address_List_object.R_Province,
            R_Cell_Phone: res.Address_List_object.R_Cell_Phone,
            R_Postal_Code: res.Address_List_object.R_Postal_Code,
            R_Work_Phone: res.Address_List_object.R_Work_Phone,
            S_Address_Id: res.Address_List_object.S_Address_Id,
            S_User_Address: res.Address_List_object.S_User_Address,
            S_City: res.Address_List_object.S_City,
            S_Home_Phone: res.Address_List_object.S_Home_Phone,
            S_Province: res.Address_List_object.S_Province,
            S_Cell_Phone: res.Address_List_object.S_Cell_Phone,
            S_Postal_Code: res.Address_List_object.S_Postal_Code,
            S_Work_Phone: res.Address_List_object.S_Work_Phone,
            Address_List: '',
            Profile_Status: res.Profile_Status,
            HIN: res.HIN,
            NewsLetterSubscription: res.NewsLetterSubscription,
            ReferredBy: res.ReferredBy,
            ReferredByOtherDesc: res.ReferredByOtherDesc,
            ClinicalPatientID: res.ClinicalPatientID,
            LPRegNo: res.LPRegNo,
            Communication_Permissions: '',
            MedicalConditions:'',
            existingOrPreviousCondition: [],
            previousCondition: '',
            previousConditionDesc: ''
        };

        this.deepCopyObj = Object.assign({}, this.user);
    }

  fillMedConditions(res: any) {

    let medicalData = res.MedicalConditions;
    let jsonMedicalData = [];
    this.tempMedicalConditions = [];
    jsonMedicalData = medicalData != "" ? medicalData.split(",") : "";

    if (this.medicalConditions) {
      if (jsonMedicalData == "") {
        for (var index = 0; index < this.medicalConditions.length; index++) {
          this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
        }
      } else {

        for (var index = 0; index < this.medicalConditions.length; index++) {
          if (jsonMedicalData.indexOf(this.medicalConditions[index].Title) != -1) {
            this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": true });
            this.tempMedicalConditions[index].Checked = true;
            this.user.existingOrPreviousCondition[index] = this.medicalConditions[index].Title;
          } else {
            this.tempMedicalConditions.push({ "Id": this.medicalConditions[index].Id, "Title": this.medicalConditions[index].Title, "Checked": false });
            this.tempMedicalConditions[index].Checked = false;
          }
        }

      }

    }

  }

    onDateChanged(event: IMyDateModel) {
        this.user.DOB = new Date(event.jsdate).toLocaleDateString();
    }

    sameAddress(event: any) {        
        if(event.target.checked) {
            this.user.S_User_Address = this.user.R_User_Address;
            this.user.S_City = this.user.R_City;
            this.user.S_Home_Phone = this.user.R_Home_Phone;
            this.user.S_Province = this.user.R_Province;
            this.user.S_Cell_Phone = this.user.R_Cell_Phone;
            this.user.S_Postal_Code = this.user.R_Postal_Code;
            this.user.S_Work_Phone = this.user.R_Work_Phone;
        } else {
            this.user.S_User_Address = '';
            this.user.S_City = '';
            this.user.S_Home_Phone = '';
            this.user.S_Province = '';
            this.user.S_Cell_Phone = '';
            this.user.S_Postal_Code = '';
            this.user.S_Work_Phone = '';
        }
    }
    generateAddress(value: any) {
        let resultArr: any = {};
        if (value.length > 0) {
            for (var index = 0; index < value.length; index++) {
                if (value[index].Address_Type == "Residence") {
                    resultArr.R_Address_Id = value[index].Address_Id;
                    resultArr.R_User_Address = value[index].User_Address;
                    resultArr.R_City = value[index].City;
                    resultArr.R_Home_Phone = value[index].Home_Phone;
                    resultArr.R_Province = value[index].Province;
                    resultArr.R_Cell_Phone = value[index].Cell_Phone;
                    resultArr.R_Postal_Code = value[index].Postal_Code;
                    resultArr.R_Work_Phone = value[index].Work_Phone;
                } else if (value[index].Address_Type == "Shipping") {
                    resultArr.S_Address_Id = value[index].Address_Id;
                    resultArr.S_User_Address = value[index].User_Address;
                    resultArr.S_City = value[index].City;
                    resultArr.S_Home_Phone = value[index].Home_Phone;
                    resultArr.S_Province = value[index].Province;
                    resultArr.S_Cell_Phone = value[index].Cell_Phone;
                    resultArr.S_Postal_Code = value[index].Postal_Code;
                    resultArr.S_Work_Phone = value[index].Work_Phone;
                }
            }
        }
        console.log(resultArr);
        return resultArr;
    }
    resetValue() {
        this.user = {
            Patient_ID: '',
            Patient_User_Name: '',
            First_Name: '',
            Last_Name: '',
            Email_Address: '',
            DOB: '',
            DateOfBirth: '',
            Phone: '',
            Height: '',
            Weight: '',
            Gender: '',
            R_User_Address: '',
            R_City: '',
            R_Home_Phone: '',
            R_Province: '',
            R_Cell_Phone: '',
            R_Postal_Code: '',
            R_Work_Phone: '',
            S_User_Address: '',
            S_City: '',
            S_Home_Phone: '',
            S_Province: '',
            S_Cell_Phone: '',
            S_Postal_Code: '',
            S_Work_Phone: '',
            Address_List: '',
            Profile_Status: '',
            HIN: '',
            NewsLetterSubscription: '',
            ReferredBy: '',
            ReferredByOtherDesc: '',
            ClinicalPatientID: '',
            LPRegNo: '',
            Communication_Permissions: '',
            MedicalConditions:'',
            existingOrPreviousCondition: [],
            previousCondition: '',
            previousConditionDesc: ''            
        };
    }
    save(value: any) {
        this._ls.display(true);
        let Address_List = [
            {
                Address_Id: value.R_Address_Id || undefined,
                Address_Type: "Residence",
                User_Address: value.R_User_Address || undefined,
                City: value.R_City || undefined,
                Home_Phone: value.R_Home_Phone || undefined,
                Province: value.R_Province || undefined,
                Cell_Phone: value.R_Cell_Phone || undefined,
                Postal_Code: value.R_Postal_Code || undefined,
                Work_Phone: value.R_Work_Phone || undefined,
            },
            {
                Address_Id: value.S_Address_Id || undefined,
                Address_Type: "Shipping",
                User_Address: value.S_User_Address || undefined,
                City: value.S_City || undefined,
                Home_Phone: value.S_Home_Phone || undefined,
                Province: value.S_Province || undefined,
                Cell_Phone: value.S_Cell_Phone || undefined,
                Postal_Code: value.S_Postal_Code || undefined,
                Work_Phone: value.S_Work_Phone || undefined,
            },
        ];
        let arrObj = JSON.parse(JSON.stringify(Address_List));
        value.Address_List = arrObj.filter((value: any) => Object.keys(value).length !== 1);

        var bPerms: boolean = true;
        this.user.Communication_Permissions = {
            PermissionsList: []
        };

        let arrPLObj = this.permissionList.filter((value: any, index: number, self: any) => {
            return value.Permission != this.tempData[index].Permission;
        });

        for (var index = 0; index < arrPLObj.length; index++) {
            this.user.Communication_Permissions.PermissionsList.push({
                "CP_Code": arrPLObj[index].CP_ID,
                "Permission": arrPLObj[index].Permission,
                "Processed": false
            })
        }
        if(this.user.Communication_Permissions.PermissionsList.length == 0 ) {
            bPerms=false;    
        }

        (this.user.previousCondition == "true" && this.user.previousConditionDesc != "") ? this.user.existingOrPreviousCondition.push(this.user.previousConditionDesc.length > 75 ? this.user.previousConditionDesc.substring(0, 75) : this.user.previousConditionDesc) : "";
        
        let filterExistingOrPreviousConditionResult = this.user.existingOrPreviousCondition.filter((responseData: any) => {
        return responseData != "";
        });
        
        this.user.MedicalConditions = filterExistingOrPreviousConditionResult ? filterExistingOrPreviousConditionResult.toString() : '';

        this._ubs.createOrUpdateProfile(value, bPerms).subscribe(res => {
            this._ls.display(false);
            if (res.Response_Code == 1) {
                this.showAlertMsg(res.Response_Msg);
            } else {
                this.showAlertMsg(res.Response_Msg);
            }
        })
    }

    onBack() {
        this._location.back();
    }
    close() {
        this.dialog.close();
    }
    showAlertMsg(value: string) {
        this.content = value;
        this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    onIndexChange(evt: Event) {
     
        console.log(evt);

    }



    composeObject(result: any) {
        result = this.sortArray(result);

        for (let index = 0; index < result.length; index++) {
            this.permissionList[index].Permission = result[index].Permission;
            this.permissionList[index].checked = result[index].Permission;
        }
    }


    onSelectionChange(data: Permission, index: number) {
        if (data.Permission) {
            this.permissionList[index].Permission = false;
            this.permissionList[index].checked = false;
        } else {
            this.permissionList[index].Permission = true;
            this.permissionList[index].checked = true;
        }
    }

    sortArray(value: any): any {
        return value.sort((a: any, b: any) => {
            return parseFloat(a.CP_Code) - parseFloat(b.CP_Code);
        });
    }


    ngOnDestroy() {
        this.subscription.unsubscribe();
        this.masterObserver.unsubscribe();
    }

  checkOnckeckConditon(checkOrUncheck: number, medicationCondition: string) {

    if (!this.tempMedicalConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.user.existingOrPreviousCondition[checkOrUncheck] = medicationCondition;
      this.tempMedicalConditions[checkOrUncheck].Checked = true;
    } else if (this.tempMedicalConditions[checkOrUncheck].Checked && medicationCondition != 'other') {
      this.user.existingOrPreviousCondition[checkOrUncheck] = "";
      this.tempMedicalConditions[checkOrUncheck].Checked = false;
    } else {
      this.previousConditionChecked ? this.previousConditionChecked = false : this.previousConditionChecked = true;
      !this.previousConditionChecked ? this.user.previousCondition = "" : "";
      !this.previousConditionChecked ? this.user.previousConditionDesc = "" : "";
    }
  }
    
}