import { Observable } from 'rxjs/Observable';
import { Component, OnInit,Input, Output ,EventEmitter} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { AddAppointmentReasonComponent } from './AddAppointmentReason/Add-AppointmentReason.component';
import { AppointmentReason } from './entity/AppointmentReason.entity';
import { UserBusinessService } from '../../../business/user.business';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { ISlimScrollOptions } from 'ng2-slimscroll';
//import { SelectedAppointmentReason } from './entity/AppointmentReason.entity';

@Component({
    templateUrl: './set-appointment.component.html',
    styleUrls: ["./set-appointment.component.scss"]
})


export class SetAppointmentComponent implements OnInit {
   
  
    //public searchlabels = searchdata;
   // @Output() onButtonClk = new EventEmitter<any>();
    public AppointmentReason: AppointmentReason[];
    public onButtonClick = new EventEmitter <any>();
    public options: ISlimScrollOptions;
    public flag:boolean;
    private _value : string;
    SelectedAppointmentReason :AppointmentReason[];
    public get value() : string {
        return this._value;
    }
    public set value(v : string) {
        this._value = v;
    }
    
    constructor(private layoutComponent:LayoutComponent,private router: Router, private _location: Location ,private userBusinessService:UserBusinessService, private completerService: CompleterService) { 
         /* this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0'
                                    }; */
    }
    ngOnInit() {
        this.layoutComponent.showSpinner(true);
         this.options = {
                    position: 'left',
                    barBackground: '#4f4f4f',
                    gridBackground: '#b6b6b6',
                    barBorderRadius: '0',
                    barWidth: '4',
                    gridWidth: '4',
                    gridMargin: '1px 0',
                    
                                    }; 


        
        this.userBusinessService.getAllClinicAppointmentReasons().subscribe(res=>{
            this.AppointmentReason=res;
        });
        this.layoutComponent.showSpinner(false);
       
       
    }
    
    onViewApptReason(CAR_ID:number) {
        this.AppointmentReason.forEach(ApptRe => {
           if (ApptRe.CAR_ID == CAR_ID){
        sessionStorage.setItem("SelectedApptReason", JSON.stringify(ApptRe));
        }
     });
       this.layoutComponent.showSpinner(true);
        
        this.router.navigate(['/profile/Add-AppointmentReason']);
    }


    onBack() {
        this._location.back();
    }

     onAddApptReason() {
       this.layoutComponent.showSpinner(true);
       sessionStorage.removeItem("SelectedApptReason");
       this.router.navigate(['/profile/Add-AppointmentReason']);
    }
    
   

}