import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
/* import { AppointmentReason } from './setappointment/entity/AppointmentReason.entity';
import {UserBusinessService } from '../../business/user.business'; */


@Component({
    templateUrl: './clinics-admin.component.html',
    styleUrls: ["./clinics-admin.component.scss"]
})
export class ClinicsAdminComponent implements OnInit {
    public ValidCurrentUser: string;
    /* public AppointmentReason: AppointmentReason[]; */
    constructor(private router: Router /* ,private userBusinessService:UserBusinessService, */) { }
    ngOnInit() {
        var currentUser = localStorage.getItem('currentUser');
        this.ValidCurrentUser = currentUser;
    }
    onUpdateClinics() {
        this.router.navigate(['/clinics/admin/edit-clinic/0']);
    }
    onSetAppointment() {
        this.router.navigate(['/profile/set-appointment']);
    }
    onReports() {
        this.router.navigate(['/Adminreport']);
    }
    onUserPermissions() {
        this.router.navigate(['/clinics/admin/permission']);
    }
    onPhases() {
        this.router.navigate(['/clinics/admin/phases']);
    }
    onReferredByOptions() {
        this.router.navigate(['/clinics/admin/referred-by-options']);
    }
}