import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, ViewContainerRef, ViewChild, TemplateRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Config } from '../../../../config/constant';
import { UserBusinessService } from "../../business/user.business";
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { ISlimScrollOptions } from 'ng2-slimscroll';

export class Permission {
    "CP_ID": number;
    "Communication_Permission"?: string;
    "Description": string;
    "Permission": boolean;
    "checked": boolean;
    "Role"?: string;
}
const CommunicationPermissions: Permission[] = [
    {
        "CP_ID": 1,
        "Communication_Permission": "APCH",
        "Description": "Appointments Changed",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 2,
        "Communication_Permission": "APCN",
        "Description": "Appointments Canceled",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 3,
        "Communication_Permission": "APCR",
        "Description": "Appointments Booked",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 4,
        "Communication_Permission": "APRM",
        "Description": "Appointment Reminders",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 5,
        "Communication_Permission": "CSRQ",
        "Description": "Consultation Request",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 11,
        "Communication_Permission": "PRUP",
        "Description": "Profile Updates",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 10,
        "Communication_Permission": "PHAS",
        // "Description": "Notification for when a patient is assigned to you.",
        "Description": "Physician Assigned",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 6,
        "Communication_Permission": "MDAC",
        "Description": "Medical Document Accepted",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 7,
        "Communication_Permission": "MDCR",
        "Description": "Medical Document Created",
        "Permission": false,
        "checked": false,
        "Role": "All"
    },
    {
        "CP_ID": 12,
        "Communication_Permission": "MDDC",
        "Description": "Medical Document Declined By LP",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 13,
        "Communication_Permission": "MDNV",
        "Description": "Medical Document Not Verified By Physician",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    },
    {
        "CP_ID": 14,
        "Communication_Permission": "MDVR",
        "Description": "Medical Document Verified By Physician",
        "Permission": false,
        "checked": false,
        "Role": "Patients"
    }
]

@Component({
    templateUrl: './edit-notification.component.html',
    styleUrls: ["./edit-notification.component.scss"]
})
export class EmailNotificationComponent implements OnInit, OnDestroy {
    private dialog: DialogRef<any>;
    private permissionList: Permission[];
    private tempPermissionList: Permission[];
    private selectedItems: Permission[] = [];
    private userDetail: any;
    private tempData: any;
    private content: string;
    private contentData: string;
    private notificationDisableFlag: boolean = true;
    public opts: ISlimScrollOptions;
    //entries: any ;
    private subscription: Subscription;
    @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;

    @ViewChild('noChangesNotification') public noChangesNotificationRef: TemplateRef<any>;

    constructor(private config: Config, private router: Router, private _ubs: UserBusinessService, private _ls: LoaderService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {

        this.notificationDisableFlag = false;

        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.permissionList = CommunicationPermissions;
        this.tempPermissionList = CommunicationPermissions;

        this.subscription = this._ubs.profileDetails$.subscribe((userData: any) => {
            let result: any = [];
            if (userData == true) {
                this._ls.display(true);
                this._ubs.getUserInfo().subscribe(data => {
                    this._ls.display(false);
                    this.userDetail = data.Patient_Login_Data;
                    result = this.userDetail.Communication_Permissions.map((x: any) => Object.assign({}, x));
                    this.tempData = this.sortArray(result);
                    this.composeObject(result);
                });
                return false;
            }
            this.userDetail = userData;
            this.tempData = userData.Communication_Permissions.map((x: any) => Object.assign({}, x));
            this.tempData = this.sortArray(this.tempData);
            result = userData.Communication_Permissions;
            this.composeObject(result);
        });
    }
    composeObject(result: any) {
        result = this.sortArray(result);

        for (let index = 0; index < result.length; index++) {
            this.permissionList[index].Permission = result[index].Permission;
            this.permissionList[index].checked = result[index].Permission;
        }
    }
    save(list: Permission[]) {
        this.userDetail.Communication_Permissions = {
            PermissionsList: []
        };

        let arrObj = list.filter((value: any, index: number, self: any) => {
            return value.Permission != this.tempData[index].Permission;
        });

        for (var index = 0; index < arrObj.length; index++) {
            this.userDetail.Communication_Permissions.PermissionsList.push({
                "CP_Code": arrObj[index].CP_ID,
                "Permission": arrObj[index].Permission,
                "Processed": false
            })
        }
        if (this.userDetail.Communication_Permissions.PermissionsList.length == 0) {
            this.noChangesNotificationModel();
            return;
        }

        this._ls.display(true);
        this._ubs.createOrUpdateProfile(this.userDetail, true).subscribe(res => {
            let msg = res.Response_Msg;
            if (res.Response_Code == 1) {
                let data = {
                    user_name: this.userDetail.Patient_User_Name,
                    user_role: localStorage.getItem('userRole')
                }
                this._ubs.getUserUpdateLoginResponse(data).subscribe(res => {
                    this._ls.display(false);
                    this.userDetail = res.Patient_Login_Data;
                    let result = res.Patient_Login_Data.Communication_Permissions.map((x: any) => Object.assign({}, x));
                    this.tempData = this.sortArray(result);
                    this.composeObject(res.Patient_Login_Data.Communication_Permissions);
                    this.showAlertMsg(msg);
                })
            } else {
                this.showAlertMsg(res.Response_Msg);
            }
        })
    }

    onSelectionChange(data: Permission, index: number, list: any) {
        this.notificationDisableFlag = true;
        if (data.Permission) {
            this.permissionList[index].Permission = false;
            this.permissionList[index].checked = false;
             this.notificationDisableFlag = false;
        } else {
            this.permissionList[index].Permission = true;
            this.permissionList[index].checked = true;
             this.notificationDisableFlag = true;
        }
    }

    showAlertMsg(value: string) {
        this.content = value;
        this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }


    noChangesNotificationModel() {
        this.contentData = this.config.noChangesMadeUpateNotification;
        this.modal.open(this.noChangesNotificationRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    close() {
        this.dialog.close();
    }

    sortArray(value: any): any {
        return value.sort((a: any, b: any) => {
            return parseFloat(a.CP_Code) - parseFloat(b.CP_Code);
        });
    }

    closeProfile() {
        this.dialog.close();
        this.router.navigate(['profile']);
    }

    ngOnDestroy() {
        // prevent memory leak when component destroyed
        this.subscription.unsubscribe();
    }

}