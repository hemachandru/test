import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy, ViewChild, TemplateRef, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ManageSettingInterfcae } from '../../entity/user.interface';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

import { UserBusinessService } from '../../business/user.business';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";

@Component({
  selector: "emailSetting",
  styleUrls: ["./emailSetting.component.scss"],
  templateUrl: './emailSetting.component.html'
})
export class emailSetting implements OnInit, OnDestroy {
  public ManageSetting: ManageSettingInterfcae;
  public invalidEmail: any;
  public invalidPassword: any;
  public invalidDob: any;
  public invalidConfirmPassword: any;
  public idate: any;
  public date = new Date();
  public val: boolean;
  private isEdited: boolean = true;
  private content: string;
  private isSuccess: boolean = false;
  private isFail: boolean = false;
  private isAddressAvail: boolean = false;
  private userDetail: any;
  entries: any ;
  private subscription: Subscription;

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  @ViewChild('editprofiletemplate') public editprofiletemplate: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private _ubs: UserBusinessService, private _sos: SharedObserverService, private _ls: LoaderService) {
    overlay.defaultViewContainer = vcRef;

    this.entries = {
        NewsLetterSubscription: true,
        value: 1
      }
    this.userDetail = {};
  }

  ngOnInit() { 
    this.subscription = this._ubs.profileDetails$.subscribe((userData: any) => {
        if (userData == true) {
          this._ls.display(true);
          this._ubs.getUserInfo().subscribe(data => {
            this._ls.display(false);
            this.userDetail = data.Patient_Login_Data;
            this.isAddressAvail = data.Patient_Login_Data.Address_List.length > 0 ? true : false;
          });
          return false;
        }
        this.userDetail = userData;
        this.isAddressAvail = userData.Address_List.length > 0 ? true : false;
    });
  }
  changePassword() {
    this.router.navigate(['/profile/ChangePassword']);

  }
  editProfileInfo() {
    this.router.navigate(['/profile/ChangePassword']);
  }


  profileBack() {
    this.router.navigate(['profile']);
  }
  dialogClosed() {
    this.dialog.close();
  }
  editEmail() {
    this.isEdited = !this.isEdited;
  }
  onSelectionChange(checked: boolean) {
    this.userDetail.NewsLetterSubscription = checked;
  }
  onSave(data: any) {
    this._ls.display(true);
    this._ubs.createOrUpdateProfile(data, false).subscribe(res => {
      this._ls.display(false);
      this.isSuccess = false;
      this.isFail = false;
      if (res.Response_Code == 1) {
        this.isSuccess = true;
        this.content = res.Response_Msg;
      } else {
        this.isFail = true;
        this.content = res.Response_Msg;
      }
    })
  }
  ngOnDestroy() {
      // prevent memory leak when component destroyed
      this.subscription.unsubscribe();
  }
}