export interface DocumentTypeEntity {
    id: number;
    name: string;
    value: string;
    activeLabel: boolean;
}

export interface DocumentListEntity {
    id: number;
    f_name: string;
    f_date: string;
    author: string;
    bucket_name: string;
    bucket_type: string;
    file_type: string;
    doc_title: string;
    isDeletable: boolean;
}