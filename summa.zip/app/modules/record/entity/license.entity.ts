export interface LicenseRequestClient {
    client_name: string;
    client_req_date: string;
    client_id: number;
    client_med_doc?: string;
    client_reg_doc?: string;
    client_prod_list?: {
        prod_id: number;
        product_name: string;
        product_quantity: string;
    }
}