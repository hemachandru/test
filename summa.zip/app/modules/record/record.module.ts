import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlimScrollModule } from 'ng2-slimscroll';
import { FormsModule } from '@angular/forms';
import { NgPipesModule } from 'ng-pipes';

import { RecordComponent } from './component/record.component';
import { CannabisComponent } from './component/cannabis/cannabis.component';
import { RecordRoutingModule } from './record.routing';

import { DocumentTypeLabel } from './component/documenttype/document-type.component';
import { DocumentListComponent } from './component/documentlist/document-list.component';
import { LPRequestComponent } from "./component/licenserequest/lp-request.component";
import { RequestList } from "./component/licenselist/lp-request-list.component";

import { AlertButtonComponent } from "./component/licensealert/lp-alertmodal.component";
import { Ng2CompleterModule } from "ng2-completer";
import { MedicalDocumentComponent } from "../record/component/shared/medical-document/medical-document.component";
import { UploadContentComponent } from './component/upload-content/uploadcontent.component';
import { UploadLpComponent } from './component/upload-content/upload-lp/uploadlp.component';
import { UpdateProductComponent } from './component/upload-content/update-product/updateproduct.component';
import { SharedModule } from "../../shared/sharedmodule/shared.module";
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { Config } from '../../config/constant';
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { RecordBusiness } from './component/business/record.business';
import { RecordService } from './component/service/record.service';
import { LayoutBusiness } from '../layout/business/layout.business';
import { LayoutService } from '../layout/service/layout.service';
import { cannabisslider } from './component/cannabis/cannabisslider.service';
import { PrintService } from "../../shared/shared-util/shared-print-service";
import { ChangePasswordComponent } from './component/upload-content/changepassword/changepassword.component';
import { UserBusinessService } from '../user/business/user.business';
import { UserService } from '../user/service/user.service';
import { MedicalComponentModel } from '../../../app/modules/record/component/shared/medical-componentmodel';
//import {  } from '../component/shared/medical-document/medical-document.component';

@NgModule({
  imports: [
    FormsModule,
    RecordRoutingModule,
    SlimScrollModule,
    CommonModule,
    SharedModule,
    NgPipesModule,
    PipeModule,
    Ng2CompleterModule,
    MedicalComponentModel
  ],
  declarations: [
    RecordComponent,
    CannabisComponent,
    DocumentTypeLabel,
    DocumentListComponent,
    LPRequestComponent,
    AlertButtonComponent,
    RequestList,
    UploadContentComponent,
    UploadLpComponent,
    UpdateProductComponent,
    ChangePasswordComponent
  ],
  providers: [UserBusinessService, UserService, PrintService, HttpRequestService, Config, RecordBusiness, RecordService, LayoutBusiness, LayoutService, cannabisslider]
})
export class RecordModule { }