import { Observable } from 'rxjs/Observable';
import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, OnDestroy, Input, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Config } from '../../../config/constant';
import { DocumentTypeEntity, DocumentListEntity } from '../entity/document.entity';
import { SharedObserverService } from "../../../shared/shared-service-module/shared-observer.service";
import { RecordBusiness } from "./business/record.business";
import { LayoutComponent } from "../../layout/component/layout.component";
import { NgForm } from '@angular/forms';

@Component({
  templateUrl: './record.component.html',
  styleUrls: ['./record.component.scss']
})
export class RecordComponent implements OnInit {

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;
  public opts: ISlimScrollOptions;
  public docLabel: DocumentTypeEntity[] = [];
  public docList: DocumentListEntity[] = [];
  public document: any;
  private isEmptyList: boolean = true;
  private uploadFile: FileList;
  public maxFileUploadSize: any;
  public maxFileUploadText: any = this.config.maxDocumentUploadSize;
  public formatNotSupported: any = this.config.formatNotSupported;
  public formatNotSupport: any;
  files: FileList;
  private uploadSucessBool: boolean = false;
  private uploadFailedBool: boolean = false;
  private uploadSucessText: string = this.config.uploadSucess;
  private uploadFailedText: string = this.config.uploadUnSucess;
  private noData = this.config.noData;
  private getBucketName: string = '';
  private maxCharacter20: string = this.config.maxCharacter20;
  public maxStrainNameStyle: any;
  constructor(private layoutComponent: LayoutComponent, private config: Config, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _sos: SharedObserverService, private _rb: RecordBusiness) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    this.layoutComponent.showSpinner(true);
    this.documentEntityRefresh();
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
    RecordComponent.prototype.maxStrainNameStyle = 'none';
    RecordComponent.prototype.maxFileUploadSize = 'none';
    RecordComponent.prototype.formatNotSupport = 'none';
    this._sos.eventReceiver$.subscribe(res => {
      if (res && res.SharepointBuckets) {
        let activeLab = false;
        for (var index = 0; index < res.SharepointBuckets.length; index++) {
          if (this.getBucketName == res.SharepointBuckets[index].Value) {
            activeLab = true;
          } else {
            activeLab = false;
          }
          this.docLabel.push({
            id: res.SharepointBuckets[index].Id,
            name: res.SharepointBuckets[index].Text,
            value: res.SharepointBuckets[index].Value,
            activeLabel: activeLab
          });
        }
      }
    }, (err) => {
      this.layoutComponent.showSpinner(false);
    });
    if (sessionStorage.getItem("getBucketName")) {
      this.getBucketName = sessionStorage.getItem("getBucketName");
      this.getDocumentListByBucketName(sessionStorage.getItem("getBucketName"));
    } else {
      this.getBucketName = '';
      this.getDocumentList();
    }
  }

  onClick(event: Event) {
    this.uploadSucessBool = false;
    this.uploadFailedBool = false;
    RecordComponent.prototype.maxFileUploadSize = 'none';
    RecordComponent.prototype.formatNotSupport = 'none';
    return this.modal.open(this.templateRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-upload-task' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      });

  }

  close() {
    this.dialog.close();
  }

  onChange(fileInput: any) {
    this.uploadSucessBool = false;
    this.uploadFailedBool = false;
    RecordComponent.prototype.maxFileUploadSize = 'none';
    RecordComponent.prototype.formatNotSupport = 'none';
    this.layoutComponent.showSpinner(true);
    if (fileInput.target.files && fileInput.target.files[0]) {
      RecordComponent.prototype.maxFileUploadSize = 'none';
      RecordComponent.prototype.formatNotSupport = 'none';
      let checkFileSizeStatus = this.checkFileSize(fileInput.target.files[0].size);
      let checkFileFormatStatus = this.checkFileFormat(fileInput.target.files[0].type, fileInput.target.files[0].name);

      if (!checkFileSizeStatus || !checkFileFormatStatus) {
        this.layoutComponent.showSpinner(false);
        return false;
      }
      this.files = fileInput.target.files;
      var filename = fileInput.target.files[0].name
      filename = filename.substring(0, filename.lastIndexOf('.'));
      this.document.fileName = filename;

      var reader = new FileReader();
      reader.onload = this._handleReaderLoaded.bind(this);
      reader.readAsArrayBuffer(this.files[0]);
      this.layoutComponent.showSpinner(false);
    }
    else {
      RecordComponent.prototype.maxFileUploadSize = 'none';
      RecordComponent.prototype.formatNotSupport = 'none';
      this.documentEntityRefresh();
      this.layoutComponent.showSpinner(false);
    }
  }

  _handleReaderLoaded(readerEvt: any) {
    this.document.filebinary = readerEvt.target.result;
  }

  onUpdateDocument(event: DocumentTypeEntity) {
    sessionStorage.setItem("getBucketName", event.value);
    this.getDocumentListByBucketName(event.value);
  }

  getDocumentList() {
    this._rb.getAllDocuments().subscribe(res => {
      if (res.length == 0) {
        this.docList = [];
        this.isEmptyList = true;
        this.layoutComponent.showSpinner(false);
        return false;
      }
      this.isEmptyList = false;
      this.createDocumentData(res);
      this.layoutComponent.showSpinner(false);
    }, (err) => {
      console.log("record component getDocumentLsitByBucketName", err);
      this.layoutComponent.showSpinner(false);
    });
  }

  createDocumentData(res: any) {
    this.docList = [];
    for (var index = 0; index < res.length; index++) {
      this.docList.push({
        id: res[index].Doc_Hash_ID,
        f_name: res[index].Doc_Name,
        f_date: res[index].Uploaded_On,
        author: res[index].Uploaded_By,
        bucket_name: res[index].Doc_Bucket,
        bucket_type: res[index].Doc_Type,
        file_type: res[index].File_Type,
        doc_title: res[index].Title,
        isDeletable: true
      })
    }
  }

  getDocumentListByBucketName(buckName: string) {
    this.layoutComponent.showSpinner(true);
    this._rb.getDocumentsByBucketName(buckName).subscribe(res => {
      if (res.length == 0) {
        this.docList = [];
        this.isEmptyList = true;
        this.layoutComponent.showSpinner(false);
        return false;
      }
      this.isEmptyList = false;
      this.createDocumentData(res);
      this.layoutComponent.showSpinner(false);
    }, (err) => {
      console.log("record component getDocumentLsitByBucketName", err);
      this.layoutComponent.showSpinner(false);
    });
  }

  onDeleteDoument(event: any) {
    event.dialog.close();
    this.layoutComponent.showSpinner(true);
    this._rb.removeDocument(event.data).subscribe(res => {
      if (sessionStorage.getItem("getBucketName")) {
        this.getBucketName = sessionStorage.getItem("getBucketName");
        this.getDocumentListByBucketName(sessionStorage.getItem("getBucketName"));
      } else {
        this.getBucketName = '';
        this.getDocumentList();
      }
    });
  }

  onClosePopup(event: any) {
    event.close();
  }

  onUploadDocument(value: any, formData: NgForm) {
    if (value.title.length > 20) {
      RecordComponent.prototype.maxStrainNameStyle = 'block';
      return false;
    }
    RecordComponent.prototype.maxStrainNameStyle = 'none';
    if (RecordComponent.prototype.maxFileUploadSize == 'none' && RecordComponent.prototype.formatNotSupport == 'none' && RecordComponent.prototype.maxStrainNameStyle == 'none') {
      this.layoutComponent.showSpinner(true);
      this._rb.uploadDocument(value).subscribe(res => {
        if (Number(res) == Number(1)) {
          this.uploadSucessBool = true;
          if (sessionStorage.getItem("getBucketName")) {
            if (value.type == sessionStorage.getItem("getBucketName")) {
              this.getBucketName = sessionStorage.getItem("getBucketName");
              formData.resetForm();
              this.getDocumentListByBucketName(sessionStorage.getItem("getBucketName"));
            } else {
              formData.resetForm();
              this.layoutComponent.showSpinner(false);
            }
          } else {
            formData.resetForm();
            this.getBucketName = '';
            this.getDocumentList();
          }
        } else {
          this.uploadFailedBool = true;
          this.layoutComponent.showSpinner(false);
        }
      }, (err) => {
        this.layoutComponent.showSpinner(false);
      });
    }
  }

  clearFile() {
    RecordComponent.prototype.maxFileUploadSize = 'none';
    RecordComponent.prototype.formatNotSupport = 'none';
    this.dialog.close();
    this.files = null;
    this.documentEntityRefresh();
  }

  checkFileSize(bytes: any) {
    if (bytes == 0) {
      RecordComponent.prototype.maxFileUploadSize = 'block';
      return false;
    } else {
      var sizeInMB = (bytes / (1024 * 1024)).toFixed(3);
      if (Number(sizeInMB) <= 20) {
        RecordComponent.prototype.maxFileUploadSize = 'none';
        return true;
      } else {
        RecordComponent.prototype.maxFileUploadSize = 'block';
        return false;
      }
    }
  }

  checkFileFormat(fileType: string, fileName: string) {

    let fileTypes = fileName.substr(fileName.lastIndexOf('.') + 1);
    if (this.config.uploadDocFormats.indexOf(fileTypes) != -1) {
      this.document.fileType = fileTypes;
      RecordComponent.prototype.formatNotSupport = 'none';
      return true;
    }
    RecordComponent.prototype.formatNotSupport = 'block';
    return false;
  }

  documentEntityRefresh() {
    this.uploadSucessBool = false;
    this.uploadFailedBool = false;
    this.document = {
      file: '',
      type: '',
      title: '',
      fileType: '',
      notes: '',
      filebinary: '',
      fileName: ''
    };
  }

  emptyTextFunction(nameValue: string) {
    if (nameValue.trim().length == 0) {
      this.document.title = ""
    }
  }
  ngOnDestroy() {
    sessionStorage.removeItem("getBucketName");
  }
}