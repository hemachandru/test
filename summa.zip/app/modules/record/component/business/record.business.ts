import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Config } from '../../../../config/constant';
import { RecordService } from '../service/record.service';

@Injectable()
export class RecordBusiness {
  constructor(private recordService: RecordService, private config: Config) { }

  //service get the new requested client medical documents details.
  getAllMedicalDocument() {
    var url = this.config.getAllDocumentUrl + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/0/' + this.config.documentStatus;
    return this.recordService.getAllMedicalDocument(url).map(response => response.json());
  }

  //service to send verification request to physician or decline  request.
  updateMedicalDocStatus(patientDetail: any, docStatus: string) {
    var reqParam = {
      "LP_Id": patientDetail.LP_Id,
      "Medical_Doc_Id": patientDetail.Medical_Document_Id,
      "Doc_Status": docStatus,
      "Medical_Doc_Relation_Id": patientDetail.Medical_Doc_Relation_Id,
      "Decline_Notes": '',
      "Not_Verified_Notes": '',
      "Patient_Id": patientDetail.Patient_Id,
      "Provider_Id": patientDetail.Provider_Id,
      "PatientProductRequests": '',
      "IsPrinted": patientDetail.IsPrinted,
      "Provider_LocalIP": '',
      "Provider_ISPIP": '',
      "LP_ComingFrom": '',
      "Provider_Browser": '',
      "Provider_OSVersion": '',
      "Provider_PCAccount": ''
    }
    return this.recordService.updateMedicalDocStatus(this.config.updateMedicalDocStatus, JSON.stringify(reqParam)).map(response => response.json());
  }

  //service get the single medical document detail
  getMedicalDocument(medicalDocId: number) {
    var url = this.config.getMedicalDocument + medicalDocId;
    return this.recordService.getMedicalDocument(url).map(response => response.json());
  }

  //service get the StrainList depend on LpUser
  getStrainsList(isAutoSuggest: boolean) {

    var reqParam = {
      "Search_Code": 1,
      "LP_Id": Number(localStorage.getItem('mvcUserId')),
      "Product_Name": '',
      "FromTHC": 0,
      "ToTHC": 0,
      "FromCBD": 0,
      "ToCBD": 0,
      "Profile": '',
      "Product_Type": '',
      "ParentClinicID": 0,
      "IsAutoSuggest": false
    }
    return this.recordService.getStrainsList(JSON.stringify(reqParam), this.config.getProductList).map(response => response.json());
  }


  //service add or update Lpuser order palce detail
  orderProduct(productOrderDetail: any, selectedStrainDetail: any, patientDetail: any, medicalDocId: number, profileType: string, productType: string) {

    var reqParam = {
      "Added_Date": productOrderDetail.orderDate.date.day + '/' + productOrderDetail.orderDate.date.month + '/' + productOrderDetail.orderDate.date.year,
      "CBD": selectedStrainDetail[0].CBD,
      "LP_First_Name": localStorage.getItem('lpFirstName'),
      "LP_Id": selectedStrainDetail[0].LP_Id,
      "LP_Last_Name": localStorage.getItem('lpLastName'),
      "LP_Store_Name": selectedStrainDetail[0].Store_Name,
      "Medical_Doc_Id": medicalDocId,
      "Modified_Date": '',
      "New_Order": true,
      "Patient_First_Name": patientDetail.patient_info.First_Name,
      "Patient_Id": patientDetail.patient_info.Patient_ID,
      "Patient_Last_Name": patientDetail.patient_info.Last_Name,
      "Quantity": productOrderDetail.quality,
      "Strain": selectedStrainDetail[0].Product_Name,
      "THC": selectedStrainDetail[0].THC,
      "Type": productType,
      "Product_ID": productOrderDetail.product_Id,
      "Profile": profileType
    }
    return this.recordService.orderProduct(JSON.stringify(reqParam), this.config.addOrModifiyOrder).map(response => response.json());
  }

  //this service Update LpUser Details
  updateLpDetail(updateLpData: any, userDetail: any) {

    var imageUrl = updateLpData.imageBase64Url ? updateLpData.imageBase64Url : userDetail.LP_Login_Data.Image_Url ? userDetail.LP_Login_Data.Image_Url : ''
    var reqParam = {
      "LP_Id": userDetail.LP_Login_Data.LP_Id,
      "LP_First_Name": updateLpData.firstname,
      "LP_Last_Name": updateLpData.lastname,
      "LP_User_Name": userDetail.LP_Login_Data.LP_User_Name ? userDetail.LP_Login_Data.LP_User_Name : '',
      "Store_Name": userDetail.LP_Login_Data.Store_Name ? userDetail.LP_Login_Data.Store_Name : '',
      "Business_Registration_No": userDetail.LP_Login_Data.Business_Registration_No ? userDetail.LP_Login_Data.Business_Registration_No : '',
      "Image_Url": imageUrl,
      "Profile_Status": userDetail.LP_Login_Data.Profile_Status ? userDetail.LP_Login_Data.Profile_Status : '',
      "Email": updateLpData.email,
      "About_Us": updateLpData.desc,
      "address": {
        "Address_Id": userDetail.address ? (userDetail.address.Address_Id ? userDetail.address.Address_Id : '') : 0,
        "User_Address": updateLpData.street,
        "City": updateLpData.city,
        "Postal_Code": userDetail.address ? (userDetail.address.Postal_Code ? userDetail.address.Postal_Code : '') : '',
        "Province": userDetail.address ? (userDetail.address.Province ? userDetail.address.Province : '') : '',
        "Country": userDetail.address ? (userDetail.address.Country ? userDetail.address.Country : '') : '',
        "Work_Phone": userDetail.address ? (userDetail.address.Work_Phone ? userDetail.address.Work_Phone : '') : '',
        "Home_Phone": updateLpData.phone,
        "Cell_Phone": userDetail.address ? (userDetail.address.Cell_Phone ? userDetail.address.Cell_Phone : '') : '',
        "Fax": userDetail.address ? (userDetail.address.Fax ? userDetail.address.Fax : '') : '',
        "Address_Type": userDetail.address ? (userDetail.address.Address_Type ? userDetail.address.Address_Type : '') : '',
        "Longitude": userDetail.address ? (userDetail.address.Longitude ? userDetail.address.Longitude : '') : '',
        "Latitude": userDetail.address ? (userDetail.address.Latitude ? userDetail.address.Latitude : '') : ''
      }
    }

    return this.recordService.updateLpDetail(JSON.stringify(reqParam), this.config.updateLpData).map(response => response.json());
  }

  //service to update or add UserAddress Detail
  addOrModifyUserAddress(userDetail: any, updateLpData: any, requestCode: number) {
    var currentUser = localStorage.getItem('currentUser');
    var userDetailData = [];
    if (currentUser == "LpUser") {
      userDetailData = userDetail.LP_Login_Data;
    }
    var reqParam = {
      "Request_Code": requestCode,
      "UserName": userDetailData.LP_User_Name,
      "UserRole": userDetail.User_Role,
      "address": {
        "Address_Id": userDetailData.address ? userDetailData.address.Address_Id : 0,
        "Address_Type": "Work",
        "Cell_Phone": "",
        "City": updateLpData.city,
        "Country": "",
        "Fax": "",
        "Home_Phone": updateLpData.phone,
        "Latitude": '',
        "Longitude": '',
        "Postal_Code": '',
        "Province": "",
        "User_Address": updateLpData.street,
        "Work_Phone": ""
      }
    }
    return this.recordService.addOrModifyUserAddress(JSON.stringify(reqParam), this.config.addorUpdateUserAddressUrl).map(response => response.json());

  }


  //service to get the Lp ProductList
  getProductList() {
    let reqParam = {
      "Search_Code": 1,
      "LP_Id": Number(localStorage.getItem('mvcUserId')),
      "Product_Name": '',
      "FromTHC": 0,
      "ToTHC": 0,
      "FromCBD": 0,
      "ToCBD": 0,
      "Profile": '',
      "Product_Type": '',
      "ParentClinicID": 0,
      "IsAutoSuggest": false
    };
    return this.recordService.getProductList(JSON.stringify(reqParam), this.config.productListUrl).map(response => response.json());
  }

  //service getting the setting detail for LpProduct add or update
  getSettingDetail() {
    return this.recordService.getSettingDetail(this.config.settingUrl).map(response => response.json());
  }


  //service to add Or Update the Lp ProductList
  addOrUpdateLpProductDetail(addProduct: any, newProductOrNot: boolean) {
    if (addProduct.imageUrl.indexOf(',') != -1) {
      var segments = addProduct.imageUrl.split(',');
      addProduct.imageUrl = segments[1];
      console.log("segments ", segments);
    }
    let reqParam = {
      "New_Product": newProductOrNot,
      "product": {
        "Product_Id": addProduct.productId ? addProduct.productId : 0,
        "Product_Name": addProduct.name,
        "Profile": addProduct.profileType,
        "Product_Desc": addProduct.desc,
        "Product_Type": addProduct.productType,
        "LP_Id": localStorage.getItem('mvcUserId'),
        "Store_Name": localStorage.getItem('lpStoreName'),
        "Price": 0,
        "Price_Type": addProduct.profileType == "1" ? "Milligram" : addProduct.profileType == "2" ? "Milliliter" : addProduct.profileType == "3" ? "Count" : addProduct.profileType == "4" ? "Gram" : '',
        "THC": addProduct.thc,
        "CBD": addProduct.cbd,
        "Product_In_Stock": addProduct.productStatusType == "1" ? true : false,
        "Product_Img_Url": addProduct.imageUrl,
        "Recorded_Date": "",
        "Discount_Offer": ""
      }
    };
    return this.recordService.addOrUpdateLpProductDetail(JSON.stringify(reqParam), this.config.add_UpdateLpProductUrl).map(response => response.json());
  }

  //service get the new requested client medical documents details latest three.
  getAllMedicalDocumentByRange() {
    let url = this.config.getAllDocumentUrl + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/0/' + this.config.documentStatusFWTLP;
    return this.recordService.getAllMedicalDocumentByRange(url).map(response => response.json());
  }

  // get client update details 
  getClientUpdateDetail() {
    let url = this.config.getClientUpdates + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole');
    return this.recordService.getClientUpdateDetail(url).map(response => response.json());
  }

  getAllDocuments() {
    //TODO need to change the value
    let url = this.config.getALlDocument + '/' + 1 + '/' + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('login_Username') ;
    return this.recordService.getAllDocuments(url).map(res => res.json());
  }

  uploadDocument(data: any) {
    //TODO need to change the value
    let queryStr = '?&user_name=' + localStorage.getItem('login_Username') + '&MVC_User_ID=' + localStorage.getItem('mvcUserId') + '&Request_Code=' + 1 + '&Doc_Type=' + data.type + '&Doc_Name=' + data.fileName + '&File_Type=' + data.fileType + '&Doc_Bucket=' + data.type + '&Uploaded_By=' + localStorage.getItem('login_Username') + '&Title=' + data.title + '&Description=' + data.notes;
    let url = this.config.uploadDocument + queryStr;
    return this.recordService.uploadDocument(url, data.filebinary).map(res => res.json());
  }

  removeDocument(data: any) {
    let url = this.config.deleteDocument + '/' + 1 + '/' + data.id + '/' + data.file_type + '/' + data.author + '/' + data.bucket_name;
    return this.recordService.getAllDocuments(url).map(res => res.json());
  }

  downloadDocument(data: any) {
    let url = this.config.downloadDocument + '/' + 1 + '/' + data.id + '/' + data.file_type + '/' + data.author;
    return this.recordService.downloadDocument(url).map(res => res);
  }
  //service get the current cannabislog by patient id
  getCurrentCannabisLogByPatientId() {

    return this.recordService.getCurrentCannabisLogByPatientId(this.config.currentCannabisLog + localStorage.getItem('mvcUserId')).map(response => response.json());
  }

  //service fetch all the cannabislog By patientId
  getAllCannabisLogByPatientId() {
    return this.recordService.getAllCannabisLogByPatientId(this.config.getAllCannabisLog + localStorage.getItem('mvcUserId') + '/0').map(response => response.json());
  }

  //service fetch 5top ratedstrain.
  get5TopRatedStrainByPatientId_Condition(medicalCondition: string) {
    let reqParam = {
      "Patient_ID": Number(localStorage.getItem('mvcUserId')),
      "Medical_Conditions": medicalCondition ? medicalCondition : '',
      "LP_ID": 0
    }
    return this.recordService.get5TopRatedStrainByPatientId_Condition(JSON.stringify(reqParam), this.config.getTopRatedStrain).map(response => response.json());
  }

  //service get the ProductList based on patientid
  getProductBasedOnPatientId(reviewCode: number) {
    return this.recordService.getProductBasedOnPatientId(this.config.getProductsUsedByPatient + localStorage.getItem('mvcUserId') + '/' + reviewCode + '/0').map(response => response.json());
  }

  addOrUpdateCannabiesLog(logData: any) {
    let reqParam = {
      "Log_ID": logData.logId,
      "Patient_ID": logData.patient_ID ? logData.patient_ID : '',
      "Product_ID": logData.product_ID ? logData.product_ID : '',
      "Conditions": logData.conditions ? logData.conditions : '',
      "Intake": logData.intake ? logData.intake : '',
      "Positive_Effects": logData.positive_Effects ? logData.positive_Effects : '',
      "Positive_Comments": logData.positive_Comments ? logData.positive_Comments : '',
      "Negative_Effects": logData.negative_Effects ? logData.negative_Effects : '',
      "Negative_Comments": logData.negative_Comments ? logData.negative_Comments : '',
      "Effectiveness": 0,
      "Side_Effects": 0
    }
    return this.recordService.addOrUpdateCannabiesLog(JSON.stringify(reqParam), this.config.addOrUpdateCannabisLog).map(res => res.json());
  }

  /**
   * Get the upload DocumentList Depend on the login patient and bucketname
   * @param bucket_name 
   */
  getDocumentsByBucketName(bucket_name: string) {
    let url = this.config.getALlDocument + '/' + 1 + '/' + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('login_Username') + '/' + bucket_name;
    return this.recordService.getAllDocuments(url).map(res => res.json());
  }
}

