import { Component, Input, OnInit, Output, EventEmitter, ElementRef } from '@angular/core';

import { DocumentTypeEntity } from '../../entity/document.entity';

@Component({
    selector: "doc-label",
    template: `
        <ul>
            <li *ngFor="let item of items" [class.active]="item.activeLabel" (click)="onLabelClick($event, item)">
                {{item.name}}
            </li>
        </ul>
    `,
    styles: [`
        ul li {
            display: inline-block;
            background-color: #4899cd;
            min-width: 50px;
            color: #fff;
            border-radius: .5em;
            padding-top: 0.4em;
            padding-right: 1.6em;
            padding-bottom: 0.4em;
            padding-left: 1.6em;
            font-size: 11px;
            font-weight: 700;
            margin-bottom: 7px;
            margin-left: 7px;
            letter-spacing: 0.05em;
            cursor: pointer;
        }
        ul .active {
            background-color: #27ab6f;
        }
    `]
})

export class DocumentTypeLabel implements OnInit {
    @Input() items: DocumentTypeEntity[];

    @Output() onLabelBtnClick = new EventEmitter();

    constructor() { }
    ngOnInit() { }
    
    /**
     * Method to filter the document files
     *  
     * @param ele the element which is clicked
     */
    onLabelClick(ele: any, item: DocumentTypeEntity) {
        this.onLabelBtnClick.emit(item);
        let parentEle = ele.target.parentNode;
        let childEle = parentEle.children;
        for(let i=0; i<childEle.length; i++) {
            this.removeClass(childEle[i], 'active');
        }
        this.addClass(ele.target, 'active');
    }

    /**
     * Check whether target element has specified class or not
     * 
     * @param el Taget element to check class is available or not
     * @param className Name of the class to be matched
     */
    hasClass(el: any, className: string) {
        if (el.classList)
            return el.classList.contains(className)
        else
            return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'))
    }

    /**
     * Add class to target element
     * 
     * @param el Taget element to check class is available or not
     * @param className Name of the class to add
     */
    addClass(el: any, className: string) {
        if (el.classList)
            el.classList.add(className)
        else if (!this.hasClass(el, className)) el.className += " " + className
    }

    /**
     * Remove class from the target element
     * 
     * @param el Taget element to check class is available or not
     * @param className Name of the class to remove
     */
    removeClass(el: any, className: string) {
        if (el.classList)
            el.classList.remove(className)
        else if (this.hasClass(el, className)) {
            var reg = new RegExp('(\\s|^)' + className + '(\\s|$)')
            el.className = el.className.replace(reg, ' ')
        }
    }
}