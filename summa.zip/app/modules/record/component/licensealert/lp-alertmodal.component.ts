import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, ElementRef, EventEmitter } from "@angular/core";
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'alert-button',
    templateUrl: './lp-alertmodal.component.html',
    styles: [`
        .alert-wrapper {
            padding: 40px 20px;
            text-align: center;
        }
        .alert-wrapper p {
            margin-bottom: 20px;
            color: #999;
        }
        .alert-wrapper button {
            font-size: 11px;
            padding-top: 3px;
            padding-bottom: 3px;
            padding-left: 15px;
            padding-right: 15px;
        }
    `]
})

export class AlertButtonComponent implements OnInit {
    dialog: DialogRef<any>;

    @Input() className: string;
    @Input() value: string;
    @Input() content: string;

    @Output() btnClicked = new EventEmitter();

    @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;

    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
       
     }

    onClick(event: Event) {
        this.btnClicked.emit(event);
        this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    close() {
        this.dialog.close();
    }
}