import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';


@Injectable()
export class RecordService {

    constructor(private httpRequestService : HttpRequestService){
    }
     
    //service return the new requested client medical documents details.
    getAllMedicalDocument(url:string){
        return this.httpRequestService.getHttpRequest(url);
    }
    
    //service to send verification request to physician or decline  request.
    updateMedicalDocStatus(url:string,data: any){
         return this.httpRequestService.putHttpRequest(data,url);

    }
    //service get the single medical document detail
    getMedicalDocument(url:string){
        return this.httpRequestService.getHttpRequest(url);
    }

    //service get the StrainList depend on LpUser
    getStrainsList(data :any, url:string){
       return this.httpRequestService.postHttpRequest(data, url);
    }
  
    //service add or update Lpuser order palce detail
    orderProduct(data :any, url:string){
      return this.httpRequestService.postHttpRequest(data, url);
    }

    //Update LpUser Details
    updateLpDetail(data :any, url:string){
      return this.httpRequestService.putHttpRequest(data, url);
    }
    
    //service to update or add UserAddress Detail
    addOrModifyUserAddress(data :any, url:string){
      return this.httpRequestService.postHttpRequest(data, url);
    }

   //service to get the Lp ProductList
    getProductList(data :any, url:string){
      return this.httpRequestService.postHttpRequest(data, url);
    }
    
    //service getting the setting detail for LpProduct add or update
    getSettingDetail(url:string){
       return this.httpRequestService.getHttpRequest(url);
    }
    
  //   //service to add Or Update the Lp ProductList
  //   addOrUpdateLpProductDetail(data :any, url:string): Promise<any>{
  //   return this.httpRequestService.postHttpRequestPromise(data, url).catch(res=>{
  //    console.log("resresresresresresresresresresres");
  //   });
  // }

    //service to add Or Update the Lp ProductList
    addOrUpdateLpProductDetail(data :any, url:string){
    return this.httpRequestService.postHttpRequest(data, url);
    }
  
    getAllMedicalDocumentByRange(url:string){
    return this.httpRequestService.getHttpRequest(url);
  }
  
  // get client update details 
   getClientUpdateDetail(url:string){
   return this.httpRequestService.getHttpRequest(url);
  }
  
  getAllDocuments(url: string) {
    return this.httpRequestService.getHttpRequest(url);
  }

  uploadDocument(url: string, data: any) {
    return this.httpRequestService.postHttpRequest_Upload_Doc_Image(data, url);
  }

  removeDocument(url: string) {
    return this.httpRequestService.getHttpRequest(url);
  }

  downloadDocument(url: string) {
    return this.httpRequestService.getHttpDocumentDownload(url);
  }

  //service get the current cannabislog by patient id
  getCurrentCannabisLogByPatientId(url:string){
    return this.httpRequestService.getHttpRequest(url);
  }
  //service fetch all the cannabislog By patientId
  getAllCannabisLogByPatientId(url:string){
    return this.httpRequestService.getHttpRequest(url);
  }
  
  //service fetch 5top ratedstrain.
  get5TopRatedStrainByPatientId_Condition(data :any, url:string){
    return this.httpRequestService.postHttpRequest(data, url);
  }
  
  //service get the ProductList based on patientid
  getProductBasedOnPatientId(url:string){
    return this.httpRequestService.getHttpRequest(url);
  }

  addOrUpdateCannabiesLog(data:string ,url:string){
   return this.httpRequestService.postHttpRequest(data,url);
  }
}