import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { RecordBusiness } from '../../business/record.business';
import { PrintService } from "../../../../../shared/shared-util/shared-print-service";

@Component({
	selector: 'medical-document',
	templateUrl: './medical-document.component.html',
	styleUrls: ['./medical-document.component.scss']
})
export class MedicalDocumentComponent implements OnInit {

	public opts: ISlimScrollOptions;
	public daysvalue:string;
	public weeksvalue:string;
	public monthsvalue:string;
	public initial:string;
	public ValidCurrentUser:string;
	public canUpdate:boolean;
	dialog: DialogRef<any>;

	@Input() medicaldocumentData: any;
	@ViewChild('viewStrainInfo') public viewStrainInfo: TemplateRef<any>;
	@Output() modelClose = new EventEmitter();
	@Output() modelPrint = new EventEmitter();
	
	constructor(private recordBusiness: RecordBusiness, private layoutComponent: LayoutComponent, overlay: Overlay
			 , private printService: PrintService, vcRef: ViewContainerRef, public modal: Modal
			 , private router: Router, private el: ElementRef) {
		overlay.defaultViewContainer = vcRef;
	}

	ngOnInit() {
		this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
		}

        this.ValidCurrentUser = localStorage.getItem('currentUser');
		this.canUpdate = false;

		if(this.medicaldocumentData){
			if(this.medicaldocumentData.Period_of_Use == "Days"){
				this.daysvalue = this.medicaldocumentData.Period_Value;
				this.weeksvalue = "";
				this.monthsvalue = "";
			}
			else if(this.medicaldocumentData.Period_of_Use == "Weeks"){
				this.weeksvalue = this.medicaldocumentData.Period_Value;
				this.daysvalue = "";
				this.monthsvalue = "";
			}
			else if(this.medicaldocumentData.Period_of_Use == "Months"){
				this.monthsvalue = this.medicaldocumentData.Period_Value;
				this.weeksvalue = "";
				this.daysvalue = "";
			}

			let splitted = this.medicaldocumentData.HCP_Given_Name.split(' ');
			this.initial = splitted[0].substring(0,1) + "." + splitted[1].substring(0,1);
		}

	 }

	printOptionMedicalDoc(evt: any) {
		this.modelPrint.emit(evt);
		return false;
	}

	onPrintMD(){

		/* let headerMecialDocument = document.getElementById('headerMecialDocument').innerHTML;
        let diagnosishtml = document.getElementById('diagnosishtml').innerHTML;
        let suggestionshtml = document.getElementById('suggestionshtml').innerHTML;
        let marijuanaValue = (<HTMLInputElement>document.getElementById('marijuanaValue')).value;
        let PeriodValue = (<HTMLInputElement>document.getElementById('PeriodValue')).value;
        let thcValue = (<HTMLInputElement>document.getElementById('thcValue')).value;
        let cbdValue = (<HTMLInputElement>document.getElementById('cbdValue')).value;
        let period_of_Use = (<HTMLInputElement>document.getElementById('Period_of_Use')).innerHTML;
        
    
        let innerFullHtml = "<section class='view-doc-wrapper'>" +
        "<header >"+
         headerMecialDocument+
        "</header> <div class='view-area'>"+
        " <p class='modal-cont'>Daily quantity of marijuana to be used by the patient:</p>"+
        "<p><input type='text' value="+marijuanaValue+" readonly class='txt-box'/><span class='spacing-txtbox'> gram/day</span></p>"+
        "<p class='modal-cont'> The Period of Use Is</p>"+
        "<p><input type='text' value="+PeriodValue+"  readonly class='txt-box'/> <span class='spacing-txtbox'>" +period_of_Use+"</span></p>"+
        "<p class='modal-cont'> Diagnosis Comments</p><p>"+
        diagnosishtml+
        "</p><p class='modal-cont'> Suggestions Only</p>"+
        "<p><input type='text' readonly value="+thcValue+" class='txt-box'/> THC (%)</p> "+
        "<p><input type='text'  readonly value="+cbdValue+" class='txt-box'/> CBD (%)</p>"+
        "<p class='modal-cont'> Notes and/or Restrictions</p>"+
		"<textarea  class='txt-area' rows='3'>"+suggestionshtml+"</textarea></div></section>" */
		
		let inner = "<section> <div class='container-wrapper'><h3 class='inner-header'>MEDICAL DOCUMENT\
		</h3> <div id='medicaldocument' class='personalinfo container-fluid'>" + document.getElementById("medicaldocument").innerHTML + 
		"</div></div></section>";
    
        this.printService.printFile(inner, 'medicalDocumentprint');

	}

	onRemoveWatermark(){}

	onUpdateMD(){}

	onDeleteMD(){}

	onCancel(evt: any){
		this.modelClose.emit(evt);
		return false;
	}


}
