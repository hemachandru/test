import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { MedicalDocumentComponent } from './medical-document/medical-document.component';
import { PipeModule } from '../../../../shared/shared-pipe/pipe.module';
import { SlimScrollModule } from 'ng2-slimscroll';
import { PrintService } from "../../../../shared/shared-util/shared-print-service";

@NgModule({
    imports: [PipeModule, SlimScrollModule, CommonModule, FormsModule],
    declarations: [MedicalDocumentComponent],
    exports: [MedicalDocumentComponent],
    providers:[PrintService]
})

export class MedicalComponentModel {

}