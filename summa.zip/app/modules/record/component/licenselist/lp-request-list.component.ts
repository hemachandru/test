import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, ElementRef, EventEmitter } from "@angular/core";
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { PlatformLocation } from '@angular/common';
import { RepeatPipe } from 'ng-pipes';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { RecordService } from '../service/record.service';
import { RecordBusiness } from '../business/record.business';
import { ClientBusiness } from '../../../client/business/client.business';
import { Router } from '@angular/router';
import { LoginBusiness } from '../../../account/component/business/login.business';
import { LoginService } from '../../../account/component/service/login.service';
import { LayoutComponent } from "../../../layout/component/layout.component";
import { PrintService } from "../../../../shared/shared-util/shared-print-service";

@Component({
    selector: 'request-list',
    templateUrl: './lp-request-list.component.html',
    styleUrls: ['./lp-request-list.component.scss'],
    providers: [RecordService, RecordBusiness, HttpRequestService, Config, RepeatPipe, ClientBusiness, LoginBusiness, LoginService]
})

export class RequestList implements OnInit, CloseGuard {
    dialog: DialogRef<any>;
    isMedicalDoc: boolean = true;
    allMedicalDocument: any;
    statusText: string;
    orderProductData: any;
    patientFullName: string;
    public opts: ISlimScrollOptions;
    public sendforverification: string = this.config.sendforverification;
    public declined: string = this.config.decline;
    public Verificationdeclined: string = this.config.Verificationdeclined;
    public Verificationrequested: string = this.config.Verificationrequested;
    public Verificationapproved: string = this.config.Verificationapproved;
    public requestDeclined: string = this.config.requestdeclinedLpUser;
    public verificationrequest: string = this.config.verificationrequest;
    public medicalDocumentDetail: any;

    @ViewChild('productListRef') public productListRef: TemplateRef<any>;
    @ViewChild('viweDocRef') public viweDocRef: TemplateRef<any>;
    @ViewChild('alertModalRef') public alertModalRef: TemplateRef<any>;

    constructor(private printService: PrintService,private location: PlatformLocation, private layoutComponent: LayoutComponent, private config: Config, private loginBusiness: LoginBusiness, private router: Router, private recordBusiness: RecordBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        this.initService();
    }


    onClick(event: Event) {
        this.modal.open(this.productListRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            })
    }

    onViewDocument(event: Event, isMedDoc: boolean) {
        this.isMedicalDoc = isMedDoc ? true : false;

        return this.modal.open(this.viweDocRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    onProductDocument(event: Event) {

        return this.modal.open(this.productListRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    onMedicalDocument(event: Event, isMedDoc: boolean, medicalDocumentId: number) {
        this.layoutComponent.showSpinner(true);
        this.recordBusiness.getMedicalDocument(medicalDocumentId).subscribe(response => {
            this.layoutComponent.showSpinner(false);
            this.medicalDocumentDetail = response;
            this.onViewDocument(event, isMedDoc);
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.error("RequestList lpRequestBusiness updateMedicalDocStatus sendForVerification  erro  ", err);
        });
    }

    close() {
        this.dialog.close();
    }

    onProductDoc(event: Event, orderProductData: any, patientFirstName: string, patientLastName: string) {
        this.orderProductData = [];
        this.patientFullName = '';
        this.orderProductData = orderProductData;
        this.patientFullName = patientFirstName + ' ' + patientLastName;
        this.onProductDocument(event);
    }

    sendForVerification(e: any, patientObject: any) {
        //service to send verification request to physician or decline  request.
        var docStatus = "LPSVTP";
        this.layoutComponent.showSpinner(true);
        this.recordBusiness.updateMedicalDocStatus(patientObject, docStatus).subscribe(response => {
            var target = e.target || e.srcElement || e.currentTarget;
            target.classList.add('display-none');
            target = document.getElementById("sendDeclinedButton_" + patientObject.Medical_Document_Id)
            target.classList.add("display-none");
            target = document.getElementById("verificationRequest_" + patientObject.Medical_Document_Id)
            target.classList.add("display-block");
            this.layoutComponent.showSpinner(false);
            this.sendForVerificationAlert(e);
        }, (err) => {
            console.error("RequestList lpRequestBusiness updateMedicalDocStatus sendForVerification  erro  ", err);
        });
    }

    decline(e: any, patientObject: any) {
        var docStatus = "LPD";
        this.layoutComponent.showSpinner(true);
        this.recordBusiness.updateMedicalDocStatus(patientObject, docStatus).subscribe(response => {
            var target = e.target || e.srcElement || e.currentTarget;
            target.classList.add('display-none');
            target = document.getElementById("sendVerificationButton_" + patientObject.Medical_Document_Id)
            target.classList.add("display-none");
            target = document.getElementById("verificationDeclined_" + patientObject.Medical_Document_Id)
            target.classList.add("display-block");
            this.layoutComponent.showSpinner(false);
            this.declineAlert(e);
        }, (err) => {
            console.error("RequestList lpRequestBusiness updateMedicalDocStatus  decline erro  ", err);
        });
    }

    sendForVerificationAlert(e: Event) {

        return this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                var x = e.target;
                this.statusText = this.config.verficationPhysician;
                this.dialog = dialog;
                //this.close();
                console.log(this.dialog);
            });
    }

    declineAlert(e: Event) {
        return this.modal.open(this.alertModalRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-cls' }, BSModalContext))
            .then(dialog => {
                this.statusText = this.config.requestDeclined;
                this.dialog = dialog;
                console.log(this.dialog);
            });
    }

    onRegisterDocument(event: Event, isMedDoc: boolean) {
        this.isMedicalDoc = isMedDoc ? true : false;

        return this.modal.open(this.viweDocRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }

    initService() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.opts = {
                position: 'right',
                barBackground: '#4f4f4f',
                barBorderRadius: '0',
                barWidth: '4',
                gridWidth: '4',
                gridMargin: '1px 0'
            }
            this.allMedicalDocument = [];
            this.statusText = '';
            this.recordBusiness.getAllMedicalDocument().subscribe(response => {
                this.allMedicalDocument = response;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.error("RequestList lpRequestBusiness getAllMedicalDocument erro  ", err);
            });
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }

    onModelClose(event: any) {
        this.dialog.close();
    }

    printOption(event: any, productOrMedicalDocFlag: string): void {
        let innerContents = document.getElementById('productListData').innerHTML;
        let innerFullList = "<div class='product-wrapper'>" +
            "<p>" + this.patientFullName + "- Product List</p>" +
            "<div class='item-wrapper'>" +
            "<ul>" +
            innerContents +
            "</ul></div></div>"

        this.printService.printFile(innerFullList, productOrMedicalDocFlag);
    }
    printOptionMedicalDoc(event: any){
    let headerMecialDocument = document.getElementById('headerMecialDocument').innerHTML;
    let diagnosishtml = document.getElementById('diagnosishtml').innerHTML;
    let suggestionshtml = document.getElementById('suggestionshtml').innerHTML;
    let marijuanaValue = (<HTMLInputElement>document.getElementById('marijuanaValue')).value;
    let PeriodValue = (<HTMLInputElement>document.getElementById('PeriodValue')).value;
    let thcValue = (<HTMLInputElement>document.getElementById('thcValue')).value;
    let cbdValue = (<HTMLInputElement>document.getElementById('cbdValue')).value;
    let period_of_Use = (<HTMLInputElement>document.getElementById('Period_of_Use')).innerHTML;
    

    let innerFullHtml = "<section class='view-doc-wrapper'>" +
    "<header >"+
     headerMecialDocument+
    "</header> <div class='view-area'>"+
    " <p class='modal-cont'>Daily quantity of marijuana to be used by the patient:</p>"+
    "<p><input type='text' value="+marijuanaValue+" readonly class='txt-box'/><span class='spacing-txtbox'> gram/day</span></p>"+
    "<p class='modal-cont'> The Period of Use Is</p>"+
    "<p><input type='text' value="+PeriodValue+"  readonly class='txt-box'/> <span class='spacing-txtbox'>" +period_of_Use+"</span></p>"+
    "<p class='modal-cont'> Diagnosis Comments</p><p>"+
    diagnosishtml+
    "</p><p class='modal-cont'> Suggestions Only</p>"+
    "<p><input type='text' readonly value="+thcValue+" class='txt-box'/> THC (%)</p> "+
    "<p><input type='text'  readonly value="+cbdValue+" class='txt-box'/> CBD (%)</p>"+
    "<p class='modal-cont'> Notes and/or Restrictions</p>"+
    "<textarea  class='txt-area' rows='3'>"+suggestionshtml+"</textarea></div></section>"

    this.printService.printFile(innerFullHtml, 'medicalDocument');
    }
}
