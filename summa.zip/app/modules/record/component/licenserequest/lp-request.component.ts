import { Component } from '@angular/core';
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
    selector: 'request',
    templateUrl: './lp-request.component.html',
    styleUrls: ['./lp-request.component.scss']
    // styles: [`
    //     .main-wrapper {
    //         height: 445px;
    //         padding-left: 20px;
    //         padding-top: 0;
    //     }
    // `]
})

export class LPRequestComponent {
    public opts: ISlimScrollOptions;

    constructor() {
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
    }
}