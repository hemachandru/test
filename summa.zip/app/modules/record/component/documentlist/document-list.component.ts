import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { DocumentListEntity } from '../../entity/document.entity';
import { RecordBusiness } from "../business/record.business";
import { DomSanitizer } from '@angular/platform-browser';
import { Config } from '../../../../config/constant';
import { LayoutComponent } from "../../../layout/component/layout.component";
import * as FileSaver from 'file-saver';
import { PrintService } from "../../../../shared/shared-util/shared-print-service";

@Component({
    selector: 'doc-list',
    templateUrl: './document-list.component.html',
    styleUrls: ['./document-list.component.scss']
})

export class DocumentListComponent {

    @Input() lists: DocumentListEntity[];
    @Output() onBtnClick = new EventEmitter();
    @Output() onBtnClose = new EventEmitter();

    @ViewChild('viweDocRef') public viweDocRef: TemplateRef<any>;
    @ViewChild('deleteDocRef') public deleteDocRef: TemplateRef<any>;
    dialog: DialogRef<any>;
    private dataObj: any;
    private fileURL: any;
    private doc_title: string = "";
    private f_date: any;

    constructor(private printService: PrintService, private layoutComponent: LayoutComponent, private config: Config, private sanitizer: DomSanitizer, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef, private _rb: RecordBusiness) {
        overlay.defaultViewContainer = vcRef;
    }

    onViewImageFile(event: Event, item: any) {
        this.layoutComponent.showSpinner(true);
        let data = {
            id: item.id,
            file_type: item.file_type,
            author: item.author
        }

        this._rb.downloadDocument(data).subscribe((res: any) => {
            
            item.file_type.toLowerCase();
            if (item.file_type == "txt" || item.file_type == "pdf" || item.file_type == "doc" || item.file_type == "docx" || item.file_type == "png" || item.file_type == "jpeg" || item.file_type == "bmp" || item.file_type == "gif" ) {
                FileSaver.saveAs(res._body, item.doc_title + "." + item.file_type);
                this.layoutComponent.showSpinner(false);
            } else {
                this.doc_title = "";
                this.f_date = "";
                this.fileURL = "";
                this.doc_title = item.doc_title;
                this.f_date = item.f_date;

                var ie = navigator.userAgent.match(/MSIE\s([\d.]+)/),
                    ie11 = navigator.userAgent.match(/Trident\/7.0/) && navigator.userAgent.match(/rv:11/),
                    ieEDGE = navigator.userAgent.match(/Edge/g),
                    ieVer = (ie ? ie[1] : (ie11 ? 11 : (ieEDGE ? 12 : -1)));

                if (ie && ieVer < 10) {
                    console.log("No blobs on IE ver<10");
                }
                if (ieVer > -1) {
                    window.navigator.msSaveOrOpenBlob(res._body, item.doc_title + "." + item.file_type);
                    this.layoutComponent.showSpinner(false);
                } else {
                    this.fileURL = URL.createObjectURL(res._body);
                    this.onViewDocument(event);
                    this.layoutComponent.showSpinner(false);
                }
            }
        }, (err) => {
            this.layoutComponent.showSpinner(false);
        });
    }

    _handleReaderLoaded(readerEvt: any) {
        this.fileURL = readerEvt.target.result;
        this.onViewDocument(event);
    }
    onViewDocument(event: Event) {
        return this.modal.open(this.viweDocRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-view-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    onDeleteDocument(event: Event, data: any) {
        event.stopPropagation();
        event.preventDefault();

        this.dataObj = data;
        return this.modal.open(this.deleteDocRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-delete-document' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
                //this.close();
            });
    }

    onPrint(url: any) {
        this.dialog.close();
        let innerFullHtml = "<img src=" + this.fileURL + " alt='ImageLoadProblem'>"
        this.printService.printFile(innerFullHtml, '');
    }

    onClose() {
        this.onBtnClose.emit(this.dialog);
    }

    onImagePreviewClose() {
        this.doc_title = "";
        this.f_date = "";
        this.fileURL = "";
        this.dialog.close();
    }
    onDelete() {
        let event = {
            data: this.dataObj,
            dialog: this.dialog
        }
        this.onBtnClick.emit(event);
    }
}