import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { cannabisslider } from './cannabisslider.service';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';

import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { RecordBusiness } from '../business/record.business';
import { RecordService } from '../service/record.service';
import { LayoutBusiness } from '../../../layout/business/layout.business';
import { LayoutService } from '../../../layout/service/layout.service';
import { LayoutComponent } from '../../../layout/component/layout.component';
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";
import { CannabisEntity } from '../../entity/cannabislog.entity';

@Component({
  templateUrl: './cannabis.component.html',
  styleUrls: ['./cannabis.component.scss'],
  providers: [cannabisslider, RecordService, RecordBusiness, HttpRequestService, Config, LayoutBusiness, LayoutService],
})
export class CannabisComponent implements OnInit {

  public opts: ISlimScrollOptions;
  private currentCannabisLogDetail: any;
  private allCannabisLogDetail: any;
  private top5StrainDetail: any;
  private noData = this.config.noData;
  private masterInfoData: any;
  private medicalConditions: any;
  private intakeModes: any;
  private strainDetail: any;
  public searchStr: string;
  protected dataService: CompleterData;
  public clearSearchInput: boolean = false;
  public tempFilter: any;
  public strainConditon: any;
  public conditionData: any;
  public top5StrainDetailStatus: boolean = false;

  public searchStrain: string;
  protected dataServiceStrain: CompleterData;
  public clearSearchInputStrain: boolean = false;
  public currentDate: any = Date();
  private positiveEffects: any;
  private negativeEffects: any;
  private cannabisEntity: CannabisEntity;

  //public appendCondition: any;

  @ViewChild('appendCondition') appendCondition: ElementRef;
  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;
  highlightedDiv: number;

  constructor(private completerService: CompleterService, private _sos: SharedObserverService, private layoutComponent: LayoutComponent, private layoutBusiness: LayoutBusiness, private recordBusiness: RecordBusiness, private config: Config, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef, private sliderjs: cannabisslider) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {
      this.top5StrainDetailStatus = false;
      this.clearSearchInput = true;
      this.layoutComponent.showSpinner(true);
      this.opts = {
        position: 'right',
        barBackground: '#4f4f4f',
        barBorderRadius: '0',
        barWidth: '4',
        gridWidth: '4',
        gridMargin: '1px 0'
      }
      this.highlightedDiv = 5;

      this.canabiesService();

      //service fetch 5top ratedstrain.
      this.get5TopRatedStrain("");

      //service return full master detail
      this._sos.eventReceiver$.subscribe(res => {
        this.masterInfoData = res;
        this.medicalConditions = res.MedicalConditions;
        this.tempFilter = res.MedicalConditions;
        this.medicalConditions ? this.dataService = this.completerService.local(this.medicalConditions, 'Title', 'Title') : '';
        this.intakeModes = res.IntakeModes;
        this.positiveEffects = res.PositiveEffects;
        this.negativeEffects = res.NegativeEffects;
      });

      //service get the ProductList based on patientid
      this.recordBusiness.getProductBasedOnPatientId(1).subscribe(res => {
        this.strainDetail = res;
        this.strainDetail ? this.dataServiceStrain = this.completerService.local(this.strainDetail, 'Strain', 'Strain') : '';
        this.layoutComponent.showSpinner(false);
      }, (err) => {
        this.layoutComponent.showSpinner(false);
        console.log("layoutBusiness getProductBasedOnPatientId err", err);
      })

    } else {
      this.layoutComponent.showSpinner(false);
      this.router.navigate(['portal-login']);
    }
  }

  newCanabisEntry(action: string, e: any) {

    this.cannabisEntity = {
      logId: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Log_ID : 0,
      patient_ID: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Patient_ID : Number(localStorage.getItem('mvcUserId')),
      product_ID: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Product_ID : 0,
      conditions: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Conditions : '',
      intake: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Intake : '',
      positive_Effects: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Positive_Effects : '',
      positive_Comments: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Positive_Comments : '',
      negative_Effects: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Negative_Effects : '',
      negative_Comments: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Negative_Comments : '',
      effectiveness: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Effectiveness : 0,
      side_Effects: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Side_Effects : 0,
      product_Name: this.currentCannabisLogDetail ? this.currentCannabisLogDetail.Product_Name : ''
    }

    return this.modal.open(this.templateRef, overlayConfigFactory({ isBlocking: true, dialogClass: 'modal-dialog modal-dialog-register profileModal canbisModal' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        this.sliderjs.onstart();
      })
  }

  saveCannabiesLog(logData: any, evt: any) {
    if (logData.product_ID != "0" || logData.conditions != null || logData.intake != null || logData.positive_Effects != null  || logData.positive_Comments != null || logData.negative_Effects != null  || logData.negative_Comments != null) {
      this.layoutComponent.showSpinner(true);
      this.recordBusiness.addOrUpdateCannabiesLog(logData).subscribe(res => {
        this.dialog.close();
        this.canabiesService();
        this.layoutComponent.showSpinner(false);
     
  },(err) => {
      this.layoutComponent.showSpinner(false);
      console.log("layoutBusiness addOrUpdateCannabiesLog", err);
    });
    console.log(logData);
     }else{
        this.dialog.close();
     }
  }

  //PREV and NEXT for slides
  plusSlides(n: any) {
    this.sliderjs.plusSlides(n);
  }

  //DOTS for the Slides.
  currentSlide(n: any) {
    this.sliderjs.currentSlide(n);
  }

  onClose() {
    this.dialog.close();
  }

  public listClick(newValue: number, event: any) {
    event.preventDefault();
    if (this.highlightedDiv === newValue) {
      this.highlightedDiv = 0;
    }
    else {
      this.highlightedDiv = newValue;
    }
  }
  onSelectName(selected: CompleterItem) {
    if (selected) {
      this.strainConditon = "'" + selected.originalObject.Title + "'";
      this.conditionData = selected.originalObject.Title;
      this.get5TopRatedStrain(this.strainConditon.toString())
    }
  }

  removeCondition(conditionName: string, index: number) {
    this.strainConditon = '';
    this.conditionData = '';
    this.get5TopRatedStrain('');
  }
  get5TopRatedStrain(input: string) {
    //service fetch 5top ratedstrain.
    this.layoutComponent.showSpinner(true);
    this.recordBusiness.get5TopRatedStrainByPatientId_Condition(input).subscribe(res => {
      res.Products ? this.top5StrainDetailStatus = false : this.top5StrainDetailStatus = true;
      this.top5StrainDetail = res.Products;

      this.layoutComponent.showSpinner(false);
    }, (err) => {
      this.layoutComponent.showSpinner(false);
      console.log("recordBusiness getTopRatedStrain err", err);
    });
  }

  onSelectStrainName(selected: CompleterItem) {
    if (selected) {
      this.cannabisEntity.product_ID = selected.originalObject.Product_ID;
      this.cannabisEntity.product_Name = selected.originalObject.Strain;
    }
  }

  canabiesService() {
    //service get the current cannabislog by patient id
    this.layoutComponent.showSpinner(true);
    this.recordBusiness.getCurrentCannabisLogByPatientId().subscribe(res => {
      this.currentCannabisLogDetail = res;
    }, (err) => {
      this.layoutComponent.showSpinner(false);
      console.log("recordBusiness getCurrentCannabisLogByPatientId err", err);
    });

    //service fetch all the cannabislog By patientId
    this.recordBusiness.getAllCannabisLogByPatientId().subscribe(res => {
      this.allCannabisLogDetail = res;
      this.layoutComponent.showSpinner(false);
    }, (err) => {
      this.layoutComponent.showSpinner(false);
      console.log("recordBusiness getAllCannabisLogByPatientId err", err);
    });

  }

  onChangeSearchText(event: any) {
		if (!event) {
			 this.cannabisEntity.product_ID = "0";
       this.cannabisEntity.product_Name = "";
		}

	}
}
