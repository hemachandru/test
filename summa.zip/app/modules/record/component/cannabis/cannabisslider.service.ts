// File: app/slider.service.ts
import { Injectable } from '@angular/core';

@Injectable()
export class cannabisslider {
	slideIndex: number = 1;
	onstart(){	    
	    this.showSlides(this.slideIndex);	    
	}
	plusSlides(n: any) {
        this.showSlides(this.slideIndex += n);
    }
    currentSlide(n: any) {
        this.showSlides(this.slideIndex = n);
    }
    showSlides(n: any) {
        var i;
        var slides: any = document.getElementsByClassName("mySlides");
        var dots: any = document.getElementsByClassName("dot");
        var nextArroweHidden: any =document.getElementById("nextArrowEnd");
        var prevArroweHidden: any =document.getElementById("prevArrowEnd");
           //.style.display = "none"
        console.log(slides)
        if (n > slides.length) {this.slideIndex = 1}    
        if (n < 1) {this.slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
        	console.log(slides[i]);
            slides[i].style.display = "none";  
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");

        }
        slides[this.slideIndex-1].style.display = "block";  
        n==1?prevArroweHidden.style.display="none":'';
        n > 1?prevArroweHidden.style.display="block":'';
        n<5?nextArroweHidden.style.display="block":'';
        n==5?nextArroweHidden.style.display="none":'';
        dots[this.slideIndex-1].className += " active";
        
    }
}