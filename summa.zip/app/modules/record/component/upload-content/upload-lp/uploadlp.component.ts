import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { PlatformLocation } from '@angular/common';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { UpdateLPEntity } from './entity/upload-lp.entity';

import { Config } from '../../../../../config/constant';
import { HttpRequestService } from '../../../../../shared/shared-service/http-request.service';
import { RecordService } from '../../service/record.service';
import { RecordBusiness } from '../../business/record.business';
import { LoginBusiness } from '../../../../account/component/business/login.business';
import { LoginService } from '../../../../account/component/service/login.service';
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
    selector: 'upload-lp',
    templateUrl: './uploadlp.component.html',
    styleUrls: ['./uploadlp.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor'],
    providers: [HttpRequestService, Config, RecordService, RecordBusiness, LoginBusiness, LoginService]
})
export class UploadLpComponent implements OnInit {
    activeColor: string = 'green';
    baseColor: string = '#ccc';
    overlayColor: string = 'rgba(255,255,255,0.5)';
    dragging: boolean = false;
    loaded: boolean = false;
    imageLoaded: boolean = false;
    imageSrc: string = '';
    borderColor: any;
    iconColor: any;
    updateentity: UpdateLPEntity;
    invalidEmail: any;
    invalidPhone: any;
    invalidFile: any;
    phoneerror = true;
    emailerror = true;
    filesize = true;
    private userDetail: any;
    private maxImageSizeText: string = this.config.maximageuploadsize;
    private successAlert: boolean = false;
    private infoAlert: boolean = false;
    private errorAlert: boolean = false;
    private showError: any;
    // public numberMask =  [/[1-9]/];

    @ViewChild('successsave') public successsave: TemplateRef<any>;
    dialog: DialogRef<any>;
    constructor(private location: PlatformLocation, private layoutComponent: LayoutComponent, private recordBusiness: RecordBusiness, private config: Config, private loginBusiness: LoginBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;

    }
    ngOnInit() {
        //var pattern=/^[0-9]*$/;
        this.initService();
    }
    onClose() {
        this.dialog.close();
    }
    onBack() {
        this.router.navigate(['record']);
    }
    onSave(updateLpData: any) {
        this.layoutComponent.showSpinner(true);
        this.showErrorMessage(false, false, false, '');
        updateLpData.imageBase64Url = this.imageSrc ? this.imageSrc : '';
        //service update the LpUserData
        this.recordBusiness.updateLpDetail(updateLpData, this.userDetail).subscribe(res => {
            let responsedata = res;
            //fetch the latest userDetail code
            this.loginBusiness.getUserDetail().subscribe(res => {
                this.userDetail = res;

                //update Address Details
                this.recordBusiness.addOrModifyUserAddress(this.userDetail, updateLpData, this.userDetail.LP_Login_Data.address ? 2 : 1).subscribe(res => {
                    this.loginBusiness.getUserDetail().subscribe(res => {
                        this.userDetail = res;
                        responsedata.Response_Code == 3 ? this.showErrorMessage(false, false, true, this.config.emailalreadyexist) : this.onSaveAlertModel();
                        this.layoutComponent.showSpinner(false);
                    }, (err) => {
                        this.layoutComponent.showSpinner(false);
                        console.error("UploadLpComponent recordBusiness addOrModifyUserAddress ", err);
                    });
                }, (err) => {
                    this.layoutComponent.showSpinner(false);
                    console.error("UploadLpComponent recordBusiness addOrModifyUserAddress ", err);
                });

            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.error("UploadLpComponent loginBusiness getUserDetail ", err);

            });

        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.error("UploadLpComponent recordBusiness updateLpDetail ", err);
        });
    }

    onSaveAlertModel() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onEmailBlur(val: any) {
        if (val != "") {
            if (val.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
                UploadLpComponent.prototype.invalidEmail = 'none';
            } else {
                this.emailerror = false;
                UploadLpComponent.prototype.invalidEmail = 'block';
            }
        }
    }
    
   _keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
  
    onFocusInput(e: any) {
        if (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0) {
            setTimeout(function () {
                e.srcElement.autocomplete = 'off';
            }, 1);
        };
    }
    //upload image
    handleDragEnter() {
        this.dragging = true;
    }

    handleDragLeave() {
        this.dragging = false;
    }

    handleDrop(e: any) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }

    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e: any) {
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }
        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }

    _handleReaderLoaded(e: any) {
        var value = e.total;
        if (value > 2097152) // 2 mb for bytes.
        {
            this.filesize = false;
            UploadLpComponent.prototype.invalidFile = 'block';
        }
        else {
            this.filesize = true;
            UploadLpComponent.prototype.invalidFile = 'none';
            var reader = e.target;
            this.imageSrc = reader.result;
            this.loaded = true;
        }
    }

    _setActive() {
        this.borderColor = this.activeColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.activeColor;
        }
    }

    _setInactive() {
        this.borderColor = this.baseColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.baseColor;
        }
    }

    initService() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.showErrorMessage(false, false, false, '');
            UploadLpComponent.prototype.invalidPhone = 'none';
            UploadLpComponent.prototype.invalidFile = 'none';
            this.updateentity = {
                email: '',
                phone: '',
                street: '',
                city: '',
                firstname: '',
                desc: '',
                file: '',
                imageBase64Url: '',
                lastname: ''
            }
            // Get LoginUserDeatil
            this.loginBusiness.getUserDetail().subscribe(res => {

                this.userDetail = res;
                if (res.LP_Login_Data) {
                    this.updateentity.email = res.LP_Login_Data.Email ? res.LP_Login_Data.Email : '';

                    this.updateentity.phone = res.LP_Login_Data.address ? (res.LP_Login_Data.address.Home_Phone ? res.LP_Login_Data.address.Home_Phone : '') : '';

                    this.updateentity.street = res.LP_Login_Data.address ? (res.LP_Login_Data.address.User_Address ? res.LP_Login_Data.address.User_Address : '') : '';

                    this.updateentity.city = res.LP_Login_Data.address ? (res.LP_Login_Data.address.City ? res.LP_Login_Data.address.City : '') : '';

                    this.updateentity.firstname = res.LP_Login_Data.LP_First_Name ? res.LP_Login_Data.LP_First_Name : '';

                    this.updateentity.lastname = res.LP_Login_Data.LP_Last_Name ? res.LP_Login_Data.LP_Last_Name : '';

                    this.imageSrc = res.LP_Login_Data.Image_Url ? res.LP_Login_Data.Image_Url : '';

                    this.updateentity.desc = res.LP_Login_Data.About_Us ? res.LP_Login_Data.About_Us : '';
                }
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.error("UploadLpComponent loginBusiness getUserDetail ", err)
            });
        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }

    showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
        this.successAlert = succeboolean;
        this.errorAlert = errorboolean;
        this.infoAlert = infoboolean;
        this.showError = errorMessage;
    }

    emptyTextFunction(nameValue:string,firstOrLastName:string){
       if(firstOrLastName == "firstname"){
         nameValue.trim() == "" ?this.updateentity.firstname="":'';
       }else if(firstOrLastName == "lastname"){
         nameValue.trim() == "" ?this.updateentity.lastname="":'';
       }else if(firstOrLastName == "street"){
         nameValue.trim() == "" ?this.updateentity.street="":'';
       }else if(firstOrLastName == "city"){
         nameValue.trim() == "" ?this.updateentity.city="":'';
       }else if(firstOrLastName == "desc"){
         nameValue.trim() == "" ?this.updateentity.desc="":'';
       }
    }
}
