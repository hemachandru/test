import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'upload-content',
    templateUrl: './uploadcontent.component.html',
    styleUrls: ['./uploadcontent.component.scss']
})
export class UploadContentComponent {
    constructor(private router: Router) {
        let validCurrentUser = localStorage.getItem('currentUser');
        /** this code is need don't remove.in patient login user will remove "documents/documents" to "documents"  then redirect to this page .so solve that bug add this code.*/
        if (validCurrentUser == "PatientUser") {
            router.navigate(['dashboard']);
            return;
        }
    }
    onUploadLp() {
        this.router.navigate(['record/uploadlp']);
    }
    onUpdateProduct() {
        this.router.navigate(['record/updateproduct']);
    }
}