import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs/Subscription';

import { ManageSettingInterfcae } from '../../../../user/entity/user.interface';
import { LoginBusiness } from '../../../../account/component/business/login.business';
import { LoginService } from '../../../../account/component/service/login.service';
import { UserBusinessService } from '../../../../user/business/user.business';
import { Config } from '../../../../../config/constant';
import { HttpRequestService } from '../../../../../shared/shared-service/http-request.service';
import { LayoutComponent } from "../../../../layout/component/layout.component";
import { Location } from '@angular/common';

@Component({
    templateUrl: './changepassword.component.html',
    styleUrls: ["./changepassword.component.scss"],
    providers: [LoginBusiness, LoginService, Config, HttpRequestService]
})
export class ChangePasswordComponent implements OnInit {
    public user: any;
    public invalidPassword: any;
    public userDetail: any;
    newpassword: string = 'DEFUALT';
    private  validCurrentUser: string;
    private successAlert: boolean = false;
    private infoAlert: boolean = false;
    private errorAlert: boolean = false;
    private showError: any;
    private subscription: Subscription;

    constructor(private _location: Location, private layoutComponent:LayoutComponent,private loginBusiness: LoginBusiness, private router: Router, private _ubs: UserBusinessService, private config:Config) {
        this.user = {
            oldpassword: '',
            newpassword: '',
            confirmpassword: '',
        }
    }
    ngOnInit() {
        this.initService();
    }
    onBack() {
        this._location.back();
    }
    save(event: Event, model: ManageSettingInterfcae, isValid: boolean, formReset: NgForm) {
        event.preventDefault();
        this.layoutComponent.showSpinner(true);
        if (this.validCurrentUser == "LpUser") {
            model.username = this.userDetail.LP_Login_Data.LP_User_Name;
        } else if (this.validCurrentUser == "PatientUser") {
            model.username = this.userDetail.Patient_User_Name;
        }
        this.loginBusiness.changePassword(model, "", false).subscribe(res => {
            res.Response_Code ==1?this.showErrorMessage(true,false,false,this.config.passwordSucessReset):'';
            res.Response_Code ==6?this.showErrorMessage(false,false,true,this.config.currentPassword):'';
            res.Response_Code ==7?this.showErrorMessage(false,true,false,this.config.lastThreePassword):'';
            formReset.resetForm();
            this.layoutComponent.showSpinner(false);
        }, (err) => {
            this.layoutComponent.showSpinner(false);
            console.log("ChangePasswordComponent loginBusiness changePassword ", err)
        });
    }
    resetForm(model: ManageSettingInterfcae) {
        console.log(model.newpassword = "")
    }

    initService() {
        if (localStorage.getItem('token')) {
             this.layoutComponent.showSpinner(true);
            this.showErrorMessage(false,false,false,'');
            this.validCurrentUser = localStorage.getItem('currentUser');
            if (this.validCurrentUser == "LpUser") {
                //fetch the user details
                this._ubs.getUserInfo().subscribe(userData => {
                    this.userDetail = userData;
                    this.layoutComponent.showSpinner(false);
                    console.log(userData);
                }, (err) => {
                    this.layoutComponent.showSpinner(false);
                    console.log("ChangePasswordComponent loginBusiness getUserDetail", err);
                });
            } 
        } else {
             this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }

    showErrorMessage(succeboolean: boolean, infoboolean: boolean, errorboolean: boolean, errorMessage: string) {
        this.successAlert = succeboolean;
        this.errorAlert = errorboolean;
        this.infoAlert = infoboolean;
        this.showError = errorMessage;
    }
    ngOnDestroy() {
        // prevent memory leak when component destroyed
        if(this.subscription){
         this.subscription.unsubscribe();
        }
        
    }
}