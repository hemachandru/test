import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { PlatformLocation } from '@angular/common';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { NgForm } from '@angular/forms';
import { UpdateProduct } from './entity/updateproduct.entity';
import { UpdateProductName } from './entity/component-entity/updatecomponent.entity';
import { UpdateNewProduct } from './entity/component-entity/updateproduct.entity';
import { Config } from '../../../../../config/constant';
import { HttpRequestService } from '../../../../../shared/shared-service/http-request.service';
import { RecordService } from '../../service/record.service';
import { RecordBusiness } from '../../business/record.business';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { LayoutComponent } from "../../../../layout/component/layout.component";

@Component({
    selector: 'upload-content',
    templateUrl: './updateproduct.component.html',
    styleUrls: ['./updateproduct.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor'],
    providers: [HttpRequestService, Config, RecordService, RecordBusiness]
})
export class UpdateProductComponent implements OnInit {
    public opts: ISlimScrollOptions;
    activeColor: string = 'green';
    baseColor: string = '#ccc';
    overlayColor: string = 'rgba(255,255,255,0.5)';
    dragging: boolean = false;
    loaded: boolean = false;
    imageLoaded: boolean = false;
    imageSrc: string = '';
    borderColor: any;
    iconColor: any;
    updateproduct: UpdateProduct;
    invalidFile: any;
    invalidFilevisiable: any;
    filesize = true;
    requiredFile: any;
    fileEmpty = true;
    public productdata: any;
    updatenewproduct: UpdateNewProduct;
    private status_Type: any;
    productList: any;
    private productType: any;
    private productProfiles: any;
    public searchStr: string;
    protected dataService: CompleterData;
    public clearSearchInput: boolean = false;
    public tempProduct: any;
    private maxImageSizeText: string = this.config.maximageuploadsize;
    private imagemandatory: string = this.config.imagemandatory;
    private stockAvailablity: string = this.config.stockAvailability;
    private profileTypeText: string = this.config.profileType;
    private maxCharacter25: string = this.config.maxCharacter25;
    public maxStrainNameStyle: any;

    @ViewChild('addProduct') public addProduct: TemplateRef<any>;
    @ViewChild('viewProduct') public viewProduct: TemplateRef<any>;
    dialogView: DialogRef<any>;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    @ViewChild('myInput') public myInputVariable: any;
    dialogNew: DialogRef<any>;
    dialog: DialogRef<any>;
    constructor(private location: PlatformLocation, private layoutComponent: LayoutComponent, private completerService: CompleterService, private config: Config, private recordBusiness: RecordBusiness, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    onCancel() {
        this.dialog.close();
    }
    ngOnInit() {
        this.initService();
    }
    _keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
    onSave(addProduct: any, newOrUpdate: boolean, formData: NgForm) {
        this.layoutComponent.showSpinner(true);
        if (this.loaded == true) {
            this.fileEmpty = true;
            UpdateProductComponent.prototype.requiredFile = 'none';
            newOrUpdate ? this.updateproduct.imageUrl = this.imageSrc : this.updatenewproduct.imageUrl = this.imageSrc
        }
        else {
            this.fileEmpty = false;

            UpdateProductComponent.prototype.requiredFile = 'block';
            this.layoutComponent.showSpinner(false);

            return false;
        }
        if (addProduct.name.length > 25) {
            UpdateProductComponent.prototype.maxStrainNameStyle = 'block';
            this.layoutComponent.showSpinner(false);
            return false;
        } else {
            UpdateProductComponent.prototype.maxStrainNameStyle = 'none';
        }

        //service  add Or Update the Lp ProductList
        this.recordBusiness.addOrUpdateLpProductDetail(addProduct, newOrUpdate).subscribe(result => {
            newOrUpdate ? formData.resetForm() : '';
            //service to get the Lp ProductList
            this.recordBusiness.getProductList().subscribe(res => {
                this.productdata = res;
                this.tempProduct = this.productdata;
                // if (this.productdata) {
                //     this.dataService = this.completerService.local(this.productdata, 'Product_Name', 'Product_Name') : "";
                // }
                this.productdata ? this.dataService = this.completerService.local(this.productdata, 'Product_Name', 'Product_Name') : "";
                this.layoutComponent.showSpinner(false);
                this.dialog.close();
                this.onSaveView();
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("recordBusiness getProductList erro " + err);
            });
        }, (error) => {
            this.layoutComponent.showSpinner(false);
            console.log("" + error);
        });

    }

    onSuccessSaveAlert() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    onSaveView() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    onClose() {
        this.dialogNew.close();
    }
    onAddNew() {
        this.loaded = false;
        this.imageLoaded = false;
        this.imageSrc = "";
        this.fileEmpty = true;
        UpdateProductComponent.prototype.requiredFile = 'none';
        UpdateProductComponent.prototype.invalidFile = 'none';
        UpdateProductComponent.prototype.invalidFilevisiable = 'none';
        UpdateProductComponent.prototype.maxStrainNameStyle = 'none';
        this.filesize = true;
        this.updateproduct = {
            productId: 0,
            name: '',
            thc: '',
            cbd: '',
            desc: '',
            file: '',
            productname: '',
            productthc: '',
            productcbd: '',
            productdesc: '',
            productStatusType: '',
            productType: '',
            imageUrl: '',
            profileType: ''
        }


        return this.modal.open(this.addProduct, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-addproduct' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onViewProduct(product_Detail: any) {
        UpdateProductComponent.prototype.maxStrainNameStyle = 'none';
        UpdateProductComponent.prototype.invalidFile = 'hidden';
        this.imageSrc = 'data:image/jpeg;base64,' + product_Detail.lpUpdatProduct.Product_Img_Url;
        this.loaded = true;
        this.updatenewproduct = {
            productId: product_Detail.lpUpdatProduct.Product_Id,
            name: product_Detail.lpUpdatProduct.Product_Name,
            thc: product_Detail.lpUpdatProduct.THC,
            cbd: product_Detail.lpUpdatProduct.CBD,
            desc: product_Detail.lpUpdatProduct.Product_Desc,
            file: '',
            productname: '',
            productthc: '',
            productcbd: '',
            productdesc: '',
            productStatusType: product_Detail.lpUpdatProduct.Product_In_Stock ? 1 : 2,
            productType: product_Detail.lpUpdatProduct.Product_Type,
            imageUrl: product_Detail.lpUpdatProduct.Product_Img_Url,
            profileType: product_Detail.lpUpdatProduct.Profile
        }
        return this.modal.open(this.viewProduct, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-addproduct' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            });
    }
    //upload image
    handleDragEnter() {
        this.dragging = true;
    }

    handleDragLeave() {
        this.dragging = false;
    }

    handleDrop(e: any) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }

    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e: any) {
        this.fileEmpty = true;
        UpdateProductComponent.prototype.requiredFile = 'none';
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }

        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }

    _handleReaderLoaded(e: any) {
        var value = e.total;
        if (value > 2097152) // 2 mb for bytes.
        {
            debugger;
            this.filesize = false;
            UpdateProductComponent.prototype.invalidFile = 'block';
            UpdateProductComponent.prototype.invalidFilevisiable = 'block';
        }
        else {
            this.filesize = true;
            UpdateProductComponent.prototype.invalidFile = 'none';
            UpdateProductComponent.prototype.invalidFilevisiable = 'none';
            var reader = e.target;
            this.imageSrc = reader.result;
            this.loaded = true;
        }
    }

    _setActive() {
        this.borderColor = this.activeColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.activeColor;
        }
    }

    _setInactive() {
        this.borderColor = this.baseColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.baseColor;
        }
    }

    initService() {
        if (localStorage.getItem('token')) {
            this.layoutComponent.showSpinner(true);
            this.productdata = [];
            UpdateProductComponent.prototype.invalidFile = 'none';
            UpdateProductComponent.prototype.invalidFilevisiable = 'none';
            this.opts = {
                position: 'right',
                barBackground: '#4f4f4f',
                barBorderRadius: '0',
                barWidth: '4',
                gridWidth: '4',
                gridMargin: '1px 0'
            }
            this.updateproduct = {
                productId: 0,
                name: '',
                thc: '',
                cbd: '',
                desc: '',
                file: '',
                productname: '',
                productthc: '',
                productcbd: '',
                productdesc: '',
                productStatusType: '',
                productType: '',
                imageUrl: '',
                profileType: ''
            }

            this.updatenewproduct = {
                productId: 0,
                name: '',
                thc: '',
                cbd: '',
                desc: '',
                file: '',
                productname: '',
                productthc: '',
                productcbd: '',
                productdesc: '',
                productStatusType: '',
                productType: '',
                imageUrl: '',
                profileType: ''
            }

            //service to get the Lp ProductList
            this.recordBusiness.getProductList().subscribe(res => {
                this.productdata = res;
                this.tempProduct = this.productdata;
                if (this.productdata) {
                    this.dataService = this.completerService.local(this.productdata, 'Product_Name', 'Product_Name');
                }
            }, (err) => {
                console.log("recordBusiness getProductList erro " + err);
            });

            //service getting the setting detail for LpProduct add or update
            this.recordBusiness.getSettingDetail().subscribe(res => {
                this.status_Type = res.StockTypes;
                this.productType = res.ProductTypes;
                this.productProfiles = res.ProductProfiles;
                this.layoutComponent.showSpinner(false);
            }, (err) => {
                this.layoutComponent.showSpinner(false);
                console.log("recordBusiness getSettingDetail erro " + err);
            });

        } else {
            this.layoutComponent.showSpinner(false);
            this.router.navigate(['portal-login']);
        }
    }

    onSelectName(selected: CompleterItem) {
        if (selected) {
            let filterResults = this.tempProduct.filter((orderData: any) => {
                return (orderData.Product_Name == selected.originalObject.Product_Name);
            });
            this.productdata = filterResults;
        }
    }

    onChangeSearchText(event: any) {
        if (!event) {
            this.productdata = this.tempProduct;
        }
    }

    /** StrainName Validation Function */
    validateMaxStrainName(val: any) {
        if (val.trim() != "" || val != null) {
            if (val.length > 25) {
                UpdateProductComponent.prototype.maxStrainNameStyle = 'block'
            } else {
                UpdateProductComponent.prototype.maxStrainNameStyle = 'none'
            }
        }
    }

    emptyTextFunction(nameValue: string, newOroldProduct: string, fieldData: string) {
        if (newOroldProduct == "newProduct" && fieldData == "name") {
            nameValue.trim() == "" ? this.updateproduct.name = "" : '';
        } else if (newOroldProduct == "updateProduct" && fieldData == "name") {
            nameValue.trim() == "" ? this.updatenewproduct.name = "" : '';
        } else if (newOroldProduct == "newProduct" && fieldData == "thc") {
            nameValue.trim() == "" ? this.updateproduct.thc = "" : '';
        } else if (newOroldProduct == "updateProduct" && fieldData == "thc") {
            nameValue.trim() == "" ? this.updatenewproduct.thc = "" : '';
        } else if (newOroldProduct == "newProduct" && fieldData == "cbd") {
            nameValue.trim() == "" ? this.updateproduct.cbd = "" : '';
        } else if (newOroldProduct == "updateProduct" && fieldData == "cbd") {
            nameValue.trim() == "" ? this.updatenewproduct.cbd = "" : '';
        } else if (newOroldProduct == "newProduct" && fieldData == "desc") {
            nameValue.trim() == "" ? this.updateproduct.desc = "" : '';
        } else if (newOroldProduct == "updateProduct" && fieldData == "desc") {
            nameValue.trim() == "" ? this.updatenewproduct.desc = "" : '';
        }
    }
}