import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CannabisComponent } from './component/cannabis/cannabis.component';
import { RecordComponent } from './component/record.component';
import { LPRequestComponent } from "./component/licenserequest/lp-request.component";
import { UploadContentComponent } from './component/upload-content/uploadcontent.component';
import { UploadLpComponent } from './component/upload-content/upload-lp/uploadlp.component';
import { UpdateProductComponent } from './component/upload-content/update-product/updateproduct.component';
import { ChangePasswordComponent } from './component/upload-content/changepassword/changepassword.component';

const recordRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'documents',
        component: RecordComponent,
      },
      {
        path: 'request',
        component: LPRequestComponent,
      },
      {
        path: 'cannabis-log',
        component: CannabisComponent
      },
      {
        path: '',
        component: UploadContentComponent
      },
      {
        path: 'uploadlp',
        component: UploadLpComponent
      },
      {
        path: 'updateproduct',
        component: UpdateProductComponent
      },
      {
        path: 'changepassword',
        component: ChangePasswordComponent
      }
    ],
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(recordRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class RecordRoutingModule { }
