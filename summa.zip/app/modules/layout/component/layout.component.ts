import { Component, OnInit, ElementRef, Renderer, Input } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { TourService } from '../../../shared/tour/tour.service';
import { LogoutComponent } from "../../account/component/logout/logout.component";
import { SideMenuListEntity } from '../entity/side-menu.entity';
import { SharedObserverService } from "../../../shared/shared-service-module/shared-observer.service";
import { LayoutBusiness } from '../business/layout.business';
import { LayoutService } from '../service/layout.service';
import { Config } from '../../../config/constant';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { LoaderService } from '../../../shared/shared-loader/shared-loader.service';
import { LoginBusiness } from "../../account/component/business/login.business";

const patientList: SideMenuListEntity[] = [
  {
    id: 11,  //please do not change this id.
    menu_name: "Appointment",
    active_router: "null",
    tour_anchor: "appointment",
    router_link: '/clinics/notregistered',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-appt"

  },
  {
    id: 1,
    menu_name: "profile",
    active_router: "null",
    tour_anchor: "profile",
    router_link: '/profile',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-profile"

  },
  {
    id: 1,
    menu_name: "clinics",
    active_router: "null",
    tour_anchor: "clinic",
    router_link: '/clinics',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-clinic"

  },
  {
    id: 1,
    menu_name: "suppliers",
    active_router: "null",
    tour_anchor: "suppliers",
    router_link: '/suppliers',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },
  {
    id: 1,
    menu_name: "cannabis log",
    active_router: "null",
    tour_anchor: "cannabis",
    router_link: '/record/cannabis-log',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-cannabislog"

  },
  {
    id: 1,
    menu_name: "strain finder",
    active_router: "null",
    tour_anchor: "strain",
    router_link: '/strain-finder/strain',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-strainfinder"


  },
  {
    id: 1,
    menu_name: "info centre",
    active_router: "null",
    tour_anchor: "info",
    router_link: '/info-center',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-info"

  },
  {
    id: 1,
    menu_name: "documents",
    active_router: "null",
    tour_anchor: "documents",
    router_link: '/documents/documents',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-doc"

  }
]

const lpList: SideMenuListEntity[] = [
  {
    id: 1,
    menu_name: "Requests",
    active_router: "isActiveLink",
    tour_anchor: "Null",
    router_link: '/lp-request/request',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-lprequest"

  },
  {
    id: 1,
    menu_name: "clients",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/clients',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-lpclient"

  },
  {
    id: 1,
    menu_name: "update content",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/record',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-lpupcontent"

  },
  {
    id: 1,
    menu_name: "order tracking",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/ordertracking',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-lpordertracking"

  },
  {
    id: 1,
    menu_name: "info centre",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/info-center',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-info"

  }
]

const adminList: SideMenuListEntity[] = [
  {
    id: 1,
    menu_name: "Patients",
    active_router: "null",
    tour_anchor: "Null",
    router_link: '/clients',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-pateint"
  },
  {
    id: 1,
    menu_name: "clinics",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/clinics/admin',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-clinic"

  },
  {
    id: 1,
    menu_name: "suppliers",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/suppliers/supplier-admin',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },
  {
    id: 1,
    menu_name: "Admin Reports",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/Adminreport',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-admin_report"

  },
  {
    id: 31,
    menu_name: "Add / Tag",
    active_router: "SUPER ADMINS",
    tour_anchor: "null",
    router_link: '/addtag-superadmin',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-super_admin"
  },
  {
    id: 56,
    menu_name: "Form Builder",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  }
]

const clinicsList: SideMenuListEntity[] = [
  {
    id: 101,
    menu_name: "Schedule",
    active_router: "null",
    tour_anchor: "Null",
    router_link: '/clinics/schedule-clinic',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-pateint"
  },
  {
    id: 1,
    menu_name: "Patients",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/patient-clinics',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-clinic"

  },

  {
    id: 31,
    menu_name: "appointment",
    active_router: "Request",
    tour_anchor: "null",
    router_link: '/clinics/appointmentrequest',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },

  {
    id: 1,
    menu_name: "administration",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/clinicsadmin/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-admin_report"

  },
  {
    id: 1,
    menu_name: "suppliers",
    active_router: "SUPER ADMINS",
    tour_anchor: "null",
    router_link: '/suppliers/supplierlist',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-super_admin"
  },


  {
    id: 32,
    menu_name: "lp-request",
    active_router: "lprequest",
    tour_anchor: "null",
    router_link: '/profile/lp-request/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },

  {
    id: 1,
    menu_name: "status",
    active_router: "userstatus",
    tour_anchor: "null",
    router_link: '/profile/user-status/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  }
]
const doctorList: SideMenuListEntity[] = [
  {
    id: 101,
    menu_name: "Schedule",
    active_router: "null",
    tour_anchor: "Null",
    router_link: '/clinics/schedule-clinic',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-pateint"
  },
  {
    id: 1,
    menu_name: "Patients",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/patient-clinics',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-clinic"

  },
  {
    id: 31,
    menu_name: "appointment",
    active_router: "requests",
    tour_anchor: "null",
    router_link: '/clinics/appointmentrequest',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },
  {
    id: 1,
    menu_name: "administration",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/clinicsadmin/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-admin_report"

  },
  {
    id: 1,
    menu_name: "suppliers",
    active_router: "SUPER ADMINS",
    tour_anchor: "null",
    router_link: '/suppliers/supplierlist',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-super_admin"
  },
  {
    id: 1,
    menu_name: "lp requests",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/lp-request/',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  },
  {
    id: 1,
    menu_name: "status",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/user-status/',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  }
]
const educatorList: SideMenuListEntity[] = [
  {
    id: 101,
    menu_name: "Schedule",
    active_router: "null",
    tour_anchor: "Null",
    router_link: '/clinics/schedule-clinic',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-pateint"
  },
  {
    id: 1,
    menu_name: "Patients",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/patient-clinics',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-clinic"

  },
  {
    id: 31,
    menu_name: "appointment",
    active_router: "requests",
    tour_anchor: "null",
    router_link: '/clinics/appointmentrequest',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-supplier"

  },
  {
    id: 1,
    menu_name: "administration",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/clinicsadmin/',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-admin_report"

  },
  {
    id: 1,
    menu_name: "suppliers",
    active_router: "SUPER ADMINS",
    tour_anchor: "null",
    router_link: '/suppliers/supplierlist',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-super_admin"
  },
  {
    id: 1,
    menu_name: "lp requests",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/lp-request/',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  },
  {
    id: 1,
    menu_name: "info center",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/info-center',
    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  },
  {
    id: 1,
    menu_name: "status",
    active_router: "null",
    tour_anchor: "null",
    router_link: '/profile/user-status/',

    router_active_link: "active-route",
    routerLinkActiveOptions: true,
    menu_icon: "menu-icon-form_builder"

  }
]
@Component({
  selector: 'app-dashboard',
  templateUrl: './layout.component.html',
  providers: [LayoutBusiness,LayoutService,Config,HttpRequestService],
  styleUrls: ['./layout.component.scss'],

  host: {
    '(window:resize)': 'onResize($event)'
  }
})

export class LayoutComponent implements OnInit {

  public isopen: boolean = false;
  public tourEnabled: boolean = false;
  private tourInit: boolean = false;
  private tourShowing: boolean = false;
  public appTourStepId: number = 0;
  public activeURL: string;
  public ValidCurrentUser: string;
  public MenuList: any;
  public showLoader: boolean = false;
  private siteImageUrl: string;
  private isImageAvail: boolean = true;
  userCurrentRating: any;
  public clinics: any = [];

  private startInterview() {
    this.tourInit = false;
    this.tourService.start();
  }

  private skipInterview() {
    this.tourInit = false;
    this.tourEnabled = false;
    if (this.isopen) { this.isopen = false; }
  }

  constructor(private el: ElementRef,
    private _lb: LayoutBusiness,
    private renderer: Renderer,
    private _sos: SharedObserverService,
    public tourService: TourService, private router: Router, private loaderService: LoaderService, private _loginbusiness: LoginBusiness) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    var currentUser = localStorage.getItem('currentUser');
    this.loaderService.display(true);
    this.tourService = tourService;
    //this.routerCheckforShowingTour(this.router.url);
    this.router.events.subscribe(event => {
      // if (event instanceof NavigationStart) { 
      //    this.routerCheckforShowingTour(event.url);
      // } 
      if (event instanceof NavigationEnd) {
        this.activeURL = event.url;

        /** during this active url  "/clinics/viewappointments" and "/clinics/notregistered" button tile are not active inside the pages during click (Appointment) button,
         * this is fix for that dont remove this code
        */
      
        /** End */
      }
    });

    this.tourService.currentSteps_Broadcase.subscribe(
      value => {
        this.appTourStepId = parseInt(value.stepId);
        if (window.screen.width <= 991 && 0 < parseInt(value.stepId) && parseInt(value.stepId) < 9) {
          this.isopen = true;
          this.tourShowing = true;
        } else {
          this.isopen = false;
          this.tourShowing = false;
        }
      }
    );
    this.tourService.previousCallback.subscribe(value => {
      if (value) {
        this.tourEnabled = false;
      }
    });
    this.tourService.nextCallback.subscribe(value => {
      if (value) {
        this.tourEnabled = false;
      }
    });
    this.loaderService.display(false);

    this.tourService.initialize([
      {
        anchorId: 'appointment',
        content: 'Request you appointment with your clinic using our automated scheduling system directly linked directly to the clinic, you can also view your upcoming appointment or join your upcoming video conference appointment with your Health Care practitioner from here, if you have not already registered with any clinic,click here to go to Explore Clinics.',
        title: 'Appointment:',

        stepId: '1',
        placement: 'right'
      }, {
        anchorId: 'profile',
        content: 'change your information at any time including your contact information and preferred email address so you can stay up-to-date on your account. Manage your shipping address to ensure secure delivery of your future order.',
        title: 'Profile:',
        stepId: '2',
        placement: 'right'
      }, {
        anchorId: 'clinic',
        content: 'Search through a list of Cannabis knowledgeable clinics and education centers to get you started on your journey with medical cannabis. simply find clinic that meets your needs and click to request a new consultation, request appointment directly and manage your bookings with your clinic. it’s that easy!',
        title: 'Clinic:',
        stepId: '3',
        placement: 'right'
      }, {
        anchorId: 'suppliers',
        content: 'Navigate through our extensive list of available strains all from tested, approved and regulated suppliers, Find the right strain based on THC/CBD,form,price,reviews and other factors, add strains to your favorite lists to follow them later, or find the producers that carry that strain and register directly with them in minutes, you can also add your strains to your treatment plan to track the effects of your strains on your condition, Don’t know what strain to pick? Use our Strain Finder!',
        title: 'Suppliers:',
        stepId: '4',
        placement: 'right'
      }, {
        anchorId: 'cannabis',
        content: 'Update your cannabis log created by your clinic or a new treatment plain in minutes. Simply select the type of conditions you want to track your cannabis use for, enter your strains or pick from a list of your favorite strains, your preferred method of administration and how often you want a reminder to complete, that’s it! You can tack your strains effects on your condition and understand what strain has the best effect. and best of all, you can easily communicate this to your physician and find the producers that carry your preferred strain types. Take control of your cannabis use!',
        title: 'CANNABIS LOG:',
        stepId: '5',
        placement: 'right'
      }, {
        anchorId: 'strain',
        content: 'Navigate through our extensive list of available strains all from tested, approved and regulated suppliers, Find the right strain based on THC/CBD,form,price,reviews and other factors, add strains to your favorite lists to follow them later, or find the producers that carry that strain and register directly with them in minutes, you can also add your strains to your treatment plan to track the effects of your strains on your condition, Don’t know what strain to pick? Use our Strain Finder!',
        title: 'Strain Finder:',
        stepId: '6',
        placement: 'right'
      }, {
        anchorId: 'info',
        content: 'Find the latest information specific to your health needs. Search health and medical articles by condition type or based on the latest date. Save articles to your clipboard to share with your healthcare practitioner or other member to inform, educate and learn the effects of cannabis on health outcomes, Sign up to our weekly newsletter to receive top stories and articles curated to your specific needs.',
        title: 'Info Centre:',
        stepId: '7',
        placement: 'right'
      }, {
        anchorId: 'documents',
        content: 'Upload documents into our HIPAA Compliant and secure storage servers only accessible by you or the clinics you provide authorization to. Be in control of your documentation and never go without your documents again the next time you meet a healthcare provider. Access your latest prescription information,digital medical card and forms requested by your clinic to complete for your upcoming visits.',
        title: 'Documents:',
        stepId: '8',
        placement: 'right'
      }, {
        anchorId: 'dashboard',
        content: 'An easy view into all areas of your account. View upcoming appointments, track your medical documents expiry,create or update your treatment plan, view open tasks by your clinic,search relevant articles, view your favorites lists and promotions from suppliers all in one easy to view dashboard!',
        title: 'Dashboard:',
        stepId: '9',
      }, {
        anchorId: 'notification',
        content: 'View any messages sent to you via email.To keep your privacy top of mind, emails will never disclose the message. It will simply ask you to login to readmore. Click on Notifications at any time when you receive an email to see the details of that message. Your privacy is our number one priority!',
        title: 'Notifications:',
        stepId: '10',
      }, {
        anchorId: 'support',
        content: 'Have a question or unsure about how to complete a step? View our support page for a list of tutorials, how-to content, frequently asked questions and other helpful information. Please note that Sail is only a technology platform. For any health or medical related questions, please contact your clinic directly.',
        title: 'Support:',
        stepId: '11',
      }, {
        anchorId: 'final',
        content: 'THAT’S IT! YOU’RE READY',
        stepId: '12',
        placement: 'right'
      }]);
  }


  // To open side menu when resizeing screen  
  public onResize(event: any) {
    if (this.tourService.isTourOn() && event.target.innerWidth <= 991 && 0 < this.appTourStepId && this.appTourStepId < 9) {
      this.isopen = true;
    } else {
      this.isopen = false;
    }
  }
  /**   
   * toggled function - to open/close the left side menu in mobile and tab view
   */
  public toggled(): void {
    if (!this.tourService.isTourOn()) {
      this.isopen = !this.isopen;
    }
  }

  public routerCheckforShowingTour(url: string) {
    if (url == '/dashboard') {
      this.tourInit = true;
    } else {
      this.tourInit = false;
    }
  }
  ngOnInit(): void {
    this.userCurrentRating = localStorage.getItem('userRatingValue');
    if (localStorage.getItem('token')) {
      this.loaderService.display(true);
      this.getMasterInfo();
      this.loaderService.display(false);
      var currentUser = localStorage.getItem('currentUser');


      if (currentUser == "PatientUser") {

        this.ValidCurrentUser = currentUser;
      } else if (currentUser == "LpUser") {
        this.MenuList = lpList;
        this.ValidCurrentUser = currentUser;
      } else if (currentUser == "AdminUser") {
        this.MenuList = adminList;
        this.ValidCurrentUser = currentUser;
      } else if (currentUser == "ClinicsUser") {
        this.MenuList = clinicsList;
        this.ValidCurrentUser = currentUser;
      } else if (currentUser == "DoctorUser") {
        this.MenuList = doctorList;
        this.ValidCurrentUser = currentUser;
      } else if (currentUser == "EducatorUser") {
        this.MenuList = educatorList;
        this.ValidCurrentUser = currentUser;
      }
      else {
        this.router.navigate(['dashboard']);
      }
      this.getProfileInfo();

    } else {
      this.router.navigate(['portal-login']);
    }
  }
  onSupport() {
    this.router.navigate(['support']);
  }

  onBeginTour() {
    this.tourInit = true;
    this.tourEnabled = true;
  }

  getMasterInfo() {
    this._lb.getMasterInfoDetail().subscribe(res => {
      this._sos.sendEventToSubscriber(res);
    });
  }

  getProfileInfo() {
    this._lb.getUserInfo().subscribe(res => {
      if (this.ValidCurrentUser == "PatientUser") {
        let id = res.Patient_Login_Data.Patient_Provider_Relation.ObjProvider.Clinic_Id;
        if (id > 0) {
          patientList[0].router_link = "/clinics/viewappointments";
          this.MenuList = patientList;
        } else {
          patientList[0].router_link = "/clinics/notregistered";
          this.MenuList = patientList;
        }
      }
      if (res.LP_Login_Data) {
        this.isImageAvail = false;
      } else if (res.Provider_Login_Data) {
        this.isImageAvail = false;
      } else if (res.Clinic_Login_Data) {
        this.isImageAvail = false;
      }

      this._sos.sendProfileInfoToSubsciber(res);

      if (this.ValidCurrentUser == "DoctorUser" || this.ValidCurrentUser == "EducatorUser") {
        this.clinics = res.Provider_Login_Data.ProviderClinicRelations;
      }
      else if (this.ValidCurrentUser == "PatientUser") {
        let param = {
          id: res.Patient_Login_Data.Patient_Provider_Relation.ParentClinic_ID,
          url: window.location.origin
        };
        this._loginbusiness.getSiteLogo(param).subscribe(res => {
          if (res.Logo_Url == null) {
            this.isImageAvail = false;
            return;
          }

          this.isImageAvail = true;
          this.siteImageUrl = res.Logo_Url;
        });
      }
    });
  }

  clinicChange(clinicValues: any) {
    localStorage.setItem('ClinicId', clinicValues.Clinic_ID);
    console.log(clinicValues);

  }

  showSpinner(boolVlaue: boolean) {
    this.loaderService.display(boolVlaue);
  }

  beginInterview() {
    this.onBeginTour();
  }

  /** this method call during create appointment booking, ths can set   /clinics/viewappointments or /clinics/notregistered this url in Appointment routing url*/
  changeUrl() {
    this._lb.getUserInfo().subscribe(res => {
      let id = res.Patient_Login_Data.Patient_Provider_Relation.ObjProvider.Clinic_Id;
      if (id > 0) {
        patientList[0].router_link = "/clinics/viewappointments";
        this.MenuList = patientList;
      } else {
        patientList[0].router_link = "/clinics/notregistered";
        this.MenuList = patientList;
        this.router.navigate(['/clinics/notregistered']);
      }
    }, (err) => {
      console.log("getUserInfo viewappointments", err);
    });
  }
}