import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, ElementRef, EventEmitter } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { SideMenuListEntity } from '../entity/side-menu.entity';

@Component({
    selector: 'sidemenu-list',
    templateUrl: './side-menu.component.html',
    styleUrls: ['./layout.component.scss']
})

export class SideMenuListComponent {

    @Input() SideMenulists: SideMenuListEntity[];
    @Output() onMenuClick = new EventEmitter();


    public ValidCurrentUser: string;
    private isActiveExactTrue: boolean = false;
    private currentUser: string = "";
    private isAppoinmentExactTrue: boolean = false;
    private tileActiveColor: any = "#27ab6f";
    private tileSpanActiveColor: any = "#73c9a2";

    constructor(overlay: Overlay, vcRef: ViewContainerRef, private router: Router, public modal: Modal, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
        this.currentUser = localStorage.getItem('currentUser');
         /** during this active url  "/clinics/viewappointments" and "/clinics/notregistered" button tile are not active inside the pages during click (Appointment) button,
         * this is fix for that dont remove this code
        */
        if (this.currentUser == "PatientUser") {
            this.router.events.subscribe(event => {
                if (event instanceof NavigationEnd) {
                    var bookAppintmentClinicId = event.url.split('/')[3];
                    if (event.url == "/clinics/notregistered" || event.url == "/clinics/viewappointments") {
                        this.isActiveExactTrue = true
                        this.isAppoinmentExactTrue = false
                    } else if (event.url == "/clinics/appointment/" + bookAppintmentClinicId) {
                        this.isActiveExactTrue = false;
                        this.isAppoinmentExactTrue = true
                    } else {
                        this.isAppoinmentExactTrue = false
                        this.isActiveExactTrue = false;
                    }
                }
            });
        }
        /** End */

    }

    ngOnInit(): void {
        var currentUser = localStorage.getItem('currentUser');
        if (currentUser == "PatientUser") {
            this.ValidCurrentUser = currentUser;
        } else if (currentUser == "LpUser") {
            this.ValidCurrentUser = currentUser;
        } else if (currentUser == "AdminUser") {
            this.ValidCurrentUser = currentUser;
        } else if (currentUser == "ClinicsUser") {
            this.ValidCurrentUser = currentUser;
        } else if (currentUser == "DoctorUser") {
            this.ValidCurrentUser = currentUser;
        } else if (currentUser == "EducatorUser") {
            this.ValidCurrentUser = currentUser;
        } else {
            this.router.navigate(['dashboard']);
        }
    }
    public toggled(event: Event): void {
        this.onMenuClick.emit(event);
    }

    loadData(params:any){
        if(params == 101){
             //setTimeout(function(){ location.reload();  }, 500);           
        }
    }
   


}