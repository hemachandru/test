
export interface SideMenuListEntity {
    id: number;
    active_router: string,
    tour_anchor:string,
    router_link:string,
    router_active_link:string,
    menu_name: string,
    routerLinkActiveOptions:boolean,
    menu_icon: string
}