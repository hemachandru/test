import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Config } from '../../../config/constant';
import { LayoutService } from '../service/layout.service';


@Injectable()
export class LayoutBusiness {

  constructor(private layoutService: LayoutService, private config: Config) {
  }

  //service return full master detail
  getMasterInfoDetail() {
    return this.layoutService.getMasterInfoDetail(this.config.getMasterData).map(res => res.json());
  }

  getUserInfo() {
    let url = this.config.userdetailUrl;
    return this.layoutService.getUserInfo(url).map(res => res.json());
  }

}