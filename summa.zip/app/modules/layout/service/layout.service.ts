import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';

@Injectable()
export class LayoutService {
  constructor(private httpRequestService: HttpRequestService) {
  }
  
  //service return full master detail
  getMasterInfoDetail(url:string){
    return this.httpRequestService.getHttpRequest(url);
  }

  getUserInfo(url: string) {
      return this.httpRequestService.getHttpRequest(url);
  }
}