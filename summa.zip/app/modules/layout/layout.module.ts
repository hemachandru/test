import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlimScrollModule } from 'ng2-slimscroll';
import { FormsModule } from '@angular/forms';
import { NgPipesModule } from 'ng-pipes';
import { Routes, RouterModule } from '@angular/router';
import { TourNgBootstrapModule} from '../../shared/tour/plugin/ng-bootstrap/ng-bootstrap.module';
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";
import { LayoutComponent } from './component/layout.component';
import { LogoutComponent } from "../account/component/logout/logout.component";
import { StarRatingComponent } from "../account/component/logout/rating/rating";
import { SideMenuListComponent } from "./component/side-menu.component";
import { DateFormatter } from '../../shared/shared-pipe/date-formatter';
import { LoaderService } from '../../shared/shared-loader/shared-loader.service';
import { Dashboardbusiness } from '../dashboard/business/dashboard.business';
import { DashboardService } from '../dashboard/service/dashboard.service';
import { LayoutBusiness } from './business/layout.business';
import { Config } from '../../config/constant';
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { LayoutService } from './service/layout.service';
import { LoginBusiness } from "../account/component/business/login.business";

@NgModule({
  imports: [
    CommonModule,
    RouterModule, 
    FormsModule,
    SharedServiceModule.forRoot(),
    TourNgBootstrapModule.forRoot()
  ],
  declarations: [
    LayoutComponent,
    LogoutComponent,
    SideMenuListComponent,
    StarRatingComponent
  ],
  providers: [
    Dashboardbusiness,
    LoaderService,
    DashboardService,
    LayoutBusiness,
    LoginBusiness,
    Config,
    HttpRequestService,
    LayoutService
  ],
  exports: [ ]
})
export class LayoutModule {}