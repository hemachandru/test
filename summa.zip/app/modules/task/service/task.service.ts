import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';

import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { Config } from '../../../config/constant';

@Injectable()
export class TaskService {

    constructor(private _hrs: HttpRequestService, private config: Config) {

    }

    /**
     * Get task list
     * @param url API end point
     */
    getMyTaskList (url: string) {
        return this._hrs.getHttpRequest(url);
    }

    addOrUpdateTask(url: string, params: any) {
        return this._hrs.postHttpRequest(params, url);
    }
    completedTask(url: string, params: any) {
        return this._hrs.postHttpRequest(params, url);
    }
}