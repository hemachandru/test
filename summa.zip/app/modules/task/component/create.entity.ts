export interface Create {
    description: string; 
}