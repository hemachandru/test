import { Observable } from 'rxjs/Observable';
import { Component, OnInit, ViewContainerRef, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { TaskBusiness } from '../business/task.business';
import { LoaderService } from "../../../shared/shared-loader/shared-loader.service";

import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur, IMyDate } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';

export class TaskEntity {
  id: number;
  title: string;
  desc: string;
  taskDate: Date;
}

@Component({
  selector: "my-task",
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.scss'],
  providers: [DatePipe]
})
export class TaskComponent implements OnInit {
  dialog: DialogRef<any>;
  taskList: TaskEntity[];
  isTaskItemChecked: boolean = true;
  selectedTask: any = [];
  private editTask: any;
  isReadOnly: boolean = false;
  private isEmpty: boolean = false;

  public date = new Date();
  public invalidDob: any;
  private modelDate: IMyDate = { year: 0, month: 0, day: 0 };
  private myDatePickerNormalOptions: IMyOptions = {
    dateFormat: 'mm/dd/yyyy',
    todayBtnTxt: 'Today',
    firstDayOfWeek: 'mo',
    showClearDateBtn: false,
    indicateInvalidDate: true,
    minYear: 1900,
    maxYear: this.date.getUTCFullYear(),
    editableDateField: false,
  };

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;

  constructor(public datepipe: DatePipe, private _tb: TaskBusiness, private _ls: LoaderService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
    //this.taskList = this.ts.getTaskList();
    this.taskList = [];
  }

  ngOnInit() {
    this.editTask = {
      desc: '',
      title: ''
    }
  }

  onDateChanged(event: IMyDateModel) {
    TaskComponent.prototype.invalidDob = 'hidden';
    this.modelDate = event.date;
  }

  onEditTask(evt: any, value: object) {
    if (evt.target.checked) {
      this.selectedTask.push(value);
      this.selectedTask = this.selectedTask.filter((v: any, i: number, a: any) => a.indexOf(v) === i)
    }

    if (!evt.target.checked) {
      this.selectedTask.splice(this.selectedTask.indexOf(value), 1);
    }

    this.isTaskItemChecked = (this.selectedTask.length > 0) ? false : true;

  }

  onCompleteTask() {
    if (this.selectedTask.length === 0) {
      return false;
    }

    let postData = "";
    for (let entry of this.selectedTask) {
      if (postData) {
        postData = postData + "," + entry.id;
      } else {
        postData = postData + entry.id;
      }
    }

    let param = {
      id: postData
    }

    this._ls.display(true);
    this._tb.completedTask(param).subscribe(res => {
      this._ls.display(false);
      this.selectedTask = [];
      if (this.dialog) {
        this.close();
      }
      this.isTaskItemChecked = true;
      this.loadTaskList();
    })
  }
  loadTaskList() {
    this._ls.display(true);
    this._tb.getMyTaskList().subscribe(res => {
      this._ls.display(false);
      if (res.length === 0) {
        this.taskList = [];
        this.isEmpty = true;
        return false;
      }
      this.isEmpty = false;
      this.taskList = res;
    })
  }
  onAddOrUpdateTask(val: any, isAdd: boolean, isCompleted: boolean) {
    if (val.title.trim() != "" && val.desc.trim() != "") {
      !isAdd ? val.date = this.modelDate : '';
      this._tb.addOrUpdateTask(val, isAdd, isCompleted).subscribe(res => {
        if (res) {
          if (this.dialog) {
            this.close();
            this.editTask = {
              desc: '',
              title: '',
              id: 0
            }
          }
          this.loadTaskList();
        }
      });
    }
  }

  updateTaskList(evt: any) {
    console.log(evt);
  }

  onViewTask(value: any) {
    this.selectedTask = [];
    this.isTaskItemChecked = true;
    this.selectedTask.push(value);
    this.editTask.id = value.id
    this.editTask.desc = value.desc;
    this.editTask.title = value.title;
    let tempDate = new Date(value.taskDate);
    let latest_date = this.datepipe.transform(tempDate, 'yyyy-MM-dd');
    let tempArray = latest_date.toString().split('-');
    this.modelDate = { year: Number(tempArray[0]), month: Number(tempArray[1]), day: Number(tempArray[2]) };
    this.editTask.taskDate = this.modelDate
    this.modal.open(this.templateRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-task' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
      })
  }

  close() {
    this.dialog.close();
  }

  onEditComplete() {
    this.close();
  }

  onEditTextbox(evt: any) {
    evt.target.readOnly = false;
    this.isReadOnly = true;
  }

  onBlur(evt: any) {
    evt.target.readOnly = true;
    this.isReadOnly = false;
  }
}