import { Component, ViewContainerRef, ViewChild, TemplateRef, OnInit, Input, Output, EventEmitter, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Overlay, overlayConfigFactory, CloseGuard, DialogRef } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur, IMyDate } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';

//import { Create } from './create.entity';

@Component({
  selector: 'create-task',
  //template: `<button (click)="onClick()">Alert</button>`
  templateUrl: './create-task.component.html',
  styleUrls: ['./create-task.component.scss']
})

export class CreateTaskComponent implements OnInit {

  public date = new Date();
  public invalidDob: any;

  dialog: DialogRef<any>;
  description: string;
  task: object = {};
  isReadOnly: boolean = false;
  private modelDate: IMyDate = {
    year: this.date.getFullYear(),
    month: this.date.getMonth() + 1,
    day: this.date.getDate()
  };
  private myDatePickerNormalOptions: IMyOptions = {
    dateFormat: 'mm/dd/yyyy',
    todayBtnTxt: 'Today',
    firstDayOfWeek: 'mo',
    showClearDateBtn: false,
    indicateInvalidDate: true,
    minYear: 1900,
    maxYear: this.date.getUTCFullYear(),
    editableDateField: false,
  };

  @Output() onTaskCreated = new EventEmitter();

  @ViewChild('templateRef') public templateRef: TemplateRef<any>;

  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    this.task = {
      desc: '',
      title: ''
    }
    // this.create = {
    //   description: ''
    // }
  }


  onDateChanged(event: IMyDateModel) {
    CreateTaskComponent.prototype.invalidDob = 'hidden';
    this.modelDate = event.date;
  }

  /**
   * Generic function to show additional information while clicking icon
   * 
   * @param {Number} id in which info need to show while clicking 
   */
  onClick(event: Event) {
    this.modelDate = {
      year: this.date.getFullYear(),
      month: this.date.getMonth() + 1,
      day: this.date.getDate()
    };
    event.stopPropagation();
    event.preventDefault();
    this.modal.open(this.templateRef, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-task' }, BSModalContext))
      .then(dialog => {
        this.dialog = dialog;
        //this.close();
      })

  }
  close() {
    this.dialog.close();
  }

  // onTest() {
  //   alert('test click');
  // }

  onSave(task: any) {
    if (task.title != "" && task.desc != "") {
      this.close();
      task.date = this.modelDate;
      this.onTaskCreated.emit(this.task);
      this.task = {};
    }
  }

  onEditTextbox(evt: any) {
    evt.target.readOnly = false;
    this.isReadOnly = true;
  }

  onBlur(evt: any) {
    evt.target.readOnly = true;
    this.isReadOnly = false;
  }
}