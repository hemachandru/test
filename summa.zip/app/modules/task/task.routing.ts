import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {TaskComponent} from './component/task.component';

const recordRoutes: Routes = [
  { path: '',  component: TaskComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(recordRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class TaskRoutingModule { }
