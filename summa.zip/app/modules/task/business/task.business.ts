import { Injectable, Component } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { TaskService } from '../service/task.service';
import { Config } from '../../../config/constant';

@Injectable()
export class TaskBusiness {
    constructor(private _hrs: HttpRequestService, private _ts: TaskService, private config: Config) {

    }

    /**
     * Get task list
     * 
     * @return Observerable
     */
    getMyTaskList() {
        let url = this.config.GetTasks + localStorage.getItem('userRole') + '/' + localStorage.getItem('mvcUserId');
        return this._ts.getMyTaskList(url).map((response) => {
            let res = response.json();
            let taskList = [];
            for (let i = 0; i < res.length; i++) {
                taskList.push({
                    id: res[i].Id,
                    title: res[i].Title,
                    desc: res[i].Description,
                    taskDate : res[i].TaskDate
                })
            }
            return taskList;
        });
    }

    addOrUpdateTask(data: any, isAdd: boolean, isCompleted: boolean) {
        //dd/mm/yyy
        var selectedTaskDate = data.date.month +'/'+ data.date.day +'/'+ data.date.year;
        console.log('Task date : ',selectedTaskDate);

        let params = {
            Id: isAdd ? null : data.id,
            MvcUserId: localStorage.getItem('mvcUserId'),
            Role: localStorage.getItem('userRole'),
            Title: data.title,
            Description: data.desc,
            IsCompleted: isCompleted ? true : false,
            TaskDate: selectedTaskDate
        }
        let url = this.config.AddOrUpdateTask;
        return this._ts.addOrUpdateTask(url, params).map(response => response.json());
    }

    completedTask(data: any) {
        let params = {
            Id: data.id,
            MvcUserId: localStorage.getItem('mvcUserId'),
            Role: localStorage.getItem('userRole')
        }
        let url = this.config.CompleteTask;
        return this._ts.completedTask(url, params).map(res => res.json());
    }
}