import { NgModule }       from '@angular/core';
import { CommonModule }       from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TaskComponent } from './component/task.component';
import { CreateTaskComponent } from './component/create-task.component';
import { TaskService } from "./service/task.service";
import { TaskBusiness } from "./business/task.business";
import { HttpRequestService } from '../../shared/shared-service/http-request.service';
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";
import { MyDatePickerModule } from 'mydatepicker';
@NgModule({
  imports: [
    // TaskRoutingModule
    CommonModule,
    FormsModule,
    SharedServiceModule,
    MyDatePickerModule
  ],
  declarations: [
    TaskComponent,
    CreateTaskComponent
  ],
  providers: [ TaskService, TaskBusiness, HttpRequestService ],
  exports: [TaskComponent]
})
export class TaskModule {}