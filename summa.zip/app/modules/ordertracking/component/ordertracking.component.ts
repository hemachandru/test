import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Location } from '@angular/common';

import { OrderTrackingBusiness } from '../business/ordertracking.business';
import { OrderTrackingService } from '../service/ordertracking.service';
import { Config } from '../../../config/constant';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { LoginBusiness } from '../../account/component/business/login.business';
import { LoginService } from '../../account/component/service/login.service';
import { LayoutComponent } from "../../layout/component/layout.component";

@Component({
	templateUrl: './ordertracking.component.html',
	styleUrls: ['./ordertracking.component.scss'],
	providers: [OrderTrackingBusiness, OrderTrackingService, HttpRequestService, Config, LoginBusiness, LoginService]
})

export class OrderTrackingComponent implements OnInit {
	public orderdata: any;
	public opts: ISlimScrollOptions;
	public searchStr: string;
	protected dataService: CompleterData;
	public clearSearchInput: boolean = false;
	public tempFilter: any;
	public duplicateRemovedData: any;
	public ValidCurrentUser: string;
	private localPatientId: number = 0;

	constructor(private _location: Location, private layoutComponent: LayoutComponent, private completerService: CompleterService, private config: Config, private loginBusiness: LoginBusiness, private router: Router, private orderTrackingBusiness: OrderTrackingBusiness, private orderTrackingService: OrderTrackingService, private httpRequestService: HttpRequestService,private route: ActivatedRoute ) { }
	ngOnInit() {
		this.ValidCurrentUser = localStorage.getItem('currentUser');

		this.route.params.subscribe((params: Params) => {
			if(params['id']) {
				this.localPatientId = parseInt(params['id']);
			}
			else
				this.localPatientId = 0;
			});	

		this.initService();
	}
	onlineTracking(requestCode: number, isAutoSuggest: boolean, patientName: string, patientId:number ,lpId:number) {
		// this service fetch the client order TpatientIdacking detail from Database
		this.layoutComponent.showSpinner(true);
		this.orderTrackingBusiness.getOrderTrackingDetailsList(requestCode, isAutoSuggest, patientName,patientId,lpId).subscribe(response => {
			this.orderdata = response;
			this.tempFilter = this.orderdata;
			if (this.orderdata) {
				this.duplicateRemovedData = new Array();
				for (let i = 0; i < this.orderdata.length; i++) {
					let filterResult = this.duplicateRemovedData.filter((uniqueData: any) => {
						return this.orderdata[i].Patient_Id == uniqueData.Patient_Id;
					});
					filterResult.length == 0 ? this.duplicateRemovedData.push(this.orderdata[i]) : '';
				}
				this.orderdata ? this.dataService = this.completerService.local(this.duplicateRemovedData, 'Patient_First_Name,Patient_Last_Name', 'Patient_First_Name,Patient_Last_Name'):"";
				this.layoutComponent.showSpinner(false);
			} else {
				this.layoutComponent.showSpinner(false);
			}
		}, (err) => {
			console.log("OrderTrackingComponent orderTrackingBusiness.getOrderTrackingDetailsList error: ", err);
		});
	}
	onBack() {
		if (this.localPatientId == 0) {
            this._location.back();
        } else {
            this.router.navigate(['profile/patient-view/' + this.localPatientId]);
        }
	}
	initService() {
		if (localStorage.getItem('token')) {
			this.orderdata = [];
			this.searchStr = '';
			this.opts = {
                position: 'right',
				barBackground: '#4f4f4f',
				barBorderRadius: '0',
				barWidth: '4',
				gridWidth: '4',
				gridMargin: '1px 0'
			}
			switch(localStorage.getItem('userRole')) { 
				case 'Clinics': {
					this.onlineTracking(1, false, '',this.localPatientId,0);
					break; 
				} 
				case 'LicenseProducers': { 
					this.onlineTracking(2, false, '',0,Number(localStorage.getItem("mvcUserId")));
					break; 
				} 
				default: { 
				break; 
				} 
			}

		} else {
		 	this.layoutComponent.showSpinner(false);
			this.router.navigate(['portal-login']);
		}
	}

	onSelectName(selected: CompleterItem) {
		if (selected) {
			let filterResult = this.tempFilter.filter((orderData: any) => {
				return (orderData.Patient_First_Name == selected.originalObject.Patient_First_Name) && (orderData.Patient_Last_Name == selected.originalObject.Patient_Last_Name);
			});
			this.orderdata = filterResult;
		}
	}

	onChangeSearchText(event: any) {
		if (!event) {
			this.orderdata = this.tempFilter;
		}
	}
}