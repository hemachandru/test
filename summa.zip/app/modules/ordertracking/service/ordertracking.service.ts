import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { Config } from '../../../config/constant';
@Injectable()
export class OrderTrackingService {
  constructor(private httpRequestService :HttpRequestService, private config :Config){

  }
  //return the order Tracking details
  getOrderTrackingDetailsList(data:string, url:string){
    return this.httpRequestService.postHttpRequest(data,url);
  }
}