import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { ReplaySubject } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/shared-service/http-request.service';
import { Config } from '../../../config/constant';
import { OrderTrackingService } from '../service/ordertracking.service';
@Injectable()
export class OrderTrackingBusiness {
  constructor(private httpRequestService :HttpRequestService, private config :Config, private orderTrackingService: OrderTrackingService){

  }
  
  //return the order Tracking details
  getOrderTrackingDetailsList(requestCode :number, isAutoSuggest :boolean, patientName :string,patientId:number,lpId:number){
       var reqParam={
        "Request_Code" : requestCode,
        "Patient_Id"  :patientId,
        "LP_Id" :lpId,
        "Medical_Doc_Id" :0,
        "Patient_Name":patientName,
        "IsAutoSuggest" : isAutoSuggest
       }
       return this.orderTrackingService.getOrderTrackingDetailsList(JSON.stringify(reqParam),this.config.getLpOrdersUrl).map(response =>response.json());
       
  }
}