import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import {OrderTrackingComponent} from './component/ordertracking.component';
import { PipeModule } from '../../shared/shared-pipe/pipe.module';

const ordertrackingRoutes: Routes = [
  { path: '',  component: OrderTrackingComponent },
  {
		path: 'ordertracking/:id',
		component: OrderTrackingComponent
	},
];

@NgModule({
  imports: [
    RouterModule.forChild(ordertrackingRoutes),
    PipeModule
  ],
  exports: [
    RouterModule
  ]
})
export class OrderTrackingRoutingModule { }
