import { NgModule }       from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { OrderTrackingComponent } from './component/ordertracking.component';
import { OrderTrackingRoutingModule } from './ordertracking.routing';
import { SlimScrollModule } from 'ng2-slimscroll';
import { PipeModule } from '../../shared/shared-pipe/pipe.module';
import { Ng2CompleterModule } from "ng2-completer"

@NgModule({
  imports: [
    OrderTrackingRoutingModule,
    CommonModule,
    SlimScrollModule,
    PipeModule,
    Ng2CompleterModule,
    FormsModule
  ],
  declarations: [
    OrderTrackingComponent
  ],
  providers: []
})
export class OrderTrackingModule {}