import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { PageScrollInstance, PageScrollService, EasingLogic } from 'ng2-page-scroll';

@Component({
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent implements OnInit {
  public dynamicTargets = ['theanchor1', 'theanchor2', 'theanchor3'];
  public dynamicSelectedTarget1 = this.dynamicTargets[0];
  public dynamicSelectedTarget2 = this.dynamicTargets[1];
  public dynamicSelectedTarget3 = this.dynamicTargets[2];
  constructor(private router: Router) { }

  ngOnInit() { }

  onBack() {
    this.router.navigate(['dashboard']);
  }

}