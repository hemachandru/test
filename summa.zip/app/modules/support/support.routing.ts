import { Route } from '@angular/router';

import { SupportComponent } from './component/support.component';

export const SupportRoutes: Route[] = [
	{
		path: '',
		component: SupportComponent
	}
];