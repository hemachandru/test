export interface ReviewProductEntity {
   log_ID :number,
   patient_ID :number,
   product_ID :string,
   conditions :string,
   intake :string,
   positive_Effects :{},
   positive_Comments :string,
   negative_Effects :{},
   negative_Comments :string,
   effectiveness :number,
   side_Effects:number
}