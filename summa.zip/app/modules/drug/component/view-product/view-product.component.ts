import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { ReviewProductEntity } from '../../entity/reviewProduct.entity';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

const buttonLogout = [
  {
    "id": 1,
    "buttonName": "LOG OUT"
  }
];

const buttonNext = [
  {
    "id": 1,
    "buttonName": "NEXT"
  }
];

@Component({
  selector: 'app-viewProduct',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})

export class ViewProductComponent { 
  public btnData = buttonLogout;
  public btnNextData = buttonNext;
  public inTakeModes: any = [];
  //router
  public isGuest: boolean = false;
  private temp: any;
  private userType: any;
  private infoAlert: boolean = false;
  private selectedCondition: string = "";
  private previousSelctedValue: number = -1;
  public reviewProductEntity: ReviewProductEntity;
  public spinnerShow: boolean = false;
  public tempselectedProductDetail: any;
  public selectedProductDetail: any;
  public userOrGuest: string = "";
  public medicalData : any = [];
  constructor(private _db: DrugBusinessService, private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute) {
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {
    this.reviewProductEntity = {
      log_ID: 0,
      patient_ID: 0,
      product_ID: "",
      conditions: "",
      intake: "",
      positive_Effects: "",
      positive_Comments: "",
      negative_Effects: "",
      negative_Comments: "",
      effectiveness: 50,
      side_Effects: 50
    }

    this.userOrGuest = localStorage.getItem('usertype');
    if (!localStorage.getItem("fromReviewOrSkipReviewPage") && this.userOrGuest == 'user') {
      this.router.navigate(['reviewStrain-page']);
      return false;
    } else {
      this.reviewProductEntity = JSON.parse(sessionStorage.getItem("reviewLogDetail"));
      this.reviewProductEntity.log_ID = 0;
      this.reviewProductEntity.patient_ID != 0 ? this.reviewProductEntity.patient_ID = this.reviewProductEntity.patient_ID : 0;
      this.reviewProductEntity.product_ID != "" ? this.reviewProductEntity.product_ID = this.reviewProductEntity.product_ID : '';
      this.reviewProductEntity.conditions != "" ? this.reviewProductEntity.conditions = this.reviewProductEntity.conditions : '';
      this.reviewProductEntity.intake != "" ? this.reviewProductEntity.intake = this.reviewProductEntity.intake : '';
      this.selectedCondition=this.reviewProductEntity.intake;
      this.reviewProductEntity.positive_Effects != "" ? this.reviewProductEntity.positive_Effects = this.reviewProductEntity.positive_Effects : '';
      this.reviewProductEntity.positive_Comments != "" ? this.reviewProductEntity.positive_Comments = this.reviewProductEntity.positive_Comments : '';
      this.reviewProductEntity.negative_Effects != "" ? this.reviewProductEntity.negative_Effects = this.reviewProductEntity.negative_Effects : '';
      this.reviewProductEntity.negative_Comments != "" ? this.reviewProductEntity.negative_Comments = this.reviewProductEntity.negative_Comments : '';
      this.reviewProductEntity.effectiveness != 0 ? this.reviewProductEntity.effectiveness = this.reviewProductEntity.effectiveness : '';
      this.reviewProductEntity.side_Effects != 0 ? this.reviewProductEntity.side_Effects = this.reviewProductEntity.side_Effects : '';
    }
    this.spinnerShow = true;
    this._ls.display(true);
    this._db.getMasterInfoDetail().subscribe(res => {
      let status:boolean=false;
      for (let i = 0; i < res.IntakeModes.length; i++) {
        if(this.selectedCondition == res.IntakeModes[i].Title ){
        status =true;
        this.previousSelctedValue=i;
        }else{
        status =false
        }
        this.inTakeModes.push(
          {
            "id": res.IntakeModes[i].Id,
            "strain": res.IntakeModes[i].Title,
            "status": status
          });
      }
    }, (err) => {
      console.log("_db getMasterInfoDetail ", err);
      this.spinnerShow = false;
    });
    if (sessionStorage.getItem("selectedProductDetail")) {
      this.tempselectedProductDetail = JSON.parse(sessionStorage.getItem("selectedProductDetail"));
      this._db.getIndividualProductDetailBy_PatientId_ProductId_Role(this.tempselectedProductDetail.Product_ID, this.tempselectedProductDetail.Patient_Id).subscribe(res => {
        this.selectedProductDetail = res;
        this.reviewProductEntity.product_ID = res ?res.Product_Id:"" ;
        this.spinnerShow = false;
      }, (err) => {
        console.log("_db getIndividualProductDetailBy_PatientId_ProductId_Role", err);
        this.spinnerShow = false;
      })
    }
    this.temp = this.routeParam
      .params
      .subscribe(params => {
        var paramValue = params['id'];

        if (paramValue == 1) {
          this.userType = "PATIENT X";
          this.isGuest = true;
        } else if (paramValue == 2) {
          this.isGuest = false;
          this.userType = "GUEST";
        } else {
          console.log("Unkonwn");
        }
        this._ls.display(false);
      });
      } else {
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }

  productsNext() {
    this.spinnerShow = true;
    if (localStorage.getItem("fromReviewOrSkipReviewPage") == "fromreview" && this.userOrGuest == 'user') {
      if (this.selectedCondition != "") {
        this.reviewProductEntity.intake = this.selectedCondition;
        sessionStorage.setItem('reviewLogDetail', JSON.stringify(this.reviewProductEntity));
        this.spinnerShow = false;
        this.router.navigate(['positive-effects']);
      } else {
        this.spinnerShow = false;
        this.infoAlert = true;
      }
    }
  }

  profileSubmit(event: Event) {
    //this.router.navigate(['primaryReason-page']);
  }

  selectConditionSubmit(selectedIndex: number) {
    this.infoAlert = false;
    var getStatus = this.inTakeModes[selectedIndex].status;
    var getID = this.inTakeModes[selectedIndex].id;
    this.selectedCondition = this.inTakeModes[selectedIndex].strain;
    if (this.previousSelctedValue == Number(selectedIndex)) {
      this.inTakeModes[selectedIndex].status = true
    } else {
      this.inTakeModes[selectedIndex].status = true;
      this.previousSelctedValue != -1 ? this.inTakeModes[this.previousSelctedValue].status = false : '';
      this.previousSelctedValue = selectedIndex;
    }
  }
}