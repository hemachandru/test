import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { ReviewProductEntity } from '../../entity/reviewProduct.entity';

const buttonNext = [
    {
        "id": 1,
        "buttonName": "NEXT"
    }
];

@Component({
    selector: 'app-negativeEffect',
    templateUrl: './negative-effects.component.html',
    styleUrls: ['./negative-effects.component.scss'],
    providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class NegativeEffectsComponent {
    public btnNextData = buttonNext;
    public isGuest: boolean = false;
    public medicalData: any = [];
    //public productdata = buttonGuest;
    public infoAlert: boolean = false;
    //public productdata = buttonGuest;
    public reviewProductEntity: ReviewProductEntity;
    private temp: any;
    private userType: any;
    private prdArr: any[] = [];
    public spinnerShow: boolean = false;
    private tempNegativeEffectsData: any = [];
    private negativeEffectsData: any = [];
    private negativeEffectComment: string = "";
    public userOrGuest: string = "";
    public negativeEffects: any = [];
    //router
    constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) { }

    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.reviewProductEntity = {
                log_ID: 0,
                patient_ID: 0,
                product_ID: "",
                conditions: "",
                intake: "",
                positive_Effects: {},
                positive_Comments: "",
                negative_Effects: {},
                negative_Comments: "",
                effectiveness: 50,
                side_Effects: 50
            }
            this.userOrGuest = localStorage.getItem('usertype');
            if (!localStorage.getItem("fromReviewOrSkipReviewPage") && this.userOrGuest == 'user') {
                this.router.navigate(['reviewStrain-page']);
                return false;
            } else {

                this.reviewProductEntity = JSON.parse(sessionStorage.getItem("reviewLogDetail"));
                this.reviewProductEntity.log_ID = 0;
                this.reviewProductEntity.patient_ID != 0 ? this.reviewProductEntity.patient_ID = this.reviewProductEntity.patient_ID : 0;
                this.reviewProductEntity.product_ID != "" ? this.reviewProductEntity.product_ID = this.reviewProductEntity.product_ID : '';
                this.reviewProductEntity.conditions != "" ? this.reviewProductEntity.conditions = this.reviewProductEntity.conditions : '';
                this.reviewProductEntity.intake != "" ? this.reviewProductEntity.intake = this.reviewProductEntity.intake : '';
                this.reviewProductEntity.positive_Effects != "" ? this.reviewProductEntity.positive_Effects = this.reviewProductEntity.positive_Effects : '';
                this.reviewProductEntity.positive_Comments != "" ? this.reviewProductEntity.positive_Comments = this.reviewProductEntity.positive_Comments : '';
                this.reviewProductEntity.negative_Effects != "" ? this.tempNegativeEffectsData = this.reviewProductEntity.negative_Effects : '';
                this.reviewProductEntity.negative_Comments != "" ? this.reviewProductEntity.negative_Comments = this.reviewProductEntity.negative_Comments : '';
                this.negativeEffectComment = this.reviewProductEntity.negative_Comments;
                this.reviewProductEntity.effectiveness != 0 ? this.reviewProductEntity.effectiveness = this.reviewProductEntity.effectiveness : '';
                this.reviewProductEntity.side_Effects != 0 ? this.reviewProductEntity.side_Effects = this.reviewProductEntity.side_Effects : '';

                for (var index = 0; index < this.tempNegativeEffectsData.length; index++) {
                    this.negativeEffectsData.push(this.tempNegativeEffectsData[index].negativeEffects);
                }
            }
            this.spinnerShow = true;
            var paramValue = localStorage.getItem('usertype')
            if (paramValue == 'user') {
                var fname = localStorage.getItem('patient_fname');
                //var lname = localStorage.getItem('patient_lname');
                //this.userType="PATIENT X";
                this.userType = fname;
                this.isGuest = true;
                console.log(this.isGuest);
            } else if (paramValue == "guest") {
                this.isGuest = false;
                this.userType = "GUEST";
            } else {
                console.log("Unkonwn");
            }

            //PositiveEffects, NegativeEffects
            this._db.getMasterInfoDetail().subscribe(res => {
                //console.log(res);
                this.medicalData = [];
                let status: boolean = false;
                for (let i = 0; i < res.NegativeEffects.length; i++) {
                    this.negativeEffectsData.indexOf(res.NegativeEffects[i].Title) == -1 ? status = false : status = true;
                    this.medicalData.push(
                        {
                            "id": res.NegativeEffects[i].Id,
                            "strain": res.NegativeEffects[i].Title,
                            "status": status
                        });
                }
                this.spinnerShow = false;
            });
        } else {
            this.spinnerShow = false;
            this.router.navigate(['landing-page']);
        }
    }


    submitNext() {
        this.spinnerShow = true;
        if (localStorage.getItem("fromReviewOrSkipReviewPage") == "fromreview") {
            if (this.tempNegativeEffectsData.length > 0) {
                this.reviewProductEntity.negative_Effects = this.tempNegativeEffectsData;
                this.reviewProductEntity.negative_Comments = this.negativeEffectComment;
                sessionStorage.setItem('reviewLogDetail', JSON.stringify(this.reviewProductEntity));
                this.spinnerShow = false;
                this.router.navigate(['review-thanks']);
            } else {
                this.spinnerShow = false;
                this.infoAlert = true;
            }
        }
    }

    logoutSubmit(event: Event) {
        this._ls.display(false);
        this.router.navigate(['landing-page']);
    }

    profileSubmit(event: Event) {
        //profile
    }

    selectConditionSubmit(selectedIndex: any) {
        this.infoAlert = false;
        var getStatus = this.medicalData[selectedIndex].status;
        var getID = this.medicalData[selectedIndex].id;
        if (getStatus == true) {
            this.medicalData[selectedIndex].status = false;
            for (var index = 0; index < this.tempNegativeEffectsData.length; index++) {
                if ((this.tempNegativeEffectsData[index].Id == Number(selectedIndex))) {
                    this.tempNegativeEffectsData.splice(Number(index), 1);
                }
            }
        } else {
            this.medicalData[selectedIndex].status = true;
            let negativeEffectsObject = {
                Id: selectedIndex,
                negativeEffects: this.medicalData[selectedIndex].strain
            }
            this.tempNegativeEffectsData.push(negativeEffectsObject);
        }
    }
    //router
}