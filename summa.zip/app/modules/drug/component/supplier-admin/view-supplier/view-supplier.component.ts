import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { AddEntity } from '../supplier-entity/add.entity';
import { UpdateProductName } from '../supplier-entity/update-entity/updatecomponent.entity';
import { UpdateProduct } from '../supplier-entity/update-entity/updateproduct.entity';
const updateProductname = [

    {
        "id": 1,
        "strain": "Purple Kush",
        "className": "product-color1"
    },
    {
        "id": 2,
        "strain": "Banana OG",
        "className": "product-color2"
    },
    {
        "id": 3,
        "strain": "Swag Daddy",
        "className": "product-color3"
    },
    {
        "id": 4,
        "strain": "Diesel",
        "className": "product-color1"
    },
    {
        "id": 5,
        "strain": "Blue River",
        "className": "product-color2"
    },
    {
        "id": 6,
        "strain": "Hazel Kush",
        "className": "product-color3"
    },
    {
        "id": 7,
        "strain": "Midnight Train",
        "className": "product-color1"
    },
    {
        "id": 8,
        "strain": "Midnight Train",
        "className": "product-color1"
    }
];
@Component({
    templateUrl: './view-supplier.component.html',
    styleUrls: ['./view-supplier.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor']
})
export class ViewSupplierComponent implements OnInit {

    activeColor: string = 'green';
    baseColor: string = '#ccc';
    overlayColor: string = 'rgba(255,255,255,0.5)';

    dragging: boolean = false;
    loaded: boolean = false;
    imageLoaded: boolean = false;
    imageSrc: string = '';
    borderColor: any;
    iconColor: any;
    addentity: AddEntity;
    filesize = true;
    invalidFile: any;
    requiredFile: any;
    fileEmpty = true;
    public productdata = updateProductname;
    updateproduct: UpdateProduct;

    @ViewChild('addProduct') public addProduct: TemplateRef<any>;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    @ViewChild('viewProduct') public viewProduct: TemplateRef<any>;
    dialogView: DialogRef<any>;
    dialog: DialogRef<any>;
    dialogNew: DialogRef<any>;
    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        ViewSupplierComponent.prototype.invalidFile = 'none';
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        ViewSupplierComponent.prototype.invalidFile = 'none';
        this.addentity = {
            name: '',
            thc: '',
            cbd: '',
            desc: '',
            file: '',
            productname: '',
            productthc: '',
            productcbd: '',
            productdesc: ''
        }
        this.updateproduct = {
            name: 'Banana OG',
            thc: '20',
            cbd: '7',
            desc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.',
            file: '',
            productname: 'Banana OG',
            productthc: '20',
            productcbd: '7',
            productdesc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.'
        }
    }
    onCancelSupplier() {
        this.router.navigate(['/suppliers/supplier-admin']);
    }
    onEdit() {
        this.router.navigate(['/suppliers/supplier-admin/edit-view']);
    }
    onAddSupplier() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    onAddNew() {
        this.imageLoaded = false;
        this.imageSrc = "";
        this.fileEmpty = true;
        ViewSupplierComponent.prototype.requiredFile = 'none';
        ViewSupplierComponent.prototype.invalidFile = 'none';
        this.filesize = true;
        this.addentity = {
            name: '',
            thc: '',
            cbd: '',
            desc: '',
            file: '',
            productname: '',
            productthc: '',
            productcbd: '',
            productdesc: ''
        }
        this.updateproduct = {
            name: 'Banana OG',
            thc: '20',
            cbd: '7',
            desc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.',
            file: '',
            productname: 'Banana OG',
            productthc: '20',
            productcbd: '7',
            productdesc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.'
        }
        return this.modal.open(this.addProduct, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-addproduct' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onViewProduct() {
        this.updateproduct = {
            name: 'Banana OG',
            thc: '20',
            cbd: '7',
            desc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.',
            file: '',
            productname: 'Banana OG',
            productthc: '20',
            productcbd: '7',
            productdesc: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus.'
        }
        return this.modal.open(this.viewProduct, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-addproduct' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onSave() {
        if (this.loaded == true) {
            this.fileEmpty = true;
            ViewSupplierComponent.prototype.requiredFile = 'none';
        }
        else {
            this.fileEmpty = false;
            ViewSupplierComponent.prototype.requiredFile = 'block';
            return false;
        }
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    onSaveView() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialogNew => {
                this.dialogNew = dialogNew;
            })
    }
    _keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);

        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    }
    onClose() {
        this.dialogNew.close();
    }
    onCancel() {
        this.dialog.close();
    }
    onViewAll() {
        this.router.navigate(['/suppliers/supplier-admin/view-all']);
    }
    //upload image
    handleDragEnter() {
        this.dragging = true;
    }

    handleDragLeave() {
        this.dragging = false;
    }

    handleDrop(e: any) {
        e.preventDefault();
        this.dragging = false;
        this.handleInputChange(e);
    }

    handleImageLoad() {
        this.imageLoaded = true;
        this.iconColor = this.overlayColor;
    }

    handleInputChange(e: any) {
        this.fileEmpty = true;
        ViewSupplierComponent.prototype.requiredFile = 'none';
        var file = e.dataTransfer ? e.dataTransfer.files[0] : e.target.files[0];

        var pattern = /image-*/;
        var reader = new FileReader();

        if (!file.type.match(pattern)) {
            alert('invalid format');
            return;
        }

        this.loaded = false;

        reader.onload = this._handleReaderLoaded.bind(this);
        reader.readAsDataURL(file);
    }

    _handleReaderLoaded(e: any) {
        var value = e.total;
        if (value > 2097152) // 2 mb for bytes.
        {
            this.filesize = false;
            ViewSupplierComponent.prototype.invalidFile = 'block';
        }
        else {
            this.filesize = true;
            ViewSupplierComponent.prototype.invalidFile = 'none';
            var reader = e.target;
            this.imageSrc = reader.result;
            this.loaded = true;
        }
    }

    _setActive() {
        this.borderColor = this.activeColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.activeColor;
        }
    }

    _setInactive() {
        this.borderColor = this.baseColor;
        if (this.imageSrc.length === 0) {
            this.iconColor = this.baseColor;
        }
    }
}