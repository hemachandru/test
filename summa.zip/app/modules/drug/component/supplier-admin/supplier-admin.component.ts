import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

const dataObj = [
    {
        id: 0,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 1,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 2,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 3,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 4,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 5,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 6,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 7,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 8,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 9,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 10,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 11,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 12,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 13,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 14,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 15,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 16,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 17,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    },
    {
        id: 18,
        url: require('../../../../../assets/images/supplier_icon.png'),
        title: "Doug's Cannabis"
    }
]

@Component({
    templateUrl: './supplier-admin.component.html',
    styleUrls: ['./supplier-admin.component.scss']
})
export class SupplierAdminComponent implements OnInit {

    data: any = dataObj;
    constructor(private router: Router) { }
    ngOnInit() {

    }
    onAddSupplier() {
        this.router.navigate(['/suppliers/supplier-admin/add-supplier']);
    }
    onView() {
        this.router.navigate(['/suppliers/supplier-admin/view-supplier']);
    }
}