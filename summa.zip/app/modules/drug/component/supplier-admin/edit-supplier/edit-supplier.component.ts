import { Component, Input, Output, EventEmitter, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, NavigationStart, Event as NavigationEvent } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { EditEntity } from '../supplier-entity/edit.entity';

@Component({
    templateUrl: './edit-supplier.component.html',
    styleUrls: ['./edit-supplier.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor']
})
export class EditSupplierComponent implements OnInit {
    editvalues: EditEntity;
    @ViewChild('successsave') public successsave: TemplateRef<any>;
    @ViewChild('fileInput') public myFileInput: ElementRef;
    dialog: DialogRef<any>;
    change = false;
    cliniclogo: any;
    constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.editvalues = {
            uname: '',
            password: '',
            confirmpassword: '',
            clinicname: '',
            description: '',
            website: '',
            cliniclogo: '',
            address: '',
            town: '',
            postal: '',
            country: 'CANADA',
            phone: '',
            fax: '',
            fname: '',
            lname: '',
            email: ''
        }
    }
    onChange(event: any) {
        if (event.target.files && event.target.files[0]) {
            let file = event.target.files;
            // this.editvalues.cliniclogo = file;
        }
    }
    onCancel(event: Event) {
        this.router.navigate(['/suppliers/supplier-admin/add-supplier']);
    }
    onSave() {
        return this.modal.open(this.successsave, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-dialog-appointmentsuccess' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }
    onClose() {
        this.dialog.close();
    }
}
