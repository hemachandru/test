import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';

const buttonNext = [
  {
    "id": 1,
    "buttonName": "FIND THE RIGHT PRODUCTS"
  }
];

const buttonSession = [
  {
    "id": 1,
    "buttonName": "REVIEW ANOTHER PRODUCT",
    "status": false
  },
  {
    "id": 2,
    "buttonName": "GO TO STRAIN SELECTOR",
    "status": false
  },
  {
    "id": 3,
    "buttonName": "GO TO YOUR LOG",
    "status": false
  }
];

const buttonSession1 = [
  {
    "id": 2,
    "buttonName": "GO TO STRAIN SELECTOR",
    "status": false
  }
];

@Component({
  selector: 'app-ourRecommendationPage',
  templateUrl: './ourRecommendation-page.component.html',
  styleUrls: ['./ourRecommendation-page.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class OurRecommendationPageComponent {
  public btnNextData = buttonNext;
  public spinnerShow: boolean = false;
  public thc = [
    {
      "id": 1,
      "strain": "0-0"
    }
  ];

  public cbd = [
    {
      "id": 1,
      "strain": "0-0"
    }
  ];

  public thcData = this.thc;
  public cbdData = this.cbd;

  public isGuest: boolean = false;
  private temp: any;
  private userType: any;
  public medicalConditionData: any = [];
  public tempMedicalConditionData: any = [];
  public userOrGuest: string = "";
  public recomendedValue: any;
  public medicalRecordClinic: any;
  public medicalSystemRecord: any;
  public btnRelatedData = buttonSession;
  public showOrHiddenTemplate: boolean = false;
  public thcValues: string = "";
  public cbdValue: string = "";
  constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) {
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {
      this.spinnerShow = true;
      if (!sessionStorage.getItem('selectMultipleCondition') && !sessionStorage.getItem('timeofdayused')) {
        this.router.navigate(['review-thanks']);
        this.spinnerShow = false;
        return false;
      }
      var paramValue = localStorage.getItem('usertype')
      paramValue == "guest" ? this.btnRelatedData = buttonSession1 : this.btnRelatedData = buttonSession;
      this.userOrGuest = paramValue;
      this.tempMedicalConditionData = JSON.parse(sessionStorage.getItem("selectMultipleCondition"));
      if (this.tempMedicalConditionData.length > 0) {
        for (let i = 0; i < this.tempMedicalConditionData.length; i++) {
          this.medicalConditionData.push(this.tempMedicalConditionData[i].medicalCondition);
        }
        let patientId = 0;
        this.userOrGuest == "guest" ? patientId = 0 : patientId = Number(localStorage.getItem('patient_id'));
        this._db.getMedConditionRecomendation_Thc_Cbd_Value(this.medicalConditionData.toString(), patientId).subscribe(res => {
          this.recomendedValue = res;
          this.thcValues = "";
          this.cbdValue = "";
          if (res.MED_REC_SYS.length > 0 && res.MED_REC_SYS[0].THC != "" && res.MED_REC_SYS[0].CBD != "") {
            this.medicalSystemRecord = res.MED_REC_SYS[0];
            this.thcValues = res.MED_REC_SYS[0].THC;
            this.cbdValue = res.MED_REC_SYS[0].CBD;
          } else if (res.MED_REC_Clinic.length > 0 && res.MED_REC_Clinic[0].MorningTHC != "" && res.MED_REC_Clinic[0].MorningCBD != "") {
            this.medicalRecordClinic = res.MED_REC_Clinic[0];
            let timeOfDayUsed = sessionStorage.getItem("timeofdayused");

            switch (timeOfDayUsed) {
              case "MORNING": {
                this.thcValues = this.medicalRecordClinic.MorningTHC;
                this.cbdValue = this.medicalRecordClinic.MorningCBD;
                break;
              }
              case "AFTERNOON": {
                this.thcValues = this.medicalRecordClinic.AfterNoonTHC;
                this.cbdValue = this.medicalRecordClinic.AfterNoonCBD;
                break;
              }
              case "EVENING": {
                this.thcValues = this.medicalRecordClinic.EveningTHC;
                this.cbdValue = this.medicalRecordClinic.EveningCBD;
                break;
              }
              case "NIGHT": {
                this.thcValues = this.medicalRecordClinic.NightTHC;
                this.cbdValue = this.medicalRecordClinic.NightCBD;
                break;
              }
            }

            let indexCbdValue = this.cbdValue.indexOf('-');
            let firstcbdValue = this.cbdValue.substring(0, indexCbdValue).trim();
            let lastcbdValue = this.cbdValue.substring(indexCbdValue + 1, this.cbdValue.length).trim();
            this.cbdValue = parseInt(firstcbdValue).toString() + - +parseInt(lastcbdValue).toString();

            let indexThcValue = this.thcValues.indexOf('-');
            let firstTHCValue = this.thcValues.substring(0, indexThcValue).trim();
            let lastTHCValue = this.thcValues.substring(indexThcValue + 1, this.thcValues.length).trim();
            this.thcValues = parseInt(firstTHCValue).toString() + - +parseInt(lastTHCValue).toString();
          } else {
            sessionStorage.removeItem('selectMultipleCondition');
            sessionStorage.removeItem('timeofdayused');
            sessionStorage.removeItem('primaryReason');
            localStorage.removeItem('currentPage');
            sessionStorage.removeItem("thcData");
            sessionStorage.removeItem("cbdData");
            sessionStorage.removeItem("selectedProductDataList");
            sessionStorage.removeItem('selectedProductDetail');
            sessionStorage.removeItem('reviewLogDetail');

            this.showOrHiddenTemplate = true;
          }
          this.thc = [
            {
              "id": 1,
              "strain": this.thcValues
            }
          ];

          this.cbd = [
            {
              "id": 1,
              "strain": this.cbdValue
            }
          ];
          this.thcData = this.thc;
          this.cbdData = this.cbd;
          this.spinnerShow = false;
        }, (err) => {
          this.spinnerShow = false;
          console.log("_db getMedConditionRecomendation_Thc_Cbd_Value", err);
        });
      }
    } else {
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }

  ourRecomnendNextSubmit(event: Event) {
    if (this.thcValues != "" && this.cbdValue != "") {
      sessionStorage.removeItem("selectedProductDataList");
      sessionStorage.setItem("thcData", String(this.thcValues));
      sessionStorage.setItem("cbdData", String(this.cbdValue));
      this.router.navigate(['products-page']);
    } else {
      this.router.navigate(['review-thanks']);
    }
  }

  selectConditionSubmit(event: any) {
    var getVal = this.btnRelatedData[event].id;

    if (getVal == 1) {
      this.router.navigate(['reviewStrain-page']);
    } else if (getVal == 2) {
      this.router.navigate(['guestHome-page']);
    } else if (getVal == 3) {
      this.router.navigate(['gotoLog-page']);
    } else {
    }


  }

}