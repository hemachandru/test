import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';

const buttonNext = [
  {
    "id": 1,
    "buttonName": "NEXT"
  }
];


const buttonSession = [
  {
    "id": 1,
    "buttonName": "MORNING",
    "status": false
  },
  {
    "id": 1,
    "buttonName": "AFTERNOON",
    "status": false
  },
  {
    "id": 1,
    "buttonName": "EVENING",
    "status": false
  },
  {
    "id": 1,
    "buttonName": "NIGHT",
    "status": false
  }
];

@Component({
  selector: 'app-timesUsedPage',
  templateUrl: './timesUsed-page.component.html',
  styleUrls: ['./timesUsed-page.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class TimesUsedPageComponent {
  public btnNextData = buttonNext;
  public btnSessData = buttonSession;
  public isGuest: boolean = false;

  public productdata = buttonSession;
  private temp: any;
  private userType: any;
  private prdArr: any[] = [];
  public timesDayUsed: any = [];
  public infoAlert: boolean = false;
  public selectedCondition: string = "";
  public previousSelctedValue: number = -1;
  public spinnerShow: boolean = false
  //router
  constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) { }

  ngOnInit() {
    if (localStorage.getItem('token')) {
    if (!sessionStorage.getItem('selectMultipleCondition')) {
      this.router.navigate(['review-thanks']);
      return false;
    }
    if (sessionStorage.getItem("timeofdayused")) {
      this.selectedCondition = sessionStorage.getItem("timeofdayused");
    }
    this.spinnerShow = true;
    //strain list
    this._db.getMasterInfoDetail().subscribe(res => {
      // console.log(res.DayTimes[0]);
      this.timesDayUsed = [];
      let status: boolean = false;
      for (let i = 0; i < res.DayTimes.length; i++) {
        if (this.selectedCondition == res.DayTimes[i].Title) {
          this.previousSelctedValue=i;
          status = true;
        } else {
          status = false
        }
        this.timesDayUsed.push(
          {
            "id": res.DayTimes[i].Id,
            "buttonName": res.DayTimes[i].Title,
            "status": status
          });
      }
      this.spinnerShow = false;
      console.log(this.timesDayUsed);
    });
    }else{
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }


  timesNextSubmit(event: Event) {
    if (this.selectedCondition != "") {
      sessionStorage.setItem("timeofdayused", this.selectedCondition);
      this.router.navigate(['primaryReason-page']);
    } else {
      sessionStorage.removeItem("timeofdayused");
      this.infoAlert = true;
    }
  }

  selectConditionSubmit(selectedIndex: any) {
    this.infoAlert = false;
    var getStatus = this.timesDayUsed[selectedIndex].status;
    var getID = this.timesDayUsed[selectedIndex].id;
    this.selectedCondition = this.timesDayUsed[selectedIndex].buttonName;
    if (this.previousSelctedValue == Number(selectedIndex)) {
      this.timesDayUsed[selectedIndex].status = true
    } else {
      this.timesDayUsed[selectedIndex].status = true;
      this.previousSelctedValue != -1 ? this.timesDayUsed[this.previousSelctedValue].status = false : '';
      this.previousSelctedValue = selectedIndex;
    }
  }

}