import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { NgStyle } from '@angular/common';

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';


const buttonNext = [
  {
    "id": 1,
    "buttonName": "NEXT"
  }
];


const buttonSession = [
  {
    "id": 1,
    "buttonName": "GO TO STRAIN SELECTOR",
    "status": false
  },
  {
    "id": 2,
    "buttonName": "REVIEW ANOTHER PRODUCT",
    "status": false
  }
];

@Component({
  selector: 'app-reviewThanks',
  templateUrl: './gotoLog-page.component.html',
  styleUrls: ['./gotoLog-page.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})

export class GotoLogComponent {
  public btnNextData = buttonNext;
  public btnSessData = buttonSession;
  public isGuest: boolean = false;

  public productdata = buttonSession;
  private temp: any;
  private userType: any;
  private prdArr: any[] = [];
  private prdTable: any[] = [];
  private noDataFlag: boolean = false;
  private noTopRatedStrainFlag: boolean = false;
  private noData: string = this.config.noData;
  public spinnerShow: boolean = false
  //router
  constructor(private config: Config, private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) { }

  ngOnInit() {
    if (localStorage.getItem('token')) {
      this.spinnerShow = true;
      this._db.getTopRatedStrain().subscribe(res => {
        this.prdArr = res;
        res.length == 0 ? this.noTopRatedStrainFlag = true : this.noTopRatedStrainFlag = false;
      })

      this._db.GetCannabisLog_all().subscribe(result => {
        this.prdTable = result;
        result.length == 0 ? this.noDataFlag = true : this.noDataFlag = false;
        this.spinnerShow = false;
      })
    } else {
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }

  logoutSubmit(event: Event) {
    this.router.navigate(['landing-page']);
  }
  //profile

  profile(event: Event) {
    this.router.navigate(['profile']);
  }

  selectConditionSubmit(event: any) {
    var getVal = this.productdata[event].id;
    if (getVal == 2) {
      this.router.navigate(['reviewStrain-page']);
    } else if (getVal == 1) {
      this.router.navigate(['guestHome-page']);
    } else {
      console.log('error');
    }

  }

  sendCannabisLog() {
    this.spinnerShow = true;
    this._db.sendCannabisLogDetailAsEmail().subscribe(res => {
      this.spinnerShow = false;
    }, (err) => {
      this.spinnerShow = false;
      console.log("_db sendCannabisLogDetailAsEmail" + err);
    });
  }

}