import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  templateUrl: './supplier.component.html'
})
export class SupplierComponent implements OnInit {
  constructor() { }
  ngOnInit() { }
}