import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Component, OnInit, OnDestroy, Inject, TemplateRef, ViewChild, ChangeDetectorRef, ViewContainerRef, ElementRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { CompleterService, CompleterData, CompleterItem } from 'ng2-completer';
import { Config } from '../../../../../config/constant';
import { DrugBusinessService } from "../../../business/drug.business";
import { LoaderService } from "../../../../../shared/shared-loader/shared-loader.service";

@Component({
  templateUrl: './supplier-list.component.html',
  styleUrls: ['./supplier-list.component.scss'],
})


export class SupplierListComponent implements OnInit, OnDestroy {

  clinicDetails: any;
  public resultValue: any;
  public opts: ISlimScrollOptions;
  highlightedDiv: number;
  private sortByTHC = [0, 100];
  private sortByCBD = [0, 100];
  private masterInfo: any;
  private isloaded: boolean = false;
  private isEmpty: boolean = false;
  private selectedProductList: any = [];
  private selectedProductType: any = [];
  private cites: any = [];
  private strainDetail: any = {};
  private productTypeList: any = [];
  protected dataService: CompleterData;
  private clearSearchInput: boolean = false;
  private serverData: any = {};
  private userDetails: any = {};
  private isDocumentAvailable: boolean = false;
  private documentDetails: any = {};
  private observerMasterInfo: Subscription;
  private observerProfile: Subscription;
  private searchFlagOnOff = false;
  private searchLocationFlagOnOff = false;
  private searchLimitFlagOnOff = false;
  private searchProductNameLimitFlagOnOff = false;
  private selectedFilter: any = {};
  private findyourstrain: any = this.config.findyourstrain;
  private currentUser: string = "";
  private searchStr: string= "";
  
  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
  dialog: DialogRef<any>;

  constructor(private route: ActivatedRoute, private config: Config, private _cdr: ChangeDetectorRef, private completerService: CompleterService, private _dbs: DrugBusinessService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }

  ngOnInit() {
    //this.resultValue = this.clinicDetails[0];
    this.currentUser = localStorage.getItem('currentUser');
    this.clearSearchInput = true;
    this.clinicDetails = [];
    this.resultValue = [];
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.serverData = {
      search_code: 4,
      parent_clinic_id: 0,
      cities: '',
      productType: '',
      ProductName: '',
      fromTHC: 0,
      toTHC: 100,
      fromCBD: 0,
      toCBD: 100
    }
    this.highlightedDiv = 1;
    this.getMasterInfoDetail();
    this.getLocation();
    this.observerProfile = this._dbs.getUserInfo().subscribe(res => {
      this.userDetails = res.Patient_Login_Data;
      this.checkMedicalDocument(this.userDetails.Patient_Provider_Relation.ObjProvider.Clinic_Id);
    })

  }

  onEnter(enterValue: string) {
    if (enterValue.trim().length == 0 && !this.searchFlagOnOff) {
      return false;
    }
    if (enterValue.trim().length >= 3) {
      this.searchFlagOnOff = true;
      this.searchProductNameLimitFlagOnOff =true;
      this.serverData.productName = enterValue;
      this.serverData.code = 4;
      this.getAllSupplier(this.serverData);
    } else {
      this.serverData.productName = null;
      this.serverData.code = 4;
      if (enterValue.trim().length == 0 && this.searchFlagOnOff && this.searchProductNameLimitFlagOnOff) {
        this.searchFlagOnOff = false;
        this.searchProductNameLimitFlagOnOff =false;
        this.getAllSupplier(this.serverData)
      }
    }

  }

  onClinicView(value: any) {
    //this.resultValue = value;
    this.getSupplierDetail(value);
    if (this.highlightedDiv === value.LP_Id) {
      this.highlightedDiv = 0;
    }
    else {
      this.highlightedDiv = value.LP_Id;
    }

  }
  onBookAppointment() {
    this.router.navigate(['clinics/appointment']);
  }

  onChangeTHC(event: Event) {
    this.serverData.fromTHC = event[0];
    this.serverData.toTHC = event[1];
    this.getAllSupplier(this.serverData);
  }

  onChangeCBD(event: Event) {
    this.serverData.fromCBD = event[0];
    this.serverData.toCBD = event[1];
    this.getAllSupplier(this.serverData);
  }

  onSelectName(enterValue: any) {
    if ((enterValue.trim().length == 0 && !this.searchLocationFlagOnOff) || enterValue == null) {
      return false;
    }
    if (enterValue.trim().length >= 3) {
      this.searchLimitFlagOnOff =true;
      this.searchLocationFlagOnOff = true;
      this.serverData.cities = enterValue;
      this.serverData.code = 4;
      this.getAllSupplier(this.serverData);
    } else {
      this.serverData.cities = null;
      this.serverData.code = 4;
      this.searchLocationFlagOnOff = true;
      if (enterValue.trim().length == 0 && this.searchLocationFlagOnOff && this.searchLimitFlagOnOff) {
        this.searchLimitFlagOnOff =false;
        this.searchLocationFlagOnOff = false;
        this.getAllSupplier(this.serverData)
      }
    }

  }

  onSelectionChange(val: string) {
    this.serverData.productType = val;
    this.getAllSupplier(this.serverData);
  }

  getStrainDetail(value: any) {
    let data = {
      product_id: value.Product_Id
    }
    this._dbs.getStrainDetail(data, this.masterInfo.ProductTypes).subscribe(res => {
      this.strainDetail = res;
      return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog suplier-popup-list' }, BSModalContext)).then(dialog => {
        this.dialog = dialog;
        //this.close();
      });
    })
  }

  favclose() {
    this.dialog.close();
  }
  getMasterInfoDetail() {
    this.observerMasterInfo = this._dbs.getMasterInfoDetail().subscribe(res => {
      if (res) {
        this.masterInfo = res;
        this.productTypeList = res.ProductTypes;
        this.getAllSupplier(this.serverData);
      }
    })
  }
  getAllSupplier(data: any) {
    this._dbs.getAllSupplier(data).subscribe(res => {
      if (res.length === 0) {
        setTimeout(() => {
          this.isEmpty = true;
          this.clinicDetails = [];
        }, 10);
        return false;
      }
      this.isEmpty = false;
      this.clinicDetails = res;
      this.route.params.subscribe((params: Params) => {
        let licenceProducerId = params['id'];
        if (licenceProducerId) {
          let index = res.findIndex((res: any) => res.LP_Id == Number(licenceProducerId));
          this.getSupplierDetail(res[index]);
        } else {
          this.getSupplierDetail(res[0]);
        }
      });

    })
  }

  getSupplierDetail(singleObj: any) {
    this._dbs.getSupplierDetails(singleObj).subscribe(res => {
      this.resultValue = res[0];
      this.highlightedDiv = res[0].LP_Id
      this.getSelectedSupplierProduct(parseInt(this.resultValue.LP_Id), this.masterInfo.ProductTypes);
    })
  }

  getSelectedSupplierProduct(id: number, masterInfo: any) {
    this._dbs.getSelectedSupplierProduct(id, masterInfo).subscribe(res => {
      if (res.length === 0) {
        this.selectedProductList = [];
        this.isloaded = false;
        return false;
      }
      this.isloaded = true;
      this.selectedProductList = res;
    })
  }

  public get latestSupplierProduct() {
    return this.selectedProductList.filter((item: any, index: any) => index < 6)
  }

  addToFavouriteStrain(id: number, isAdd: boolean) {
    let isAddOrRemove = !isAdd;
    this._dbs.addOrRemoveFavoriteStrain(id, isAddOrRemove).subscribe(res => {
      this.strainDetail.IsFavourite = isAddOrRemove;
    })
  }

  getLocation() {
    this._dbs.getClinicProvincesCities().subscribe(res => {
      this.dataService = res;
    })
  }

  checkMedicalDocument(data: number) {
    this._dbs.getAllMedicalDocument(data).subscribe(res => {
      if (!res) {
        this.isDocumentAvailable = res;
        return false;
      }

      this.isDocumentAvailable = true;
      this.documentDetails = res;
    })
  }

  updateMedicalDocStatus(data: any) {
    let params = {
      LP_Id: this.documentDetails.LP_Id,
      Medical_Doc_Id: this.documentDetails.Medical_Document_Id,
      Doc_Status: this.documentDetails.Medical_Doc_Status,
      Medical_Doc_Relation_Id: this.documentDetails.Medical_Doc_Relation_Id,
      PatientProductRequests: this.documentDetails.PatientProductRequests,
      Patient_Id: this.documentDetails.Patient_Id,
      Provider_Id: this.documentDetails.Provider_Id,
      IsPrinted: this.documentDetails.IsPrinted
    }
    this._dbs.sendMedicalDocument(params).subscribe(res => {
      if (res) {
        this.favclose();
      }
    })
  }

  ngOnDestroy() {
    this.observerMasterInfo.unsubscribe();
    this.observerProfile.unsubscribe();
  }
}





