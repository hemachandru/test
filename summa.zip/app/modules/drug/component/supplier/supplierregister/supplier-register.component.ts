import { Observable } from 'rxjs/Observable';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { IMyOptions, IMyDateModel, IMyInputFieldChanged, IMyCalendarViewChanged, IMyInputFocusBlur } from 'mydatepicker';
import { MyDatePicker } from 'mydatepicker';

@Component({
    templateUrl: './supplier-register.componenet.html',
    styleUrls: ["./supplier-register.component.scss"]
})
export class SupplierRegistrationComponent implements OnInit {
    public opts: ISlimScrollOptions; 
    public idate: any;
    public date = new Date();


     private myDatePickerNormalOptions: IMyOptions = {
    todayBtnTxt: 'Today',
    dateFormat: 'mm/dd/yyyy',
    firstDayOfWeek: 'mo',
    height: '25px',
    width: '203px',
    selectionTxtFontSize: '12px',
    indicateInvalidDate: true,
    editableMonthAndYear: true,
    minYear: 1900,
    maxYear: this.date.getUTCFullYear(),
    disableSince: { year: this.date.getUTCFullYear(), month: this.date.getUTCMonth() + 1, day: this.date.getUTCDate() + 1 },
    componentDisabled: false,
    showClearDateBtn: false,
    showSelectorArrow: true,
    showInputField: true,
    openSelectorOnInputClick: true,
    inline: false,
    editableDateField: false,
    disableHeaderButtons: true,
    inputAutoFill: false,
    showWeekNumbers: false
  };
    constructor( private router: Router) { }
      ngOnInit() {
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }

    } 
      save() {
        this.router.navigate(['/suppliers/supplierdetails']);
    }
}