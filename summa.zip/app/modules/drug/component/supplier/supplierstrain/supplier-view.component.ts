import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';


const clinicdata = [
  {
    "id": 1,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$20 - $100"
  },
  {
    "id": 2,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$200 - $100"
  },
  {
    "id": 3,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$10 - $50"
  },
  {
    "id": 4,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$50 - $100"
  },
  {
    "id": 5,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$100 - $150"
  },
  {
    "id": 6,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 7,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 8,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  },
  {
    "id": 9,
    "clinicaddress": "Doug's Cannabis",
    "aboutclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "bookclinic": "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Sed id mollis mi, ut convallis risus. Nulla ac augue id sem mattis dignissim et eu mi. In at mollis lectus.",
    "clinicpricing": "$150 - $200"
  }

];
@Component({
  templateUrl: './supplier-view.component.html',
  styleUrls: ['./supplier-view.component.scss'],
})


export class SupplierStrainComponent implements OnInit {

  clinicDetails = clinicdata;
  public resultValue: any;
  public opts: ISlimScrollOptions;
  @ViewChild('templateRef') public templateRef: TemplateRef<any>;
    dialog: DialogRef<any>;
  constructor(overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }

  ngOnInit() {
    this.resultValue = this.clinicDetails[0];
    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }
  }
  onClinicView(id: any) {
    this.resultValue = this.clinicDetails.find(function (res) {
      return res.id == id;
    });
  }
  onBookAppointment() {
    this.router.navigate(['clinics/appointment']);
  }
    onSubmit() {
        return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
        this.dialog = dialog;
        //this.close();
        });
    }
    favclose(){
        this.dialog.close();
    }
}