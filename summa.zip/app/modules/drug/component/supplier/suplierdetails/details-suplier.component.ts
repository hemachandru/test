import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Config } from '../../../../../config/constant';
import { DrugBusinessService } from "../../../business/drug.business";

@Component({
    templateUrl: './detail-suplier.component.html',
    styleUrls: ["./details-suplier.component.scss"]
})
export class SuplierDetailComponent implements OnInit {
    @ViewChild('templateRef') public templateRef: TemplateRef<any>;
    public opts: ISlimScrollOptions;
    public ValidCurrentUser: string;
    private masterInfo: any = [];
    private isloaded: boolean = false;
    private isEmpty: boolean = false;
    private selectedProductList: any = [];
    private strainDetail: any = {};
    private resultValue: any;
    private LP_Identification: number;
    private isDocumentAvailable: boolean = false;
    private documentDetails: any = {};
    private userDetails: any = {};
    public flowerArray: any[] = [];
    public oilArray: any[] = [];
    public capsuleArray: any[] = [];
    public milledArray: any[] = [];
    public flowerText = this.config.FLOWERS;
    public oilText = this.config.OILS;
    public capsuleText = this.config.CAPSULES;
    public milledText = this.config.MILLED;
    public flowerArrayFlag: boolean = false;
    public oilArrayFlag: boolean = false;
    public capsuleArrayFlag: boolean = false;
    public milledArrayFlag: boolean = false;
    public noStrain = this.config.noStrain;
    public productProfiles: any;
    public nodataFlag: boolean = false;

    dialog: DialogRef<any>;
    constructor(private config: Config, private _dbs: DrugBusinessService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private route: ActivatedRoute, private el: ElementRef) {
        overlay.defaultViewContainer = vcRef;
    }
    ngOnInit() {
        this.resultValue = [];
        this.ValidCurrentUser = localStorage.getItem('currentUser');
        this.opts = {
            position: 'right',
            barBackground: '#4f4f4f',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
        this.getMasterInfoDetail();
        this.route.params.subscribe((params: Params) => {
            let lp_id = params['id'];
            if (lp_id) {
                this.LP_Identification = lp_id;
                let self = this;
                self.getSupplierDetail(parseInt(lp_id));
            }
        })

        this._dbs.getUserInfo().subscribe(res => {
            this.userDetails = res.Patient_Login_Data;
            this.checkMedicalDocument(this.userDetails.Patient_Provider_Relation.ObjProvider.Clinic_Id);
        })
    }
    onSubmit() {
        return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog suplier-popup-list' }, BSModalContext)).then(dialog => {
            this.dialog = dialog;
            //this.close();
        });
    }
    favclose() {
        this.dialog.close();
    }
    getMasterInfoDetail() {
        this._dbs.getMasterInfoDetail().subscribe(res => {
            if (res) {
                this.masterInfo = res;
                this.productProfiles = res.ProductProfiles;
                this.getSupplierProduct(this.LP_Identification, this.masterInfo.ProductTypes);
            }
        })
    }

    getStrainDetail(value: any) {
        let data = {
            product_id: value.Product_Id
        }
        this._dbs.getStrainDetail(data, this.masterInfo.ProductTypes).subscribe(res => {
            console.log(res);
            this.strainDetail = res;
            return this.modal.open(this.templateRef, overlayConfigFactory({ dialogClass: 'modal-dialog suplier-popup-list' }, BSModalContext)).then(dialog => {
                this.dialog = dialog;
            });
        })
    }

    getSupplierDetail(id: number) {
        let data = {
            LP_Id: id
        }
        this._dbs.getSupplierDetails(data).subscribe(res => {
            this.resultValue = res[0];
        });
    }

    getSupplierProduct(id: number, productTypes: any) {

        this._dbs.getSelectedSupplierProduct(id, productTypes).subscribe(res => {
            this.isloaded = true;
            this.selectedProductList = res;
            if (this.selectedProductList) {
                for (let recomendedProductListtData of this.selectedProductList) {
                    let profileType = this.productProfiles.filter((data: any) => {
                        return Number(data.Id) == Number(recomendedProductListtData.Profile);
                    });

                    if (profileType[0].Type == this.config.FLOWER) {
                        this.flowerArray.push(recomendedProductListtData);
                    } else if (profileType[0].Type == this.config.OIL) {
                        this.oilArray.push(recomendedProductListtData);
                    } else if (profileType[0].Type == this.config.CAPSULE) {
                        this.capsuleArray.push(recomendedProductListtData);
                    } else if (profileType[0].Type == this.config.MILLED) {
                        this.milledArray.push(recomendedProductListtData);
                    }
                }

                this.flowerArray.length == 0 ? this.flowerArrayFlag = true : this.flowerArrayFlag = false;
                this.oilArray.length == 0 ? this.oilArrayFlag = true : this.oilArrayFlag = false;
                this.capsuleArray.length == 0 ? this.capsuleArrayFlag = true : this.capsuleArrayFlag = false;
                this.milledArray.length == 0 ? this.milledArrayFlag = true : this.milledArrayFlag = false;

                if(this.flowerArrayFlag && this.oilArrayFlag && this.capsuleArrayFlag && this.milledArrayFlag){
                 this.nodataFlag=true;
                }
            }
        })
    }

    addToFavouriteStrain(id: number, isAdd: boolean) {
        let isAddOrRemove = !isAdd;
        this._dbs.addOrRemoveFavoriteStrain(id, isAddOrRemove).subscribe(res => {
            this.strainDetail.IsFavourite = isAddOrRemove;
        })
    }

    checkMedicalDocument(data: number) {
        this._dbs.getAllMedicalDocument(data).subscribe(res => {
            if (!res) {
                this.isDocumentAvailable = res;
                return false;
            }

            this.isDocumentAvailable = true;
            this.documentDetails = res;
            console.log(res);
        })
    }

    updateMedicalDocStatus(data: any) {
        let params = {
            LP_Id: this.documentDetails.LP_Id,
            Medical_Doc_Id: this.documentDetails.Medical_Document_Id,
            Doc_Status: this.documentDetails.Medical_Doc_Status,
            Medical_Doc_Relation_Id: this.documentDetails.Medical_Doc_Relation_Id,
            PatientProductRequests: this.documentDetails.PatientProductRequests,
            Patient_Id: this.documentDetails.Patient_Id,
            Provider_Id: this.documentDetails.Provider_Id,
            IsPrinted: this.documentDetails.IsPrinted
        }
        this._dbs.sendMedicalDocument(params).subscribe(res => {
            if (res) {
                this.favclose();
            }
        })
    }
}