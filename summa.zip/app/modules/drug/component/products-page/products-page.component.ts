import { Component, Input, OnInit, ViewContainerRef, TemplateRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';

import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { SharedObserverService } from '../../../../shared/shared-service-module/shared-observer.service';


const buttonNext = [
    {
        "id": 1,
        "buttonName": "NEXT"
    }
];




@Component({
    selector: 'app-productsPage',
    templateUrl: './products-page.component.html',
    styleUrls: ['./products-page.component.scss'],
    inputs: ['activeColor', 'baseColor', 'overlayColor'],
    providers: [DrugBusinessService, DrugService, HttpRequestService, Config, SharedObserverService]
})

export class ProductsPageComponent {
    public btnNextData = buttonNext;
    //routing
    public isGuest: boolean = false;
    private temp: any;
    private userType: any;
    dialog: DialogRef<any>;
    public flowerArray: any[] = [];
    public oilArray: any[] = [];
    public capsuleArray: any[] = [];
    public milledArray: any[] = [];
    public flowerText = this.config.FLOWERS;
    public oilText = this.config.OILS;
    public capsuleText = this.config.CAPSULES;
    public milledText = this.config.MILLED;
    public spinnerShow: boolean = false;
    public flowerArrayFlag: boolean = false;
    public oilArrayFlag: boolean = false;
    public capsuleArrayFlag: boolean = false;
    public milledArrayFlag: boolean = false;
    public noData = this.config.noData;
    public recomendedProductList: any;
    public selectedProductData: any;
    public selectedIndex: number = -1;
    public selectedProductDataList: any = [];
    public selectedProductIdList: any = [];
    public selectedProfileType: string = "";
    private infoAlert: boolean = false;
    public stockRange : any;

    @ViewChild('viewProduct') public viewProduct: TemplateRef<any>;
    constructor(private config: Config, private drugBusinessService: DrugBusinessService, private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal) {
        overlay.defaultViewContainer = vcRef;
    }

    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.spinnerShow = true;
            if (sessionStorage.getItem("thcData") && sessionStorage.getItem("cbdData")) {
                if (sessionStorage.getItem("selectedProductDataList")) {
                    this.selectedProductDataList = JSON.parse(sessionStorage.getItem("selectedProductDataList"));
                    for (let i = 0; i < this.selectedProductDataList.length; i++) {
                        this.selectedProductIdList.push(this.selectedProductDataList[i].productId);
                    }
                }
                let cbdValue = sessionStorage.getItem("cbdData");
                let thcValues = sessionStorage.getItem("thcData");

                let indexCbdValue = cbdValue.indexOf('-');
                let firstcbdValue = parseInt(cbdValue.substring(0, indexCbdValue).trim()).toString();
                let lastcbdValue = parseInt(cbdValue.substring(indexCbdValue + 1, cbdValue.length).trim()).toString();

                let indexThcValue = cbdValue.indexOf('-');
                let firstTHCValue = parseInt(cbdValue.substring(0, indexThcValue).trim()).toString();
                let lastTHCValue = parseInt(cbdValue.substring(indexThcValue + 1, cbdValue.length).trim()).toString();
                this.drugBusinessService.getProductListBasedOnThc_Cbd_Value(8, Number(this.config.Lp_Id), Number(firstTHCValue), Number(lastTHCValue), Number(firstcbdValue), Number(lastcbdValue)).subscribe(res => {
                    this.recomendedProductList = res;
                    if (this.recomendedProductList) {
                        this.drugBusinessService.getMasterInfoDetail().subscribe(response => {
                            this.spinnerShow = true;
                            let productTypes = response.ProductTypes;
                            let productProfiles = response.ProductProfiles;
                            let status: boolean = false;
                            for (let recomendedProductListtData of this.recomendedProductList) {
                                let profileType = productProfiles.filter((data: any) => {
                                    return Number(data.Id) == Number(recomendedProductListtData.Profile);
                                });
                                let productTypesData = productTypes.filter((data: any) => {
                                    return Number(data.Id) == Number(recomendedProductListtData.Product_Type);
                                });

                                if (this.selectedProductIdList.indexOf(recomendedProductListtData.Product_Id) == -1) {
                                    status = false;
                                } else {
                                    status = true;
                                }

                                if (profileType[0].Type == this.config.FLOWER) {
                                    this.flowerArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData[0], "Checked": status });
                                } else if (profileType[0].Type == this.config.OIL) {
                                    this.oilArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData[0], "Checked": status });
                                } else if (profileType[0].Type == this.config.CAPSULE) {
                                    this.capsuleArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData[0], "Checked": status });
                                } else if (profileType[0].Type == this.config.MILLED) {
                                    this.milledArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData[0], "Checked": status });
                                }
                            }
                            this.flowerArray.length == 0 ? this.flowerArrayFlag = true : this.flowerArrayFlag = false;
                            this.oilArray.length == 0 ? this.oilArrayFlag = true : this.oilArrayFlag = false;
                            this.capsuleArray.length == 0 ? this.capsuleArrayFlag = true : this.capsuleArrayFlag = false;
                            this.milledArray.length == 0 ? this.milledArrayFlag = true : this.milledArrayFlag = false;
                            this.spinnerShow = false;
                            if (this.flowerArrayFlag && this.oilArrayFlag && this.capsuleArrayFlag && this.milledArrayFlag) {
                                sessionStorage.removeItem('selectMultipleCondition');
                                sessionStorage.removeItem('timeofdayused');
                                sessionStorage.removeItem('primaryReason');
                                localStorage.removeItem('currentPage');
                                sessionStorage.removeItem("thcData");
                                sessionStorage.removeItem("cbdData");
                                sessionStorage.removeItem("selectedProductDataList");
                                sessionStorage.removeItem('selectedProductDetail');
                                sessionStorage.removeItem('reviewLogDetail');
                                this.spinnerShow = false;
                                this.router.navigate(['review-thanks']);
                            }
                        }, (err) => {
                            this.spinnerShow = false;
                            console.log("drugBusinessService getMasterInfoDetail", err);
                        });
                        this.spinnerShow = false;
                    }
                }, (err) => {
                    this.spinnerShow = false;
                    console.log("drugBusinessService getProductListBasedOnThc_Cbd_Value", err);
                });

            } else {
                sessionStorage.removeItem('selectMultipleCondition');
                sessionStorage.removeItem('timeofdayused');
                sessionStorage.removeItem('primaryReason');
                localStorage.removeItem('currentPage');
                sessionStorage.removeItem("thcData");
                sessionStorage.removeItem("cbdData");
                sessionStorage.removeItem("selectedProductDataList");
                sessionStorage.removeItem('selectedProductDetail');
                sessionStorage.removeItem('reviewLogDetail');
                this.spinnerShow = false;
                this.router.navigate(['review-thanks']);
            }
        } else {
            this.spinnerShow = false;
            this.router.navigate(['landing-page']);
        }

    }

    onViewProduct(profileType: string, selectedIndex: any, selectedProductData: any) {
        this.infoAlert = false;
        this.selectedIndex = selectedIndex;
        this.selectedProductData = selectedProductData;
        this.selectedProfileType = profileType;
        if(this.selectedProductData.data.Product_In_Stock == true){
            this.stockRange ='In stock'
        }else{
            this.stockRange ='Out of stock'
        }

        //return this.modal.open(this.viewProduct, overlayConfigFactory({ dialogClass: 'modal-dialog modal-dialog-addproduct' }, BSModalContext))
        return this.modal.open(this.viewProduct, overlayConfigFactory({ isBlocking: false, dialogClass: 'modal-dialog modal-upload-task' }, BSModalContext))
            .then(dialog => {
                this.dialog = dialog;
            })
    }

    productsNextSubmit(event: Event) {
        if (this.selectedProductDataList.length > 0) {
            this.infoAlert = false;
            sessionStorage.setItem("selectedProductDataList", JSON.stringify(this.selectedProductDataList));
            this.router.navigate(['summary-page']);
        } else {
            this.infoAlert = true;
        }

    }

    addToWishList(profileType: string, selectedIndex: any, selectedProductData: any) {
        this.infoAlert = false;
        let alreadyAddOrNot: boolean = false;
        if (profileType == "flower") {
            this.flowerArray[selectedIndex].Checked = true;
        } else if (profileType == "oil") {
            this.oilArray[selectedIndex].Checked = true;
        } else if (profileType == "capsule") {
            this.capsuleArray[selectedIndex].Checked = true;
        } else if (profileType == "milled") {
            this.milledArray[selectedIndex].Checked = true;
        }

        for (let selectedProductDataListData of this.selectedProductDataList) {
            if (selectedProductDataListData.productId == selectedProductData.data.Product_Id) {
                alreadyAddOrNot = true;
            }
        }

        if (!alreadyAddOrNot) {
            this.selectedProductDataList.push({ "Id": selectedIndex, "productId": selectedProductData.data.Product_Id, "data": selectedProductData });
            this.dialog.close();
        } else {
            this.dialog.close();
        }


    }
    onClose(){
        this.dialog.close();
    }

}