import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';


const buttonNext = [
  {
    "id": 1,
    "buttonName": "NEXT"
  }
];



@Component({
  selector: 'app-primaryReasonPage',
  templateUrl: './primaryReason-page.component.html',
  styleUrls: ['./primaryReason-page.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class PrimaryReasonPageComponent {
  public btnNextData = buttonNext;
  public isGuest: boolean = false;
  private temp: any;
  private userType: any;
  private prdArr: any[] = [];
  public primaryReason: any = [];
  public infoAlert: boolean = false;
  public selectedCondition: string = "";
  public previousSelctedValue: number = -1;
  public spinnerShow: boolean = false

  constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) {
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {
    this.spinnerShow=true;
    if (!sessionStorage.getItem('selectMultipleCondition') && !sessionStorage.getItem('timeofdayused')) {
     this.router.navigate(['review-thanks']);
     this.spinnerShow=false;
     return false;
    }
    if (sessionStorage.getItem("primaryReason")) {
      this.selectedCondition = sessionStorage.getItem("primaryReason");
    }
    this._db.getMasterInfoDetail().subscribe(res => {
      this.primaryReason = [];
      let status: boolean = false;
      for (let i = 0; i < res.UsageReasons.length; i++) {
        if (this.selectedCondition == res.UsageReasons[i].Title) {
          this.previousSelctedValue=i;
          status = true;
        } else {
          status = false
        }
        this.primaryReason.push(
          {
            "id": res.UsageReasons[i].Id,
            "buttonName": res.UsageReasons[i].Title,
            "status": status
          });
      }
      this.spinnerShow=false;
    });
    }else{
     this.spinnerShow=false; 
     this.router.navigate(['landing-page']);
    }
  }
  
  timesNextSubmit(event: Event) {
    if (this.selectedCondition != "") {
      sessionStorage.setItem("primaryReason", this.selectedCondition);
      this.router.navigate(['ourRecommendation-page']);
    } else {
      sessionStorage.removeItem("primaryReason");
      this.infoAlert = true;
    }
  }


  selectConditionSubmit(selectedIndex: any) {
    var getStatus = this.primaryReason[selectedIndex].status;
    this.primaryReason[selectedIndex].status = true;
    this.infoAlert = false;
    var getStatus = this.primaryReason[selectedIndex].status;
    var getID = this.primaryReason[selectedIndex].id;
    this.selectedCondition = this.primaryReason[selectedIndex].buttonName;
    if (this.previousSelctedValue == Number(selectedIndex)) {
      this.primaryReason[selectedIndex].status = true
    } else {
      this.primaryReason[selectedIndex].status = true;
      this.previousSelctedValue != -1 ? this.primaryReason[this.previousSelctedValue].status = false : '';
      this.previousSelctedValue = selectedIndex;
    }
  }

}