import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { SharedObserverService } from '../../../../shared/shared-service-module/shared-observer.service';
import { ReviewProductEntity } from '../../entity/reviewProduct.entity';


const buttonNext = [
  {
    "id": 1,
    "buttonName": "SKIP"
  }
];


@Component({
  selector: 'app-reviewStrainPage',
  templateUrl: './reviewStrain-page.component.html',
  styleUrls: ['./reviewStrain-page.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config, SharedObserverService]
})
export class ReviewStrainPageComponent {
  public btnNextData = buttonNext;
  public masterData: any;
  public lastUsedProductList: any;
  public flowerArray: any[] = [];
  public oilArray: any[] = [];
  public capsuleArray: any[] = [];
  public milledArray: any[] = [];
  public flowerText = this.config.FLOWER;
  public oilText = this.config.OIL;
  public capsuleText = this.config.CAPSULE;
  public milledText = this.config.MILLED;
  public flowerTexts = this.config.FLOWERS;
  public oilTexts = this.config.OILS;
  public capsuleTexts = this.config.CAPSULES;
  public milledTexts = this.config.MILLEDS;
  public spinnerShow: boolean = false;
  public flowerArrayFlag: boolean = false;
  public oilArrayFlag: boolean = false;
  public capsuleArrayFlag: boolean = false;
  public milledArrayFlag: boolean = false;
  public noData = this.config.noData;
  public reviewProductEntity: ReviewProductEntity;
  //router
  public isGuest: boolean = false;
  private temp: any;
  private userType: any;
  private wholeDetail: boolean = false;
  constructor(private config: Config, private drugBusinessService: DrugBusinessService, private sharedObserverService: SharedObserverService, private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute) {
    localStorage.setItem('currentPage', "reviewStrainpage");
  }

  ngOnInit() {
    if (localStorage.getItem('token')) {
      this.wholeDetail = false;
      //patient_lname  patient_fname
      sessionStorage.removeItem("selectMultipleCondition");
      sessionStorage.removeItem("timeofdayused");
      sessionStorage.removeItem("primaryReason");
      localStorage.removeItem('fromReviewOrSkipReviewPage');
      sessionStorage.removeItem('selectedProductDetail');
      sessionStorage.removeItem('reviewLogDetail');
      sessionStorage.removeItem("thcData");
      sessionStorage.removeItem("cbdData");
      var paramValue = localStorage.getItem('usertype');
      this.spinnerShow = true;
      if (paramValue == 'user') {
        this.reviewProductEntity = {
          log_ID: 0,
          patient_ID: Number(localStorage.getItem('patient_id')),
          product_ID: "",
          conditions: "",
          intake: "",
          positive_Effects: "",
          positive_Comments: "",
          negative_Effects: "",
          negative_Comments: "",
          effectiveness: 50,
          side_Effects: 50
        }
        sessionStorage.setItem('reviewLogDetail', JSON.stringify(this.reviewProductEntity));
        this.drugBusinessService.getPreviousUsedStrainByPatientId().subscribe(res => {
          this.lastUsedProductList = res;
          if (this.lastUsedProductList) {
            for (let lastUsedProductListData of this.lastUsedProductList) {
              if (lastUsedProductListData.Profile == this.config.FLOWER) {
                this.flowerArray.push(lastUsedProductListData);
              } else if (lastUsedProductListData.Profile == this.config.OIL) {
                this.oilArray.push(lastUsedProductListData);
              } else if (lastUsedProductListData.Profile == this.config.CAPSULE) {
                this.capsuleArray.push(lastUsedProductListData);
              } else if (lastUsedProductListData.Profile == this.config.MILLED) {
                this.milledArray.push(lastUsedProductListData);
              }
            }
            this.flowerArray.length == 0 ? this.flowerArrayFlag = true : this.flowerArrayFlag = false;
            this.oilArray.length == 0 ? this.oilArrayFlag = true : this.oilArrayFlag = false;
            this.capsuleArray.length == 0 ? this.capsuleArrayFlag = true : this.capsuleArrayFlag = false;
            this.milledArray.length == 0 ? this.milledArrayFlag = true : this.milledArrayFlag = false;
            this.spinnerShow = false;
            if (this.flowerArrayFlag && this.oilArrayFlag && this.capsuleArrayFlag && this.milledArrayFlag) {
              this.wholeDetail = true;
            }
          }

        }, (err) => {
          this.spinnerShow = false;
          console.log("drugBusinessService getPreviousUsedStrainByPatientId", err);
        });
        var fname = localStorage.getItem('patient_fname');
        this.userType = fname;
        this.isGuest = true;
        console.log(this.isGuest);
      } else if (paramValue == "guest") {
        this.isGuest = false;
        this.userType = "GUEST";
      } else {
        console.log("Unkonwn");
      }
    } else {
      this.spinnerShow = false;
      this.router.navigate(['landing-page']);
    }
  }

  onView(individualProductData: any) {
    localStorage.setItem("fromReviewOrSkipReviewPage", "fromreview");
    sessionStorage.setItem("selectedProductDetail", JSON.stringify(individualProductData));
    this.router.navigate(['guestHome-page']);
  }

  productsNextSubmit(event: Event) {
    localStorage.setItem("fromReviewOrSkipReviewPage", "skipreview");
    this.router.navigate(['guestHome-page']);
  }


}