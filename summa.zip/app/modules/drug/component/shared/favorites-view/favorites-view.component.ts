import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, Input, Output, EventEmitter, TemplateRef, ViewChild, ViewContainerRef, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
	selector: 'favorites-view',
	templateUrl: './favorites-view.component.html',
	styleUrls: ['./favorites-view.component.scss']
})
export class FavoriteViewComponent implements OnInit {

	@Input() value: any;
	@Input() addToFavData: any;
	@Output() onClose = new EventEmitter();
	@Output() favBtnClick = new EventEmitter();


	constructor(private layoutComponent: LayoutComponent, private router: Router) {

	}

	ngOnInit() { }

	dialogClosed() {
		this.layoutComponent.showSpinner(true);
		this.onClose.emit(this);
	}

	addToFavorite(id: number, isFav: boolean) {
		//this.dialogClosed();
		this.layoutComponent.showSpinner(true);
		let data = {
			id: id,
			isFav: isFav,
			thisData:this
		};
		this.favBtnClick.emit(data);
	}

	supplierSubmit(supplierData:any) {
		this.dialogClosed();
		this.layoutComponent.showSpinner(true);
		let self = this;
		setTimeout(()=> {
			this.layoutComponent.showSpinner(false);
			self.router.navigate(['/suppliers/supplierlist/'+supplierData.LP_Id]);
		}, 10);
	}

}