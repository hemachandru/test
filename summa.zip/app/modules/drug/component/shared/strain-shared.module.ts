import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FavoriteViewComponent } from './favorites-view/favorites-view.component';

@NgModule({
    imports: [
        CommonModule
    ],
    exports: [FavoriteViewComponent],
    declarations: [FavoriteViewComponent],
    providers: [],
})
export class StrainSharedModule { }
