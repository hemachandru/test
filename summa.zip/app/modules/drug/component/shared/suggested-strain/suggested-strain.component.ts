import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Config } from '../../../../../config/constant';
@Component({
    selector: 'app-suggested-strain',
    templateUrl: './suggested-strain.component.html',
    styleUrls: ['./suggested-strain.component.scss']
})
export class SuggestedStrainComponent {

    @Input() flowerArrayDataDetail: any;
    @Input() oilArrayDataDetail: any;
    @Input() capsuleArrayDataDetail: any;
    @Input() milledArrayDataDetail: any;
    @Output() viewIndividualStrain = new EventEmitter();
     public flowerText = this.config.FLOWERS;
    public oilText = this.config.OILS;
    public capsuleText = this.config.CAPSULES;
    public milledText = this.config.MILLED;
    constructor(private sanitizer: DomSanitizer,private config:Config ) {
    }
    suggestedSubmit(viewStraindata: any) {
        this.viewIndividualStrain.emit(viewStraindata);
    }
}