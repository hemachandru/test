import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";

import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { ReviewProductEntity } from '../../entity/reviewProduct.entity';
const buttonLogout = [
  {
    "id": 1,
    "buttonName": "LOG OUT"
  }
];

const buttonNext = [
  {
    "id": 1,
    "buttonName": "NEXT"
  }
];

const buttonSession = [
  {
    "id": 1,
    "buttonName": "REVIEW ANOTHER PRODUCT",
    "status": false
  },
  {
    "id": 2,
    "buttonName": "GO TO STRAIN SELECTOR",
    "status": false
  },
  {
    "id": 3,
    "buttonName": "GO TO YOUR LOG",
    "status": false
  }
];

const buttonSession1 = [
  {
    "id": 2,
    "buttonName": "GO TO STRAIN SELECTOR",
    "status": false
  }
];

@Component({
  selector: 'app-reviewThanks',
  templateUrl: './review-thanks.component.html',
  styleUrls: ['./review-thanks.component.scss'],
  providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class ReviewThanksComponent {
  public btnData = buttonLogout;
  public btnNextData = buttonNext;
  public isGuest: boolean = false;
  public reviewProductEntity: ReviewProductEntity;
  public productdata = buttonSession;
  private temp: any;
  private userType: any;
  private prdArr: any[] = [];
  private userOrGuest: string = "";
  private reviewOrGuestLogin: boolean = false;

  //router
  constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) { }

  ngOnInit() {
    if (localStorage.getItem('token')) {
      this.userOrGuest = localStorage.getItem('usertype');
      if (localStorage.getItem("fromReviewOrSkipReviewPage") == 'fromreview' && this.userOrGuest == 'user') {
        this.reviewOrGuestLogin = true;
        this.reviewProductEntity = JSON.parse(sessionStorage.getItem("reviewLogDetail"));
        let positiveEffect: any = [];
        let negativeEffects: any = [];
        let tempPositiveEffects: any = [];
        let tempNegativeEffects: any = [];
        tempPositiveEffects = this.reviewProductEntity.positive_Effects;
        tempNegativeEffects = this.reviewProductEntity.negative_Effects;
        for (let i = 0; i < tempPositiveEffects.length; i++) {
          positiveEffect.push(tempPositiveEffects[i].positiveEffects);
        }
        for (let i = 0; i < tempNegativeEffects.length; i++) {
          negativeEffects.push(tempNegativeEffects[i].negativeEffects);
        }
        this._db.addOrUpdateCannabisLog(this.reviewProductEntity, positiveEffect.toString(), negativeEffects.toString()).subscribe(res => {
          if (res.Response_Code == 1) {
            localStorage.removeItem('fromReviewOrSkipReviewPage');
            sessionStorage.removeItem('selectedProductDetail');
            sessionStorage.removeItem('reviewLogDetail');
            localStorage.removeItem('currentPage');
          }
        }, (err) => {
          console.log("_db addOrUpdateCannabisLog" + err);
        });
      } else if (localStorage.getItem("fromReviewOrSkipReviewPage") == 'skipreview' && this.userOrGuest == 'user') {
        this.productdata = buttonSession;
        this.reviewOrGuestLogin = false;
      } else if (localStorage.getItem("fromReviewOrSkipReviewPage") == 'skipreview' && this.userOrGuest == 'guest') {
        this.reviewOrGuestLogin = false;
        this.productdata = buttonSession1;
      }
      var paramValue = localStorage.getItem('usertype')
      if (paramValue == 'user') {
        var fname = localStorage.getItem('patient_fname');
        this.userType = fname;
        this.isGuest = true;
        console.log(this.isGuest);
      } else if (paramValue == "guest") {
        this.isGuest = false;
        this.userType = "GUEST";
      } else {
        console.log("Unkonwn");
      }
    } else {
      this.router.navigate(['landing-page']);
    }
  }

  logoutSubmit(event: Event) {
    this._ls.display(false);
    this.router.navigate(['landing-page']);
  }
  //router

  selectConditionSubmit(event: any) {
    var getVal = this.productdata[event].id;
    if (getVal == 1) {
      this.router.navigate(['reviewStrain-page']);
    } else if (getVal == 2) {
      localStorage.setItem("fromReviewOrSkipReviewPage","skipreview")
      this.router.navigate(['guestHome-page']);
    } else if (getVal == 3) {
      console.log('third');
      this.router.navigate(['gotoLog-page']);
    } else {
      console.log('error');
    }


  }

}