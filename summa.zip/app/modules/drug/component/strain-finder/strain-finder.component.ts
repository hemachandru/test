import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, HostListener } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { ISlimScrollOptions } from 'ng2-slimscroll';
//import { LayoutBusiness } from '../../../layout/business/layout.business';
import { SharedObserverService } from "../../../../shared/shared-service-module/shared-observer.service";
import { LayoutComponent } from "../../../layout/component/layout.component";
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from 'angular-2-dropdown-multiselect';
import { DrugBusinessService } from '../../business/drug.business';
import { Config } from '../../../../config/constant';
@Component({
  templateUrl: './strain-finder.component.html',
  styleUrls: ['./strain-finder.component.scss']
})
export class StrainFinderComponent implements OnInit {

  public opts: ISlimScrollOptions;
  public masterInfoData: any;
  public medicalCondition: any;
  public dayTimes: any;
  private usageReasons: any;
  public medicalConditionArray: any = [];
  myOptions: IMultiSelectOption[];
  public tempMyOptions: any = [];
  mySettings: IMultiSelectSettings;
  myTexts: IMultiSelectTexts;
  public dayTimesText: any = "";
  private usageReasonsText: any = "";
  private selectedItems: any = [];
  private showHideButton: boolean = false;
  private cbdValueData: any;
  private thcValuesData: any
  private recomendedStrainDetailData: any;
  public flowerArray: any[] = [];
  public oilArray: any[] = [];
  public capsuleArray: any[] = [];
  public milledArray: any[] = [];
  public noStrainFlag: boolean = false;
  public noCbdThcStrainFlag: boolean = false;
  public noCbdThcValueNotFoundFlag: boolean = false;
  public firstcbdValue = "";
  public lastcbdValue = "";
  public firstTHCValue = "";
  public lastTHCValue = "";
  private searchStrainName: any;
  private searchFlagOnOff = false;
  private noStrain=this.config.noStrain;
  private basedOnConditionStrainList=this.config.basedOnConditionStrainList;
  private basedOnConditionNoStrainList=this.config.basedOnConditionNoStrainList;
  private findyourstrain:any=this.config.findyourstrain;

  @HostListener("removeEventListener", ["$event"])
  public onClick(event: any): void {
    event.stopPropagation();
  }



  constructor(private config: Config, private drugBusinessService: DrugBusinessService, private layoutComponent: LayoutComponent, private _sos: SharedObserverService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
    overlay.defaultViewContainer = vcRef;
  }
  ngOnInit() {
    this.layoutComponent.showSpinner(true);
    this.mySettings = {
      enableSearch: false,
      checkedStyle: 'checkboxes',
      buttonClasses: 'multiSelectbtn',
      dynamicTitleMaxItems: 0,
      maxHeight: '200px',
      containerClasses: 'dropdown-inline'
    };

    this.myTexts = {
      defaultTitle: 'Select MedicalCondition',
      checked: 'Selected',
      checkedPlural:'Selected'
    };

    this.opts = {
      position: 'right',
      barBackground: '#4f4f4f',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    }

    this._sos.eventReceiver$.subscribe(res => {
      if (res != true) {
        this.masterInfoData = res;
        this.medicalCondition = res.MedicalConditions;
        for (let medicalConditionsData of res.MedicalConditions) {
          this.tempMyOptions.push({ id: Number(medicalConditionsData.Id), name: String(medicalConditionsData.Title) });
        }
        this.myOptions = this.tempMyOptions;
        this.dayTimes = res.DayTimes;
        this.usageReasons = res.UsageReasons;
      }
      this.layoutComponent.showSpinner(false);
    });
  }

  onMedicalChange(event: any) {
    this.enableButton();
  }

  onDayTimesChange(onDayTimes: any) {
    this.dayTimesText = onDayTimes;
    this.enableButton();
  }

  onReasonChange(onReasonChange: any) {

    this.usageReasonsText = onReasonChange;
    this.enableButton();
  }

  enableButton() {
    if (this.usageReasonsText != "" && this.dayTimesText != "" && this.selectedItems.length > 0) {
      this.showHideButton = true;
      return false;
    }
    this.showHideButton = false;
  }

  getRecomendedStrain() {
    this.layoutComponent.showSpinner(true);
    let medicationArray: any = [];
    let strMedicationArray: any = this.selectedItems.map(String);
    this.tempMyOptions.forEach(function (item: any) {
      if (strMedicationArray.indexOf(String(item.id)) != -1) {
        medicationArray.push(item.name);
      }
    });
    this.drugBusinessService.getMedConditionRecomendation_Thc_Cbd_Value(medicationArray.toString(), Number(localStorage.getItem('mvcUserId'))).subscribe(res => {
      this.noCbdThcValueNotFoundFlag = false;
      let thcValues = "";
      let cbdValue = "";
      let medicalSystemRecord: any;
      let medicalRecordClinic: any;
      if (res.MED_REC_SYS.length > 0 && res.MED_REC_SYS[0].THC != "" && res.MED_REC_SYS[0].CBD != "") {
        medicalSystemRecord = res.MED_REC_SYS[0];
        thcValues = res.MED_REC_SYS[0].THC;
        cbdValue = res.MED_REC_SYS[0].CBD;
      } else if (res.MED_REC_Clinic.length > 0 && res.MED_REC_Clinic[0].MorningTHC != "" && res.MED_REC_Clinic[0].MorningCBD != "") {
        this.firstcbdValue = "";
        this.lastcbdValue = "";
        this.firstTHCValue = "";
        this.lastTHCValue = "";
        medicalRecordClinic = res.MED_REC_Clinic[0];
        let timeOfDayUsed = this.dayTimesText;

        switch (timeOfDayUsed) {
          case "MORNING": {
            thcValues = medicalRecordClinic.MorningTHC;
            cbdValue = medicalRecordClinic.MorningCBD;
            break;
          }
          case "AFTERNOON": {
            thcValues = medicalRecordClinic.AfterNoonTHC;
            cbdValue = medicalRecordClinic.AfterNoonCBD;
            break;
          }
          case "EVENING": {
            thcValues = medicalRecordClinic.EveningTHC;
            cbdValue = medicalRecordClinic.EveningCBD;
            break;
          }
          case "NIGHT": {
            thcValues = medicalRecordClinic.NightTHC;
            cbdValue = medicalRecordClinic.NightCBD;
            break;
          }
        }
      } else if (res.MED_REC_SYS.length == 0 && res.MED_REC_Clinic.length == 0) {
        this.noCbdThcValueNotFoundFlag = true;
        this.layoutComponent.showSpinner(false);
        return false;
      }
      this.noCbdThcStrainFlag = true;
      let indexCbdValue = cbdValue.indexOf('-');
      this.firstcbdValue = cbdValue.substring(0, indexCbdValue).trim();
      this.lastcbdValue = cbdValue.substring(indexCbdValue + 1, cbdValue.length).trim();
      cbdValue = parseInt(this.firstcbdValue).toString() + - +parseInt(this.lastcbdValue).toString();


      let indexThcValue = thcValues.indexOf('-');
      this.firstTHCValue = thcValues.substring(0, indexThcValue).trim();
      this.lastTHCValue = thcValues.substring(indexThcValue + 1, thcValues.length).trim();
      thcValues = parseInt(this.firstTHCValue).toString() + - +parseInt(this.lastTHCValue).toString();
      this.cbdValueData = cbdValue;
      this.thcValuesData = thcValues;
      this.getRecommendedProductBasedOnThc_Cbd_Value(this.firstTHCValue, this.lastTHCValue, this.firstcbdValue, this.lastcbdValue);
    }, (err) => {
      this.layoutComponent.showSpinner(false);
      console.log("drugBusinessService getMedConditionRecomendation_Thc_Cbd_Value", err);
    });
  }

  getRecommendedProductBasedOnThc_Cbd_Value(firstTHCValueData: any, lastTHCValueData: any, firstcbdValueData: any, lastcbdValueData: any, productName?: any) {
    this.drugBusinessService.getProductListBasedOnThc_Cbd_Value(8, Number(0), Number(firstTHCValueData), Number(lastTHCValueData), Number(firstcbdValueData), Number(lastcbdValueData), productName).subscribe(res => {
      let recomendedProductList: any = res;
      this.recomendedStrainDetailData = res;
      this.flowerArray = [];
      this.oilArray = [];
      this.capsuleArray = [];
      this.milledArray = [];
      if (recomendedProductList) {
        let productTypes = this.masterInfoData.ProductTypes;
        let productProfiles = this.masterInfoData.ProductProfiles;
        let status: boolean = false;
        for (let recomendedProductListtData of recomendedProductList) {
          let profileType = productProfiles.filter((data: any) => {
            return Number(data.Id) == Number(recomendedProductListtData.Profile);
          });
          let productTypesData = productTypes.filter((data: any) => {
            return Number(data.Id) == Number(recomendedProductListtData.Product_Type);
          });

          if (profileType[0].Type == this.config.FLOWER) {
            this.flowerArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData });
          } else if (profileType[0].Type == this.config.OIL) {
            this.oilArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData });
          } else if (profileType[0].Type == this.config.CAPSULE) {
            this.capsuleArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData });
          } else if (profileType[0].Type == this.config.MILLED) {
            this.milledArray.push({ "data": recomendedProductListtData, "productTypesData": productTypesData });
          }
        }

        if (this.flowerArray.length == 0 && this.oilArray.length == 0 && this.capsuleArray.length == 0 && this.milledArray.length == 0) {
          this.noStrainFlag = true;
        }else{
          this.noStrainFlag = false;
        }
        this.layoutComponent.showSpinner(false);
      } else {
        this.noCbdThcValueNotFoundFlag = true;
        this.layoutComponent.showSpinner(false);
        return false;
      }
    }, (err) => {
      this.layoutComponent.showSpinner(false);
      console.log("drugBusinessService getProductListBasedOnThc_Cbd_Value", err);
    });
  }

  onEnter(enterValue: string) {

    this.layoutComponent.showSpinner(true);
    if (enterValue.trim().length == 0 && !this.searchFlagOnOff) {
      this.layoutComponent.showSpinner(false);
      return false;
    }
    if (enterValue.trim().length >= 3) {
      setTimeout(() => {
        this.searchFlagOnOff = true;
        this.getRecommendedProductBasedOnThc_Cbd_Value(this.firstTHCValue, this.lastTHCValue, this.firstcbdValue, this.lastcbdValue, enterValue);
      }, 3000);
    } else {
      if (enterValue.trim().length == 0 && this.searchFlagOnOff) {
        setTimeout(() => {
          this.searchFlagOnOff = false;
          this.getRecommendedProductBasedOnThc_Cbd_Value(this.firstTHCValue, this.lastTHCValue, this.firstcbdValue, this.lastcbdValue, null)
        }, 3000);
      } else {
        this.layoutComponent.showSpinner(false);
      }
    }
  }

}