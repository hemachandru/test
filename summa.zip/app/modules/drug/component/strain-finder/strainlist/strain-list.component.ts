import { Observable } from 'rxjs/Observable';
import { Component, OnInit, Inject, TemplateRef, ViewChild, ViewContainerRef, ElementRef, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Overlay, overlayConfigFactory, DialogRef, ModalComponent, CloseGuard } from 'angular2-modal';
import { Modal, BSModalContext } from 'angular2-modal/plugins/bootstrap';
import { DrugBusinessService } from '../../../business/drug.business';
import { SharedObserverService } from "../../../../../shared/shared-service-module/shared-observer.service";
import { LayoutComponent } from "../../../../layout/component/layout.component";
@Component({
	selector: 'strain-list',
	templateUrl: './strain-list.component.html',
	styleUrls: ['./strain-list.component.scss']
})
export class StrainListComponent implements OnInit {

	@ViewChild('viewStrainInfo') public viewStrainInfo: TemplateRef<any>;
	dialog: DialogRef<any>;

	@Input() flowerArrayData: any;
	@Input() oilArrayData: any;
	@Input() capsuleArrayData: any;
	@Input() milledArrayData: any;
	private individualProductData: any;
	private productTypes: any;
	private product_Id: any;
	private data: any = [];

	constructor(private layoutComponent:LayoutComponent, private _sos: SharedObserverService, private drugBusinessService: DrugBusinessService, overlay: Overlay, vcRef: ViewContainerRef, public modal: Modal, private router: Router, private el: ElementRef) {
		overlay.defaultViewContainer = vcRef;
	}

	ngOnInit() { }

	viewStrain(viewProductData: any) {
		this.layoutComponent.showSpinner(true);
		this.data.product_id = viewProductData.data.Product_Id;
		this.product_Id = viewProductData.data.Product_Id;
		this._sos.eventReceiver$.subscribe(res => {
			if (res != true) {
				this.productTypes = res.ProductTypes;
				this.indivudualStrainDetail(this.data, this.productTypes);
			}else{
				this.layoutComponent.showSpinner(false);
			}
		});
	}

	indivudualStrainDetail(data: any, productTypes: any) {
		this.drugBusinessService.getStrainDetail(data, productTypes).subscribe(res => {
			this.individualProductData = res;
			this.layoutComponent.showSpinner(false);
			return this.modal.open(this.viewStrainInfo, overlayConfigFactory({ dialogClass: 'modal-dialog' }, BSModalContext)).then(dialog => {
				this.dialog = dialog;
			});
		}, (err) => {
			this.layoutComponent.showSpinner(false);
			console.log("drugBusinessService getStrainDetail", err);
		})
	}

	dialogClosed(evt:any) {
		this.dialog.close();
		evt.layoutComponent.showSpinner(false);
	}

	addFavourites(event: any) {
		let isAddOrRemove = !event.isFav;
		this.drugBusinessService.addOrRemoveFavoriteStrain(event.id, isAddOrRemove).subscribe(res => {
			event.thisData.layoutComponent.showSpinner(false);
			this.layoutComponent.showSpinner(true);
			this.individualProductData.IsFavourite = isAddOrRemove;
			this.data.product_id = this.product_Id;
			this.layoutComponent.showSpinner(false);
		})
	}

}