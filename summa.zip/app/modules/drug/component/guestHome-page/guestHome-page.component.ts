import { Component, Input, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoaderService } from "../../../../shared/shared-loader/shared-loader.service";
import { DrugBusinessService } from "../../business/drug.business"
import { DrugService } from '../../service/drug.service';
import { Config } from '../../../../config/constant';
import { HttpRequestService } from '../../../../shared/shared-service/http-request.service';
import { ReviewProductEntity } from '../../entity/reviewProduct.entity';

import { ISlimScrollOptions } from 'ng2-slimscroll';

const buttonNext = [
    {
        "id": 1,
        "buttonName": "NEXT"
    }
];

@Component({
    selector: 'app-guestHomePage',
    templateUrl: './guestHome-page.component.html',
    styleUrls: ['./guestHome-page.component.scss'],
    providers: [DrugBusinessService, DrugService, HttpRequestService, Config]
})
export class GuestHomePageComponent {
    public btnNextData = buttonNext;
    public isGuest: boolean = false;
    public medicalData: any = [];
    private temp: any;
    private userType: any;
    private prdArr: any[] = [];
    private previousSelctedValue: number = -1;
    private selectedCondition: string = "";
    private infoAlert: boolean = false;
    public reviewProductEntity: ReviewProductEntity;
    public spinnerShow: boolean = false;
    public userOrGuest: string = "";
    public guestOrLogin: boolean = false;
    public tempMedicalConditionData: any = [];
    public tempGuestMedicalData: any = [];
    
    public opts: ISlimScrollOptions;

    //router
    constructor(private _ls: LoaderService, private router: Router, private routeParam: ActivatedRoute, private _db: DrugBusinessService) { }

    ngOnInit() {
        if (localStorage.getItem('token')) {
            this.reviewProductEntity = {
                log_ID: 0,
                patient_ID: 0,
                product_ID: "",
                conditions: "",
                intake: "",
                positive_Effects: "",
                positive_Comments: "",
                negative_Effects: "",
                negative_Comments: "",
                effectiveness: 50,
                side_Effects: 50
            }
            var paramValue = localStorage.getItem('usertype')
            this.userOrGuest = paramValue;
            if (!localStorage.getItem("fromReviewOrSkipReviewPage") && this.userOrGuest == 'user') {
                this.router.navigate(['reviewStrain-page']);
                return false;
            } else if (localStorage.getItem("fromReviewOrSkipReviewPage") == "fromreview" && this.userOrGuest == 'user') {
                this.guestOrLogin = true;
                this.reviewProductEntity = JSON.parse(sessionStorage.getItem("reviewLogDetail"));
                this.reviewProductEntity.log_ID = 0;
                this.reviewProductEntity.patient_ID != 0 ? this.reviewProductEntity.patient_ID = this.reviewProductEntity.patient_ID : 0;
                this.reviewProductEntity.product_ID != "" ? this.reviewProductEntity.product_ID = this.reviewProductEntity.product_ID : '';
                this.reviewProductEntity.conditions != "" ? this.reviewProductEntity.conditions = this.reviewProductEntity.conditions : '';
                this.selectedCondition = this.reviewProductEntity.conditions;
                this.reviewProductEntity.intake != "" ? this.reviewProductEntity.intake = this.reviewProductEntity.intake : '';
                this.reviewProductEntity.positive_Effects != "" ? this.reviewProductEntity.positive_Effects = this.reviewProductEntity.positive_Effects : '';
                this.reviewProductEntity.positive_Comments != "" ? this.reviewProductEntity.positive_Comments = this.reviewProductEntity.positive_Comments : '';
                this.reviewProductEntity.negative_Effects != "" ? this.reviewProductEntity.negative_Effects = this.reviewProductEntity.negative_Effects : '';
                this.reviewProductEntity.negative_Comments != "" ? this.reviewProductEntity.negative_Comments = this.reviewProductEntity.negative_Comments : '';
                this.reviewProductEntity.effectiveness != 0 ? this.reviewProductEntity.effectiveness = this.reviewProductEntity.effectiveness : '';
                this.reviewProductEntity.side_Effects != 0 ? this.reviewProductEntity.side_Effects = this.reviewProductEntity.side_Effects : '';
            } else if (localStorage.getItem("fromReviewOrSkipReviewPage") == "skipreview" && (this.userOrGuest == 'user' || this.userOrGuest == 'guest')) {
                sessionStorage.removeItem('reviewLogDetail');
                localStorage.setItem("currentPage", 'guestHomePage');
                this.guestOrLogin = false;
                if (sessionStorage.getItem("selectMultipleCondition")) {
                    this.tempMedicalConditionData = JSON.parse(sessionStorage.getItem("selectMultipleCondition"));

                    for (let i = 0; i < this.tempMedicalConditionData.length; i++) {
                        this.tempGuestMedicalData.push(this.tempMedicalConditionData[i].medicalCondition);
                    }
                }

            }

            this.spinnerShow = true;
            if (paramValue == 'user') {
                var fname = localStorage.getItem('patient_fname');
                //var lname = localStorage.getItem('patient_lname');
                //this.userType="PATIENT X";
                this.userType = fname;
                this.isGuest = true;
                console.log(this.isGuest);
            } else if (paramValue == "guest") {
                this.isGuest = false;
                this.userType = "GUEST";
            } else {
                console.log("Unkonwn");
            }

            //strain list
            this._db.getMasterInfoDetail().subscribe(res => {
                this.medicalData = [];
                let status: boolean = false;
                for (let i = 0; i < res.MedicalConditions.length; i++) {

                    if (localStorage.getItem("fromReviewOrSkipReviewPage") == "fromreview" && this.userOrGuest == 'user') {
                        if (this.selectedCondition == res.MedicalConditions[i].Title) {
                            status = true;
                            this.previousSelctedValue = i;
                        } else {
                            status = false
                        }
                    } else if (this.userOrGuest == 'guest') {
                        if (this.tempGuestMedicalData.indexOf(res.MedicalConditions[i].Title) != -1) {
                            status = true;
                        } else {
                            status = false
                        }
                    }else if (localStorage.getItem("fromReviewOrSkipReviewPage") == "skipreview" && this.userOrGuest == 'user') {
                        if (this.tempGuestMedicalData.indexOf(res.MedicalConditions[i].Title) != -1) {
                            status = true;
                        } else {
                            status = false
                        }
                    }

                    this.medicalData.push(
                        {
                            "id": res.MedicalConditions[i].Id,
                            "strain": res.MedicalConditions[i].Title,
                            "status": status
                        });
                }
                this.spinnerShow = false;
            }, (err) => {
                console.log("_db getMasterInfoDetail", err);
                this.spinnerShow = false;
            });
        } else {
            this.spinnerShow = false;
            this.router.navigate(['landing-page']);
        }

        this.opts = {
            position: 'right',
            barBackground: 'rgb(173, 181, 189)',
            barBorderRadius: '0',
            barWidth: '4',
            gridWidth: '4',
            gridMargin: '1px 0'
        }
    }


    guestHomeSubmit(event: Event) {
        this.spinnerShow = true;
        if (localStorage.getItem("fromReviewOrSkipReviewPage") == "fromreview") {
            if (this.selectedCondition != "") {
                this.reviewProductEntity.conditions = this.selectedCondition;
                sessionStorage.setItem('reviewLogDetail', JSON.stringify(this.reviewProductEntity));
                this.spinnerShow = false;
                this.router.navigate(['view-product'])
            } else {
                this.spinnerShow = false;
                this.infoAlert = true;
            }

        } else if (!this.guestOrLogin) {
            if (this.tempMedicalConditionData.length > 0) {
                sessionStorage.setItem("selectMultipleCondition", JSON.stringify(this.tempMedicalConditionData));
                this.spinnerShow = false;
                this.router.navigate(['timesUsed-page']);
            } else {
                sessionStorage.removeItem("selectMultipleCondition");
                this.spinnerShow = false;
                this.infoAlert = true;
            }
        }
    }

    selectConditionSubmit(selectedIndex: number) {
        this.infoAlert = false;
        var getStatus = this.medicalData[selectedIndex].status;
        var getID = this.medicalData[selectedIndex].id;
        this.selectedCondition = this.medicalData[selectedIndex].strain;
        if (this.guestOrLogin) {
            if (this.previousSelctedValue == Number(selectedIndex)) {
                this.medicalData[selectedIndex].status = true
            } else {
                this.medicalData[selectedIndex].status = true;
                this.previousSelctedValue != -1 ? this.medicalData[this.previousSelctedValue].status = false : '';
                this.previousSelctedValue = selectedIndex;
            }
        } else if (!this.guestOrLogin) {
            if (getStatus == true) {
                this.medicalData[selectedIndex].status = false;
                for (var index = 0; index < this.tempMedicalConditionData.length; index++) {
                    if ((this.tempMedicalConditionData[index].Id == Number(selectedIndex))) {
                        this.tempMedicalConditionData.splice(Number(index), 1);
                    }
                }
            } else {
                this.medicalData[selectedIndex].status = true;
                let medicalConditionObject = {
                    Id: selectedIndex,
                    medicalCondition: this.medicalData[selectedIndex].strain
                }
                this.tempMedicalConditionData.push(medicalConditionObject);
            }
        }

    }
}