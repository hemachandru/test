import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ViewSuplierComponent } from './component/supplier/viewsuplier/view-suplier.component';
import { SupplierListComponent } from './component/supplier/supplierlist/supplier-list.component';
import { SuplierDetailComponent } from './component/supplier/suplierdetails/details-suplier.component';
import { SupplierStrainComponent } from './component/supplier/supplierstrain/supplier-view.component';
import { SupplierRegistrationComponent } from './component/supplier/supplierregister/supplier-register.component';
import { StrainFinderComponent } from './component/strain-finder/strain-finder.component';
import { SupplierAdminComponent } from "./component/supplier-admin/supplier-admin.component";
import { AddSupplierComponent } from "./component/supplier-admin/add-supplier/add-supplier.component";
import { EditSupplierComponent } from "./component/supplier-admin/edit-supplier/edit-supplier.component";
import { ViewSupplierComponent } from "./component/supplier-admin/view-supplier/view-supplier.component";
import { ViewAllComponent } from './component/supplier-admin/view-supplier/viewall-supplier/viewall.component';
import { EditComponent } from "./component/supplier-admin/view-supplier/edit-view-supplier/edit-view.component";

import { ViewProductComponent } from "./component/view-product/view-product.component";

//import { FavoriteViewComponent } from './shared/favorites-view/favorites-view.component';
//import { SuggestedStrainComponent } from './shared/suggested-strain/suggested-strain.component';

const supplierRoutes: Routes = [
  {
    path: '',
    redirectTo: 'supplierlist',
    pathMatch: 'full',
    component: ViewSuplierComponent
  },
  { path: 'supplierlist', component: SupplierListComponent },
  { path: 'supplierlist/:id', component: SupplierListComponent },
  { path: 'supplierdetails/:id', component: SuplierDetailComponent },
  { path: 'strainsupplier', component: SupplierStrainComponent },
  { path: 'supplierregistration', component: SupplierRegistrationComponent },
  { path: 'strain', component: StrainFinderComponent },
  {
    path: 'supplier-admin',
    children: [
      {
        path: '',
        component: SupplierAdminComponent
      },
      {
        path: 'add-supplier',
        component: AddSupplierComponent
      },
      {
        path: 'edit-supplier',
        component: EditSupplierComponent
      },
      {
        path: 'view-supplier',
        component: ViewSupplierComponent
      },
      {
        path: 'view-all',
        component: ViewAllComponent
      },
      {
        path: 'edit-view',
        component: EditComponent
      },
      {
        path: 'view-product',
        component: ViewProductComponent
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(supplierRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DrugRoutingModule { }
