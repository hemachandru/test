import { NgModule, Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SupplierComponent } from './component/supplier/supplier.component';
import { ViewSuplierComponent } from './component/supplier/viewsuplier/view-suplier.component';
import { SupplierListComponent } from './component/supplier/supplierlist/supplier-list.component';
import { SuplierDetailComponent } from './component/supplier/suplierdetails/details-suplier.component';
import { SupplierStrainComponent } from './component/supplier/supplierstrain/supplier-view.component';
import { SupplierRegistrationComponent } from './component/supplier/supplierregister/supplier-register.component';
import { MyDatePickerModule } from 'mydatepicker';
import { StrainFinderComponent } from './component/strain-finder/strain-finder.component';
import { StrainListComponent } from './component/strain-finder/strainlist/strain-list.component';
import { SupplierAdminComponent } from "./component/supplier-admin/supplier-admin.component";
import { AddSupplierComponent } from "./component/supplier-admin/add-supplier/add-supplier.component";
import { EditSupplierComponent } from "./component/supplier-admin/edit-supplier/edit-supplier.component";
import { ViewSupplierComponent } from "./component/supplier-admin/view-supplier/view-supplier.component";
import { ViewAllComponent } from './component/supplier-admin/view-supplier/viewall-supplier/viewall.component';
import { SharedModule } from "../../shared/sharedmodule/shared.module";
import { SharedServiceModule } from "../../shared/shared-service-module/shared-service.module";
import { EditComponent } from "./component/supplier-admin/view-supplier/edit-view-supplier/edit-view.component";

import { FavoriteViewComponent } from './component/shared/favorites-view/favorites-view.component';
import { SuggestedStrainComponent } from './component/shared/suggested-strain/suggested-strain.component';
import { DrugRoutingModule } from './drug.routing';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SlimScrollModule } from 'ng2-slimscroll';
import { Ng2CompleterModule } from "ng2-completer";
import { EqualValidator } from './component/supplier-admin/validator/equal-validator.directive';
import { StrainSharedModule } from "./component/shared/strain-shared.module";
import { HttpRequestService } from "../../shared/shared-service/http-request.service";
import { Config } from "../../config/constant";
import { DrugBusinessService } from "./business/drug.business";
import { DrugService } from "./service/drug.service";
import { LoaderService } from '../../shared/shared-loader/shared-loader.service';

import {ReviewStrainPageComponent} from "./component/reviewStrain-page/reviewStrain-page.component";
import {GuestHomePageComponent} from "./component/guestHome-page/guestHome-page.component";
import {TimesUsedPageComponent} from "./component/timesUsed-page/timesUsed-page.component";
import {PrimaryReasonPageComponent} from "./component/primaryReason-page/primaryReason-page.component";
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import {ViewProductComponent} from "./component/view-product/view-product.component";
import { NouisliderModule } from 'ng2-nouislider';

@NgModule({
  imports: [
    DrugRoutingModule,
    CommonModule,
    FormsModule,
    Ng2CompleterModule,
    SlimScrollModule,
    MyDatePickerModule,
    SharedServiceModule,
    SharedModule,

    NouisliderModule,
    
    StrainSharedModule,
    MultiselectDropdownModule
  ],
  declarations: [
    SupplierComponent,
    ViewSuplierComponent,
    SupplierListComponent,
    SuplierDetailComponent,
    SupplierStrainComponent,
    SupplierRegistrationComponent,
    StrainFinderComponent,
    StrainListComponent,
    SupplierAdminComponent,
    AddSupplierComponent,
    EditSupplierComponent,
    ViewSupplierComponent,
    EqualValidator,
    ViewAllComponent,
    SuggestedStrainComponent,
    EditComponent,
    ViewProductComponent    
  ],
  providers: [
    HttpRequestService,
    Config,
    LoaderService,
    DrugBusinessService,
    DrugService    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class DrugModule { }