import { Injectable } from '@angular/core';

import { HttpRequestService } from "../../../shared/shared-service/http-request.service";

@Injectable()
export class DrugService {
    constructor(private _http: HttpRequestService) { }

    getMasterInfoDetail(url: string) {
        return this._http.getHttpRequest(url);
    }

    getUserInfo(url: string) {
        return this._http.getHttpRequest(url);
    }

    getAllSupplier(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }

    getSupplierDetails(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }

    getSelectedSupplierProduct(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }

    getAllMedicalDocument(url: string) {
        return this._http.getHttpRequest(url);
    }

    getDocumentDetail(url: string) {
        return this._http.getHttpRequest(url);
    }

    sendMedicalDocument(data: string, url: string) {
        return this._http.putHttpRequest(data, url);
    }
    
    getStrainDetail(url: string) {
        return this._http.getHttpRequest(url);
    }

    getClinicProvincesCities(url: string) {
        return this._http.getHttpRequest(url);
    }

    addOrRemoveFavoriteStrain(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }
    
    /**
     * this service get the last used products with not reviwed  of login patient.
     */
    getPreviousUsedStrainByPatientId(url: string) {
        return this._http.getHttpRequest(url);
    }

    getTopRatedStrain(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }

    GetCannabisLog_all(url: string) {
        return this._http.getHttpRequest(url);
    }
    
    /**
     * this service get the single product detail depend on the product,patient,role
     * @param url 
     */
    getIndividualProductDetailBy_PatientId_ProductId_Role(url: string) {
        return this._http.getHttpRequest(url);
    }
    
    /**
     * 
     * @param data this service add or update addOrUpdateCannabisLog loginpatientuser
     * @param url 
     */
    addOrUpdateCannabisLog(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }
    
    /**
     * this service get the thc and cbd value depends on the medical condition
     * @param url 
     */
    getMedConditionRecomendation_Thc_Cbd_Value(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }
    
    /**
     * this service get the product Based on the thc and cpd value.
     * @param data 
     * @param url 
     */
    getProductListBasedOnThc_Cbd_Value(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }
    
    /**
     * 
     * @param data this service send order product detail to consern lp user
     * @param url 
     */
    sendProductRequestEmailToLPByGuest(data: any, url: string) {
        return this._http.postHttpRequest(data, url);
    }
    
    /**
     * This service send Login Patient Canabislog detail to consern lp user.
     * @param url 
     */
    sendCannabisLogDetailAsEmail(url: string) {
        return this._http.getHttpRequest(url);
    }
}