import { Injectable } from '@angular/core';

import { DrugService } from "../service/drug.service";
import { Config } from "../../../config/constant";

@Injectable()
export class DrugBusinessService {

    constructor(private _ds: DrugService, private _config: Config) { }

    getMasterInfoDetail() {
        return this._ds.getMasterInfoDetail(this._config.getMasterData).map(res => res.json());
    }

    getUserInfo() {
        let url = this._config.userdetailUrl;
        return this._ds.getUserInfo(url).map(res => res.json());
    }

    getAllSupplier(data: any) {
        let url = this._config.getLicenseProducers;
        let params: any = {
            "Search_Code": data.search_code || 4,
            "LP_Id": null,
            "LP_Store_Name": "",
            "ParentClinicID": data.parent_clinic_id || 0,
            "ParentClinicName": "",
            "Location": data.cities || "",
            "ProductType": data.productType || "",
            "ProductName":data.productName || "",
            "FromTHC": data.fromTHC || 0,
            "ToTHC": data.toTHC || 100,
            "FromCBD": data.fromCBD || 0,
            "ToCBD": data.toCBD || 100
        }
        return this._ds.getAllSupplier(params, url).map(res => res.json())
    }

    getSupplierDetails(data: any) {
        let url = this._config.getLicenseProducers;
        let params: any = {
            "Search_Code": 1,
            "LP_Id": data.LP_Id,
            "LP_Store_Name": "",
            "ParentClinicID": 0,
            "ParentClinicName": "",
            "Location": "",
            "ProductType": "",
            "FromTHC": 0,
            "ToTHC": 100,
            "FromCBD": 0,
            "ToCBD": 100
        }
        return this._ds.getSupplierDetails(params, url).map(res => res.json())
    }

    getSelectedSupplierProduct(id: number, masterInfo: any) {
        let url = this._config.getProductList;
        let params: any = {
            "Search_Code": 1,
            "LP_Id": id,
            "Product_Name": null,
            "FromTHC": 0,
            "ToTHC": 0,
            "FromCBD": 0,
            "ToCBD": 0,
            "Profile": null,
            "Product_Type": null,
            "ParentClinicID": 0,
            "IsAutoSuggest": false
        }
        return this._ds.getSelectedSupplierProduct(params, url).map(res => {
            let result = [];
            let data = res.json();
            for (let index = 0; index < data.length; index++) {
                if (data[index].Product_Img_Url != "") {
                    let logo_url = "data:image/jpeg;base64," + data[index].Product_Img_Url;
                    data[index].Product_Img_Url = logo_url;
                }
                for (let i = 0; i < masterInfo.length; i++) {
                    if (data[index].Product_Type == masterInfo[i].Id) {
                        data[index].Product_Type_Name = masterInfo[i].Type;
                        data[index].Product_Type_Color = masterInfo[i].Color;
                    }
                }
            }
            return data;
        })
    }

    getClinicProvincesCities() {
        let url = this._config.getClinicProvincesCities;
        return this._ds.getClinicProvincesCities(url).map(res => {
            let arrObj = res.json();
            let resultObj: any = [];

            for (let index = 0; index < arrObj.length; index++) {
                if (arrObj[index].cities.length > 0) {
                    resultObj.push(...arrObj[index].cities);
                }
            }

            return resultObj;
        })
    }

    getAllMedicalDocument(clinic_id: number) {
        let url = this._config.getAllDocumentUrl + localStorage.getItem('mvcUserId') + '/' + localStorage.getItem('userRole') + '/' + clinic_id + '/' + "'CR','LPD'";
        return this._ds.getAllMedicalDocument(url).map(res => {
            if (res.json().length == 0) {
                return false;
            }

            return res.json()[0];
        })
    }

    getDocumentDetail() {
        let url = this._config.getMedicalDocument;
        return this._ds.getDocumentDetail(url).map(res => res.json())
    }

    sendMedicalDocument(data: any) {
        let url = this._config.updateMedicalDocStatus;
        let params: any = {
            "LP_Id": data.LP_Id,
            "Medical_Doc_Id": data.Medical_Doc_Id,
            "Doc_Status": data.Doc_Status,
            "Medical_Doc_Relation_Id": data.Medical_Doc_Relation_Id,
            "Decline_Notes": "",
            "Not_Verified_Notes": "",
            "Patient_Id": data.Patient_Id,
            "Provider_Id": data.Provider_Id,
            "PatientProductRequests": data.PatientProductRequests || [],
            "IsPrinted": data.IsPrinted || false,
            "Provider_LocalIP": null,
            "Provider_ISPIP": null,
            "LP_ComingFrom": null,
            "Provider_Browser": null,
            "Provider_OSVersion": null,
            "Provider_PCAccount": null
        }
        return this._ds.sendMedicalDocument(params, url).map(res => {
            if (res.json() == "Success") {
                return true;
            }

            return false;
        });
    }

    getStrainDetail(data: any, masterInfo: any) {
        let url = this._config.getProductDetails + data.product_id + "/" + localStorage.getItem('mvcUserId') + "/" + localStorage.getItem('userRole');
        return this._ds.getStrainDetail(url).map(res => {
            let resultObj = res.json();
            let logo_url = (resultObj.Product_Img_Url ? "data:image/jpeg;base64," + resultObj.Product_Img_Url : '');
            resultObj.Product_Img_Url = logo_url;

            for (let i = 0; i < masterInfo.length; i++) {
                if (resultObj.Product_Type == masterInfo[i].Id) {
                    resultObj.Product_Type_Name = masterInfo[i].Type;
                    resultObj.Product_Type_Color = masterInfo[i].Color;
                }
            }

            return resultObj;
        });
    }

    addOrRemoveFavoriteStrain(id: number, isAdd: boolean) {
        let url = this._config.addOrRemoveFavouriteStrains;
        let params = {
            "MvcUserId": localStorage.getItem('mvcUserId'),
            "Role": localStorage.getItem('userRole'),
            "ProductId": id,
            "Action": isAdd ? "add" : "remove"
        }

        return this._ds.addOrRemoveFavoriteStrain(params, url).map(res => res.json());
    }

    /**
     * this service get the last used products with not reviwed  of login patient.
     */
    getPreviousUsedStrainByPatientId() {
        let url = this._config.getProductsUsedByPatient + localStorage.getItem('patient_id') + "/3/" + this._config.Lp_Id;
        return this._ds.getPreviousUsedStrainByPatientId(url).map(res => res.json())
    }


    getTopRatedStrain() {
        let url = this._config.getTopRatedStrain;
        let params: any = {
            "Patient_ID": localStorage.getItem('patient_id'),
            "Medical_Conditions": "",
            "LP_ID": "0"
        }
        return this._ds.getTopRatedStrain(params, url).map(res => res.json())
    }

    GetCannabisLog_all() {
        let url = this._config.GetCannabisLog_all + localStorage.getItem('patient_id') + "/0";
        return this._ds.GetCannabisLog_all(url).map(res => res.json())
    }

    /**
    * this service get the single product detail depend on the product,patient,role
    * @param url 
    */
    getIndividualProductDetailBy_PatientId_ProductId_Role(product_ID: string, patient_Id: string) {
        let url = this._config.getProductDetails + product_ID + "/" + patient_Id + "/" + this._config.patientsRole;
        return this._ds.getIndividualProductDetailBy_PatientId_ProductId_Role(url).map(res => res.json())
    }

    /**
     * 
     * @param data this service add or update addOrUpdateCannabisLog loginpatientuser
     * @param url 
     */
    addOrUpdateCannabisLog(reviewProductEntity: any, positiveEffect: string, negativeEffect: string) {
        let reParam: object = {
            "Log_ID": 0,
            "Patient_ID": reviewProductEntity.patient_ID,
            "Product_ID": reviewProductEntity.product_ID,
            "Conditions": reviewProductEntity.conditions,
            "Intake": reviewProductEntity.intake,
            "Positive_Effects": positiveEffect,
            "Positive_Comments": reviewProductEntity.positive_Comments,
            "Negative_Effects": negativeEffect,
            "Negative_Comments": reviewProductEntity.negative_Comments,
            "Effectiveness": reviewProductEntity.effectiveness,
            "Side_Effects": reviewProductEntity.side_Effects
        }
        return this._ds.addOrUpdateCannabisLog(JSON.stringify(reParam), this._config.addOrUpdateCannabisLog).map(res => res.json());
    }

    /**
     * this service get the thc and cbd value depends on the medical condition
     * @param url 
     */
    getMedConditionRecomendation_Thc_Cbd_Value(medicalConditionData: string, patiendId: number) {
        let reqParam = {
            "Patient_ID": patiendId,
            "Medical_Conditions": medicalConditionData
        }
        let url = this._config.getMedDocRecomendation;
        return this._ds.getMedConditionRecomendation_Thc_Cbd_Value(JSON.stringify(reqParam), url).map(res => res.json());
    }

    /**
     * this service get the product Based on the thc and cpd value.
     * @param data 
     * @param url 
     */
    getProductListBasedOnThc_Cbd_Value(searchCode: number, lpId: number, firstTHCValue: number, lastTHCValue: number, firstcbdValue: number, lastcbdValue: number,productName?: number) {
        let reqParam: object = {
            "Search_Code": searchCode,
            "LP_Id": lpId,
            "Product_Name": productName || null,
            "FromTHC": firstTHCValue,
            "ToTHC": lastTHCValue,
            "FromCBD": firstcbdValue,
            "ToCBD": lastcbdValue,
            "Profile": null,
            "Product_Type": null,
            "ParentClinicID": 0,
            "IsAutoSuggest": false
        }
        let url = this._config.productListUrl;
        return this._ds.getProductListBasedOnThc_Cbd_Value(JSON.stringify(reqParam), url).map(res => res.json());
    }

    /**
     * 
     * @param data this service send order product detail to consern lp user
     * @param url 
     */
    sendProductRequestEmailToLPByGuest(regData: string) {
        let url = this._config.SendProductRequestEmailToLP;
        return this._ds.sendProductRequestEmailToLPByGuest(regData, url).map(res => res.json());
    }
    
    /**
     * This service send Login Patient Canabislog detail to consern lp user.
     * @param url 
     */
    sendCannabisLogDetailAsEmail() {
        let url = this._config.sendCannabisLogViaEmail+localStorage.getItem('mvcUserId')+"/"+this._config.Lp_Id;
        return this._ds.sendCannabisLogDetailAsEmail(url).map(res => res.json());
    }

}