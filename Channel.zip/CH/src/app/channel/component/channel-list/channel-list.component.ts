import { Component, OnInit, OnDestroy } from '@angular/core';
import { Response } from '@angular/http';
import { MatDialog } from '@angular/material';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router, NavigationEnd, ParamMap } from '@angular/router';

import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { RequestSuggestionComponent } from '@app/shared/shared-component/request-suggestion/request-suggestion.component';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import {
  ChannelStatus, PopUpTitle, PopUpSuccessMsg,
  AccessPermissionEnum, RoleIdEnum, LeadManagement, RelationStatus
} from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ISlimScrollOptions } from 'ng2-slimscroll';

import {
  datatable, DismissReasons,
  FilterResult, UpdateChannelData, Upgrade
} from '@app/channel/models/channel_models';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { UpdateDefaultContact } from '@app/shared/models/contact-list-models';
import { ToastrService } from 'ngx-toastr';
import { NoDataFound, Role, Permission, UserStatusDetail } from '@app/shared/models/shared-model';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ChannelStatusTypeName, ChannelTypeIdEnum } from '@app/config/constant';
import { AccessPermissionCustom } from '../../models/channel_models';
import { TranslateService } from '@ngx-translate/core';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
  selector: 'app-channel-list',
  templateUrl: './channel-list.component.html',
  styleUrls: ['./channel-list.component.scss']
})

export class ChannelListComponent implements OnInit, OnDestroy {
  public webUrl = WebUrl;
  public channelViewUrl: string;
  public opts: ISlimScrollOptions;
  public title = 'channelList.searchresult';
  public titlemsg: string;
  public ChannelStatus;
  public _DismissReasons: Array<DismissReasons>;
  public _NoDataFound: NoDataFound;
  public filter: number;
  public tableresult: datatable;
  public searchdata: string;
  public offSet = 1;
  public pageSize = 10;
  public filterresult: FilterResult;
  public pager: any = {};
  public pagedItems: any[];
  public preloader: boolean;
  public listresult: any;
  public resultCount: number;
  public pagination: any;
  public result: any = [];
  public filtershow: boolean;
  public filteractive: boolean;
  public channelListForm: FormGroup;
  public _UpdateChannelData: UpdateChannelData;
  public columncount: any;
  public search: string;
  public country: any = [];
  public location: any = [];
  public productGroup: any = [];
  public productCategory: any = [];
  public productBrands: any = [];
  public interestTag: any = [];
  public UserTypeId: string;
  public userDetails;
  public upgrade: Upgrade;
  public connectionStatusType;
  public aprovalchannel: number;
  public _UpdateDefaultContact = new UpdateDefaultContact();
  navigationSubscription: any;
  public defaultlocation: Array<any>;
  public defaultcountry: Array<any>;
  public setting: Object;
  public originCountry: Object;
  public categorysetting: Object;
  public productsetting: Object;
  public defaultproductCategory: Array<any>;
  public defaultproductGroup: Array<any>;
  public selectedproductcategory: Array<any>;
  public selectedlocations: Array<any>;
  public selectedcountries: Array<any>;
  public selectedproduct: Array<any>;
  noresult: boolean;
  userTypes: Array<number>;
  firstTabUserType: number;
  isPostBack = false;
  filterToogle: boolean;
  public brand: Array<any>;
  public brandlistData: Array<any>;
  public selectedbrandchannelItems: Array<any>;
  public selectedinterestlevelItems: Array<any>;
  public dropdownbrandchannelSettings: Object;
  public dropdowninterestlevelSettings: Object;
  public sortToggle: boolean;
  aggregations: any;
  public defaultbrands: Array<any>;
  parentAuthorizeId: number;
  authorizeIdsTemp: Array<AccessPermissionCustom> = new Array<AccessPermissionCustom>();
  isAccountUser: boolean;
  subtitle: any;
  public TagLsit = LeadManagement;
  relationName: string;
  public channelListCountType: Array<number>;
  public isFrenchTech: boolean;

  constructor(
    private sharedService: SharedService,
    private accountBusiness: AccountBusiness,
    private toastr: ToastrService,
    public dialog: MatDialog, private route: ActivatedRoute, private router: Router,
    private _channelBusiness: ChannelBusiness, private fb: FormBuilder,
    private _pagination: PaginationService, public sharedBusiness: SharedBusiness,
    private authorizeService: AuthorizeService,
    private translate: TranslateService,
    protected asyncLocalStorage: LocalStorage) {
    this._NoDataFound = new NoDataFound();

    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      this.userTypes = new Array<number>(ChannelTypeIdEnum.VENDOR,
        ChannelTypeIdEnum.DISTRIBUTOR, ChannelTypeIdEnum.RETAILER);

      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        const role = localStorage.getItem(AppLocalStorageKeys.ROLE);
        if (role) {
          const _role = JSON.parse(role) as Role;
          if (parseInt(_role.roleId, 10) !== RoleIdEnum.AccountUser) {
            this.route.queryParams.subscribe(params => {
              const channelStatusTypeName = params['connectionStatusTypeName'];
              /*if (channelStatusTypeName === ChannelStatusTypeName.SUGGESTION &&
                !this.authorizeAction(AccessPermissionEnum.MY_SUGGESSIONS)) {
                this.router.navigate(['/dashboard']);
                return;
              } else if (channelStatusTypeName === ChannelStatusTypeName.PROSPECT
                && !this.authorizeAction(AccessPermissionEnum.MY_PROSPECTS)) {
                this.router.navigate(['/dashboard']);
                return;
              } else if (channelStatusTypeName === ChannelStatusTypeName.CHANNEL
                && !this.authorizeAction(AccessPermissionEnum.MY_CHANNELS)) {
                this.router.navigate(['/dashboard']);
                return;
              }*/
              if ((channelStatusTypeName === ChannelStatusTypeName.SUGGESTION &&
                !this.authorizeAction(AccessPermissionEnum.MY_SUGGESSIONS)) ||
                (channelStatusTypeName === ChannelStatusTypeName.PROSPECT
                  && !this.authorizeAction(AccessPermissionEnum.MY_PROSPECTS)) ||
                (channelStatusTypeName === ChannelStatusTypeName.CHANNEL
                  && !this.authorizeAction(AccessPermissionEnum.MY_CHANNELS))) {
                this.router.navigate(['/dashboard']);
                return;
              }
              this.initialiseInvites();
            });
          } else {
            this.initialiseInvites();
          }
        } else {
          this.initialiseInvites();
        }
      }
    });
  }

  initialiseInvites() {
    this.channelListCountType = [0, 0, 0];
    this.filterToogle = false;
    this.brand = [];
    this.brandlistData = [];
    this.selectedbrandchannelItems = [];
    this.selectedinterestlevelItems = [];
    this.dropdownbrandchannelSettings = {};
    this.dropdowninterestlevelSettings = {};
    this.defaultlocation = [];
    this.defaultcountry = [];
    this.setting = {};
    this.originCountry= {};
    this.categorysetting = {};
    this.productsetting = {};
    this.defaultproductCategory = [];
    this.defaultbrands = [];
    this.selectedproductcategory = [];
    this.selectedcountries = [];
    this.selectedlocations = [];
    this.selectedproduct = [];
    this.defaultproductGroup = [];

    const role = localStorage.getItem(AppLocalStorageKeys.ROLE);
    let _role;
    if (role) {
      _role = JSON.parse(role) as Role;
      this.isAccountUser = (parseInt(_role.roleId, 10) === RoleIdEnum.AccountUser) ? true : false;
    }

    this.isPostBack = false;
    this.upgrade = {
      show: false
    };

    this.country = [];
    this.location = [];
    this.productGroup = [];
    this.productCategory = [];
    this.productBrands = [];
    this.interestTag = [];

    this.sortToggle = true;
    this.noresult = false;
    this.isFrenchTech = false;

    this.dropdownbrandchannelSettings = {
      text: 'Select Brand',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Brand...',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdowninterestlevelSettings = {
      text: 'Select Interest Level',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Interest...',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.setting = {
      text: 'Select Location',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Location...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.originCountry = {
      text: 'Select Country',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search country...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    }
    
    this.categorysetting = {
      text: 'Select Category',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Category...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };
    this.productsetting = {
      text: 'Select Speciality',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Speciality...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.UserTypeId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    this.userDetails = localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS);
    this.filtershow = false;
    this.filteractive = true;
    this.filterresult = {
      relationId: 1
    };

    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    if (listUrl === this.webUrl.CHANNEL_SUGGESTION) {
      this.filterresult.relationId = 1;
      this.connectionStatusType = ChannelStatusTypeName.SUGGESTION;
    } else if (listUrl === this.webUrl.CHANNEL_MYPROSPECTS) {
      this.filterresult.relationId = 2;
      this.connectionStatusType = ChannelStatusTypeName.PROSPECT;
    } else if (listUrl === this.webUrl.MYCHANNEL_APPROVALS) {
      this.filterresult.relationId = 3;
      this.connectionStatusType = ChannelStatusTypeName.CHANNEL_APPROVAL;
    } else if (listUrl === this.webUrl.CHANNEL_MYCHANNELS) {
      this.filterresult.relationId = 4;
      this.connectionStatusType = ChannelStatusTypeName.CHANNEL;
    } else if (listUrl === this.webUrl.MYPROSPECTS_APPROVALS) {
      this.filterresult.relationId = 7;
      this.connectionStatusType = ChannelStatusTypeName.PROSPECT_APPROVAL;
    }

    this.filter = null;
    this.route.queryParams.subscribe(params => {
      if (params.connectionid) {
        this.filterresult.relationId = parseInt(params.connectionid, 10) || 1;
      }
      if (params.connectionStatusTypeName) {
        this.connectionStatusType = params.connectionStatusTypeName || 'Data';
      }
      if (params.filterType) {
        this.filter = parseInt(params.filterType, 10);
        this.filterresult.typeId = parseInt(params.filterType, 10);
      }
      const _userStatusDetails = (<UserStatusDetail>JSON.parse(this.userDetails));
      if (_userStatusDetails && _userStatusDetails.relation_counts) {
        const _relationCounts = _userStatusDetails.relation_counts[this.filterresult.relationId];
        // _relationCounts[ChannelTypeIdEnum.RETAILER] = 0;
        let _relationCountValue;
        if (_relationCounts) {
          if (_relationCounts[ChannelTypeIdEnum.VENDOR] !== undefined &&
            _relationCounts[ChannelTypeIdEnum.VENDOR] !== 0 && _relationCounts[ChannelTypeIdEnum.VENDOR] !== null) {
            _relationCountValue = ChannelTypeIdEnum.VENDOR;
          } else if (_relationCounts[ChannelTypeIdEnum.DISTRIBUTOR] !== undefined &&
            _relationCounts[ChannelTypeIdEnum.DISTRIBUTOR] !== 0 && _relationCounts[ChannelTypeIdEnum.DISTRIBUTOR] !== null) {
            _relationCountValue = ChannelTypeIdEnum.DISTRIBUTOR;
          } else if (_relationCounts[ChannelTypeIdEnum.RETAILER] !== undefined &&
            _relationCounts[ChannelTypeIdEnum.RETAILER] !== 0 && _relationCounts[ChannelTypeIdEnum.RETAILER] !== null) {
            _relationCountValue = ChannelTypeIdEnum.RETAILER;
          } else {
            const userTypeId = parseInt(this.UserTypeId, 10);
            _relationCountValue = userTypeId === ChannelTypeIdEnum.VENDOR ? ChannelTypeIdEnum.DISTRIBUTOR
              : userTypeId === ChannelTypeIdEnum.DISTRIBUTOR ? ChannelTypeIdEnum.RETAILER : ChannelTypeIdEnum.VENDOR;
            this.noresult = true;
          }
          this.setResultCount(_relationCountValue, _relationCounts);
        } else {
          this.noresult = true;
        }
      }
    });

    this.setAuthorizeIds();
    this.manipulateUserTypes();

    this.ChannelStatus = ChannelStatus;
    this._UpdateChannelData = new UpdateChannelData();
    this.getDismissReasonList();
    this.titleBasedFunction();
    this.channelListForm = this.fb.group({
      productGroupControl: [],
      userLoc: [],
      productCategory: []
    });
    this.searchdata = '';
    // this.getChannelInfos();
    if (!this.noresult) {
      // load data from localstorage
      this.asyncLocalStorage.getItem('channel-list-relation-' + this.filterresult.relationId).subscribe((data) => {
        if (data) {

          this.tableresult = data.query;
          this.search = this.searchdata = this.tableresult.searchKey;
          this.offSet = this.tableresult.pageNumber;
          this.pageSize = this.tableresult.limit;
          this.sortToggle = (this.tableresult.sort === 'desc') ? true : false;

          this.filterresult = data.filter;
          this.filterToogle = data.filter.toogle;
          this.isFrenchTech = data.filter.is_french_tech;
          this.aprovalchannel = (this.filterresult.request === 'IN') ? 2 : 1;

          // dropdown select
          this.selectedproduct = data.selected.selectedproduct;
          this.selectedproductcategory = data.selected.selectedproductcategory;
          this.selectedcountries = data.selected.selectedcountries;
          this.selectedlocations = data.selected.selectedlocations;
          this.selectedbrandchannelItems = data.selected.selectedbrandchannelItems;
          this.selectedinterestlevelItems = data.selected.selectedinterestlevelItems;
        }

        this.getChannelList(this.searchdata, this.offSet, this.pageSize);
      });

    }
    if(+this.filterresult.relationId == 1) {
      this.getUpgradeChannelList();
    }
    
    /** assign Interest value to dropdown */
    this.interestTag = [];
    for (let i = 0; i < this.TagLsit.length; i++) {
      this.interestTag.push({
        'id': this.TagLsit[i].tag,
        'itemName': this.TagLsit[i].tag
      });
    }
  }

  setResultCount(resultCount, _relationCounts) {
    if (this.filterresult.relationId === 3 || this.filterresult.relationId === 7) {
      if (_relationCounts[resultCount]['OUT'] !== undefined && _relationCounts[resultCount]['OUT'] !== null
        || _relationCounts[resultCount]['OUT'] === undefined && _relationCounts[resultCount]['IN'] === undefined
        || _relationCounts[resultCount]['OUT'] === null && _relationCounts[resultCount]['IN'] === null) {
        this.aprovalchannel = 1;
        this.filterresult.request = 'OUT';
      } else if (_relationCounts[resultCount]['IN'] !== undefined && _relationCounts[resultCount]['IN'] !== null) {
        this.aprovalchannel = 2;
        this.filterresult.request = 'IN';
      }
    }
    this.filter = resultCount;
    this.filterresult.typeId = resultCount;
  }

  ngOnInit() {
    // this.filterresult.productCategoryId = [];
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
  }

  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  getChannelList(searchdata, offSet, pageSize) {
    this.noresult = false;
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callChannelList();
  }

  callChannelList() {
    const selected = {
      selectedproduct: this.selectedproduct,
      selectedproductcategory: this.selectedproductcategory,
      selectedcountries: this.selectedcountries,
      selectedlocations: this.selectedlocations,
      selectedbrandchannelItems: this.selectedbrandchannelItems,
      selectedinterestlevelItems: this.selectedinterestlevelItems
    };

    // unset type id for pending 
    if(this.filterresult.relationId == 7) {
        delete this.filterresult.typeId;
    }

    this._channelBusiness.ChannelList(this.tableresult, this.filterresult, selected, this.filterToogle).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        this.removeUserTypes();
        this.listresult = (<any>response)._body;
        this.listresult = JSON.parse(this.listresult);

        // load data to localstorage
        // this.asyncLocalStorage.setItemSubscribe('channel-list-relation-' + this.filterresult['relationId'], {
        //   query: this.tableresult,
        //   filter: Object.assign(this.filterresult, {
        //     toogle: this.filterToogle
        //   }),
        //   selected: {
        //     selectedproduct: this.selectedproduct,
        //     selectedproductcategory: this.selectedproductcategory,
        //     selectedlocations: this.selectedlocations,
        //     selectedbrandchannelItems: this.selectedbrandchannelItems,
        //     selectedinterestlevelItems: this.selectedinterestlevelItems
        //   },
        //   response: this.listresult.pagination,
        //   collectionIds: this.listresult.results.map(item => (item.id))
        // });

        this.aggregations = this.listresult.aggregations;
        if (this.aggregations.prechanneltypes) {
          const bucketsChannelCounts = this.aggregations.prechanneltypes.buckets;
          this.channelListCountType[0] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.VENDOR)[0]
            ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.VENDOR)[0].doc_count : 0;
          this.channelListCountType[1] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.DISTRIBUTOR)[0]
            ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.DISTRIBUTOR)[0].doc_count : 0;
          this.channelListCountType[2] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.RETAILER)[0]
            ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.RETAILER)[0].doc_count : 0;
        } else {
          this.channelListCountType = [0, 0, 0];
        }
        
        this.country = [];
        if (this.listresult.aggregations['country']) {
          this.defaultcountry = this.listresult.aggregations['country']['buckets'];
          for (let i = 0; i < this.defaultcountry.length; i++) {
            this.country.push({
              'id': this.defaultcountry[i].key,
              'itemName': this.defaultcountry[i].label,
              'count': this.defaultcountry[i].doc_count
            });
          }
        }
        
        this.location = [];
        if (this.listresult.aggregations['location']) {
          this.defaultlocation = this.listresult.aggregations['location']['buckets'];
          for (let i = 0; i < this.defaultlocation.length; i++) {
            this.location.push({
              'id': this.defaultlocation[i].key,
              'itemName': this.defaultlocation[i].label,
              'count': this.defaultlocation[i].doc_count
            });
          }
        }
        this.productGroup = [];
        if (this.listresult.aggregations['speciality']) {
          this.defaultproductGroup = this.listresult.aggregations['speciality']['buckets'];
          for (let i = 0; i < this.defaultproductGroup.length; i++) {
            this.productGroup.push({
              'id': this.defaultproductGroup[i].key,
              'itemName': this.defaultproductGroup[i].label,
              'count': this.defaultproductGroup[i].doc_count
            });
          }
        }

        this.productCategory = [];
        if (this.listresult.aggregations['category']) {
          this.defaultproductCategory = this.listresult.aggregations['category']['buckets'];
          for (let i = 0; i < this.defaultproductCategory.length; i++) {
            this.productCategory.push({
              'id': this.defaultproductCategory[i].key,
              'itemName': this.defaultproductCategory[i].label,
              'count': this.defaultproductCategory[i].doc_count
            });
          }
        }

        this.productBrands = [];
        if (this.listresult.aggregations['brands']) {
          this.defaultbrands = this.listresult.aggregations['brands']['buckets'];
          for (let i = 0; i < this.defaultbrands.length; i++) {
            this.productBrands.push({
              'id': this.defaultbrands[i].key,
              'itemName': this.defaultbrands[i].label,
              'count': this.defaultbrands[i].doc_count
            });
          }
        }

        this.result = this.listresult.results;
        this.pagination = this.listresult.pagination;
        this.resultCount = this.pagination.total;
        // this.channelListCountType[3] = this.listresult.others.product_count;
        if (this.resultCount === 0) {
          this.noresult = true;
          if (this.userTypes && this.userTypes.length > 0) {
            this.filterresult.typeId = this.userTypes[0];
            // this.callChannelList();
            // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
          } else {
            if (this.isPostBack) {
              this.filter = this.filterresult.typeId;
            } else {
              this.filter = this.firstTabUserType;
              this.filterresult.typeId = this.firstTabUserType;
            }
          }
        } else {
          this.noresult = false;
          this.filter = this.filterresult.typeId;
          // if (this.isPostBack) {
          //   this.filter = this.filterresult.typeId;
          // } else {
          //   this.filter = this.firstTabUserType;
          //   this.filterresult.typeId = this.firstTabUserType;
          // }
          delete this.userTypes;
        }
        this.setPage(this.tableresult.pageNumber);
      }

      for (let i = 0; i < this.result.length; i++) {
        this.result[i].customedata = false;
      }
      this.preloader = false;
    },
      (error) => {
        this.noresult = true;
        console.log(error);
      });
  }

  setPage(page: number) {

    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  public ChannelFilter(items: number) {
    if (!this.isAccountUser) {
      const authorizeData = this.authorizeIdsTemp.filter(element => element.ChannelType === items)[0];
      if (!this.authorizeAction(authorizeData.AccessPermissionId)) {
        return;
      }
    }

    this.isPostBack = true;
    this.filtershow = false;
    this.filter = items;
    this.filterresult.typeId = items;
    this.titleBasedFunction();
    this.offSet = 1; // reset page when switch channelId
    // this.filterreset();
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  searchFunction(data) {
    this.searchdata = data;
    this.getChannelList(data, this.offSet, this.pageSize);
  }

  filterData() {
    this.filteractive = true;
    if (this.selectedproduct.length) {
      this.filterresult.specialityId = this.selectedproduct.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.specialityId;
    }
    if (this.selectedproductcategory.length) {
      this.filterresult.productCategoryId = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.productCategoryId;
    }
    if (this.selectedlocations.length) {
      this.filterresult.locationId = this.selectedlocations.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.locationId;
    }
    if (this.selectedcountries.length) {
      this.filterresult.countryId = this.selectedcountries.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.countryId;
    }
    if (this.selectedbrandchannelItems.length) {
      this.filterresult.brandId = this.selectedbrandchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.brandId;
    }
    if (this.selectedinterestlevelItems.length) {
      this.filterresult.tag = this.selectedinterestlevelItems.map(x => x.id);
    } else {
      delete this.filterresult.tag;
    }
    this.filterresult.is_french_tech = this.isFrenchTech;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  filterreset() {
    this.filteractive = false;
    this.searchdata = '';
    this.search = '';
    this.selectedproductcategory = [];
    this.selectedcountries = [];
    this.selectedlocations = [];
    this.selectedproduct = [];
    this.selectedbrandchannelItems = [];
    this.selectedinterestlevelItems = [];
    this.isFrenchTech = false;
    delete this.filterresult.is_french_tech;
    delete this.filterresult.countryId;
    delete this.filterresult.locationId;
    delete this.filterresult.specialityId;
    delete this.filterresult.productCategoryId;
    delete this.filterresult.brandId;
    delete this.filterresult.tag;
    delete this.filterresult.is_french_tech;
    this.isFrenchTech = false;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  filteractives() {
    this.filteractive = true;
  }

  approvalFilter(value) {
    this.offSet = 1;
    this.aprovalchannel = value;
    if (value === 2) {
      this.filterresult.request = 'IN';
    } else {
      this.filterresult.request = 'OUT';
      // delete this.filterresult.request;
    }
    // this.filterreset();
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  openaction(channellist) {
    channellist.customedata = !channellist.customedata;
  }

  paginationFunction(data: number) {
    this.getChannelList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getChannelList(this.searchdata, 1, pageSize);
  }

  updateChannelStatus(event, channelListdata) {
    let list = [];
    if (parseInt(event.target.id.split('-')[0], 10) === 5) {
      if (+channelListdata.relation_status == +RelationStatus.SUGGESTION) {
        list = this._DismissReasons.filter((item) => {
          if (item.relationId == +RelationStatus.SUGGESTION) return item;
        });
      } else {
        list = this._DismissReasons.filter((item) => {
          if (item.relationId != +RelationStatus.SUGGESTION) return item;
        });
      }
    }
    if (parseInt(event.target.id.split('-')[0], 10) === 18) {
      this.OpenConfirmDialog('Edit Interest Level', PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    } else {
      this.OpenConfirmDialog(this.translate.instant(event.target.text), PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    }

  }

  getDismissReasonList() {
    this._channelBusiness.getDissmissList(true).subscribe(response => {
      const dataDismiss = response as Response;
      this._DismissReasons = dataDismiss.json();
      // this.OpenConfirmDialog('Contact Request', 'Do you wish to accept the contact ?', 'test', this._DismissReasons);
    });
  }

  private OpenConfirmDialog(title: string, message: string, data: Array<DismissReasons>, id: string, jtcId, tag?: string, contact?: any) {
    const contactdata = contact;
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        // message: this.translate.instant(message),
        message: message,
        list: data,
        id: parseInt(id.split('-')[0], 10),
        channelId: parseInt(id.split('-')[1], 10),
        jtcChannelId: jtcId,
        tag: tag
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        if (parseInt(id.split('-')[0], 10) !== 17 && parseInt(id.split('-')[0], 10) !== 18) {
          this._UpdateChannelData.connectionStatusTypeId = parseInt(id.split('-')[0], 10);
          this._UpdateChannelData.channelJCTId = parseInt(jtcId, 10);
          if (this._UpdateChannelData.connectionStatusTypeId === 2) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
            // this.toastr.success(this.translate.instant('channelList.toastrMsg.channelAddprospect'));
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 5) {
            this.toastr.success(this.translate.instant('channelList.toastrMsg.channelDismissed'));
            this._UpdateChannelData.dismissreasonid = parseInt(responseType.dismissId, 10);
            if (this._UpdateChannelData.dismissreasonid === 6 || this._UpdateChannelData.dismissreasonid === 11) {
              this._UpdateChannelData.otherreasons = responseType.others;
            }
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 7) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
          }
          this.changeChannelStatus(this._UpdateChannelData, parseInt(id.split('-')[1], 10));
          // this._channelBusiness.updateChannel(this._UpdateChannelData, true, parseInt(id.split('-')[1], 10)).subscribe(response => {
          //   if (response.ok) {
          //     this.getChannelList(this.searchdata, this.offSet, this.pageSize);
          //     const msg = this.translate.instant(PopUpSuccessMsg[this._UpdateChannelData.connectionStatusTypeId]);
          //     this.toastr.success(msg);
          //   } else {
          //     const msg = this.translate.instant(PopUpSuccessMsg[19]);
          //     this.toastr.error(msg);
          //   }
          // });
        } else {
          if (parseInt(id.split('-')[0], 10) === 17) {

            this.changeAsDefault(responseType.channelId, responseType.contactId, contactdata);
          } else if (parseInt(id.split('-')[0], 10) === 18) {
            const params = {
              channelJCTId: parseInt(jtcId, 10),
              leadManagementTag: responseType.leadManagementTag
            };
            /** Call Interest level service */
            this._channelBusiness.updateLeadManagementTag(params, true).subscribe(response => {
              if (response.ok) {
                this.getChannelList(this.searchdata, this.offSet, this.pageSize);
                const msg = this.translate.instant(PopUpSuccessMsg[18]);
                this.toastr.success(msg);
              } else {
                const msg = this.translate.instant(PopUpSuccessMsg[19]);
                this.toastr.error(msg);
              }
            });
          }
        }
      } else {
        if (contactdata) {
          this.OpenContactDialog(contactdata.title, PopUpTitle[11],
            contactdata.channelListdata, id, contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
        }
      }
    });
  }

  /** Update channel status */
  changeChannelStatus(UpdateStatusData, id) {
    this._channelBusiness.updateChannel(UpdateStatusData, true, id).subscribe(response => {
      if (response.ok) {
        this.getChannelList(this.searchdata, this.offSet, this.pageSize);
        this.getChannelProfileStatus();
        const msg = this.translate.instant(PopUpSuccessMsg[UpdateStatusData.connectionStatusTypeId]);
        this.toastr.success(msg);
      } else {
        const msg = this.translate.instant(PopUpSuccessMsg[19]);
        this.toastr.error(msg);
      }
    });
  }

  /** Change defalut contact */
  changeAsDefault(jtcId, idContact, contactdata?: any) {
    localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'false');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'CommonUsageLabel.defaultContact',
        type: 2,
        message: 'CommonUsageLabel.defaultcontactAdd',
        list: [],
        id: 15,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'true');
      document.getElementsByTagName('html').item(0).style.removeProperty('top');

      if (responseType && responseType.action === true) {
        this.preloader = true;
        this._UpdateDefaultContact.channelId = parseInt(jtcId, 10);
        this._UpdateDefaultContact.contactId = parseInt(idContact, 10);
        this.sharedBusiness.updateDefaultContact(this._UpdateDefaultContact, true).subscribe(response => {

          if (response.ok) {
            if (contactdata) {
              this.OpenContactDialog(contactdata.title, PopUpTitle[11],
                contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
            }
            this.getChannelList(this.searchdata, this.offSet, this.pageSize);
          }
          this.preloader = false;
          this.toastr.success(this.translate.instant('CommonUsageLabel.toastrMsgcontact'));
        });
      } else if (contactdata) {
        this.OpenContactDialog(contactdata.title, PopUpTitle[11],
          contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
      }
    });
  }

  // private OpenRequestDialig(relationData) {
  //   const dialogRef = this.dialog.open(RequestSuggestionComponent, {
  //     data: {
  //       title: 'title',
  //       type: 2,
  //       // message: this.translate.instant(message),
  //       message: 'message',
  //       relation: relationData
  //     },
  //     panelClass: 'modalPointer'
  //   });
  //   dialogRef.afterClosed().subscribe(responseType => {
  //     document.getElementsByTagName('html').item(0).style.removeProperty('top');
  //     if (responseType && responseType.action === true) {
  //       this.changeChannelStatus(responseType, responseType.id);
  //       // if (responseType.status === 1) {
  //       //   // this.addToBusiness(productId);
  //       // } else if (responseType.status === 3) {
  //       //   // this.productDismissReasons();
  //       // }
  //     }
  //   });
  // }

  getUpgradeChannelList() {
    this._channelBusiness.UpgradeChannels(true).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        this.upgrade = <Upgrade>res.json();
      } else {
        this.upgrade.show = false;
      }
    });
  }

  viewContactDetails(event, channelListdata, relation_id) {
    const list = [];
    this.OpenContactDialog(event.target.text, PopUpTitle[11],
      channelListdata, event.target.id, channelListdata.channel_jct_id, relation_id);
  }

  /** Open contact popup */
  private OpenContactDialog(title: string, message: string, data: any, id: string, jtcId: number, relation_id) {
    const dialogRef = this.dialog.open(ContactViewDialogComponent, {
      data: {
        title: this.translate.instant(message),
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: data.default_contact.id,
        channelId: data.channelId,
        jtcChannelId: jtcId,
        relation_id: relation_id,
        approvalstauts: this.filterresult.relationId === 7 ? this.aprovalchannel : 1,
        relation_tag: data.relation_tag ? data.relation_tag : 'Low'
      },
    });
    dialogRef.afterClosed().subscribe(responseType => {
      if (responseType && responseType.action === true) {
        /** variable for call again contact popup */
        const contactData = {
          title: title,
          channelListdata: data,
          relation_id: relation_id
        };

        if (responseType.contact === 1) { /** Open see all contact popup */
          this.OpenConfirmDialog(this.translate.instant('shared.buttonLabels.sellContacts'), PopUpTitle[10]
            , [], '17-' + data.id, jtcId, '', contactData);
        } else if (responseType.contact === 2) { /** Open mail popup */
          // if (responseType.permission === 1 || responseType.permission === 7) {
          //   const relation = {
          //     id: relation_id,
          //     jtcChannelId: jtcId
          //   };
          //   // this.OpenRequestDialig(relation);
          // } else {
          this.sendEmail(responseType, contactData);
          // }
        }

      }
      // if (responseType.changes) {
      this.getChannelList(this.searchdata, this.offSet, this.pageSize);
      // }
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    });
  }

  public openMessageDialog(event, channelListdata) {

    const contactData = {
      title: null,
      channelListdata: channelListdata,
      relation_id: 2
    };

    this.sendEmail({
      receiverId: channelListdata.default_contact.id,
      userId: localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID)
    }, contactData, true);
  }

  /** Send email */
  public sendEmail(contact, contactdata, skip?) {
    const dialogRef = this.dialog.open(EmailPopupComponent, {
      data: {
        senderId: contact.userId,
        receiverId: contact.receiverId
      },
      width: '600px',
      height: 'auto'
    });
    if(skip !== true) {
      dialogRef.afterClosed().subscribe(responseType => {
        document.getElementsByTagName('html').item(0).style.removeProperty('top');
        this.OpenContactDialog(contactdata.title, PopUpTitle[11],
          contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
      });
    }
  }

  upgradeFunction() {
    localStorage.setItem('RedirectId', this.filterresult.relationId.toString());
    this.router.navigate(['/user/subscriptionplan']);
  }

  titleBasedFunction() {
    if (this.filterresult.relationId === 1) {
      this._NoDataFound.noDataImageSrc = '../assets/images/no-suggestion.png';
      this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nochannel1');
      this.title = 'channelList.title';
      this.subtitle = this.translate.instant('channelList.channelDescription');
      this._NoDataFound.btnText = '';
      this.relationName = 'shared.buttonLabels.addProspect';
      this.channelViewUrl = this.webUrl.CHANNEL_SUGGESTION_VIEW;
    } else if (this.filterresult.relationId === 2) {
      this.relationName = 'shared.buttonLabels.addChannel';
      this._NoDataFound.noDataImageSrc = '../assets/images/no-my-prospect.png';
      this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nochannel2');
      this._NoDataFound.btnLink = this.webUrl.CHANNEL_SUGGESTION;
      this._NoDataFound.queryParam = {
        'connectionid': 1,
        'connectionStatusTypeName': ChannelStatusTypeName.SUGGESTION, 'filterType': this.filter
      };
      this._NoDataFound.btnText = this.translate.instant('channelList.viewSuggestion');
      this.title = 'channelList.propects';
      this.subtitle = this.translate.instant('channelList.myProspects');
      this.channelViewUrl = this.webUrl.CHANNEL_MYPROSPECTS_VIEW;
    } else if (this.filterresult.relationId === 7) {
      this.title = 'channelList.prospectApproval';
      this.subtitle = this.translate.instant('channelList.myProspectsApproval');
      // this.aprovalchannel = 1;
      // this.filterresult.request = 'OUT';
      this._NoDataFound.noDataImageSrc = '../assets/images/no-my-prospect.png';
      this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nochannel2');
      this._NoDataFound.btnLink = this.webUrl.CHANNEL_SUGGESTION;
      this._NoDataFound.queryParam = {
        'connectionid': 1,
        'connectionStatusTypeName': ChannelStatusTypeName.SUGGESTION, 'filterType': this.filter
      };
      this._NoDataFound.btnText = this.translate.instant('channelList.viewSuggestion');
      this.channelViewUrl = this.webUrl.MYPROSPECTS_APPROVALS_VIEW;
    } else {
      this._NoDataFound.noDataImageSrc = '../assets/images/no-my-channel.png';
      if (this.filterresult.relationId === 3) {
        this.relationName = 'shared.buttonLabels.approve';
        // this.aprovalchannel = 1;
        // this.filterresult.request = 'OUT';
        this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nochannel3');
        this._NoDataFound.btnLink = this.webUrl.CHANNEL_MYPROSPECTS;
        this._NoDataFound.queryParam = {
          'connectionid': 2,
          'connectionStatusTypeName': ChannelStatusTypeName.PROSPECT, 'filterType': this.filter
        };
        this.title = 'channelList.channelApproval';
        this.subtitle = this.translate.instant('channelList.myChannelApproval');
        this._NoDataFound.btnText = this.translate.instant('channelList.viewprospects');
        this.channelViewUrl = this.webUrl.MYCHANNEL_APPROVALS_VIEW;
      } else {
        this.relationName = this.translate.instant('shared.buttonLabels.editrating');
        this.title = 'channelList.myChannel';
        this.subtitle = this.translate.instant('channelList.myChannelsub');
        this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nochannelOther');
        this.aprovalchannel = 2;
        this._NoDataFound.btnLink = '';
        this._NoDataFound.btnText = '';
        this.channelViewUrl = this.webUrl.CHANNEL_MYCHANNELS_VIEW;
      }
    }
  }

  removeUserTypes() {
    if (this.userTypes && this.userTypes.length > 0) {
      const index = this.userTypes.findIndex(item => item === this.filterresult.typeId);
      if (index > -1) {
        this.userTypes.splice(index, 1);
      }
    }
  }

  // Search the Brand List
  changebrandList(event) {
    // if (this.brandtextlength.length >= 1) {
    this.accountBusiness.getBrandList(event, 0).subscribe(result => {
      this.brandlistData = result as Array<any>;
      if (this.brandlistData.length > 0) {
        for (let i = 0; i < this.brandlistData.length; i++) {
          this.brand.push({ 'id': this.brandlistData[i].id, 'itemName': this.brandlistData[i].Name });
        }
      } else {
        console.log('error');
      }

    },
      (error) => {
        console.log(error);
      });
    // }
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  authorizeAction(authorizeId: number, showMessage = true) {
    const hasAccess = this.authorizeService.hasAccess(authorizeId);
    if (!hasAccess) {
      if (showMessage) {
        if (authorizeId === AccessPermissionEnum.MY_SUGGESSIONS || authorizeId === AccessPermissionEnum.MY_CHANNELS
          || authorizeId === AccessPermissionEnum.MY_PROSPECTS) {
          this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
        } else {
          this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        }
      }

      return false;
    } else {
      return true;
    }
  }

  setAuthorizeIds() {
    if (this.connectionStatusType.toLowerCase() === ChannelStatusTypeName.SUGGESTION.toLowerCase()) {
      this.parentAuthorizeId = AccessPermissionEnum.MY_SUGGESSIONS;
      this.authorizeIdsTemp = [{
        'AccessPermissionId': AccessPermissionEnum.MY_SUGGESSIONS_VENDOR,
        'ChannelType': ChannelTypeIdEnum.VENDOR
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_SUGGESSIONS_RETAILER,
        'ChannelType': ChannelTypeIdEnum.RETAILER
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_SUGGESSIONS_DISTRIBUTOR,
        'ChannelType': ChannelTypeIdEnum.DISTRIBUTOR
      }];

    } else if (this.connectionStatusType.toLowerCase() === ChannelStatusTypeName.PROSPECT.toLowerCase()) {
      this.parentAuthorizeId = AccessPermissionEnum.MY_PROSPECTS;
      this.authorizeIdsTemp = [{
        'AccessPermissionId': AccessPermissionEnum.MY_PROSPECTS_VENDOR,
        'ChannelType': ChannelTypeIdEnum.VENDOR
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_PROSPECTS_RETAILER,
        'ChannelType': ChannelTypeIdEnum.RETAILER
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_PROSPECTS_DISTRIBUTOR,
        'ChannelType': ChannelTypeIdEnum.DISTRIBUTOR
      }];
    } else if (this.connectionStatusType.toLowerCase() === ChannelStatusTypeName.CHANNEL.toLowerCase()) {
      this.parentAuthorizeId = AccessPermissionEnum.MY_CHANNELS;
      this.authorizeIdsTemp = [{
        'AccessPermissionId': AccessPermissionEnum.MY_CHANNELS_VENDOR,
        'ChannelType': ChannelTypeIdEnum.VENDOR
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_CHANNELS_RETAILER,
        'ChannelType': ChannelTypeIdEnum.RETAILER
      }, {
        'AccessPermissionId': AccessPermissionEnum.MY_CHANNELS_DISTRIBUTOR,
        'ChannelType': ChannelTypeIdEnum.DISTRIBUTOR
      }];
    }
  }

  authorizeUserTypesForList(): void {
    const activeChilds = this.authorizeService.getActiveChilds(this.parentAuthorizeId);

    let _authorizeIdsTemp = new Array<AccessPermissionCustom>();
    activeChilds.forEach(activeChildItem => {
      const permissionId = parseInt(activeChildItem.accesspermissionid, 10);
      _authorizeIdsTemp = this.authorizeIdsTemp.filter(item => item.AccessPermissionId !== permissionId);
    });

    _authorizeIdsTemp.forEach(item => {
      this.userTypes = this.userTypes.filter(userTypeItem => userTypeItem !== item.ChannelType);
    });
  }

  manipulateUserTypes() {
    this.userTypes = this.userTypes.filter(item => item !== parseInt(this.UserTypeId, 10));
    if (!this.isAccountUser) {
      this.authorizeUserTypesForList();
    }

    if (this.userTypes && this.userTypes.length > 0) {
      if (this.userTypes.includes(this.filter)) {
        this.firstTabUserType = this.filter;
        this.filterresult.typeId = this.filter;
      } else {
        this.firstTabUserType = this.userTypes[0];
        this.filter = this.userTypes[0];
        this.filterresult.typeId = this.userTypes[0];
      }
    } else if (!this.isAccountUser) {
      // you dont have permission
      this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
      this.router.navigate(['/dashboard']);
      return;
    } else {
      this.toastr.warning(this.translate.instant('commonMessage.somethingWentWrong'));
      this.router.navigate(['/dashboard']);
    }

  }

  async getChannelProfileStatus() {
    let userstatus;
    userstatus = await this.sharedService.getChannelStatusId();
    const response = userstatus as Response;
    if (response.ok) {
      const userStatusData = userstatus.json();
      localStorage.setItem(AppLocalStorageKeys.USER_STATUS_DETAILS, JSON.stringify(userstatus.json()));
    }
  }
}
