import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerticalProductViewComponent } from './vertical-product-view.component';

describe('VerticalProductViewComponent', () => {
  let component: VerticalProductViewComponent;
  let fixture: ComponentFixture<VerticalProductViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerticalProductViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerticalProductViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
