import { Component, OnInit, Input } from '@angular/core';
import { Product } from '@app/channel/models/channel_models';
import { ProductQuality, CurrencyType } from '@app/config/constant';
import { WebUrl } from '@app/config/constant_keys';
@Component({
  selector: 'app-vertical-product-view',
  templateUrl: './vertical-product-view.component.html',
  styleUrls: ['./vertical-product-view.component.scss']
})
export class VerticalProductViewComponent implements OnInit {
  @Input() product: Product;
  _qualityEnum = ProductQuality;
  public _CurrencyType = CurrencyType;
  public webUrl = WebUrl;
  constructor() { }

  ngOnInit() {
  }


}
