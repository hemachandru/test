import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelDetailViewComponent } from './channel-detail-view.component';

describe('ChannelDetailViewComponent', () => {
  let component: ChannelDetailViewComponent;
  let fixture: ComponentFixture<ChannelDetailViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelDetailViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelDetailViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
