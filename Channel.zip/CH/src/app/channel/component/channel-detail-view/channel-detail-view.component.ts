import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import {
  ChannelCompanyDetailTitle, ChannelTypeIdEnum, ButtonTypes, CurrencyType,
  ChannelStatusTypeName, RelationStatus
} from '@app/config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Router, ActivatedRoute } from '@angular/router';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { RootObjectChannelView, MatchingProfile, VendorProduct } from '@app/channel/models/channelView_models';
import { MatDialog, MatDialogRef } from '@angular/material';
import { DismissReasons, UpdateChannelData, OfficialDocument, ChannelClaim, datatable } from '@app/channel/models/channel_models';
import { PopUpTitle, PopUpSuccessMsg, SocialLinkConfig, PageNames, RedirectChannelList } from '@app/config/constant';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { Response } from '@angular/http';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { BrandResult, ChannelKeyRetailerGet } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { AwardsPopupComponent } from '@app/channel/component/awards-popup/awards-popup.component';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';
import { WebUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { ChannelContactService } from '@app/shared/shared-service/channel-contact-service';
import { ChannelContactRequest, ContactRelation } from '@app/shared/models/shared-model';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';

@Component({
  selector: 'app-channel-detail-view',
  templateUrl: './channel-detail-view.component.html',
  styleUrls: ['./channel-detail-view.component.scss']
})
export class ChannelDetailViewComponent implements OnInit {
  public webUrl = WebUrl;
  public title = 'channelDetailview.companyProfile';
  public contactList;
  public brandResult: BrandResult;
  public matchingDistributorList;
  public isPrevious: boolean;
  public isNext: boolean;
  interestDataShow = 3;
  existingDataShow = 3;
  customerDataShow = 3;
  serviceDataShow = 3;
  sellingDataShow = 5;
  locationDataShow = 5;
  locationretailerDataShow = 5;
  routeSubscription;
  channelCompanySubscription;
  profileId: number;
  channelCompany: any;
  channelCompanyDetailTitle;
  rating: number;
  public opts: ISlimScrollOptions;
  public loading: boolean;
  public channelId;
  public channelDetailsInfo: RootObjectChannelView = null;
  public productGroup;
  public productCategory;
  public locations;
  public channelTypeId;
  public matchdataParams: MatchingProfile;
  public channelJCTID;
  public _DismissReasons: Array<DismissReasons>;
  public _UpdateChannelData: UpdateChannelData;
  public relation_status;
  public preloader = false;
  public productListresult;
  public productListParams: VendorProduct;
  public channelType;
  public pendingApproval: string;
  public officialDistributorList;
  public noOfYear;
  public unauthorized: string;
  public _SocialLinkConfig;
  public _OfficialDocument: OfficialDocument;
  public _ChannelClaim: ChannelClaim;
  public subscription: boolean;
  public userChannelId;
  public relationId: number;

  public scrollbarOptionsCnl = { axis: 'y', theme: 'dark' };
  public channelKeyRetailers: ChannelKeyRetailerGet[];
  public channelKeyDistributors: ChannelKeyRetailerGet[];
  public isDownloadOfficialDocsClicked: boolean;
  public isOfficialDocsLoading: boolean;
  public _CurrencyType = CurrencyType;
  public isPrevNextBool: boolean;
  relationName: string;
  dialogRef: MatDialogRef<MessageDialogComponent>;
  tableresult: datatable;
  constructor(private route: ActivatedRoute,
    private router: Router, private _location: Location,
    private sharedBusiness: SharedBusiness,
    private _channelBusiness: ChannelBusiness,
    private toastr: ToastrService,
    public dialog: MatDialog,
    private translate: TranslateService,
    private channelContactService: ChannelContactService,
    protected asyncLocalStorage: LocalStorage,
  ) {
    this.productListParams = <VendorProduct>{
      'isActive': true
    };
  }

  ngOnInit() {
    this.isPrevNextBool = true;
    this.isPrevious = true;
    this.isNext = true;
    this.unauthorized = '';
    this._UpdateChannelData = new UpdateChannelData();
    this.isDownloadOfficialDocsClicked = false;
    this.isOfficialDocsLoading = false;
    this.getDismissReasonList();
    this.getChannelCompanyID();
    // this.officialDocuments();
    this.channelCompanyDetailTitle = ChannelCompanyDetailTitle;
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this._SocialLinkConfig = SocialLinkConfig;
    this.userChannelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    this.modifyRelation();
    // let listUrl = this.router.url;
    // listUrl = listUrl.split('?')[0];
    // if (listUrl === this.webUrl.CHANNEL_SUGGESTION) {
    //   this.relationId = 1;
    // } else if (listUrl === this.webUrl.CHANNEL_MYPROSPECTS) {
    //   this.relationId = 2;
    // } else if (listUrl === this.webUrl.MYCHANNEL_APPROVALS) {
    //   this.relationId = 3;
    // } else if (listUrl === this.webUrl.CHANNEL_MYCHANNELS) {
    //   this.relationId = 4;
    // } else if (listUrl === this.webUrl.MYPROSPECTS_APPROVALS) {
    //   this.relationId = 7;
    // }
  }

  // Get Channel Id in params
  getChannelCompanyID() {
    this.route.params.subscribe(
      (params: any) => {
        this.channelId = parseInt(params.id, 10);
        this.getChannelCompanyDetails(this.channelId);
        this.isPrevNextChannelView();
      },
      (error) => {
        console.log(error);
      });
  }

  relationStatus() {
    // tslint:disable-next-line:triple-equals
    if (this.relation_status == 1 || this.relation_status == null) {
      this.relationName = 'shared.buttonLabels.addProspect';
      // tslint:disable-next-line:triple-equals
    } else if (this.relation_status == 2) {
      // this.relationName = 'shared.buttonLabels.addChannel';
      this.relationName = 'shared.buttonLabels.editrating';
      // tslint:disable-next-line:triple-equals
    } else if (this.relation_status == 3) {
      this.relationName = 'shared.buttonLabels.approval';
    } else {
      this.relationName = 'shared.buttonLabels.editrating';
    }
    this.setPreviousNextDisplay();
  }
  // Get channel detail list with channel Id
  getChannelCompanyDetails(channelId) {
    this.preloader = true;
    this.unauthorized = ' ';
    this._channelBusiness.channelCompanyBusiness(channelId).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.getContactList(this.channelId);

        this.getOfficialDistributorList(this.channelId);
        // this.getProductList(this.productListParams);
        this.channelDetailsInfo = result.json() as RootObjectChannelView;
        // this.loadOfficialDocuments();
        this.relation_status = this.channelDetailsInfo.connectionStatusTypeId;
        this.pendingApproval = this.channelDetailsInfo.pendingApprovalInOutBound;
        this.channelJCTID = parseInt(this.channelDetailsInfo.channelJCT, 10);
        this.rating = this.channelDetailsInfo.rating;
        this.rating = 0; // Temporary count, Need to be removed after dynamic
        this.channelDetailsInfo.reviewCount = 0;  // Temporary count, Need to be removed after dynamic
        this.channelTypeId = this.channelDetailsInfo.channelTypeId;
        this.channelType = this.channelDetailsInfo.channelType;
        const channelTypeId = parseInt(this.channelTypeId, 10);
        if (channelTypeId !== ChannelTypeIdEnum.RETAILER) {
          this.getBrandList(this.channelId);
        }

        this.productGroup = this.channelDetailsInfo.tradeInformationIds.productGroup;
        this.productCategory = this.channelDetailsInfo.tradeInformationIds.productCategory;
        this.locations = this.channelDetailsInfo.tradeInformationIds.locations;
        this.channelKeyRetailers = this.channelDetailsInfo.channelKeyRetailer;
        this.channelKeyDistributors = this.channelDetailsInfo.channelKeyDistributor;

        this.matchdataParams = <MatchingProfile>{
          'channelId': channelId,
          'channelTypeId': channelTypeId,
          'productGroup': this.productGroup,
          'productCategory': this.productCategory,
          'locations': this.locations
        };
        this.productListParams = <VendorProduct>{
          'isActive': true,
          'channelId': channelId,
        };
        this.getmatchingDistributorList(this.matchdataParams);
        // if (this.channelType === 'VENDOR') {
        this.getProductList(this.productListParams);
        // }
        // Get no of years for vendor
        if (channelTypeId === ChannelTypeIdEnum.VENDOR) {
          const currentYear = moment(new Date(), 'DD/MM/YYY').year();
          const estYear = parseInt(this.channelDetailsInfo.estYear, 10);
          this.noOfYear = currentYear - estYear;
        }
        this.relationStatus();
        this.preloader = false;
      } else if (response.json()[0]['errors'][0]['code'] === 3030) {
        this.preloader = false;
        this.unauthorized = response.json()[0]['errors'][0]['message'];
      } else if (response.json()[0]['property'] === 'SUBSCRIPTION' && response.json()[0]['errors'][0]['code'] === 3031) {
        this.preloader = false;
        this.openUpgradePopup();
      } else {
        this.preloader = false;
        this.unauthorized = this.translate.instant('CommonUsageLabel.unauthorizedRequest');
      }
    }, (error) => {
      this.preloader = false;
      console.log(error);
    });
  }

  // Get Contact List
  getContactList(channelId) {
    this.preloader = true;
    this.sharedBusiness.getChannelContactListById(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.contactList = response.json();
      }
    }, (error) => {
      console.log(error);
    });
    this.preloader = false;
  }

  // Get Brand List
  getBrandList(channelId) {
    this.preloader = true;
    this.sharedBusiness.getChannelBrandList(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.brandResult = response.json() as BrandResult;
      }
    }, (error) => {
      console.log(error);
    });
    this.preloader = false;
  }

  // Get Official Distributor List
  getOfficialDistributorList(channelId) {
    this.sharedBusiness.getOfficialDistributorList(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.officialDistributorList = response.json();
      }
    }, (error) => {
      console.log(error);
    });
  }

  // Get Matching List
  getmatchingDistributorList(data: MatchingProfile) {
    this.sharedBusiness.getmatchingDistributorList(data, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.matchingDistributorList = response.json();
      }
    }, (error) => {
      console.log(error);
    });
  }

  // Product carosel List
  // getProductList(productlistData: VendorProduct) {
  //   this.sharedBusiness.GetVendorProductList(productlistData).subscribe(res => {
  //     const response = res as Response;
  //     if (response.ok) {
  //       const result = response.json();
  //       this.productListresult = result;
  //     }
  //   });
  // }

  // Product carosel List
  getProductList(productlistData: VendorProduct) {
    this.tableresult = {
      searchKey: '',
      pageNumber: 1,
      limit: 15,
      sort: 'asc'
    };
    // this._channelBusiness.ProductList(productlistData).subscribe(res => {
    this._channelBusiness.ProductList(this.tableresult, null, this.channelId).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const result = response.json();
        this.productListresult = result;
      }
    });
  }

  getDismissReasonList() {
    this._channelBusiness.getDissmissList(true).subscribe(response => {
      const dataDismiss = response as Response;
      this._DismissReasons = dataDismiss.json();
      // this.OpenConfirmDialog('Contact Request', 'Do you wish to accept the contact ?', 'test', this._DismissReasons);
    });
  }

  updateChannelStatus(event) {
    let list = [];
    if (parseInt(event.target.id.split('-')[0], 10) === 5) {
      if(+this.relation_status == +RelationStatus.SUGGESTION) {
        list = this._DismissReasons.filter((item) => {
          if(item.relationId == +RelationStatus.SUGGESTION) return item;
        });        
      } else {
        list = this._DismissReasons.filter((item) => {
          if(item.relationId != +RelationStatus.SUGGESTION) return item;
        });    
      }
    }
    this.OpenConfirmDialog(event.target.value, PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
      , list, event.target.id, this.channelJCTID);
  }

  private OpenConfirmDialog(title: string, message: string, data: Array<DismissReasons>, id: string, jtcId) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        message: message,
        list: data,
        id: parseInt(id.split('-')[0], 10),
        channelId: parseInt(id.split('-')[1], 10),
        jtcChannelId: jtcId,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        this.preloader = true;
        this._UpdateChannelData.connectionStatusTypeId = parseInt(id.split('-')[0], 10);
        this._UpdateChannelData.channelJCTId = parseInt(jtcId, 10);
        if (this._UpdateChannelData.connectionStatusTypeId === 2 || this._UpdateChannelData.connectionStatusTypeId === 7) {
          this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
        }
        if (this._UpdateChannelData.connectionStatusTypeId === 5) {
          this._UpdateChannelData.dismissreasonid = parseInt(responseType.dismissId, 10);
          if (this._UpdateChannelData.dismissreasonid === 6 || this._UpdateChannelData.dismissreasonid === 11) {
            this._UpdateChannelData.otherreasons = responseType.others;
          }
        }
        this._channelBusiness.updateChannel(this._UpdateChannelData, true, parseInt(id.split('-')[1], 10)).subscribe(response => {
          // response as Response;
          if (response.ok) {
            if (this.relation_status == 1 || this.relation_status == null) {
              this.router.navigate([this.webUrl.CHANNEL_SUGGESTION]);
            } else if (this.relation_status == 2) {
              this.router.navigate([this.webUrl.CHANNEL_MYPROSPECTS]);
            } else if (this.relation_status == 3) {
              this.router.navigate([this.webUrl.MYCHANNEL_APPROVALS]);
            } else if (this.relation_status == 4) {
              this.router.navigate([this.webUrl.CHANNEL_MYCHANNELS]);
            } else if (this.relation_status == 7) {
              this.router.navigate([this.webUrl.MYPROSPECTS_APPROVALS]);
            }
            const msg = this.translate.instant(PopUpSuccessMsg[this._UpdateChannelData.connectionStatusTypeId]);
            this.toastr.success(msg);
            this.preloader = false;
          } else {
            const msg = this.translate.instant(PopUpSuccessMsg[19]);
            this.toastr.error(msg);
            this.preloader = false;
          }

        });
      }
    });
  }

  locationDataFuction(currentdata, totalLenght) {
    this.locationDataShow = currentdata === 5 ? totalLenght : 5;
  }

  // channelClaim() {
  //   this._channelBusiness.getChannelClaim(true, this.channelId).subscribe(response => {
  //     const claimData = response as Response;
  //     this._ChannelClaim = claimData.json();
  //     if (this._ChannelClaim.claim) {
  //       this.officialDocuments();
  //     } else {
  //       this._OfficialDocument.folderPath = '';
  //     }
  //   });
  // }

  downloadOfficialDocs() {
    this.isDownloadOfficialDocsClicked = false;
    if (this.channelDetailsInfo.channelDocument) {
      if (this._OfficialDocument && this._OfficialDocument.folderPath) {
        this.loading = false;
        window.location.href = this._OfficialDocument.folderPath;
      } else {
        this.loading = true;
        this.isDownloadOfficialDocsClicked = true;
        if (!this.isOfficialDocsLoading) {
          this.loadOfficialDocuments();
        }
      }
    }
  }

  loadOfficialDocuments() {
    this.channelDetailsInfo.channelDocument = true;
    if (this.channelDetailsInfo.channelDocument) {
      this.isOfficialDocsLoading = true;
      this._channelBusiness.getOfficialDocuments(true, this.channelId).subscribe(response => {
        const officialData = response as Response;
        this.loading = false;
        this.isOfficialDocsLoading = false;
        if (officialData.ok) {
          this._OfficialDocument = officialData.json();
          if (this.isDownloadOfficialDocsClicked) {
            window.location.href = this._OfficialDocument.folderPath;
            this.isDownloadOfficialDocsClicked = false;
          }
        }
      });
    }
  }

  // Awards popup
  awardsPopup() {
    this.dialog.open(AwardsPopupComponent, {
      data: {
        awards: this.channelDetailsInfo.awards
      },
      width: '800px',
      panelClass: 'awardsPanel'
    });
  }

  public openUpgradePopup() {
    const title = this.translate.instant('productList.upgradetitle');
    // const message = this.translate.instant('searchList.upgradeMsg');
    const message = this.translate.instant('searchList.upgradeMsgViewChannel');
    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.subscriptionPlan();
      } else {
        this.unauthorized = this.translate.instant('searchList.upgradeMsgViewChannel');
        this.subscription = true;
      }
    });
  }

  modifyRelation() {
    this.channelContactService.currentRequest.subscribe(item => {
      if (item) {
        const contactRelation = item as ChannelContactRequest;
        if (contactRelation.page === PageNames.CHANNEL_DETAIL_VIEW) {
          this.relation_status = contactRelation.relation.relationId;
          this.relationStatus();
        }
      }
    });
  }

  /** history back */
  backClicked() {
    this._location.back();
  }

  /** call subscription plan */
  subscriptionPlan() {
    localStorage.setItem('RedirectId', '10');
    this.router.navigate(['/user/subscriptionplan']);
  }

  previousNextChannel(flag: string, channelId: number) {
    this.asyncLocalStorage.getItem('channel-list-relation-' + this.getRelationStatus()).subscribe((channelList) => {
      if (channelList) {
        const listIds = channelList.collectionIds;
        const index = listIds.indexOf(channelId);
        const indexList = flag === 'previous' ? index - 1 : index + 1;
        if (listIds[indexList]) {
          this.router.navigate([RedirectChannelList[this.getRelationStatus()] + '/channelView', listIds[indexList]]);
        } else if (flag === 'previous' && channelList.response.page > 1 || flag === 'next'
          && channelList.response.page < (channelList.response.total / channelList.response.limit)) {
          const page = flag === 'previous' ? channelList.response.page - 1 : channelList.response.page + 1;
          channelList.query.pageNumber = page;
          this.preloader = true;

          this._channelBusiness.PreviousNextChannelList(channelList.query, channelList.filter,
            channelList.selected, channelList.filter.filterToogle, this.getRelationStatus()).subscribe(response => {
              this.preloader = false;
              const res = response as Response;
              if (res.ok) {
                const total = res.json();
                this.asyncLocalStorage.getItem('channel-list-relation-' + this.getRelationStatus()).subscribe((channelLst) => {
                  const listId = channelLst.collectionIds;
                  const channelIdCheck = flag === 'previous' ? listId[total.pagination.limit - 1] : listId[0];
                  const inx = listId.indexOf(channelIdCheck);
                  if (listId[inx]) {
                    this.router.navigate([RedirectChannelList[this.getRelationStatus()] + '/channelView', listId[inx]]);
                  }
                });
              }
            });
        }
      }
    });
  }

  setPreviousNextDisplay() {
    this.asyncLocalStorage.getItem('channel-list-relation-' + this.getRelationStatus()).subscribe((channelList) => {
      if (channelList && channelList.collectionIds) {
        const index = channelList.collectionIds.indexOf(this.channelId);
        if (index >= 0) {
          if (channelList.query.pageNumber === 1 && index === 0) {
            this.isPrevious = false;
          } else {
            this.isPrevious = true;
          }
          // const lastRow =
          const ss = (channelList.response.page - 1) * channelList.response.limit;
          if (channelList.query.pageNumber === channelList.response.page &&
            ((channelList.response.page - 1) * channelList.response.limit) + index + 1 === channelList.response.total) {
            this.isNext = false;
          } else {
            this.isNext = true;
          }
        } else {
          this.isPrevNextBool = false;
        }
      } else {
        this.isPrevNextBool = false;
      }
    });
  }

  getRelationStatus() {
    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    let relationStatus;
    if (listUrl === this.webUrl.CHANNEL_SEARCHRESULT_VIEW + this.channelId) {
      relationStatus = RelationStatus.TOP_SEARCH;
    } else if (listUrl === this.webUrl.MORE_MATCHING_CHANNEL_VIEW + this.channelId) {
      relationStatus = RelationStatus.MORE_MATCHING;
    } else {
      relationStatus = this.relation_status;
    }
    return relationStatus;
  }

  isPrevNextChannelView() {
    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    if (listUrl === this.webUrl.MORE_MATCHING_CHANNEL_VIEW_PREV_NEXT + this.channelId) {
      this.isPrevNextBool = false;
    }
  }

  /** Send email */
  public sendEmail() {
    this.dialog.open(EmailPopupComponent, {
      data: {
        senderType: 'channel',
        senderId: localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID),
        receiverId: this.channelId
      },
      width: '600px',
      height: 'auto'
    });
  }
}
