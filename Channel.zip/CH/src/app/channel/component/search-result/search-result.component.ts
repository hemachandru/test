import { Component, OnInit, OnDestroy } from '@angular/core';
import { Response } from '@angular/http';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { LocalStorage } from '@ngx-pwa/local-storage';

import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { ChannelStatus, PopUpTitle, LeadManagement, PopUpSuccessMsg, RelationStatus } from '@app/config/constant';
import {
  datatable, DismissReasons,
  SearchFilter, UpdateChannelData, Upgrade
} from '@app/channel/models/channel_models';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { UpdateDefaultContact } from '@app/shared/models/contact-list-models';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ButtonTypes, FeatureAccessEnum, ChannelTypeIdEnum } from '@app/config/constant';
import { SharedService } from '@app/shared/shared-service/shared-service';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.scss']
})
export class SearchResultComponent implements OnInit, OnDestroy {
  public webUrl = WebUrl;
  isPostBack: boolean;
  public _NoDataFound: NoDataFound;
  public opts: ISlimScrollOptions;
  public title = 'channelList.searchresult';
  public titlemsg: string;
  public ChannelStatus;
  public _DismissReasons: Array<DismissReasons>;
  public filter: number;
  public tableresult: datatable;
  public searchdata: string;
  public offSet = 1;
  public pageSize = 10;
  private filterresult: SearchFilter;
  public pager: any = {};
  public pagedItems: any[];
  public preloader: boolean;
  public listresult: any;
  public resultCount: number;
  public pagination: any;
  public result: any = [];
  public filtershow: boolean;
  public filteractive: boolean;
  public _UpdateChannelData: UpdateChannelData;
  public columncount: any;
  public search: string;
  public country: any = [];
  public location: any = [];
  public productGroup: any = [];
  public productBrands: any = [];
  public interestTag: any = [];
  public productCategory: any = [];
  public resultss: any = {};
  public companyList: any = [];
  public UserTypeId: string;
  public headerdata: any;
  public upgrade: Upgrade;
  public showProductTitle: boolean;
  public _UpdateDefaultContact = new UpdateDefaultContact();
  public setting: Object;
  public originCountry: Object;
  public categorysetting: Object;
  public productsetting: Object;
  public productbrandsetting: Object;
  public defaultproductCategory: Array<any>;
  public defaultlocation: Array<any>;
  public defaultcountry: Array<any>;
  public defaultproductGroup: Array<any>;
  public selectedproductcategory: Array<any>;
  public selectedproductbrand: Array<any>;
  public selectedcountries: Array<any>;
  public selectedlocations: Array<any>;
  public selectedproduct: Array<any>;
  public defaultproductBrand: Array<any>;
  public selectedinterestlevelItems: Array<any>;
  public dropdowninterestlevelSettings: Object;
  public selectedbrandchannelItems: Array<any>;
  userTypes: Array<number>;
  firstTabUserType: number;
  isProductLoadedConditionally: boolean;
  filterToogle: boolean;
  public sortToggle: boolean;
  noresult: boolean;
  aggregations: any;
  subtitle: any;
  public TagLsit = LeadManagement;
  navigationSubscription: any;
  relationName: string;
  dialogRef: MatDialogRef<MessageDialogComponent>;
  public channelListCountType: Array<Number>;
  public isFrenchTech: boolean;

  constructor(public dialog: MatDialog, private route: ActivatedRoute, private router: Router,
    private sharedService: SharedService,
    private _channelBusiness: ChannelBusiness, private toastr: ToastrService,
    private _pagination: PaginationService, public sharedBusiness: SharedBusiness,
    private authorizeService: AuthorizeService, private translate: TranslateService,
    protected asyncLocalStorage: LocalStorage) {
    this._NoDataFound = new NoDataFound();
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.initialiseInvites();
      }
    });
    this.filterresult = new SearchFilter();
    this.defaultlocation = [];
    this.defaultcountry = [];
    this.setting = {};
    this.categorysetting = {};
    this.productsetting = {};
    this.defaultproductCategory = [];
    this.selectedproductcategory = [];
    this.selectedlocations = [];
    this.selectedcountries = [];
    this.selectedproduct = [];
    this.selectedproductbrand = [];
    this.defaultproductGroup = [];
    this.defaultproductBrand = [];
  }

  initialiseInvites() {
    this.channelListCountType = [0, 0, 0, 0];
    this.isProductLoadedConditionally = false;
    this.userTypes = new Array<number>(2, 3, 4, 5);
    this.isPostBack = false;
    this.sortToggle = true;
    this.selectedbrandchannelItems = [];
    this.productbrandsetting = {};
    this.country = [];
    this.location = [];
    this.productGroup = [];
    this.productCategory = [];
    this.selectedinterestlevelItems = [];
    this.dropdowninterestlevelSettings = {};
    this.interestTag = [];
    this.showProductTitle = true;
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('channelList.noMessage.nosearch');
    this.isFrenchTech = false;

    this.upgrade = {
      show: false
    };

    this.UserTypeId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);

    this.filtershow = false;
    this.filteractive = true;
    this.route.queryParams.subscribe(params => {
      let keydata = params.keydata;
      if (!keydata) {
        keydata = params[1];
      }

      this.searchdata = keydata;
      this.search = this.searchdata;
    });

    this.ChannelStatus = ChannelStatus;
    this._UpdateChannelData = new UpdateChannelData();
    this.getDismissReasonList();
    this.subtitle = this.translate.instant('channelList.searchsub');

    this.filterresult = {};

    this.userTypes = this.userTypes.filter(item => item !== parseInt(this.UserTypeId, 10));
    if (this.UserTypeId === '2') {
      this.userTypes = this.userTypes.filter(item => item !== 5); // exclude product for type 2
    }

    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    if (listUrl === this.webUrl.PRODUCT_SEARCHRESULT) {
      this.filter = 5;
      this.ProductFilter(5);
    } else {
      this.filterresult.typeId = 2;
      this.firstTabUserType = this.userTypes[0];
      if (this.UserTypeId === '2') {
        this.filterresult.typeId = 3;
        this.filter = 3;
      }
      this.filterresult.relationId = RelationStatus.TOP_SEARCH;
      this.asyncLocalStorage.getItem('channel-list-relation-' + RelationStatus.TOP_SEARCH).subscribe((data) => {
        if (data) {

          this.tableresult = data.query;
          this.search = this.searchdata = this.tableresult.searchKey;
          this.offSet = this.tableresult.pageNumber;
          this.pageSize = this.tableresult.limit;
          this.sortToggle = (this.tableresult.sort === 'desc') ? true : false;

          this.filterresult = data.filter;
          this.filterToogle = data.filter.toogle;
          this.isFrenchTech = data.filter.is_french_tech;
          // this.aprovalchannel = (this.filterresult.request === 'IN') ? 2 : 1;

          // dropdown select
          this.selectedproduct = data.selected.selectedproduct;
          this.selectedproductcategory = data.selected.selectedproductcategory;
          this.selectedcountries = data.selected.selectedcountries;
          this.selectedlocations = data.selected.selectedlocations;
          this.selectedbrandchannelItems = data.selected.selectedbrandchannelItems;
          this.selectedinterestlevelItems = data.selected.selectedinterestlevelItems;
        }

        this.getChannelList(this.searchdata, this.offSet, this.pageSize);
      });
      // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
      this.getUpgradeChannelList();
    }

    //  else {
    // this.filterresult.typeId = 2;
    // this.filter = 2;
    // }

    // this.firstTabUserType = this.userTypes[0];
    // this.filterresult.typeId = this.userTypes[0];
    // this.filter = this.userTypes[0];

    // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
    // this.getUpgradeChannelList();

    this.setting = {
      text: 'Select Location',
      enableSearchFilter: true,
      classes: 'myclass  custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Location...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.originCountry = {
      text: 'Select Country',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search country...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.categorysetting = {
      text: 'Select Category',
      enableSearchFilter: true,
      classes: 'myclass  custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Category...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };
    this.productsetting = {
      text: 'Select Speciality',
      enableSearchFilter: true,
      classes: 'myclass  custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Speciality...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.productbrandsetting = {
      text: 'Select Brand',
      enableSearchFilter: true,
      classes: 'myclass  custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Brand...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdowninterestlevelSettings = {
      text: 'Select Interest Level',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Interest...',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    /** assign Interest value to dropdown */
    this.interestTag = [];
    for (let i = 0; i < this.TagLsit.length; i++) {
      this.interestTag.push({
        'id': this.TagLsit[i].tag,
        'itemName': this.TagLsit[i].tag
      });
    }
  }

  ngOnInit() {
    this.noresult = false;
    this.filterToogle = false;

    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.authorizedChannel();
  }

  /** Check Plan to allow search the company */
  authorizedChannel() {
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.TOP_SEARCH).then(item => {
      if (item || item === null || item === undefined) {
        // this.setSearchListWidth();
        // this.opensearch = true;
      } else {
        // this.opensearch = false;
        // const inputList = [].slice.call((<HTMLElement>this.el.nativeElement).getElementsByTagName('input'));
        // inputList.forEach((input: HTMLElement) => {
        //   input.blur();
        // });
        this.openUpgradePopup();
      }
    });
  }

  /** Call Upgrade popup */
  public openUpgradePopup() {
    const title = this.translate.instant('searchList.upgradetitle');
    const message = this.translate.instant('searchList.upgradeMsg');
    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        localStorage.setItem('RedirectId', '5');
        this.router.navigate(['/user/subscriptionplan']);
      } else {
        this.router.navigate(['/dashboard']);
      }
    });
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  getChannelList(searchdata, offSet, pageSize) {
    this.noresult = false;
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callChannelList();
  }

  removeUserTypes() {
    if (this.userTypes && this.userTypes.length > 0) {
      const index = this.userTypes.findIndex(item => item === this.filterresult.typeId);
      if (index > -1) {
        this.userTypes.splice(index, 1);
      }
    }
  }

  callChannelList() {
    const selected = {
      selectedproduct: this.selectedproduct,
      selectedproductcategory: this.selectedproductcategory,
      selectedcountries: this.selectedcountries,
      selectedlocations: this.selectedlocations,
      selectedbrandchannelItems: this.selectedbrandchannelItems,
      selectedinterestlevelItems: this.selectedinterestlevelItems
    };
    this._channelBusiness.SearchList(this.tableresult, this.filterresult, selected, this.filterToogle).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        this.removeUserTypes();
        this.listresult = (<any>response)._body;
        this.listresult = JSON.parse(this.listresult);
        this.companyList = this.listresult.results;
        this.pagination = this.listresult.pagination;
        this.resultCount = this.pagination.total;
        this.aggregations = this.listresult.aggregations;
        if (this.aggregations.prechanneltypes) {
          const bucketsChannelCounts = this.aggregations.prechanneltypes.buckets;
          this.setChannelsCount(bucketsChannelCounts);
        } else {
          this.channelListCountType = [0, 0, 0];
        }
        this.channelListCountType[3] = this.listresult.others.product_count;

        this.country = [];
        if (this.listresult.aggregations['country']) {
          this.defaultcountry = this.listresult.aggregations['country']['buckets'];
          for (let i = 0; i < this.defaultcountry.length; i++) {
            this.country.push({
              'id': this.defaultcountry[i].key,
              'itemName': this.defaultcountry[i].label,
              'count': this.defaultcountry[i].doc_count
            });
          }
        }

        this.location = [];
        if (this.listresult.aggregations['location']) {
          this.defaultlocation = this.listresult.aggregations['location']['buckets'];
          for (let i = 0; i < this.defaultlocation.length; i++) {
            this.location.push({
              'id': this.defaultlocation[i].key,
              'itemName': this.defaultlocation[i].label,
              'count': this.defaultlocation[i].doc_count
            });
          }
        }

        this.productGroup = [];
        if (this.listresult.aggregations['speciality']) {
          this.defaultproductGroup = this.listresult.aggregations['speciality']['buckets'];
          for (let i = 0; i < this.defaultproductGroup.length; i++) {
            this.productGroup.push({
              'id': this.defaultproductGroup[i].key,
              'itemName': this.defaultproductGroup[i].label,
              'count': this.defaultproductGroup[i].doc_count
            });
          }
        }

        this.productCategory = [];
        if (this.listresult.aggregations['category']) {
          this.defaultproductCategory = this.listresult.aggregations['category']['buckets'];
          for (let i = 0; i < this.defaultproductCategory.length; i++) {
            this.productCategory.push({
              'id': this.defaultproductCategory[i].key,
              'itemName': this.defaultproductCategory[i].label,
              'count': this.defaultproductCategory[i].doc_count
            });
          }
        }

        this.productBrands = [];
        if (this.listresult.aggregations['brands']) {
          this.defaultproductBrand = this.listresult.aggregations['brands']['buckets'];
          for (let i = 0; i < this.defaultproductBrand.length; i++) {
            this.productBrands.push({
              'id': this.defaultproductBrand[i].key,
              'itemName': this.defaultproductBrand[i].label,
              'count': this.defaultproductBrand[i].doc_count
            });
          }
        }

        if (this.resultCount === 0) {
          if (this.userTypes && this.userTypes.length > 0) {
            this.filterresult.typeId = this.userTypes[0];
            if (this.filterresult.typeId === 5) {
              this.isProductLoadedConditionally = true;
              // this.showProductConditionally = true;
              this.filter = 5;
            } else {
              this.callChannelList();
            }
          } else {
            if (!this.isPostBack) {
              this.filter = this.firstTabUserType;
              this.filterresult.typeId = this.firstTabUserType;
            } else {
              this.filter = this.filterresult.typeId;
            }
          }
        } else {
          this.noresult = false;
          this.filter = this.filterresult.typeId;
          // if (this.isPostBack) {
          //   this.filter = this.filterresult.typeId;
          // } else {
          //   this.filter = this.firstTabUserType;
          //   this.filterresult.typeId = this.firstTabUserType;
          // }
          delete this.userTypes;
        }
        this.setPage(this.tableresult.pageNumber);
      }

      for (let i = 0; i < this.companyList.length; i++) {
        this.companyList[i].customedata = false;
      }
      this.companyList.forEach(relation => {
        // tslint:disable-next-line:triple-equals
        if (relation.relation_status == 1 || relation.relation_status === null) {
          this.relationName = 'shared.buttonLabels.addProspect';
          relation.relation_statusname = 'shared.buttonLabels.addProspect';
          // tslint:disable-next-line:triple-equals
        } else if (relation.relation_status == 2) {
          this.relationName = 'shared.buttonLabels.addChannel';
          relation.relation_statusname = 'shared.buttonLabels.addChannel';
          // tslint:disable-next-line:triple-equals
        } else if (relation.relation_status == 3) {
          this.relationName = 'shared.buttonLabels.approval';
          relation.relation_statusname = 'shared.buttonLabels.approval';
        } else {
          this.relationName = 'shared.buttonLabels.editrating';
          relation.relation_statusname = 'shared.buttonLabels.editrating';
        }
      });

      this.preloader = false;
    },
      (error) => {
        console.log(error);
      });
  }

  setChannelsCount(bucketsChannelCounts) {
    this.channelListCountType[0] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.VENDOR)[0]
    ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.VENDOR)[0].doc_count : 0;
    this.channelListCountType[1] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.DISTRIBUTOR)[0]
    ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.DISTRIBUTOR)[0].doc_count : 0;
    this.channelListCountType[2] = bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.RETAILER)[0]
    ? bucketsChannelCounts.filter(item => item.key === ChannelTypeIdEnum.RETAILER)[0].doc_count : 0;
    // this.channelListCountType[3] = bucketsChannelCounts.filter(item => item.key === 5)[0]
    // ? bucketsChannelCounts.filter(item => item.key === 5)[0].doc_count : 0;
  }

  setPage(page: number) {

    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  ChannelFilter(items: number) {
    this.isPostBack = true;
    this.filtershow = false;
    this.filter = items;
    this.filterresult.typeId = items;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  ProductFilter(items: number) {
    this.isPostBack = true;
    this.filter = items;
    this.isProductLoadedConditionally = false;
  }

  searchFunction(data) {
    this.searchdata = data;
    this.getChannelList(data, this.offSet, this.pageSize);
  }

  filterData() {
    this.filteractive = true;
    if (this.selectedproduct.length) {
      this.filterresult.specialityId = this.selectedproduct.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.specialityId;
    }
    if (this.selectedproductcategory.length) {
      this.filterresult.productCategoryId = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.productCategoryId;
    }
    if (this.selectedlocations.length) {
      this.filterresult.locationId = this.selectedlocations.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.locationId;
    }
    if (this.selectedcountries.length) {
      this.filterresult.countryId = this.selectedcountries.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.countryId;
    }
    if (this.selectedproductbrand.length) {
      this.filterresult.brandId = this.selectedproductbrand.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.brandId;
    }
    if (this.selectedinterestlevelItems.length) {
      this.filterresult.tag = this.selectedinterestlevelItems.map(x => x.id);
    } else {
      delete this.filterresult.tag;
    }
    this.filterresult.is_french_tech = this.isFrenchTech;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  filterreset() {
    this.filteractive = false;
    this.isFrenchTech = false;
    this.searchdata = '';
    this.search = '';
    this.selectedproductcategory = [];
    this.selectedcountries = [];
    this.selectedlocations = [];
    this.selectedproduct = [];
    this.selectedproductbrand = [];
    this.selectedinterestlevelItems = [];
    delete this.filterresult.locationId;
    delete this.filterresult.countryId;
    delete this.filterresult.specialityId;
    delete this.filterresult.productCategoryId;
    delete this.filterresult.brandId;
    delete this.filterresult.tag;
    delete this.filterresult.is_french_tech;
    this.isFrenchTech = false;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }

  openaction(channellist) {
    channellist.customedata = !channellist.customedata;
  }

  paginationFunction(data: number) {
    this.getChannelList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getChannelList(this.searchdata, 1, pageSize);
  }

  updateChannelStatus(event, channelListdata) {
    let list = [];
    if (parseInt(event.target.id.split('-')[0], 10) === 5) {
      if(+channelListdata.relation_status == +RelationStatus.SUGGESTION) {
        list = this._DismissReasons.filter((item) => {
          if(item.relationId == +RelationStatus.SUGGESTION) return item;
        });        
      } else {
        list = this._DismissReasons.filter((item) => {
          if(item.relationId != +RelationStatus.SUGGESTION) return item;
        });    
      }
    }
    if (parseInt(event.target.id.split('-')[0], 10) === 18) {
      this.OpenConfirmDialog('Edit Interest Level', PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    } else {
      this.OpenConfirmDialog(this.translate.instant(event.target.text), PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    }
  }

  getDismissReasonList() {
    this._channelBusiness.getDissmissList(true).subscribe(response => {
      const dataDismiss = response as Response;
      this._DismissReasons = dataDismiss.json();
      // this.OpenConfirmDialog('Contact Request', 'Do you wish to accept the contact ?', 'test', this._DismissReasons);
    });
  }

  private OpenConfirmDialog(title: string, message: string, data: Array<DismissReasons>, id: string, jtcId, tag?: string, contact?: any) {
    const contactdata = contact;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        message: message,
        list: data,
        id: parseInt(id.split('-')[0], 10),
        channelId: parseInt(id.split('-')[1], 10),
        jtcChannelId: jtcId,
        tag: tag
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');

      if (responseType && responseType.action === true) {
        if (parseInt(id.split('-')[0], 10) !== 17 && parseInt(id.split('-')[0], 10) !== 18) {
          this._UpdateChannelData.connectionStatusTypeId = parseInt(id.split('-')[0], 10);
          this._UpdateChannelData.channelJCTId = parseInt(jtcId, 10);
          if (this._UpdateChannelData.connectionStatusTypeId === 2) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
            this.toastr.success(this.translate.instant('channelList.toastrMsg.channelprospect'));
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 5) {
            this._UpdateChannelData.dismissreasonid = parseInt(responseType.dismissId, 10);
            if (this._UpdateChannelData.dismissreasonid === 6 || this._UpdateChannelData.dismissreasonid === 11) {
              this._UpdateChannelData.otherreasons = responseType.others;
            }
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 7) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
          }
          this._channelBusiness.updateChannel(this._UpdateChannelData, true, parseInt(id.split('-')[1], 10)).subscribe(response => {
            if (response.ok) {
              this.getChannelList(this.searchdata, this.offSet, this.pageSize);
              const msg = this.translate.instant(PopUpSuccessMsg[this._UpdateChannelData.connectionStatusTypeId]);
              this.toastr.success(msg);
              this.getChannelProfileStatus();
            } else {
              const msg = this.translate.instant(PopUpSuccessMsg[19]);
              this.toastr.error(msg);
            }
          });
        } else {
          if (parseInt(id.split('-')[0], 10) === 17) {

            this.changeAsDefault(responseType.channelId, responseType.contactId, contactdata);
          } else if (parseInt(id.split('-')[0], 10) === 18) {
            const params = {
              channelJCTId: parseInt(jtcId, 10),
              leadManagementTag: responseType.leadManagementTag
            };
            /** Call Interest level service */
            this._channelBusiness.updateLeadManagementTag(params, true).subscribe(response => {
              if (response.ok) {
                this.getChannelList(this.searchdata, this.offSet, this.pageSize);
                const msg = this.translate.instant(PopUpSuccessMsg[18]);
                this.toastr.success(msg);
              } else {
                const msg = this.translate.instant(PopUpSuccessMsg[19]);
                this.toastr.error(msg);
              }
            });
          }
        }
      } else {
        if (contactdata) {
          this.OpenContactDialog(contactdata.title, PopUpTitle[11],
            contactdata.channelListdata, id, contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
        }
      }
    });
  }

  changeAsDefault(jtcId, idContact, contactdata?: any) {
    localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'false');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'CommonUsageLabel.defaultContact',
        type: 2,
        message: 'CommonUsageLabel.defaultcontactAdd',
        list: [],
        id: 15,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'true');
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this._UpdateDefaultContact.channelId = parseInt(jtcId, 10);
        this._UpdateDefaultContact.contactId = parseInt(idContact, 10);
        this.sharedBusiness.updateDefaultContact(this._UpdateDefaultContact, true).subscribe(response => {

          if (response.ok) {
            if (contactdata) {
              this.OpenContactDialog(contactdata.title, PopUpTitle[11],
                contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
            }
            this.getChannelList(this.searchdata, this.offSet, this.pageSize);
          }
        });
      } else if (contactdata) {
        this.OpenContactDialog(contactdata.title, PopUpTitle[11],
          contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
      }
    });
  }

  getUpgradeChannelList() {
    this._channelBusiness.UpgradeChannels(true).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        this.upgrade = <Upgrade>res.json();
      } else {
        this.upgrade.show = false;
      }
    });
  }

  viewContactDetails(event, channelListdata, relation_id) {
    const list = [];
    this.OpenContactDialog(event.target.text, PopUpTitle[11],
      channelListdata, event.target.id, channelListdata.channel_jct_id, relation_id);
  }

  private OpenContactDialog(title: string, message: string, data: any, id: string, jtcId: number, relation_id) {

    const dialogRef = this.dialog.open(ContactViewDialogComponent, {
      data: {
        title: this.translate.instant(message),
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: data.default_contact.id,
        channelId: data.channelId,
        jtcChannelId: jtcId,
        relation_id: relation_id,
        approvalstauts: data.request === 'IN' ? 2 : 1,
        relation_tag: data.relation_tag ? data.relation_tag : 'Low'
      },
    });
    dialogRef.afterClosed().subscribe(responseType => {
      if (responseType.action === true) {
        /** variable for call again contact popup */
        const contactData = {
          title: title,
          channelListdata: data,
          relation_id: relation_id
        };

        if (responseType.contact === 1) { /** Open see all contact popup */
          this.OpenConfirmDialog(this.translate.instant('shared.buttonLabels.sellContacts'), PopUpTitle[10]
            , [], '17-' + data.id, jtcId, '', contactData);
        } else if (responseType.contact === 2) { /** Open mail popup */
          this.sendEmail(responseType, contactData);
        }

      }
      this.getChannelList(this.searchdata, this.offSet, this.pageSize);
    });
    document.getElementsByTagName('html').item(0).style.removeProperty('top');
  }

  public openMessageDialog(event, channelListdata) {

    const contactData = {
      title: null,
      channelListdata: channelListdata,
      relation_id: 2
    };

    this.sendEmail({
      receiverId: channelListdata.default_contact.id,
      userId: localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID)
    }, contactData, true);
  }

  /** Send email */
  public sendEmail(contact, contactdata, skip?) {
    const dialogRef = this.dialog.open(EmailPopupComponent, {
      data: {
        senderId: contact.userId,
        receiverId: contact.receiverId
      },
      width: '600px',
      height: 'auto'
    });
    if(skip !== true) {
      dialogRef.afterClosed().subscribe(responseType => {
        document.getElementsByTagName('html').item(0).style.removeProperty('top');
        this.OpenContactDialog(contactdata.title, PopUpTitle[11],
          contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
      });
    }    
  }

  upgradeFunction() {
    localStorage.setItem('RedirectId', '5');
    this.router.navigate(['/user/subscriptionplan']);
  }

  onProductLoaded(val) {
    this.removeUserTypes();
    if (this.isProductLoadedConditionally && !val) {
      this.filter = this.firstTabUserType;
      this.filterresult.typeId = this.firstTabUserType;
    }
  }

  onChannelCount(channelCount) {
    console.log(channelCount);
    this.channelListCountType[3] = channelCount.product;
    const channelListcount = channelCount.channel;
    this.setChannelsCount(channelListcount);
  }

  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  async getChannelProfileStatus() {
    let userstatus;
    userstatus = await this.sharedService.getChannelStatusId();
    const response = userstatus as Response;
    if (response.ok) {
      const userStatusData = userstatus.json();
      localStorage.setItem(AppLocalStorageKeys.USER_STATUS_DETAILS, JSON.stringify(userstatus.json()));
    }
  }
}
