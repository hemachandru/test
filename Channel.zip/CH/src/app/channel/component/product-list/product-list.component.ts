import { Component, OnInit, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { BrandId, GroupId, CatgoryId, ChanneFilterItems, ChannelProductlist, Product, datatable } from '@app/channel/models/channel_models';
import { Response } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorage } from '@ngx-pwa/local-storage';

import { ProductQuality, ChannelTypeIdEnum, CurrencyType, RelationStatus } from '@app/config/constant';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { PaginationService } from '../../../shared/shared-service/pagination.service';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { Pagination } from '@app/shared/models/contact-list-models';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { SharedService } from '@app/shared/shared-service/shared-service';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  public webUrl = WebUrl;
  public _NoDataFound: NoDataFound;
  public opts: ISlimScrollOptions;
  public title: string;
  public titlemsg: string;
  public search: string;
  public retailercommisionto: number;
  public retailercommisionfrom: number;
  public distributorcommisionto: number;
  public distributorcommisionfrom: number;
  public retailercommision_min: number;
  public retailercommision_max: number;
  public retailercommision_reset_min: number;
  public retailercommision_reset_max: number;
  public distributorcommision_max: number;
  public distributorcommision_min: number;
  public distributorcommision_reset_max: number;
  public distributorcommision_reset_min: number;
  public retailprice_max: number;
  public retailprice_min: number;
  public retailprice_reset_max: number;
  public retailprice_reset_min: number;
  public preloader: boolean;
  public morecountry: boolean;
  public horizontalViewdata: boolean;
  public listViewdata: boolean;
  private product_List: ChannelProductlist;
  public products: Array<Product>;
  public _qualityEnum = ProductQuality;
  public Group: Array<any>;
  public Category: Array<any>;
  public brand: Array<any>;
  public filterToogle: boolean;
  public brandIds: Array<BrandId>;
  public familyIds: Array<GroupId>;
  public categoryIds: Array<CatgoryId>;
  public position: string;
  public price: boolean;
  public filterItems: ChanneFilterItems;
  public offSet = 1;
  public pageSize = 12;
  public pager: any = {};
  public pagination: any;
  public resultCount: number;
  public pagedItems: any[];
  public result: any = [];
  public retailfrom: number;
  public retailto: number;
  public brandlistData: Array<any>;
  @Input() SearchText: string;
  @Input() showTitle: boolean;
  public selectedbrandchannelItems: Array<any>;
  public selectedQualitychannelItems: Array<any>;
  public selectedGroupchannelItems: Array<any>;
  public selectedIsFreeSamples: Array<any>;
  public selectedproductcategory: Array<any>;
  public dropdownbrandchannelSettings: Object;
  public dropdownQualitySettings: Object;
  public dropdownGroupchannelSettings: Object;
  public dropdownIsFreeSampleSettings: Object;
  public dropdownCategorychannelSettings: Object;
  public channelId: number;
  public _channelTypeEnum = ChannelTypeIdEnum;
  ratingdata: any;
  public _CurrencyType = CurrencyType;
  public showMyCurrencyBtn: Boolean;
  public showMyCurrencyFlag: Boolean;
  public userCurrencyID: number;

  public tableresult: datatable;
  public filtershow: boolean;
  public filteractive: boolean;
  public sortToggle: boolean;
  public searchdata: string;
  public isFrenchTech: boolean;

  // private currencyCode: any = {
  //   '1': 'EUR',
  //   '2': 'USD'
  // };

  @Output() productLoaded: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() channelCount: EventEmitter<object> = new EventEmitter<object>();
  @Input() productTopSearchFlag: boolean;
  noresult: boolean;
  aggregations: any;
  productBrands: any[];
  defaultbrands: any;
  productCategory: any[];
  defaultproductCategory: any;
  productFamily: any[];
  defaultproductFamily: any;
  productQuality: any[];
  defaultproductQuality: any;
  productIsFree: any[];
  defaultproductIsFree: any;
  productViewUrl: string;
  currencyTable: any;
  userCurrency: any;
  currencyMaster: any = {};
  constructor(
    private _channelBusiness: ChannelBusiness, private _pagination: PaginationService,
    private accountBusiness: AccountBusiness, public sharedBusiness: SharedBusiness, private route: ActivatedRoute,
    private translate: TranslateService, protected asyncLocalStorage: LocalStorage,
    private sharedService: SharedService) {
    this.listViewdata = false;
    this.horizontalViewdata = false;
    this.product_List = new ChannelProductlist();
    this.products = new Array<Product>();
    this.Group = [];
    this.Category = [];
    this.brand = [];
    this.filterToogle = false;
    this.brandIds = [];
    this.familyIds = [];
    this.categoryIds = [];
    this.position = '';
    this.filterItems = new ChanneFilterItems();
    this.product_List.pagination = new Pagination();
    this.brandlistData = [];
    this.morecountry = false;
    this.selectedbrandchannelItems = [];
    this.selectedQualitychannelItems = [];
    this.selectedGroupchannelItems = [];
    this.selectedIsFreeSamples = [];
    this.selectedproductcategory = [];
    this.dropdownbrandchannelSettings = {};
    this.dropdownQualitySettings = {};
    this.dropdownGroupchannelSettings = {};
    this.dropdownIsFreeSampleSettings = {};
    this.dropdownCategorychannelSettings = {};
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    this._NoDataFound = new NoDataFound();
    this.productTopSearchFlag = false;
    const _currencyTable: any = localStorage.getItem('currency_conversion_table');
    if (_currencyTable) {
      this.currencyTable = JSON.parse(_currencyTable);
    } else {
      this.getCurrencyConverionTable();
    }

    this.currencyTable.map((item) => {
      this.currencyMaster[item.currencyid] = item;
    });
  }

  // To get currency convertions
  getCurrencyConverionTable() {
    this.sharedService.getCurrencyConversionList().subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        localStorage.setItem(AppLocalStorageKeys.CURRENCY_CONVERTION_TABLE, JSON.stringify(result.body));
        this.currencyTable = result.body;
      }
    },
      (error) => {
        console.log(error);
      });
  }

  ngOnInit() {
    this.sortToggle = true;
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };

    this.productBrands = [];
    this.title = 'productSuggestion.title';
    this.titlemsg = 'productSuggestion.subtitle';
    this._NoDataFound.noDataImageSrc = '../assets/images/no-product.png';
    this._NoDataFound.noDataMsg = this.translate.instant('productSuggestion.noProductSuggestion');
    this.search = this.SearchText || '';
    this.searchdata = this.search;
    // this.changebrandList('');

    this.dropdownQualitySettings = {
      text: 'Select Positioning',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownbrandchannelSettings = {
      text: 'Select Brand',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownGroupchannelSettings = {
      text: 'Select Family',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownIsFreeSampleSettings = {
      singleSelection: true,
      text: 'Sample price',
      classes: 'myclass custom-dropdown-class custom-overflow  custom-single-select',
      maxHeight: '165'
    };

    this.dropdownCategorychannelSettings = {
      text: 'Select Category',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };
    this.isFrenchTech = false;

    if (localStorage.getItem('user-currency')) {
      this.showMyCurrencyBtn = true;
      // tslint:disable-next-line:radix
      this.userCurrencyID = parseInt(localStorage.getItem('user-currency'));
      this.userCurrency = this.currencyTable.filter(item => item.currencyid == this.userCurrencyID)[0];
    }

    this.productViewUrl = this.webUrl.PRODUCT_SUGGESTION_VIEW;
    if (this.productTopSearchFlag) {
      this.productViewUrl = this.webUrl.PRODUCT_SEARCHRESULT_VIEW;
    }

    // load data from localstorage
    this.asyncLocalStorage.getItem('product-' + RelationStatus.PRODUCTS_SUGGESTION).subscribe((data) => {
      if (data) {

        this.tableresult = data.query;
        this.search = this.searchdata = this.tableresult.searchKey;
        this.offSet = this.tableresult.pageNumber;
        this.pageSize = this.tableresult.limit;
        this.sortToggle = (this.tableresult.sort === 'desc') ? true : false;

        this.filterItems = data.filter;
        this.filterToogle = data.filter.toogle;
        this.isFrenchTech = data.filter.is_french_tech;

        // dropdown select
        this.selectedQualitychannelItems = data.selected.selectedQuality;
        this.selectedbrandchannelItems = data.selected.selectedBrands;
        this.selectedGroupchannelItems = data.selected.product;
        this.selectedproductcategory = data.selected.selectedCategories;
      }
    });

    this.route.queryParams.subscribe(
      (params: any) => {
        if (params.channelId) {
          this.getProductList(this.searchdata, this.offSet, this.pageSize, params.channelId);
        } else {
          this.getProductList(this.searchdata, this.offSet, this.pageSize);
        }
      },
      (error) => {
        console.log(error);
      });

  }

  morecountrydata() {
    this.morecountry = true;
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  filterreset() {
    this.filteractive = true;
    this.isFrenchTech = false;
    this.search = '';
    this.searchdata = '';
    this.position = '';
    this.brandIds = [];
    this.categoryIds = [];
    this.familyIds = [];
    delete this.filterItems.brandIds;
    delete this.filterItems.productCategoryIds;
    delete this.filterItems.productFamilyIds;
    delete this.filterItems.is_french_tech;
    this.selectedbrandchannelItems = [];
    this.selectedQualitychannelItems = [];
    this.selectedGroupchannelItems = [];
    this.selectedIsFreeSamples = [];
    this.selectedproductcategory = [];
    delete this.filterItems.retail_price_min;
    delete this.filterItems.retail_price_max;
    this.distributorcommisionfrom = 0;
    this.distributorcommisionto = 0;
    this.retailfrom = 0;
    this.retailto = 0;
    this.retailercommisionfrom = 0;
    this.retailercommisionto = 0;
    delete this.filterItems.retailer_commission_min;
    delete this.filterItems.retailer_commission_max;
    delete this.filterItems.distributor_commission_min;
    delete this.filterItems.distributor_commission_max;
    delete this.filterItems.is_sample_free;
    delete this.filterItems.quality;

    this.retailprice_max = this.retailprice_reset_max;
    this.retailprice_min = this.retailprice_reset_min;
    this.retailercommision_min = this.retailercommision_reset_min;
    this.retailercommision_max = this.retailercommision_reset_max;
    this.distributorcommision_max = this.distributorcommision_reset_max;
    this.distributorcommision_min = this.distributorcommision_reset_min;

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  listView() {
    this.listViewdata = true;
    this.horizontalViewdata = false;
  }

  horizontalView() {
    this.horizontalViewdata = true;
    this.listViewdata = false;
  }


  // search Function
  searchFunction(data) {
    this.searchdata = data;
    this.getProductList(data, this.offSet, this.pageSize);
  }

  filterData() {
    this.filteractive = true;
    if (this.selectedQualitychannelItems.length) {
      this.filterItems.quality = this.selectedQualitychannelItems.map(x => x.id);
    } else {
      delete this.filterItems.quality;
    }
    if (this.selectedproductcategory.length) {
      this.filterItems.productCategoryIds = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productCategoryIds;
    }
    if (this.selectedGroupchannelItems.length) {
      this.filterItems.productFamilyIds = this.selectedGroupchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productFamilyIds;
    }
    if (this.selectedIsFreeSamples.length) {
      if (this.selectedIsFreeSamples[0]['id'] === 0) {
        this.filterItems.is_sample_free = false;
      } else {
        this.filterItems.is_sample_free = true;
      }
    } else {
      delete this.filterItems.is_sample_free;
    }
    if (this.selectedbrandchannelItems.length) {
      this.filterItems.brandIds = this.selectedbrandchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.brandIds;
    }
    this.filterItems.is_french_tech = this.isFrenchTech;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  getProductList(search, offSet, pageSize, channelId: number = null) {
    this.noresult = false;
    this.tableresult = {
      searchKey: search,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc',
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callProductList(channelId);
  }

  callProductList(channelId: number) {
    const selected = {
      selectedQuality: this.selectedQualitychannelItems,
      selectedBrands: this.selectedbrandchannelItems,
      product: this.selectedGroupchannelItems,
      selectedCategories: this.selectedproductcategory,
    };
    this._channelBusiness.ProductList(this.tableresult, this.filterItems, channelId, this.productTopSearchFlag,
      selected, this.filterToogle).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const product_List = response.json() as ChannelProductlist;
        this.aggregations = product_List.aggregations;
        this.resultCount = product_List.pagination.total;
        if (this.productTopSearchFlag) {
          const productChannelCount = {
            'product': product_List.pagination.total,
            'channel': product_List.others.company_count
          };
          this.channelCount.emit(productChannelCount);
        }
        if (this.resultCount === 0) {
          this.noresult = true;
        }
        this.products = product_List.results;
        this.products.forEach(product => {
          if (product.images.primary.length === 1) {
            product.defaultimage = product.images.primary[0].documentUrl;
          } else if (product.images.others.length > 0) {
            product.defaultimage = product.images.others[0].documentUrl;
          } else {
            product.defaultimage = '../assets/images/acc-logo.jpg';
          }
        });

        this.productQuality = [];
        if (this.aggregations['quality']) {
          this.defaultproductQuality = this.aggregations['quality']['buckets'];
          for (let i = 0; i < this.defaultproductQuality.length; i++) {
            this.productQuality.push({
              'id': this.defaultproductQuality[i].key,
              'itemName': this.defaultproductQuality[i].key,
              'count': this.defaultproductQuality[i].doc_count
            });
          }
        }

        this.productBrands = [];
        if (this.aggregations['brands']) {
          this.defaultbrands = this.aggregations['brands']['buckets'];
          for (let i = 0; i < this.defaultbrands.length; i++) {
            this.productBrands.push({
              'id': this.defaultbrands[i].key,
              'itemName': this.defaultbrands[i].label,
              'count': this.defaultbrands[i].doc_count
            });
          }
        }

        this.productCategory = [];
        if (this.aggregations['category']) {
          this.defaultproductCategory = this.aggregations['category']['buckets'];
          for (let i = 0; i < this.defaultproductCategory.length; i++) {
            this.productCategory.push({
              'id': this.defaultproductCategory[i].key,
              'itemName': this.defaultproductCategory[i].label,
              'count': this.defaultproductCategory[i].doc_count
            });
          }
        }

        this.productFamily = [];
        if (this.aggregations['family']) {
          this.defaultproductFamily = this.aggregations['family']['buckets'];
          for (let i = 0; i < this.defaultproductFamily.length; i++) {
            this.productFamily.push({
              'id': this.defaultproductFamily[i].key,
              'itemName': this.defaultproductFamily[i].label,
              'count': this.defaultproductFamily[i].doc_count
            });
          }
        }

        this.productIsFree = [];
        if (this.aggregations['free_sample']) {
          this.defaultproductIsFree = this.aggregations['free_sample']['buckets'];
          for (let i = 0; i < this.defaultproductIsFree.length; i++) {
            this.productIsFree.push({
              'id': this.defaultproductIsFree[i].key,
              'itemName': this.defaultproductIsFree[i].key ? 'Free' : 'Paid',
              'count': this.defaultproductIsFree[i].doc_count
            });
          }
        }

        // if (isloadedFirst) {
        this.retailprice_min = product_List.aggregations.retail_min_price.value;
        this.retailprice_max = product_List.aggregations.retail_max_price.value;

        if (this.retailprice_reset_min <= 0) {
          this.retailprice_reset_min = this.retailprice_min;
        }

        if (this.retailprice_reset_max <= 0) {
          this.retailprice_reset_max = this.retailprice_max;
        }

        this.distributorcommision_min = product_List.aggregations.distributer_min_margin.value;
        this.distributorcommision_max = product_List.aggregations.distributer_max_margin.value;

        if (this.distributorcommision_reset_min <= 0) {
          this.distributorcommision_reset_min = this.distributorcommision_min;
        }

        if (this.distributorcommision_reset_max <= 0) {
          this.distributorcommision_reset_max = this.distributorcommision_max;
        }

        this.retailercommision_min = product_List.aggregations.retailer_min_margin.value;
        this.retailercommision_max = product_List.aggregations.retailer_max_margin.value;

        if (this.retailercommision_reset_min <= 0) {
          this.retailercommision_reset_min = this.retailercommision_min;
        }

        if (this.retailercommision_reset_max <= 0) {
          this.retailercommision_reset_max = this.retailercommision_max;
        }
        // }

        this.preloader = false;
        this.setPage(this.tableresult.pageNumber);
        this.productLoaded.emit(true);
      } else {
        this.noresult = true;
        this.productLoaded.emit(false);
      }
    });

  }

  paginationFunction(data: number) {
    this.getProductList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getProductList(this.searchdata, 1, pageSize);
  }

  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  retailerPriceChange(event) {
    this.retailfrom = event.from;
    this.retailto = event.to;
    if (!ValidationService.isNullOrEmpty(this.retailfrom) && this.retailfrom !== 0) {
      this.filterItems.retail_price_min = this.retailfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailto) && this.retailto !== 0) {
      this.filterItems.retail_price_max = this.retailto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  distributorcommision(event) {
    this.distributorcommisionfrom = event.from;
    this.distributorcommisionto = event.to;
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionfrom) && this.distributorcommisionfrom !== 0) {
      this.filterItems.distributor_commission_min = this.distributorcommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionto) && this.distributorcommisionto !== 0) {
      this.filterItems.distributor_commission_max = this.distributorcommisionto;
    }

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  retailercommision(event) {
    this.retailercommisionfrom = event.from;
    this.retailercommisionto = event.to;

    if (!ValidationService.isNullOrEmpty(this.retailercommisionfrom) && this.retailercommisionfrom !== 0) {
      this.filterItems.retailer_commission_min = this.retailercommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailercommisionto) && this.retailercommisionto !== 0) {
      this.filterItems.retailer_commission_max = this.retailercommisionto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  // productView() {
  //   this.router.navigate(['/product/productadd']);
  // }

  // Search the Brand List
  changebrandList(event) {
    // if (this.brandtextlength.length >= 1) {
    this.accountBusiness.getBrandList(event, 0).subscribe(result => {
      this.brandlistData = result as Array<any>;
      if (this.brandlistData.length > 0) {
        for (let i = 0; i < this.brandlistData.length; i++) {
          this.brand.push({ 'id': this.brandlistData[i].id, 'itemName': this.brandlistData[i].Name });
        }
      } else {
        console.log('error');
      }

    },
      (error) => {
        console.log(error);
      });
    // }
  }

  getCurrencyConverion(currencyId, price) {
    let convRate = 1;
    if (+this.currencyMaster[currencyId].currencyid !== +this.userCurrencyID) {
      convRate = this.currencyMaster[currencyId].conversion_rate.rates[this.userCurrency.currencycode];
    }

    return (price * convRate).toFixed(2);
  }

  public showMyCurrency() {
    this.showMyCurrencyFlag = true;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= 1024) {
      this.listView();
    }
  }
}
