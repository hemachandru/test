import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import {
  MoreListViewEnum, ChannelTypeIdEnum, CurrencyType, ProductQuality, ChannelType
} from '@app/config/constant';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import {
  datatable,
  MoreListFilter,
  ChannelTitleInfo,
  ChannelProductlist,
  ChanneFilterItems,
  BrandId, GroupId, CatgoryId, Product
} from '@app/channel/models/channel_models';
import { NoDataFound } from '@app/shared/models/shared-model';
import { Pagination } from '@app/shared/models/contact-list-models';
import { BrandResult } from '@app/shared/models/shared-model';
import { Response } from '@angular/http';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { TranslateService } from '@ngx-translate/core';
import { AppLocalStorageKeys } from '@app/config/constant_keys';

@Component({
  selector: 'app-more-list',
  templateUrl: './more-list.component.html',
  styleUrls: ['./more-list.component.scss']
})

export class MoreListComponent implements OnInit, OnDestroy {
  tileImageAltPath: string;
  tileTitle: string;
  UserTypeId: string;
  title: string;
  titleMsg: string;
  channelName: string;
  channelType: string;
  currentView: number;
  public viewTypes = MoreListViewEnum;
  public companyList: any = [];
  public moreResultCount: number;
  public preloader: boolean;
  public filterresult: MoreListFilter;
  public pagination: any;
  public pager: any = {};
  public pageSize = 10;
  public pagedItems: any[];
  public result: any = [];
  public offSet = 1;
  public _NoDataFound: NoDataFound;
  public channelTitleInfo: ChannelTitleInfo;
  public moreProducts: Array<Product>;
  private product_List: ChannelProductlist = new ChannelProductlist();
  public isProductVerticalView: boolean;
  public brandList: BrandResult;
  public officialDistributorList: any;
  tileImage: string;
  currentChannelId?: number;
  currentChanneltypeId: number;
  currentChannelName: string;
  currentChanneltypeName: string;
  currentBrandId: number;
  public channelStatusType: number;
  public channelStatusTypeName: string;
  public excludedBrandId: number;
  public categorysetting: Object;
  public productsetting: Object;
  public originCountry: Object;
  public setting: Object;

  // Filter suggestion variables
  selectedbrandchannelItems: Array<any> = new Array<any>();
  filterToogle = false;
  aggregations: any;
  public country: Array<any> = new Array<any>();
  public location: Array<any> = new Array<any>();
  public productGroup: Array<any> = new Array<any>();
  public productCategory: Array<any> = new Array<any>();
  public productBrands: Array<any> = new Array<any>();
  public defaultcountry: Array<any> = new Array<any>();
  public defaultlocation: Array<any> = new Array<any>();
  public defaultproductCategory: Array<any> = new Array<any>();
  public defaultproductGroup: Array<any> = new Array<any>();
  public selectedproductcategory: Array<any> = new Array<any>();
  public selectedcountries: Array<any> = new Array<any>();
  public selectedlocations: Array<any> = new Array<any>();
  public selectedproduct: Array<any> = new Array<any>();
  public defaultbrands: Array<any> = new Array<any>();
  public search: string;
  noresult: boolean;

  public tableresult: datatable;
  public filtershow: boolean;
  public filteractive: boolean;
  public sortToggle: boolean;
  public searchdata: string;

  // product filters
  public productFilterItems: ChanneFilterItems = new ChanneFilterItems();
  public selectedQualitychannelItems: Array<any> = new Array<any>();
  public selectedGroupchannelItems: Array<any> = new Array<any>();
  public selectedIsFreeSamples: Array<any> = new Array<any>();
  public dropdownbrandchannelSettings: Object = {};
  public dropdownQualitySettings: Object = {};
  public dropdownGroupchannelSettings: Object = {};
  public dropdownIsFreeSampleSettings: Object = {};
  public dropdownCategorychannelSettings: Object = {};
  public channelId: number;
  public _channelTypeEnum = ChannelTypeIdEnum;
  ratingdata: any;
  public _CurrencyType = CurrencyType;
  public showMyCurrencyBtn: Boolean;
  public showMyCurrencyFlag: Boolean;
  public userCurrencyID: number;
  public position: string;

  productFamily: any[];
  defaultproductFamily: any;
  productQuality: any[];
  defaultproductQuality: any;
  productIsFree: any[];
  defaultproductIsFree: any;

  public retailercommisionto: number;
  public retailercommisionfrom: number;
  public distributorcommisionto: number;
  public distributorcommisionfrom: number;
  public retailercommision_min: number;
  public retailercommision_max: number;
  public retailercommision_reset_min: number;
  public retailercommision_reset_max: number;
  public distributorcommision_max: number;
  public distributorcommision_min: number;
  public distributorcommision_reset_max: number;
  public distributorcommision_reset_min: number;
  public retailprice_max: number;
  public retailprice_min: number;
  public retailprice_reset_max: number;
  public retailprice_reset_min: number;
  public morecountry = false;
  public horizontalViewdata = false;
  public listViewdata = false;
  public _qualityEnum = ProductQuality;
  public Group: Array<any> = new Array<any>();
  public Category: Array<any> = new Array<any>();
  public brand: Array<any> = new Array<any>();
  public brandIds: Array<BrandId> = new Array<BrandId>();
  public familyIds: Array<GroupId> = new Array<GroupId>();
  public categoryIds: Array<CatgoryId> = new Array<CatgoryId>();
  public price: boolean;
  public resultCount: number;
  public retailfrom: number;
  public retailto: number;
  public brandlisFilter: any;
  public isBrandDisabled = true;
  public isFrenchTech: boolean;
  tileSubTitle: string;
  navigationSubscription: any;
  loggedInChannelType: string;
  isNotDistributor: boolean;

  constructor(private route: ActivatedRoute, private router: Router,
    private _channelBusiness: ChannelBusiness,
    private _pagination: PaginationService,
    public sharedBusiness: SharedBusiness,
    private translate: TranslateService
  ) {
    this._NoDataFound = new NoDataFound();
    this.title = 'channelMoreList.title';
    this.channelTitleInfo = new ChannelTitleInfo();
    this.product_List.pagination = new Pagination();
    this.isProductVerticalView = true;

    // Brand configs
    this.tileImage = 'document.documentUrl';
    this.tileTitle = 'brandName';
    this.tileImageAltPath = 'assets/images/pro-logo.jpg';

    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.noresult = false;
        this.filterToogle = false;
        this.sortToggle = true;
        this.route.queryParams.subscribe(params => {
          this.channelStatusType = parseInt(params['connectionid'], 10);
          this.channelStatusTypeName = params['connectionStatusTypeName'];
          this.currentChanneltypeId = parseInt(params['filterType'], 10);
          this.currentView = parseInt(params['viewType'], 10);
          this.currentChannelId = parseInt(params['channelId'], 10);
          this.currentChannelName = params['channelName'];
          this.currentBrandId = parseInt(params['brandId'], 10);
          this.excludedBrandId = parseInt(params['excludedBrand'], 10);
          this.setTitleMessage();
          this.initializeMoreList(this.channelStatusType, this.channelStatusTypeName, this.currentChanneltypeId);
        });
      }
    });
  }

  initializeMoreList(channelStatusType: number, channelStatusTypeName: string, channelType) {
    this.dropdownbrandchannelSettings = {};
    this.categorysetting = {};
    this.productsetting = {};
    this.setting = {};
    this.channelTitleInfo.channelName = this.currentChannelName;
    if (channelType === ChannelTypeIdEnum.VENDOR) {
      this.channelTitleInfo.channelType = 'Vendor';
    } else if (channelType === ChannelTypeIdEnum.DISTRIBUTOR) {
      this.channelTitleInfo.channelType = 'Distributor';
    } else if (channelType === ChannelTypeIdEnum.RETAILER) {
      this.channelTitleInfo.channelType = 'Retailer';
    } else if (channelType === ChannelTypeIdEnum.SALESREP) {
      this.channelTitleInfo.channelType = 'Salesrep';
    }
    this.currentChanneltypeName = this.channelTitleInfo.channelType;

    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('channelMoreList.noSearch');
    this.isFrenchTech = false;

    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.setSuggestionsFilterData();
      this.getChannelList(this.searchdata = '', this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.getBrandList(this.currentChannelId, this.searchdata = '', this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.getOfficialDistributorList(this.currentChannelId, this.searchdata = '', this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.filterProductData();
      // this.getProductList(this.searchdata = '', this.offSet, this.pageSize);
    } else {
      // navigate to dashboard
      this.router.navigate(['']);
    }
  }

  ngOnInit() {
    this.isNotDistributor = false;
    if (localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE)) {
      this.loggedInChannelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
      if (this.loggedInChannelType !== ChannelType.DISTRIBUTOR) {
        this.isNotDistributor = true;
      }
    }

    if (localStorage.getItem('user-currency')) {
      this.showMyCurrencyBtn = true;
      // tslint:disable-next-line:radix
      this.userCurrencyID = parseInt(localStorage.getItem('user-currency'));
    }

    this.dropdownbrandchannelSettings = {
      text: 'Select Brand',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Brand...',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    // this.dropdowninterestlevelSettings = {
    //   text: 'Select Interest Level',
    //   enableSearchFilter: true,
    //   classes: 'myclass custom-dropdown-class custom-overflow',
    //   noDataLabel: 'Search Interest...',
    //   selectAllText: 'Select All',
    //   unSelectAllText: 'UnSelect All',
    //   maxHeight: '150',
    //   badgeShowLimit: 1
    // };

    this.originCountry = {
      text: 'Select Country',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search country...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    }

    this.setting = {
      text: 'Select Location',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Location...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.categorysetting = {
      text: 'Select Category',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Category...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };
    this.productsetting = {
      text: 'Select Speciality',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Speciality...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdownQualitySettings = {
      text: 'Select Positioning',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Positioning...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdownGroupchannelSettings = {
      text: 'Select Positioning',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Quality...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdownIsFreeSampleSettings = {
      text: 'Select Price',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search price...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdownGroupchannelSettings = {
      text: 'Select Family',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Family...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.dropdownCategorychannelSettings = {
      text: 'Select Category',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      noDataLabel: 'Search Category...',
      labelKey: 'itemName',
      maxHeight: '150',
      badgeShowLimit: 1
    };

  }

  paginationFunction(data: number) {
    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.getChannelList(this.searchdata = '', data, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.getBrandList(this.currentChannelId, this.searchdata = '', data, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.getOfficialDistributorList(this.currentChannelId, this.searchdata = '', this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.getProductList(this.searchdata = '', data, this.pageSize);
    } else {
      // navigate to dashboard
    }
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.getChannelList(this.searchdata = '', 1, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.getBrandList(this.currentChannelId, this.searchdata = '', 1, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.getOfficialDistributorList(this.currentChannelId, this.searchdata = '', 1, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.getProductList(this.searchdata = '', 1, this.pageSize);
    } else {
      // navigate to dashboard
    }
  }

  getChannelList(searchdata, offSet, pageSize) {
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };

    this.companyList = [];
    this.moreResultCount = 0;
    this.preloader = true;
    this.noresult = false;
    this.callChannelList();
  }

  callChannelList() {
    const selected = {
      selectedproduct: this.selectedproduct,
      selectedproductcategory: this.selectedproductcategory,
      selectedcountries: this.selectedcountries,
      selectedlocations: this.selectedlocations,
      selectedbrandchannelItems: this.selectedbrandchannelItems,
      selectedinterestlevelItems: null
    };
    this._channelBusiness.getSimilarCompanies(this.tableresult, this.filterresult, selected, this.filterToogle).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        const listresult = res.json();
        this.companyList = listresult.results;
        this.aggregations = listresult.aggregations;
        this.pagination = listresult.pagination;
        this.moreResultCount = this.pagination.total;
        if (this.moreResultCount === 0) {
          this.noresult = true;
        } else {
          this.noresult = false;
        }
        this.loadFilterControls();
        this.setPage(this.tableresult.pageNumber);
      }

      for (let i = 0; i < this.companyList.length; i++) {
        this.companyList[i].customedata = false;
      }
      this.preloader = false;
    },
      (error) => {
        this.noresult = true;
        this.preloader = false;
        console.log(error);
      });
  }

  setPage(page: number) {

    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.moreResultCount, page, this.pageSize);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.moreResultCount, page, this.pageSize);
    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  getProductList(searchdata, offSet, pageSize) {
    this.preloader = true;
    // this.product_List.pagination.page = pageSize;
    // this.product_List.pagination.offset = offSet;
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    // Commented and modified due to multifilter implementation
    // this._channelBusiness.ProductList(this.filterresult, this.searchdata = '', this.product_List.pagination).subscribe(res => {
    this._channelBusiness.ProductList(this.tableresult, this.productFilterItems, this.currentChannelId).subscribe(res => {
      this.preloader = false;
      const response = res as Response;
      // let j = 0;
      if (response.ok) {
        const product_List = res.json() as ChannelProductlist;
        this.aggregations = product_List.aggregations;
        this.moreResultCount = product_List.pagination.total;
        if (this.moreResultCount === 0) {
          this.noresult = true;
        } else {
          this.noresult = false;
        }

        this.loadProductFilterControls(product_List);

        // this.moreProducts = product_List.results;
        // this.moreProducts.forEach(product => {
        //   if (product.images.primary.length === 1) {
        //     product.defaultimage = product.images.primary[0].documentUrl;
        //   } else if (product.images.others.length > 0) {
        //     product.defaultimage = product.images.others[0].documentUrl;
        //   } else {
        //     product.defaultimage = '../assets/images/acc-logo.jpg';
        //   }
        // });
      } else {
      }
      this.setPage(offSet);
    });
  }

  // Get Brand List
  getBrandList(channelId, searchdata, offSet, pageSize) {
    if (this.currentChanneltypeId !== ChannelTypeIdEnum.RETAILER) {
      this.preloader = true;
      this.tableresult = {
        searchKey: searchdata,
        pageNumber: offSet,
        limit: pageSize,
        sort: this.sortToggle ? 'desc' : 'asc'
      };

      if (this.excludedBrandId) {
        this.brandlisFilter = {
          'excludedBrand': [this.excludedBrandId]
        };
      } else {
        this.brandlisFilter = null;
      }

      this.sharedBusiness.getChannelBrandList(channelId, true, this.tableresult, this.brandlisFilter).subscribe(response => {
        const result = response as Response;
        if (result.ok) {
          this.brandList = result.json();
          this.pagination = this.brandList.pagination;
          this.moreResultCount = this.brandList.pagination.total;
          if (this.moreResultCount === 0) {
            this.noresult = true;
          } else {
            this.noresult = false;
          }
          this.setPage(this.tableresult.pageNumber);
        }
      }, (error) => {
        console.log(error);
      });
      this.preloader = false;
    }
  }

  // Get Official Distributor List
  getOfficialDistributorList(channelId, searchdata, offSet, pageSize) {
    // Brand configs
    this.tileImage = 'logo.url';
    this.tileSubTitle = 'country.name';
    this.tileTitle = 'name';
    this.preloader = true;
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };

    this.sharedBusiness.getOfficialDistributorList(channelId, true, this.tableresult).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.officialDistributorList = response.json();
        this.pagination = this.officialDistributorList.pagination;
        this.moreResultCount = this.officialDistributorList.pagination.total;
        if (this.moreResultCount === 0) {
          this.noresult = true;
        } else {
          this.noresult = false;
        }
      }
    }, (error) => {
      console.log(error);
    });
    this.preloader = false;
  }

  setSuggestionsFilterData() {
    this.filteractive = true;
    delete this.filterresult;
    this.filterresult = {};

    if (this.selectedproduct.length) {
      this.filterresult.specialityId = this.selectedproduct.map(x => parseInt(x.id, 10));
    }

    if (this.selectedproductcategory.length) {
      this.filterresult.productCategoryId = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    }

    if (this.selectedlocations.length) {
      this.filterresult.locationId = this.selectedlocations.map(x => parseInt(x.id, 10));
    }

    if (this.selectedcountries.length) {
      this.filterresult.countryId = this.selectedcountries.map(x => parseInt(x.id, 10));
    }

    if (this.selectedbrandchannelItems.length) {
      this.filterresult.brandId = this.selectedbrandchannelItems.map(x => parseInt(x.id, 10));
    }

    if (this.currentChannelId) {
      this.filterresult.typeId = this.currentChannelId;
    }

    if (this.currentChannelId) {
      this.filterresult.channelId = this.currentChannelId;
    }

  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }


  filterreset() {
    this.filteractive = false;
    this.isFrenchTech = false;
    this.searchdata = '';
    // this.search = '';
    this.selectedproductcategory = [];
    this.selectedcountries = [];
    this.selectedlocations = [];
    this.selectedproduct = [];
    this.selectedbrandchannelItems = [];
    delete this.filterresult.locationId;
    delete this.filterresult.countryId;
    delete this.filterresult.specialityId;
    delete this.filterresult.productCategoryId;
    delete this.filterresult.brandId;
    delete this.filterresult.is_french_tech;
    this.getChannelList(this.searchdata, this.offSet, this.pageSize);
  }


  filterData() {
    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.setSuggestionsFilterData();
      this.filterresult.is_french_tech = this.isFrenchTech;
      this.getChannelList(this.searchdata, this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.filterProductData();
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.getBrandList(this.currentChannelId, this.searchdata, this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.getOfficialDistributorList(this.currentChannelId, this.searchdata, this.offSet, this.pageSize);
    }
  }

  loadFilterControls() {
    this.country = [];
    if (this.aggregations['country']) {
      this.defaultcountry = this.aggregations['country']['buckets'];
      for (let i = 0; i < this.defaultcountry.length; i++) {
        this.country.push({
          'id': this.defaultcountry[i].key,
          'itemName': this.defaultcountry[i].label,
          'count': this.defaultcountry[i].doc_count
        });
      }
    }

    this.location = [];
    if (this.aggregations['location']) {
      this.defaultlocation = this.aggregations['location']['buckets'];
      for (let i = 0; i < this.defaultlocation.length; i++) {
        this.location.push({
          'id': this.defaultlocation[i].key,
          'itemName': this.defaultlocation[i].label,
          'count': this.defaultlocation[i].doc_count
        });
      }
    }

    this.productGroup = [];
    if (this.aggregations['speciality']) {
      this.defaultproductGroup = this.aggregations['speciality']['buckets'];
      for (let i = 0; i < this.defaultproductGroup.length; i++) {
        this.productGroup.push({
          'id': this.defaultproductGroup[i].key,
          'itemName': this.defaultproductGroup[i].label,
          'count': this.defaultproductGroup[i].doc_count
        });
      }
    }

    this.productCategory = [];
    if (this.aggregations['category']) {
      this.defaultproductCategory = this.aggregations['category']['buckets'];
      for (let i = 0; i < this.defaultproductCategory.length; i++) {
        this.productCategory.push({
          'id': this.defaultproductCategory[i].key,
          'itemName': this.defaultproductCategory[i].label,
          'count': this.defaultproductCategory[i].doc_count
        });
      }
    }

    this.productBrands = [];
    if (this.aggregations['brands']) {
      this.defaultbrands = this.aggregations['brands']['buckets'];
      for (let i = 0; i < this.defaultbrands.length; i++) {
        this.productBrands.push({
          'id': this.defaultbrands[i].key,
          'itemName': this.defaultbrands[i].label,
          'count': this.defaultbrands[i].doc_count
        });
      }
    }
  }

  onTileItemClicked(event) {
    this.currentView = MoreListViewEnum.PRODUCT_LIST_VIEW;
    this.router.navigate(['/channel/morelist'],
      {
        queryParams: {
          connectionid: this.channelStatusType,
          connectionStatusTypeName: this.channelStatusTypeName,
          filterType: this.currentChanneltypeId,
          viewType: MoreListViewEnum.PRODUCT_LIST_VIEW,
          channelId: this.currentChannelId,
          channelName: this.currentChannelName,
          brandId: event.id,
        }
      });
  }

  onTileItemClickedChannel(tileItem) {
    this.router.navigate(['/channel/morelist/channelView/', tileItem.id]);
  }

  searchFunction(searchText: string) {
    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.getChannelList(searchText, this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.getProductList(searchText, this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.getBrandList(this.currentChannelId, searchText, this.offSet, this.pageSize);
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.getOfficialDistributorList(this.currentChannelId, searchText, this.offSet, this.pageSize);
    }
  }

  filterProductData() {
    this.filteractive = true;
    if (this.selectedQualitychannelItems.length) {
      this.productFilterItems.quality = this.selectedQualitychannelItems.map(x => x.id);
    } else {
      delete this.productFilterItems.quality;
    }
    if (this.selectedproductcategory.length) {
      this.productFilterItems.productCategoryIds = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    } else {
      delete this.productFilterItems.productCategoryIds;
    }
    if (this.selectedGroupchannelItems.length) {
      this.productFilterItems.productFamilyIds = this.selectedGroupchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.productFilterItems.productFamilyIds;
    }
    if (this.selectedIsFreeSamples.length) {
      if (this.selectedIsFreeSamples[0]['id'] === 0) {
        this.productFilterItems.is_sample_free = false;
      } else {
        this.productFilterItems.is_sample_free = true;
      }
    } else {
      delete this.productFilterItems.is_sample_free;
    }
    if (this.selectedbrandchannelItems.length) {
      this.productFilterItems.brandIds = this.selectedbrandchannelItems.map(x => parseInt(x.id, 10));
    } else if (this.currentBrandId) {
      this.productFilterItems.brandIds = [];
      this.productFilterItems.brandIds.push(this.currentBrandId);
    } else {
      delete this.productFilterItems.brandIds;
    }

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  filterProductreset() {
    this.filteractive = true;

    this.search = '';
    this.searchdata = '';
    this.position = '';
    this.brandIds = [];
    this.categoryIds = [];
    this.familyIds = [];
    delete this.productFilterItems.brandIds;
    delete this.productFilterItems.productCategoryIds;
    delete this.productFilterItems.productFamilyIds;
    this.selectedbrandchannelItems = [];
    this.selectedQualitychannelItems = [];
    this.selectedGroupchannelItems = [];
    this.selectedIsFreeSamples = [];
    this.selectedproductcategory = [];
    delete this.productFilterItems.retail_price_min;
    delete this.productFilterItems.retail_price_max;
    this.distributorcommisionfrom = 0;
    this.distributorcommisionto = 0;
    this.retailfrom = 0;
    this.retailto = 0;
    this.retailercommisionfrom = 0;
    this.retailercommisionto = 0;
    delete this.productFilterItems.retailer_commission_min;
    delete this.productFilterItems.retailer_commission_max;
    delete this.productFilterItems.distributor_commission_min;
    delete this.productFilterItems.distributor_commission_max;
    delete this.productFilterItems.is_sample_free;
    delete this.productFilterItems.quality;

    this.retailprice_max = this.retailprice_reset_max;
    this.retailprice_min = this.retailprice_reset_min;
    this.retailercommision_min = this.retailercommision_reset_min;
    this.retailercommision_max = this.retailercommision_reset_max;
    this.distributorcommision_max = this.distributorcommision_reset_max;
    this.distributorcommision_min = this.distributorcommision_reset_min;

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  loadProductFilterControls(product_List: any) {
    this.moreProducts = product_List.results;
    this.moreProducts.forEach(product => {
      if (product.images.primary.length === 1) {
        product.defaultimage = product.images.primary[0].documentUrl;
      } else if (product.images.others.length > 0) {
        product.defaultimage = product.images.others[0].documentUrl;
      } else {
        product.defaultimage = '../assets/images/acc-logo.jpg';
      }
    });

    this.productQuality = [];
    if (this.aggregations['quality']) {
      this.defaultproductQuality = this.aggregations['quality']['buckets'];
      for (let i = 0; i < this.defaultproductQuality.length; i++) {
        this.productQuality.push({
          'id': this.defaultproductQuality[i].key,
          'itemName': this.defaultproductQuality[i].key,
          'count': this.defaultproductQuality[i].doc_count
        });
      }
    }

    this.productBrands = [];
    if (this.aggregations['brands']) {
      this.defaultbrands = this.aggregations['brands']['buckets'];
      for (let i = 0; i < this.defaultbrands.length; i++) {
        this.productBrands.push({
          'id': this.defaultbrands[i].key,
          'itemName': this.defaultbrands[i].label,
          'count': this.defaultbrands[i].doc_count
        });
      }
    }

    this.productCategory = [];
    if (this.aggregations['category']) {
      this.defaultproductCategory = this.aggregations['category']['buckets'];
      for (let i = 0; i < this.defaultproductCategory.length; i++) {
        this.productCategory.push({
          'id': this.defaultproductCategory[i].key,
          'itemName': this.defaultproductCategory[i].label,
          'count': this.defaultproductCategory[i].doc_count
        });
      }
    }

    this.productFamily = [];
    if (this.aggregations['family']) {
      this.defaultproductFamily = this.aggregations['family']['buckets'];
      for (let i = 0; i < this.defaultproductFamily.length; i++) {
        this.productFamily.push({
          'id': this.defaultproductFamily[i].key,
          'itemName': this.defaultproductFamily[i].label,
          'count': this.defaultproductFamily[i].doc_count
        });
      }
    }

    this.productIsFree = [];
    if (this.aggregations['free_sample']) {
      this.defaultproductIsFree = this.aggregations['free_sample']['buckets'];
      for (let i = 0; i < this.defaultproductIsFree.length; i++) {
        this.productIsFree.push({
          'id': this.defaultproductIsFree[i].key,
          'itemName': this.defaultproductIsFree[i].key ? 'Free' : 'Paid',
          'count': this.defaultproductIsFree[i].doc_count
        });
      }
    }

    // if (isloadedFirst) {
    this.retailprice_min = product_List.aggregations.retail_min_price.value;
    this.retailprice_max = product_List.aggregations.retail_max_price.value;

    if (this.retailprice_reset_min <= 0) {
      this.retailprice_reset_min = this.retailprice_min;
    }

    if (this.retailprice_reset_max <= 0) {
      this.retailprice_reset_max = this.retailprice_max;
    }

    this.distributorcommision_min = product_List.aggregations.distributer_min_margin.value;
    this.distributorcommision_max = product_List.aggregations.distributer_max_margin.value;

    if (this.distributorcommision_reset_min <= 0) {
      this.distributorcommision_reset_min = this.distributorcommision_min;
    }

    if (this.distributorcommision_reset_max <= 0) {
      this.distributorcommision_reset_max = this.distributorcommision_max;
    }

    this.retailercommision_min = product_List.aggregations.retailer_min_margin.value;
    this.retailercommision_max = product_List.aggregations.retailer_max_margin.value;

    if (this.retailercommision_reset_min <= 0) {
      this.retailercommision_reset_min = this.retailercommision_min;
    }

    if (this.retailercommision_reset_max <= 0) {
      this.retailercommision_reset_max = this.retailercommision_max;
    }
  }

  retailerPriceChange(event) {
    this.retailfrom = event.from;
    this.retailto = event.to;
    if (!ValidationService.isNullOrEmpty(this.retailfrom) && this.retailfrom !== 0) {
      this.productFilterItems.retail_price_min = this.retailfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailto) && this.retailto !== 0) {
      this.productFilterItems.retail_price_max = this.retailto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  distributorcommision(event) {
    this.distributorcommisionfrom = event.from;
    this.distributorcommisionto = event.to;
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionfrom) && this.distributorcommisionfrom !== 0) {
      this.productFilterItems.distributor_commission_min = this.distributorcommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionto) && this.distributorcommisionto !== 0) {
      this.productFilterItems.distributor_commission_max = this.distributorcommisionto;
    }

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  retailercommision(event) {
    this.retailercommisionfrom = event.from;
    this.retailercommisionto = event.to;

    if (!ValidationService.isNullOrEmpty(this.retailercommisionfrom) && this.retailercommisionfrom !== 0) {
      this.productFilterItems.retailer_commission_min = this.retailercommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailercommisionto) && this.retailercommisionto !== 0) {
      this.productFilterItems.retailer_commission_max = this.retailercommisionto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  public showMyCurrency() {
    this.showMyCurrencyFlag = true;
  }

  // TO Get Currency Conversion
  getCurrencyConverion(currencyId, price) {

    // if (this.userCurrencyID != currencyId) {
    const Currency: any = localStorage.getItem('currency_conversion_table');
    let convertedPrice;
    if (Currency) {
      const CurrencyTable = JSON.parse(Currency);
      const UserCurrency = this.getCurrencyCode(CurrencyTable, this.userCurrencyID); // this.currencyCode[this.userCurrencyID];
      const ProductCurrency = this.getCurrencyCode(CurrencyTable, currencyId); // this.currencyCode[currencyId]; //
      CurrencyTable.forEach(currency => {
        if (currency.currencycode !== ProductCurrency) {
          let convRate = 1;

          switch (UserCurrency) {
            case 'EUR':
              convRate = currency.conversion_rate.rates.USD;
              break;
            case 'USD':
              convRate = currency.conversion_rate.rates.EUR;
              break;
            default:
              convRate = 1;
          }

          convertedPrice = price * convRate;
        }
      });
    }
    if (convertedPrice) {
      return convertedPrice.toFixed(2);
    } else {
      return price;
    }
    /*}
    else {
      this.showMyCurrencyFlag = false;
      return price;
    }*/
  }

  getCurrencyCode(currencyObject, currencyID) {
    let retCode = '';
    currencyObject.forEach(currency => {
      // tslint:disable-next-line:triple-equals
      if (parseFloat(currency.currencyid) == parseFloat(currencyID)) {
        retCode = currency.currencycode;
      }
    });
    return retCode;
  }

  setTitleMessage() {
    if (this.currentView === MoreListViewEnum.SUGGESTION_VIEW) {
      this.titleMsg = 'channelMoreList.titleMsgMoreMatching';
    } else if (this.currentView === MoreListViewEnum.PRODUCT_LIST_VIEW) {
      this.titleMsg = 'channelMoreList.titleMsgChannelProducts';
    } else if (this.currentView === MoreListViewEnum.BRAND_LIST_VIEW) {
      this.titleMsg = this.currentChanneltypeId ===
        ChannelTypeIdEnum.DISTRIBUTOR ? 'channelMoreList.titleMsgDistributionBrands' :
        'channelMoreList.titleMsgChannelBrands';
    } else if (this.currentView === MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW) {
      this.titleMsg = 'channelMoreList.titleMsgOfficialDistributors';
    } else {
      this.titleMsg = 'channelMoreList.titleMsg';
    }
  }
  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  OnDataTableActionOccured() {
    this.preloader = true;
    this.callChannelList();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= 1024) {
      this.isProductVerticalView = true;
    }
  }
}
