import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Response } from '@angular/http';
import { MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';

import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { ChannelStatus, PopUpTitle, LeadManagement, PopUpSuccessMsg } from '@app/config/constant';
import {
  datatable, DismissReasons,
  SearchFilter, UpdateChannelData, Upgrade
} from '@app/channel/models/channel_models';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { UpdateDefaultContact } from '@app/shared/models/contact-list-models';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';

@Component({
  selector: 'app-more-list-datatable',
  templateUrl: './more-list-datatable.component.html',
  styleUrls: ['./more-list-datatable.component.scss']
})
export class MoreListDatatableComponent implements OnInit {
  public opts: ISlimScrollOptions;
  @Input() moreListSource;
  public _DismissReasons: Array<DismissReasons>;
  public _NoDataFound: NoDataFound;
  public filterresult: SearchFilter;
  filterToogle: boolean;
  public upgrade: Upgrade;
  public showProductTitle: boolean;
  public _UpdateDefaultContact = new UpdateDefaultContact();
  public UserTypeId: string;
  public filtershow: boolean;
  public filteractive: boolean;
  public sortToggle: boolean;
  noresult: boolean;
  public TagLsit = LeadManagement;
  public _UpdateChannelData: UpdateChannelData;
  relationBtnName: string;
  @Output() actionOccurred = new EventEmitter<boolean>();
  constructor(public dialog: MatDialog, private route: ActivatedRoute, private router: Router,
    private _channelBusiness: ChannelBusiness, private toastr: ToastrService,
    public sharedBusiness: SharedBusiness,
    private translate: TranslateService) {
    this._NoDataFound = new NoDataFound();
    this.filterresult = new SearchFilter();
  }

  ngOnInit() {
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };

    this.showProductTitle = true;
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = 'channelList.noMessage.nosearch';

    this.upgrade = {
      show: false
    };

    this.UserTypeId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);

    this.filtershow = false;
    this.filteractive = true;
    this.sortToggle = true;
    this.noresult = false;
    this.filterToogle = false;

    this.filterresult = {
      typeId: 1
    };

    this.moreListSource.forEach(relation => {
      // tslint:disable-next-line:triple-equals
      if (relation.relation_status == 1) {
        this.relationBtnName = 'shared.buttonLabels.addProspect';
        // tslint:disable-next-line:triple-equals
      } else if (relation.relation_status == 2) {
        this.relationBtnName = 'shared.buttonLabels.addChannel';
        // tslint:disable-next-line:triple-equals
      } else if (relation.relation_status == 3) {
        this.relationBtnName = 'shared.buttonLabels.approval';
      } else {
        this.relationBtnName = 'shared.buttonLabels.editrating';
      }
    });

  }

  openaction(channellist) {
    channellist.customedata = !channellist.customedata;
  }

  updateChannelStatus(event, channelListdata) {
    let list = [];
    if (parseInt(event.target.id.split('-')[0], 10) === 5) {
      list = this._DismissReasons;
    }
    if (parseInt(event.target.id.split('-')[0], 10) === 18) {
      this.OpenConfirmDialog('Edit Interest Level', PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    } else {
      this.OpenConfirmDialog(event.target.text, PopUpTitle[parseInt(event.target.id.split('-')[0], 10)]
        , list, event.target.id, channelListdata.channel_jct_id, channelListdata.relation_tag);
    }
  }

  private OpenConfirmDialog(title: string, message: string, data: Array<DismissReasons>, id: string, jtcId, tag?: string) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        message: message,
        list: data,
        id: parseInt(id.split('-')[0], 10),
        channelId: parseInt(id.split('-')[1], 10),
        jtcChannelId: jtcId,
        tag: tag
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        if (parseInt(id.split('-')[0], 10) !== 17 && parseInt(id.split('-')[0], 10) !== 18) {
          this._UpdateChannelData = {
            connectionStatusTypeId: parseInt(id.split('-')[0], 10)
          };
          this._UpdateChannelData.channelJCTId = parseInt(jtcId, 10);
          if (this._UpdateChannelData.connectionStatusTypeId === 2) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
            this.toastr.success(this.translate.instant('channelList.toastrMsg.channelprospect'));
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 5) {
            this._UpdateChannelData.dismissreasonid = parseInt(responseType.dismissId, 10);
            if (this._UpdateChannelData.dismissreasonid === 6) {
              this._UpdateChannelData.otherreasons = responseType.others;
            }
          }
          if (this._UpdateChannelData.connectionStatusTypeId === 7) {
            this._UpdateChannelData.leadManagementTag = responseType.leadManagementTag;
          }
          this._channelBusiness.updateChannel(this._UpdateChannelData, true, parseInt(id.split('-')[1], 10)).subscribe(response => {
            if (response.ok) {
              // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
              this.actionOccurred.emit(true);
              const msg = this.translate.instant(PopUpSuccessMsg[this._UpdateChannelData.connectionStatusTypeId]);
              this.toastr.success(msg);
            } else {
              const msg = this.translate.instant(PopUpSuccessMsg[19]);
              this.toastr.error(msg);
            }
          });
        } else {
          if (parseInt(id.split('-')[0], 10) === 17) {
            this.changeAsDefault(responseType.channelId, responseType.contactId);
          } else if (parseInt(id.split('-')[0], 10) === 18) {
            const params = {
              channelJCTId: parseInt(jtcId, 10),
              leadManagementTag: responseType.leadManagementTag
            };
            /** Call Interest level service */
            this._channelBusiness.updateLeadManagementTag(params, true).subscribe(response => {
              if (response.ok) {
                this.actionOccurred.emit(true);
                // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
                const msg = this.translate.instant(PopUpSuccessMsg[18]);
                this.toastr.success(msg);
              } else {
                const msg = this.translate.instant(PopUpSuccessMsg[19]);
                this.toastr.error(msg);
              }
            });
          }
        }
      }
    });
  }

  changeAsDefault(jtcId, idContact) {
    localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'false');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'CommonUsageLabel.defaultContact',
        type: 2,
        message: 'CommonUsageLabel.defaultcontactAdd',
        list: [],
        id: 15,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'true');
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        this._UpdateDefaultContact.channelId = parseInt(jtcId, 10);
        this._UpdateDefaultContact.contactId = parseInt(idContact, 10);
        this.sharedBusiness.updateDefaultContact(this._UpdateDefaultContact, true).subscribe(response => {
          // const dataDefault = response as Response;
          if (response.ok) {
            // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
          }
        });
      }
    });
  }

  getUpgradeChannelList() {
    this._channelBusiness.UpgradeChannels(true).subscribe(response => {
      const res = response as Response;
      if (res.ok) {
        this.upgrade = <Upgrade>res.json();
      } else {
        this.upgrade.show = false;
      }
    });
  }

  viewContactDetails(event, channelListdata, relation_id) {
    const list = [];
    this.OpenContactDialog(event.target.text, PopUpTitle[11],
      channelListdata, event.target.id, channelListdata.channel_jct_id, relation_id);
  }

  private OpenContactDialog(title: string, message: string, data: any, id: string, jtcId: number, relation_id) {
    const dialogRef = this.dialog.open(ContactViewDialogComponent, {
      data: {
        title: this.translate.instant(message),
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: data.default_contact.id,
        channelId: data.channelId,
        jtcChannelId: jtcId,
        relation_id: relation_id,
        approvalstauts: (data.request && data.request === 'IN') ? 2 : 1,
        relation_tag: data.relation_tag ? data.relation_tag : 'Low'
      },
    });
    dialogRef.afterClosed().subscribe(responseType => {
      if (responseType && responseType.action === true) {
        /** variable for call again contact popup */
        const contactData = {
          title: title,
          channelListdata: data,
          relation_id: relation_id
        };

        if (responseType.contact === 1) { /** Open see all contact popup */
          this.OpenConfirmDialog(this.translate.instant('shared.buttonLabels.sellContacts'), PopUpTitle[10]
            , [], '17-' + data.id, jtcId, data.relation_status);
        } else if (responseType.contact === 2) { /** Open mail popup */
          // if (responseType.permission === 1 || responseType.permission === 7) {
          //   const relation = {
          //     id: relation_id,
          //     jtcChannelId: jtcId
          //   };
          //   // this.OpenRequestDialig(relation);
          // } else {
          this.sendEmail(responseType, contactData);
          // }
        }

      }
      // if (responseType.changes) {
        this.actionOccurred.emit(true);
      // }
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    });
  }

  /** Send email */
  public sendEmail(contact, contactdata) {
    const dialogRef = this.dialog.open(EmailPopupComponent, {
      data: {
        senderId: contact.userId,
        receiverId: contact.receiverId
      },
      width: '600px',
      height: 'auto'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      this.OpenContactDialog(contactdata.title, PopUpTitle[11],
        contactdata.channelListdata, '', contactdata.channelListdata.channel_jct_id, contactdata.relation_id);
    });
  }
}
