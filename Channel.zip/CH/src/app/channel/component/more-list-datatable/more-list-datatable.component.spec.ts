import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreListDatatableComponent } from './more-list-datatable.component';

describe('MoreListDatatableComponent', () => {
  let component: MoreListDatatableComponent;
  let fixture: ComponentFixture<MoreListDatatableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoreListDatatableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoreListDatatableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
