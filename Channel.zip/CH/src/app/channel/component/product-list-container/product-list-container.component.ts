import { Component, OnInit, Input } from '@angular/core';
import { Product } from '@app/channel/models/channel_models';
@Component({
  selector: 'app-product-list-container',
  templateUrl: './product-list-container.component.html',
  styleUrls: ['./product-list-container.component.scss']
})
export class ProductListContainerComponent implements OnInit {
  @Input() products: Array<Product>;
  @Input() isVerticalView: boolean;
  constructor() {
  }

  ngOnInit() {
  }

}

