import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.scss']
})
export class ContactListComponent implements OnInit {
  public title = 'My Contact';
  public titlemsg = 'View all your contact dairy with various channel partners like Vendors , Distributors , Retailers and Sales Rep';
  public contact_list: any;
  public filter: number;
  constructor() { }

  ngOnInit() {
    this.filter = 2;

    this.contact_list = [
      { id: 1, fname: 'Mr. Nice', lname: ' Pearson' , jobtitle : 'Sales' , partnername: 'BBB', type: 'Main Contact' },
      { id: 2, fname: 'Narco', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Secondary' },
      { id: 3, fname: 'Bombasto', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Main Contact' },
      { id: 4, fname: 'Celeritas', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Secondary' },
      { id: 5, fname: 'Magneta', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Main Contact' },
      { id: 6, fname: 'RubberMan', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Main Contact' },
      { id: 7, fname: 'Dynama', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB' , type: 'Secondary'},
      { id: 8, fname: 'Dr IQ', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB', type: 'Main Contact'},
      { id: 9, fname: 'Magma', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB' , type: 'Secondary'},
      { id: 10, fname: 'Tornado', lname: ' Pearson' , jobtitle : 'AAA' , partnername: 'BBB' , type: 'Main Contact'}
    ];

  }

  ChannelFilter(value) {
    this.filter = value;
  }

}
