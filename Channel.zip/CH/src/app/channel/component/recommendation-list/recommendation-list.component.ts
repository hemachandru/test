import { Component } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';

import { InvitationModel, InvitationResponse } from '@app/channel/models/invitation.model';
import { NoDataFound, PaginationQuery } from '@app/shared/models/shared-model';
import { InvitationBusiness } from '@app/channel/business/invitation.business';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { DialogRecomendationComponent } from '@app/product/component/dialog-recomendation/dialog-recomendation.component';
import { WebUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { ChannelTypeIdEnum, errorListInvitation, ButtonTypes } from '@app/config/constant';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';

@Component({
    selector: 'app-recommendation-list',
    templateUrl: './recommendation-list.component.html',
    styleUrls: ['./recommendation-list.component.scss']
})

export class RecommendationListComponent {
    public title = 'My Invitations';
    public titlemsg = '';
    public webUrl = WebUrl;
    public subtitle;
    public channelType = {
        2: 'Vendor',
        3: 'Distributor',
        4: 'Retailer'
    };
    dialogRef: MatDialogRef<MessageDialogComponent>;
    // preloader
    public preloader: boolean = false;

    // configure nodata found
    public _NoDataFound: NoDataFound = new NoDataFound({
        noDataImageSrc: '../assets/images/search.png',
        // noDataMsg: 'channelList.noMessage.nosearch'
    });

    public invitationList: Array<InvitationModel> = [];

    // sort button
    public sortToggle: boolean = true;
    public resultCount: number = 0;
    private _pagination: PaginationQuery = {
        limit: 12
    };
    pager: any = {};
    public filtershow: boolean;

    public get pagination(): PaginationQuery {
        return Object.assign(this._pagination, {
            sort: (this.sortToggle) ? 'desc' : 'asc'
        });
    }

    public set pagination(value: PaginationQuery) {
        this._pagination = value;
    }

    public resetPagination() {
        this.pagination = {
            limit: 12
        };
    }

    paginationFunction(page: number) {
        this.pagination.page = page;
        this.getInvitationList();
    }

    paginationFunctionOffset(limit: number) {
        this.pagination.limit = limit;
        this.getInvitationList();
    }

    // filter block
    public filterToogle: boolean = false;
    public tagControl: string = '';
    public filters = {
        // channelTypeIds: [],
        tag: [], // New, Active, Existing
        countryIds: []
    };

    public filterAggregations = {
        // channelTypeIds: [],
        country: []
    };

    public countrySetting: {};
    public countrySource = [];
    public countryList = [];

    // Get Country list

    getCountryList() {
        this.sharedBusiness.getCountryListBusiness().subscribe(data => {
            this.countrySource = data;
        });
    }

    tagChange(value) {
        this.filters.tag = [];
        if (value !== '') {
            if (value === 'InActive') {
                this.filters.tag = ['New', 'Existing']
            } else if (value === 'Active') {
                this.filters.tag = ['Active']
            }
        }

        this.getInvitationList();
    }

    constructor(
        private _invitationBusiness: InvitationBusiness,
        public sharedBusiness: SharedBusiness,
        private _paginationService: PaginationService,
        public dialog: MatDialog, private router: Router,
        private translate: TranslateService,
        private toastr: ToastrService
    ) {
        this.filtershow = false;

        this.getCountryList();
    }

    ngOnInit() {
        // get my invitation list
        this.getInvitationList();
        // this.openUpgradePopup();
        const channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
        this.subtitle = channelTypeId === ChannelTypeIdEnum.VENDOR ? this.translate.instant('recommendation.subtitle.vendor') :
            channelTypeId === ChannelTypeIdEnum.DISTRIBUTOR ? this.translate.instant('recommendation.subtitle.distributor') :
                this.translate.instant('recommendation.subtitle.retailer');
        this.countrySetting = {
            text: 'Select Country',
            enableSearchFilter: true,
            classes: 'myclass custom-dropdown-class custom-overflow',
            noDataLabel: 'Search Country...',
            maxHeight: '150',
            badgeShowLimit: 1,
            primaryKey: 'countryId',
            labelKey: 'country'
        };
    }

    getInvitationList() {
        this.preloader = true;
        this._invitationBusiness.getMyInvitationList(this.pagination, this.getFilterValues()).subscribe((response) => {
            if (response.ok) {
                response = response.json() as InvitationResponse;
                this.invitationList = response.results;
                this.getFormatedInvitationList();
                this.resultCount = response.pagination.total;

                if (this.countrySource && response.aggregations.country) {
                    this.countryList = [];
                    this.countrySource.forEach((country) => {       // VJ 26/03/2019 Sonar bug fix rmv .map -> .forEach
                        if (response.aggregations.country.includes(+country.countryId)) {
                            this.countryList.push(country);
                        }
                    });
                }
                this.pager = this._paginationService.setPage(this.pagination.page || 1, this.resultCount, this.pagination.limit, 12);
            }
            this.preloader = false;
        });
    }

    getFilterValues(): any {
        const filterValues: any = {};
        Object.keys(this.filters).forEach(key => {
            if (this.filters[key].length > 0) {
                if (key === 'countryIds') {
                    filterValues[key] = this.filters[key].map((item) => { return +item.countryId; });
                } else {
                    filterValues[key] = this.filters[key];
                }

            }
        });

        return filterValues;
    }

    isNoResult(): boolean {
        return (this.invitationList && this.invitationList.length <= 0);
    }

    getFormatedInvitationList() {
        this.invitationList.forEach(invitation => {
            let company: any = null;
            if (invitation.existchannelid) {
                company = invitation.existchannel;
            }
            invitation.companyname = (company) ? company.companyName : invitation.companyname;
            invitation.channelId = (company) ? company.channelId : null;
            invitation.channelType = this.channelType[(company) ? +company.channelTypeId : +invitation.suggested_type];
            invitation.tag = (invitation.active_id) ? 'Active' : 'InActive';
            invitation.websiteUrl = invitation.websiteurl;
            invitation.channelDocumentUrl = (invitation && invitation.active_channel && invitation.active_channel.channelDetail &&
                invitation.active_channel.channelDetail.channelLogo) ?
                invitation.active_channel.channelDetail.channelLogo.documentUrl : null;
            invitation.suggestedby_channelid = invitation.suggestedby_channelid ? invitation.suggestedby_channelid : null,
                invitation.suggestedby_type = invitation.suggestedby_type ? invitation.suggestedby_type : null,
                invitation.suggestedby = invitation.suggestedby ? invitation.suggestedby : null,
                invitation.suggestedto = invitation.suggestedto ? invitation.suggestedto : null,
                invitation.contact = {
                    name: (company && company.contact) ? company.contact.firstName + ' ' +
                        company.contact.lastName : invitation.contactname,
                    city: invitation.city,
                    country: (company && company.contact.country) ? company.contact.country.country : invitation.country.country,
                    jobTitle: (company && company.contact) ? company.contact.jobTitle : null,
                    email: (company && company.contact) ? company.contact.email : invitation.mail,
                    mobileNumber: (company && company.contact) ? company.contact.mobileNo : invitation.mobileno,
                    documentUrl: (company && company.contact && company.contact.document) ? company.contact.document.documentUrl : null
                };
        });
        // return this.invitationList.map(invitation => {

        //     let company: any = null;
        //     if (invitation.existchannelid) {
        //         company = invitation.existchannel;
        //     }

        //     return {
        //         companyname: (company) ? company.companyName : invitation.companyname,
        //         channelId: (company) ? company.channelId : null,
        //         channelType: this.channelType[(company) ? +company.channelTypeId : +invitation.suggested_type],
        //         tag: (invitation.tag === 'Active') ? 'Active' : 'InActive',
        //         websiteUrl: invitation.websiteurl,
        //         contact: {
        //             name: (company && company.contact) ? company.contact.firstName + ' ' +
        //              company.contact.lastName : invitation.contactname,
        //             city: invitation.city,
        //             country: (company && company.contact.country) ? company.contact.country.country : invitation.country.country,
        //             jobTitle: (company && company.contact) ? company.contact.jobTitle : null,
        //             email: (company && company.contact) ? company.contact.email : invitation.mail,
        //             mobileNumber: (company && company.contact) ? company.contact.mobileNo : invitation.mobileno,
        //             documentUrl: (company && company.contact && company.contact.document) ? company.contact.document.documentUrl : null
        //         }
        //     };
        // });
    }

    filterClk() {
        if (!this.filterToogle) {
            this.filterToogle = true;
        } else {
            this.filterToogle = false;
        }
    }

    clearAllFilters() {
        this.resetPagination();

        this.resetFilters();

        this.getInvitationList();
    }

    resetFilters() {
        this.pagination.search = '';
        this.tagControl = '';

        // reset all the filters
        this.filters = {
            // channelTypeIds: [],
            tag: [], // New, Active, Existing
            countryIds: []
        };
    }

    openDialogRecomendation() {
        const dialogRef = this.dialog.open(DialogRecomendationComponent, {
            data: {
                title: 'Invitation',
                suggestedTo: null,
                suggestedToType: null, // vendor
                suggestedType: null, // Distributor
                roleShow: true
            },
            panelClass: 'modalPointer'
        });
        dialogRef.afterClosed().subscribe(responseType => {
            document.getElementsByTagName('html').item(0).style.removeProperty('top');
            if (responseType === true) {
                this.getInvitationList();
            }
        });
    }

    redirectTo(channelId: number) {
        this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, channelId]);
    }

    reDirectToWebSite(url: string) {
        const link = url.indexOf('http') === 0 ? url : 'https://' + url;
        window.open(link, '_blank');
    }

    addToPartner(invitationId: number) {
        this.preloader = true;
        this._invitationBusiness.addToPartnerBusiness(invitationId).subscribe((response) => {
            this.preloader = false;
            if (response.ok) {
                response = response.json();
                this.toastr.success(this.translate.instant(errorListInvitation[response.code]));
                this.getInvitationList();
            } else {
                if (response.json()[0].errors[0].code === 3031) {
                    this.openUpgradePopup();
                    this.toastr.error(this.translate.instant(errorListInvitation[response.json()[0].errors[0].code]));
                } else {
                    this.toastr.error(this.translate.instant('commonMessage.somethingWentWrong'));
                }
            }
        });
    }

    openUpgradePopup() {
        const title = this.translate.instant('recommendation.upgradetitle');
        // const message = this.translate.instant('searchList.upgradeMsg');
        const message = this.translate.instant('recommendation.upgradeMsgViewChannel');
        this.dialogRef = this.dialog.open(MessageDialogComponent, {
            data: {
                title: title,
                type: ButtonTypes.UpgradeCancel,
                message: message
            }
        });

        this.dialogRef.afterClosed().subscribe(result => {
            if (result) {
                this.subscriptionPlan();
            }
            //  else {
            //     this.unauthorized = this.translate.instant('searchList.upgradeMsgViewChannel');
            //     this.subscription = true;
            // }
        });
    }

    /** call subscription plan */
    subscriptionPlan() {
        localStorage.setItem('RedirectId', '13');
        this.router.navigate(['/user/subscriptionplan']);
    }
}
