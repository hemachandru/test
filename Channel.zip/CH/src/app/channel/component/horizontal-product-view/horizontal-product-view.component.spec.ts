import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HorizontalProductViewComponent } from './horizontal-product-view.component';

describe('HorizontalProductViewComponent', () => {
  let component: HorizontalProductViewComponent;
  let fixture: ComponentFixture<HorizontalProductViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HorizontalProductViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HorizontalProductViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
