import { Component, OnInit, Input } from '@angular/core';
import { Product } from '@app/channel/models/channel_models';
import { ProductQuality, CurrencyType } from '@app/config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { WebUrl } from '@app/config/constant_keys';

@Component({
  selector: 'app-horizontal-product-view',
  templateUrl: './horizontal-product-view.component.html',
  styleUrls: ['./horizontal-product-view.component.scss']
})
export class HorizontalProductViewComponent implements OnInit {
  @Input() product: Product;
  _qualityEnum = ProductQuality;
  public opts: ISlimScrollOptions;
  public _CurrencyType = CurrencyType;
  public webUrl = WebUrl;

  constructor() { }

  ngOnInit() {
  }
}
