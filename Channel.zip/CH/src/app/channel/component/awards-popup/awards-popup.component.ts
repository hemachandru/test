import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { ISlimScrollOptions } from 'ng2-slimscroll';

@Component({
  selector: 'app-awards-popup',
  templateUrl: './awards-popup.component.html',
  styleUrls: ['./awards-popup.component.scss']
})
export class AwardsPopupComponent implements OnInit {
  public title: string;
  public awards = [];
  public opts: ISlimScrollOptions;
  constructor(public dialogRef: MatDialogRef<AwardsPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private _channelBusiness: ChannelBusiness) { }

  ngOnInit() {
    this.title = 'Awards';
    this.getAwards();
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  getAwards() {
    this.awards = this.data.awards;
  }

}
