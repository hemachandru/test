import { Injectable } from '@angular/core';
import { ApiUrl } from '@app/config/constant_keys';
import { HttpParams, HttpClient } from '@angular/common/http';
import { ChannelService } from '@app/channel/service/channel-service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { RelationStatus } from '@app/config/constant';

@Injectable()
export class ChannelBusiness {
  private apiUrl = ApiUrl;

  constructor(private _channelService: ChannelService, protected asyncLocalStorage: LocalStorage) {
  }

  getDissmissList(responseBool: boolean) {
    const url: any = this.apiUrl.DISMISS_REASONS;
    return this._channelService.getService(url, responseBool).map(res => {
      return res;
    });
  }

  ChannelList(datas, filters, filterDatas, filterToggle) {
    let params = new HttpParams();
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);

    const url: any = this.apiUrl.COMPANY_LIST + '?' + params;
    return this._channelService.postService(filters, url, true)
      .map(res => {
        const response = res as Response;
        if (response.ok) {
          let lists = (<any>response)._body;
          lists = JSON.parse(lists);

          // load data to localstorage
          this.asyncLocalStorage.setItemSubscribe('channel-list-relation-' + filters['relationId'], {
            query: datas,
            filter: Object.assign(filters, {
              toogle: filterToggle
            }),
            selected: filterDatas,
            response: lists.pagination,
            collectionIds: lists.results.map(item => (item.id))
          });
        }
        return res;
      });
  }

  updateChannel(data, responseBool: boolean, id: number) {
    const url: any = this.apiUrl.UPDATE_CHANNEL + '/' + id;
    return this._channelService.postService(data, url, responseBool).map(res => {
      return res;
    });
  }

  /**UPDATE Channel interset Level service*/
  updateLeadManagementTag(data, responseBool: boolean) {
    const url: any = this.apiUrl.UPDATE_INTERSET_LEVEL;
    return this._channelService.postService(data, url, responseBool).map(res => {
      return res;
    });
  }

  SearchList(datas, filters, filterDatas, filterToggle) {
    // SEARCH_RESULT
    let params = new HttpParams();
    datas.searchKey = datas.searchKey ? datas.searchKey : '';
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);
    params = params.set('product_count', 'true');
    const url: any = this.apiUrl.SEARCH_RESULT + '?' + params;
    return this._channelService.postService(filters, url, true)
      .map(res => {
        const response = res as Response;
        if (response.ok) {
          let lists = (<any>response)._body;
          lists = JSON.parse(lists);

          // load data to localstorage
          this.asyncLocalStorage.setItemSubscribe('channel-list-relation-' + filters['relationId'], {
            query: datas,
            filter: Object.assign(filters, {
              toogle: filterToggle
            }),
            selected: filterDatas,
            response: lists.pagination,
            collectionIds: lists.results.map(item => (item.id))
          });
        }
        return res;
      });
  }

  PreviousNextChannelList(datas, filters, filterDatas, filterToggle, channelOrSearch) {
    if (channelOrSearch === RelationStatus.TOP_SEARCH) {
      return this.SearchList(datas, filters, filterDatas, filterToggle);
    } else if (channelOrSearch === RelationStatus.MORE_MATCHING) {
      return this.getSimilarCompanies(datas, filters, filterDatas, filterToggle);
    } else {
      return this.ChannelList(datas, filters, filterDatas, filterToggle);
    }
  }

  channelCompanyBusiness(channelid: number) {
    const url: any = this.apiUrl.CHANNELDETAILVIEW;
    return this._channelService.getByIDService(channelid, url, true).map(res => {
      return res;
    });
  }

  dashboardchannelBusiness() {
    const url: any = this.apiUrl.MYCHANNELDETAIL;
    return this._channelService.getService(url, true).map(res => {
      return res;
    });
  }

  UpgradeChannels(responseBool: boolean) {
    const url: any = this.apiUrl.CHANNELUPGRADE;
    return this._channelService.getService(url, responseBool).map(res => {
      return res;
    });
  }


  ProductList(datas, filters, channelId: number = null, topSearch: boolean = false, filterDatas: object = {}
    , filterToggle: boolean = false) {
    let params = new HttpParams();
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);
    params = params.set('company_count', 'true');
    let url = '';
    if (channelId) {
      url = this.apiUrl.CHANNEL_PRODUCTS_LIST + '/' + channelId + '?' + params;
    } else {
      url = this.apiUrl.PRODUCT_SEARCH + '?' + params;
    }
    if (topSearch) {
      url = this.apiUrl.PRODUCT_TOP_SEARCH + '?' + params;
    }
    return this._channelService.postService(filters, url, true)
      .map(res => {
        const response = res as Response;
        if (response.ok && channelId === null) {
          let lists = (<any>response)._body;
          lists = JSON.parse(lists);
          // load data to localstorage
          this.asyncLocalStorage.setItemSubscribe('product-' + (topSearch ?
           RelationStatus.TOP_SEARCH_PRODUCT : RelationStatus.PRODUCTS_SUGGESTION), {
            query: datas,
            filter: Object.assign(filters, {
              toogle: filterToggle
            }),
            selected: filterDatas,
            response: lists.pagination,
            collectionIds: lists.results.map(item => (item.sku))
          });
        }

        return res;
      });
  }

  getOfficialDocuments(responseBool: boolean, channelId: number) {
    const url: any = this.apiUrl.OFFICIAL_DOCUMENTS + '/' + channelId;
    return this._channelService.getService(url, responseBool).map(res => {
      return res;
    });
  }

  getChannelClaim(responseBool: boolean, channelId: number) {
    const url: any = this.apiUrl.CHANNEL_CLAIM + '/' + channelId;
    return this._channelService.getService(url, responseBool).map(res => {
      return res;
    });
  }

  getSimilarCompanies(datas, filters, filterDatas, filterToggle) {
    // SEARCH_RESULT
    let params = new HttpParams();
    datas.searchKey = datas.searchKey ? datas.searchKey : '';
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);
    const url: any = this.apiUrl.SIMILAR_COMPANY + '?' + params;
    return this._channelService.postService(filters, url, true)
      .map(res => {
        const response = res as Response;
        if (response.ok) {
          let lists = (<any>response)._body;
          lists = JSON.parse(lists);

          // load data to localstorage
          this.asyncLocalStorage.setItemSubscribe('channel-list-relation-' + RelationStatus.MORE_MATCHING, {
            query: datas,
            filter: Object.assign(filters, {
              toogle: filterToggle
            }),
            selected: filterDatas,
            response: lists.pagination,
            collectionIds: lists.results.map(item => (item.id))
          });
        }
        return res;
      });
  }

}
