import { Injectable } from "@angular/core";
import { ApiUrl } from "@app/config/constant_keys";
import { InvitationService } from "../service/invitation.service";
import { HttpParams } from "@angular/common/http";

@Injectable()
export class InvitationBusiness {
    apiUrl: any = ApiUrl;

    constructor(private _invitationService: InvitationService) {
    }

    getMyInvitationList(data, filters) {
       

        const url: any = this.apiUrl.MY_INVITATION_LIST + '?' +  new HttpParams({
            fromObject: data
        });
        
        return this._invitationService.postService(filters, url, true);
    }

    addToPartnerBusiness(invitationId: number) {
        const url: any = this.apiUrl.ADD_TO_PARTNER + '/' + invitationId;
        return this._invitationService.postService('', url, true);
    }
}
