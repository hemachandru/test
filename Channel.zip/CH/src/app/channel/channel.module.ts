import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChannelRoutingModule } from './channel-routing.module';
import { SharedModule } from './../shared/shared.module';
import { IonRangeSliderModule } from 'ng2-ion-range-slider';

import { ChannelDetailViewComponent } from './component/channel-detail-view/channel-detail-view.component';
import { ChannelListComponent } from './component/channel-list/channel-list.component';
import { SearchResultComponent } from './component/search-result/search-result.component';
import { ContactListComponent } from './component/contact-list/contact-list.component';
import { ChannelBusiness } from './business/channel.business';
import { ChannelService } from './service/channel-service';
import { ProductListComponent } from './component/product-list/product-list.component';
import { SlimScrollModule } from 'ng2-slimscroll';
import { MoreListComponent } from '@app/channel/component/more-list/more-list.component';
import { MoreListDatatableComponent } from '@app/channel/component/more-list-datatable/more-list-datatable.component';
import { ProductListContainerComponent } from '@app/channel/component/product-list-container/product-list-container.component';
import { HorizontalProductViewComponent } from '@app/channel/component/horizontal-product-view/horizontal-product-view.component';
import { VerticalProductViewComponent } from '@app/channel/component/vertical-product-view/vertical-product-view.component';
import { AwardsPopupComponent } from '@app/channel/component/awards-popup/awards-popup.component';
import { RecommendationListComponent } from './component/recommendation-list/recommendation-list.component';
import { InvitationBusiness } from './business/invitation.business';
import { InvitationService } from './service/invitation.service';
import { TooltipModule } from 'ng2-tooltip';

export const COMPONENTS = [
  ChannelListComponent,
  ChannelDetailViewComponent,
  SearchResultComponent,
  ContactListComponent,
  ProductListComponent,
  MoreListComponent,
  MoreListDatatableComponent,
  ProductListContainerComponent,
  HorizontalProductViewComponent,
  VerticalProductViewComponent,
  AwardsPopupComponent,
  RecommendationListComponent,
];

@NgModule({
  imports: [
    CommonModule,
    ChannelRoutingModule,
    SharedModule,
    IonRangeSliderModule,
    SlimScrollModule,
    FormsModule,
    TooltipModule
  ],
  declarations: COMPONENTS,
  exports: COMPONENTS,
  entryComponents: COMPONENTS,
  providers: [ChannelBusiness, ChannelService, InvitationBusiness, InvitationService]
})
export class ChannelModule { }
