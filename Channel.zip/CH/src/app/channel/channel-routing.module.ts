import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChannelDetailViewComponent } from './component/channel-detail-view/channel-detail-view.component';
import { ChannelListComponent } from './component/channel-list/channel-list.component';
import { SearchResultComponent } from './component/search-result/search-result.component';
import { ContactListComponent } from './component/contact-list/contact-list.component';
import { ProductListComponent } from './component/product-list/product-list.component';
import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';
import { MoreListComponent } from '@app/channel/component/more-list/more-list.component';
import { ViewProductComponent } from '@app/product/component/view-product/view-product.component';
import { RatingDetailViewComponent } from '@app/order/rating-detail-view/rating-detail-view.component';
import { RecommendationListComponent } from './component/recommendation-list/recommendation-list.component';

const routes: Routes = [
    {
        path: 'channel', children:
            [
                { path: '', redirectTo: 'suggestions', pathMatch: 'full' },
                {
                    path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                    data: {
                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                    },
                },
                {
                    path: 'suggestions', children: [
                        {
                            path: '', component: ChannelListComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED],
                                queryParams: { 'connectionid': 1, 'connectionStatusTypeName': 'suggestion' }
                            }
                        },
                        {
                            path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                            },
                        }
                    ],
                },
                {
                    path: 'myprospects', children: [
                        {
                            path: '', component: ChannelListComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED],
                                queryParams: { 'connectionid': 2, 'connectionStatusTypeName': 'Prospects' }
                            }
                        },
                        {
                            path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                            }
                        },

                        {
                            path: 'approvals', children: [
                                {
                                    path: '', component: ChannelListComponent, canActivate: [AuthGuard],
                                    data: {
                                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED],
                                        queryParams: { 'connectionid': 3, 'connectionStatusTypeName': 'Approvals' }
                                    }
                                },
                                {
                                    path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                                    data: {
                                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                    }
                                },
                            ],
                        },
                    ],
                },
                {
                    path: 'mychannels', children: [
                        {
                            path: '', component: ChannelListComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED],
                                queryParams: { 'connectionid': 4, 'connectionStatusTypeName': 'Channel' }
                            }
                        },
                        {
                            path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                            }
                        },
                        {
                            path: 'approvals', children: [
                                {
                                    path: '', component: ChannelListComponent, canActivate: [AuthGuard],
                                    data: {
                                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED],
                                        queryParams: { 'connectionid': 3, 'connectionStatusTypeName': 'Approvals' }
                                    }
                                },
                                {
                                    path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                                    data: {
                                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                    }
                                },
                            ],
                        },
                        {
                            path: 'invitations', component: RecommendationListComponent, canActivate: [AuthGuard],
                            data: {
                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                            }
                        }
                    ],
                },
                // {
                //     path: 'contactlist', component: ContactListComponent, canActivate: [AuthGuard],
                //     data: {
                //         currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                //     }
                // },
                {
                    path: 'invitations', component: RecommendationListComponent, canActivate: [AuthGuard],
                    data: {
                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                    }
                },
                {
                    path: 'morelist', children:
                        [
                            {
                                path: '', component: MoreListComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                            {
                                path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                            {
                                path: 'channelview/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                        ]
                },

            ],
    },
    {
        path: 'product', children:
            [
                {
                    path: 'suggestions', children:
                        [
                            {
                                path: '', component: ProductListComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                            {
                                path: 'productview/:id', children:
                                    [
                                        {
                                            path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                        {
                                            path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                    ]
                            },
                            {
                                path: 'productView/:id', children:
                                    [
                                        {
                                            path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                        {
                                            path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                    ]
                            },
                        ]
                },
                {
                    path: 'morelist', children:
                        [
                            {
                                path: '', component: MoreListComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                            {
                                path: 'productview/:id', children:
                                    [
                                        {
                                            path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                        {
                                            path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                                            data: {
                                                currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                            }
                                        },
                                    ]
                            },
                        ]
                },
                {
                    path: 'productview/:id', children:
                        [
                            {
                                path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                            {
                                path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                                data: {
                                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                                }
                            },
                        ]
                }
            ],
    },
    {
        path: 'searchResult', children: [
            {
                path: '', component: SearchResultComponent, canActivate: [AuthGuard],
                data: {
                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                }
            },
            {
                path: 'channelView/:id', component: ChannelDetailViewComponent, canActivate: [AuthGuard],
                data: {
                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                }
            },
            {
                path: 'productview/:id', component: ViewProductComponent, canActivate: [AuthGuard],
                data: {
                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                }
            },
            {
                path: 'product', component: SearchResultComponent, canActivate: [AuthGuard],
                data: {
                    currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                }
            },
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ChannelRoutingModule { }
