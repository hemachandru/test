import { Injectable } from '@angular/core';

import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';

@Injectable()
export class ChannelService {

  constructor(private _httpReqService: HttpRequestService) { }

  getService(url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequest(url, returnFullResponse);
  }

  postService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.postHttpRequest(data, url, returnFullResponse);
  }

  getByIDService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequestWithData(data, url, returnFullResponse);
  }

  putService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.putHttpRequest(data, url, returnFullResponse);
  }

  updateService(data: any, url: string, returnFullResponse: boolean) {
    return this._httpReqService.patchHttpRequest(data, url, returnFullResponse);
  }


}
