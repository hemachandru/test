import { Injectable } from "@angular/core";
import { ChannelService } from "./channel-service";

@Injectable()
export class InvitationService extends ChannelService {
    
}