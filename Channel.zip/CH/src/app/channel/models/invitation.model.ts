import { Pagination } from "@app/shared/models/shared-model";
import { integer } from "aws-sdk/clients/cloudfront";

export interface InvitationModel {
    tag:                   string;
    channelrecommendid:    string;
    existchannelid:        string;
    oldchannelid:          null;
    companyname:           string;
    contactname:           string;
    countryid:             string;
    city:                  string;
    mail:                  string;
    mobileno:              null;
    addressid:             string;
    websiteurl:            string;
    updatedby:             string;
    createdat:             string;
    suggestedto:           string;
    suggestedto_type:      string;
    suggestedby:           string;
    suggestedby_channelid: string;
    suggestedby_type:      string;
    suggested_type:        string;
    active_id:             string;
    existchannel:          Existchannel;
    country:               Country;
    address:               Address;
    channelId:             integer;
    channelType:           any;
    websiteUrl:            string;
    contact:               any;
    channelDocumentUrl:    string;
    active_channel:        any;
    // getContact() {
    //     if()
    // }
}

export interface Address {
    addressId:  string;
    address:    string;
    city:       string;
    countryId:  string;
    postalCode: string;
    country:    Country;
}

export interface Country {
    country:   string;
    countryId: string;
}

export interface Existchannel {
    channelId:      string;
    companyName:    string;
    signUpStatusId: string;
    channelTypeId:  string;
    createdAt:      string;
    channelDetail:  ChannelDetail;
    regAddress:     Address;
    billAddress:    Address;
    contacts:       Contact[];
}

export interface ChannelDetail {
    channelId:     string;
    channelLogoId: string;
    channelLogo:   ChannelLogo;
}

export interface ChannelLogo {
    documentUrl:  string;
    documentPath: string;
    documentId:   string;
}

export interface Contact {
    contactId: string;
    firstName: string;
    lastName:  string;
    jobTitle:  string;
    document:  null;
    country:   Country;
}

export interface InvitationResponse {
    pagination:   Pagination;
    results:      InvitationModel[];
    aggregations: InvitationAggregations;
}

export interface InvitationAggregations {
    country: number[];
}