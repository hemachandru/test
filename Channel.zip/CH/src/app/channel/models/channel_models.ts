// tslint:disable-next-line:class-name
export class userFilter {
    roleId: number;
    isActive: string;
    countryId: number;
}

// tslint:disable-next-line:class-name
export class datatable {
    searchKey: string;
    pageNumber: number;
    limit: number;
    sort?: string;
}

export class ChannelStatusList {
    STATUS_ID: number;
    STATUS_TYPE: string;
}

export class DismissReasons {
    dismissreasonid: string;
    dismissreason: string;
    relationId?: number;
}

export class UpdateChannelData {
    connectionStatusTypeId?: number;
    channelJCTId?: number;
    dismissreasonid?: number;
    otherreasons?: string;
    leadManagementTag?: string;
    partnerLeadManagementTag?: string;
}


// export interface FilterResult {
//     connectionStatusTypeId: number;
//     channelTypeId?: number;
//     brand?: any[];
//     productGroup?: any[];
//     productCategory?: any[];
//     speciality?: any[];
//     locations?: any[];
//     entryType?: string;
// }

export interface FilterResult {
    relationId: number;
    request?: string;
    typeId?: number;
    locationId?: any[];
    countryId?: any[];
    productCategoryId?: any[];
    specialityId?: any[];
    brandId?: any[];
    tag?: any[];
    is_french_tech?: boolean;
}

export class SearchFilter {
    typeId?: number;
    locationId?: any[];
    countryId?: any[];
    productCategoryId?: any[];
    specialityId?: any[];
    brandId?: BrandId[];
    channelId?: any[];
    tag?: any[];
    is_french_tech?: boolean;
    relationId?: number;
}

export interface Upgrade {
    show?: boolean;
    count?: number;
    types?: any;
}

export class ChanneFilterItems {
    quality: any[];
    is_sample_free: boolean;
    retail_price_min: number;
    retail_price_max: number;
    retailer_commission_min: number;
    retailer_commission_max: number;
    distributor_commission_min: number;
    distributor_commission_max: number;
    brandIds: BrandId[];
    productFamilyIds: GroupId[];
    productCategoryIds: CatgoryId[];
    is_french_tech?: boolean;
}
export class BrandId {

}
export class GroupId {
}
export class CatgoryId {

}

export class Pagination {
    limit: number;
    page: number;
    total: number;
    offset: number;
}

export interface Code {
    code: string;
    id: number;
    type: string;
}

export interface Retailer {
    margin_price: number;
    margin_unit: string;
}

export interface Currency {
    code: string;
    id: string;
}

export interface Sample {
    unit: string;
    price: string;
}

export interface Distributor {
    margin_price: number;
    margin_unit: string;
}

export interface Retail {
    unit: string;
    price: string;
}

export interface Price {
    is_sample_free: boolean;
    is_unlimited_sample: boolean;
    retailer: Retailer;
    currency: Currency;
    sample_threshold: string;
    sample: Sample;
    distributor: Distributor;
    retail: Retail;
}

export interface Brand {
    name: string;
    id: number;
}

export interface ProductFamily {
    name: string;
    id: number;
}

export interface Preference {
    name: string;
    id: number;
}

export interface Location {
    name: string;
    id: number;
}

export interface Target {
    locations: Location[];
}

export interface Location2 {
    name: string;
    id: number;
}

export interface Selling {
    locations: Location2[];
}

export interface ProductCategory {
    name: string;
    id: number;
}

export interface RetailerMinMargin {
    value?: any;
}

export interface RetailMaxPrice {
    value?: any;
}

export interface Brands {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: any[];
}

export interface DistributerMinMargin {
    value?: any;
}

export interface RetailerMaxMargin {
    value?: any;
}

export interface RetailMinPrice {
    value?: any;
}

export interface FreeSample {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: any[];
}

export interface Family {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: any[];
}

export interface Category {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: any[];
}

export interface DistributerMaxMargin {
    value?: any;
}

export interface Quality {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: any[];
}

export class Rangefilter {
    brands: Brands;
    category: Category;
    distributer_max_margin: DistributerMaxMargin;
    distributer_min_margin: DistributerMinMargin;
    family: Family;
    free_sample: FreeSample;
    quality: Quality;
    retail_max_price: RetailMaxPrice;
    retail_min_price: RetailMinPrice;
    retailer_max_margin: RetailerMaxMargin;
    retailer_min_margin: RetailerMinMargin;
}

export interface Product {
    avaialble_from: Date;
    codes: Code[];
    has_variant: boolean;
    created_at: Date;
    usp: string;
    updated_at: Date;
    price: Price;
    id: number;
    is_avaialble_immediate: boolean;
    sku: string;
    brand: Brand;
    productdesc: string;
    product_family: ProductFamily[];
    images: ImagesList;
    is_active: boolean;
    company_id: number;
    preference: Preference[];
    avaialbility_comment: string;
    deleted_at?: any;
    quality: string;
    target: Target;
    urlkey: string;
    can_view_free_plan_members: boolean;
    name: string;
    selling: Selling;
    variantdetails: string;
    product_category: ProductCategory[];
    sellinglocation: string;
    tragetlocation: string;
    defaultimage: string;
    other_info: RatingDetails;
}

export class ImagesList {
    others: OtherList[];
    primary: PrimaryList[];
}

export class OtherList {
    documentUrl: string;
    documentId: number;
    documentPath: string;
}

export class PrimaryList {
    documentUrl: string;
    documentId: number;
    documentPath: string;
}
export class ChannelProductlist {
    pagination: Pagination;
    results: Product[];
    aggregations: Rangefilter;
    others: any;
}
export class RatingDetails {
    no_of_evaluations: number;
    rating: number;
    no_of_orders: number;
}

export class OfficialDocument {
    folderPath: string;
}

export class ChannelClaim {
    claim: boolean;
}

export class ChannelTitleInfo {
    channelName: string;
    channelType: string;
}

export class MoreListServiceData {
    channelType: string;
    channelName: string;
    viewType: number;
}

export interface MoreListFilter {
    typeId?: number;
    locationId?: number[];
    countryId?: number[];
    productCategoryId?: number[];
    specialityId?: number[];
    brandId?: number[];
    channelId?: number;
    is_french_tech?: boolean;
}

export class SampleOrderFilterResult {
    status?: any[];
    start?: string;
    end?: string;
}

export interface AccessPermissionCustom {
    AccessPermissionId: any;
    ChannelType: any;
}
