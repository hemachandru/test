import { ChannelKeyRetailerGet } from '@app/shared/models/shared-model';

export interface Subscription {
  subscriptionPlanId: string;
  isActive: string;
}
export interface TradeInformationIds {
  productGroup: string[];
  productCategory: string[];
  speciality: string[];
  service: any[];
  locations: string[];
}

export interface Coupon {
  couponDesc?: any;
  couponCode?: any;
  couponOfferValue?: any;
  discountUnit?: any;
}

export interface SubscriptionDetails {
  subscriptionId: string;
  actualAmount: string;
  finalAmount: string;
  paymentTransactionId: string;
  startedAt: Date;
  endAt: Date;
  isActive: string;
  subscription: Subscription;
  coupon: Coupon;
  paymentTransaction?: any;
}

export interface TradeInformation {
  existingCategories: string[];
  speciality: string[];
  interestedCategories: any[];
  customerProfile: string[];
  service: string[];
}

export interface Locations {
  SELLING: any[];
  TARGET: string[];
  RETAIL: any[];
}

export interface User {
  userId: string;
  contactId: string;
  channelId: string;
  email: string;
  isActive: string;
  role: string;
}

export interface ContactSocialLink {
  social: string;
  link: string;
}

export interface Contact {
  contactId: string;
  rptContactId?: any;
  channelId: string;
  firstName: string;
  lastName: string;
  phone1: string;
  phone2: string;
  mobileNo: string;
  email: string;
  responsibilityId?: any;
  workNatureId?: any;
  jobTitle: string;
  linkedIn: string;
  googleplus?: any;
  documentId: string;
  countryId: string;
  isDefaultContact: string;
  isShared: string;
  isActive: string;
  empId: string;
  user: User;
  contactSocialLink: ContactSocialLink[];
  IntProductCategory: any[];
  country: string;
  documentUrl: string;
}

export interface CertificateType {
  cerificateTypeId: string;
  cerificateType: string;
}

export interface Registration {
  cerificateName: string;
  cerificateNumber: string;
}

export interface Tax {
  cerificateName: string;
  cerificateNumber: string;
}

export interface Certificate {
  Registration: Registration[];
  Tax: Tax[];
}

export interface RootObjectChannelView {
  channelId: string;
  companyName: string;
  companyMail: string;
  profileType: string;
  isActive: string;
  signUpStatus: string;
  channelTypeId: string;
  channelType: string;
  country: string;
  oldChannelId?: any;
  channelLogo: string;
  channelIcon: string;
  webSiteUrl: string;
  productCount?: number;
  vendorCount?: number;
  estYear: string;
  regYear: string;
  aboutUs: string;
  empCntRange: string;
  empCnt: number;
  empCntDSale?: any;
  empCntISale?: any;
  empCntDMar?: any;
  empCntIMar?: any;
  revD?: any;
  revI?: any;
  turnoverRange: string;
  turnover?: any;
  retailerCount?: number;
  distributorCount?: number;
  rating: number;
  reviewCount: number;
  subscriptionPlan: string;
  tradeInformationIds: TradeInformationIds;
  subscriptionDetails: SubscriptionDetails;
  tradeInformation: TradeInformation;
  locations: Locations;
  contacts: Contact[];
  awards: any[];
  certificate: Certificate;
  userDefaultContact: string;
  channelJCT: string;
  connectionStatusTypeId: string;
  pendingApprovalInOutBound?: string;
  socialLinks: SocialLink;
  sampleOrderCount: number;
  sampleEvaluationCount: number;
  channelDocument: boolean;
  channelKeyRetailer: ChannelKeyRetailerGet[];
  channelKeyDistributor: ChannelKeyRetailerGet[];
  isFrenchTech: string;
  no_of_distributors: number;
  no_of_retailers: number;
  no_of_skus: number;
  no_of_vendors: number;
}


export interface MatchingProfile {
  channelTypeId: number;
  productGroup: string[];
  productCategory: string[];
  locations: string[];
}

export interface VendorProduct {
  isActive: boolean;
  position?: string;
  brand?: number[];
  productGroup?: number[];
  productCategory?: number[];
  excludedProductSku?: string[];
  channelId?: number;
}

export interface SocialLink {
  social: string;
  link: string;
}

export interface Pagination {
  limit: number;
  page: number;
  total: number;
}
