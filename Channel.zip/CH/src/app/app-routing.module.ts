import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorPageComponent } from '@app/core/components/errorpage/errorpage.component';
import { AnonymousGuard, RedirectGuard, AuthGuard } from '@app/shared/shared-service/auth-guard.service';
import { environment } from 'environments/environment';
import { HomeComponent } from './home/containers/home/home.component';
import { ChannelListComponent } from './channel/component/channel-list/channel-list.component';
import { UserAccountStatus } from './config/constant';

const homePage = {
  path: '',
  canActivate: [RedirectGuard],
  component: HomeComponent,
  data: {
    externalUrl: 'https://channelhub.net/'
  },
};

// const channelData = {
//   path: '', component: HomeComponent, canActivate: [AnonymousGuard],
// };

// const channelTemp = {
//   // path: '', component: HomeComponent, canActivate: [AnonymousGuard],
//   path: '',
//   component: RedirectGuard,
//   data: {
//     externalUrl: 'https://channelhub.net/'
//   },
//   canActivate: [RedirectGuard]
// };

const routes: Routes = [
  // environment.WP_Home_PAGE ? channelTemp : channelData,
  homePage,
  {
    path: 'auth',
    loadChildren: './auth/auth.module#RootAuthModule',
  },
  {
    path: 'profile',
    loadChildren: './profile/profile.module#ProfileModule',
  },
  {
    path: '**',
    component: ErrorPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
