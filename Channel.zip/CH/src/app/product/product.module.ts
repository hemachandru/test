import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImageZoomModule } from 'angular2-image-zoom';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { TabModule } from 'angular-tabs-component';
import { IonRangeSliderModule } from 'ng2-ion-range-slider';
import { MatDialogModule } from '@angular/material';
// import { AutocompleteModule } from 'ng2-input-autocomplete';

import { AddProductComponent } from './component/add-product/add-product.component';
import { ViewProductComponent } from './component/view-product/view-product.component';
import { ProductRoutingModule } from './product-routing-module';
import { GeneralComponent } from './component/general/general.component';
import { TradeDetailsComponent } from './component/trade-details/trade-details.component';
import { DistributionChannelsComponent } from './component/distribution-channels/distribution-channels.component';
import { SharedModule } from './../shared/shared.module';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductService } from '@app/product/service/product-service.service';
import { ProductBusiness } from '@app/product/business/product.business';
import { ProductDetailComponent } from './component/product-detail/product-detail.component';
import { ProductDetailTabComponent } from './component/product-detail-tab/product-detail-tab.component';
import { ProductInformationComponent } from './component/product-information/product-information.component';
import { BrochuresComponent } from './component/brochures/brochures.component';
import { ProductArticlesComponent } from './component/product-articles/product-articles.component';
import { RatingsReviewComponent } from './component/ratings-review/ratings-review.component';
import { KeyRetailersComponent } from './component/key-retailers/key-retailers.component';
import { DistributorsSalesComponent } from './component/distributors-sales/distributors-sales.component';
import { ProductImportComponent } from './component/product-import/product-import.component';
import { WatchVideoComponent } from './component/product-import/dialog-components/watch-video/watch-video.component';
import { ImportProductComponent } from './component/product-import/dialog-components/import-product/import-product.component';
import { ProductImageGalleryComponent } from './component/product-image-gallery/product-image-gallery.component';
import { SlimScrollModule } from 'ng2-slimscroll';
import { FormsModule } from '@angular/forms';
import { ProductVideoComponent } from './component/product-video/product-video.component';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { OrderSuccessMessageComponent } from './component/order-success-message/order-success-message.component';
import { WishListComponent } from './component/wish-list/wish-list.component';
import { CartListComponent } from './component/cart-list/cart-list.component';
import { UserAddressComponent } from './component/user-address/user-address.component';
import { NgxCarouselModule } from 'ngx-carousel';
import { CheckoutService } from './service/checkout.service';
import { CartService } from './service/cart-service';
import { QuillEditorModule } from 'ngx-quill-editor';
import { AwardDetailsComponent } from './component/award-details/award-details.component';
import { DialogRecomendationComponent } from './component/dialog-recomendation/dialog-recomendation.component';
import { ChannelBusiness } from '../channel/business/channel.business';
import { AddBrandComponent } from '@app/account/component/add-brand/add-brand.component';

@NgModule({
  imports: [
    CommonModule,
    ProductRoutingModule,
    TabModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    ImageZoomModule,
    SlimScrollModule,
    FormsModule,
    IonRangeSliderModule,
    NgxCarouselModule,
    QuillEditorModule,
    // AutocompleteModule.forRoot(),
    MatDialogModule
  ],
  declarations: [AddProductComponent, ViewProductComponent,
    GeneralComponent, TradeDetailsComponent, DistributionChannelsComponent,
    ProductListComponent, ProductDetailComponent, ProductDetailTabComponent, ProductInformationComponent, BrochuresComponent,
    ProductImportComponent, WatchVideoComponent, ImportProductComponent,
    ProductArticlesComponent, RatingsReviewComponent, KeyRetailersComponent,
    DistributorsSalesComponent, ProductImageGalleryComponent, ProductVideoComponent,
    CheckoutComponent, OrderSuccessMessageComponent, WishListComponent, CartListComponent,
    UserAddressComponent, AwardDetailsComponent, DialogRecomendationComponent],
  providers: [ProductBusiness, ProductService, CheckoutService, CartService, ChannelBusiness],
  exports: [
    UserAddressComponent,
    NgxCarouselModule
  ],
  entryComponents: [WatchVideoComponent, ImportProductComponent, ProductVideoComponent, DialogRecomendationComponent, AddBrandComponent]
})
export class ProductModule {

}
