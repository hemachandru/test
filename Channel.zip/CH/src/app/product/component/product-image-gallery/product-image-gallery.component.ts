import { Component, OnInit, Input } from '@angular/core';
import { NgxCarousel, NgxCarouselStore } from 'ngx-carousel';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { ProductRootObject } from '@app/product/models/product-view';
import { ProductVideoComponent } from '../product-video/product-video.component';

@Component({
  selector: 'app-product-image-gallery',
  templateUrl: './product-image-gallery.component.html',
  styleUrls: ['./product-image-gallery.component.scss']
})
export class ProductImageGalleryComponent implements OnInit {
  _ProductRootObject: ProductRootObject;
  public carouselTile: NgxCarousel;
  public defaultImage: string;
  public imagelist: any[];
  public imageid: string;
  public imagelistselected: string;
  public selectedblock: boolean;
  public embedLink: string;

  constructor(public dialog: MatDialog) {
    this._ProductRootObject = new ProductRootObject();
  }

  @Input() set objectProduct(value: ProductRootObject) {
    this._ProductRootObject = value;
    if (this._ProductRootObject.defaultImage) {
      this.defaultImage = this._ProductRootObject.defaultImage.image.documentUrl;
      this.imageid = this._ProductRootObject.defaultImage.productimageid;
      this.imagelist = this._ProductRootObject.images.PRODUCT;
      this.imagelistselected = 'product';
      this.selectedblock = true;
    }

  }

  ngOnInit() {

    this.carouselTile = {
      grid: { xs: 4, sm: 4, md: 4, lg: 5, all: 0 },
      slide: 4,
      speed: 400,
      animation: 'lazy',
      point: {
        visible: false,
        hideOnSingleSlide: false
      },
      load: 4,
      touch: true,
      easing: 'ease'
    };
  }

  imageSwape(values) {
    this.defaultImage = values.image.documentUrl;
    this.imageid = values.productimageid;
  }

  ImageChange(values, selectblock, data) {
    this.imagelistselected = selectblock;
    this.imagelist = values;
    this.selectedblock = data;
  }

  videoSwape(values) {
    this.OpenProductVideoDialog('video', 'link', values);
  }

  private OpenProductVideoDialog(title: string, message: string, urllink: any) {
    const samp = urllink.match(/^https?:\/\/([\w-]+\.\w{2})\/([\w-]{11})?/);
    if (samp) {
      if (samp[1] === 'youtu.be') {
        this.embedLink = 'https://www.youtube.com/embed/';
        urllink = this.embedLink + samp[2];
      }
      console.log(samp);
    } else {
      urllink = urllink;
    }
    this.dialog.open(ProductVideoComponent, {
      data: {
        title: message,
        type: 2,
        message: message,
        url: urllink
      },
    });
  }

}
