import { Component, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PlatformLocation } from '@angular/common';

import { CheckoutService } from '../../service/checkout.service';
import { ProductService } from '@app/product/service/product-service.service';
import { Config, CartMessage, UserAccountStatus, AccessPermissionEnum } from '@app/config/constant';
import { CartService } from '../../service/cart-service';
import { ScrollToService } from 'ng2-scroll-to-el';
import { CartModel } from '../../models/cart-model';
import { MatDialogRef, MatDialog } from '@angular/material';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { ButtonTypes, CurrencyType } from '@app/config/constant';
import { CartCountService } from '@app/shared/shared-service/cart-count';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.scss']
})
export class CartListComponent implements OnInit {
  public webUrl = WebUrl;
  public title: string;
  public preloader: boolean;
  public cartList: any;
  public rating: number;
  public emptyResult: number;
  dialogRef: MatDialogRef<MessageDialogComponent>;
  public cartCount;
  public _CurrencyType = CurrencyType;
  public checkoutLmtAmt: number;
  public InActiveProduct;

  constructor(private productService: ProductService, private Const: Config, private platformLocation: PlatformLocation,
    private router: Router, private _checkoutservice: CheckoutService,
    private toastr: ToastrService, private cartService: CartService, private scrollToService: ScrollToService,
    private dialog: MatDialog, private cartCountService: CartCountService,
    private authorizeService: AuthorizeService, private translate: TranslateService) { }

  ngOnInit() {
    this.title = 'cart.title';
    if (!this.authorizeBeforeLoad()) {
      this.router.navigate(['/dashboard']);
    }
    this.rating = 3.356;
    this.checkoutLmtAmt = 900000;
    this.InActiveProduct = [{ product: 'Product Name' }, { product: 'Product Name2' }, { product: 'Product Name3' }];
    this.getCartCount();
    this.cartListService();
    this.bindCartService();
    this.getCheckoutAmountLimit();
    // this.cartModification();
  }

  // POPUP FOR CART INACTIVE PRODUCT DESIGN
  cartModification(inactiveProduct) {
    this.InActiveProduct = inactiveProduct;
    const title = 'cart.cartUpdation';
    const message = 'cart.cartModified';
    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.Continue,
        message: message,
        list: this.InActiveProduct
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        // this.preloader = true;
      }
      this.getCartCount();
    });
  }

  cartListService() {
    this.preloader = true;
    this.productService.cartList().subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        this.cartList = (<any>response)._body;
        const cartListObj = JSON.parse(this.cartList);
        this.cartList = cartListObj.cart;
        this.emptyResult = this.cartList.length;

        for (let i = 0; i < this.cartList.length; i++) {
          this.cartList[i].policy = false;
          this.cartList[i].accept = false;
          this.cartList[i].cartError = false;
          const subtotalValid = parseFloat(this.cartList[i].subtotal);
          this.cartList[i].subtotal = subtotalValid.toFixed(2);
          for (let j = 0; j < this.cartList[i].items.length; j++) {
            this.cartList[i].items[j].countError = '';
            this.cartList[i].items[j].count = this.cartList[i].items[j].quantity;
          }
        }

        if (cartListObj.inactiveProduct.length) {
          this.cartModification(cartListObj.inactiveProduct);
        }
      } else {
        console.error('Error :', res);
      }
      this.preloader = false;
    });
  }

  cartQuantityUpdate(cart, cartlist, data) {
    if (data.target.value !== '') {
      this.preloader = true;
      const params = {
        'id': parseInt(cartlist.productid, 10),
        'quantity': parseInt(data.target.value, 10),
        'action': 'replace'
      };
      if (!params.quantity) {
        cartlist.countError = CartMessage.validNumber;
        cart.cartError = true;
        this.preloader = false;
      } else {
        this.productService.cartUpdate(params).subscribe(res => {
          const response = res as Response;
          if (response.ok) {
            cartlist.count = data.target.value;
            cartlist.countError = '';
            cart.cartError = false;

            for (let i = 0; i < cart.items.length; i++) {
              if (cart.items[i].countError) {
                cart.cartError = true;
              }
            }

            cartlist.quantity = cartlist.count;
            // cartlist.unitprice = cartlist.unitprice * parseInt(data.target.value, 10);
            const subtotal = cart.items.reduce((acc, val) => {
              const cartamount = parseFloat(val.unitprice) * parseInt(val.count, 10);
              return acc + cartamount;
            }, 0);

            cart.subtotal = (subtotal).toFixed(2);
            const grandtotal = parseFloat(cart.subtotal) + parseInt(cart.taxcost, 10);
            cart.grandtotal = (grandtotal).toFixed(2);

            this.toastr.success(this.translate.instant(CartMessage.succesMessage));
            // this.cartListService();
          } else if (response.json()[0]['errors'][0]['code'] === 0) {
            cartlist.countError = CartMessage.limitedMessage;
            cart.cartError = true;
          }
          this.preloader = false;
        });
      }
    } else {
      cartlist.countError = CartMessage.validNumber;
      cart.cartError = true;
    }
  }

  cartItemDelete(id) {
    this.preloader = true;
    this.productService.cartItemdelete(id).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        this.getCartCount();
        this.toastr.info(this.translate.instant(CartMessage.itemdeleted));
        this.cartListService();
      } else {
        console.error('Error :', (<any>response)._body);
      }
      this.preloader = false;
    });
  }

  cartListDelete(id) {
    this.preloader = true;
    this.productService.cartListdelete(id).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        this.getCartCount();
        this.toastr.info(this.translate.instant(CartMessage.listdeleted));
        this.cartListService();
      } else {
        console.error('Error :', (<any>response)._body);
      }
      this.preloader = false;
    });
  }

  cartClear() {
    const title = this.translate.instant('cart.cart');
    const message = this.translate.instant(CartMessage.confirmMessage);
    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.ConfirmCancel,
        message: message
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.preloader = true;
        this.productService.cartClear().subscribe(res => {
          const response = res as Response;
          if (response.ok) {
            this.getCartCount();
            this.toastr.info(this.translate.instant(CartMessage.cartdeleted));
            this.cartListService();
          } else {
            console.error('Error :', (<any>response)._body);
          }
          this.preloader = false;
        });
      }
    });
  }

  herebyAccept(cart) {
    cart.accept = !cart.accept;
  }

  herebyPolicy(cart) {
    cart.policy = !cart.policy;
  }

  patternValidate(event) {
    if (event.target.value.match('^[1-9][0-9]*$') === null) {
      event.target.value = '';
      return false;
    }
  }

  checkout(cart: CartModel) {
    if (parseInt(cart.grandtotal, 10) <= this.checkoutLmtAmt) {
      if (!cart.accept) {
        this._checkoutservice.updateData(false);
        this._checkoutservice.sendData(cart);
        this.router.navigate([this.webUrl.CHECKOUT]);
      }
    } else {
      this.toastr.error(this.translate.instant('cart.tostMsg') + this.checkoutLmtAmt);
    }
  }

  bindCartService() {
    // this.scrollToService.scrollTo(document.getElementById('cart_14'), 1000, -100);
    this.cartService.currentCartDetail.subscribe(item => {
      if (item) {
        this.scrollToService.scrollTo(document.getElementById('cart_' + item), 1000, -100);
      }
    });
  }

  getCartCount() {
    this.productService.getCartCount().subscribe(res => {
      if (res.status) {
        const result = res.data;
        this.cartCount = result.reduce((acc, val) => {
          const productCount = parseInt(val.product_count, 10);
          return acc + productCount;
        }, 0);
        this.cartCountService.cartCountDetailChange(this.cartCount);
      } else {
        console.log('add to cart ' + res);
      }
    });
  }

  getCheckoutAmountLimit() {
    this.productService.getCheckoutAmountLimit().subscribe(res => {
      if (res.value) {
        this.checkoutLmtAmt = parseInt(res.value, 10);
      }
    });
  }

  authorizeBeforeLoad() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.PRODUCTS_ADD_TO_CART);
      if (!hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  termsConditionnewPage() {
    const pageURL = (this.platformLocation as any).location.origin;
    window.open(pageURL + '/' + 'termsconditions');
    // win.focus();
  }
}
