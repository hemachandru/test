import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ProductRootObject, ProductInfoRootObject } from '@app/product/models/product-view';
import { TabComponent, TabsContainer } from 'angular-tabs-component';


@Component({
  selector: 'app-product-detail-tab',
  templateUrl: './product-detail-tab.component.html',
  styleUrls: ['./product-detail-tab.component.scss']
})
export class ProductDetailTabComponent implements OnInit {
  public title;
  _ProductRootObject: ProductRootObject;
  _ProductInfoRootObject: ProductInfoRootObject;

  constructor() {
    this._ProductRootObject = new ProductRootObject();
    // this._ProductInfoRootObject = new ProductInfoRootObject();
  }


  @Input() set objectProduct(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  @Input() set ObjProductInfo(value: ProductInfoRootObject) {
    this._ProductInfoRootObject = value;
  }

  @Input() set showCurrentTab(value: boolean) {
    // if (this.showCurrentTab === true) {
    //   this.onTabChange(3);
    // } else {
    //   this.onTabChange(1);
    // }
  }

  @ViewChild(TabsContainer) tabsContainer: TabsContainer;

  ngOnInit() {

  }

  onTabChange(value: number) {
   this.tabsContainer.selectTab(this.tabsContainer.tabs[value]);
  }

}


