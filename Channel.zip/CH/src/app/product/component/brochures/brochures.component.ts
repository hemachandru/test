import { Component, OnInit, Input } from '@angular/core';
import { ProductRootObject } from '@app/product/models/product-view';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-brochures',
  templateUrl: './brochures.component.html',
  styleUrls: ['./brochures.component.scss']
})
export class BrochuresComponent implements OnInit {
  _ProductRootObject: ProductRootObject;
  public scrollbarOptionsCnl = { axis: 'y', theme: 'dark' };
  public _NoDataFound: NoDataFound;
  constructor(private translate: TranslateService) {
    this._ProductRootObject = new ProductRootObject();
    this._NoDataFound = new NoDataFound();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  ngOnInit() {
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('commonError.noData');
  }
}

