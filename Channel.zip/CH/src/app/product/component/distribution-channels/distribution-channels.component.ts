import { Component, OnInit, QueryList, ViewChildren, Input, Output, EventEmitter } from '@angular/core';
import {
  ChannelType, S3Buckets, LocationType, ActionType, ChannelLocationUniqueKeys,
  AddProductSectionMaxLimit
} from '@app/config/constant';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import {
  ProductKeyRetailerListAdd, Productkeyretailer, Targetlocation, NewKeyRetailer
} from '../../models/add-product';
import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { ProductAvailability, Distributionchannel, Retailchannel, ProductRelevantChannel } from '../../models/add-product';
import * as moment from 'moment';
import { parseDate } from 'ngx-bootstrap/chronos';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ChannelInfos, RelevantChannel, LocationData, CountryMaster, ErrorCustomModel } from '@app/shared/models/shared-model';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
// tslint:disable-next-line:max-line-length
import { MultipleSelectWithFilterComponent } from '@app/shared/shared-component/multiple-select-with-filter/multiple-select-with-filter.component';
import {
  ChannelLocation, Zone, Region, Country, ChannelLocationSearchItem, RegionCountryJCT1,
  ChannelLocationDetail
} from '../../models/channel-location';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { Response } from '@angular/http';
// tslint:disable-next-line:max-line-length
import { CheckBoxListComponent } from '../../../shared/shared-component/check-box-list/check-box-list.component';
import { ProductKeyRetailerGet, ProductLocationGet } from '../../models/get-product';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ScrollToService } from 'ng2-scroll-to-el';
import { CommonHelper } from '@app/shared/common-helper';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import {
  Channel, KeyRetailerFilterList, KeyRetailerListPost, KeyRetailerRootObject,
  KeyRetailerSelectedList, ChannelKeyRetailerObject, ChannelKeyretailersDescription
} from '@app/account/models/trade-information';
import { AddBrandComponent } from '@app/account/component/add-brand/add-brand.component';
import { ProductBusiness } from '@app/product/business/product.business';
import { SharedService } from '../../../shared/shared-service/shared-service';

@Component({
  selector: 'app-distribution-channels',
  templateUrl: './distribution-channels.component.html',
  styleUrls: ['./distribution-channels.component.scss']
})
export class DistributionChannelsComponent implements OnInit {
  public distributionChannelSelectedList: Array<RelevantChannel>;
  public distributionChannelSearchList: Array<RelevantChannel>;

  public retailChannelSelectedList: Array<RelevantChannel>;
  public retailChannelSearchList: Array<RelevantChannel>;

  public productGroups: Array<any> = new Array<any>();
  public productCategories: Array<any> = new Array<any>();
  public brands: Array<any> = new Array<any>();
  public urlRetailImg: Array<any>;
  public channelType = ChannelType;

  // Form controls;
  public isavaialbleimmediateCtrl: FormControl;
  public avaialblefromCtrl: FormControl;
  public avaialbilitycommentCtrl: FormControl;

  public retailerItemsArray: FormArray;

  // Form Groups
  public availablityFormGroup: FormGroup;
  public retailerGroup: FormGroup;
  public errLocation: string;
  public msg_code_sellingzones: string;
  public msg_code_sellingregions: string;
  public msg_code_sellingcountries: string;
  public msg_code_targetzones: string;
  public msg_code_targetregions: string;
  public msg_code_targetcountries: string;
  public scrollbarOptionsBrand = { axis: 'y', theme: 'dark' };
  public keyRetailerSelectedData: Array<KeyRetailerSelectedList> = [];
  public keyRetailerUpdatedData: Array<KeyRetailerSelectedList> = [];
  public keyRetailerFilterData: Array<KeyRetailerFilterList> = [];
  public keyRetailerFilterDataChannel: Array<KeyRetailerFilterList> = [];
  public keyRetailerPostData: Array<KeyRetailerListPost> = [];

  // public keyRetailerPostData: Array<number>;
  public searchKeyretailer: string;
  public keyRetailersDescription: FormControl;
  public keyDistributorsDescription: FormControl;
  public keyretailerDisable: boolean;


  dropBox: boolean;
  imageArraytemp = [];
  document: Document;
  claimDocError;
  msg_code;
  errDistributor;
  errRetailer;
  msg_code_distributor;
  msg_code_retailer;

  targetZones: Array<ChannelLocationSearchItem>;
  targetRegions: Array<ChannelLocationSearchItem>;
  targetCountries: Array<ChannelLocationSearchItem>;

  sellingZones: Array<ChannelLocationSearchItem>;
  sellingRegions: Array<ChannelLocationSearchItem>;
  sellingCountries: Array<ChannelLocationSearchItem>;

  public locationUniqueKeys = ChannelLocationUniqueKeys;
  public scrollToElementId: string;
  countryMasterList: Array<CountryMaster>;
  @Output()
  public loaderNotify: EventEmitter<boolean> = new EventEmitter<boolean>();
  public selectedSellingZones: Array<string>;
  public selectedSellingRegions: Array<string>;
  public selectedSellingCountries: Array<string>;

  public selectedTargetZones: Array<string>;
  public selectedTargetRegions: Array<string>;
  public selectedTargetCountries: Array<string>;
  deletedkeyretailer: Array<number>;
  @Input()
  public actionType: number;
  @Input() loaderStart;
  @ViewChildren(MultipleSelectWithFilterComponent) relevantChannels: QueryList<MultipleSelectWithFilterComponent>;
  @ViewChildren(CheckBoxListComponent) checkBoxListComponents: QueryList<CheckBoxListComponent>;
  timerId: any;
  public isActivatedFirstTime: boolean;
  public partnerObjects: object;
  public collapseProductsDetail: Array<boolean>;
  @Input() set isActive(value: boolean) {
    if (value) {
      if (!this.isActivatedFirstTime) {
        this.isActivatedFirstTime = value;
        if (this.actionType === ActionType.UPDATE || this.actionType === ActionType.COPYORDUPLICATE) {
          //
          if (this.loaderStart) {
            this.loaderNotify.emit(true);
          }
          this.timerId = setTimeout(this.prefillLocations, 2000, this);
        } else {
          this.timerId = setTimeout(this.setLocationsDisabledState, 2000, this);
        }
      }
      // this.prefillLocations();
    }
  }

  // Location disabled states
  isSellingRegionDisabled: boolean;
  isSellingCountryDisabled: boolean;

  isTargetRegionDisabled: boolean;
  isTargetCountryDisabled: boolean;

  constructor(private dialog: MatDialog, private s3UploadFileService: S3UploadFileService, private scrollService: ScrollToService,
    public _ProductBusiness: ProductBusiness, public sharedBusiness: SharedBusiness,
    private toastr: ToastrService, private translate: TranslateService, private _sharedService: SharedService
  ) {
    this.scrollToElementId = '';
  }

  ngOnInit() {
    this.partnerObjects = {
      '3': {
        'keyRetailerSelectedData': this.keyRetailerSelectedData,
        'keyRetailerFilterData': this.keyRetailerFilterData,
        'keyRetailerPostData': this.keyRetailerPostData,
        'keyRetailerFilterDataChannel': this.keyRetailerFilterDataChannel,
        'keyRetailerUpdatedData': this.keyRetailerUpdatedData,
        'deletedkeyretailer': this.deletedkeyretailer
      },
      '4': {
        'keyRetailerSelectedData': this.keyRetailerSelectedData,
        'keyRetailerFilterData': this.keyRetailerFilterData,
        'keyRetailerPostData': this.keyRetailerPostData,
        'keyRetailerFilterDataChannel': this.keyRetailerFilterDataChannel,
        'keyRetailerUpdatedData': this.keyRetailerUpdatedData,
        'deletedkeyretailer': this.deletedkeyretailer
      }
    };
    this.urlRetailImg = [];
    // this.keyRetailerSelectedData = [];
    // this.keyRetailerFilterDataChannel = [];
    this.errDistributor = 'channelDistributor';
    this.errRetailer = 'channelRetailer';
    this.errLocation = 'ChannelLocation';
    this.partnerObjects[3].keyRetailerSelectedData = [];
    this.partnerObjects[4].keyRetailerSelectedData = [];

    this.partnerObjects[3].keyRetailerPostData = [];
    this.partnerObjects[4].keyRetailerPostData = [];

    this.partnerObjects[3].deletedkeyretailer = new Array<number>();
    this.partnerObjects[4].deletedkeyretailer = new Array<number>();

    this.partnerObjects[3].keyRetailerFilterDataChannel = [];
    this.partnerObjects[4].keyRetailerFilterDataChannel = [];

    this.keyretailerDisable = false;
    this.searchKeyretailer = '';
    this.initializeDistributionGroup();
    // this.loadLocations();
    // this.getCountryList();
    this.getTradeKeyRetailer('3');
    // this.getKeyRetailerOldNew('3', false);
    this.getTradeKeyRetailer('4');
    // this.getKeyRetailerOldNew('4', false);
    this.collapseProductsDetail = this.actionType === ActionType.ADD ? [false, false, false, false, false] : [true, true, true, true, true];
    // this.collapseProductsDetail = true;
    // if (this.actionType === ActionType.ADD) {
    // this.getTradeKeyRetailer();
    // }

    // if (this.actionType === ActionType.UPDATE) {
    //   this.deletedkeyretailer = new Array<number>();
    // }

  }

  initializeDistributionGroup() {
    // this.isavaialbleimmediateCtrl = new FormControl(1, Validators.compose([Validators.required]));
    // this.avaialblefromCtrl = new FormControl('');
    // this.avaialbilitycommentCtrl = new FormControl('');

    // this.availablityFormGroup = new FormGroup({
    //   isavaialbleimmediate: this.isavaialbleimmediateCtrl,
    //   avaialblefrom: this.avaialblefromCtrl,
    //   avaialbilitycomment: this.avaialbilitycommentCtrl
    // });

    this.keyRetailersDescription = new FormControl('', Validators.compose([Validators.maxLength(2000)]));
    this.keyDistributorsDescription = new FormControl('', Validators.compose([Validators.maxLength(2000)]));

    this.retailerItemsArray = new FormArray([]);
    this.retailerGroup = new FormGroup({
      retailerItemsArray: this.retailerItemsArray,
      retailernameDescription: this.keyRetailersDescription,
      distributornameDescription: this.keyDistributorsDescription
    });
    this.addRetailerItem('', '', '');
  }

  addRetailerItem(name: string, countryId: string, image: string, retailerId: number = 0, imageId: number = 0) {
    this.retailerItemsArray = this.retailerGroup.get('retailerItemsArray') as FormArray;
    if (this.retailerItemsArray.length < AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit) {
      this.retailerItemsArray.push(this.buildItem(this.retailerItemsArray.length, name, countryId, image, imageId, retailerId));
      this.urlRetailImg.push('');
    } else {
      const error = new ErrorCustomModel();
      error.displayName = this.translate.instant('addProduct.distributionchannelTab.keyRetailer');
      error.requiredLength = AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit;
      this.toastr.warning(this.translate.instant('addProduct.validationMessage.multipleSectionMaxReached', error));
    }
  }

  buildItem(index, name: string, countryId: string, image: string, imageId: number, retailerId: number) {
    let controls = {};
    // controls = {
    //   retailername: new FormControl(name, Validators.compose([Validators.required, Validators.maxLength(255)])),
    //   countryid: new FormControl(countryId, Validators.compose([Validators.required])),
    // };

    controls = {
      retailername: new FormControl(name, Validators.compose([Validators.maxLength(255)])),
      countryid: new FormControl(countryId),
    };
    controls['image'] = new FormControl(image);
    // controls['image'] = new FormControl(image, Validators.compose([Validators.required]));
    controls['imageValue'] = new FormControl('');
    if (imageId !== 0) {
      controls['productkeyretailerid'] = new FormControl(retailerId);
      controls['documentid'] = new FormControl(imageId);
    }
    return new FormGroup(controls);
  }

  deleteItem(type, index, id) {
    this.retailerItemsArray.removeAt(index);
    this.urlRetailImg.splice(index, 1);
    if (id.toString().length > 0 && id !== 0 && this.actionType === ActionType.UPDATE) {
      this.deletedkeyretailer.push(id);
    }
  }

  userProfileRetailerUpload(e, Dimension, indexArr) {
    this.addOrRemoveKeyRetailerValidation(indexArr);
    const file = e.target.files.item(0);
    if (file) {
      let fileExtension = file.name.substr((file.name.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString();
      if (fileExtension === 'jpeg' || fileExtension === 'jpg' || fileExtension === 'png') {
        if (CommonHelper.checkValidImageSize(file.size)) {
          this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: true });
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            img.src = event.target.result;
            img.onload = async function () {
              // img.width === Dimension && img.height === Dimension
              if (img) {
                self.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: true });
                self.urlRetailImg[indexArr] = event.target.result;
                const folderName = S3Buckets.ACCOUNT_S3 + '/';
                self.loaderNotify.emit(true);
                const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
                self.loaderNotify.emit(false);
                let imageKey = '';
                if (resImagePath.key) {
                  imageKey = resImagePath.key;
                } else {
                  imageKey = resImagePath.Key;
                }
                self.retailerItemsArray.controls[indexArr].get('imageValue').setValue(imageKey);
                self.retailerItemsArray.controls[indexArr].get('image').setErrors(null);
                self.retailerItemsArray.controls[indexArr].get('image').markAsDirty();
                // return null;
              } else {
                self.urlRetailImg[indexArr] = '';
                self.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFailure: false });
              }
            };
          };
          reader.readAsDataURL(e.target.files[0]);
        } else {
          this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageSize: false });
        }
      } else {
        this.urlRetailImg[indexArr] = '';
        this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: false });
      }
    }
  }

  // Remove image
  onRemoved(event) {
    // console.log(event);
    this.imageArraytemp.forEach((item, index) => {
      const deleteItem = item.uploadImage === event.file.name;
      if (deleteItem) {
        this.imageArraytemp.splice(index, 1);
      }
    });
    // console.log('img' + this.imageArraytemp);
  }

  onUploadStateChanged(event) {
  }

  getProductRetailer(): ProductKeyRetailerListAdd {
    const productKeyRetailerAdd = new ProductKeyRetailerListAdd();
    productKeyRetailerAdd.productkeyretailer = new Array<Productkeyretailer>();
    // productRetailer = this.retailerItemsArray.value;
    for (let i = 0; i < this.retailerItemsArray.controls.length; i++) {
      const tempFormGroup = this.retailerItemsArray.controls[i] as FormGroup;
      const name = tempFormGroup.controls['retailername'].value;
      const countryID = tempFormGroup.controls['countryid'].value;
      const retailermage = tempFormGroup.controls['imageValue'].value;
      const retailer = new Productkeyretailer();
      if (this.actionType !== ActionType.ADD && tempFormGroup.controls['productkeyretailerid']
        && tempFormGroup.controls['productkeyretailerid'].value > 0) {
        if (tempFormGroup.dirty) {
          retailer.retailername = name;
          retailer.countryid = parseInt(countryID, 10);
          retailer.productkeyretailerid = tempFormGroup.controls['productkeyretailerid'].value;
          if (tempFormGroup.controls['image'].dirty) {
            if (tempFormGroup.controls['documentid'] && tempFormGroup.controls['documentid'].value) {
              retailer.imageid = parseInt(tempFormGroup.controls['documentid'].value, 10);
              retailer.image = retailermage;
            } else {
              if (retailermage) {
                retailer.image = retailermage;
              }
            }
          }

          productKeyRetailerAdd.productkeyretailer.push(retailer);
        }
      } else {
        if (name && countryID) {
          retailer.retailername = name;
          if (retailermage) {
            retailer.image = retailermage;
          }

          retailer.countryid = parseInt(countryID, 10);
          productKeyRetailerAdd.productkeyretailer.push(retailer);
        }
      }
    }

    return productKeyRetailerAdd;
  }

  loadDistributionSearchList(retailer: Array<RelevantChannel>, distributor: Array<RelevantChannel>): void {
    this.distributionChannelSearchList = distributor;
    this.retailChannelSearchList = retailer;
  }

  setloadLocations(response): void {
    // const channelId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID).toString(), 10);
    // this.sharedBusiness.getChannelLocation(channelId, true).subscribe(response => {
    //   const result = response as Response;
    //   if (result.ok) {
    const locationDetal = response.json() as ChannelLocationDetail;
    const locations = locationDetal.currentLocation;
    // const locations = result.json();
    // console.log('ChannelLocation', JSON.stringify(locations));

    this.targetZones = Array<ChannelLocationSearchItem>();
    this.targetRegions = Array<ChannelLocationSearchItem>();
    this.targetCountries = Array<ChannelLocationSearchItem>();

    this.sellingZones = Array<ChannelLocationSearchItem>();
    this.sellingRegions = Array<ChannelLocationSearchItem>();
    this.sellingCountries = Array<ChannelLocationSearchItem>();

    (locations.TARGET as Array<Zone>).forEach(zoneItem => {
      this.targetZones.push({
        'id': zoneItem.zoneId, 'name': zoneItem.zone,
        'isChecked': this.actionType === ActionType.ADD ? true : false
      });
      zoneItem.region.forEach(regionItem => {
        this.targetRegions.push({
          'parentId': zoneItem.zoneId, 'id': regionItem.regionId, 'name': regionItem.region,
          'isChecked': this.actionType === ActionType.ADD ? true : false
        });
        regionItem.country.forEach(countryItem => {
          this.targetCountries.push({
            'parentId': regionItem.regionId, 'id': countryItem.countryId,
            'name': countryItem.country, 'isChecked': this.actionType === ActionType.ADD ? true : false,
            'regioncountryjctid': countryItem.RegionCountryJCT.regionCountryJCTId
          });
        });
      });
    });

    (locations.SELLING as Array<Zone>).forEach(zoneItem => {
      this.sellingZones.push({
        'id': zoneItem.zoneId, 'name': zoneItem.zone,
        'isChecked': this.actionType === ActionType.ADD ? true : false
      });
      zoneItem.region.forEach(regionItem => {
        this.sellingRegions.push({
          'parentId': zoneItem.zoneId, 'id': regionItem.regionId, 'name': regionItem.region,
          'isChecked': this.actionType === ActionType.ADD ? true : false
        });
        regionItem.country.forEach(countryItem => {
          this.sellingCountries.push({
            'parentId': regionItem.regionId, 'id': countryItem.countryId,
            'name': countryItem.country, 'isChecked': this.actionType === ActionType.ADD ? true : false,
            'regioncountryjctid': countryItem.RegionCountryJCT.regionCountryJCTId
          });
        });
      });
    });
    //   }
    // });
  }

  // getAvailability(): ProductAvailability {
  //   const _productAvailability = new ProductAvailability();
  //   _productAvailability.isavaialbleimmediate = this.isavaialbleimmediateCtrl.value.toString();
  //   if (this.isavaialbleimmediateCtrl.value === 0) {
  //     // _productAvailability.avaialblefrom = moment(this.avaialblefromCtrl.value, 'YYYY/MM/DD').toDate();
  //     const availableDate = new Date(this.avaialblefromCtrl.value);
  //     // _productAvailability.avaialblefrom = availableDate.getDate() + '/'
  //  + availableDate.getMonth() + '/' + availableDate.getFullYear();
  //     _productAvailability.avaialblefrom = availableDate;
  //     _productAvailability.avaialbilitycomment = this.avaialbilitycommentCtrl.value;
  //   }

  //   return _productAvailability;
  // }

  getRelevantChannels(): ProductRelevantChannel {
    const productRelevantChannel = new ProductRelevantChannel();
    productRelevantChannel.distributionchannel = Array<Distributionchannel>();
    productRelevantChannel.retailchannel = Array<Retailchannel>();

    const _relevantChannelComps: Array<MultipleSelectWithFilterComponent> = this.relevantChannels.toArray();
    for (let i = 0; i < _relevantChannelComps.length; i++) {
      if (_relevantChannelComps[i].type === ChannelType.DISTRIBUTOR) {
        const distChannels = _relevantChannelComps[i].viewDataSource as Array<RelevantChannel>;
        if (distChannels) {
          for (let j = 0; j < distChannels.length; j++) {
            const distChannel = new Distributionchannel();
            distChannel.customerProfileId = parseInt(distChannels[j].Channel_Customer_Profile_ID, 10);
            productRelevantChannel.distributionchannel.push(distChannel);
          }
        }
      } else if (_relevantChannelComps[i].type === ChannelType.RETAILER) {
        if (_relevantChannelComps[i].viewDataSource) {
          const retailChannels = _relevantChannelComps[i].viewDataSource as Array<RelevantChannel>;
          if (retailChannels) {
            for (let k = 0; k < retailChannels.length; k++) {
              const retailChannel = new Retailchannel();
              retailChannel.customerProfileId = parseInt(retailChannels[k].Channel_Customer_Profile_ID, 10);
              productRelevantChannel.retailchannel.push(retailChannel);
            }
          }
        }
      }
    }
    return productRelevantChannel;
  }

  onLocationListItemChecked(locationData: LocationData) {
    this.validateLocationsOnChange(locationData.type);
    if (locationData.type === ChannelLocationUniqueKeys.SELLING_ZONES) {
      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];

      sellingRegionComponent.onAddingSelectedItemIds(locationData.data);
      const selectedRegions = sellingRegionComponent.getSelectedIds();

      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.refreshItemsByParent(selectedRegions);
    } else if (locationData.type === ChannelLocationUniqueKeys.SELLING_REGIONS) {
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.onAddingSelectedItemIds(locationData.data);
    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_ZONES) {
      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      targetRegionComponent.onAddingSelectedItemIds(locationData.data);

      const selectedRegions = targetRegionComponent.getSelectedIds();
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.refreshItemsByParent(selectedRegions);
    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_REGIONS) {
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.onAddingSelectedItemIds(locationData.data);
    }

    this.setLocationsDisabledState(this, locationData.type, true);
  }

  onLocationListItemUnchecked(locationData: LocationData) {
    this.validateLocationsOnChange(locationData.type);
    if (locationData.type === ChannelLocationUniqueKeys.SELLING_ZONES) {
      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];
      sellingRegionComponent.onAddingUnSelectedItemIds(locationData.data);
      const selectedRegions = sellingRegionComponent.getSelectedIds();

      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.refreshItemsByParent(selectedRegions);
    } else if (locationData.type === ChannelLocationUniqueKeys.SELLING_REGIONS) {
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.onAddingUnSelectedItemIds(locationData.data);
    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_ZONES) {
      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      targetRegionComponent.onAddingUnSelectedItemIds(locationData.data);

      const selectedRegions = targetRegionComponent.getSelectedIds();
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.refreshItemsByParent(selectedRegions);
    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_REGIONS) {
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.onAddingUnSelectedItemIds(locationData.data);
    }

    this.setLocationsDisabledState(this, locationData.type, false);
  }

  getTargetLocations(): Array<Targetlocation> {
    const targetLocations = new Array<Targetlocation>();
    const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
    if (targetCountryComponent) {
      const targetSelectedItems = targetCountryComponent.getSelectedData() as Array<ChannelLocationSearchItem>;
      if (targetSelectedItems && targetSelectedItems.length > 0) {
        targetSelectedItems.forEach(result => {
          const country = { 'regioncountryjctid': parseInt(result.regioncountryjctid, 10) };
          targetLocations.push(country);
        });
      }
    }

    return targetLocations;
  }

  getSellingLocations(): Array<Targetlocation> {
    const sellingLocations = new Array<Targetlocation>();
    const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
    if (sellingCountryComponent) {
      const sellingSelectedItems = sellingCountryComponent.getSelectedData() as Array<ChannelLocationSearchItem>;
      if (sellingSelectedItems && sellingSelectedItems.length > 0) {
        sellingSelectedItems.forEach(result => {
          const country = { 'regioncountryjctid': parseInt(result.regioncountryjctid, 10) };
          sellingLocations.push(country);
        });
      }
    }

    return sellingLocations;
  }

  async onUploadFinished(event) {
    this.dropBox = true;
    const file = event.file;
    const folderName = S3Buckets.ACCOUNT_S3 + '/';
    const resImagePath: any = await this.s3UploadFileService.uploadfile(file, folderName);
    if (resImagePath) {

      // this.imageArraytemp.push({
      //   's3UploadImage': resImagePath.key,
      //   'uploadImage': file.name
      // });
    } else {
      this.onRemoved(event);
      // console.log('s3 srror');
    }
    // if (this.imageArraytemp.length > 0) {
    //   this.claimDocError = '';
    //   this.msg_code = '';
    // }
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      const response = data as Response;
      if (response.ok) {
        this.countryMasterList = data;
      }
    });
  }

  preFillRelevantChannels(distributorChannels: RelevantChannel[], retailerChannels: RelevantChannel[]) {
    this.distributionChannelSelectedList = distributorChannels;
    this.retailChannelSelectedList = retailerChannels;
  }

  preFillKeyRetailers(keyRetailers: ProductKeyRetailerGet[]) {
    if (keyRetailers && keyRetailers.length > 0) {
      this.retailerItemsArray.removeAt(0);
      for (let i = 0; i < keyRetailers.length; i++) {
        this.addRetailerItem(keyRetailers[i].retailername, keyRetailers[i].countryid,
          this.actionType === ActionType.UPDATE &&
            keyRetailers[i].retailerImage &&
            keyRetailers[i].retailerImage.documentUrl ? keyRetailers[i].retailerImage.documentUrl : ''
          , this.actionType === ActionType.UPDATE ? parseInt(keyRetailers[i].productkeyretailerid, 10) : 0,
          this.actionType === ActionType.UPDATE ? parseInt(keyRetailers[i].documentid, 10) : 0);
        if (this.actionType === ActionType.UPDATE) {
          this.urlRetailImg[i] = keyRetailers[i].retailerImage && keyRetailers[i].retailerImage.documentUrl ?
            keyRetailers[i].retailerImage.documentUrl : '';
        }
      }

      this.setKeyRetailerValidation();
    }
  }

  // preFillAvailability(isavaialbleimmediate: string, avaialblefrom: string, avaialbilitycomment: string) {
  //   if (isavaialbleimmediate) {
  //     const availableImmediate = parseInt(isavaialbleimmediate, 10);
  //     this.isAvailableCheck(availableImmediate);
  //     if (availableImmediate === 0) {
  //       this.isavaialbleimmediateCtrl.setValue(availableImmediate);
  //       // this.avaialblefromCtrl.setValue(avaialblefrom ? moment(avaialblefrom).format('DD/MMYYYY') : null);
  //       this.avaialblefromCtrl.setValue(avaialblefrom ? new Date(avaialblefrom) : null);
  //       this.avaialbilitycommentCtrl.setValue(avaialbilitycomment ? avaialbilitycomment : '');
  //     } else {
  //       this.isavaialbleimmediateCtrl.setValue(1);
  //     }
  //   }
  // }

  // isAvailableCheck(value: number) {
  //   if (value === 0) {
  //     this.availablityFormGroup.controls['avaialblefrom'].setValidators([Validators.required]);
  //     this.availablityFormGroup.controls['avaialbilitycomment'].setValidators([Validators.required, Validators.minLength(10),
  //     Validators.maxLength(8000)]);
  //     const availableFrom = this.avaialblefromCtrl.value;
  //     const availableComment = this.avaialbilitycommentCtrl.value;
  //     this.availablityFormGroup.controls['avaialblefrom'].setValue(availableFrom ? availableFrom : '');
  //     this.availablityFormGroup.controls['avaialbilitycomment'].setValue(availableComment ? availableComment : '');
  //     this.availablityFormGroup.controls['avaialblefrom'].markAsTouched();
  //     this.availablityFormGroup.controls['avaialbilitycomment'].markAsTouched();
  //     this.availablityFormGroup.controls['avaialblefrom'].markAsDirty();
  //     this.availablityFormGroup.controls['avaialbilitycomment'].markAsDirty();
  //   } else {
  //     this.availablityFormGroup.controls['avaialblefrom'].setValue('');
  //     this.availablityFormGroup.controls['avaialbilitycomment'].setValue('');
  //     this.availablityFormGroup.controls['avaialblefrom'].clearValidators();
  //     this.availablityFormGroup.controls['avaialblefrom'].setErrors(null);
  //     this.availablityFormGroup.controls['avaialbilitycomment'].clearValidators();
  //     this.availablityFormGroup.controls['avaialbilitycomment'].setErrors(null);
  //   }
  // }

  // markFormGroupTouched(formGroup: FormGroup) {
  //   // (<any>Object).values(formGroup.controls).forEach(control => {
  //   for (const field in formGroup.controls) {
  //     const control = formGroup.get(field);
  //     /*if (control) { // control is a FormGroup
  //       this.markFormGroupTouched(control);
  //     } else { // control is a FormControl*/
  //     //this.markFormGroupTouched(formGroup);
  //     control.markAsTouched();
  //     // }
  //   };
  // }

  onViewDataAddRemove(event) {
    // this.revalantChannelCheck();
  }

  revalantChannelCheck() {
    if (this.relevantChannels) {
      let checkCountDistributor: Array<MultipleSelectWithFilterComponent>; // = this.relevantChannels.toArray();
      checkCountDistributor = this.relevantChannels.toArray().filter((book) => book['type'].toString().toUpperCase()
        .includes(ChannelType.DISTRIBUTOR));
      if (checkCountDistributor.length > 0) {
        if (checkCountDistributor[0].viewDataSource && checkCountDistributor[0].viewDataSource.length) {
          this.msg_code_distributor = '';
        } else {
          this.msg_code_distributor = '0001';
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = 'relevantdistributor';
          }
        }
      } else {
        this.msg_code_distributor = '';
      }

      let checkCountRetailer: Array<MultipleSelectWithFilterComponent>; // = this.relevantChannels.toArray();
      checkCountRetailer = this.relevantChannels.toArray().filter((book) => book['type'].toString().toUpperCase()
        .includes(ChannelType.RETAILER));
      if (checkCountRetailer.length > 0) {
        if (checkCountRetailer[0].viewDataSource && checkCountRetailer[0].viewDataSource.length) {
          this.msg_code_retailer = '';
        } else {
          this.msg_code_retailer = '0001';
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = 'relevantdistributor';
          }
        }
      } else {
        this.msg_code_retailer = '';
      }

    }
  }

  preFillLocations(productLocations: ProductLocationGet[]) {
    if (productLocations && productLocations.length > 0) {
      this.selectedSellingZones = new Array<string>();
      this.selectedSellingRegions = new Array<string>();
      this.selectedSellingCountries = new Array<string>();

      this.selectedTargetZones = new Array<string>();
      this.selectedTargetRegions = new Array<string>();
      this.selectedTargetCountries = new Array<string>();

      const sellingLocations = productLocations.filter(item => item.locationtype.toUpperCase() === LocationType.SELLING.toUpperCase());

      if (sellingLocations && sellingLocations.length > 0) {
        sellingLocations.forEach(productLocation => {
          if (productLocation.regionCountryJCT) {
            if (this.sellingRegions && this.sellingRegions.length > 0) {
              const _sellingRegions = this.sellingRegions.filter(item => item.id === productLocation.regionCountryJCT.regionId);
              if (_sellingRegions && _sellingRegions.length > 0) {
                this.selectedSellingZones.push(_sellingRegions[0].parentId);
              }

              this.selectedSellingRegions.push(productLocation.regionCountryJCT.regionId);
              this.selectedSellingCountries.push(productLocation.regionCountryJCT.countryId);
            }
          }
        });
      }

      const targetLocations = productLocations.filter(item => item.locationtype.toUpperCase() === LocationType.TARGET.toUpperCase());
      if (targetLocations && targetLocations.length > 0) {
        targetLocations.forEach(productLocation => {
          if (productLocation.regionCountryJCT) {
            if (this.targetRegions && this.targetRegions.length > 0) {
              const _targetRegions = this.targetRegions.filter(item => item.id === productLocation.regionCountryJCT.regionId);
              if (_targetRegions && _targetRegions.length > 0) {
                this.selectedTargetZones.push(_targetRegions[0].parentId);
              }

              this.selectedTargetRegions.push(productLocation.regionCountryJCT.regionId);
              this.selectedTargetCountries.push(productLocation.regionCountryJCT.countryId);
            }
          }
        });
      }
    }
  }

  validateLocationsOnChange(locationType) {
    const locationComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === locationType)[0];
    if (locationComponent.getSelectedData().length === 0) {
      if (locationType === ChannelLocationUniqueKeys.SELLING_ZONES) {
        this.msg_code_sellingzones = '0001';
      } else if (locationType === ChannelLocationUniqueKeys.SELLING_REGIONS) {
        this.msg_code_sellingregions = '0002';
      } else if (locationType === ChannelLocationUniqueKeys.SELLING_COUNTRIES) {
        this.msg_code_sellingcountries = '0003';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_ZONES) {
        this.msg_code_targetzones = '0004';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_REGIONS) {
        this.msg_code_targetregions = '0005';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_COUNTRIES) {
        this.msg_code_targetcountries = '0006';
      }
    } else {
      if (locationType === ChannelLocationUniqueKeys.SELLING_ZONES) {
        this.msg_code_sellingzones = '';
      } else if (locationType === ChannelLocationUniqueKeys.SELLING_REGIONS) {
        this.msg_code_sellingregions = '';
      } else if (locationType === ChannelLocationUniqueKeys.SELLING_COUNTRIES) {
        this.msg_code_sellingcountries = '';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_ZONES) {
        this.msg_code_targetzones = '';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_REGIONS) {
        this.msg_code_targetregions = '';
      } else if (locationType === ChannelLocationUniqueKeys.TARGET_COUNTRIES) {
        this.msg_code_targetcountries = '';
      }
    }
  }

  validateLocationsOnSave() {
    let returnVal = true;
    if (this.checkBoxListComponents) {
      const sellingZones = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const sellingZones = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.SELLING_ZONES)[0];
      // console.log('sellingZones', sellingZones);
      if (sellingZones && (!sellingZones.getSelectedData() || sellingZones.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_sellingzones = '0001';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'sellingLocationId';
        }
      } else {
        this.msg_code_sellingzones = '';
      }
      const sellingRegions = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const sellingRegions = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.SELLING_REGIONS)[0];
      if (sellingRegions && (!sellingRegions.getSelectedData() || sellingRegions.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_sellingregions = '0002';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'sellingLocationId';
        }
      } else {
        this.msg_code_sellingregions = '';
      }
      const sellingCountries = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const sellingCountries = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.SELLING_COUNTRIES)[0];
      if (sellingCountries && (!sellingCountries.getSelectedData() || sellingCountries.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_sellingcountries = '0003';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'sellingLocationId';
        }
      } else {
        this.msg_code_sellingcountries = '';
      }
      const targetZones = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const targetZones = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.TARGET_ZONES)[0];
      if (targetZones && (!targetZones.getSelectedData() || targetZones.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_targetzones = '0004';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'targetLocationId';
        }
      } else {
        this.msg_code_targetzones = '';
      }
      const targetRegions = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const targetRegions = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.TARGET_REGIONS)[0];
      if (targetRegions && (!targetRegions.getSelectedData() || targetRegions.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_targetregions = '0005';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'targetLocationId';
        }
      } else {
        this.msg_code_targetregions = '';
      }
      const targetCountries = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId ===
        // const targetCountries = this.checkBoxListComponents.filter(comp => comp.uniqueId ===
        ChannelLocationUniqueKeys.TARGET_COUNTRIES)[0];
      if (targetCountries && (!targetCountries.getSelectedData() || targetCountries.getSelectedData().length === 0)) {
        returnVal = false;
        this.msg_code_targetcountries = '0006';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'targetLocationId';
        }
      } else {
        this.msg_code_targetcountries = '';
      }
    }
    return returnVal;
  }

  checkValidate() {
    this.scrollToElementId = '';
    let checkFlag = true;
    // this.revalantChannelCheck();
    this.markFormArrayTouched(this.retailerItemsArray);
    if (this.retailerGroup.invalid) {
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        this.scrollToElementId = 'retailerId';
      }
    }
    if (!this.validateLocationsOnSave()) {
      checkFlag = false;
    }

    // this.markFormGroupTouched(this.availablityFormGroup);
    // if (this.availablityFormGroup.invalid) {
    //   if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
    //     this.scrollToElementId = 'availableId';
    //   }
    // }

    if (this.retailerGroup.valid && checkFlag === true) {
      checkFlag = true;
    } else {
      checkFlag = false;
    }

    //   if (this.retailerGroup.valid && this.availablityFormGroup.valid && this.msg_code_distributor === ''
    //   && this.msg_code_retailer === '' && checkFlag === true) {
    //   checkFlag = true;
    // } else {
    //   checkFlag = false;
    // }

    // if (this.isavaialbleimmediateCtrl.value === 0) {
    //   // this.isAvailableCheck(0);
    //   if (this.avaialblefromCtrl.invalid || this.avaialbilitycommentCtrl.invalid) {
    //     checkFlag = false;
    //     if (!this.scrollToElementId) {
    //       this.scrollToElementId = 'availableId';
    //     }
    //   }
    // }
    this.scrollToElement();
    return checkFlag;
  }

  scrollToElement() {
    this.scrollService.scrollTo(document.getElementById(this.scrollToElementId), 1000, -100);
    // this.scrollToElementId = '';
  }

  prefillLocations(self) {
    if (self.isActivatedFirstTime) {
      const sellingCountryComponent = self.checkBoxListComponents.toArray().filter(
        comp => comp.uniqueId === ChannelLocationUniqueKeys.SELLING_COUNTRIES)[0];
      sellingCountryComponent.selectItemsOnPreFill(self.selectedSellingRegions, self.selectedSellingCountries);

      const sellingRegionComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.SELLING_REGIONS)[0];
      sellingRegionComponent.selectItemsOnPreFill(self.selectedSellingZones, self.selectedSellingRegions);

      const sellingZoneComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.SELLING_ZONES)[0];
      sellingZoneComponent.selectItemsOnPreFill(null, self.selectedSellingZones);

      const targetCountryComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.TARGET_COUNTRIES)[0];
      targetCountryComponent.selectItemsOnPreFill(self.selectedTargetRegions, self.selectedTargetCountries);

      const targetRegionComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.TARGET_REGIONS)[0];
      targetRegionComponent.selectItemsOnPreFill(self.selectedTargetZones, self.selectedTargetRegions);

      const targetZoneComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.TARGET_ZONES)[0];
      targetZoneComponent.selectItemsOnPreFill(null, self.selectedTargetZones);
      clearTimeout(self.timerId);
      //
      if (self.loaderStart) {
        self.loaderNotify.emit(false);
      }
    }
  }

  addOrRemoveKeyRetailerValidation(index) {
    const retailernameCtrl = this.retailerItemsArray.controls[index].get('retailername') as FormControl;
    const countryidCtrl = this.retailerItemsArray.controls[index].get('countryid') as FormControl;
    const imageCtrl = this.retailerItemsArray.controls[index].get('image') as FormControl;
    // const retailermagePathCtrl = this.retailerItemsArray.controls['imageValue'];

    if (!retailernameCtrl.value && !countryidCtrl.value && !imageCtrl.value) {
      retailernameCtrl.clearValidators();
      retailernameCtrl.setErrors(null);
      countryidCtrl.clearValidators();
      countryidCtrl.setErrors(null);
      // imageCtrl.setValue('');
      // imageCtrl.clearValidators();
      // imageCtrl.setErrors(null);
    } else {
      retailernameCtrl.setValidators([Validators.required, Validators.maxLength(255)]);
      retailernameCtrl.setValue(retailernameCtrl.value);
      retailernameCtrl.markAsTouched();

      countryidCtrl.setValidators([Validators.required]);
      countryidCtrl.setValue(countryidCtrl.value);
      countryidCtrl.markAsTouched();

      // imageCtrl.setValidators([Validators.required]);
      // if (!imageCtrl.value) {
      //   imageCtrl.setErrors({ required: true });
      // }
      // imageCtrl.markAsTouched();
      // imageCtrl.setValue(imageCtrl.value);
      // imageCtrl.markAsTouched();
    }
  }

  setKeyRetailerValidation() {
    this.retailerItemsArray.controls.forEach(item => {
      const retailername = (item as FormGroup).controls['retailername'] as FormControl;
      const countryid = (item as FormGroup).controls['countryid'] as FormControl;
      const image = (item as FormGroup).controls['image'] as FormControl;

      if (retailername.value || countryid.value || image.value) {
        retailername.setValidators([Validators.required, Validators.maxLength(255)]);
        countryid.setValidators([Validators.required]);
        // image.setValidators([Validators.required]);
      }
    });
  }

  markFormArrayTouched(formarrray) {
    if (formarrray && formarrray.controls) {
      if (formarrray.controls.length) {
        formarrray.controls.forEach(control => {
          if (control) { // control is a FormGroup
            this.markFormArrayTouched(control);
          } else { // control is a FormControl
            control.markAsTouched();
          }
        });
      } else {
        const keys = Object.keys(formarrray.controls);
        keys.forEach(val => {
          const ctrl = formarrray.controls[val];
          if (!ctrl.valid) {
            ctrl.markAsTouched();
          }
        });
      }
    }
  }

  markFormGroupTouched(formGroup) {
    const keys = Object.keys(formGroup.controls);
    keys.forEach(val => {
      const ctrl = formGroup.controls[val];
      if (!ctrl.valid) {
        ctrl.markAsTouched();
        if (!this.scrollToElementId) {
          this.scrollToElementId = val + 'Id';
        }
      }
    });
  }

  setLocationsDisabledState(self, locationType, isChecked) {
    if (locationType === ChannelLocationUniqueKeys.SELLING_ZONES) {
      if (isChecked) {
        self.isSellingRegionDisabled = false;
        // self.isSellingCountryDisabled = false;
        self.setSellingCountryDisabled(self);
      } else {
        const sellingZoneComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
          === ChannelLocationUniqueKeys.SELLING_ZONES)[0];
        const selectedZones = sellingZoneComponent.getSelectedData();
        if (selectedZones.length > 0) {
          self.isSellingRegionDisabled = false;
          // self.isSellingCountryDisabled = false;
          self.setSellingCountryDisabled(self);
        } else {
          self.isSellingRegionDisabled = true;
          self.isSellingCountryDisabled = true;
        }
      }
    } else if (locationType === ChannelLocationUniqueKeys.SELLING_REGIONS) {
      if (isChecked) {
        self.isSellingCountryDisabled = false;
      } else {
        self.setSellingCountryDisabled(self);
      }
    } else if (locationType === ChannelLocationUniqueKeys.TARGET_ZONES) {
      if (isChecked) {
        self.isTargetRegionDisabled = false;
        self.setTargetCountryDisabled(self);
      } else {
        const resultComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
          === ChannelLocationUniqueKeys.TARGET_ZONES)[0];
        const selectedInfo = resultComponent.getSelectedData();
        if (selectedInfo.length > 0) {
          self.isTargetRegionDisabled = false;
          self.setTargetCountryDisabled(self);
        } else {
          self.isTargetRegionDisabled = true;
          self.isTargetCountryDisabled = true;
        }
      }
    } else if (locationType === ChannelLocationUniqueKeys.TARGET_REGIONS) {
      if (isChecked) {
        self.isTargetCountryDisabled = false;
      } else {
        self.setTargetCountryDisabled(self);
      }
    } else {
      if (locationType !== ChannelLocationUniqueKeys.SELLING_COUNTRIES && locationType !== ChannelLocationUniqueKeys.TARGET_COUNTRIES) {
        self.isSellingRegionDisabled = true;
        self.isSellingCountryDisabled = true;
        self.isTargetRegionDisabled = true;
        self.isTargetCountryDisabled = true;
      }
    }

    clearTimeout(self.timerId);
  }

  setSellingCountryDisabled(self) {
    const resultComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
      === ChannelLocationUniqueKeys.SELLING_REGIONS)[0];
    const selectedInfo = resultComponent.getSelectedData();
    if (selectedInfo.length > 0) {
      self.isSellingCountryDisabled = false;
    } else {
      self.isSellingCountryDisabled = true;
    }
  }

  setTargetCountryDisabled(self) {
    const resultComponent = self.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
      === ChannelLocationUniqueKeys.TARGET_REGIONS)[0];
    const selectedInfo = resultComponent.getSelectedData();
    if (selectedInfo.length > 0) {
      self.isTargetCountryDisabled = false;
    } else {
      self.isTargetCountryDisabled = true;
    }
  }

  onLocationListAllSelected(locationData: LocationData) {
    this.validateLocationsOnChange(locationData.type);
    if (locationData.type === ChannelLocationUniqueKeys.SELLING_ZONES) {
      const sellingZoneComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.SELLING_ZONES)[0];
      const selectedZones = sellingZoneComponent.getSelectedIds();
      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];
      sellingRegionComponent.refreshItemsByParent(selectedZones);
      const selectedRegions = sellingRegionComponent.getSelectedIds();
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.SELLING_REGIONS) {

      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      // sellingCountryComponent.onAddingSelectedItemIds(locationData.data);
      const selectedRegions = sellingRegionComponent.getSelectedIds();
      sellingCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_ZONES) {
      const targetZoneComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId
        === ChannelLocationUniqueKeys.TARGET_ZONES)[0];
      const selectedZones = targetZoneComponent.getSelectedIds();

      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      targetRegionComponent.refreshItemsByParent(selectedZones);
      const selectedRegions = targetRegionComponent.getSelectedIds();
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_REGIONS) {

      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      // targetCountryComponent.onAddingSelectedItemIds(locationData.data);
      const selectedRegions = targetRegionComponent.getSelectedIds();
      targetCountryComponent.refreshItemsByParent(selectedRegions);

    }

    this.setLocationsDisabledState(this, locationData.type, true);
  }

  onLocationListAllUnselected(locationData: LocationData) {
    this.validateLocationsOnChange(locationData.type);
    if (locationData.type === ChannelLocationUniqueKeys.SELLING_ZONES) {
      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];
      sellingRegionComponent.refreshItemsByParent(null);
      const selectedRegions = sellingRegionComponent.getSelectedIds();
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      sellingCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.SELLING_REGIONS) {

      const sellingRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingRegions')[0];
      const sellingCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'SellingCountries')[0];
      // sellingCountryComponent.onAddingUnSelectedItemIds(locationData.data);
      const selectedRegions = sellingRegionComponent.getSelectedIds();
      sellingCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_ZONES) {

      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      targetRegionComponent.refreshItemsByParent(null);
      const selectedRegions = targetRegionComponent.getSelectedIds();
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      targetCountryComponent.refreshItemsByParent(selectedRegions);

    } else if (locationData.type === ChannelLocationUniqueKeys.TARGET_REGIONS) {

      const targetRegionComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetRegions')[0];
      const targetCountryComponent = this.checkBoxListComponents.toArray().filter(comp => comp.uniqueId === 'TargetCountries')[0];
      // targetCountryComponent.onAddingUnSelectedItemIds(locationData.data);
      const selectedRegions = targetRegionComponent.getSelectedIds();
      targetCountryComponent.refreshItemsByParent(selectedRegions);

    }

    this.setLocationsDisabledState(this, locationData.type, false);
  }

  // Remove the Key Retailer List
  removeKeyRetailerList(data: KeyRetailerSelectedList, index, typeId: string) {
    if (index !== -1) {
      if (data.keypartnerid) {
        this.partnerObjects[typeId].deletedkeyretailer.push(data.keypartnerid);
        this.partnerObjects[typeId].keyRetailerSelectedData =
          this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.keypartnerid !== data.keypartnerid);
        const checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel.filter(item => item.oldchannelid
          === data.keypartnerid);
        if (checkDuplicates[0] === null) {
          const deletedKeypartners = data;
          delete deletedKeypartners.keypartnerid;
          this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(deletedKeypartners);
          this.partnerObjects[typeId].keyRetailerFilterData.push(deletedKeypartners);
        }
      } else if (data.existchannelid || data.oldchannelid) {
        let checkDuplicates = [null];
        if (data.existchannelid) {
          this.partnerObjects[typeId].keyRetailerSelectedData
            = this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.existchannelid !== data.existchannelid);
          checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel.
            filter(item => item.existchannelid === data.existchannelid);
        } else {
          this.partnerObjects[typeId].keyRetailerSelectedData
            = this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.oldchannelid !== data.oldchannelid);
          checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel.
            filter(item => item.oldchannelid === data.oldchannelid);
        }
        if (checkDuplicates[0] === null) {
          this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(data);
          this.partnerObjects[typeId].keyRetailerFilterData.push(data);
        }
      } else if (data.existchannelid === null && data.oldchannelid === null) {
        this.partnerObjects[typeId].keyRetailerSelectedData.splice(index, 1);
      }
    }
  }

  // Popup for add brand details
  addNewKeyRetailer(keyRetailer, typeId: string): void {
    this.keyretailerDisable = true;
    const dialogRef = this.dialog.open(AddBrandComponent, {
      data: {
        type: 2,
        boolClose: false,
        name: keyRetailer,
        title: typeId === '4' ? ['tradeinformation.bodyLabels.addkeyretailer', 'addProduct.distributionchannelTab.retailerName',
          'Retailer.pageTitle', '4']
          : ['tradeinformation.bodyLabels.addkeydistributor', 'addProduct.distributionchannelTab.distributorName', 'Distributor.pageTitle'
            , '3']
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result.boolClose) {
        delete result.boolClose;
        this.checkDuplicatesKeyretailers(result.keyretailer, typeId);
      }
      this.keyretailerDisable = false;
    });
  }

  onSelectKeyRetailer(event: KeyRetailerSelectedList, typeId: string = '3') {
    // event['keyretailerid'] = null;
    // event['countryName'] = null;
    this.partnerObjects[typeId].keyRetailerSelectedData.push(event);
    this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
      if (selectitem.existchannelid !== null) {
        this.partnerObjects[typeId].keyRetailerFilterDataChannel = this.partnerObjects[typeId].keyRetailerFilterDataChannel.filter(item =>
          item.existchannelid !== selectitem.existchannelid);
      } else if (selectitem.oldchannelid !== null) {
        this.partnerObjects[typeId].keyRetailerFilterDataChannel = this.partnerObjects[typeId].keyRetailerFilterDataChannel.filter(item =>
          item.oldchannelid !== selectitem.oldchannelid);
      }
    });
  }

  // Search Key Retailer List
  getTradeKeyRetailer(typeId: string) {
    // delete this.keyRetailerFilterData;
    const channelId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID).toString(), 10);
    this._ProductBusiness.getTradeKeyRetailerSearch(channelId, true, typeId).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        const keyRetailersResponse = response.json() as ChannelKeyretailersDescription;
        const _keyRetailerListResponse = keyRetailersResponse.channelKeyRetailers as ChannelKeyRetailerObject[];
        if (typeId === '4' && keyRetailersResponse.keyretailerDescription && this.actionType !== ActionType.UPDATE) {
          this.retailerGroup.controls['retailernameDescription'].setValue(keyRetailersResponse.keyretailerDescription);
        }
        if (typeId === '3' && keyRetailersResponse.keydistributorDescription && this.actionType !== ActionType.UPDATE) {
          this.retailerGroup.controls['distributornameDescription'].setValue(keyRetailersResponse.keydistributorDescription);
        }
        const action = this.actionType === ActionType.ADD ? 1 : 2;
        this.preFillKeyRetailerList(_keyRetailerListResponse, action, typeId);
      }
    });
  }

  preFillKeyRetailerList(_keyRetailerListResponse, type, typeId: string) {
    this.partnerObjects[typeId].keyRetailerUpdatedData = [];
    if (_keyRetailerListResponse && _keyRetailerListResponse.length > 0) {
      _keyRetailerListResponse.forEach(item => {
        const keyRetailerList = new KeyRetailerSelectedList();
        let retailers;
        keyRetailerList.oldchannelid = null;
        keyRetailerList.existchannelid = null;
        keyRetailerList.channelId = null;
        if (item.active) {
          retailers = item.active;
          keyRetailerList.existchannelid = retailers.id;
          keyRetailerList.channelId = retailers.id;
        } else if (item.new) {
          retailers = item.new;
        } else if (item.old) {
          retailers = item.old;
          keyRetailerList.oldchannelid = retailers.id;
        }
        if (retailers.company_name) {
          keyRetailerList.companyName = retailers.company_name;
          keyRetailerList.partnername = retailers.company_name;
        }
        if (retailers.country) {
          keyRetailerList.countryid = retailers.country.country_id;
          keyRetailerList.countryName = retailers.country.country_name;
        }
        if (retailers.logo) {
          if (item.new) {
            keyRetailerList.documentPath = retailers.logo.logo_name;
          } else {
            keyRetailerList.documentPath = retailers.logo.documentPath;
          }
          keyRetailerList.documentUrl = retailers.logo.documentUrl ? retailers.logo.documentUrl : 'assets/images/pro-logo.jpg';
          keyRetailerList.imageid = retailers.logo.logo_id;
        } else {
          keyRetailerList.documentUrl = 'assets/images/pro-logo.jpg';
        }
        keyRetailerList.keypartnerid = item.keypartnerid;
        if (type === 1) {
          this.partnerObjects[typeId].keyRetailerSelectedData.push(keyRetailerList);
          this.partnerObjects[typeId].keyRetailerUpdatedData.push(keyRetailerList);
          this.getKeyRetailerOldNew('3');
          this.getKeyRetailerOldNew('4');
        } else {
          // this.keyRetailerFilterData.push(keyRetailerList);
          this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(keyRetailerList);
        }
        // this.keyRetailerFilterDataChannel.push(keyRetailerList);
      });
    } else {
      this.loaderNotify.emit(false);
    }
  }

  filterKeyRetailersUpdate(typeId: string) {
    this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
      this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData
        .filter(filter => filter.keypartnerid !== selectitem.keypartnerid);
    });
  }
  // // Search Key Retailer List
  // getKeyRetailer() {
  //   // delete this.keyRetailerFilterData;
  //   this._ProductBusiness.getKeyRetailerSearch(this.searchKeyretailer).subscribe(result => {
  //     const response = result as Response;
  //     if (response.ok) {
  //       const _keyRetailerListResponse = response.json() as KeyRetailerRootObject;

  //       if (_keyRetailerListResponse.channel) {
  //         _keyRetailerListResponse.channel.forEach(item => {
  //           this.keyRetailerFilterData.push({
  //             channelId: item.channelId ? item.channelId : null,
  //             oldchannelid: item.oldChannelId ? item.oldChannelId : null,
  //             companyName: item.companyName,
  //             documentPath: item.companylogo ? item.companylogo.documentPath : '',
  //             documentUrl: item.companylogo ? item.companylogo.documentUrl : '',
  //             countryid: item.regaddresscountry.countryId,
  //             existchannelid: item.channelId ? item.channelId : null,
  //             countryName: item.regaddresscountry.country
  //           });
  //         });
  //         this.keyRetailerSelectedData.forEach(selectitem => {
  //           this.keyRetailerFilterData = this.keyRetailerFilterData.filter(item => item.channelId
  //             !== selectitem.channelId);
  //             console.log("Selected key retailer new channel", this.keyRetailerFilterData, ' ', selectitem.oldchannelid);

  //         });

  //       }

  //       if (_keyRetailerListResponse.oldchannel) {
  //         _keyRetailerListResponse.oldchannel.forEach(item => {
  //           this.keyRetailerFilterData.push({
  //             channelId: null,
  //             oldchannelid: item.oldChannelId ? item.oldChannelId : null,
  //             companyName: item.companyName,
  //             documentPath: item.oldchanneldetail ? item.oldchanneldetail.documentPath : '',
  //             documentUrl: item.oldchanneldetail ? item.oldchanneldetail.documentUrl : '',
  //             countryid: item.oldregaddresscountry.countryId,
  //             existchannelid: null,
  //             countryName: item.oldregaddresscountry.country
  //           });
  //         });
  //         this.keyRetailerSelectedData.forEach(selectitem => {
  //           this.keyRetailerFilterData = this.keyRetailerFilterData.filter(item => item.oldchannelid
  //             !== selectitem.oldchannelid);
  //             console.log("Selected key retailer old channel", this.keyRetailerFilterData, ' ', selectitem.oldchannelid);
  //         });
  //       }
  //     }
  //   });
  // }

  // getKeyRetailersList() {
  //   this.keyRetailerPostData = [];
  //   this.keyRetailerSelectedData.forEach(item => {
  //     if (item.keyretailerid) {
  //       this.keyRetailerPostData.push(item.keyretailerid);
  //     }
  //   });
  //   return this.keyRetailerPostData;
  // }

  getKeyRetailersList(typeId: string) {
    this.partnerObjects[typeId].keyRetailerPostData = [];
    let count = 0;
    this.partnerObjects[typeId].keyRetailerSelectedData.forEach(item => {
      const keyRetailer = new KeyRetailerListPost();
      if (item.channelId && item.channelId !== null) {
        keyRetailer['existchannelid'] = item.channelId;
      } else if (item.oldchannelid && item.oldchannelid !== null) {
        keyRetailer['oldchannelid'] = item.oldchannelid;
      }
      if (item.keypartnerid) {
        keyRetailer['keypartnerid'] = item.keypartnerid;
      }
      keyRetailer['countryid'] = item.countryid;
      keyRetailer['partnername'] = item.companyName;
      keyRetailer['image'] = item.documentPath;
      keyRetailer['imageid'] = item.imageid;
      const countKeyRetailer = this.partnerObjects[typeId].keyRetailerUpdatedData.
        filter(retailer => retailer.keypartnerid === item.keypartnerid);
      if (countKeyRetailer.length !== 0) {
        count++;
      }
      this.partnerObjects[typeId].keyRetailerPostData.push(keyRetailer);
    });
    if (count === this.partnerObjects[typeId].keyRetailerSelectedData.length && this.actionType === ActionType.UPDATE) {
      this.partnerObjects[typeId].keyRetailerPostData = [];
    }
    return this.partnerObjects[typeId].keyRetailerPostData;
  }

  // Search Key Retailer List
  getKeyRetailerOldNew(typeId: string, loader: boolean = true) {
    // delete this.keyRetailerFilterData;
    if (loader) {
      this.loaderNotify.emit(true);
    }
    this._ProductBusiness.getKeyRetailerSearch(this.searchKeyretailer, typeId).subscribe(result => {
      const response = result as Response;
      if (loader) {
        this.loaderNotify.emit(false);
      }
      if (response.ok) {
        const _keyRetailerListResponse = response.json() as KeyRetailerRootObject;
        this.partnerObjects[typeId].keyRetailerFilterData = [];
        if (_keyRetailerListResponse.channel) {
          _keyRetailerListResponse.channel.forEach(item => {
            this.partnerObjects[typeId].keyRetailerFilterData.push({
              channelId: item.channelId ? item.channelId : null,
              oldchannelid: item.oldChannelId ? item.oldChannelId : null,
              companyName: item.companyName,
              documentPath: item.companylogo ? item.companylogo.documentPath : null,
              documentUrl: item.companylogo ? item.companylogo.documentUrl : null,
              countryid: item.regaddresscountry.countryId,
              existchannelid: item.channelId ? item.channelId : null,
              countryName: item.regaddresscountry.country
            });
          });
          this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
            if (selectitem.channelId !== null) {
              this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData
                .filter(item => item.channelId !== selectitem.channelId);
            }
          });
        }
        console.log(this.keyRetailerFilterData.length);
        if (_keyRetailerListResponse.oldchannel) {
          _keyRetailerListResponse.oldchannel.forEach(item => {
            this.partnerObjects[typeId].keyRetailerFilterData.push({
              channelId: null,
              oldchannelid: item.oldChannelId ? item.oldChannelId : null,
              companyName: item.companyName,
              documentPath: item.oldchanneldetail ? item.oldchanneldetail.documentPath : null,
              documentUrl: item.oldchanneldetail ? item.oldchanneldetail.documentUrl : null,
              countryid: item.oldregaddresscountry.countryId,
              existchannelid: null,
              countryName: item.oldregaddresscountry.country
            });
          });
          this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
            if (selectitem.oldchannelid !== null) {
              this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData
                .filter(item => item.oldchannelid
                  !== selectitem.oldchannelid);
            }
          });
        }
        this.partnerObjects[typeId].keyRetailerFilterDataChannel.forEach(selectitem => {
          let checkDuplicates = [];
          if (selectitem.channelId !== null || selectitem.oldchannelid !== null
            || (selectitem.keypartnerid === null && selectitem.keypartnerid !== undefined)) {
            if (selectitem.channelId !== null && selectitem.channelId !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.filter(item => item.channelId
                === selectitem.channelId);
            } else if (selectitem.oldchannelid !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.filter(item => item.oldchannelid
                === selectitem.oldchannelid);
            } else if (selectitem.keypartnerid === null && selectitem.keypartnerid !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.filter(item => item.companyName
                === selectitem.companyName);
            }
          }
          if (checkDuplicates.length === 0) {
            this.partnerObjects[typeId].keyRetailerFilterData.push(selectitem);
          }
        });
        this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
          if (selectitem.keypartnerid !== null && selectitem.keypartnerid !== undefined) {
            this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData
              .filter(item => item.keypartnerid !== selectitem.keypartnerid);
          }
        });
      }
    });
  }

  checkDuplicatesKeyretailers(keyRetailer, typeId: string) {
    this.loaderNotify.emit(true);
    this._sharedService.checkDuplicatesKeyretailerService(keyRetailer.partnername, typeId).subscribe(res => {
      const response = res as Response;
      this.loaderNotify.emit(false);
      const checkDuplicateSelected = this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.partnername !== undefined
        && item.partnername.toUpperCase() === keyRetailer.partnername.toUpperCase());
      if (response.ok && checkDuplicateSelected.length === 0) {
        const getCountryName = this.countryMasterList.filter(country => parseInt(country.countryId, 10) === keyRetailer.country);
        if (getCountryName.length) {
          keyRetailer.countryName = getCountryName[0].country;
        }
        this.partnerObjects[typeId].keyRetailerSelectedData.push(keyRetailer);
      } else {
        this.toastr.error(this.translate.instant(typeId === '4' ? 'CommonUsageLabel.keyRetailer' : 'CommonUsageLabel.keyDistributor'));
      }
    });
  }

  // Search Key Retailer
  onSearchProductKeyRetailer(search: string, typeId: string) {
    // if(this.searchKeyretailer != search || this.partnerObjects[typeId].keyRetailerFilterData.length === 0) {
    this.searchKeyretailer = search;
    this.getKeyRetailerOldNew(typeId);
    // }
  }
}
