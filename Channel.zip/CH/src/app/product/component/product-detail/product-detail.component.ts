import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Response } from '@angular/http';
import { ProductRootObject, ProductInfoRootObject } from '@app/product/models/product-view';
import { ProductInfoObject } from '@app/product/models/product-info';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { PopUpTitle, CurrencyType, PopUpSuccessMsg, ChannelTypeIdEnum, PageNames, ButtonTypes } from '@app/config/constant';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { DismissReasons } from '@app/channel/models/channel_models';
import { UpdateDefaultContact } from '@app/shared/models/contact-list-models';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { ProductBusiness } from '@app/product/business/product.business';
import { RequestSuggestionComponent } from '@app/shared/shared-component/request-suggestion/request-suggestion.component';
import { TranslateService } from '@ngx-translate/core';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { ChannelContactService } from '@app/shared/shared-service/channel-contact-service';
import { ChannelContactRequest } from '@app/shared/models/shared-model';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss']
})

export class ProductDetailComponent implements OnInit {
  public webUrl = WebUrl;
  private userId: any;
  public locationDataShow = 5;
  public locationtargetDataShow = 5;
  public locationDataShowProduct = 2;
  public productReviewDataShow = 4;
  _ProductRootObject: ProductRootObject;
  _ProductInfoObject: ProductInfoObject;
  rating = 2;
  public channelId: string;
  public countError: string;
  public preloader: boolean;
  public currencyType = CurrencyType;
  _ProductInfoRootObject: ProductInfoRootObject;
  dialogRef: MatDialogRef<MessageDialogComponent>;

  public _UpdateDefaultContact = new UpdateDefaultContact();
  @Output() cartQuantityChange = new EventEmitter<string>();
  @Output() EmitTabKeyRetailer = new EventEmitter();
  public channelTypeIdEnum = ChannelTypeIdEnum;
  public unauthorized: string;
  public subscription: boolean;

  constructor(public dialog: MatDialog, public sharedBusiness: SharedBusiness
    , private productBusiness: ProductBusiness, private toastr: ToastrService,
    private translate: TranslateService, private _channelBusiness: ChannelBusiness,
    private router: Router, private channelContactService: ChannelContactService) {
    this._ProductRootObject = new ProductRootObject();
    this._ProductInfoObject = new ProductInfoObject();

  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  @Input() set ObjProductInfo(value: ProductInfoObject) {
    this._ProductInfoObject = value;
  }

  @Input() sku: string;

  ngOnInit() {
    this.unauthorized = '';
    this.cartQuantityChange.emit('1');
    this.userId = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    this.channelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    this.modifyRelation();
  }

  /** Open mail popup */
  public sendEmail(contactId, contactData) {
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(EmailPopupComponent, {
      data: {
        senderId: this.userId,
        receiverId: contactId
      },
      width: '600px',
      height: 'auto'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      this.OpenContactDialog(contactData.title, PopUpTitle[11],
        contactData.channelListdata, '', 5);
    });
  }

  /** Request suggestion */
  public OpenRequestDialig(relationData) {
    const dialogRef = this.dialog.open(RequestSuggestionComponent, {
      data: {
        title: 'UPDATE',
        type: 2,
        // message: this.translate.instant(message),
        message: 'message',
        relation: relationData,
        channelId: parseInt(this._ProductInfoObject.channel.channelId, 10),
        // tslint:disable-next-line:max-line-length
        approvalstauts: (this._ProductInfoObject.relation && this._ProductInfoObject.relation.request && this._ProductInfoObject.relation.request === 'IN') ? 2 : 1,
        // tslint:disable-next-line:max-line-length
        relation_tag: (this._ProductInfoObject.relation && this._ProductInfoObject.relation.tag) ? this._ProductInfoObject.relation.tag : 'Low'
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this.changeChannelStatus(responseType, responseType.channelId);
        // if (responseType.status === 1) {
        //   // this.addToBusiness(productId);
        // } else if (responseType.status === 3) {
        //   // this.productDismissReasons();
        // }
      }
    });
  }

  /** Update channel status */
  changeChannelStatus(UpdateStatusData, id) {
    const channelStatus = {
      connectionStatusTypeId: UpdateStatusData.relation.relationId === 1 || UpdateStatusData.relation.relationId === undefined ? 7 : 2,
      channelJCTId: UpdateStatusData.relation.channelJCTId,
      // tslint:disable-next-line:max-line-length
      leadManagementTag: (this._ProductInfoObject.relation && this._ProductInfoObject.relation.tag) ? this._ProductInfoObject.relation.tag : 'Low'
    };
    this._channelBusiness.updateChannel(channelStatus, true, id).subscribe(response => {
      if (response.ok) {
        // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
        this._ProductInfoObject.relation.relationId = channelStatus.connectionStatusTypeId;
        const msg = this.translate.instant(PopUpSuccessMsg[channelStatus.connectionStatusTypeId]);
        this.toastr.success(msg);
      } else {
        this.preloader = false;
        if (response.json()[0]['errors'][0]['code'] === 3031) {
          // this.openUpgradePopup();
          const msg = this.translate.instant(PopUpSuccessMsg[20]);
          this.toastr.error(msg);
        } else {
          const msg = this.translate.instant(PopUpSuccessMsg[19]);
          this.toastr.error(msg);
        }
      }
    });
  }

  // Upgrade popup
  public openUpgradePopup() {
    const title = this.translate.instant('productList.upgradetitle');
    const message = this.translate.instant('searchList.upgradeMsg');
    const dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.subscriptionPlan();
      } else {
        this.unauthorized = this.translate.instant('searchList.upgradeMsg');
        this.subscription = true;
      }
    });
  }

      /** call subscription plan */
  subscriptionPlan() {
    localStorage.setItem('RedirectId', '12');
    this.router.navigate(['/user/subscriptionplan']);
  }

  viewContactDetails(event, contactData) {
    const list = [];
    this.OpenContactDialog(event.target.text, PopUpTitle[11], contactData, event.target.id, 5);
  }

  private OpenContactDialog(title: string, message: string, data: any, id: string, jtcId: number) {
    const dialogRef = this.dialog.open(ContactViewDialogComponent, {
      data: {
        title: this.translate.instant(message),
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: data.contact.contactId,
        channelId: data.channelId,
        channelType: data.channelType,
        jtcChannelId: jtcId,
        pageName:  PageNames.PRODUCT_DETAIL_VIEW,
        // tslint:disable-next-line:max-line-length
        approvalstauts: (this._ProductInfoObject.relation && this._ProductInfoObject.relation.request && this._ProductInfoObject.relation.request === 'IN') ? 2 : 1,
        // tslint:disable-next-line:max-line-length
        relation_tag: (this._ProductInfoObject.relation && this._ProductInfoObject.relation.tag) ? this._ProductInfoObject.relation.tag : 'Low'
      },
    });
    dialogRef.afterClosed().subscribe(responseType => {

      if (responseType && responseType.action === true) {
        /** variable for call again contact popup */
        const contactData = {
          title: title,
          channelListdata: data
        };
        if (responseType.contact === 1) { /** Open see all contact popup */
          this.OpenConfirmDialog('shared.buttonLabels.sellContacts', PopUpTitle[10]
            , [], data.channelId, 5, contactData);
        } else if (responseType.contact === 2) { /** Open mail popup */
          this.sendEmail(responseType.receiverId, contactData);
        }
      }
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    });
  }

  seeAllContact(event, data) {
    const list = [];
    this.OpenConfirmDialog(event.target.text, PopUpTitle[10], list, data.channelId, 5);
  }

  private OpenConfirmDialog(title: string, message: string, data: Array<DismissReasons>, id: string, jtcId, contact?: any) {
    const contactdata = contact;
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: this.translate.instant(message),
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: 17,
        channelId: id,
        jtcChannelId: jtcId,
      },
    });
    dialogRef.afterClosed().subscribe(responseType => {
      if (responseType) {
        this.changeAsDefault(responseType.channelId, responseType.contactId, contactdata);
      } else {
        if (contactdata) {
          this.OpenContactDialog(contactdata.title, PopUpTitle[11],
            contactdata.channelListdata, '', 5);
        }
      }
    });
  }

  changeAsDefault(jtcId, idContact, contactdata?: any) {
    localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'false');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'CommonUsageLabel.defaultContact',
        type: 2,
        message: 'CommonUsageLabel.defaultcontactAdd',
        list: [],
        id: 15,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'true');
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this._UpdateDefaultContact.channelId = parseInt(jtcId, 10);
        this._UpdateDefaultContact.contactId = parseInt(idContact, 10);
        this.sharedBusiness.updateDefaultContact(this._UpdateDefaultContact, true).subscribe(response => {

          if (response.ok) {
            if (contactdata) {
              this.OpenContactDialog(contactdata.title, PopUpTitle[11],
                contactdata.channelListdata, '', 5);
            }
            this.toastr.success(this.translate.instant('CommonUsageLabel.toastrMsgcontact'));
            this.getProductInfo(this.sku);
          } else {
            this.toastr.warning(this.translate.instant('commonError.somthingWrong'));
          }
        });
      } else if (contactdata) {
        this.OpenContactDialog(contactdata.title, PopUpTitle[11],
          contactdata.channelListdata, '', 5);
      }
    });
  }

  getProductInfo(productSKU) {
    this.preloader = true;
    this.productBusiness.GetProductInfo(productSKU).subscribe(res => {
      const response = res as Response;
      this.preloader = false;
      if (response.ok) {
        // const info = response.json();
        this._ProductInfoObject = response.json();
      }
    });
  }

  patternValidate(event) {
    if (event.target.value.match('^[1-9][0-9]*$') === null) {
      event.target.value = '';
      return false;
    }
  }

  cartQuantityUpdate(data, pricelimit) {
    if (data.target.value !== '') {
      // if (pricelimit.isunlimitsample === '1') {
      this.countError = '';
      this.cartQuantityChange.emit(data.target.value);
      // } else {
      // if (parseInt(pricelimit.samplethreshold, 10) >= parseInt(data.target.value, 10)) {
      //     this.countError = '';
      //     this.cartQuantityChange.emit(data.target.value);
      // } else {
      //   this.cartQuantityChange.emit('0');
      //   this.countError = 'This product reached the limit';
      // }
      // }
    } else {
      this.cartQuantityChange.emit('0');
      this.countError = this.translate.instant('popupText.validNumber');
    }
  }
  locationDataFuction(currentdata, totalLenght) {
    this.locationDataShow = currentdata === 5 ? totalLenght : 5;
  }

  // Product Evaluation rating
  evaluationRating(productObject) {
    // tslint:disable-next-line:triple-equals
    if (parseInt(this.channelId, 10) === this.channelTypeIdEnum.VENDOR) {
      this.router.navigate([this.webUrl.MY_PRODUCTVIEW + productObject.productSKU + '/rating/', productObject.productId]);
    } else {
      this.router.navigate([this.webUrl.PRODUCT_SUGGESTION_VIEW + productObject.productSKU + '/rating/', productObject.productId]);
    }
  }

  // Open show the tab
  emitTabKeyRetailer(data: number) {
    this.EmitTabKeyRetailer.emit(data);
  }

  modifyRelation() {
    this.channelContactService.currentRequest.subscribe(item => {
      if (item) {
        const contactRelation = item as ChannelContactRequest;
        if (contactRelation.page === PageNames.PRODUCT_DETAIL_VIEW) {
          this._ProductInfoObject.relation.relationId = contactRelation.relation.relationId;
        }
      }
    });
  }
}
