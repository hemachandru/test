import { Component, OnInit, Input, Output, EventEmitter, ViewChildren, AfterViewInit, QueryList, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray, AbstractControl } from '@angular/forms';
import { ScrollToService } from 'ng2-scroll-to-el';
import * as moment from 'moment';
import { Config, ActionType, ChannelType, S3Buckets, UploadNotifyEnum, AddProductSectionMaxLimit, FeatureAccessEnum } from '@app/config/constant';
// import { Config, ChannelType, LocationType, SocialMedia, Role, ProductCategoryTypeEnum } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import {
  ProductBasicInfo, Producttag, ProductBasicInfoAdd, ProductArticleReview, ProductImages,
  ProductBrochure, ProductPreferences, Review, Productexistingrating, Preference,
  Productimage, Productdisplayimage, Productpackagingimage, Productpdf, AwardDetail
} from '../../models/add-product';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { Response } from '@angular/http';
import {
  ProductGroup, ProductCategory, Brand, ChannelInfos, ShareType, ImageUploadItem, ErrorCustomModel
} from '@app/shared/models/shared-model';
import {
  ProductArticleReviewGet, ProductExistRatingGet, ProductSharePreference,
  ProductImageGet, ImagesGet, ProductAwards
} from '../../models/get-product';
import { ReturnStatement } from '@angular/compiler/src/output/output_ast';
import { FileHolder, ImageUploadComponent, UploadMetadata } from 'angular2-image-upload';
import { MultipleFileUploadModel, MessageNotify, FileUploadModel } from '@app/shared/models/multiple-file-upload-model';
import { CommonHelper } from '@app/shared/common-helper';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';

enum GeneralEnum {
  PRODUCT_IMAGES = 1,
  PRODUCT_DISPLAY = 2,
  PRODUCT_PACKAGING = 3,
  PRODUCT_Brouchures = 4,
}

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss']
})
// Form groups
export class GeneralComponent implements OnInit {
  basicInfoGroup: FormGroup;
  // Form controls
  productNameCtrl: FormControl;
  productGroupCtrl: FormControl;
  productCategoryCtrl: FormControl;
  brandsCtrl: FormControl;
  productDescriptionCtrl: FormControl;
  uspCtrl: FormControl;
  productstatusCtrl: FormControl;
  public productGroupList;
  activeStatus: FormControl;
  reviewItemsArray: FormArray;
  articleReview: FormGroup;
  ratingItemsArray: FormArray;
  awardDetailGroup: FormGroup;

  // Variables
  productGroups: Array<ProductGroup>;
  productCategoriesSource: Array<ProductCategory>;
  productCategoryList: Array<ProductCategory>;
  brands: Array<Brand>;
  urlReviewImg: Array<any>;
  urlExistingImg: Array<any>;
  urlAwardImg: Array<any>;
  reviewRating: Array<any>;
  imageArraytemp = [];
  document: Document;
  claimDocError;
  msg_code;
  productTags: Array<Producttag> = new Array<Producttag>();
  @Input()
  public actionType: number;
  deletedProductTag: Array<number>;
  deletedArticleReview: Array<number>;
  deletedExistingRating: Array<number>;
  deletedAwardDetail: Array<number>;
  deletedProductImage: Array<number>;
  deletedProductDisplayimage: Array<number>;
  deletedProductPackageImage: Array<number>;
  deletedProductBrochure: Array<number>;
  shareTypes: Array<ShareType>;
  isshowtofreesub: string;
  productImagesMaxLimit: number;
  productDisplayImagesMaxLimit: number;
  productPackagingImagesMaxLimit: number;
  productBrouchureMaxLimit: number;
  generalEnum = GeneralEnum;
  productImages: ProductImages;
  productBrochure: ProductBrochure;
  productTag: string;
  videoUrl: string;
  public TagIderror: boolean;
  errBrochureImage = 'brouchureImage';
  errDisplayImage = 'displayImage';
  errPakageImage = 'packageImage';
  errProductImage = 'productImage';
  errShareType = 'shareType';
  errVideoURL = 'videoURL';
  errProductTags = 'productTags';
  msg_code_ShareType = '';
  msg_code_videoURL = '';
  msg_code_ProductTags = '';
  msg_code_arr = { '1': '', '2': '', '3': '', '4': '' };
  @Output()
  public loaderNotify: EventEmitter<boolean> = new EventEmitter<boolean>();
  public preview = true;
  scrollToElementId: string;
  dropBoxProductImage: boolean;
  dropBoxProductDisplay: boolean;
  dropBoxProductPackaging: boolean;
  dropBoxProductBrouchure: boolean;
  allowedImageTypes: string[] = ['jpg', 'png', 'jpeg'];

  @ViewChildren(ImageUploadComponent) imageUploaders: QueryList<ImageUploadComponent>;
  public isRatingValidationSet: boolean;
  productImagePrefillInput: Array<FileUploadModel>;
  productDisplayImagePrefillInput: Array<FileUploadModel>;
  productPackageImagePrefillInput: Array<FileUploadModel>;
  productBrouchurePrefillInput: Array<FileUploadModel>;

  public defaultModules = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote', 'code-block'],

      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction

      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

      [{ 'color': new Array<any>() }, { 'background': new Array<any>() }],          // dropdown with defaults from theme
      [{ 'font': new Array<any>() }],
      [{ 'align': new Array<any>() }],

      ['clean'],                                         // remove formatting button

      ['link']                         // link add  ['link', 'image', 'video'] for all
    ]
  };

  public productdescOptions = {
    placeholder: 'Enter Product Description',
    modules: this.defaultModules
  };

  public productuspOptions = {
    placeholder: 'Enter Product USP',
    modules: this.defaultModules
  };

  public productdescCtrl: string;
  public productdescErrCode: string;

  public productuspCtrl: string;
  public productuspErrCode: string;
  private productDescMinLength: number;
  private productDescMaxLength: number;
  private uspMinLength: number;
  private uspMaxLength: number;
  public itemsAward: FormArray;
  @ViewChild('productnameId') productnameElement: ElementRef;
  isvideoUrlAuthorized: boolean;
  productFileMaxSize = 2000000;
  constructor(private config: Config, private s3UploadFileService: S3UploadFileService, private translate: TranslateService,
    private scrollService: ScrollToService, private sharedBusiness: SharedBusiness,
    private toastr: ToastrService, private authorizeService: AuthorizeService) { }

  ngOnInit() {
    this.authorizeVideoUrl();
    this.authorizeProductImage();
    this.productdescCtrl = 'productdesc';
    this.productuspCtrl = 'productusp';
    this.productDescMinLength = 15;
    this.productDescMaxLength = 8000;
    this.uspMinLength = 15;
    this.uspMaxLength = 8000;
    this.productImagesMaxLimit = 5;
    this.productDisplayImagesMaxLimit = 5;
    this.productPackagingImagesMaxLimit = 5;
    this.productBrouchureMaxLimit = 5;
    this.urlReviewImg = [];
    this.urlExistingImg = [];
    this.reviewRating = [2];
    this.urlAwardImg = [];
    if (this.actionType === ActionType.UPDATE) {
      this.deletedProductTag = new Array<number>();
      this.deletedArticleReview = new Array<number>();
      this.deletedExistingRating = new Array<number>();
      this.deletedProductImage = new Array<number>();
      this.deletedProductDisplayimage = new Array<number>();
      this.deletedProductPackageImage = new Array<number>();
      this.deletedProductBrochure = new Array<number>();
      this.deletedAwardDetail = new Array<number>();
    } else {
      this.productTag = '';
    }

    this.isshowtofreesub = '0';
    this.initializeRegistrationGroup();
    // this.getShareTypeList();
    this.productImages = new ProductImages();
    this.productImages.productimage = new Array<Productimage>();
    this.productImages.productdisplayimage = new Array<Productdisplayimage>();
    this.productImages.productpackagingimage = new Array<Productpackagingimage>();
    this.productBrochure = new ProductBrochure();
    this.productBrochure.productpdf = new Array<Productpdf>();
    this.videoUrl = '';
    this.TagIderror = false;
    this.scrollToElementId = '';

    this.dropBoxProductImage = false;
    this.dropBoxProductDisplay = false;
    this.dropBoxProductPackaging = false;
    this.dropBoxProductBrouchure = false;
    this.isRatingValidationSet = false;
  }

  initializeRegistrationGroup() {
    this.productNameCtrl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(3),
    Validators.maxLength(255)]));
    this.productstatusCtrl = new FormControl(true, Validators.compose([]));
    this.productGroupCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.productCategoryCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.brandsCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.productDescriptionCtrl = new FormControl('');
    this.uspCtrl = new FormControl('');
    this.activeStatus = new FormControl('', Validators.compose([Validators.required]));
    this.basicInfoGroup = new FormGroup({
      productname: this.productNameCtrl,
      productstatus: this.productstatusCtrl,
      productgroup: this.productGroupCtrl,
      productcategory: this.productCategoryCtrl,
      productbrand: this.brandsCtrl,
      productdesc: this.productDescriptionCtrl,
      productusp: this.uspCtrl
    });

    this.reviewItemsArray = new FormArray([]);
    this.ratingItemsArray = new FormArray([]);
    this.itemsAward = new FormArray([]);
    this.articleReview = new FormGroup({
      reviewItemsArray: this.reviewItemsArray,
      ratingItemsArray: this.ratingItemsArray
    });

    this.awardDetailGroup = new FormGroup({
      itemsAward: this.itemsAward
    });

    // if (this.actionType === ActionType.ADD) {
    this.addItem('', '', '');
    this.addRatingItem('', '', '', '', 0, 0);
    this.addItemAward('', '', 0, null, '0');
    // }
  }

  onProductGroupChange(productGroupId) {
    this.productCategoryList = this.productCategoriesSource.filter(item => item.productGroupId === productGroupId);
    this.productCategoryCtrl.setValue('');
  }

  onProductKeyWordAdding(): void {
    this.msg_code_ProductTags = '';
    const _producttagUpdate = new Producttag();
    _producttagUpdate.tag = this.productTag;
    if (this.productTag.trim().length > 0 && this.productTags.filter(item =>
      item.tag.toUpperCase() === this.productTag.toUpperCase()).length === 0) {
      if (this.productTag.trim().length < 19) {
        this.TagIderror = false;
        this.productTags.push(_producttagUpdate);
        this.productTag = '';
      } else {
        this.TagIderror = true;
      }
    }
  }

  onTagRemoved(productTag: Producttag): void {
    this.productTags = this.productTags.filter(item => item.tag.toUpperCase() !== productTag.tag.toUpperCase());
    if (this.actionType === ActionType.UPDATE && productTag.producttagid > 0) {
      this.deletedProductTag.push(productTag.producttagid);
    }
  }

  addItem(name: string, url: string, image: string, imageId: number = 0, reviewId: number = 0) {
    if (this.reviewItemsArray.length < AddProductSectionMaxLimit.ReviewsMaxLimit) {
      this.reviewItemsArray = this.articleReview.get('reviewItemsArray') as FormArray;
      this.reviewItemsArray.push(this.buildItem(this.reviewItemsArray.length, 1, name, '', url, image, imageId, reviewId));
      this.urlReviewImg.push('');
    } else {
      const error = new ErrorCustomModel();
      error.displayName = this.translate.instant('addProduct.generalTab.articlesProperty');
      error.requiredLength = AddProductSectionMaxLimit.ReviewsMaxLimit;
      this.toastr.warning(this.translate.instant('addProduct.validationMessage.multipleSectionMaxReached', error));
    }
  }

  addRatingItem(name: string, logoname: string, url: string, image: string, imageId: number = 0, productexistratingid: number = 0) {
    if (this.ratingItemsArray.length < AddProductSectionMaxLimit.ProductExistingRatingMaxLimit) {
      this.ratingItemsArray = this.articleReview.get('ratingItemsArray') as FormArray;
      this.ratingItemsArray.push(
        this.buildItem(this.ratingItemsArray.length, 2, name, logoname, url, image, imageId, productexistratingid));
      this.urlExistingImg.push('');
      // this.reviewRating.push(2);

      // console.log('ratingItemsArray', this.ratingItemsArray);
    } else {
      const error = new ErrorCustomModel();
      error.displayName = this.translate.instant('addProduct.generalTab.reviewsProperty');
      error.requiredLength = AddProductSectionMaxLimit.ProductExistingRatingMaxLimit;
      this.toastr.warning(this.translate.instant('addProduct.validationMessage.multipleSectionMaxReached', error));
    }
  }

  addItemAward(name: string, id: string, row_id: number, valid_upto: Date, lifeTime: string, image: string = '', imageId: number = 0) {
    this.itemsAward = this.awardDetailGroup.get('itemsAward') as FormArray;
    this.itemsAward.push(this.buildItemAward(this.itemsAward.length, 3, name, id, row_id, valid_upto, lifeTime, image, imageId));
    this.urlAwardImg.push('');
  }

  deleteItem(type: number, index: number, id: number) {
    if (type === 1) {
      this.reviewItemsArray.removeAt(index);
      this.urlReviewImg.splice(index, 1);
      if (id && id.toString().length > 0 && parseInt(id.toString(), 10) !== 0 &&
        this.actionType === ActionType.UPDATE) {
        this.deletedArticleReview.push(id);
      }
      if (index === 0) {
        this.addItem('', '', '', 0, 0);
      }
    } else if (type === 2) {
      this.ratingItemsArray.removeAt(index);
      this.urlExistingImg.splice(index, 1);
      if (id && id.toString().length > 0 && parseInt(id.toString(), 10) !== 0 &&
        this.actionType === ActionType.UPDATE) {
        this.deletedExistingRating.push(id);
      }
      if (index === 0) {
        this.addRatingItem('', '', '', '', 0, 0);
      }
    } else if (type === 3) {
      this.itemsAward.removeAt(index);
      this.urlAwardImg.splice(index, 1);
      if (id && id.toString().length > 0 && parseInt(id.toString(), 10) !== 0 &&
        this.actionType === ActionType.UPDATE) {
        this.deletedAwardDetail.push(id);
      }
    }
    if (id !== 0) {
      // this.defaultConfig.accCertiNameId[arr].deleteId.push(id);
    }
  }

  buildItem(index, type: number, name: string, logoname: string = '', url: string, image: string, row_id: number, reviewId: number) {
    let controls = {};
    if (type === 1 || type === 2) {
      // controls = {
      //   url: new FormControl(url, Validators.compose([Validators.required,
      //   Validators.maxLength(255), Validators.pattern(this.config.urlPattern)]
      //   )),
      // };

      if (type === 1) {
        // controls = {
        //   url: new FormControl(url, Validators.compose([Validators.required,
        //   Validators.maxLength(255), Validators.pattern(this.config.urlPattern)]
        //   )),
        // };

        controls = {
          url: new FormControl(url, Validators.compose([
            Validators.maxLength(255),
            //  Validators.pattern(this.config.urlPattern)
          ]
          )),
        };
        // controls['name'] = new FormControl(name, Validators.compose([Validators.required]));
        controls['name'] = new FormControl(name);
        controls['profileImageValue'] = new FormControl('');
        // controls['profileImage'] = new FormControl(image, Validators.compose([Validators.required]));
        controls['profileImage'] = new FormControl(image);
        if (reviewId > 0) {
          controls['productarticlereviewid'] = new FormControl(reviewId);
        }

        if (row_id !== 0) {
          controls['imageid'] = new FormControl(row_id);
        }
      } else {
        controls = {
          url: new FormControl(url, Validators.compose([
            Validators.maxLength(255),
            //  Validators.pattern(this.config.urlPattern)
          ]
          )),
        };
        // controls['name'] = new FormControl(name && name.toString().length > 0 ? name : 0, Validators.compose([Validators.required]));
        controls['name'] = new FormControl(name && name.toString().length > 0 ? name : 0);
        controls['sitename'] = new FormControl(logoname, Validators.compose([Validators.required]));
        controls['profileImageValue'] = new FormControl('');
        // controls['profileImage'] = new FormControl(image, Validators.compose([Validators.required]));
        controls['profileImage'] = new FormControl(image);
        if (reviewId > 0) {
          controls['productexistratingid'] = new FormControl(reviewId);
        }

        if (row_id !== 0) {
          controls['imageid'] = new FormControl(row_id);
        }
      }
    }
    return new FormGroup(controls);
  }

  buildItemAward(index, type: number, name: string, id: string, row_id: number,
    valid_upto: Date, isLifeTime: string, image: string = '', imageId: number = 0) {
    let controls = {};
    let validRequired = null;
    if (index !== 0) {
      validRequired = Validators.required;
    }
    controls = {
      details: new FormControl(name, Validators.compose([validRequired, Validators.minLength(3), Validators.maxLength(254)])),
      issued_by: new FormControl(id, Validators.compose([validRequired, Validators.minLength(3), Validators.maxLength(254)])),
      valid_upto: new FormControl(valid_upto !== null ? moment(valid_upto).format('DD/MM/YYYY') : null),
      isLifeTime: new FormControl(isLifeTime),
      profileImageValue: new FormControl(''),
      profileImage: new FormControl(image),
      // channel_award_id: new FormControl(row_id),
    };
    if (row_id !== 0) {
      controls['product_award_id'] = new FormControl(row_id);
    }
    if (imageId !== 0) {
      controls['imageid'] = new FormControl(imageId);
    }
    return new FormGroup(controls);
  }

  userProfileUpload(e, DimensionWidth, DimensionHeight, indexArr, itemsArrayName) {
    const file = e.target.files.item(0);
    if (file) {
      let fileExtension = file.name.substr((file.name.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString();
      if (fileExtension === 'jpeg' || fileExtension === 'jpg' || fileExtension === 'png') {
        if (CommonHelper.checkValidImageSize(file.size)) {
          this[itemsArrayName].controls[indexArr].get('profileImage').setErrors({ imageUploadFormat: true });
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            img.src = event.target.result;
            img.onload = async function () {
              // img.width === DimensionWidth && img.height === DimensionHeight
              if (img) {
                self[itemsArrayName].controls[indexArr].get('profileImage').setErrors({ imageUploadFormat: true });
                if (itemsArrayName === 'ratingItemsArray') {
                  self.urlExistingImg[indexArr] = event.target.result;
                } else if (itemsArrayName === 'itemsAward') {
                  self.urlAwardImg[indexArr] = event.target.result;
                  self.awardValidation(indexArr);
                } else {
                  self.urlReviewImg[indexArr] = event.target.result;
                }
                const folderName = S3Buckets.ACCOUNT_S3 + '/';
                self.loaderNotify.emit(true);
                const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
                let imageKey = '';
                if (resImagePath.key) {
                  imageKey = resImagePath.key;
                } else {
                  imageKey = resImagePath.Key;
                }
                self.loaderNotify.emit(false);
                self[itemsArrayName].controls[indexArr].get('profileImage').setErrors(null);
                self[itemsArrayName].controls[indexArr].get('profileImage').markAsDirty();
                self[itemsArrayName].controls[indexArr].get('profileImageValue').setValue(imageKey);
              } else {
                if (itemsArrayName === 'ratingItemsArray') {
                  self.urlExistingImg.splice(indexArr, 1);
                } else if (itemsArrayName === 'itemsAward') {
                  self.urlAwardImg.splice(indexArr, 1);
                } else {
                  self.urlReviewImg.splice(indexArr, 1);
                }
                self[itemsArrayName].controls[indexArr].get('profileImage').setErrors({ imageUploadFailure: false });
              }
            };
          };
          reader.readAsDataURL(e.target.files[0]);
        } else {
          this[itemsArrayName].controls[indexArr].get('profileImage').setErrors({ imageSize: false });
        }
      } else {
        this[itemsArrayName].controls[indexArr].get('profileImage').setErrors({ imageUploadFormat: false });
      }
    }
  }

  setRequiredData(_productGroups: Array<ProductGroup>, _productCategories: Array<ProductCategory>, _brands: Array<Brand>) {
    this.productGroups = _productGroups;
    this.productCategoriesSource = _productCategories;
    this.brands = _brands;
    // urlReviewImg: Array<any>;
    // reviewRating: Array<any>;
  }

  setShareTypeList(response): void {
    const _shareTypes = <Array<ShareType>>(response.json());
    this.shareTypes = _shareTypes.filter(res => res.sharetype === ChannelType.DISTRIBUTOR
      || res.sharetype === ChannelType.RETAILER);
  }

  onShareTypeChanged(shareType: string, isChecked: boolean) {
    this.shareTypes.find(item => item.sharetype === shareType).isChecked = !isChecked;
    if (this.shareTypes.filter(item => item.isChecked === true).length > 0) {
      this.msg_code_ShareType = '';
    } else {
      this.msg_code_ShareType = '0006';
    }
  }

  onFreeSubscriptionChange() {
    this.isshowtofreesub = this.isshowtofreesub === '1' ? '0' : '1';
  }

  getBasicInfo(): ProductBasicInfoAdd {
    const productBasicInfoAdd = new ProductBasicInfoAdd();
    productBasicInfoAdd.productname = this.basicInfoGroup.value.productname;
    // tslint:disable-next-line:triple-equals
    productBasicInfoAdd.productstatus = this.basicInfoGroup.value.productstatus == true ? '1' : '0';
    productBasicInfoAdd.productgroup = parseInt(this.basicInfoGroup.value.productgroup, 10);
    productBasicInfoAdd.productcategory = parseInt(this.basicInfoGroup.value.productcategory, 10);
    productBasicInfoAdd.productbrand = parseInt(this.basicInfoGroup.value.productbrand, 10);
    productBasicInfoAdd.productdesc = this.basicInfoGroup.value.productdesc;
    productBasicInfoAdd.productusp = this.basicInfoGroup.value.productusp;
    if (this.productTags && this.productTags.length > 0) {
      productBasicInfoAdd.producttag = this.productTags;
    }

    return productBasicInfoAdd;
  }

  getArticlesReviews(): ProductArticleReview {
    const reviewItemsArray: FormArray = this.articleReview.get('reviewItemsArray') as FormArray;
    const ratingItemsArray: FormArray = this.articleReview.get('ratingItemsArray') as FormArray;
    const productArticleReview = new ProductArticleReview();
    productArticleReview.review = new Array<Review>();
    productArticleReview.productexistingrating = new Array<Productexistingrating>();
    for (let i = 0; i < reviewItemsArray.controls.length; i++) {
      const tempFormGroup = reviewItemsArray.controls[i] as FormGroup;
      const name = tempFormGroup.controls['name'].value;
      const profileImage = tempFormGroup.controls['profileImageValue'].value;
      const url = tempFormGroup.controls['url'].value;
      const review = new Review();

      if (this.actionType === ActionType.UPDATE && tempFormGroup.controls['productarticlereviewid']
        && tempFormGroup.controls['productarticlereviewid'].value) {
        if (tempFormGroup.dirty) {
          review.reviewername = name;
          review.articleurl = this.urlFormatting(url.toString());
          review.productarticlereviewid = parseInt(tempFormGroup.controls['productarticlereviewid'].value, 10);
          if (tempFormGroup.controls['profileImage'].dirty) {
            if (tempFormGroup.controls['imageid'] && tempFormGroup.controls['imageid'].value) {
              review.imageid = parseInt(tempFormGroup.controls['imageid'].value, 10);
              review.logo = profileImage;
            } else {
              if (profileImage) {
                review.logo = profileImage;
              }
            }
          }

          productArticleReview.review.push(review);
        }
      } else {
        if (name && url) {
          review.reviewername = name;
          review.articleurl = this.urlFormatting(url.toString());
          if (profileImage) {
            review.logo = profileImage;
          }
          productArticleReview.review.push(review);
        }
      }
    }

    for (let i = 0; i < ratingItemsArray.controls.length; i++) {
      const tempFormGroup = ratingItemsArray.controls[i] as FormGroup;
      const name = tempFormGroup.controls['name'].value;
      const url = tempFormGroup.controls['url'].value;
      const logoname = tempFormGroup.controls['sitename'].value;
      const logoIcon = tempFormGroup.controls['profileImageValue'].value;

      const productexistingrating = new Productexistingrating();

      if (this.actionType === ActionType.UPDATE && tempFormGroup.controls['productexistratingid']
        && tempFormGroup.controls['productexistratingid'].value) {
        if (tempFormGroup.dirty) {
          if (name) {
            productexistingrating.existproductrating = parseInt(name.toString(), 10);
          }

          if (url) {
            productexistingrating.ratingproofvalidationurl = this.urlFormatting(url.toString());
          }

          if (logoname) {
            productexistingrating.ratingproofvalidationname = logoname.toString();
          }

          if (tempFormGroup.controls['profileImage'].dirty) {
            if (tempFormGroup.controls['imageid'] && tempFormGroup.controls['imageid'].value) {
              productexistingrating.ratingproofvalidationlogo = logoIcon.toString();
              productexistingrating.ratingproofvalidationlogoid = parseInt(tempFormGroup.controls['imageid'].value, 10);
            } else {
              if (logoIcon) {
                productexistingrating.ratingproofvalidationlogo = logoIcon.toString();
              }
            }
          }

          productexistingrating.productexistratingid = parseInt(tempFormGroup.controls['productexistratingid'].value, 10);
          productArticleReview.productexistingrating.push(productexistingrating);
        }
      } else {
        let count = 0;
        if (name) {
          ++count;
          productexistingrating.existproductrating = parseInt(name.toString(), 10);
        }

        if (url) {
          ++count;
          productexistingrating.ratingproofvalidationurl = this.urlFormatting(url.toString());
        }

        if (logoname) {
          ++count;
          productexistingrating.ratingproofvalidationname = logoname.toString();
        }

        if (logoIcon) {
          ++count;
          productexistingrating.ratingproofvalidationlogo = logoIcon.toString();
        }

        if (count > 0) {
          productArticleReview.productexistingrating.push(productexistingrating);
        }
      }
    }

    return productArticleReview;
  }

  addOrRemoveValidationForRating(index) {
    const urlCtrl = this.ratingItemsArray.controls[index].get('url');
    const nameCtrl = this.ratingItemsArray.controls[index].get('name');
    const logoName = this.ratingItemsArray.controls[index].get('sitename');
    // const logoIcon = this.ratingItemsArray.controls[index].get('profileImage');
    const logoIconValue = this.ratingItemsArray.controls[index].get('profileImage');
    if (!urlCtrl.value && !nameCtrl.value && !logoName.value && !logoIconValue.value) {
      urlCtrl.clearValidators();
      urlCtrl.setErrors(null);
      nameCtrl.clearValidators();
      nameCtrl.setErrors(null);
      logoName.clearValidators();
      logoName.setErrors(null);
      // logoIcon.clearValidators();
      // logoIcon.setErrors(null);
    } else {
      urlCtrl.setValidators([
        Validators.required, Validators.maxLength(255),
        //  Validators.pattern(this.config.urlPattern)
      ]);
      urlCtrl.setValue(urlCtrl.value);
      urlCtrl.markAsTouched();
      nameCtrl.setValidators([
        Validators.required]);
      if (!nameCtrl.value || nameCtrl.value === 0) {
        nameCtrl.setValue('');
      }
      nameCtrl.markAsTouched();
      logoName.setValidators([
        Validators.required]);
      logoName.setValue(logoName.value);
      logoName.markAsTouched();
      // logoIcon.setValidators([
      //   Validators.required]);
      // if (!logoIcon.value) {
      //   logoIcon.setErrors({ required: true });
      // }
      // logoIcon.markAsTouched();
    }
  }

  getProductImages(): ProductImages {
    // this.productImages.videourl = this.videoUrl;
    this.productImages.videourl = this.urlFormatting(this.videoUrl);
    return this.productImages;
  }

  getProductBrochure(): ProductBrochure {
    return this.productBrochure;
  }

  getProductPreferences(): ProductPreferences {
    const productPreferences = new ProductPreferences();
    productPreferences.isshowtofreesub = this.isshowtofreesub;
    productPreferences.preferences = new Array<Preference>();
    // this.shareTypes = this.shareTypes.filter(item => item.isChecked === true);
    const shareTypesConst = <Array<ShareType>>(this.shareTypes.filter(item => item.isChecked === true));

    for (let i = 0; i < shareTypesConst.length; i++) {
      const preference = new Preference();
      preference.sharetypeid = parseInt(shareTypesConst[i].sharetypeid, 10);
      productPreferences.preferences.push(preference);
    }

    return productPreferences;
  }

  // Get Award Details while Submitting Data
  getAwardDetailRecords() {
    const awardDetails = new Array<AwardDetail>();
    // (this.itemsAward.value as Array<AwardDetail>).forEach(item => {
    //   if (item.details || item.issued_by) {
    //     if (item.valid_upto) {
    //       item.valid_upto = moment(item.valid_upto, 'YYYY/MM/DD').toDate();
    //     }
    //     awardDetails.push(item);
    //   }
    // });
    const itemsAwardArray: FormArray = this.awardDetailGroup.get('itemsAward') as FormArray;
    for (let i = 0; i < itemsAwardArray.controls.length; i++) {
      const tempFormGroup = itemsAwardArray.controls[i] as FormGroup;
      const details = tempFormGroup.controls['details'].value;
      const profileImage = tempFormGroup.controls['profileImageValue'].value;
      const isLifeTime = tempFormGroup.controls['isLifeTime'].value;
      const issued_by = tempFormGroup.controls['issued_by'].value;
      let valid_upto = tempFormGroup.controls['valid_upto'].value;
      const award = new AwardDetail();
      if (details || issued_by) {
        if (valid_upto) {
          valid_upto = moment(valid_upto, 'YYYY/MM/DD').toDate();
        }
      }
      if (this.actionType === ActionType.UPDATE && tempFormGroup.controls['product_award_id']
        && tempFormGroup.controls['product_award_id'].value) {
        // if (tempFormGroup.dirty || tempFormGroup.touched) {
          award.details = details;
          award.isLifeTime = isLifeTime;
          award.issued_by = issued_by;
          award.valid_upto = valid_upto;
          award.product_award_id = parseInt(tempFormGroup.controls['product_award_id'].value, 10);
          // if (tempFormGroup.controls['profileImage'].dirty) {
          if (tempFormGroup.controls['imageid'] && tempFormGroup.controls['imageid'].value) {
            award.imageId = parseInt(tempFormGroup.controls['imageid'].value, 10);
            if (profileImage) {
              award.image = profileImage;
            }
          } else {
            if (profileImage) {
              award.image = profileImage;
            }
          }
          // }
          awardDetails.push(award);
        // }
      } else {
        if (details || issued_by) {
          award.details = details;
          award.isLifeTime = isLifeTime;
          award.issued_by = issued_by;
          award.valid_upto = valid_upto;
          if (profileImage) {
            award.image = profileImage;
          }
          awardDetails.push(award);
        }
      }
    }
    return awardDetails;
  }

  preFilllBasicInfo(productName: string, productGroupId: string, productCategorieId,
    brandId: string, isactive: string, productdesc: string, usp: string, _productTags: Producttag[]) {
    this.productNameCtrl.setValue(this.actionType === ActionType.COPYORDUPLICATE ? productName + ' - Copy' : productName);
    this.productstatusCtrl.setValue(isactive === '1' ? true : false);
    this.productGroupCtrl.setValue(productGroupId);
    this.onProductGroupChange(productGroupId);
    this.productCategoryCtrl.setValue(productCategorieId);
    this.brandsCtrl.setValue(brandId);
    this.productDescriptionCtrl.setValue(productdesc);
    this.uspCtrl.setValue(usp);
    this.productnameElement.nativeElement.focus();
    _productTags.forEach(result => {
      if (this.actionType === ActionType.UPDATE) {
        this.productTags.push({ 'producttagid': parseInt(result.producttagid.toString(), 10), 'tag': result.tag });
      } else {
        this.productTags.push({ 'tag': result.tag });
      }
    });
  }

  preFillArticlesAndReviews(productArticleReviews: ProductArticleReviewGet[], productExistRatings: ProductExistRatingGet[]) {
    if (productArticleReviews && productArticleReviews.length > 0) {
      this.reviewItemsArray.removeAt(0);
      for (let i = 0; i < productArticleReviews.length; i++) {
        productArticleReviews[i].articleurl = this.removeUrlFormat(productArticleReviews[i].articleurl);

        if (this.actionType !== ActionType.ADD) {
          const productReviewId = parseInt(productArticleReviews[i].productarticlereviewid, 10);
          const _reviewmagazinelogoid = productArticleReviews[i].reviewmagazinelogoid ?
            parseInt(productArticleReviews[i].reviewmagazinelogoid, 10) : 0;

          const reviewMagazineLogo = productArticleReviews[i].reviewmagazinelogo && productArticleReviews[i].reviewmagazinelogo.documentUrl
            ? productArticleReviews[i].reviewmagazinelogo.documentUrl : '';

          this.addItem(productArticleReviews[i].productreviewername,
            productArticleReviews[i].articleurl,
            reviewMagazineLogo,
            _reviewmagazinelogoid,
            productReviewId
          );

          if (this.actionType === ActionType.UPDATE) {
            this.urlReviewImg[i] = productArticleReviews[i].reviewmagazinelogo && productArticleReviews[i].reviewmagazinelogo.documentUrl ?
              productArticleReviews[i].reviewmagazinelogo.documentUrl : '';
          }

        } else {
          this.addItem(productArticleReviews[i].productreviewername, productArticleReviews[i].articleurl,
            '', 0, 0);
        }
      }
    }

    if (productExistRatings && productExistRatings.length > 0) {
      this.ratingItemsArray.removeAt(0);
      for (let i = 0; i < productExistRatings.length; i++) {
        productExistRatings[i].ratingproofvalidationurl = this.removeUrlFormat(productExistRatings[i].ratingproofvalidationurl);
        if (this.actionType !== ActionType.ADD) {
          const logoID = productExistRatings[i].ratingproofvalidationlogoid ?
            parseInt(productExistRatings[i].ratingproofvalidationlogoid.toString(), 10) : 0;
          const ratingId = parseInt(productExistRatings[i].productexistratingid, 10);
          this.addRatingItem(productExistRatings[i].existproductrating.toString(),
            productExistRatings[i].ratingproofvalidationname ? productExistRatings[i].ratingproofvalidationname.toString() : '',
            productExistRatings[i].ratingproofvalidationurl,
            productExistRatings[i].ratingproofvalidationlogo ? productExistRatings[i].ratingproofvalidationlogo.documentUrl : '',
            logoID
            , ratingId);
          this.reviewRating[i] = productExistRatings[i].existproductrating;
          if (this.actionType === ActionType.UPDATE) {
            this.urlExistingImg[i] = productExistRatings[i].ratingproofvalidationlogo ?
              productExistRatings[i].ratingproofvalidationlogo.documentUrl : '';
          }
        } else {
          this.addRatingItem(productExistRatings[i].existproductrating.toString(),
            productExistRatings[i].ratingproofvalidationname.toString(),
            productExistRatings[i].ratingproofvalidationurl, '', 0, 0);
        }
      }
    }
  }

  // Pre fill the award details
  preFillproductAwards(awardDetails: ProductAwards[]) {
    this.itemsAward.removeAt(0);
    for (let i = 0; i < awardDetails.length; i++) {
      const awardId = parseInt(awardDetails[i].productAwardId, 10);
      const logoID = awardDetails[i].documentId ?
        parseInt(awardDetails[i].documentId.toString(), 10) : 0;
      if (this.actionType !== ActionType.ADD) {
        const documentUrlAward = awardDetails[i].document && awardDetails[i].document.documentUrl ?
          awardDetails[i].document.documentUrl : '';
        this.urlAwardImg[i] = documentUrlAward;
        this.addItemAward(awardDetails[i].awardDetail, awardDetails[i].issuedBy, awardId
          , awardDetails[i].validUpto,
          awardDetails[i].isLifeTime, documentUrlAward, logoID);
      } else {
        this.addItemAward(awardDetails[i].awardDetail, awardDetails[i].issuedBy, awardId
          , awardDetails[i].validUpto,
          awardDetails[i].isLifeTime, '', 0);
      }
    }
  }

  preFillProductPreferences(productSharePreferences: ProductSharePreference[], _isshowtofreesub: string) {
    if (productSharePreferences && productSharePreferences.length > 0) {
      this.shareTypes.forEach(shareTypeItem => {
        productSharePreferences.forEach(item => {
          if (shareTypeItem.sharetypeid === item.sharetypeid) {
            shareTypeItem.isChecked = true;
          }
        });
      });
    }

    this.isshowtofreesub = _isshowtofreesub;
  }

  checkValidate() {
    let checkFlag = true;
    this.markFormGroupTouched(this.basicInfoGroup);
    this.productDescContentChange();
    this.productUspContentChange();

    if (!this.scrollToElementId) {
      if (this.productdescErrCode) {
        checkFlag = false;
        this.scrollToElementId = 'productDescriptionId';
      } else if (this.productuspErrCode) {
        checkFlag = false;
        this.scrollToElementId = 'productuspId';
      }
    }

    // if (this.productTags && this.productTags.length > 0) {
    //   this.msg_code_ProductTags = '';
    // } else {
    //   this.msg_code_ProductTags = '0001';

    //   if (this.scrollToElementId.length === 0) {
    //     this.scrollToElementId = 'productTagId';
    //   }
    //   checkFlag = false;
    // }

    this.markFormArrayTouched(this.reviewItemsArray);

    this.ratingItemsArray.controls.forEach(item => {
      const formgroup = item as FormGroup;
      if (formgroup.controls['name'] && formgroup.controls['name'].value === 0) {
        formgroup.controls['name'].setValue(null);
      }
    });

    this.markFormArrayTouched(this.ratingItemsArray);
    this.validateFormArray();
    if (this.actionType === ActionType.UPDATE) {
      if (this.productImages && this.productImages.productimage && this.productImages.productimage.length > 0) {
        this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '';
      } else {
        if (this.productImagePrefillInput && this.productImagePrefillInput.length > 0) {
          this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '';
        } else {
          this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '0001';
          if (this.scrollToElementId.length === 0) {
            this.scrollToElementId = 'productImagesId';
          }
        }
      }

      // DISPLAY images are not mandatory Task #52425
      this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '';
      // if (this.productImages && this.productImages.productdisplayimage && this.productImages.productdisplayimage.length > 0) {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '';
      // } else {
      //   if (this.productDisplayImagePrefillInput && this.productDisplayImagePrefillInput.length > 0) {
      //     this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '';
      //   } else {
      //     this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '0001';
      //     if (this.scrollToElementId.length === 0) {
      //       this.scrollToElementId = 'productDisplayId';
      //     }
      //   }
      // }

      if (this.productImages && this.productImages.productpackagingimage && this.productImages.productpackagingimage.length > 0) {
        this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '';
      } else {
        if (this.productPackageImagePrefillInput && this.productPackageImagePrefillInput.length > 0) {
          this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '';
        } else {
          this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '0001';
          if (this.scrollToElementId.length === 0) {
            this.scrollToElementId = 'productPackagingId';
          }
        }
      }

      this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      // if (this.productBrochure && this.productBrochure.productpdf && this.productBrochure.productpdf.length > 0) {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      // } else {
      //   if (this.productBrouchurePrefillInput && this.productBrouchurePrefillInput.length > 0) {
      //     this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      //   } else {
      //     this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '0001';
      //     if (this.scrollToElementId.length === 0) {
      //       this.scrollToElementId = 'broucherId';
      //     }
      //   }
      // }
    } else {
      if (this.productImages && this.productImages.productimage && this.productImages.productimage.length > 0) {
        this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '';
      } else {
        this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '0001';
        if (this.scrollToElementId.length === 0) {
          this.scrollToElementId = 'productImagesId';
        }
      }

      // if (this.productImages && this.productImages.productdisplayimage && this.productImages.productdisplayimage.length > 0) {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '';
      // } else {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '0001';
      //   if (this.scrollToElementId.length === 0) {
      //     this.scrollToElementId = 'productDisplayId';
      //   }
      // }

      if (this.productImages && this.productImages.productpackagingimage && this.productImages.productpackagingimage.length > 0) {
        this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '';
      } else {
        this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '0001';
        if (this.scrollToElementId.length === 0) {
          this.scrollToElementId = 'productPackagingId';
        }
      }

      this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      // if (this.productBrochure && this.productBrochure.productpdf && this.productBrochure.productpdf.length > 0) {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      // } else {
      //   this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '0001';
      //   if (this.scrollToElementId.length === 0) {
      //     this.scrollToElementId = 'broucherId';
      //   }
      // }
    }

    if (this.shareTypes && this.shareTypes.filter(item => item.isChecked === true).length > 0) {
      this.msg_code_ShareType = '';
    } else {
      this.msg_code_ShareType = '0006';
      if (this.scrollToElementId.length === 0) {
        this.scrollToElementId = 'productVisibilityId';
      }
    }
    if (this.videoUrl && this.videoUrl.trim() === ''
      // && !this.videoUrl.match(this.config.urlPattern)
    ) {
      this.msg_code_videoURL = '0001';
      if (this.scrollToElementId.length === 0) {
        this.scrollToElementId = 'videoLinkId';
      }
      checkFlag = false;
    } else {
      this.msg_code_videoURL = '';
    }

    if (this.awardDetailGroup.invalid || this.basicInfoGroup.invalid || this.articleReview.invalid
      || this.msg_code_arr[1] !== '' || this.msg_code_arr[2] !== ''
      || this.msg_code_arr[3] !== '' || this.msg_code_arr[4] !== '' || this.msg_code_ShareType !== '') {
      checkFlag = false;
    }

    if (this.itemsAward.invalid) {
      this.scrollToElementId = 'itemsAwardId';
    }

    if (this.scrollToElementId.length > 0) {
      this.scrollToElement();
    }

    return checkFlag;
  }

  markFormGroupTouched(formGroup) {
    const keys = Object.keys(formGroup.controls);
    let count = 0;
    keys.forEach(val => {
      const ctrl = formGroup.controls[val];
      if (!ctrl.valid) {
        ctrl.markAsTouched();
        if (count === 0) {
          this.scrollToElementId = val + 'Id';
        }
        ++count;
      }
    });
  }

  // markFormArrayTouchedNew(formarrray) {
  //   if (formarrray.controls.length) {
  //     // console.log("Control: ", formarrray.controls.length);
  //     // (<any>Object).values(formarrray.controls).forEach(control => {
  //     // formarrray.controls.forEach(control => {
  //     formarrray.controls.forEach(control => {
  //       if (control) { // control is a FormGroup
  //         // const keys = Object.keys(control.controls);
  //         this.markFormArrayTouched(control);
  //       } else { // control is a FormControl
  //         control.markAsTouched();
  //       }
  //     });
  //   }
  // }

  markFormArrayTouched(formarrray) {
    if (formarrray && formarrray.controls) {
      if (formarrray.controls.length) {
        formarrray.controls.forEach(control => {
          if (control) { // control is a FormGroup
            this.markFormArrayTouched(control);
          } else { // control is a FormControl
            control.markAsTouched();
          }
        });
      } else {
        const keys = Object.keys(formarrray.controls);
        keys.forEach(val => {
          const ctrl = formarrray.controls[val];
          if (!ctrl.valid) {
            ctrl.markAsTouched();
          }
        });
      }
    }
  }

  validateFormArray() {
    this.reviewItemsArray.markAsTouched();
    if (this.reviewItemsArray.invalid && this.scrollToElementId.length === 0) {
      this.scrollToElementId = 'reviewItemsArrayId';
    }

    this.ratingItemsArray.markAsTouched();
    if (this.ratingItemsArray.invalid && this.scrollToElementId.length === 0) {
      this.scrollToElementId = 'ratingItemsArrayId';
    }

    // this.reviewItemsArray.controls.forEach(item => {
    //   item.markAsTouched();
    // });
  }

  onVideoUrlChange(event) {
    this.videoUrl = event;
    if (this.videoUrl.length > 0) {
      // if (!this.videoUrl.match(this.config.urlPattern)) {
      //   this.msg_code_videoURL = '0002';
      // } else {
      //   this.msg_code_videoURL = '';
      // }
    } else {
      this.msg_code_videoURL = '0001';
    }
  }

  preFillImagesAndBrouchures(imageGet: ImagesGet, _videoUrl: string = '') {
    this.videoUrl = this.removeUrlFormat(_videoUrl);

    if (imageGet && imageGet.PRODUCT && imageGet.PRODUCT.length > 0) {
      const _productImagePrefillInput = new Array<FileUploadModel>();
      imageGet.PRODUCT.forEach(result => {
        const fileModel = new FileUploadModel();
        fileModel.fileId = parseInt(result.productimageid, 10);
        fileModel.fileUrl = result.image.documentUrl;
        _productImagePrefillInput.push(fileModel);
      });
      this.productImagePrefillInput = _productImagePrefillInput;
    }

    if (imageGet && imageGet.DISPLAY && imageGet.DISPLAY.length > 0) {
      const _productDisplayImagePrefillInput = new Array<FileUploadModel>();
      imageGet.DISPLAY.forEach(result => {
        const fileModel = new FileUploadModel();
        fileModel.fileId = parseInt(result.productimageid, 10);
        fileModel.fileUrl = result.image.documentUrl;
        _productDisplayImagePrefillInput.push(fileModel);
      });
      this.productDisplayImagePrefillInput = _productDisplayImagePrefillInput;
    }

    if (imageGet && imageGet.PACKING && imageGet.PACKING.length > 0) {
      const _productPackageImagePrefillInput = new Array<FileUploadModel>();
      imageGet.PACKING.forEach(result => {
        const fileModel = new FileUploadModel();
        fileModel.fileId = parseInt(result.productimageid, 10);
        fileModel.fileUrl = result.image.documentUrl;
        _productPackageImagePrefillInput.push(fileModel);
      });
      this.productPackageImagePrefillInput = _productPackageImagePrefillInput;
    }

    if (imageGet && imageGet.BROUCHER && imageGet.BROUCHER.length > 0) {
      const _productBrouchurePrefillInput = new Array<FileUploadModel>();
      imageGet.BROUCHER.forEach(result => {
        const fileModel = new FileUploadModel();
        fileModel.fileId = parseInt(result.productimageid, 10);
        fileModel.fileUrl = result.image.documentUrl;
        _productBrouchurePrefillInput.push(fileModel);
      });
      this.productBrouchurePrefillInput = _productBrouchurePrefillInput;
    }
  }

  setRatingValidation() {
    this.ratingItemsArray.controls.forEach(item => {
      const name = (item as FormGroup).controls['name'] as FormControl;
      // const url = (item as FormGroup).controls['url'] as FormControl;

      if (name.value === null && !name.value) {
        name.setValidators([Validators.required]);
        name.setValue('');
        this.isRatingValidationSet = true;
      }
    });
  }

  removeRatingValidation() {
    this.ratingItemsArray.controls.forEach(item => {
      const name = (item as FormGroup).controls['name'] as FormControl;
      const url = (item as FormGroup).controls['url'] as FormControl;
      if (!name.value && !url.value) {
        name.clearValidators();
        name.setErrors(null);
        url.clearValidators();
        url.setErrors(null);
      }
    });
  }

  scrollToElement() {
    this.scrollService.scrollTo(document.getElementById(this.scrollToElementId), 1000, -100);
    this.scrollToElementId = '';
  }

  onProductFilesUploaded(event: MultipleFileUploadModel, uploadCategory: number) {
    this.setProductDetails(event, uploadCategory);
    this.loaderNotify.emit(false);
  }

  onProductFilesRemoved(event: MultipleFileUploadModel, uploadCategory: number) {
    this.setProductDetails(event, uploadCategory);
  }

  onProductFilesNotify(arg: MessageNotify, uploadCategory: number) {
    if (arg.code === UploadNotifyEnum.UploadedFailed) {
      this.msg_code_arr[uploadCategory] = '0004';
    } else if (arg.code === UploadNotifyEnum.MaximumReached) {
      this.msg_code_arr[uploadCategory] = '0005';
    } else if (arg.code === UploadNotifyEnum.FilesNotAllowed) {
      this.msg_code_arr[uploadCategory] = '0002';
    } else if (arg.code === UploadNotifyEnum.BeforeUpload) {
      this.msg_code_arr[uploadCategory] = '';
      this.loaderNotify.emit(true);
    } else if (arg.code === UploadNotifyEnum.FileSizeNotAllowed) {
      this.msg_code_arr[uploadCategory] = '0006';
    }
  }

  setProductDetails(event: MultipleFileUploadModel, uploadCategory: number) {
    if (uploadCategory === GeneralEnum.PRODUCT_IMAGES) {
      // this.msg_code_arr[this.generalEnum.PRODUCT_IMAGES] = '';
      if (event.removedItems && event.removedItems.length > 0) {
        delete this.deletedProductImage;
        this.deletedProductImage = Array<number>();
        event.removedItems.forEach(item => {
          this.deletedProductImage.push(item.fileId);
        });
      }

      delete this.productImages.productimage;
      this.productImages.productimage = new Array<Productimage>();
      event.source.forEach(item => {
        const productimage = new Productimage();
        if (item.fileUploadKey) {
          productimage.image = item.fileUploadKey;
        }

        if (item.fileId) {
          productimage.productimageid = item.fileId;
        }

        productimage.isdefault = item.isFirst ? '1' : '0';
        productimage.sortorder = item.sortOrder;
        this.productImages.productimage.push(productimage);
      });
    } else if (uploadCategory === GeneralEnum.PRODUCT_DISPLAY) {
      // this.msg_code_arr[this.generalEnum.PRODUCT_DISPLAY] = '';
      if (event.removedItems && event.removedItems.length > 0) {
        delete this.deletedProductDisplayimage;
        this.deletedProductDisplayimage = Array<number>();
        event.removedItems.forEach(item => {
          this.deletedProductDisplayimage.push(item.fileId);
        });
      }

      delete this.productImages.productdisplayimage;
      this.productImages.productdisplayimage = new Array<Productdisplayimage>();
      event.source.forEach(item => {
        const productimage = new Productdisplayimage();
        if (item.fileUploadKey) {
          productimage.image = item.fileUploadKey;
        }

        if (item.fileId) {
          productimage.productimageid = item.fileId;
        }

        productimage.isdefault = item.isFirst ? '1' : '0';
        productimage.sortorder = item.sortOrder;
        this.productImages.productdisplayimage.push(productimage);
      });
    } else if (uploadCategory === GeneralEnum.PRODUCT_PACKAGING) {
      // this.msg_code_arr[this.generalEnum.PRODUCT_PACKAGING] = '';
      if (event.removedItems && event.removedItems.length > 0) {
        delete this.deletedProductPackageImage;
        this.deletedProductPackageImage = Array<number>();
        event.removedItems.forEach(item => {
          this.deletedProductPackageImage.push(item.fileId);
        });
      }

      delete this.productImages.productpackagingimage;
      this.productImages.productpackagingimage = new Array<Productpackagingimage>();
      event.source.forEach(item => {
        const productimage = new Productpackagingimage();
        if (item.fileUploadKey) {
          productimage.image = item.fileUploadKey;
        }

        if (item.fileId) {
          productimage.productimageid = item.fileId;
        }

        productimage.isdefault = item.isFirst ? '1' : '0';
        productimage.sortorder = item.sortOrder;
        this.productImages.productpackagingimage.push(productimage);
      });
    } else if (uploadCategory === GeneralEnum.PRODUCT_Brouchures) {
      // this.msg_code_arr[this.generalEnum.PRODUCT_Brouchures] = '';
      if (event.removedItems && event.removedItems.length > 0) {
        delete this.deletedProductBrochure;
        this.deletedProductBrochure = Array<number>();
        event.removedItems.forEach(item => {
          this.deletedProductBrochure.push(item.fileId);
        });
      }

      delete this.productBrochure.productpdf;
      this.productBrochure.productpdf = new Array<Productpdf>();
      event.source.forEach(item => {
        const productimage = new Productpdf();
        if (item.fileUploadKey) {
          productimage.image = item.fileUploadKey;
        }

        if (item.fileId) {
          productimage.productimageid = item.fileId;
        }

        productimage.isdefault = item.isFirst ? '1' : '0';
        productimage.sortorder = item.sortOrder;
        this.productBrochure.productpdf.push(productimage);
      });
    }
  }

  productDescContentChange() {
    const htmlContent = this.basicInfoGroup.controls['productdesc'].value;
    if (htmlContent === null || htmlContent.length === 0) {
      this.productdescErrCode = '0001';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length < this.productDescMinLength) {
      this.productdescErrCode = '0002';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length > this.productDescMaxLength) {
      this.productuspErrCode = '0003';
    } else {
      this.productdescErrCode = '';
    }
  }

  productUspContentChange() {
    const htmlContent = this.basicInfoGroup.controls['productusp'].value;
    if (htmlContent === null || htmlContent.length === 0) {
      this.productuspErrCode = '0001';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length < this.uspMinLength) {
      this.productuspErrCode = '0002';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length > this.uspMaxLength) {
      this.productuspErrCode = '0003';
    } else {
      this.productuspErrCode = '';
    }
  }

  // Award Validation Function
  awardValidation(index) {
    const details = this.itemsAward.controls[index].get('details');
    const issuedby = this.itemsAward.controls[index].get('issued_by');
    const islifetime = this.itemsAward.controls[index].get('isLifeTime');
    const validupto = this.itemsAward.controls[index].get('valid_upto');
    if (details.value !== '' && issuedby.value !== '' && islifetime.value === '0'
      && validupto.value !== null && this.urlAwardImg[index] !== '') {
      details.clearValidators();
      details.setErrors(null);
      issuedby.clearValidators();
      issuedby.setErrors(null);
      islifetime.clearValidators();
      islifetime.setErrors(null);
      validupto.clearValidators();
      validupto.setErrors(null);
    } else {
      details.setValidators([
        Validators.required, Validators.minLength(3), Validators.maxLength(254)]);
      details.setValue(details.value);
      details.markAsTouched();
      issuedby.setValidators([
        Validators.required, Validators.minLength(3), Validators.maxLength(254)]);
      issuedby.setValue(issuedby.value);
      issuedby.markAsTouched();
      if (islifetime.value === '0') {
        validupto.setValidators([
          Validators.required]);
        validupto.setValue(validupto.value);
        validupto.markAsTouched();
      } else {
        validupto.clearValidators();
        validupto.setErrors(null);
      }
    }
  }

  LifeTimeToogle(index: number) {
    if (this.itemsAward.controls[index].get('isLifeTime').value === '1') {
      this.itemsAward.controls[index].get('isLifeTime').setValue('0');
    } else {
      this.itemsAward.controls[index].get('isLifeTime').setValue('1');
      this.itemsAward.controls[index].get('valid_upto').setValue(null);
    }
  }

  public urlFormatting(unFormattedUrl) {
    if (unFormattedUrl) {
      if (unFormattedUrl.indexOf('http')) {
        return '//' + unFormattedUrl;
      } else {
        return unFormattedUrl;
      }
    } else {
      return unFormattedUrl;
    }
  }

  public removeUrlFormat(url) {
    let temp_sourceurl = '';
    if (url) {
      temp_sourceurl = url;
      while (temp_sourceurl.charAt(0) === '/') {
        temp_sourceurl = temp_sourceurl.substring(2);
      }
    }

    return temp_sourceurl;
  }

  authorizeVideoUrl() {
    // this.loaderNotify.emit(true);
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.PRODUCT_VIDEO_BY_SHEET).then(item => {
      // this.loaderNotify.emit(false);
      this.isvideoUrlAuthorized = item;
    });
  }

  authorizeProductImage() {
    // this.loaderNotify.emit(true);
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.PRODUCT_IMAGE_BY_SHEET).then(item => {
      // this.loaderNotify.emit(false);
      if (item) {
        const imageCount = parseInt(item, 10);
        if (imageCount % 3 === 0) {
          const dataToFill = imageCount / 3;
          this.productImagesMaxLimit = dataToFill;
          this.productDisplayImagesMaxLimit = dataToFill;
          this.productPackagingImagesMaxLimit = dataToFill;
        }
      }
    });
  }

  addOrRemoveValidationForReviews(index) {
    const urlCtrl = this.reviewItemsArray.controls[index].get('url');
    const nameCtrl = this.reviewItemsArray.controls[index].get('name');
    const profileImageCtrl = this.reviewItemsArray.controls[index].get('profileImage');

    if (!urlCtrl.value && !nameCtrl.value && !profileImageCtrl.value) {
      urlCtrl.clearValidators();
      urlCtrl.setErrors(null);
      nameCtrl.clearValidators();
      nameCtrl.setErrors(null);
    } else {
      urlCtrl.setValidators([
        Validators.required, Validators.maxLength(255),
        //  Validators.pattern(this.config.urlPattern)
      ]);
      urlCtrl.setValue(urlCtrl.value);
      urlCtrl.markAsTouched();
      nameCtrl.setValidators([
        Validators.required]);
      if (!nameCtrl.value || nameCtrl.value === 0) {
        nameCtrl.setValue('');
      }
      nameCtrl.markAsTouched();
    }
  }

  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }
}
