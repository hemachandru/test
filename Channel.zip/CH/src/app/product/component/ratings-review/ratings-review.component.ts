import { Component, OnInit, Input } from '@angular/core';
import { ProductRootObject } from '@app/product/models/product-view';

@Component({
  selector: 'app-ratings-review',
  templateUrl: './ratings-review.component.html',
  styleUrls: ['./ratings-review.component.scss']
})

export class RatingsReviewComponent implements OnInit {
  _ProductRootObject: ProductRootObject;

  constructor() {
    this._ProductRootObject = new ProductRootObject();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  ngOnInit() {
  }

}
