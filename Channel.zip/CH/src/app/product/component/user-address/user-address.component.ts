import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActionType, Config, AddressType } from '@app/config/constant';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { CountryMaster, UserActionModel } from '@app/shared/models/shared-model';
import { AddressGet, AddressBookAdd } from '../../models/address-book';
import { ProductService } from '@app/product/service/product-service.service';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-user-address',
  templateUrl: './user-address.component.html',
  styleUrls: ['./user-address.component.scss']
})
export class UserAddressComponent implements OnInit, AfterViewInit {
  addressBookData = new AddressBookAdd();
  @Input() public type: number;
  nameCtrl: FormControl;
  primary_contactnoCtrl: FormControl;
  alternative_contactnoCtrl: FormControl;
  addressCtrl: FormControl;
  countryIdCtrl: FormControl;
  postalCodeCtrl: FormControl;
  cityCtrl: FormControl;
  addressGroup: FormGroup;
  countryMasterList: Array<CountryMaster>;
  @Output()
  submit: EventEmitter<any> = new EventEmitter();

  @Output()
  beforeSubmit: EventEmitter<any> = new EventEmitter();

  @Output()
  cancel: EventEmitter<any> = new EventEmitter();

  @Output()
  prefilled: EventEmitter<any> = new EventEmitter();

  @Output()
  componentLoaded: EventEmitter<any> = new EventEmitter();

  addressid: string;

  savebtnName = ' shared.buttonLabels.save';

  // _addressDetail: AddressGet;
  @Input() addressDetail: AddressGet;
  primaryPhoneCodeCtrl: FormControl;
  alternativePhoneCodeCtrl: FormControl;
  updateAddressToastMsg: any;
  addAddressToastMsg: any;
  // @Input() set addressDetail(value: AddressGet) {
  //   if (value) {
  //     this.setFormData(this.addressDetail);
  //   }
  // }

  private isLoadedFirstTime = true;
  constructor(private productService: ProductService, private constant: Config,
    private toastr: ToastrService, private translate: TranslateService, public sharedBusiness: SharedBusiness) { }

  ngOnInit() {
    this.initializeAddressGroup();
    this.getCountryList();
  }

  ngAfterViewInit(): void {
    if (this.addressDetail) {
      if (this.addressDetail.addressid) {
        this.savebtnName = 'shared.buttonLabels.update';
      } else {
        this.savebtnName = 'shared.buttonLabels.save';
      }

      this.setFormData(this.addressDetail);
    } else {
      this.savebtnName = 'shared.buttonLabels.save';
      const returnData = <UserActionModel>{
        'type': this.type,
        'action': ActionType.ADD
      };
      this.componentLoaded.emit(returnData);
    }
  }

  initializeAddressGroup() {
    this.nameCtrl = new FormControl('', Validators.compose([Validators.required]));

    this.primaryPhoneCodeCtrl = new FormControl('', Validators.compose([
      Validators.pattern(this.constant.phoneCodeWithPlus), Validators.minLength(1),
      Validators.maxLength(6)]));

    this.primary_contactnoCtrl = new FormControl('', Validators.compose([Validators.required,
      Validators.pattern(this.constant.phoneCodeWithOutPlus), Validators.minLength(4),
      Validators.maxLength(20)]));

    this.alternativePhoneCodeCtrl = new FormControl('', Validators.compose
      ([Validators.pattern(this.constant.phoneCodeWithPlus), Validators.minLength(1),
      Validators.maxLength(6)]));
    this.alternative_contactnoCtrl = new FormControl('', Validators.compose([Validators.pattern(this.constant.phoneCodeWithOutPlus),
      Validators.minLength(4),
      Validators.maxLength(20)]));

    this.countryIdCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.postalCodeCtrl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(3),
    Validators.maxLength(12)]));
    this.cityCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.addressCtrl = new FormControl('', Validators.compose([Validators.required, Validators.maxLength(255)]));

    this.addressGroup = new FormGroup({
      name: this.nameCtrl,
      primary_phone_code: this.primaryPhoneCodeCtrl,
      primary_contactno: this.primary_contactnoCtrl,
      alternative_phone_code: this.alternativePhoneCodeCtrl,
      alternative_contactno: this.alternative_contactnoCtrl,
      address: this.addressCtrl,
      countryId: this.countryIdCtrl,
      postalCode: this.postalCodeCtrl,
      city: this.cityCtrl,
    });
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      if (data) {
        this.countryMasterList = data;
        this.countryChange();
      }
    });
  }

  setAddressGroup() {

  }

  countryChange() {
    if (this.countryIdCtrl.value && this.countryMasterList && this.countryMasterList.length > 0) {
      // tslint:disable-next-line:triple-equals
      const selectedDetail = this.countryMasterList.filter(item => item.countryId == this.countryIdCtrl.value)[0];
      if (!(this.isLoadedFirstTime && this.primaryPhoneCodeCtrl.value)) {
        this.primaryPhoneCodeCtrl.setValue(selectedDetail.phoneCode);
      }

      if (!(this.isLoadedFirstTime && this.alternativePhoneCodeCtrl.value)) {
        this.alternativePhoneCodeCtrl.setValue(selectedDetail.phoneCode);
      }
    }

    this.isLoadedFirstTime = false;
  }

  onSave() {
    if (this.addressGroup.valid) {
      const data = this.addressGroup.value as AddressBookAdd;
      if (this.type === AddressType.BILLING) {
        data.isbillingaddress = true;
        data.isshippingaddress = false;
        this.updateAddressToastMsg = this.translate.instant('checkOut.updateBillingAddressMsg');
        this.addAddressToastMsg = this.translate.instant('checkOut.addBillingAddressMsg');
      } else {
        data.isbillingaddress = false;
        data.isshippingaddress = true;
        this.updateAddressToastMsg = this.translate.instant('checkOut.updateShippingAddressMsg');
        this.addAddressToastMsg = this.translate.instant('checkOut.addShippingAddressMSg');
      }
      if (!data.alternative_contactno || data.alternative_contactno.toString().trim() === '') {
        delete data.alternative_contactno;
      }

      data.countryId = parseInt(data.countryId.toString(), 10);
      this.beforeSubmit.emit(true);

      this.addressBookData = data;
      this.addressBookData.primary_contactno = data.primary_phone_code + '-' + data.primary_contactno;
      if (data.alternative_contactno) {
        this.addressBookData.alternative_contactno = data.alternative_phone_code + '-' + data.alternative_contactno;
      }

      delete this.addressBookData.primary_phone_code;
      delete this.addressBookData.alternative_phone_code;
      if (this.savebtnName === 'shared.buttonLabels.save') {
        this.productService.addAddress(data).subscribe(result => {
          const response = result as Response;
          if (response.ok) {
            this.toastr.success(this.addAddressToastMsg);
            this.addressDetail = null;
            this.submit.emit(true);
          } else {
            this.submit.emit(false);
          }
        },
          (error) => {
            console.log(error);
            this.submit.emit(false);
          });
      } else {
        this.productService.updateAddress(data, this.addressid).subscribe(result => {
          const response = result as Response;
          if (response.ok) {
            this.toastr.success(this.updateAddressToastMsg);
            this.addressDetail = null;
            this.submit.emit(true);
          } else {
            this.submit.emit(false);
          }
        },
          (error) => {
            console.log(error);
            this.submit.emit(false);
          });
      }
    } else {
      this.markFormGroupTouched(this.addressGroup);
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    // (<any>Object).values(formGroup.controls).forEach(control => {
    for (const field in formGroup.controls) {
      const control = formGroup.get(field);
      /*if (control) { // control is a FormGroup
        this.markFormGroupTouched(control);
      } else { // control is a FormControl */
      control.markAsTouched();
      // }
    }
  }

  validateForm() {
    this.markFormGroupTouched(this.addressGroup);
  }

  setFormData(value: AddressGet) {
    if (!this.addressGroup) {
      this.initializeAddressGroup();
      this.getCountryList();
    }

    this.nameCtrl.setValue(value.name);
    this.setPhoneNumberDetails(value);
    this.addressCtrl.setValue(value.address);
    this.countryIdCtrl.setValue(value.countryid);
    this.postalCodeCtrl.setValue(value.postalcode);
    this.cityCtrl.setValue(value.city);
    this.addressid = value.addressid;
    this.addressDetail = null;

    const returnData = <UserActionModel>{
      'type': this.type,
      'action': this.savebtnName === 'shared.buttonLabels.save' ? ActionType.ADD : ActionType.UPDATE
    };
    this.componentLoaded.emit(returnData);
  }

  setFormValues(value: AddressGet) {
    if (!this.addressGroup) {
      this.initializeAddressGroup();
      this.getCountryList();
    }

    this.nameCtrl.setValue(value.name);
    this.setPhoneNumberDetails(value);
    this.addressCtrl.setValue(value.address);
    this.countryIdCtrl.setValue(value.countryid);
    this.postalCodeCtrl.setValue(value.postalcode);
    this.cityCtrl.setValue(value.city);
    this.countryChange();
  }

  onCancel() {
    this.addressGroup.reset();
    this.addressDetail = null;
    this.cancel.emit(this.type);
  }

  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }

  setPhoneNumberDetails(contact) {
    if (contact.contactno1) {
      const primaryPhoneDetails = contact.contactno1.split('-');
      if (primaryPhoneDetails.length === 2) {
        this.primaryPhoneCodeCtrl.setValue(primaryPhoneDetails[0]);
        this.primary_contactnoCtrl.setValue(primaryPhoneDetails[1]);
      } else {
        this.primary_contactnoCtrl.setValue(primaryPhoneDetails[0]);
      }
    } else {
      this.primary_contactnoCtrl.setValue('');
    }

    if (contact.contactno2) {
      const alternatePhoneDetails = contact.contactno2.split('-');
      if (alternatePhoneDetails.length === 2) {
        this.alternativePhoneCodeCtrl.setValue(alternatePhoneDetails[0]);
        this.alternative_contactnoCtrl.setValue(alternatePhoneDetails[1]);
      } else {
        this.alternative_contactnoCtrl.setValue(alternatePhoneDetails[0]);
      }
    } else {
      this.alternative_contactnoCtrl.setValue('');
    }
  }
}
