import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DistributorsSalesComponent } from './distributors-sales.component';

describe('DistributorsSalesComponent', () => {
  let component: DistributorsSalesComponent;
  let fixture: ComponentFixture<DistributorsSalesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DistributorsSalesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DistributorsSalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
