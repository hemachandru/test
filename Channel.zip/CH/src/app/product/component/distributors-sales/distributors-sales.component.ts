import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ProductRootObject } from '@app/product/models/product-view';
import { PartnerChannelObject } from '@app/product/models/partner-channel';
import { Response } from '@angular/http';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { DialogRecomendationComponent } from '@app/product/component/dialog-recomendation/dialog-recomendation.component';
import { FilterResult, RecomendationPost } from '@app/product/models/recommendation';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ChannelTypeIdEnum, ChannelType, MoreListViewEnum } from '@app/config/constant';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { ScrollToService } from 'ng2-scroll-to-el';
import { Router } from '@angular/router';

@Component({
  selector: 'app-distributors-sales',
  templateUrl: './distributors-sales.component.html',
  styleUrls: ['./distributors-sales.component.scss']
})
export class DistributorsSalesComponent implements OnInit {
  public _MoreListViewEnum = MoreListViewEnum;
  public webUrl = WebUrl;
  public _NoDataFound: NoDataFound;
  _ProductRootObject: ProductRootObject;
  _RecomendationObject: RecomendationPost;
  _PartnerChannelObject: PartnerChannelObject;
  public channelTypeId: number;
  public scrollbarOptionsCnl = { axis: 'y', theme: 'dark' };
  public _ChannelTypeIdEnum = ChannelTypeIdEnum;
  public preLoader: boolean;
  officialDistributorList: any;
  noDataFound: boolean;
  public filterresult: FilterResult;
  loggedInChannelType: string;
  isDistributor: boolean;
  filter: number;
  totalResult: any;

  constructor(
    private translate: TranslateService,
    public dialog: MatDialog,
    private sharedBusiness: SharedBusiness,
    private router: Router,
    private scrollService: ScrollToService,
  ) {
    this._ProductRootObject = new ProductRootObject();
    this._PartnerChannelObject = new PartnerChannelObject();
    this._NoDataFound = new NoDataFound();
    this.filterresult = new FilterResult();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  ngOnInit() {
    this.noDataFound = false;
    this.channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
    this.isDistributor = true;
    if (localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE)) {
      this.loggedInChannelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
      if (this.loggedInChannelType !== ChannelType.DISTRIBUTOR) {
        this.isDistributor = false;
      }
    }
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('commonError.noData');
    this.getPartnersChannels(this._ProductRootObject);
  }

  getPartnersChannels(_ProductRootObject) {
    this.preLoader = true;
    this.filterresult.brandId = [parseInt(_ProductRootObject.brandId, 10)];
    this.sharedBusiness.getOfficialDistributorList(_ProductRootObject.channelId, true, null, this.filterresult).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        this.preLoader = false;
        const result = response.json();
        const officialDistributorList = result.results;
        this.officialDistributorList = officialDistributorList.slice(0, 3);
        this.noDataFound = false;
        this.totalResult = result.pagination.total;
        if (this.totalResult === 0) {
          this.noDataFound = true;
        }
      } else {
        this.preLoader = false;
        this.noDataFound = true;
      }
    });
  }

  openDialogRecomendation() {
    const dialogRef = this.dialog.open(DialogRecomendationComponent, {
      data: {
        title: 'Distributor Recommendation',
        suggestedTo: this._ProductRootObject.channelId,
        suggestedToType: 2, // vendor
        suggestedType: 3, // Distributor
        roleShow: false
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType === true) {
        // this.getPartnersChannels(this._ProductRootObject.channelId);
      }
    });
  }

  channelView(channelid) {
    if (!this.isDistributor) {
      this.router.navigate([this.webUrl.CHANNEL_SUGGESTION_VIEW, channelid]);
    } else {
      return true;
    }
  }

  goBrandsByID() {
    // let statusType;
    // const channelStatusType = parseInt(this.ChannelStatusType, 10);
    // if (channelStatusType === 1) {
    //   statusType = ChannelStatusTypeName.SUGGESTION;
    // } else if (channelStatusType === 2) {
    //   statusType = ChannelStatusTypeName.PROSPECT;
    // } else if (channelStatusType === 4) {
    //   statusType = ChannelStatusTypeName.CHANNEL;
    // }

    this.router.navigate(['/channel/morelist'],
      {
        queryParams: {
          // connectionid: this.ChannelStatusType,
          // connectionStatusTypeName: statusType,
          filterType: this._ProductRootObject.channelTypeId,
          viewType: this._MoreListViewEnum.OFFICIAL_DISTRIBUTOR_VIEW,
          channelId: this._ProductRootObject.channelId,
          channelName: this._ProductRootObject.companyName,
          excludedBrand: this._ProductRootObject.brandId
        }
      });
  }

  navigateToChannelView(data) {
    if (data.active && data.active.id) {
      this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, data.active.id]);
      this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
    } else {
      return true;
    }
  }
}
