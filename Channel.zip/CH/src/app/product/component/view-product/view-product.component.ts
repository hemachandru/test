import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductBusiness } from '@app/product/business/product.business';
import { ProductRootObject, ProductInfoRootObject, ProductKeyRetailer, ProductKeyDistributor } from '@app/product/models/product-view';
import { ProductInfoObject } from '@app/product/models/product-info';
import { LocalStorage } from '@ngx-pwa/local-storage';

import { Response } from '@angular/http';
import { ScrollToService } from 'ng2-scroll-to-el';
import { ProductListExclude } from '@app/product/models/productlist';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { PopUpTitle, ChannelTypeIdEnum, ActionType, ChannelType, RelationStatus, RedirectChannelList } from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { NoDataFound } from '@app/shared/models/shared-model';
import { BrandResult } from '@app/shared/models/shared-model';
import { ProductDetailTabComponent } from '@app/product/component/product-detail-tab/product-detail-tab.component';
import { TranslateService } from '@ngx-translate/core';
import { ChannelBusiness } from '../../../channel/business/channel.business';
import { datatable } from '@app/channel/models/channel_models';
import { ProductService } from '@app/product/service/product-service.service';

@Component({
  selector: 'app-view-product',
  templateUrl: './view-product.component.html',
  styleUrls: ['./view-product.component.scss']
})
export class ViewProductComponent implements OnInit {

  public webUrl = WebUrl;
  public sku;
  public _ProductRootObject: ProductRootObject;
  _ProductInfoRootObject: ProductInfoRootObject;
  _ProductInfoObject: ProductInfoObject;
  public defaultProductImage = '../assets/images/pro-logo.jpg';
  public productListresult;
  public brandListresult: BrandResult;
  public productlistData;
  public channelID;
  public brandlistData;
  public productSKU;
  public title: string;
  public productSKUID: string;
  public channelTypeId;
  public channelType;
  public _NoDataFound: NoDataFound;
  public isPrevNextBool: boolean;

  preloader: boolean;

  public test: any;
  public testing: any;
  public _channelTypeEnum = ChannelTypeIdEnum;
  public channelId: number;
  public productId;
  public cartQuantity: string;
  public excludedBrandId: number;
  public companyName: string;
  public boolShowCurrentTab: boolean;
  tableresult: datatable;

  public isNext: boolean;
  public isPrevious: boolean;

  constructor(
    public dialog: MatDialog,
    private route: ActivatedRoute,
    private router: Router,
    private productBusiness: ProductBusiness,
    private _productService: ProductService,
    private scrollService: ScrollToService,
    private translate: TranslateService,
    private channelBusiness: ChannelBusiness,
    protected asyncLocalStorage: LocalStorage) {
    this._ProductInfoRootObject = new ProductInfoRootObject();
    this._ProductInfoObject = new ProductInfoObject();
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    this._NoDataFound = new NoDataFound();
  }

  @ViewChild(ProductDetailTabComponent) productDetailTab: ProductDetailTabComponent;

  ngOnInit() {
    this.isPrevNextBool = true;
    this._ProductRootObject = new ProductRootObject();
    this.isPrevious = true;
    this.isNext = true;
    this._NoDataFound.noDataMsg = this.translate.instant('productView.noProduct');
    this.title = 'productView.productDetailtitle';
    this.getChannelProductID();
    // this.boolShowCurrentTab = false;
  }

  // Get Channel Id in params
  getChannelProductID() {
    this.route.params.subscribe(
      (params: any) => {
        this.productSKU = params.id;
        this.getProductDetailData(this.productSKU);
        this.isPrevNextChannelView();
      },
      (error) => {
        console.log(error);
      });
  }

  getProductDetailData(productSKU) {
    this.preloader = true;
    this.productBusiness.GetProductDetail(productSKU).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        this._ProductRootObject = response.json() as ProductRootObject;
        if (!this._ProductRootObject.productKeyRetailer) {
          this._ProductRootObject.productKeyRetailer = new Array<ProductKeyRetailer>();
        }
        if (!this._ProductRootObject.productKeyDistributor) {
          this._ProductRootObject.productKeyDistributor = new Array<ProductKeyDistributor>();
        }
        this.channelTypeId = this._ProductRootObject.channelTypeId;
        this.setChannelTypeByItsId();

        this.companyName = this._ProductRootObject.companyName;
        this.productSKUID = this._ProductRootObject.productSKU;
        // this.channelType = this._ProductRootObject.productChannelCustomerProfile.profile.pTClas.channelType;
        if (this.productSKUID) {
          this.productlistData = <ProductListExclude>{
            'excludedProductSku': [this.productSKUID]
          };

          this.getProductInfo(this.productSKU);
          this.getProductList(this.productlistData);

          this.excludedBrandId = this._ProductRootObject.brand.id;
          this.channelID = this._ProductRootObject.channelId;
          // tslint:disable-next-line:triple-equals
          if (this.excludedBrandId && this.channelID && this.channelTypeId != ChannelTypeIdEnum.RETAILER) {
            this.brandlistData = {
              'excludedBrand': [this.excludedBrandId]
            };
            this.getbrandList(this.channelID, this.brandlistData);
          }
        }
      } else {
        this.productSKUID = '';
      }
      this.setPreviousNextDisplay();
      this.preloader = false;
    });
  }

  getProductInfo(productSKU) {
    this.preloader = true;
    this.productBusiness.GetProductInfo(productSKU).subscribe(res => {
      const response = res as Response;
      this.preloader = false;
      if (response.ok) {
        const info = response.json();
        this._ProductInfoRootObject.channelPaymentOptionType = info.channel.channelPaymentOptionType;
        this._ProductInfoRootObject.channelPaymentTerm = info.channel.channelPaymentOptionType;
        this.productId = info.productId;
        this._ProductInfoObject = response.json() as ProductInfoObject;
        this._ProductInfoObject.channel.channelType.channelType = info.channel.channelType.channelType;
        this.channelType = this._ProductInfoObject.channel.channelType.channelType;
        this.channelTypeId = parseInt(info.channel.channelType.channelTypeId, 10);
      }
    });
  }

  // Product carosel List
  // getProductList(productlistData: ProductListExclude) {
  //   this.preloader = true;
  //   this.productBusiness.GetProductList(productlistData).subscribe(res => {
  //     const response = res as Response;
  //     this.preloader = false;
  //     if (response.ok) {
  //       const result = response.json();
  //       this.productListresult = result;
  //     }
  //   });
  // }

  getProductList(productlistData: ProductListExclude) {
    this.preloader = true;
    this.tableresult = {
      searchKey: '',
      pageNumber: 1,
      limit: 15,
      sort: 'asc'
    };
    // this._channelBusiness.ProductList(productlistData).subscribe(res => {
    this.channelBusiness.ProductList(this.tableresult, productlistData, parseInt(this._ProductRootObject.channelId, 10)).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const result = response.json();
        this.productListresult = result;
      }
    });
  }

  // Brand carosel List
  getbrandList(channelID, brandlistData) {
    this.preloader = true;
    this.productBusiness.getChannelBrandList(channelID, brandlistData, true).subscribe(res => {
      const response = res as Response;
      this.preloader = false;
      if (response.ok) {
        const result = response.json();
        this.brandListresult = result;
      }
    });
  }

  productCopy(product) {
    this.router.navigate([this.webUrl.PRODUCT_MANAGE],
      { queryParams: { sku: this.productSKUID, action: ActionType.COPYORDUPLICATE } });
  }
  productEdit(product) {
    this.router.navigate([this.webUrl.PRODUCT_MANAGE],
      { queryParams: { sku: this.productSKUID, action: ActionType.UPDATE } });
  }

  // product Delete
  productDelete(productSKUID) {
    const list = [];
    this.OpenConfirmDialog('Product', PopUpTitle[12], list, '12', productSKUID);
  }

  private OpenConfirmDialog(title: string, message: string, data: any, id: string, productSKUID: any) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: id,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    document.getElementsByTagName('html').item(0).style.removeProperty('top');
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        if (id === '12') {
          this.preloader = true;
          this.productBusiness.ProductDelete(this.productSKUID, true).subscribe(response => {
            this.preloader = false;
            const responsedata = response as Response;
            if (responsedata.ok) {
              this.router.navigate(['/productlist']);
            }
          });
        }
      }
    });
  }

  OncartQuantityChange(item) {
    this.cartQuantity = item;
  }

  setChannelTypeByItsId() {
    // tslint:disable-next-line:triple-equals
    if (this.channelTypeId == ChannelTypeIdEnum.VENDOR) {
      this.channelType = ChannelType.VENDOR;
      // tslint:disable-next-line:triple-equals
    } else if (this.channelTypeId == ChannelTypeIdEnum.DISTRIBUTOR) {
      this.channelType = ChannelType.DISTRIBUTOR;
      // tslint:disable-next-line:triple-equals
    } else if (this.channelTypeId == ChannelTypeIdEnum.RETAILER) {
      this.channelType = ChannelType.RETAILER;
    }
  }

  // Emit the existing rating scroll
  scrollToKeyRetailer(data) {
    // if (data) {
    this.scrollService.scrollTo(document.getElementById('productDetailTabId'), 1000, -70);
    // this.boolShowCurrentTab = true;
    this.productDetailTab.onTabChange(data);
    // }
  }

  previousNextChannel(flag: string, productId: number) {
    this.asyncLocalStorage.getItem('product-' + this.getRelationStatus()).subscribe((channelList) => {
      if (channelList) {
        const listIds = channelList.collectionIds;
        const index = listIds.indexOf(productId);
        const indexList = flag === 'previous' ? index - 1 : index + 1;
        if (listIds[indexList]) {
          this.router.navigate([RedirectChannelList[this.getRelationStatus()], listIds[indexList]]);
        } else if (flag === 'previous' && channelList.response.page > 1 || flag === 'next'
          && channelList.response.page < (channelList.response.total / channelList.response.limit)) {
          const page = flag === 'previous' ? channelList.response.page - 1 : channelList.response.page + 1;
          channelList.query.pageNumber = page;
          this.preloader = true;
          if (this.getRelationStatus() === RelationStatus.MY_PRODUCTS) {
            this.productBusiness.ProductList(channelList.query, channelList.filter,
              channelList.selected, channelList.filter.filterToogle).subscribe(response => {
                const res = response as Response;
                if (res.ok) {
                  this.redirectToNextSetResults(res.json(), flag);
                }
              });
          } else if (this.getRelationStatus() === RelationStatus.WISH_LIST) {
            this._productService.wishLists(channelList.query, channelList.filter,
              channelList.selected, channelList.filter.filterToogle).subscribe(res => {
                const response = res as Response;
                if (response.ok) {
                  this.redirectToNextSetResults(response.json(), flag);
                }
              });
          } else {
            let listUrl = this.router.url;
            listUrl = listUrl.split('?')[0];
            const topSearch = listUrl === this.webUrl.PRODUCT_SEARCHRESULT_VIEW + this.productSKU ? true : false;
            this.channelBusiness.ProductList(channelList.query, channelList.filter,
              null, topSearch, channelList.selected, channelList.filter.filterToogle).subscribe(response => {
                const res = response as Response;
                if (res.ok) {
                  this.redirectToNextSetResults(res.json(), flag);
                }
              });
          }
        }
      }
    });
  }

  redirectToNextSetResults(result, flag) {
    if (result) {
      this.asyncLocalStorage.getItem('product-' + this.getRelationStatus()).subscribe((channelLst) => {
        const listId = channelLst.collectionIds;
        const channelIdCheck = flag === 'previous' ? listId[result.pagination.limit - 1] : listId[0];
        const inx = listId.indexOf(channelIdCheck);
        if (listId[inx]) {
          this.router.navigate([RedirectChannelList[this.getRelationStatus()], listId[inx]]);
        }
      });
    }
  }


  setPreviousNextDisplay() {
    this.asyncLocalStorage.getItem('product-' + this.getRelationStatus()).subscribe((channelList) => {
      if (channelList && channelList.collectionIds) {
        const index = channelList.collectionIds.indexOf(this.productSKU);
        if (index >= 0) {
          if (channelList.query.pageNumber === 1 && index === 0) {
            this.isPrevious = false;
          } else {
            this.isPrevious = true;
          }
          // const lastRow =
          const ss = (channelList.response.page - 1) * channelList.response.limit;
          if (channelList.query.pageNumber === channelList.response.page &&
            ((channelList.response.page - 1) * channelList.response.limit) + index + 1 === channelList.response.total) {
            this.isNext = false;
          } else {
            this.isNext = true;
          }
        } else {
          this.isPrevNextBool = false;
        }
      } else {
        this.isPrevNextBool = false;
      }
    });
  }

  getRelationStatus() {
    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    let redirectURL;
    if (listUrl === this.webUrl.WISHLIST_PRODUCT_VIEW + this.productSKU) {
      redirectURL = RelationStatus.WISH_LIST;
    } else if (listUrl === this.webUrl.MY_PRODUCT_VIEW + this.productSKU) {
      redirectURL = RelationStatus.MY_PRODUCTS;
    } else if (listUrl === this.webUrl.PRODUCT_SEARCHRESULT_VIEW + this.productSKU) {
      redirectURL = RelationStatus.TOP_SEARCH_PRODUCT;
    } else {
      redirectURL = RelationStatus.PRODUCTS_SUGGESTION;
    }
    return redirectURL;
  }

  isPrevNextChannelView() {
    let listUrl = this.router.url;
    listUrl = listUrl.split('?')[0];
    if (listUrl === this.webUrl.MY_PRODUCT_VIEW_PREV_NEXT + this.productSKU
      || listUrl === this.webUrl.PRODUCT_SUGGESTION_VIEW_PREV_NEXT + this.productSKU) {
      this.isPrevNextBool = false;
    }
  }
}

