import { Component, OnInit, Input } from '@angular/core';
import { BrandId, GroupId, CatgoryId, WishlistFilterItems, ProductList, Product } from '@app/product/models/productlist';
import { Response } from '@angular/http';
import { LocalStorage } from '@ngx-pwa/local-storage';

import { ProductQuality, ChannelTypeIdEnum, UserAccountStatus, AccessPermissionEnum, RelationStatus } from '@app/config/constant';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { PaginationService } from '../../../shared/shared-service/pagination.service';
import { ProductService } from '@app/product/service/product-service.service';
import { Pagination } from '@app/shared/models/contact-list-models';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { NoDataFound } from '@app/shared/models/shared-model';
import { datatable } from '@app/channel/models/channel_models';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-wish-list',
  templateUrl: './wish-list.component.html',
  styleUrls: ['./wish-list.component.scss']
})

export class WishListComponent implements OnInit {
  public webUrl = WebUrl;
  public _NoDataFound: NoDataFound;
  public isevaluateclick: boolean;
  public iswishlistclick: boolean;
  public isbusinessclick: boolean;

  public opts: ISlimScrollOptions;
  public title: string;
  public titlemsg: string;
  public searchdata: string;
  public retailercommisionto: number;
  public retailercommisionfrom: number;
  public distributorcommisionto: number;
  public distributorcommisionfrom: number;
  public retailercommision_min: number;
  public retailercommision_max: number;
  public retailercommision_reset_min: number;
  public retailercommision_reset_max: number;
  public distributorcommision_max: number;
  public distributorcommision_min: number;
  public distributorcommision_reset_max: number;
  public distributorcommision_reset_min: number;
  public retailprice_max: number;
  public retailprice_min: number;
  public retailprice_reset_max: number;
  public retailprice_reset_min: number;
  public preloader: boolean;
  public morecountry: boolean;
  public horizontalViewdata: boolean;
  public listViewdata: boolean;
  private product_List: ProductList;
  public products: Array<Product>;
  public _qualityEnum = ProductQuality;
  public Group: Array<any>;
  public Category: Array<any>;
  public brand: Array<any>;
  public filterToogle: boolean;
  public brandIds: Array<BrandId>;
  public familyIds: Array<GroupId>;
  public categoryIds: Array<CatgoryId>;
  public position: string;
  public price: boolean;
  public filterItems: WishlistFilterItems;
  public offSet = 1;
  public pageSize = 12;
  public pager: any = {};
  public pagination: any;
  public resultCount: number;
  public pagedItems: any[];
  public result: any = [];
  public retailfrom: number;
  public retailto: number;
  public brandlistData: Array<any>;
  @Input() SearchText: string;
  @Input() showTitle: boolean;
  public selectedbrandchannelItems: Array<any>;
  public selectedQualitychannelItems: Array<any>;
  public selectedGroupchannelItems: Array<any>;
  public selectedIsFreeSamples: Array<any>;
  public selectedproductcategory: Array<any>;
  public dropdownbrandchannelSettings: Object;
  public dropdownGroupchannelSettings: Object;
  public dropdownIsFreeSampleSettings: Object;
  public dropdownCategorychannelSettings: Object;
  public dropdownQualitySettings: Object;
  public channelId: number;
  public _channelTypeEnum = ChannelTypeIdEnum;
  ratingdata: number;
  filteractive: boolean;
  noresult: boolean;
  aggregations: any;
  productBrands: any[];
  defaultbrands: any;
  productCategory: any[];
  defaultproductCategory: any;
  productFamily: any[];
  defaultproductFamily: any;
  productQuality: any[];
  defaultproductQuality: any;
  productIsFree: any[];
  defaultproductIsFree: any;

  public tableresult: datatable;
  public filtershow: boolean;
  public sortToggle: boolean;
  public isFrenchTech: boolean;
  constructor(
    private _productService: ProductService, private _pagination: PaginationService,
    public sharedBusiness: SharedBusiness, private authorizeService: AuthorizeService,
    protected asyncLocalStorage: LocalStorage,
    private toastrService: ToastrService, private router: Router, private translate: TranslateService) {
    this.listViewdata = false;
    this.horizontalViewdata = false;
    this.product_List = new ProductList();
    this.products = new Array<Product>();
    this.Group = [];
    this.Category = [];
    this.brand = [];
    this.filterToogle = false;
    this.brandIds = [];
    this.familyIds = [];
    this.categoryIds = [];
    this.position = '';
    this.filterItems = new WishlistFilterItems();
    this.product_List.pagination = new Pagination();
    this.brandlistData = [];
    this.morecountry = false;

    this.selectedbrandchannelItems = [];
    this.selectedQualitychannelItems = [];
    this.selectedGroupchannelItems = [];
    this.selectedIsFreeSamples = [];
    this.selectedproductcategory = [];
    this.dropdownbrandchannelSettings = {};
    this.dropdownQualitySettings = {};
    this.dropdownGroupchannelSettings = {};
    this.dropdownIsFreeSampleSettings = {};
    this.dropdownCategorychannelSettings = {};

    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    this.isevaluateclick = false;
    this.iswishlistclick = true;
    this.isbusinessclick = false;
    this._NoDataFound = new NoDataFound();
    this.isFrenchTech = false;
  }

  ngOnInit() {
    if (!this.authorizeBeforeLoad()) {
      this.router.navigate(['/dashboard']);
    }

    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.sortToggle = true;
    this.title = 'productList.wishList.title';
    this.titlemsg = 'productList.wishList.titlemsg';

    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('productList.wishList.nowishList');
    this.searchdata = this.SearchText || '';
    // load data from localstorage
    this.asyncLocalStorage.getItem('product-' + RelationStatus.WISH_LIST).subscribe((data) => {
      if (data) {

        this.tableresult = data.query;
        this.searchdata = this.searchdata = this.tableresult.searchKey;
        this.offSet = this.tableresult.pageNumber;
        this.pageSize = this.tableresult.limit;
        this.sortToggle = (this.tableresult.sort === 'desc') ? true : false;

        this.filterItems = data.filter;
        this.filterToogle = data.filter.toogle;
        this.isFrenchTech = data.filter.is_french_tech;

        // dropdown select
        this.selectedQualitychannelItems = data.selected.selectedQuality;
        this.selectedbrandchannelItems = data.selected.selectedBrands;
        this.selectedGroupchannelItems = data.selected.product;
        this.selectedproductcategory = data.selected.selectedCategories;
      }
      this.getProductList(this.searchdata, this.offSet, this.pageSize);
    });



    this.dropdownQualitySettings = {
      singleSelection: true,
      text: 'Select Positioning',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownbrandchannelSettings = {
      text: 'Select Brand',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownGroupchannelSettings = {
      text: 'Select Family',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownIsFreeSampleSettings = {
      singleSelection: true,
      text: 'Sample price',
      classes: 'myclass custom-dropdown-class custom-overflow custom-single-select',
      maxHeight: '165'
    };

    this.dropdownCategorychannelSettings = {
      text: 'Select Category',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };
  }

  morecountrydata() {
    this.morecountry = true;
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  filterreset() {
    this.filteractive = true;

    this.searchdata = '';
    this.position = '';
    this.brandIds = [];
    this.categoryIds = [];
    this.familyIds = [];
    delete this.filterItems.brandIds;
    delete this.filterItems.productCategoryIds;
    delete this.filterItems.productFamilyIds;
    this.selectedbrandchannelItems = [];
    this.selectedQualitychannelItems = [];
    this.selectedGroupchannelItems = [];
    this.selectedIsFreeSamples = [];
    this.selectedproductcategory = [];
    delete this.filterItems.retail_price_min;
    delete this.filterItems.retail_price_max;
    this.distributorcommisionfrom = 0;
    this.distributorcommisionto = 0;
    this.retailfrom = 0;
    this.retailto = 0;
    this.retailercommisionfrom = 0;
    this.retailercommisionto = 0;
    delete this.filterItems.retailer_commission_min;
    delete this.filterItems.retailer_commission_max;
    delete this.filterItems.distributor_commission_min;
    delete this.filterItems.distributor_commission_max;
    delete this.filterItems.is_sample_free;
    delete this.filterItems.quality;

    this.retailprice_max = this.retailprice_reset_max;
    this.retailprice_min = this.retailprice_reset_min;
    this.retailercommision_min = this.retailercommision_reset_min;
    this.retailercommision_max = this.retailercommision_reset_max;
    this.distributorcommision_max = this.distributorcommision_reset_max;
    this.distributorcommision_min = this.distributorcommision_reset_min;

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  listView() {
    this.listViewdata = true;
    this.horizontalViewdata = false;
  }

  horizontalView() {
    this.horizontalViewdata = true;
    this.listViewdata = false;
  }
  // search Function
  searchFunction(data) {
    this.searchdata = data;
    this.getProductList(data, this.offSet, this.pageSize);
  }

  filterData() {
    this.filteractive = true;
    if (this.selectedQualitychannelItems.length) {
      this.filterItems.quality = this.selectedQualitychannelItems.map(x => x.id);
    } else {
      delete this.filterItems.quality;
    }
    if (this.selectedproductcategory.length) {
      this.filterItems.productCategoryIds = this.selectedproductcategory.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productCategoryIds;
    }
    if (this.selectedGroupchannelItems.length) {
      this.filterItems.productFamilyIds = this.selectedGroupchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productFamilyIds;
    }
    if (this.selectedIsFreeSamples.length) {
      if (this.selectedIsFreeSamples[0]['id'] === 0) {
        this.filterItems.is_sample_free = false;
      } else {
        this.filterItems.is_sample_free = true;
      }
    } else {
      delete this.filterItems.is_sample_free;
    }
    if (this.selectedbrandchannelItems.length) {
      this.filterItems.brandIds = this.selectedbrandchannelItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.brandIds;
    }
    this.filterItems.is_french_tech = this.isFrenchTech;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  getProductList(search, offSet, pageSize) {
    this.noresult = false;
    this.tableresult = {
      searchKey: search,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callProductList();
  }

  evaluateData() {
    this.isevaluateclick = true;
    this.iswishlistclick = false;
    this.isbusinessclick = false;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  wishlistData() {
    this.iswishlistclick = true;
    this.isevaluateclick = false;
    this.isbusinessclick = false;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  businesslistData() {
    this.isbusinessclick = true;
    this.isevaluateclick = false;
    this.iswishlistclick = false;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  // Product List View distributecommion, retailcommion,
  callProductList() {

    if (this.isevaluateclick) {
      this.filterItems.type = 'EVALVATED';
    } else if (this.iswishlistclick) {
      this.filterItems.type = 'WISHLIST';
    } else {
      this.filterItems.type = 'BUSINESS';
    }
    const selected = {
      selectedQuality: this.selectedQualitychannelItems,
      selectedBrands: this.selectedbrandchannelItems,
      product: this.selectedGroupchannelItems,
      selectedCategories: this.selectedproductcategory,
    };

    this._productService.wishLists(this.tableresult, this.filterItems, selected, this.filterToogle).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const product_List = response.json() as ProductList;
        this.aggregations = product_List.aggregations;
        this.resultCount = product_List.pagination.total;
        if (this.resultCount === 0) {
          this.noresult = true;
        }

        this.products = product_List.results;
        this.products.forEach(product => {
          if (product.images.primary.length === 1) {
            product.defaultimage = product.images.primary[0].documentUrl;
          } else if (product.images.others.length > 0) {
            product.defaultimage = product.images.others[0].documentUrl;
          } else {
            product.defaultimage = '../assets/images/acc-logo.jpg';
          }
        });
        this.productQuality = [];
        if (this.aggregations['quality']) {
          this.defaultproductQuality = this.aggregations['quality']['buckets'];
          for (let i = 0; i < this.defaultproductQuality.length; i++) {
            this.productQuality.push({
              'id': this.defaultproductQuality[i].key,
              'itemName': this.defaultproductQuality[i].key,
              'count': this.defaultproductQuality[i].doc_count
            });
          }
        }

        this.productBrands = [];
        if (this.aggregations['brands']) {
          this.defaultbrands = this.aggregations['brands']['buckets'];
          for (let i = 0; i < this.defaultbrands.length; i++) {
            this.productBrands.push({
              'id': this.defaultbrands[i].key,
              'itemName': this.defaultbrands[i].label,
              'count': this.defaultbrands[i].doc_count
            });
          }
        }

        this.productCategory = [];
        if (this.aggregations['category']) {
          this.defaultproductCategory = this.aggregations['category']['buckets'];
          for (let i = 0; i < this.defaultproductCategory.length; i++) {
            this.productCategory.push({
              'id': this.defaultproductCategory[i].key,
              'itemName': this.defaultproductCategory[i].label,
              'count': this.defaultproductCategory[i].doc_count
            });
          }
        }

        this.productFamily = [];
        if (this.aggregations['family']) {
          this.defaultproductFamily = this.aggregations['family']['buckets'];
          for (let i = 0; i < this.defaultproductFamily.length; i++) {
            this.productFamily.push({
              'id': this.defaultproductFamily[i].key,
              'itemName': this.defaultproductFamily[i].label,
              'count': this.defaultproductFamily[i].doc_count
            });
          }
        }

        this.productIsFree = [];
        if (this.aggregations['free_sample']) {
          this.defaultproductIsFree = this.aggregations['free_sample']['buckets'];
          for (let i = 0; i < this.defaultproductIsFree.length; i++) {
            this.productIsFree.push({
              'id': this.defaultproductIsFree[i].key,
              'itemName': this.defaultproductIsFree[i].key ? 'Free' : 'Paid',
              'count': this.defaultproductIsFree[i].doc_count
            });
          }
        }

        this.retailprice_min = product_List.aggregations.retail_min_price.value;
        this.retailprice_max = product_List.aggregations.retail_max_price.value;

        if (this.retailprice_reset_min <= 0) {
          this.retailprice_reset_min = this.retailprice_min;
        }

        if (this.retailprice_reset_max <= 0) {
          this.retailprice_reset_max = this.retailprice_max;
        }

        this.distributorcommision_min = product_List.aggregations.distributer_min_margin.value;
        this.distributorcommision_max = product_List.aggregations.distributer_max_margin.value;

        if (this.distributorcommision_reset_min <= 0) {
          this.distributorcommision_reset_min = this.distributorcommision_min;
        }

        if (this.distributorcommision_reset_max <= 0) {
          this.distributorcommision_reset_max = this.distributorcommision_max;
        }

        this.retailercommision_min = product_List.aggregations.retailer_min_margin.value;
        this.retailercommision_max = product_List.aggregations.retailer_max_margin.value;

        if (this.retailercommision_reset_min <= 0) {
          this.retailercommision_reset_min = this.retailercommision_min;
        }

        if (this.retailercommision_reset_max <= 0) {
          this.retailercommision_reset_max = this.retailercommision_max;
        }

        this.preloader = false;
        this.setPage(this.tableresult.pageNumber);
      } else {
        this.noresult = true;
      }
    });
  }

  paginationFunction(data: number) {
    this.getProductList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getProductList(this.searchdata, 1, pageSize);
  }

  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  retailerPriceChange(event) {
    this.retailfrom = event.from;
    this.retailto = event.to;
    if (!ValidationService.isNullOrEmpty(this.retailfrom) && this.retailfrom !== 0) {
      this.filterItems.retail_price_min = this.retailfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailto) && this.retailto !== 0) {
      this.filterItems.retail_price_max = this.retailto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  distributorcommision(event) {
    this.distributorcommisionfrom = event.from;
    this.distributorcommisionto = event.to;
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionfrom) && this.distributorcommisionfrom !== 0) {
      this.filterItems.distributor_commission_min = this.distributorcommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.distributorcommisionto) && this.distributorcommisionto !== 0) {
      this.filterItems.distributor_commission_max = this.distributorcommisionto;
    }

    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  retailercommision(event) {
    this.retailercommisionfrom = event.from;
    this.retailercommisionto = event.to;

    if (!ValidationService.isNullOrEmpty(this.retailercommisionfrom) && this.retailercommisionfrom !== 0) {
      this.filterItems.retailer_commission_min = this.retailercommisionfrom;
    }
    if (!ValidationService.isNullOrEmpty(this.retailercommisionto) && this.retailercommisionto !== 0) {
      this.filterItems.retailer_commission_max = this.retailercommisionto;
    }
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  authorizeBeforeLoad() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.PRODUCTS_WISHLIST);
      if (!hasUpdateAccess) {
        this.toastrService.warning(this.translate.instant('userAccess.pageAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }
}
