import { Component, OnInit } from '@angular/core';
import { SuccesErrorMessage, MessageContent, SuccesErrorButton } from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-success-message',
  templateUrl: './order-success-message.component.html',
  styleUrls: ['./order-success-message.component.scss']
})
export class OrderSuccessMessageComponent implements OnInit {
  public webUrl = WebUrl;
  public successObject: SuccesErrorMessage;
  closeBtnName: string;
  orderNo: any;
  constructor(private router: Router) {
    this.successObject = new SuccesErrorMessage();
    this.successObject.messages = new Array<MessageContent>();
    this.closeBtnName = 'CloseButton';
    // this.successObject.button = new Array<SuccesErrorButton>();
  }

  ngOnInit() {
    this.orderNo = localStorage.getItem(AppLocalStorageKeys.ORDER_NUMBER);
    if (this.orderNo) {
      this.setTemplate();
      localStorage.removeItem(AppLocalStorageKeys.ORDER_NUMBER);
    } else {
      this.router.navigate([this.webUrl.CART_LIST]);
    }
  }

  setTemplate() {
    this.successObject.errorTitle = 'ordersuccess.samplesucess';
    this.successObject.errorId = '1';
    this.successObject.errorType = 'success';
    this.successObject.icon = 'fa-check';
    this.successObject.showButtonBlock = false;
    this.successObject.iconMessage = 'Order No: ' + this.orderNo;
    let messageContent = new MessageContent();
    messageContent.messageContent = 'ordersuccess.msgContent';
    this.successObject.messages.push(messageContent);
    messageContent = new MessageContent();
    messageContent.messageContent = 'ordersuccess.trackorder';
    this.successObject.messages.push(messageContent);
  }

  onContinue() {
    this.router.navigate([this.webUrl.CART_LIST]);
  }

}
