import { Component, OnInit, HostListener } from '@angular/core';
import { ProductBusiness } from '@app/product/business/product.business';
import { ProductList, Product, BrandId, GroupId, CatgoryId, FilterItems, Pagination } from '@app/product/models/productlist';
import { Response } from '@angular/http';
import { LocalStorage } from '@ngx-pwa/local-storage';
import {
  ProductQuality, ActionType, ChannelTypeIdEnum, FeatureAccessEnum,
  ButtonTypes, UserAccountStatus, AccessPermissionEnum, RelationStatus
} from '@app/config/constant';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { PaginationService } from '../../../shared/shared-service/pagination.service';
import { Router } from '@angular/router';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { PopUpTitle, CurrencyType, AWSUrl, ProductListActiveInactive } from '@app/config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { NoDataFound } from '@app/shared/models/shared-model';
import { SharedService } from '../../../shared/shared-service/shared-service';
import { ToastrService } from 'ngx-toastr';
import { CommonHelper } from '@app/shared/common-helper';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';
import { datatable } from '@app/channel/models/channel_models';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  public webUrl = WebUrl;
  ratingdata: number;
  public _NoDataFound: NoDataFound;
  public opts: ISlimScrollOptions;
  public search: string;
  public searchdata: string;
  public preloader: boolean;
  public inactiveCount: any = 0;
  public activeCount: any = 0;
  public isActive: boolean;
  public horizontalViewdata: boolean;
  public listViewdata: boolean;
  public isactiveclick: boolean;
  public inactiveclick: boolean;
  public title;
  public morecountry: boolean;
  public titlemsg;
  public product_List: ProductList;
  public products: Array<Product>;
  public productlistdata: Array<Product>;
  public _qualityEnum = ProductQuality;
  public filterToogle: boolean;
  public brandIds: Array<BrandId>;
  public familyIds: Array<GroupId>;
  public categoryIds: Array<CatgoryId>;
  public position: string;
  public filterItems: FilterItems;
  public offSet = 1;
  public pageSize = 12;
  pager: any = {};
  public pagination: any;
  public resultCount: number;
  pagedItems: any[];
  public result: any = [];
  public activeStatus: any = {};
  public activecolor: boolean;
  public inactivelistStyle: boolean;
  public selectedbrandItems: Array<any>;
  public selectedGroupItems: Array<any>;
  public selectedCategoryItems: Array<any>;
  public selectedQualitychannelItems: Array<any>;
  public dropdownbrandSettings: Object;
  public dropdownQualitySettings: Object;
  public dropdownGroupSettings: Object;
  public dropdownCategorySettings: Object;
  public _channelTypeEnum = ChannelTypeIdEnum;
  public channelId: number;
  public _CurrencyType = CurrencyType;
  dialogRef: MatDialogRef<MessageDialogComponent>;

  public tableresult: datatable;
  public filtershow: boolean;
  public filteractive: boolean;
  public sortToggle: boolean;
  noresult: boolean;
  aggregations: any;
  productBrands: any[];
  defaultbrands: any;
  productCategory: any[];
  defaultproductCategory: any;
  productFamily: any[];
  defaultproductFamily: any;
  productQuality: any[];
  defaultproductQuality: any;
  subtitle: any;
  locationurl: string;
  public countActivInactive: Array<number>;
  public isFrenchTech: boolean;

  constructor(public dialog: MatDialog, protected asyncLocalStorage: LocalStorage,
    private productBusiness: ProductBusiness, private _pagination: PaginationService,
    public sharedBusiness: SharedBusiness, private router: Router, private translate: TranslateService,
    private sharedService: SharedService, private toastr: ToastrService, private authorizeService: AuthorizeService) {
    this.title = 'productList.title';
    // this.titlemsg = 'Manage your products based on your categories, group or family and add new products.' + '<br>' +
    //   'You also can make bulk export or import of your products.';
    this.subtitle = this.translate.instant('productList.titleMessage');
    this.listViewdata = false;
    this.horizontalViewdata = false;
    this.isactiveclick = true;
    this.inactiveclick = false;
    this.product_List = new ProductList();
    this.products = new Array<Product>();
    this.productlistdata = new Array<Product>();
    this.inactiveCount = 0;
    this.activeCount = 0;
    this.filterToogle = false;
    this.brandIds = [];
    this.familyIds = [];
    this.categoryIds = [];
    this.position = '';
    this.product_List.pagination = new Pagination();
    this.filterItems = new FilterItems();
    this.activecolor = false;
    this.inactivelistStyle = false;
    this.searchdata = '';
    this.morecountry = false;
    this.selectedbrandItems = [];
    this.selectedGroupItems = [];
    this.selectedCategoryItems = [];
    this.selectedQualitychannelItems = [];
    this.dropdownbrandSettings = {};
    this.dropdownQualitySettings = {};
    this.dropdownGroupSettings = {};
    this.dropdownCategorySettings = {};
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    this._NoDataFound = new NoDataFound();
    this.locationurl = environment.AWS_DOWNLOAD_URL + AWSUrl.PRODUCT_GUIDELINE;
  }

  ngOnInit() {
    if (!this.authorizeBeforeLoad()) {
      this.router.navigate(['/dashboard']);
    }
    this.sortToggle = true;
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };

    this.searchdata = '';
    this.filterItems.isActive = true;
    // load data from localstorage
    this.asyncLocalStorage.getItem('product-' + RelationStatus.MY_PRODUCTS).subscribe((data) => {
      if (data) {

        this.tableresult = data.query;
        this.search = this.searchdata = this.tableresult.searchKey;
        this.offSet = this.tableresult.pageNumber;
        this.pageSize = this.tableresult.limit;
        this.sortToggle = (this.tableresult.sort === 'desc') ? true : false;

        this.filterItems = data.filter;
        this.filterToogle = data.filter.toogle;
        this.isFrenchTech = data.filter.is_french_tech;

        // dropdown select
        this.selectedQualitychannelItems = data.selected.selectedQuality;
        this.selectedbrandItems = data.selected.selectedBrands;
        this.selectedGroupItems = data.selected.product;
        this.selectedCategoryItems = data.selected.selectedCategories;
      }
      this.getProductList(this.searchdata, this.offSet, this.pageSize);
    });
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
    this._NoDataFound.noDataImageSrc = '../assets/images/no-product.png';
    this._NoDataFound.noDataMsg = this.translate.instant('productList.noProduct');

    this.dropdownQualitySettings = {
      text: 'Select Positioning',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownbrandSettings = {
      singleSelection: false,
      text: 'Select Brand',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownGroupSettings = {
      singleSelection: false,
      text: 'Select Family',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.dropdownCategorySettings = {
      singleSelection: false,
      text: 'Select Category',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '165',
      badgeShowLimit: 1
    };

    this.inactiveCount = 0;
    this.activeCount = 0;
    this.countActivInactive = [0, 0];
    this.isFrenchTech = false;
  }

  filterData() {
    this.filteractive = true;
    if (this.selectedQualitychannelItems.length) {
      this.filterItems.quality = this.selectedQualitychannelItems.map(x => x.id);
    } else {
      delete this.filterItems.quality;
    }
    if (this.selectedCategoryItems.length) {
      this.filterItems.productCategoryIds = this.selectedCategoryItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productCategoryIds;
    }
    if (this.selectedGroupItems.length) {
      this.filterItems.productFamilyIds = this.selectedGroupItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.productFamilyIds;
    }
    if (this.selectedbrandItems.length) {
      this.filterItems.brandIds = this.selectedbrandItems.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterItems.brandIds;
    }
    if (this.isactiveclick) {
      this.filterItems.isActive = true;
    } else {
      this.filterItems.isActive = false;
    }
    this.filterItems.is_french_tech = this.isFrenchTech;
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  activeData() {
    this.isactiveclick = true;
    this.inactiveclick = false;
    this.activecolor = false;
    this.inactivelistStyle = false;
    delete this.productlistdata;
    this.filterData();
  }

  inactiveData() {
    this.isactiveclick = false;
    this.inactiveclick = true;
    this.activecolor = true;
    this.inactivelistStyle = true;
    delete this.productlistdata;
    this.filterData();
  }

  listView() {
    this.listViewdata = true;
    this.horizontalViewdata = false;
  }

  horizontalView() {
    this.horizontalViewdata = true;
    this.listViewdata = false;
  }

  searchFunction(data) {
    this.searchdata = data;
    this.getProductList(data, this.offSet, this.pageSize);
  }

  morecountrydata() {
    this.morecountry = true;
  }

  getProductList(search, offSet, pageSize) {
    this.noresult = false;
    this.tableresult = {
      searchKey: search,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callProductList();
  }

  // Product List View
  callProductList() {
    const selected = {
      selectedQuality: this.selectedQualitychannelItems,
      selectedBrands: this.selectedbrandItems,
      product: this.selectedGroupItems,
      selectedCategories: this.selectedCategoryItems,
    };
    this.productBusiness.ProductList(this.tableresult, this.filterItems, selected, this.filterToogle).subscribe(res => {
      this.preloader = true;
      const response = res as Response;
      // let j = 0;
      if (response.ok) {
        const product_List = response.json() as ProductList;
        this.aggregations = product_List.aggregations;
        this.productlistdata = product_List.results;
        // this.activeCount = product_List.aggregations.status.active;
        // this.inactiveCount = product_List.aggregations.status.inactive;
        this.pagination = product_List.pagination;
        this.resultCount = product_List.pagination.total;
        if (this.resultCount === 0) {
          this.noresult = true;
        }
        if (this.aggregations.active) {
          this.countActivInactive[0] = this.aggregations.active.buckets.filter(item => item.key === ProductListActiveInactive.ACTIVE)[0]
            ? this.aggregations.active.buckets.filter(item => item.key === ProductListActiveInactive.ACTIVE)[0].doc_count : 0;
          this.countActivInactive[1] = this.aggregations.active.buckets.filter(item => item.key === ProductListActiveInactive.INACTIVE)[0]
            ? this.aggregations.active.buckets.filter(item => item.key === ProductListActiveInactive.INACTIVE)[0].doc_count : 0;
        } else {
          this.countActivInactive = [0, 0];
        }
        this.activeCount = this.countActivInactive[0];
        this.inactiveCount = this.countActivInactive[1];
        // if (this.activeCount === 0 || CommonHelper.getStripeIDLocally() === '0') {
        //   this.validateAndSetStripeId();
        // }
        this.productQuality = [];
        if (this.aggregations['quality']) {
          this.defaultproductQuality = this.aggregations['quality']['buckets'];
          for (let i = 0; i < this.defaultproductQuality.length; i++) {
            this.productQuality.push({
              'id': this.defaultproductQuality[i].key,
              'itemName': this.defaultproductQuality[i].key,
              'count': this.defaultproductQuality[i].doc_count
            });
          }
        }
        this.productBrands = [];
        if (this.aggregations['brands']) {
          this.defaultbrands = this.aggregations['brands']['buckets'];
          for (let i = 0; i < this.defaultbrands.length; i++) {
            this.productBrands.push({
              'id': this.defaultbrands[i].key,
              'itemName': this.defaultbrands[i].label,
              'count': this.defaultbrands[i].doc_count
            });
          }
        }
        this.productCategory = [];
        if (this.aggregations['category']) {
          this.defaultproductCategory = this.aggregations['category']['buckets'];
          for (let i = 0; i < this.defaultproductCategory.length; i++) {
            this.productCategory.push({
              'id': this.defaultproductCategory[i].key,
              'itemName': this.defaultproductCategory[i].label,
              'count': this.defaultproductCategory[i].doc_count
            });
          }
        }
        this.productFamily = [];
        if (this.aggregations['family']) {
          this.defaultproductFamily = this.aggregations['family']['buckets'];
          for (let i = 0; i < this.defaultproductFamily.length; i++) {
            this.productFamily.push({
              'id': this.defaultproductFamily[i].key,
              'itemName': this.defaultproductFamily[i].label,
              'count': this.defaultproductFamily[i].doc_count
            });
          }
        }
        this.products = product_List.results;
        this.products.forEach(product => {
          if (product.images.primary.length > 0) {
            product.defaultimage = product.images.primary[0].documentUrl;
          } else if (product.images.others.length > 0) {
            product.defaultimage = product.images.others[0].documentUrl;
          } else {
            product.defaultimage = '../assets/images/pro-logo.jpg';
          }
        });
        this.setPage(this.tableresult.pageNumber);
        this.preloader = false;
      }
    });
  }

  paginationFunction(data: number) {
    this.getProductList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getProductList(this.searchdata, 1, pageSize);
  }

  setPage(page: number) {

    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 12);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  // active Product
  activeProduct(product) {
    if (product.is_active === true) {
      const list = [];
      this.OpenConfirmDialog('Product', PopUpTitle[13], list, '13', product);
      this.activeStatus = {
        'productstatus': '0'
      };
    } else {
      const list = [];
      this.OpenConfirmDialog('Product', PopUpTitle[14], list, '14', product);
      this.activeStatus = {
        'productstatus': '1'
      };
    }
  }

  // product Delete
  productDelete(product) {
    const list = [];
    this.OpenConfirmDialog('Product', PopUpTitle[12], list, '12', product);
  }

  addProduct() {
    // if (CommonHelper.getStripeIDLocally() === '1') {
    this.preloader = true;
    this.router.navigate([this.webUrl.PRODUCT_MANAGE]);
    // } else {
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   this.validateAndSetStripeId();
    // }
  }

  importProduct() {
    // if (CommonHelper.getStripeIDLocally() === '1') {
    this.preloader = true;
    this.router.navigate([this.webUrl.PRODUCT_IMPORT]);
    // } else {
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   this.validateAndSetStripeId();
    // }
  }

  productCopy(product) {
    this.preloader = true;
    this.router.navigate([this.webUrl.PRODUCT_MANAGE],
      { queryParams: { sku: product.sku, action: ActionType.COPYORDUPLICATE } });
  }

  productEdit(product) {
    this.preloader = true;
    this.router.navigate([this.webUrl.PRODUCT_MANAGE],
      { queryParams: { sku: product.sku, action: ActionType.UPDATE } });
  }

  private OpenConfirmDialog(title: string, message: string, data: any, id: string, product: any) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: title,
        type: 2,
        message: this.translate.instant(message),
        list: data,
        id: id,
        channelId: 0,
        jtcChannelId: 0,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        if (id === '12') {
          this.preloader = true;
          this.productBusiness.ProductDelete(product.sku, true).subscribe(response => {
            this.preloader = false;
            const responsedata = response as Response;
            if (responsedata.ok) {
              this.getProductList(this.searchdata, this.offSet, this.pageSize);
            }
          });
        }

        if (id === '13' || id === '14') {
          this.preloader = true;
          this.productBusiness.ProductStatus(product.sku, this.activeStatus, true).subscribe(response => {
            this.preloader = false;
            const responsedata = response as Response;
            if (responsedata.ok) {
              this.getProductList(this.searchdata, this.offSet, this.pageSize);
            } else {
              this.toastr.error
              ('Some of the mandatory fields are not filled yet. please make sure your product is ready to active.", "Product activate');
              this.router.navigate([this.webUrl.PRODUCT_MANAGE],
                { queryParams: { sku: product.sku, action: ActionType.UPDATE } });
            }
          });
        }
      }
    });
  }

  filterreset() {
    this.filteractive = true;
    this.search = '';
    this.searchdata = '';
    this.position = '';
    this.brandIds = [];
    this.categoryIds = [];
    this.familyIds = [];
    this.isFrenchTech = false;
    delete this.filterItems.brandIds;
    delete this.filterItems.productFamilyIds;
    delete this.filterItems.productCategoryIds;
    delete this.filterItems.quality;
    delete this.filterItems.is_french_tech;
    this.selectedbrandItems = [];
    this.selectedGroupItems = [];
    this.selectedCategoryItems = [];
    this.selectedQualitychannelItems = [];
    this.getProductList(this.searchdata, this.offSet, this.pageSize);
  }

  // validateAndSetStripeId() {
  //   this.sharedService.stripeConnectCheck().subscribe(item => {
  //     if (item.ok) {
  //       localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '1');
  //     } else {
  //       localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '0');
  //     }
  //   });
  // }

  authorizeAddNewProduct() {
    this.preloader = true;
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.ADD_PRODUCT).then(item => {
      this.preloader = false;
      const _activeCount = this.activeCount ? parseInt(this.activeCount, 10) : 0;
      const _inactiveCount = this.inactiveCount ? parseInt(this.inactiveCount, 10) : 0;

      if ((_activeCount + _inactiveCount) < item) {
        this.addProduct();
      } else {
        this.openUpgradePopup();
      }
    });
  }

  authorizeCopyProduct(product) {
    this.preloader = true;
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.ADD_PRODUCT).then(item => {
      this.preloader = false;
      if ((parseInt(this.activeCount, 10) + parseInt(this.inactiveCount, 10)) < item) {
        this.productCopy(product);
      } else {
        this.openUpgradePopup();
      }
    });
  }

  public openUpgradePopup() {
    const title = this.translate.instant('productList.upgradetitle');
    const message = this.translate.instant('productList.upgradeMsg');
    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        localStorage.setItem('RedirectId', '9');
        this.router.navigate(['/user/subscriptionplan']);
      }
    });
  }

  authorizeBeforeLoad() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.MY_PRODUCTS);
      if (!hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  authorizeImportProduct() {
    this.preloader = true;
    this.authorizeService.hasFeatureAccess(FeatureAccessEnum.PRODUCT_IMPORT).then(item => {
      this.preloader = false;
      if (item) {
        this.importProduct();
      } else {
        this.openUpgradePopup();
      }
    });
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= 1024) {
      this.listView();
    }
  }
}
