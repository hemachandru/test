import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductArticlesComponent } from './product-articles.component';

describe('ProductArticlesComponent', () => {
  let component: ProductArticlesComponent;
  let fixture: ComponentFixture<ProductArticlesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductArticlesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductArticlesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
