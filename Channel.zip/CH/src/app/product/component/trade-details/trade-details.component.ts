import { Component, OnInit, Input, Output, EventEmitter, ViewChildren, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import {
  Config, ActionType, ChannelType, S3Buckets, UnitEnum, DiscountUnit, ProductQuality,
  UniversalCodeType
} from '@app/config/constant';
// import { Config, ChannelType, LocationType, SocialMedia, Role, ProductCategoryTypeEnum } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import {
  ProductBasicInfo, Producttag, ProductBasicInfoAdd, ProductArticleReview, ProductImages,
  ProductBrochure, ProductPreferences, Review, Productexistingrating, Preference, ProductPrice,
  Productimage, Productdisplayimage, Productpackagingimage, Productpdf, ProductCodeAdd, ProductCodeType,
  ProductPackageInfo, ProductPosition, ProductCompetingAdd, Productcompeting, ProductAvailability
} from '../../models/add-product';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { Response } from '@angular/http';
import {
  ProductGroup, ProductCategory, Brand, ChannelInfos, ShareType, Unit, Discount
} from '@app/shared/models/shared-model';
import {
  ProductUniversalCode, ProductPriceDetail, ProductPackageInfoGet, ProductCompetingGet
} from '../../models/get-product';
import { ScrollToService } from 'ng2-scroll-to-el';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { CurrencyDetail } from '@app/shared/models/shared-model';

@Component({
  selector: 'app-trade-details',
  templateUrl: './trade-details.component.html',
  styleUrls: ['./trade-details.component.scss']
})

export class TradeDetailsComponent implements OnInit {
  isVariant?: number;
  retailerUnits: Array<any> = new Array<any>();
  minimumOrderQuantities: Array<any> = new Array<any>();
  packageSizeUnits: Array<any> = new Array<any>();
  constant: Config;

  variantCtrl: FormControl;
  productUPCCtrl: FormControl;
  productEANCtrl: FormControl;
  productHSNCtrl: FormControl;
  variantTextCtrl: FormControl;

  currencyidCtrl: FormControl;
  retailerPriceCtrl: FormControl;
  retailerUnitCtrl: FormControl;
  // distributorMarginCtrl: FormControl;
  // retailerMarginCtrl: FormControl;
  samplePriceCtrl: FormControl;
  samplePriceUnitCtrl: FormControl;
  issamplefreeCtrl: FormControl;
  samplethresholdCtrl: FormControl;
  isunlimitsampleCtrl: FormControl;
  // distributormarginpercentunitidCtrl: FormControl;
  // retailermarginpercentunitidCtrl: FormControl;

  minorderquantityCtrl: FormControl;
  orderunitidCtrl: FormControl;
  // packagesizeCtrl: FormControl;
  // packageunitCtrl: FormControl;
  noofpackageinboxCtrl: FormControl;
  noofpackageinboxunitidCtrl: FormControl;
  // noofboxinpalletCtrl: FormControl;
  // noofboxinpalletunitidCtrl: FormControl;
  // approximateweightofpalletCtrl: FormControl;
  // approximateweightofpalletunitidCtrl: FormControl;
  // lengthCtrl: FormControl;
  // breadthCtrl: FormControl;
  // heightCtrl: FormControl;
  // weightCtrl: FormControl;

  productQualityLevelCtrl: FormControl;

  tradeDetailGroup: FormGroup;
  priceDetailGroup: FormGroup;
  packagingInfoGroup: FormGroup;
  productPositioningGroup: FormGroup;
  productCodeGroup: FormGroup;
  competingGroup: FormGroup;
  competingItemsArray: FormArray;
  unitList: Array<Unit>;
  discountList: Array<Discount>;
  productSKU: string;
  @Input()
  public actionType: number;

  deletedCompetingProduct: Array<number>;
  productUPCid: number;
  productHSNid: number;
  productEANid: number;
  distributorMarginErrCtrl: string;
  distributorMarginErrCode: string;

  retailerMarginErrCtrl: string;
  retailerMarginErrCode: string;
  currencyDetails: Array<CurrencyDetail>;
  userCurrency: string;
  scrollToElementId: string;

  minorderquantityErrCtrl: string;
  minorderquantityErrCode: string;
  retailerPriceErrCtrl: string;
  retailerPriceErrCode: string;
  samplePriceErrCtrl: string;
  samplePriceErrCode: string;
  noofpackageinboxErrCtrl: string;
  noofpackageinboxErrCode: string;
  samplethresholdErrCtrl: string;
  samplethresholdErrCode: string;
  isPriceDetailInvalid: boolean;
  public availablityFormGroup: FormGroup;
  // Form controls;
  public isavaialbleimmediateCtrl: FormControl;
  public avaialblefromCtrl: FormControl;
  public avaialbilitycommentCtrl: FormControl;

  constructor(public sharedBusiness: SharedBusiness, private scrollService: ScrollToService,
    private sharedService: SharedService) {
    this.distributorMarginErrCtrl = 'distributormarginpercent';
    this.retailerMarginErrCtrl = 'retailermarginpercent';

    this.minorderquantityErrCtrl = 'minorderquantity';
    this.retailerPriceErrCtrl = 'retailerPrice';
    this.samplePriceErrCtrl = 'samplePrice';
    this.noofpackageinboxErrCtrl = 'noofpackageinbox';
    this.samplethresholdErrCtrl = 'samplethreshold';
  }

  ngOnInit() {
    this.productUPCid = 0;
    this.productHSNid = 0;
    this.productEANid = 0;
    this.productSKU = '';
    // this.packageSizeUnits = [];
    this.initializeTradeDetailGroup();
    this.loadUnits();
    // this.loadDiscounts();
    if (this.actionType === ActionType.UPDATE) {
      this.deletedCompetingProduct = new Array<number>();
    }
    this.userCurrency = localStorage.getItem(AppLocalStorageKeys.USER_CURRENCY);
    const _currencyDetails = localStorage.getItem(AppLocalStorageKeys.CURRENCY_CONVERTION_TABLE);
    if (_currencyDetails) {
      this.currencyDetails = JSON.parse(_currencyDetails);
      if (this.actionType === ActionType.ADD) {
        this.currencyidCtrl.setValue(this.userCurrency);

      }
    } else {
      this.getCurrencyConverionTable();
    }
    if (this.actionType === ActionType.ADD) {
      this.setDefaultUnitAsPcs();
    }
  }

  setDefaultUnitAsPcs() {
    this.retailerUnitCtrl.setValue(5);
    this.samplePriceUnitCtrl.setValue(5);
    this.orderunitidCtrl.setValue(5);
  }

  initializeTradeDetailGroup() {
    this.constant = new Config();
    this.variantCtrl = new FormControl(0, Validators.compose([Validators.required]));
    this.productUPCCtrl = new FormControl('', Validators.compose([
      Validators.pattern(this.constant.numberPattern), Validators.minLength(13),
      Validators.maxLength(13)]));
    this.productEANCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.constant.numberPattern), Validators.minLength(13),
    Validators.maxLength(13)]));
    this.productHSNCtrl = new FormControl('', Validators.compose([Validators.minLength(3),
    Validators.maxLength(38)]));
    this.variantTextCtrl = new FormControl('');

    this.productCodeGroup = new FormGroup({
      productUPC: this.productUPCCtrl,
      productEAN: this.productEANCtrl,
      productHSN: this.productHSNCtrl,
      variantText: this.variantTextCtrl,
      variant: this.variantCtrl,
    });

    this.currencyidCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.retailerPriceCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.constant.floatingNumberPattern)]));
    this.retailerUnitCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.distributorMarginCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.retailerMarginCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.samplePriceCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.constant.floatingNumberPattern)]));
    this.samplePriceUnitCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.samplethresholdCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.constant.numberPattern)]));
    this.isunlimitsampleCtrl = new FormControl(false);
    this.issamplefreeCtrl = new FormControl(false);
    // this.distributormarginpercentunitidCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.retailermarginpercentunitidCtrl = new FormControl('', Validators.compose([Validators.required]));

    this.priceDetailGroup = new FormGroup({
      currencyid: this.currencyidCtrl,
      retailerprice: this.retailerPriceCtrl,
      retailerpriceunitid: this.retailerUnitCtrl,
      sampleprice: this.samplePriceCtrl,
      samplepriceunitid: this.samplePriceUnitCtrl,
      issamplefree: this.issamplefreeCtrl,
      // distributormarginpercent: this.distributorMarginCtrl,
      // distributormarginpercentunitid: this.distributormarginpercentunitidCtrl,
      // retailermarginpercent: this.retailerMarginCtrl,
      // retailermarginpercentunitid: this.retailermarginpercentunitidCtrl,
      samplethreshold: this.samplethresholdCtrl,
      isunlimitsample: this.isunlimitsampleCtrl
    });

    this.minorderquantityCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.constant.numberPattern), Validators.maxLength(8)]));
    this.orderunitidCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.packagesizeCtrl = new FormControl('', Validators.compose([Validators.required,
    // Validators.pattern(this.constant.numberPattern)]));
    // this.packageunitCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.noofpackageinboxCtrl = new FormControl('', Validators.compose([Validators.required,
    // Validators.pattern(this.constant.numberPattern)]));
    this.noofpackageinboxCtrl = new FormControl('', Validators.compose([
      Validators.pattern(this.constant.numberPattern)]));

    this.noofpackageinboxunitidCtrl = new FormControl(UnitEnum.PACK, Validators.compose([Validators.pattern(this.constant.numberPattern)]));

    // this.noofboxinpalletCtrl = new FormControl('', Validators.compose([Validators.required,
    // Validators.pattern(this.constant.numberPattern)]));

    // this.noofboxinpalletCtrl = new FormControl('', Validators.compose([Validators.pattern(
    // this.constant.numberPattern)]));

    // this.noofboxinpalletunitidCtrl = new FormControl(UnitEnum.BOX);
    // this.approximateweightofpalletCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.approximateweightofpalletunitidCtrl = new FormControl(UnitEnum.KGS, Validators.compose([Validators.required]));
    // this.lengthCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.breadthCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.heightCtrl = new FormControl('', Validators.compose([Validators.required]));
    // this.weightCtrl = new FormControl('', Validators.compose([Validators.required]));

    this.packagingInfoGroup = new FormGroup({
      minorderquantity: this.minorderquantityCtrl,
      orderunitid: this.orderunitidCtrl,
      // packagesize: this.packagesizeCtrl,
      // packageunit: this.packageunitCtrl,
      noofpackageinbox: this.noofpackageinboxCtrl,
      noofpackageinboxunitid: this.noofpackageinboxunitidCtrl,
      // noofboxinpallet: this.noofboxinpalletCtrl,
      // noofboxinpalletunitid: this.noofboxinpalletunitidCtrl,
      // approximateweightofpallet: this.approximateweightofpalletCtrl,
      // approximateweightofpalletunitid: this.approximateweightofpalletunitidCtrl,
      // length: this.lengthCtrl,
      // breadth: this.breadthCtrl,
      // height: this.heightCtrl,
      // weight: this.weightCtrl,
    });

    this.competingGroup = new FormGroup({
      competingItemsArray: new FormArray([])
    });

    this.addCompetingItem('', '', '');

    this.productQualityLevelCtrl = new FormControl(2, Validators.compose([Validators.required]));
    this.productPositioningGroup = new FormGroup({
      productQualityLevel: this.productQualityLevelCtrl,
    });

    this.isavaialbleimmediateCtrl = new FormControl(1, Validators.compose([Validators.required]));
    this.avaialblefromCtrl = new FormControl('');
    this.avaialbilitycommentCtrl = new FormControl('');

    this.availablityFormGroup = new FormGroup({
      isavaialbleimmediate: this.isavaialbleimmediateCtrl,
      avaialblefrom: this.avaialblefromCtrl,
      avaialbilitycomment: this.avaialbilitycommentCtrl
    });

  }

  addCompetingItem(productName: string, competitor: string, competitorproducturl: string, productcompetingid: number = 0) {
    this.competingItemsArray = this.competingGroup.get('competingItemsArray') as FormArray;
    this.competingItemsArray.push(this.buildItem(this.competingItemsArray.length, productName, competitor,
      competitorproducturl, productcompetingid));
  }

  deleteItem(type, index, id) {
    this.competingItemsArray.removeAt(index);
    if (id.toString().length > 0 && id !== 0 && this.actionType === ActionType.UPDATE) {
      this.deletedCompetingProduct.push(id);
    }
  }

  buildItem(index, productName: string, competitor: string, competitorproducturl: string, productcompetingid: number) {
    let controls = {};
    // controls = {
    //   competingproduct: new FormControl(productName, Validators.compose([Validators.required,
    //   Validators.minLength(3), Validators.maxLength(255)])),
    //   competitor: new FormControl(competitor, Validators.compose([Validators.required, Validators.maxLength(255)])),
    //   competitorproducturl: new FormControl(competitorproducturl, Validators.compose([
    //     Validators.required, Validators.maxLength(255), Validators.pattern(this.constant.urlPattern)])),
    // };

    controls = {
      competingproduct: new FormControl(productName, Validators.compose([
        Validators.minLength(3), Validators.maxLength(255)])),
      competitor: new FormControl(competitor, Validators.compose([Validators.maxLength(255)])),
      competitorproducturl: new FormControl(competitorproducturl, Validators.compose([
        Validators.maxLength(255),
        //  Validators.pattern(this.constant.urlPattern)
      ])),
    };

    if (productcompetingid !== 0) {
      controls['productcompetingid'] = new FormControl(productcompetingid);
    }
    return new FormGroup(controls);
  }

  loadUnits() {
    this.sharedBusiness.getUnits(true).subscribe(response => {
      const result = (response as Response).json();
      if ((<Response>response).ok) {
        this.unitList = <Array<Unit>>result;
      }
    });
  }

  loadDiscounts() {
    this.sharedBusiness.getDiscounts(true).subscribe(response => {
      const result = (response as Response).json();
      if ((<Response>response).ok) {
        this.discountList = <Array<Discount>>result;
        // const discountUnitId = this.discountList.filter(item => item.discountUnit.toLowerCase()
        //  === DiscountUnit.PERCENTAGE.toLowerCase())[0].discountUnitId;
        // this.distributormarginpercentunitidCtrl.setValue(discountUnitId);
        // this.retailermarginpercentunitidCtrl.setValue(discountUnitId);
      }
    });
  }

  getProductAttributes(): ProductCodeAdd {
    const productCodeAdd = new ProductCodeAdd();
    productCodeAdd.hasanyvariant = this.variantCtrl.value.toString();
    if (this.variantCtrl.value === 1) {
      productCodeAdd.variantdetails = this.variantTextCtrl.value;
    }

    const productCodeTypes = new Array<ProductCodeType>();
    const productUPC = this.productUPCCtrl.value;
    if (productUPC && productUPC.length > 0) {
      const upc = <ProductCodeType>{ 'productuniversalcodetype': UniversalCodeType.UPC, 'code': productUPC };
      if (this.productUPCid > 0) {
        upc['productuniversalcodeid'] = this.productUPCid;
      }

      productCodeTypes.push(upc);
    }

    const productEAN = this.productEANCtrl.value;
    const ean = <ProductCodeType>{ 'productuniversalcodetype': UniversalCodeType.EAN, 'code': productEAN };
    if (this.productEANid > 0) {
      ean['productuniversalcodeid'] = this.productEANid;
    }
    productCodeTypes.push(ean);

    const productHSN = this.productHSNCtrl.value;
    if (productHSN && productHSN.length > 0) {
      const hsn = <ProductCodeType>{ 'productuniversalcodetype': UniversalCodeType.HSN, 'code': productHSN };
      if (this.productHSNid > 0) {
        hsn['productuniversalcodeid'] = this.productHSNid;
      }

      productCodeTypes.push(hsn);
    }

    productCodeAdd.productCodeTypes = productCodeTypes;
    return productCodeAdd;
  }

  getPriceDetails(): ProductPrice {
    const productPrice = this.priceDetailGroup.value as ProductPrice;
    productPrice.currencyid = parseInt(productPrice.currencyid.toString(), 10);

    if (this.priceDetailGroup.value.issamplefree !== true) {
      productPrice.sampleprice = parseFloat(productPrice.sampleprice.toString());
      productPrice.samplepriceunitid = parseInt(this.priceDetailGroup.value.samplepriceunitid, 10);
    } else {
      productPrice.samplepriceunitid = 0;
      productPrice.sampleprice = 0;
    }
    productPrice.issamplefree = this.priceDetailGroup.value.issamplefree === true ? '1' : '0';

    if (this.priceDetailGroup.value.isunlimitsample !== true) {
      productPrice.samplethreshold = parseInt(this.priceDetailGroup.value.samplethreshold.toString(), 10);
    } else {
      productPrice.samplethreshold = 0;
    }
    productPrice.isunlimitsample = this.priceDetailGroup.value.isunlimitsample === true ? '1' : '0';
    // productPrice.distributormarginpercent = parseFloat(productPrice.distributormarginpercent.toString());
    // productPrice.retailermarginpercent = parseFloat(productPrice.retailermarginpercent.toString());
    // productPrice.samplethreshold = parseInt(productPrice.samplethreshold.toString(), 10);
    // productPrice.distributormarginpercentunitid = parseInt(this.priceDetailGroup.value.distributormarginpercentunitid, 10);
    // productPrice.retailermarginpercentunitid = parseInt(this.priceDetailGroup.value.retailermarginpercentunitid, 10);
    productPrice.retailerprice = parseFloat(this.priceDetailGroup.value.retailerprice);
    productPrice.retailerpriceunitid = parseInt(this.priceDetailGroup.value.retailerpriceunitid, 10);
    return productPrice;
  }

  getProductPackageInfo(): ProductPackageInfo {
    const packageInfo = this.packagingInfoGroup.value as ProductPackageInfo;
    packageInfo.orderunitid = parseInt(this.orderunitidCtrl.value.toString(), 10);
    // packageInfo.packageunit = parseInt(this.packageunitCtrl.value.toString(), 10);
    packageInfo.minorderquantity = parseInt(this.minorderquantityCtrl.value.toString(), 10);
    // packageInfo.packagesize = parseInt(this.packagesizeCtrl.value.toString(), 10);
    if (this.noofpackageinboxCtrl.value) {
      packageInfo.noofpackageinbox = parseInt(this.noofpackageinboxCtrl.value.toString(), 10);
      packageInfo.noofpackageinboxunitid = parseInt(this.noofpackageinboxunitidCtrl.value.toString(), 10);
    } else {
      packageInfo.noofpackageinbox = null;
      packageInfo.noofpackageinboxunitid = null;
    }

    // if (this.noofboxinpalletCtrl.value) {
    //   packageInfo.noofboxinpallet = parseInt(this.noofboxinpalletCtrl.value.toString(), 10);
    //   packageInfo.noofboxinpalletunitid = parseInt(this.noofboxinpalletunitidCtrl.value.toString(), 10);
    // } else {
    //   packageInfo.noofboxinpallet = null;
    //   packageInfo.noofboxinpalletunitid  = null;
    // }

    // packageInfo.approximateweightofpallet = parseInt(this.approximateweightofpalletCtrl.value.toString(), 10);
    // packageInfo.length = parseInt(this.lengthCtrl.value.toString(), 10);
    // packageInfo.breadth = parseInt(this.breadthCtrl.value.toString(), 10);
    // packageInfo.height = parseInt(this.heightCtrl.value.toString(), 10);
    // packageInfo.weight = parseInt(this.weightCtrl.value.toString(), 10);
    // packageInfo.approximateweightofpalletunitid = parseInt(this.approximateweightofpalletunitidCtrl.value.toString(), 10);
    return packageInfo;
  }

  getProductPosition(): ProductPosition {
    const productPosition = new ProductPosition();
    if (this.productQualityLevelCtrl.value === 1) {
      productPosition.productqualitylevel = ProductQuality.Entry;
    } else if (this.productQualityLevelCtrl.value === 2) {
      productPosition.productqualitylevel = ProductQuality.Mid;
    } else {
      productPosition.productqualitylevel = ProductQuality.High;
    }

    return productPosition;
  }

  getProductCompeting(): ProductCompetingAdd {
    const productCompetingAdd = new ProductCompetingAdd();
    productCompetingAdd.productcompeting = new Array<Productcompeting>();
    for (let i = 0; i < this.competingItemsArray.controls.length; i++) {
      const tempFormGroup = this.competingItemsArray.controls[i] as FormGroup;
      // if (this.actionType === ActionType.UPDATE) {
      //   if (tempFormGroup.dirty) {
      //     productCompetingAdd.productcompeting.push(this.competingItemsArray.controls[i].value);
      //   }
      // } else {
      //   productCompetingAdd.productcompeting.push(this.competingItemsArray.controls[i].value);
      // }

      const competingproductCtrl = this.competingItemsArray.controls[i].get('competingproduct');
      const competitorproducturlCtrl = this.competingItemsArray.controls[i].get('competitorproducturl');
      const competitorCtrl = this.competingItemsArray.controls[i].get('competitor');

      if (tempFormGroup.dirty && competingproductCtrl.value && competitorproducturlCtrl.value
        && competitorCtrl.value) {
        productCompetingAdd.productcompeting.push(this.competingItemsArray.controls[i].value);
      }
    }
    return productCompetingAdd;
  }

  preFillProductAttributes(productSku: string, universalCodes: ProductUniversalCode[],
    hasVariant: string, VariantDesc: string) {
    this.productSKU = productSku;
    if (universalCodes) {
      universalCodes.forEach(result => {
        const productuniversalcodeid = parseInt(result.productuniversalcodeid, 10);
        if (result.productuniversalcodetype === UniversalCodeType.UPC) {
          this.productUPCid = productuniversalcodeid;
          this.productUPCCtrl.setValue(result.code);
        } else if (result.productuniversalcodetype === UniversalCodeType.EAN) {
          this.productEANid = productuniversalcodeid;
          this.productEANCtrl.setValue(result.code);
        } else if (result.productuniversalcodetype === UniversalCodeType.HSN) {
          this.productHSNid = productuniversalcodeid;
          this.productHSNCtrl.setValue(result.code);
        }
      });

      this.variantCtrl.setValue(parseInt(hasVariant, 10));
      if (hasVariant === '1') {
        this.onVariantCheck(1);
        this.variantTextCtrl.setValue(VariantDesc);
      }
    }
  }

  preFillPriceDetails(_productPriceDetail: ProductPriceDetail) {
    this.currencyidCtrl.setValue(_productPriceDetail.businesscurrencyid ? _productPriceDetail.businesscurrencyid : '');
    this.retailerPriceCtrl.setValue(parseFloat(_productPriceDetail.retailerprice));
    this.retailerUnitCtrl.setValue(_productPriceDetail.retailerpriceunitid);
    // this.distributorMarginCtrl.setValue(_productPriceDetail.distributormarginpercent);
    // this.retailerMarginCtrl.setValue(_productPriceDetail.retailermarginpercent);

    if (_productPriceDetail.issamplefree === '1') {
      this.issamplefreeCtrl.setValue(true);
      this.samplePriceCtrl.disable();
      this.samplePriceUnitCtrl.disable();
    } else {
      this.issamplefreeCtrl.setValue(false);
      this.samplePriceCtrl.setValue(parseFloat(_productPriceDetail.sampleprice));
      this.samplePriceUnitCtrl.setValue(_productPriceDetail.samplepriceunitid);
    }

    if (_productPriceDetail.isunlimitsample === '1') {
      this.isunlimitsampleCtrl.setValue(true);
      this.samplethresholdCtrl.disable();

    } else {
      this.samplethresholdCtrl.setValue(false);
      this.samplethresholdCtrl.setValue(_productPriceDetail.samplethreshold);
    }

    // this.distributormarginpercentunitidCtrl.setValue(_productPriceDetail.distributormarginpercentunitid);
    // this.retailermarginpercentunitidCtrl.setValue(_productPriceDetail.retailermarginpercentunitid);
  }

  preFillPackagingInfo(productPackageInfo: ProductPackageInfoGet) {
    // this.lengthCtrl.setValue(productPackageInfo.length ? parseInt(productPackageInfo.length, 10) : 0);
    // this.breadthCtrl.setValue(productPackageInfo.breadth ? parseInt(productPackageInfo.breadth, 10) : 0);
    // this.heightCtrl.setValue(productPackageInfo.height ? parseInt(productPackageInfo.height, 10) : 0);
    // this.weightCtrl.setValue(productPackageInfo.weight ? parseInt(productPackageInfo.weight, 10) : 0);
    this.minorderquantityCtrl.setValue(parseInt(productPackageInfo.minorderquantity, 10));
    this.orderunitidCtrl.setValue(productPackageInfo.orderunitid);
    // this.packagesizeCtrl.setValue(parseInt(productPackageInfo.packagesize, 10));
    // this.packageunitCtrl.setValue(productPackageInfo.packageunit);

    if (productPackageInfo.noofpackageinbox) {
      this.noofpackageinboxCtrl.setValue(parseInt(productPackageInfo.noofpackageinbox, 10));
    }

    if (productPackageInfo.noofpackageinboxunitid) {
      this.noofpackageinboxunitidCtrl.setValue(parseInt(productPackageInfo.noofpackageinboxunitid, 10));
    }

    // if (productPackageInfo.noofboxinpallet) {
    //   this.noofboxinpalletCtrl.setValue(parseInt(productPackageInfo.noofboxinpallet, 10));
    // }

    // if (productPackageInfo.noofboxinpalletunitid) {
    //   this.noofboxinpalletunitidCtrl.setValue(productPackageInfo.noofboxinpalletunitid);
    // }

    // if (productPackageInfo.approximateweightofpallet) {
    //   this.approximateweightofpalletCtrl.setValue(parseInt(productPackageInfo.approximateweightofpallet, 10));
    //   // this.approximateweightofpalletunitidCtrl.setValue(productPackageInfo.approximateweightofpalletunitid);
    // } else {
    //   this.calculateApprWeightOfPallets();
    // }

  }

  preFillProductPosition(productqualitylevel) {
    if (productqualitylevel === ProductQuality.Entry) {
      this.productQualityLevelCtrl.setValue(1);
    } else if (productqualitylevel === ProductQuality.Mid) {
      this.productQualityLevelCtrl.setValue(2);
    } else {
      this.productQualityLevelCtrl.setValue(3);
    }
  }

  preFillCompetingProduct(productCompetings: ProductCompetingGet[]) {
    if (productCompetings && productCompetings.length > 0) {
      this.competingItemsArray.removeAt(0);
      for (let i = 0; i < productCompetings.length; i++) {
        this.addCompetingItem(productCompetings[i].competingproduct, productCompetings[i].competitor,
          productCompetings[i].competitorproducturl, this.actionType ===
            ActionType.UPDATE ? parseInt(productCompetings[i].productcompetingid, 10) : 0);
      }
    }
  }

  onVariantCheck(value: number) {
    if (value === 0) {
      this.productCodeGroup.controls['variantText'].clearValidators();
      this.productCodeGroup.controls['variantText'].setErrors(null);
    } else {
      this.productCodeGroup.controls['variantText'].setValidators([Validators.required, Validators.minLength(3)]);
      // this.productCodeGroup.controls['variantText'].markAsTouched();
    }
  }

  isSampleFreeChecked() {
    if (this.priceDetailGroup.controls['issamplefree'].value === true) {
      this.priceDetailGroup.controls['sampleprice'].disable();
      this.priceDetailGroup.controls['samplepriceunitid'].disable();
      this.priceDetailGroup.controls['sampleprice'].clearValidators();
      this.priceDetailGroup.controls['sampleprice'].setErrors(null);
      this.priceDetailGroup.controls['samplepriceunitid'].clearValidators();
      this.priceDetailGroup.controls['samplepriceunitid'].setErrors(null);
      this.priceDetailGroup.controls['sampleprice'].setValue('');
      this.priceDetailGroup.controls['samplepriceunitid'].setValue('');
      this.validateContainsZero('', 'sampleprice');
    } else {
      this.priceDetailGroup.controls['sampleprice'].enable();
      this.priceDetailGroup.controls['samplepriceunitid'].enable();
      this.priceDetailGroup.controls['sampleprice'].setValidators([Validators.required,
      Validators.pattern(this.constant.floatingNumberPattern)]);
      this.priceDetailGroup.controls['samplepriceunitid'].setValidators([Validators.required]);
      this.priceDetailGroup.controls['sampleprice'].markAsTouched();
      this.priceDetailGroup.controls['samplepriceunitid'].markAsTouched();
      this.priceDetailGroup.controls['sampleprice'].setValue('');
      this.priceDetailGroup.controls['samplepriceunitid'].setValue('');
    }
  }

  isSampleThresholdCheck() {
    if (this.priceDetailGroup.controls['isunlimitsample'].value === true) {
      this.priceDetailGroup.controls['samplethreshold'].disable();
      this.priceDetailGroup.controls['samplethreshold'].clearValidators();
      this.priceDetailGroup.controls['samplethreshold'].setErrors(null);
      this.priceDetailGroup.controls['samplethreshold'].setValue('');
      this.validateContainsZero('', 'samplethreshold');
    } else {
      this.priceDetailGroup.controls['samplethreshold'].enable();
      this.priceDetailGroup.controls['samplethreshold'].setValidators([Validators.required,
      Validators.pattern(this.constant.numberPattern)]);
      this.priceDetailGroup.controls['samplethreshold'].markAsTouched();
      this.priceDetailGroup.controls['samplethreshold'].setValue('');
    }
  }

  checkValidate() {
    let checkFlag = true;
    this.markFormGroupTouched(this.productCodeGroup);
    this.markFormGroupTouched(this.priceDetailGroup);
    this.markFormGroupTouched(this.packagingInfoGroup);
    this.markFormGroupTouched(this.productPositioningGroup);
    this.markFormGroupTouched(this.competingGroup);
    this.scrollToElementId = '';
    if (this.priceDetailGroup.invalid || this.packagingInfoGroup.invalid || this.productPositioningGroup.invalid
      || this.productCodeGroup.invalid || this.competingGroup.invalid || this.isPriceDetailInvalid || this.availablityFormGroup.invalid) {
      checkFlag = false;
      if (this.productCodeGroup.invalid) {
        this.scrollToElementId = 'productCodeGroupBlockId';
      } else if (this.priceDetailGroup.invalid || this.isPriceDetailInvalid) {
        this.scrollToElementId = 'priceDetailGroupBlockId';
      } else if (this.packagingInfoGroup.invalid) {
        this.scrollToElementId = 'packagingInfoGroupBlockId';
      } else if (this.competingGroup.invalid) {
        this.scrollToElementId = 'competingGroupBlockId';
        this.competingItemsArray.controls.forEach((item, index) => {
          if (item.invalid && this.scrollToElementId !== '') {
            this.scrollToElementId = 'competingGroupBlockId' + index;
          }
        });
      } else if (this.productPositioningGroup.invalid) {
        this.scrollToElementId = 'productPositioningGroupBlockId';
      } else if (this.availablityFormGroup.invalid) {
        this.scrollToElementId = 'availableId';
      }
      // if (this.isavaialbleimmediateCtrl.value === 0) {
      //   // this.isAvailableCheck(0);
      //   if (this.avaialblefromCtrl.invalid || this.avaialbilitycommentCtrl.invalid) {
      //     checkFlag = false;
      //     if (!this.scrollToElementId) {
      //       this.scrollToElementId = 'availableId';
      //     }
      //   }
      // }
      this.scrollService.scrollTo(document.getElementById(this.scrollToElementId), 1000, -100);
    }
    return checkFlag;
  }

  // markFormGroupTouched(formGroup: FormGroup) {
  //   console.log('check', formGroup.controls);

  //   //(<any>Object).values(formGroup.controls).forEach(control => {
  //   for (const field in formGroup.controls) {
  //     const control = formGroup.get(field);
  //     /*if (control) { // control is a FormGroup
  //       this.markFormGroupTouched(control);
  //     } else { // control is a FormControl*/
  //     //this.markFormGroupTouched(formGroup);
  //     control.markAsTouched();
  //     // }
  //   };
  // }

  markFormGroupTouched(formGroup) {
    const keys = Object.keys(formGroup.controls);
    keys.forEach(val => {
      const ctrl = formGroup.controls[val];
      if (!ctrl.valid) {
        ctrl.markAsTouched();
      }
    });
  }

  // calculateApprWeightOfPallets() {
  //   let length = 0, breadth = 0, height = 0;
  //   length = this.lengthCtrl.valid ? parseInt(this.lengthCtrl.value, 10) : 0;
  //   breadth = this.breadthCtrl.valid ? parseInt(this.breadthCtrl.value, 10) : 0;
  //   height = this.heightCtrl.valid ? parseInt(this.heightCtrl.value, 10) : 0;
  //   this.approximateweightofpalletCtrl.setValue((length * breadth * height) / 5000);
  // }

  public scrollToFirstElement() {
    const scrollElement = 'productCodeGroupBlockId';
    this.scrollService.scrollTo(document.getElementById(scrollElement), 1000, 0);
  }

  // onDistributionKeyUp(value) {
  //   if (this.distributorMarginCtrl.value) {
  //     if (!value.match(this.constant.floatingNumberPattern)) {
  //       this.distributorMarginErrCode = '0001';
  //       this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //     } else {
  //       const distributionVal = parseFloat(value);
  //       if (distributionVal <= 0) {
  //         this.distributorMarginErrCode = '0002';
  //         this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //       } else if (distributionVal > 100) {
  //         this.distributorMarginErrCode = '0003';
  //         this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //       } else {
  //         this.distributorMarginErrCode = '';
  //         this.distributorMarginCtrl.setErrors(null);
  //       }
  //     }
  //   } else {
  //     this.distributorMarginErrCode = '';
  //     this.distributorMarginCtrl.clearValidators();
  //     this.distributorMarginCtrl.setValidators([Validators.required]);
  //     this.distributorMarginCtrl.markAsTouched();
  //     // this.distributorMarginCtrl.setValidators([Validators.required]);
  //   }
  // }

  // onRetailerKeyUp(value) {
  //   if (this.retailerMarginCtrl.value) {
  //     if (!value.match(this.constant.floatingNumberPattern)) {
  //       this.retailerMarginErrCode = '0001';
  //       this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //     } else {
  //       const retailerVal = parseFloat(value);
  //       if (retailerVal <= 0) {
  //         this.retailerMarginErrCode = '0002';
  //         this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //       } else if (retailerVal > 100) {
  //         this.retailerMarginErrCode = '0003';
  //         this.distributorMarginCtrl.setErrors({ 'incorrect': true });
  //       } else {
  //         this.retailerMarginErrCode = '';
  //         this.distributorMarginCtrl.setErrors(null);
  //       }
  //     }
  //   } else {
  //     this.retailerMarginErrCode = '';
  //     this.retailerMarginCtrl.clearValidators();
  //     this.retailerMarginCtrl.setValidators([Validators.required]);
  //     this.retailerMarginCtrl.markAsTouched();
  //   }
  // }

  addOrRemoveCompetitorValidation(index) {
    const competingproductCtrl = this.competingItemsArray.controls[index].get('competingproduct');
    const competitorproducturlCtrl = this.competingItemsArray.controls[index].get('competitorproducturl');
    const competitorCtrl = this.competingItemsArray.controls[index].get('competitor');

    if (!competingproductCtrl.value && !competitorproducturlCtrl.value && !competitorCtrl.value) {
      competingproductCtrl.clearValidators();
      competingproductCtrl.setErrors(null);
      competitorproducturlCtrl.clearValidators();
      competitorproducturlCtrl.setErrors(null);
      competitorCtrl.clearValidators();
      competitorCtrl.setErrors(null);
    } else {
      competingproductCtrl.setValidators([Validators.compose([Validators.required,
      Validators.minLength(3), Validators.maxLength(255)])]);
      competingproductCtrl.setValue(competingproductCtrl.value);
      competingproductCtrl.markAsTouched();

      competitorproducturlCtrl.setValidators(Validators.compose([Validators.required,
      Validators.maxLength(255),
        //  Validators.pattern(this.constant.urlPattern)
      ]));
      competitorproducturlCtrl.setValue(competitorproducturlCtrl.value);
      competitorproducturlCtrl.markAsTouched();

      competitorCtrl.setValidators(Validators.compose([Validators.required, Validators.maxLength(255)]));
      competitorCtrl.setValue(competitorCtrl.value);
      competitorCtrl.markAsTouched();
    }
  }

  // To get currency convertions
  getCurrencyConverionTable() {
    this.sharedService.getCurrencyConversionList().subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        localStorage.setItem(AppLocalStorageKeys.CURRENCY_CONVERTION_TABLE, JSON.stringify(result.body));
        this.currencyDetails = result.body;
        if (this.actionType === ActionType.ADD) {
          this.currencyidCtrl.setValue(this.userCurrency);
        }
      }
    },
      (error) => {
        console.log(error);
      });
  }

  // onSamplePriceKeyUp(value) {
  //   if (!value.match(this.constant.floatingNumberPattern)) {
  //     this. = '0001';
  //     this.samplePriceCtrl.setErrors({ 'incorrect': true });
  //   } else {

  //   }
  // }

  validateContainsZero(val, ctrl: string) {
    ctrl = ctrl.toLowerCase();
    // tslint:disable-next-line:triple-equals
    if (val && val.trim() == '0') {
      if (ctrl === 'moq') {
        this.minorderquantityErrCode = '0001';
      } else if (ctrl === 'msrp') {
        this.retailerPriceErrCode = '0001';
      } else if (ctrl === 'sampleprice') {
        this.samplePriceErrCode = '0001';
      } else if (ctrl === 'noofpackageinbox') {
        this.noofpackageinboxErrCode = '0001';
      } else if (ctrl === 'samplethreshold') {
        this.samplethresholdErrCode = '0001';
      }

      this.isPriceDetailInvalid = true;
    } else {
      if (ctrl === 'moq') {
        this.minorderquantityErrCode = '';
      } else if (ctrl === 'msrp') {
        this.retailerPriceErrCode = '';
      } else if (ctrl === 'sampleprice') {
        this.samplePriceErrCode = '';
      } else if (ctrl === 'noofpackageinbox') {
        this.noofpackageinboxErrCode = '';
      } else if (ctrl === 'samplethreshold') {
        this.samplethresholdErrCode = '';
      }

      this.isPriceDetailInvalid = false;
    }
  }

  preFillAvailability(isavaialbleimmediate: string, avaialblefrom: string, avaialbilitycomment: string) {
    if (isavaialbleimmediate) {
      const availableImmediate = parseInt(isavaialbleimmediate, 10);
      this.isAvailableCheck(availableImmediate);
      if (availableImmediate === 0) {
        this.isavaialbleimmediateCtrl.setValue(availableImmediate);
        // this.avaialblefromCtrl.setValue(avaialblefrom ? moment(avaialblefrom).format('DD/MMYYYY') : null);
        this.avaialblefromCtrl.setValue(avaialblefrom ? new Date(avaialblefrom) : null);
        this.avaialbilitycommentCtrl.setValue(avaialbilitycomment ? avaialbilitycomment : '');
      } else {
        this.isavaialbleimmediateCtrl.setValue(1);
      }
    }
  }

  isAvailableCheck(value: number) {
    if (value === 0) {
      this.availablityFormGroup.controls['avaialblefrom'].setValidators([Validators.required]);
      this.availablityFormGroup.controls['avaialbilitycomment'].setValidators([Validators.required, Validators.minLength(10),
      Validators.maxLength(8000)]);
      const availableFrom = this.avaialblefromCtrl.value;
      const availableComment = this.avaialbilitycommentCtrl.value;
      this.availablityFormGroup.controls['avaialblefrom'].setValue(availableFrom ? availableFrom : '');
      this.availablityFormGroup.controls['avaialbilitycomment'].setValue(availableComment ? availableComment : '');
      this.availablityFormGroup.controls['avaialblefrom'].markAsTouched();
      this.availablityFormGroup.controls['avaialbilitycomment'].markAsTouched();
      this.availablityFormGroup.controls['avaialblefrom'].markAsDirty();
      this.availablityFormGroup.controls['avaialbilitycomment'].markAsDirty();
    } else {
      this.availablityFormGroup.controls['avaialblefrom'].setValue('');
      this.availablityFormGroup.controls['avaialbilitycomment'].setValue('');
      this.availablityFormGroup.controls['avaialblefrom'].clearValidators();
      this.availablityFormGroup.controls['avaialblefrom'].setErrors(null);
      this.availablityFormGroup.controls['avaialbilitycomment'].clearValidators();
      this.availablityFormGroup.controls['avaialbilitycomment'].setErrors(null);
    }
  }

  getAvailability(): ProductAvailability {
    const _productAvailability = new ProductAvailability();
    _productAvailability.isavaialbleimmediate = this.isavaialbleimmediateCtrl.value.toString();
    if (this.isavaialbleimmediateCtrl.value === 0) {
      // _productAvailability.avaialblefrom = moment(this.avaialblefromCtrl.value, 'YYYY/MM/DD').toDate();
      const availableDate = new Date(this.avaialblefromCtrl.value);
      // _productAvailability.avaialblefrom = availableDate.getDate() + '/' + availableDate.getMonth() + '/' + availableDate.getFullYear();
      _productAvailability.avaialblefrom = availableDate;
      _productAvailability.avaialbilitycomment = this.avaialbilitycommentCtrl.value;
    }

    return _productAvailability;
  }
}
