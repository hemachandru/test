import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { ProductTab, ActionType } from '@app/config/constant';
import { TabsContainer } from 'angular-tabs-component';
import { GeneralComponent } from './../general/general.component';
import { TradeDetailsComponent } from './../trade-details/trade-details.component';
import { DistributionChannelsComponent } from './../distribution-channels/distribution-channels.component';
import { ChannelInfos, APIError } from '@app/shared/models/shared-model';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { Response } from '@angular/http';
import { AddProduct, ProductSellingLocation, ProductTargetLocation, PageAction } from '../../models/add-product';
import { ProductBusiness } from '../../business/product.business';
import { MatDialog } from '@angular/material';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ProductGet } from '../../models/get-product';
import { ToastrService } from 'ngx-toastr';
import { ScrollToService } from 'ng2-scroll-to-el';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { TranslateService } from '@ngx-translate/core';
import { WebUrl } from '@app/config/constant_keys';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})

export class AddProductComponent implements OnInit, OnDestroy {
  public webUrl = WebUrl;
  public productTab;
  public title;
  @ViewChild(GeneralComponent) generalComponent: GeneralComponent;
  @ViewChild(TradeDetailsComponent) tradeDetailsComponent: TradeDetailsComponent;
  @ViewChild(DistributionChannelsComponent) distributionChannelsComponent: DistributionChannelsComponent;
  @ViewChild(TabsContainer) tabsContainer: TabsContainer;
  public preLoader: boolean;
  channelInfos: ChannelInfos;
  public buttonName: string;
  public addProduct: AddProduct;
  public isPrevTabSelected: boolean;
  public isTabLoadedFirstTime: boolean;
  public activeTabIndex: number;
  public _ProductSKUAction: PageAction;
  public productSku: string;
  public loaderStarter: boolean;
  productDetail: ProductGet;
  public productActionType: number;
  timerId: any;
  navigationSubscription: any;
  public actionType = ActionType;
  constructor(private sharedBusiness: SharedBusiness, private productBusiness: ProductBusiness,
    public dialog: MatDialog, private router: Router, private route: ActivatedRoute,
    private toastr: ToastrService, private scrollService: ScrollToService, private authorizeService: AuthorizeService,
    private translate: TranslateService) {
    this.productTab = ProductTab;
    this.title = 'addProduct.title';
    this.buttonName = 'shared.buttonLabels.next';
    this.isPrevTabSelected = false;
    this.activeTabIndex = 0;
    this.isTabLoadedFirstTime = true;
    this.productActionType = ActionType.ADD;
    this._ProductSKUAction = new PageAction();
    this._ProductSKUAction.value = '';
    this.loaderStarter = false;
    // if (CommonHelper.getStripeIDLocally() === '0') {
    //   this.router.navigate(['product/productlist']);
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   return;
    // }

    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.initialiseInvites();
      }
    });
  }

  initialiseInvites() {
    this.route.queryParams.subscribe(params => {
      if (params.sku) {
        this._ProductSKUAction.value = params.sku || '';
      }

      if (params.action) {
        this._ProductSKUAction.action = params.action;
        this.productActionType = parseInt(params.action.toString(), 10);
        if (this.productActionType === ActionType.UPDATE) {
          this.title = 'addProduct.edittitle';
        } else if (this.productActionType === ActionType.COPYORDUPLICATE) {
          this.title = 'addProduct.copytitle';
        }
      }
    });
  }

  ngOnInit() {
    this.preLoader = true;
    this.activeTabIndex = 0;
    this.distributionChannelsComponent.getCountryList();
    this.loadLocations();
    this.getShareTypeList();
  }

  getShareTypeList(): void {
    this.sharedBusiness.getShareTypeList(true).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.generalComponent.setShareTypeList(response);
        this.getChannelInfos();
      }
    },
      (error) => {
        console.log(error);
      });
  }

  loadLocations(): void {
    const channelId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID).toString(), 10);
    this.sharedBusiness.getChannelLocation(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.distributionChannelsComponent.setloadLocations(result);
      }
    });
  }


  getChannelInfos() {
    // this.preLoader = true;
    this.sharedBusiness.getChannelInfos(true).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.channelInfos = <ChannelInfos>response.json();
        this.generalComponent.setRequiredData(this.channelInfos.productGroup, this.channelInfos.productCategory,
          this.channelInfos.brand);
        this.distributionChannelsComponent.loadDistributionSearchList(this.channelInfos.RETAILER, this.channelInfos.DISTRIBUTOR);

        this.distributionChannelsComponent.preFillRelevantChannels(this.channelInfos.DISTRIBUTOR, this.channelInfos.RETAILER);
      }
      // (this.channelInfos.DISTRIBUTOR !== undefined) ? this.channelInfos.DISTRIBUTOR : [],
      // (this.channelInfos.RETAILER !== undefined) ? this.channelInfos.RETAILER : []);
      // (this.channelInfos.DISTRIBUTOR !== undefined) ? this.channelInfos.DISTRIBUTOR : [],
      // (this.channelInfos.RETAILER !== undefined) ? this.channelInfos.RETAILER : []
      if (this._ProductSKUAction && this._ProductSKUAction.action &&
        (this._ProductSKUAction.action.toString() === ActionType.UPDATE.toString() ||
          this._ProductSKUAction.action.toString() === ActionType.COPYORDUPLICATE.toString())
      ) {
        // this.productActionType = parseInt(this._ProductSKUAction.action, 10);
        this.getProductInfo();
      }
      // this.preLoader = false;
    },
      (error) => {
        console.log(error);
        this.preLoader = false;
      });
  }
  // endLoader(self) {
  //   self.preLoader = false;
  // }

  getProductInfo() {
    this.preLoader = true;
    this.productBusiness.getProductBySKU(this._ProductSKUAction.value).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.productDetail = <ProductGet>response.json();
        // fill GeneralComponent
        this.generalComponent.preFilllBasicInfo(this.productDetail.product, this.productDetail.productGroupId,
          this.productDetail.productCategorieId, this.productDetail.brandId, this.productDetail.isactive,
          this.productDetail.productDetail.productdesc, this.productDetail.productDetail.usp, this.productDetail.productTag);

        this.generalComponent.preFillArticlesAndReviews(this.productDetail.productArticleReview,
          this.productDetail.productExistRating);

        if (this.productActionType === ActionType.UPDATE && this.productDetail.images && this.productDetail.images.PRODUCT[0]) {
          const firstImage = this.productDetail.images.PRODUCT[0];
          const defaultImageIndex = this.productDetail.images.PRODUCT.findIndex(item => item.productimageid ===
            this.productDetail.defaultImage.productimageid && item.imageid === this.productDetail.defaultImage.imageid);
          // let temp = <ProductImageGet>{};
          const temp = this.productDetail.images.PRODUCT[defaultImageIndex];
          this.productDetail.images.PRODUCT[0] = temp;
          this.productDetail.images.PRODUCT[defaultImageIndex] = firstImage;
        }

        if (this.productActionType === ActionType.UPDATE) {
          this.generalComponent.preFillImagesAndBrouchures(this.productDetail.images, this.productDetail.productDetail.videourl);
        }

        if (this.productDetail.productAwards && this.productDetail.productAwards.length > 0) {
          this.generalComponent.preFillproductAwards(this.productDetail.productAwards);
        }
        this.generalComponent.preFillProductPreferences(this.productDetail.productSharePreference, this.productDetail.isshowtofreesub);
        // fill trade details
        this.tradeDetailsComponent.preFillProductAttributes(this.productDetail.productSKU, this.productDetail.productUniversalCode,
          this.productDetail.hasanyvariant, this.productDetail.variantdetails);
        this.tradeDetailsComponent.preFillPriceDetails(this.productDetail.productPriceDetail);
        this.tradeDetailsComponent.preFillPackagingInfo(this.productDetail.productPackageInfo);
        this.tradeDetailsComponent.preFillProductPosition(this.productDetail.productqualitylevel);
        this.tradeDetailsComponent.preFillCompetingProduct(this.productDetail.productCompeting);
        // fill DistributionChannelsComponent

        this.distributionChannelsComponent.preFillRelevantChannels(this.productDetail.DISTRIBUTOR, this.productDetail.RETAILER);
        // (this.productDetail.DISTRIBUTOR !== undefined) ? this.productDetail.DISTRIBUTOR : [],
        // (this.productDetail.RETAILER !== undefined) ? this.productDetail.RETAILER : []
        // this.distributionChannelsComponent.preFillKeyRetailers(this.productDetail.productKeyRetailer);
        // this.distributionChannelsComponent.getKeyRetailerOldNew(this.productDetail.productKeyRetailer, 1);
        this.distributionChannelsComponent.preFillKeyRetailerList(this.productDetail.productKeyRetailer, 1, '4');
        this.distributionChannelsComponent.preFillKeyRetailerList(this.productDetail.productKeyDistributor, 1, '3');

        // this.distributionChannelsComponent.filterKeyRetailersUpdate();
        this.tradeDetailsComponent.preFillAvailability(this.productDetail.productDetail.isavaialbleimmediate,
          this.productDetail.productDetail.avaialblefrom, this.productDetail.productDetail.avaialbilitycomment);
        this.distributionChannelsComponent.preFillLocations(this.productDetail.productLocation);
        if (this.productActionType === ActionType.UPDATE && this.productDetail.productDetail.keyretailers) {
          this.distributionChannelsComponent.retailerGroup.controls['retailernameDescription']
            .setValue(this.productDetail.productDetail.keyretailers);
        }
        if (this.productActionType === ActionType.UPDATE && this.productDetail.productDetail.keydistributors) {
          this.distributionChannelsComponent.retailerGroup.controls['distributornameDescription']
            .setValue(this.productDetail.productDetail.keydistributors);
        }
        this.preLoader = false;
      } else {
        this.preLoader = false;
      }
    },
      (error) => {
        console.log(error);
        this.preLoader = false;
      });
  }

  onSave(isSave?) {
    this.preLoader = true;
    if (this.OnSaveValidate(isSave)) {
      if (this.buttonName === 'shared.buttonLabels.save' || isSave) {
        if (this.buildSaveData()) {
          this.addProductData();
        } else {
          this.preLoader = false;
        }

      } else {
        this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
        if (this.activeTabIndex <= this.tabsContainer.tabs.length - 1) {
          const nextTab = this.tabsContainer.tabs[this.activeTabIndex + 1];
          this.tabsContainer.selectTab(nextTab);

        }
        this.preLoader = false;
      }
    } else {
      this.preLoader = false;
    }
  }

  onBack() {
    this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
    if (this.activeTabIndex > 0) {
      // this.activeTabIndex = this.activeTabIndex - 1;
      if (this.activeTabIndex === 2) {
        if (!this.distributionChannelsComponent.scrollToElementId || this.distributionChannelsComponent.checkValidate()) {
          this.activeTabIndex = this.activeTabIndex - 1;
          const prevTab = this.tabsContainer.tabs[this.activeTabIndex];
          this.tabsContainer.selectTab(prevTab);
          this.loaderStarter = true;
        }
      } else {
        this.loaderStarter = false;
        if (!this.tradeDetailsComponent.scrollToElementId || this.tradeDetailsComponent.checkValidate()) {
          this.activeTabIndex = this.activeTabIndex - 1;
          const nextTab = this.tabsContainer.tabs[this.activeTabIndex];
          this.tabsContainer.selectTab(nextTab);
        }
      }
    } else {
      this.router.navigate([this.webUrl.MY_PRODUCTLIST]);
    }
  }

  addProductData() {
    let title = '';
    let message = '';
    const sku = this._ProductSKUAction.action === ActionType.UPDATE.toString() ? this._ProductSKUAction.value : '';
    this.productBusiness.addProduct(this.addProduct, sku).subscribe(result => {
      const response = result as Response;
      this.preLoader = false;
      if (response.ok) {
        if (this._ProductSKUAction.action === ActionType.UPDATE.toString()) {
          title = this.translate.instant('addProduct.updatetitle');
          message = this.translate.instant('addProduct.successMsg.productUpdate');
        } else if (this._ProductSKUAction.action === ActionType.COPYORDUPLICATE.toString()) {
          title = this.translate.instant('addProduct.copytitle');
          message = this.translate.instant('addProduct.successMsg.productCopy');
        } else {
          title = this.translate.instant('addProduct.title');
          message = this.translate.instant('addProduct.successMsg.productAdd');
        }
        this.toastr.success(message, title);
        this.router.navigate([this.webUrl.MY_PRODUCTLIST]);
      } else {
        if (this._ProductSKUAction.action === ActionType.UPDATE.toString()) {
          title = this.translate.instant('addProduct.updatetitle');
          message = this.translate.instant('addProduct.errorMsg.failUpdateproduct');
        } else if (this._ProductSKUAction.action === ActionType.COPYORDUPLICATE.toString()) {
          title = this.translate.instant('addProduct.copytitle');
          message = this.translate.instant('addProduct.errorMsg.failCopyproduct');
        } else {
          title = this.translate.instant('addProduct.title');
          message = this.translate.instant('addProduct.errorMsg.faileAddproduct');
        }

        const errorResponse = response.json() as Array<APIError>;
        // tslint:disable-next-line:triple-equals
        const error = errorResponse.filter(item => item.property === false)[0];
        if (error && error.errors) {
          // tslint:disable-next-line:triple-equals
          const innerError = error.errors.filter(item => item.message && item.message.eligibleCount);
          if (innerError && innerError.length > 0) {
            message = innerError[0].message.message;
          }
        }

        this.toastr.error(message, title);
      }
    },
      (error) => {
        console.log(error);
        this.preLoader = false;
      });
  }

  buildSaveData(): boolean {
    let returnVal = false;
    // General Tab
    this.addProduct = new AddProduct();
    this.addProduct.productBasicInfo = this.generalComponent.getBasicInfo();
    // if (this.distributionChannelsComponent.retailerGroup.controls['retailernameDescription'].value !== null) {
    this.addProduct.productBasicInfo.keyretailers =
      this.distributionChannelsComponent.retailerGroup.controls['retailernameDescription'].value;
    this.addProduct.productBasicInfo.keydistributors =
      this.distributionChannelsComponent.retailerGroup.controls['distributornameDescription'].value;
    // }

    this.getArticlesReviews();

    this.getProductImages();
    this.getProductBrochure();
    this.addProduct.productPreferences = this.generalComponent.getProductPreferences();
    this.getAwardDetailRecords();
    // Trade Details Tab
    this.addProduct.productCode = this.tradeDetailsComponent.getProductAttributes();
    this.addProduct.productPrice = this.tradeDetailsComponent.getPriceDetails();

    this.getProductPackageInfo();
    this.addProduct.productPosition = this.tradeDetailsComponent.getProductPosition();
    this.getProductCompeting();

    // Distribution Channel Tab
    // this.addProduct.productRelevantChannel = this.distributionChannelsComponent.getRelevantChannels();
    this.getRelevantChannels();
    this.addProduct.productAvailability = this.tradeDetailsComponent.getAvailability();
    this.getProductRetailer();
    const sellingLocations = this.distributionChannelsComponent.getSellingLocations();
    const targetLocations = this.distributionChannelsComponent.getTargetLocations();
    if (sellingLocations.length > 0) {
      this.addProduct.productSellingLocation = new ProductSellingLocation();
      this.addProduct.productSellingLocation.sellinglocation = sellingLocations;
    }

    if (targetLocations.length > 0) {
      this.addProduct.productTargetLocation = new ProductTargetLocation();
      this.addProduct.productTargetLocation.targetlocation = targetLocations;
    }

    this.fillDeletedItems();
    returnVal = true;
    return returnVal;
  }

  getProductPackageInfo() {
    this.addProduct.productPackageInfo = this.tradeDetailsComponent.getProductPackageInfo();

    if (this.productActionType !== ActionType.UPDATE && !this.addProduct.productPackageInfo.noofboxinpallet) {
      delete this.addProduct.productPackageInfo.noofboxinpallet;
      delete this.addProduct.productPackageInfo.noofboxinpalletunitid;
    }

    if (this.productActionType !== ActionType.UPDATE && !this.addProduct.productPackageInfo.noofpackageinbox) {
      delete this.addProduct.productPackageInfo.noofpackageinbox;
      delete this.addProduct.productPackageInfo.noofpackageinboxunitid;

    }
  }

  fillDeletedItems() {
    // fill deleted items
    // General component
    if (this.productActionType === ActionType.UPDATE) {
      if (this.generalComponent.deletedProductTag.length > 0) {
        this.addProduct.deletedproducttag = this.generalComponent.deletedProductTag;
      }

      if (this.generalComponent.deletedArticleReview.length > 0) {
        this.addProduct.deletedarticlereview = this.generalComponent.deletedArticleReview;
      }

      if (this.generalComponent.deletedExistingRating.length > 0) {
        this.addProduct.deletedexistingrating = this.generalComponent.deletedExistingRating;
      }

      if (this.generalComponent.deletedProductImage.length > 0) {
        this.addProduct.deletedproductimage = this.generalComponent.deletedProductImage;
      }

      if (this.generalComponent.deletedProductDisplayimage.length > 0) {
        this.addProduct.deletedproductdisplayimage = this.generalComponent.deletedProductDisplayimage;
      }

      if (this.generalComponent.deletedProductPackageImage.length > 0) {
        this.addProduct.deletedproductpackageimage = this.generalComponent.deletedProductPackageImage;
      }

      if (this.generalComponent.deletedProductBrochure.length > 0) {
        this.addProduct.deletedproductbrochure = this.generalComponent.deletedProductBrochure;
      }

      if (this.generalComponent.deletedAwardDetail.length > 0) {
        this.addProduct.deleted_award_details = this.generalComponent.deletedAwardDetail;
      }

      if (this.tradeDetailsComponent.deletedCompetingProduct.length > 0) {
        this.addProduct.deletedcompetingproduct = this.tradeDetailsComponent.deletedCompetingProduct;
      }

      if (this.distributionChannelsComponent.partnerObjects[4].deletedkeyretailer.length > 0) {
        const deletedKeys = this.distributionChannelsComponent.partnerObjects[4].deletedkeyretailer;
        for (let _i = 0; _i < deletedKeys.length; _i++) {
          if (this.filterDeletedRecordswithSelectedKeyRetailers('4', deletedKeys[_i])) {
            deletedKeys.splice(_i);
          }
        }
        if (deletedKeys.length > 0) {
          this.addProduct.deletedkeyretailer = deletedKeys;
        }
      }
      if (this.distributionChannelsComponent.partnerObjects[3].deletedkeyretailer.length > 0) {
        const deletedKeys = this.distributionChannelsComponent.partnerObjects[3].deletedkeyretailer;
        for (let _i = 0; _i < deletedKeys.length; _i++) {
          if (this.filterDeletedRecordswithSelectedKeyRetailers('3', deletedKeys[_i])) {
            deletedKeys.splice(_i);
          }
        }
        if (deletedKeys.length > 0) {
          this.addProduct.deletedkeydistributor = deletedKeys;
        }
      }
    }
  }

  getRelevantChannels() {
    this.addProduct.productRelevantChannel = this.distributionChannelsComponent.getRelevantChannels();
    if (this.addProduct.productRelevantChannel) {
      if (this.addProduct.productRelevantChannel.distributionchannel) {
        if (this.addProduct.productRelevantChannel.distributionchannel.length === 0) {
          delete this.addProduct.productRelevantChannel.distributionchannel;
        }
      } else {
        delete this.addProduct.productRelevantChannel.distributionchannel;
      }

      if (this.addProduct.productRelevantChannel.retailchannel) {
        if (this.addProduct.productRelevantChannel.retailchannel.length === 0) {
          delete this.addProduct.productRelevantChannel.retailchannel;
        }
      } else {
        delete this.addProduct.productRelevantChannel.retailchannel;
      }
    }
  }

  getProductImages() {
    this.addProduct.productImages = this.generalComponent.getProductImages();
    if (this.productActionType === ActionType.ADD || this.productActionType === ActionType.COPYORDUPLICATE) {
      if (!this.addProduct.productImages.productdisplayimage || this.addProduct.productImages.productdisplayimage.length === 0) {
        delete this.addProduct.productImages.productdisplayimage;
      }
    }
    if (this.productActionType === ActionType.UPDATE) {
      if (!this.addProduct.productImages) {
        delete this.addProduct.productImages;
      } else {
        let count = 0;
        if (!this.addProduct.productImages.productimage || this.addProduct.productImages.productimage.length === 0) {
          ++count;
          delete this.addProduct.productImages.productimage;
        }

        if (!this.addProduct.productImages.productdisplayimage || this.addProduct.productImages.productdisplayimage.length === 0) {
          ++count;
          delete this.addProduct.productImages.productdisplayimage;
        }

        if (!this.addProduct.productImages.productpackagingimage || this.addProduct.productImages.productpackagingimage.length === 0) {
          ++count;
          delete this.addProduct.productImages.productpackagingimage;
        }

        if (!this.addProduct.productImages.videourl || this.addProduct.productImages.videourl.length === 0) {
          ++count;
          delete this.addProduct.productImages.videourl;
        }

        if (count === 4) {
          delete this.addProduct.productImages;
        }

        // if (count === 3) {
        //   delete this.addProduct.productImages;
        // }
      }
    }
  }

  getProductBrochure() {
    this.addProduct.productBrochure = this.generalComponent.getProductBrochure();
    if (this.addProduct.productBrochure
      && this.addProduct.productBrochure.productpdf && this.addProduct.productBrochure.productpdf.length === 0) {
      delete this.addProduct.productBrochure.productpdf;
      delete this.addProduct.productBrochure;
    }
  }

  getProductCompeting() {
    this.addProduct.productCompeting = this.tradeDetailsComponent.getProductCompeting();
    // if (this.productActionType === ActionType.UPDATE && this.addProduct.productCompeting
    //   && this.addProduct.productCompeting.productcompeting
    //   && this.addProduct.productCompeting.productcompeting.length === 0) {
    //   delete this.addProduct.productCompeting.productcompeting;
    //   delete this.addProduct.productCompeting;
    // }

    if (this.addProduct.productCompeting
      && this.addProduct.productCompeting.productcompeting
      && this.addProduct.productCompeting.productcompeting.length === 0) {
      delete this.addProduct.productCompeting.productcompeting;
      delete this.addProduct.productCompeting;
    }
  }

  getArticlesReviews() {
    this.addProduct.productArticleReview = this.generalComponent.getArticlesReviews();
    if (this.productActionType === ActionType.UPDATE) {
      let count = 0;
      if (this.addProduct.productArticleReview && this.addProduct.productArticleReview.review.length === 0) {
        ++count;
        delete this.addProduct.productArticleReview.review;
      }

      if (this.addProduct.productArticleReview && this.addProduct.productArticleReview.productexistingrating.length === 0) {
        ++count;
        delete this.addProduct.productArticleReview.productexistingrating;
      }

      if (count === 2) {
        delete this.addProduct.productArticleReview;
      }
    } else {
      if (this.addProduct.productArticleReview) {
        if (this.addProduct.productArticleReview.review.length === 0) {
          delete this.addProduct.productArticleReview.review;
        }

        if (this.addProduct.productArticleReview.productexistingrating.length === 0) {
          delete this.addProduct.productArticleReview.productexistingrating;
        }
      }
    }
  }

  getProductRetailer() {
    // this.addProduct.productKeyRetailer = this.distributionChannelsComponent.getProductRetailer();
    // if (this.productActionType === ActionType.UPDATE) {
    // if (this.addProduct.productKeyRetailer && this.addProduct.productKeyRetailer.productkeyretailer.length === 0) {
    //   delete this.addProduct.productKeyRetailer.productkeyretailer;
    //   delete this.addProduct.productKeyRetailer;
    // }
    // }
    this.addProduct.keyDistributors = this.distributionChannelsComponent.getKeyRetailersList('3');
    this.addProduct.keyRetailers = this.distributionChannelsComponent.getKeyRetailersList('4');

    if (this.addProduct.keyRetailers && this.addProduct.keyRetailers.length === 0) {
      delete this.addProduct.keyRetailers;
    }
    if (this.addProduct.keyDistributors && this.addProduct.keyDistributors.length === 0) {
      delete this.addProduct.keyDistributors;
    }
  }

  changeButtonName() {
    this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
    this.scrollService.scrollTo(document.getElementById('tabsID'), 1000, -100);
    if (this.activeTabIndex === this.tabsContainer.tabs.length - 1) {
      this.buttonName = 'shared.buttonLabels.save';
    } else {
      this.buttonName = 'shared.buttonLabels.next';
    }
  }

  onTabChange(event) {
    if (this.tabsContainer.tabs.findIndex(item => item.active === true) === 2) {
      this.loaderStarter = true;
    }
    if (this.isPrevTabSelected) {
      this.isPrevTabSelected = false;
      return false;
    }

    if (!this.isTabLoadedFirstTime) {
      // if (!this.generalComponent.isRatingValidationSet) {
      // this.generalComponent.setRatingValidation();
      // }

      // this.generalComponent.removeRatingValidation();

      if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle === ProductTab.GENERAL) {
        if (!this.generalComponent.checkValidate()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }

        // this.changeButtonName();
      } else if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle === ProductTab.TRADE_DETAILS) {
        if (!this.tradeDetailsComponent.checkValidate()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }

        // this.changeButtonName();
      } else if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle === ProductTab.DISTRIBUTION_CHANNEL) {
        if (!this.distributionChannelsComponent.checkValidate()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }
        // this.changeButtonName();
      }
    }

    this.isTabLoadedFirstTime = false;
  }

  onLoaderNotificationChange(event: boolean) {
    this.preLoader = event;
  }

  OnSaveValidate(isSave?): boolean {
    if (this.buttonName === 'shared.buttonLabels.save' || isSave) {
      // this.generalComponent.setRatingValidation();
      if (!this.generalComponent.checkValidate()) {
        const nextTab = this.tabsContainer.tabs[0];
        this.tabsContainer.selectTab(nextTab);
        return false;
      }

      if (!this.tradeDetailsComponent.checkValidate()) {
        const nextTab = this.tabsContainer.tabs[1];
        this.tabsContainer.selectTab(nextTab);
        return false;
      }

      if (this.productActionType !== ActionType.UPDATE) {
        if (this.distributionChannelsComponent.getSellingLocations().length === 0) {
          const nextTab = this.tabsContainer.tabs[2];
          this.tabsContainer.selectTab(nextTab);
          this.distributionChannelsComponent.checkValidate();
          return false;
        }
      }
      if (!this.distributionChannelsComponent.checkValidate()) {
        // const nextTab = this.tabsContainer.tabs[2];
        // this.tabsContainer.selectTab(nextTab);
        return false;
      }



    } else {
      this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
      const currentTab = this.tabsContainer.tabs[this.activeTabIndex];
      if (!this.getComponentByTabIndex(this.activeTabIndex).checkValidate()) {
        this.tabsContainer.selectTab(currentTab);
        return false;
      }
    }

    return true;
  }

  getComponentByTabIndex(index: number) {
    if (index === 0) {
      return this.generalComponent;
    } else if (index === 1) {
      return this.tradeDetailsComponent;
    } else {
      return this.distributionChannelsComponent;
    }
  }

  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  getAwardDetailRecords() {
    this.addProduct.award_details = this.generalComponent.getAwardDetailRecords();
    if (this.addProduct.award_details.length === 0) {
      delete this.addProduct.award_details;
    }
  }

  filterDeletedRecordswithSelectedKeyRetailers(typeId: string, deletedKeys) {
    let count = 0;
    this.distributionChannelsComponent.partnerObjects[typeId]
      .keyRetailerUpdatedData.forEach(item => {
        if (item.keypartnerid === deletedKeys) {
          count++;
        }
      });
    return count === 0 ? true : false;
  }
}
