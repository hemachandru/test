import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Response } from '@angular/http';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { TranslateService } from '@ngx-translate/core';
import { RecommendationsList } from '@app/config/constant';
import { Config } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ProductBusiness } from '@app/product/business/product.business';
import { RecommendationGet, RecomendationPost, RecommendationRootObject, Channel, Oldchannel } from '@app/product/models/recommendation';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { CountryMaster } from '@app/account/models/profile';
import { integer } from 'aws-sdk/clients/storagegateway';

@Component({
  selector: 'app-dialog-recomendation',
  templateUrl: './dialog-recomendation.component.html',
  styleUrls: ['./dialog-recomendation.component.scss']
})

export class DialogRecomendationComponent implements OnInit {
  public recommendationGroup: FormGroup;
  public _RecommendationsList = RecommendationsList;
  public opts: ISlimScrollOptions;
  public userCountry;
  public msgCodeCountry;
  public selectedCountryID;
  public _RecommendationGet = new RecommendationRootObject;
  public _RecomendationPost = new RecomendationPost();
  public searchValue;
  public flagExisting: boolean;
  public preLoader: boolean;
  public _colorCode: boolean;
  public country: string;
  public companySearch: boolean;
  public companyname_code: string;
  public companyname: string;
  countryMasterList: Array<CountryMaster>;
  public isActiveChannel: boolean;
  public channelTypeId: integer;
  public toggleOccasions: boolean;

  constructor(private fb: FormBuilder, private Const: Config, private _ProductBusiness: ProductBusiness,
    @Inject(MAT_DIALOG_DATA) public data: any, private toastr: ToastrService, private translate: TranslateService,
    public sharedBusiness: SharedBusiness,
    public dialogRef: MatDialogRef<DialogRecomendationComponent>) { }
  selectedItem: any = '';
  channelsList: any[] = [];
  configure: any = { 'placeholder': 'Search Company..', 'sourceField': ['label'] };
  ngOnInit() {
    this.channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
    this.searchValue = '';
    this._colorCode = true;
    this.country = 'country';
    this.assignFormControls();
    this.getChannelList();
    this.companySearch = false;
    this.companyname = 'companyname';
    this.companyname_code = '';
    this.selectedCountryID = '0';
    this.opts = {
      barBackground: 'rgba(132, 136, 132, 0.8)',
      gridBackground: 'rgba(77, 77, 77, 0.27)',
      barBorderRadius: '10px',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.msgCodeCountry = '';
    this.isActiveChannel = false;
    this.toggleOccasions = false;
  }

  assignFormControls() {
    this.recommendationGroup = this.fb.group({
      email: ['', Validators.compose([Validators.required, Validators.pattern(this.Const.emailPattern)])
        // , this.isEmailUnique.bind(this)
      ],
      mobileno: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(20),
      ])],
      channeltype: [''],
      city: [''],
      address: ['', Validators.compose([Validators.maxLength(255)])],
      postalcode: ['', Validators.compose([Validators.minLength(3), Validators.maxLength(12),
      ])],
      contactName: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      websiteurl: ['', Validators.compose([Validators.minLength(5), Validators.maxLength(255),
        // Validators.pattern(this.Const.urlPatternWithHttp)
      ])],
      // companyname: ['']
      code: ['', Validators.compose([Validators.minLength(1), Validators.maxLength(6),
      ])],
      // occasions: [''],
      // toggleOccasions: [false],
      note: ['', Validators.compose([Validators.maxLength(255)])],
    });
    // this.getCountryList();
    if (this.data.roleShow) {
      this.recommendationGroup.controls['channeltype'].setValidators([Validators.required]);
      if (this._RecommendationsList[0].id === this.channelTypeId) {
        this.recommendationGroup.controls['channeltype'].setValue(this._RecommendationsList[1].id);
      } else {
        this.recommendationGroup.controls['channeltype'].setValue(this._RecommendationsList[0].id);
      }
    } else {
      this.recommendationGroup.controls['channeltype'].setValue('');
      this.recommendationGroup.controls['channeltype'].clearValidators();
      this.recommendationGroup.controls['channeltype'].setErrors(null);

    }
  }

  // setValidatorsOccasions() {
  //   if (this.recommendationGroup.controls['toggleOccasions'].value) {
  //     this.recommendationGroup.controls['occasions'].setValidators([Validators.required, Validators.maxLength(255)]);
  //     this.recommendationGroup.controls['occasions'].markAsTouched();
  //   } else {
  //     this.recommendationGroup.controls['occasions'].setValue('');
  //     this.recommendationGroup.controls['occasions'].clearValidators();
  //     this.recommendationGroup.controls['occasions'].setErrors(null);
  //   }
  // }

  // Set Country Id
  getCountryID(countryId: number) {
    if (countryId.toString() === 'null') {
      this.userCountry = 'country';
      this.msgCodeCountry = '0002';
      this.selectedCountryID = '0';
    } else {
      this.msgCodeCountry = '';
      this.selectedCountryID = countryId.toString();
      // this.setCountryMobileCode(countryId);
    }
  }

  // Exisitng Email validation
  isEmailUnique(control: FormControl) {
    const q = new Promise((resolve, reject) => {
      this._ProductBusiness.isEmailRegisterd(control.value, true).subscribe((res: any) => {
        if (res.isavialble === false && !this.flagExisting) {
          resolve({ 'isEmailUnique': true });
        } else {
          resolve(null);
        }
      });
    });
    return q;
  }

  onSelect(item: any) {
    this.searchValue = item;
    this.selectedItem = item;
    let channelOldActive;
    let channelDetail = [null];
    let oldChannelDetail;
    if (this._RecommendationGet.channel) {
      channelDetail = this._RecommendationGet.channel.filter(channel => channel.channelId
        === item.id) as Array<Channel>;
    }
    if (this._RecommendationGet.oldchannel && !channelDetail[0]) {
      oldChannelDetail = this._RecommendationGet.oldchannel.filter(channel => channel.oldChannelId
        === item.id) as Array<Oldchannel>;
    }
    if (channelDetail[0]) {
      channelOldActive = channelDetail;
      this.isActiveChannel = false;
    } else if (oldChannelDetail) {
      channelOldActive = oldChannelDetail;
      this.isActiveChannel = true;
    }
    this.recommendationGroup.controls['address'].setValue('');
    this.recommendationGroup.controls['city'].setValue('');
    this.recommendationGroup.controls['postalcode'].setValue('');
    this.recommendationGroup.controls['email'].setValue('');
    this.recommendationGroup.controls['contactName'].setValue('');
    this.recommendationGroup.controls['websiteurl'].setValue('');
    this.selectedCountryID = '0';
    if (channelOldActive[0]) {
      this.flagExisting = true;
      this.recommendationGroup.controls['address'].setValue(ValidationService.isNullOrEmpty(channelOldActive[0].regaddress)
        ? channelOldActive[0].regaddress.address : '');
      this.recommendationGroup.controls['city'].setValue(ValidationService.isNullOrEmpty(channelOldActive[0].regaddress)
        ? channelOldActive[0].regaddress.city : '');
      this.recommendationGroup.controls['postalcode'].setValue(ValidationService.isNullOrEmpty(channelOldActive[0].regaddress) ?
        channelOldActive[0].regaddress.postalCode : '');
      // this.recommendationGroup.controls['email'].setValue(channelOldActive[0].companyMail);
      // this.recommendationGroup.controls['contactName'].setValue(channelOldActive[0].contact ?
      // channelOldActive[0].contact.firstName + ' ' +
      //   channelOldActive[0].contact.lastName : '');
      let temp_unfromatted_url = '';
      const websiteUrl = channelOldActive[0].channeldetail &&
        channelOldActive[0].channeldetail.webSiteUrl ? channelOldActive[0].channeldetail.webSiteUrl : '';
      if (!ValidationService.isNullOrEmpty(websiteUrl)) {
        temp_unfromatted_url = websiteUrl;
        if (temp_unfromatted_url) {
          while (temp_unfromatted_url.charAt(0) === '/') {
            temp_unfromatted_url = temp_unfromatted_url.substring(2);
          }
        }
      }
      this.recommendationGroup.controls['websiteurl'].setValue(temp_unfromatted_url);
      this.selectedCountryID = channelOldActive[0].regaddress.countryId;
      this.msgCodeCountry = '';
    } else {
      this.flagExisting = false;
    }
  }

  onInputChangedEvent(val: string) {
    this.searchValue = val;
    this.companyname_code = '';
    // if (!ValidationService.isNullOrEmpty(this.searchValue)) {
    this.getChannelList();
    // }
  }

  // Get channels
  getChannelList() {
    this.preLoader = true;
    let channelId = null;
    if (this.data.roleShow) {
      channelId = this.recommendationGroup.controls['channeltype'].value;
    }
    this._ProductBusiness.getChannelListBusiness(channelId, this.searchValue, true).subscribe((res: any) => {
      const response = res as Response;
      if (response.ok) {
        this.preLoader = false;
        this._RecommendationGet = response.json();
        this.channelsList = [];
        if (this._RecommendationGet.channel) {
          for (const channel of this._RecommendationGet.channel) {
            this.channelsList.push({ id: channel.channelId, label: channel.companyName });
            channel.boolActive = false;
          }
        }
        if (this._RecommendationGet.oldchannel) {
          for (const channel of this._RecommendationGet.oldchannel) {
            this.channelsList.push({ id: channel.oldChannelId, label: channel.companyName });
            channel.boolActive = true;
          }
        }
      } else {
        this.preLoader = false;
      }
    });
  }

  // Save part for recommendation
  onConfirm() {
    if (this.recommendationGroup.valid && this.searchValue !== '' && this.selectedCountryID !== '0') {
      this._RecomendationPost.confirm = true;
      if (this.flagExisting) {
        if (!this.isActiveChannel) {
          this._RecomendationPost.existchannelid = parseInt(this.selectedItem.id, 10);
          this._RecomendationPost.oldchannelid = null;
        } else {
          this._RecomendationPost.oldchannelid = parseInt(this.selectedItem.id, 10);
          this._RecomendationPost.existchannelid = null;
        }
      }
      this._RecomendationPost.companyname = this.flagExisting ?
        this.selectedItem.label : this.searchValue;
      this._RecomendationPost.countryid = parseInt(this.selectedCountryID, 10);
      if (this.data.roleShow) {
        this._RecomendationPost.suggested_type = this.recommendationGroup.controls['channeltype'].value;
      } else {
        this._RecomendationPost.suggestedto = +this.data.suggestedTo;
        this._RecomendationPost.suggestedto_type = +this.data.suggestedToType;
        this._RecomendationPost.suggested_type = +this.data.suggestedType;
      }
      this._RecomendationPost.mail = this.recommendationGroup.controls['email'].value;
      if (this.recommendationGroup.controls['address'].value !== '') {
        this._RecomendationPost.address = this.recommendationGroup.controls['address'].value;
      }
      if (this.recommendationGroup.controls['city'].value !== '') {
        this._RecomendationPost.city = this.recommendationGroup.controls['city'].value;
      }
      if (this.recommendationGroup.controls['mobileno'].value !== '') {
        this._RecomendationPost.mobileno = this.recommendationGroup.controls['mobileno'].value;
      }
      if (this.recommendationGroup.controls['postalcode'].value !== '') {
        this._RecomendationPost.postalcode = this.recommendationGroup.controls['postalcode'].value;
      }
      if (this.recommendationGroup.controls['websiteurl'].value !== '') {
        this._RecomendationPost.websiteurl = this.recommendationGroup.controls['websiteurl'].value;
      }
      // if (this.data.roleShow && this.recommendationGroup.controls['toggleOccasions'].value) {
      //   this._RecomendationPost.occasion = this.recommendationGroup.controls['occasions'].value;
      // } else {
      //   delete this._RecomendationPost.occasion;
      // }

      this._RecomendationPost.note = this.recommendationGroup.controls['note'].value;
      this._RecomendationPost.contactname = this.recommendationGroup.controls['contactName'].value;
      this.postRecommendation();
    } else {
      this.markFormGroupTouched(this.recommendationGroup);
      if (this.searchValue === '') {
        this.companyname_code = '0001';
      }
      if (this.selectedCountryID === '0') {
        this.userCountry = 'country';
        this.msgCodeCountry = '0002';
      }
    }
  }

  postRecommendation() {
    this.preLoader = true;
    this._ProductBusiness.postRecommendationBusiness(this.data.roleShow, this._RecomendationPost, true).subscribe((res: any) => {
      const response = res as Response;
      if (response.ok) {
        this.preLoader = false;
        this.toastr.success(this.translate.instant('commonValidation.savedSuccess'));
        this.dialogRef.close(true);
      } else {
        this.preLoader = false;
        this.toastr.error(this.translate.instant('commonMessage.somethingWentWrong'));
      }
    });
  }

  markFormGroupTouched(formGroup: FormGroup) {
    for (const field in formGroup.controls) {
      const control = formGroup.get(field);
      control.markAsTouched();
      // }
    }
  }

  getCountryList() {
    this.preLoader = true;
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      this.preLoader = false;
    });
  }

  // Function to set mobile code
  // setCountryMobileCode(data) {
  //   const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
  //     === parseInt(data, 10));
  //   if (countryData[0].phoneCode) {
  //   }
  // }

  // Function validate not allow space & hyphen
  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }
}
