import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogRecomendationComponent } from './dialog-recomendation.component';

describe('DialogRecomendationComponent', () => {
  let component: DialogRecomendationComponent;
  let fixture: ComponentFixture<DialogRecomendationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogRecomendationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogRecomendationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
