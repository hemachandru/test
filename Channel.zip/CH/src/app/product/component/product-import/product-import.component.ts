import { Component, OnInit, AfterViewChecked, ViewChild, ElementRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { WatchVideoComponent } from './dialog-components/watch-video/watch-video.component';
import { ImportProductComponent } from './dialog-components/import-product/import-product.component';
import { ProductService } from './../../service/product-service.service';
import { ApiUrl } from '@app/config/constant_keys';
import { ProductStrings } from '@app/config/constant';
import { environment } from 'environments/environment';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { CommonHelper } from '@app/shared/common-helper';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ValidationService } from '@app/shared/shared-service/validation-service';
// import { escapeHtml } from '@angular/platform-browser';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-product-import',
  templateUrl: './product-import.component.html',
  styleUrls: ['./product-import.component.scss']
})

export class ProductImportComponent implements OnInit, AfterViewChecked {
  public title;
  public titlemsg;
  private apiUrl = ApiUrl;
  public sampleDownloadLink;
  public loading = false;
  xlfileName = 'demo.xlsx';

  @ViewChild('downloadZipLink') private downloadZipLink: ElementRef;

  constructor(private dialog: MatDialog, private productService: ProductService,
    private router: Router, private toastr: ToastrService, private translate: TranslateService) {
    this.title = ProductStrings.PRODUCT_IMPORT_TITLE;
    this.titlemsg = ProductStrings.PRODUCT_IMPORT_DESC;
    // if (CommonHelper.getStripeIDLocally() === '0') {
    //   this.router.navigate(['product/productlist']);
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   return;
    // }
    // this.sampleDownloadLink = '#';
  }

  ngOnInit() {
    this.getSampleLink();
  }

  ngAfterViewChecked() {

  }

  public async watchVideoClick() {
    // this.dialog.open(WatchVideoComponent); // Need to enable after video is done
  }

  private getSampleLink() {
    // console.log('Down load link called!');
    const url: string = this.apiUrl.PRODUCT_IMPORT_SAMPLE;
    this.loading = true;
    this.productService.getServiceHttpClient(url).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.loading = false;
        // console.log('sample download link', result.body);
        this.xlfileName = result.body.sampleFileName;
        result.body = null;
        this.sampleDownloadLink = this.apiUrl.PRODUCT_IMPORT_SAMPLE_FOLDER + '/' + this.xlfileName;
      }
    });

  }

  public downloadSampleLink() {

    if (this.xlfileName) {
      this.productService.getServiceHttpClient(this.sampleDownloadLink, 'blob').subscribe(res => {
        const resp = res as Response;
        if (resp.ok) {
          // console.log('start download:', resp);
          if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(res.body, this.xlfileName);
            res.body = null;
          } else {
            const blobURL = URL.createObjectURL(res.body);
            const anch = document.createElement('a');
            document.body.appendChild(anch);
            anch.setAttribute('style', 'display: none');
            anch.href = blobURL;
            anch.download = this.xlfileName;
            anch.click();
            window.URL.revokeObjectURL(blobURL);
            document.body.removeChild(anch);
          }
          // anch.remove(); // remove the element
        }
      }, error => {
        console.log('download error:', JSON.stringify(error));
      }, () => {
        console.log('Completed file download.');
      });
    } else {
      console.log('No sample file name, retrying.');
      this.getSampleLink();
    }

  }

  public async productImportClick() {
    this.dialog.open(ImportProductComponent, { data: { message: '' } });
  }

}
