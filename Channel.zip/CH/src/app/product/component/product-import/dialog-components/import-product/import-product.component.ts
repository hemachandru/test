import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { CommonHelper } from '@app/shared/common-helper';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { ProductService } from './../../../../service/product-service.service';
import { ApiUrl, WebUrl } from '@app/config/constant_keys';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-import-product',
  templateUrl: './import-product.component.html',
  styleUrls: ['./import-product.component.scss']
})
export class ImportProductComponent implements OnInit {
  public webUrl = WebUrl;
  public profileForm: FormGroup;
  public successData: any = '';
  public csvFolderKey;
  public zipFolderKey;
  public errorMessage: any = '';
  private apiUrl = ApiUrl;
  public loading = false;
  public isZipUploaded = false;
  public isCsvUploaded = false;
  private csvFolderName = 'product-import-csv-s3';
  private zipFolderName = 'product-import-zip-s3';
  private csvFileName: string;
  private zipFileName: string;
  public successFlag = false;
  public failureFlag = false;
  public falureDownloadLink: string;
  public expBtnEnable = true;
  constructor(public dialogRef: MatDialogRef<ImportProductComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private uploadService: S3UploadFileService,
    private productService: ProductService, private router: Router, private translate: TranslateService,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.successData = this.data.message;
    this.expBtnEnable = true;
    console.log('Init called');
  }

  cancel() {
    this.dialogRef.close();
  }

  uploadFile(event, type) {
    const selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    this.errorMessage = '';
    if (file) {
      const fileName = file.name;
      let fileExtension = fileName.substr((fileName.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString();
      if (type === 'csv') {
        if (CommonHelper.checkValidCSVFile(fileExtension)) {
          this.loading = true;
          this.uploadService.uploadfile(file, this.csvFolderName + '/').then(res => {
            this.loading = false;
            this.csvFileName = fileName;
            if (res.key) {
              this.csvFolderKey = res.key;
            } else {
              this.csvFolderKey = res.Key;
            }
            this.isCsvUploaded = true;
            console.log('resCsvKey', res);
          },
            (error) => {
              this.loading = false;
              console.log(error);
            });
        } else {
          this.errorMessage = this.translate.instant('productImport.importError.validxlxs');
        }
      } else if (type === 'zip') {
        if (CommonHelper.checkValidZIPFile(fileExtension)) {
          this.loading = true;
          this.uploadService.uploadfile(file, this.zipFolderName + '/').then(res => {
            this.loading = false;
            this.zipFileName = fileName;
            if (res.key) {
              this.zipFolderKey = res.key;
            } else {
              this.zipFolderKey = res.Key;
            }
            this.isZipUploaded = true;
            console.log('resZipKey', res);
          },
            (error) => {
              this.loading = false;
              console.log(error);
            });
        } else {
          // skip image upload
          // this.errorMessage = this.translate.instant('productImport.importError.validzip');
        }
      } else {
        console.log('Upload Failed!');
      }
    }
  }

  importProduct() {

    if (!this.csvFolderKey) {
      this.errorMessage = this.translate.instant('productImport.importError.noxlxs');
      // } else if (!this.zipFolderKey) {
      // / skip image upload
      // this.errorMessage = this.translate.instant('productImport.importError.nozip');
    } else {

      const url: string = this.apiUrl.PRODUCT_IMPORT_UPLOAD;
      const data: any = {};

      if (this.zipFolderKey) {
        this.expBtnEnable = false;
        const zipAWSKey = this.zipFolderKey.split('/');
        data.imageFolder = zipAWSKey[0];
        data.imageFolderName = zipAWSKey[1];
        this.loading = true;
        this.productService.postService(data, url, true).subscribe(result => {
          const response = result as Response;
          this.loading = false;
          if (response.ok) {
            const UploadedImageFolder = <any>response.json();
            if (UploadedImageFolder) {
              this.uploadXlsFile(UploadedImageFolder.newPath);
            }
          }
        },
          (error) => {
            this.loading = false;
            console.log(error);
          });

      } else {
        this.uploadXlsFile(null);
      }
    }
  }

  public async uploadXlsFile(newPath) {
    const urlImport: string = this.apiUrl.PRODUCT_IMPORT;

    const csvAWSKey = this.csvFolderKey.split('/');
    const dataImport: any = {};
    dataImport.fileName = csvAWSKey[1];
    dataImport.filePath = csvAWSKey[0];
    dataImport.newImageFolder = newPath;
    this.loading = true;
    this.productService.postService(dataImport, urlImport, true).subscribe(resultImport => {
      console.log('resultImport', resultImport);
      this.loading = false;
      const resp = resultImport as Response;
      if (resp.ok) {
        const procResult = <any>resp.json();
        const successCnt = procResult.uploadedCount;
        const failureCnt = procResult.uninsertedCount;
        const totalCnt = procResult.totalCount;
        let resultMessage = 'Totally ' + successCnt + ' records successfully processed out of ' + totalCnt + '.';
        console.log('failureCnt', failureCnt);
        if (failureCnt > 0) {
          this.failureFlag = true;
          this.falureDownloadLink = procResult.uninsertedFileName;
          resultMessage = resultMessage + ' Failure records ' + failureCnt + '. Click below for details.';
        } else {
          this.successFlag = true;
          this.errorMessage = resultMessage;
          this.router.navigate([this.webUrl.MY_PRODUCTLIST]);
        }
        this.errorMessage = resultMessage;
        // console.log('this.errorMessage', resultMessage);
      } else {
        this.loading = false;
        let errorResponse = resp.json();
        if(errorResponse && errorResponse[0] && errorResponse[0]['errors'] && errorResponse[0]['errors'][0]) this.toastr.error(errorResponse[0]['errors'][0].message.message, "Product import");
        this.errorMessage = this.translate.instant('productImport.importError.failedimport');
      }
    },
      (error) => {
        this.loading = false;
        console.log(error);
      });
  }

  public async downloadSampleLink() {
    console.log('Down load link called!');
    if (this.falureDownloadLink) {
      // const url: string = this.apiUrl.PRODUCT_IMPORT_SAMPLE;
      this.loading = true;
      const downloadLink = this.apiUrl.PRODUCT_IMPORT_SAMPLE_FOLDER + '/' + this.falureDownloadLink;
      this.productService.getServiceHttpClient(downloadLink, 'blob').subscribe(res => {
        this.loading = false;
        const resp = res as Response;
        if (resp.ok) {
          console.log('start download:', res);
          if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(res.body, this.falureDownloadLink);
          } else {
            const urlLink = window.URL.createObjectURL(res.body);
            const anch = document.createElement('a');
            document.body.appendChild(anch);
            anch.setAttribute('style', 'display: none');
            anch.href = urlLink;
            anch.download = this.falureDownloadLink;
            anch.click();
            window.URL.revokeObjectURL(urlLink);
            document.body.removeChild(anch);
            // anch.remove(); // remove the element
          }
        }
      }, error => {
        this.loading = false;
        console.log('download error:', JSON.stringify(error));
      }, () => {
        this.loading = false;
        console.log('Completed file download.');
      });
    }
  }

}
