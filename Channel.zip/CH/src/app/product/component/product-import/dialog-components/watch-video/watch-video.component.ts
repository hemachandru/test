import { Component, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import {DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import { ProductStrings } from '@app/config/constant';

@Component({
  selector: 'app-watch-video',
  templateUrl: './watch-video.component.html',
  styleUrls: ['./watch-video.component.scss']
})
export class WatchVideoComponent implements OnInit {
  public successData = '';

  @Input()
  videoUrl: string = ProductStrings.PRODUCT_IMPORT_VIDEO_URL;

  safeUrl: SafeResourceUrl;

  constructor(public dialogRef: MatDialogRef<WatchVideoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public sanitizer: DomSanitizer) {
  }

  ngOnInit() {
    this.successData = this.data.message;
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.videoUrl);
  }

  cancel() {
    this.dialogRef.close();
  }

}
