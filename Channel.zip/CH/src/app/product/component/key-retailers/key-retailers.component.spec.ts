import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { KeyRetailersComponent } from './key-retailers.component';

describe('KeyRetailersComponent', () => {
  let component: KeyRetailersComponent;
  let fixture: ComponentFixture<KeyRetailersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ KeyRetailersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(KeyRetailersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
