import { Component, OnInit, Input } from '@angular/core';
import { ProductRootObject } from '@app/product/models/product-view';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { WebUrl } from '@app/config/constant_keys';
import { ScrollToService } from 'ng2-scroll-to-el';
import { Router } from '@angular/router';
@Component({
  selector: 'app-key-retailers',
  templateUrl: './key-retailers.component.html',
  styleUrls: ['./key-retailers.component.scss']
})

export class KeyRetailersComponent implements OnInit {
  public webUrl = WebUrl;
  _ProductRootObject: ProductRootObject;
  public _NoDataFound: NoDataFound;
  public scrollbarOptionsCnl = { axis: 'y', theme: 'dark' };

  constructor(
    private translate: TranslateService,
    private router: Router,
    private scrollService: ScrollToService,
  ) {
    this._ProductRootObject = new ProductRootObject();
    this._NoDataFound = new NoDataFound();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  ngOnInit() {
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('commonError.noData');
  }

  openNewWindow(url) {
    window.open(url);
  }

  navigateToChannelView(data) {
    if (data.active && data.active.id) {
      this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, data.active.id]);
      this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
    } else {
      return true;
    }
  }

}
