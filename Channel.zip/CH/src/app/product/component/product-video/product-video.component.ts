import { Component, OnInit, Inject, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-product-video',
  templateUrl: './product-video.component.html',
  styleUrls: ['./product-video.component.scss']
})
export class ProductVideoComponent implements OnInit, AfterViewInit {
  @ViewChild('iframe') iframe: any;
  public url: SafeResourceUrl;
  public preloader: boolean;

  constructor(public dialogRef: MatDialogRef<ProductVideoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public sanitizer: DomSanitizer) { }

  ngOnInit() {
    this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.data.url);
    this.preloader = true;
  }

  ngAfterViewInit() {
    this.iframe.nativeElement.addEventListener('load', this.onLoad.bind(this));
  }

  onLoad(e) {
      this.preloader = false;
  }
}
