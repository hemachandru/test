import { Component, OnInit, ViewChildren, QueryList, OnDestroy } from '@angular/core';
import { AddressType, CaroselType, ActionType } from '@app/config/constant';
import { ProductService } from '@app/product/service/product-service.service';
import { AddressList, AddressGet } from '../../models/address-book';
import { Response } from '@angular/http';
import { NgxCarousel } from 'ngx-carousel';
import { Subscription } from 'rxjs/Subscription';
import { CheckoutService } from '../../service/checkout.service';
import { Checkout, CheckoutResponse, CompanyBillingAddress } from '@app/product/models/shared-model';
import { NgxCarouselComponent } from 'ngx-carousel/src/ngx-carousel/ngx-carousel.component';
import { Router } from '@angular/router';
import { CartService } from '../../service/cart-service';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ToastrService } from 'ngx-toastr';
import { CartModel } from '../../models/cart-model';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { MatDialogRef, MatDialog } from '@angular/material';
import { ButtonTypes } from '@app/config/constant';
import { UserActionModel } from '@app/shared/models/shared-model';
import { UserAddressComponent } from '../user-address/user-address.component';
import { ScrollToService } from 'ng2-scroll-to-el';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { Contact } from '@app/shared/models/contact';
import { CartCountService } from '@app/shared/shared-service/cart-count';
import { TranslateService } from '@ngx-translate/core';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit, OnDestroy {
  public webUrl = WebUrl;
  title: string;
  companyName: string;
  addressType = AddressType;
  showBillingAddressForm: boolean;
  showShippingAddressForm: boolean;
  caroselType = CaroselType;
  billingAddressListData: Array<AddressGet>;
  shippingAddressListData: Array<AddressGet>;
  public carouselTile: NgxCarousel;
  indexr = 0;
  _smGridCount;
  _mGridCount;
  _caroselSlideCount;
  checkoutData: CartModel;
  subscription: Subscription;
  preloader: boolean;
  billingAddressPanel: HTMLElement;
  shippingAddressPanel: HTMLElement;
  summaryPanel: HTMLElement;

  billingAddressDetail: AddressGet;
  shippingAddressDetail: AddressGet;
  accBillingAddress: HTMLElement;
  accShippingAddress: HTMLElement;
  requestFreeSample: boolean;
  billingAddressCarousel: NgxCarouselComponent;
  shippingAddressCarousel: NgxCarouselComponent;
  selectedBillingAddrIndex?: number;
  selectedBillingAddress: AddressGet;

  selectedShippingAddrIndex?: number;
  selectedShippingAddress: AddressGet;
  dialogRef: MatDialogRef<MessageDialogComponent>;
  isButtonsClicked: boolean;
  @ViewChildren(NgxCarouselComponent) carousels: QueryList<NgxCarouselComponent>;
  @ViewChildren(UserAddressComponent) userAddressComponent: QueryList<UserAddressComponent>;
  timerId: any;
  companyBillingAddress: CompanyBillingAddress;
  public cartCount;

  constructor(private router: Router, private productService: ProductService, public _checkoutservice: CheckoutService,
    private cartService: CartService, private toastrService: ToastrService, private dialog: MatDialog,
    private scrollService: ScrollToService, private sharedService: SharedService, private cartCountService: CartCountService,
    private translate: TranslateService, private userSubscriptionBusiness: UserSubscriptionBusiness) {
    this.preloader = false;
    this.title = 'checkOut.title';
    this.showBillingAddressForm = true;
    this.showShippingAddressForm = true;
    this.requestFreeSample = false;
    this.isButtonsClicked = false;
  }

  ngOnInit() {
    const userStatusdetail = JSON.parse(localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS));
    this.companyName = userStatusdetail.companyName;
    if (this._checkoutservice.checkoutSource.closed === true) {
      this.router.navigate([this.webUrl.CART_LIST]);
      return;
    } else {
      this.subscription = this._checkoutservice.currentCheckoutDetail.subscribe(item => {
        this.checkoutData = item;
      });

      if (this.checkoutData) {
        this.setAccordionConfigs();
        this.billingAddressPanel = document.getElementById('billingAddressPanelId') as HTMLElement;
        this.shippingAddressPanel = document.getElementById('shippingAddressPanelId') as HTMLElement;
        this.summaryPanel = document.getElementById('accSmmaryId') as HTMLElement;
        this.accBillingAddress = document.getElementById('accBillingAddress') as HTMLElement;
        this.accShippingAddress = document.getElementById('accShippingAddress') as HTMLElement;
        this.carouselTile = {
          grid: { xs: 1, sm: 3, md: 4, lg: 4, all: 0 },
          slide: 4,
          speed: 400,
          animation: 'lazy',
          point: {
            visible: false
          },
          load: this._caroselSlideCount,
          touch: true,
          easing: 'ease'
        };
        this.getAddressList();
        const contactDetail = localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO);
        if (contactDetail) {
          const contactInfo = JSON.parse(localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO)) as Contact;
          if (!(contactInfo.mobileNo || contactInfo.phone1 || contactInfo.phone2)) {
            this.getContactInfo();
          }
        } else {
          this.getContactInfo();
        }

      } else {
        this.router.navigate([this.webUrl.CART_LIST]);
      }
    }
  }

  getCarouselInstances() {
    if (this.carousels) {
      const _carousels = this.carousels.toArray();
      if (this.carousels.length > 0) {
        this.billingAddressCarousel = _carousels[0];
        this.shippingAddressCarousel = _carousels[1];
      }
    }
  }

  setAccordionConfigs() {
    const acc = document.getElementsByClassName('accordion');
    let i;
    const self = this;
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener('click', function () {

        if (!self.isButtonsClicked) {
          const panel = this.nextElementSibling;
          if (panel.style.maxHeight) {
            panel.style.maxHeight = null;
          } else {
            panel.style.maxHeight = panel.scrollHeight + 'px';
          }
        } else {
          self.isButtonsClicked = false;
        }
      });
    }
  }

  addAdress(type: AddressType) {

    this.isButtonsClicked = false;
    if (type === AddressType.BILLING) {
      delete this.billingAddressDetail;
      this.showBillingAddressForm = true;
      this.billingAddressPanel.style.maxHeight = null;
      // this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
    } else {
      delete this.shippingAddressDetail;
      this.showShippingAddressForm = true;
      this.shippingAddressPanel.style.maxHeight = null;
      // this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
    }
  }

  onBeforeSubmit() {
    this.preloader = true;
  }

  onBillingSubmit(data: boolean) {
    this.preloader = false;
    console.log(data);
    if (data) {
      this.getAddressList(true, true);
    }
  }

  onShippingSubmit(data: boolean) {
    this.preloader = false;
    console.log(data);
    if (data) {
      this.getAddressList(true, false, true);
    }
  }

  onCancel(type) {

    if (type === AddressType.BILLING) {
      if (this.billingAddressListData && this.billingAddressListData.length > 0) {
        this.billingAddressPanel.style.maxHeight = null;
        this.showBillingAddressForm = false;
        this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
      } else {
        this.billingAddressPanel.style.maxHeight = null;
      }
    } else {
      if (this.shippingAddressListData && this.shippingAddressListData.length > 0) {
        this.shippingAddressPanel.style.maxHeight = null;
        this.showShippingAddressForm = false;
        this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
      } else {
        this.shippingAddressPanel.style.maxHeight = null;
      }
    }
  }

  getAddressList(isAfterSave: boolean = false, isAfterBillingSubmit: boolean = false,
    isAfterShippingSubmit: boolean = false) {
    this.preloader = true;
    this.productService.getAddressList().subscribe(result => {
      const response = result as Response;
      // this.preLoader = false;
      if (response.ok) {
        const addressList = response.json() as AddressList;
        if (addressList && addressList.results.length > 0) {
          this.billingAddressListData = addressList.results.filter(item => item.isbillingaddress === '1');
          if (this.billingAddressListData.length > 0) {
            this.showBillingAddressForm = false;
            if (isAfterSave && isAfterBillingSubmit) {
              this.selectedBillingAddrIndex = 0;
              this.selectedBillingAddress = this.billingAddressListData[0];
            }
          } else {
            this.showBillingAddressForm = true;
          }

          this.shippingAddressListData = addressList.results.filter(item => item.isshippingaddress === '1');
          if (this.shippingAddressListData.length > 0) {
            if (isAfterSave && isAfterShippingSubmit) {
              this.selectedShippingAddrIndex = 0;
              this.selectedShippingAddress = this.shippingAddressListData[0];
            }

            this.showShippingAddressForm = false;
          } else {
            this.showShippingAddressForm = true;
          }

          if (this.billingAddressListData.length > 0 && this.shippingAddressListData.length > 0) {
            if (!this.shippingAddressPanel.style.maxHeight) {
              this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
            }

            this.showSummaryPanel();
          }
        } else {
          this.fillCompanyBillingAddress();
        }
      }
      this.preloader = false;
      this.afterGettingAddressList();
    },
      (error) => {
        console.log(error);
        this.preloader = false;
        this.afterGettingAddressList();
      });
  }

  afterGettingAddressList() {
    this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
  }

  editAddress(addressItem: AddressGet, type: AddressType, buttonClicked = true) {

    this.isButtonsClicked = buttonClicked;
    if (type === AddressType.BILLING) {
      this.showBillingAddressForm = true;
      this.billingAddressDetail = addressItem;
      this.billingAddressPanel.style.maxHeight = null;
    } else {
      this.showShippingAddressForm = true;
      const addressComp = this.userAddressComponent.toArray().filter(item => item.type === AddressType.SHIPPING)[0];
      if (addressComp) {
        addressComp.setFormData(addressItem);
      } else {
        this.shippingAddressDetail = addressItem;
      }
      this.timerId = setTimeout(this.setShippingPanelScollHeight, 500, this);
    }
  }

  deleteAddress(type: AddressType, addressId: string) {

    // this.isButtonsClicked = true;
    let title = '', message = '';
    if (type === AddressType.BILLING) {
      title = this.translate.instant('checkOut.billingAddress');
      message = this.translate.instant('checkOut.deletebillingAddress');

    } else {
      title = this.translate.instant('checkOut.shippingAddress');
      message = this.translate.instant('checkOut.deleteshippingAddress');
    }

    this.dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.ConfirmCancel,
        message: message
      }
    });

    this.dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.preloader = true;
        this.productService.deleteAddressById(addressId).subscribe(sResult => {
          const response = sResult as Response;
          // this.preLoader = false;
          if (response.ok) {
            if (type === AddressType.BILLING) {
              this.billingAddressListData = this.billingAddressListData.filter(item => item.addressid !== addressId);
              delete this.billingAddressDetail;
              if (this.billingAddressListData.length > 0) {
                if (this.selectedBillingAddrIndex) {
                  this.selectedBillingAddress = this.billingAddressListData[this.selectedBillingAddrIndex];
                } else {
                  this.selectedBillingAddrIndex = 0;
                  this.selectedBillingAddress = this.billingAddressListData[this.selectedBillingAddrIndex];
                }
              } else {

                this.billingAddressPanel.style.maxHeight = null;
                this.showBillingAddressForm = true;
                this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
                this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
              }
            }

            if (type === AddressType.SHIPPING) {
              this.shippingAddressListData = this.shippingAddressListData.filter(item => item.addressid !== addressId);
              delete this.shippingAddressDetail;
              if (this.shippingAddressListData.length > 0) {
                if (this.selectedShippingAddrIndex) {
                  this.selectedShippingAddress = this.shippingAddressListData[this.selectedShippingAddrIndex];
                } else {
                  this.selectedShippingAddrIndex = 0;
                  this.selectedShippingAddress = this.shippingAddressListData[this.selectedShippingAddrIndex];
                }
              } else {
                this.showShippingAddressForm = true;
                this.shippingAddressPanel.style.maxHeight = null;
                this.timerId = setTimeout(this.setShippingPanelScollHeight, 500, this);
              }
            }
            this.toastrService.info(this.translate.instant('checkOut.tostMsg.addressRemove'));
          } else {
            this.toastrService.error(this.translate.instant('checkOut.tostMsg.failtoRemoveAddress'));
          }

          this.preloader = false;
        },
          (error) => {
            this.toastrService.error(this.translate.instant('checkOut.tostMsg.failtoRemove'));
            console.log(error);
            this.preloader = false;
          });
      }
    });
  }

  setShippingPanelScollHeight(self) {

    self.shippingAddressPanel.style.maxHeight = self.shippingAddressPanel.scrollHeight + 'px';
    clearTimeout(self.timerId);
  }

  onEdit() {
    if (this.checkoutData) {
      this.cartService.sendData(this.checkoutData.cartid.toString());
      this.router.navigate([this.webUrl.CART_LIST]);
    }
  }

  onFinish() {
    if (this.showBillingAddressForm) {
      this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
      const addressComp = this.userAddressComponent.toArray().filter(item => item.type === AddressType.BILLING)[0];
      if (addressComp) {
        addressComp.validateForm();
      }

      this.scrollService.scrollTo(document.getElementById('accBillingAddress'), 1000, -100);
      return;
    }

    if (this.showShippingAddressForm) {
      this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
      const addressComp = this.userAddressComponent.toArray().filter(item => item.type === AddressType.SHIPPING)[0];
      if (addressComp) {
        addressComp.validateForm();
      }

      this.scrollService.scrollTo(document.getElementById('accShippingAddress'), 1000, -100);
      return;
    }
    // tslint:disable-next-line:max-line-length
    if ((!this.selectedBillingAddress || this.billingAddressListData.length === 0) && (!this.selectedShippingAddress || this.shippingAddressListData.length === 0)) {
      this.toastrService.error(this.translate.instant('checkOut.tostMsg.selectbotherAddress'));
      return;
    }

    if (!this.selectedBillingAddress || this.billingAddressListData.length === 0) {
      this.toastrService.error(this.translate.instant('checkOut.tostMsg.selectbillinge'));
      return;
    }

    if (!this.selectedShippingAddress || this.shippingAddressListData.length === 0) {
      this.toastrService.error(this.translate.instant('checkOut.tostMsg.selectshipping'));
      return;
    }

    if (this.checkoutData && this.selectedBillingAddress && this.selectedShippingAddress) {
      const checkout = <Checkout>{
        'billingAddressId': parseInt(this.selectedBillingAddress.addressid, 10),
        'shippingAddressId': parseInt(this.selectedShippingAddress.addressid, 10),
        'cartId': parseInt(this.checkoutData.cartid.toString(), 10),
        'requestFreeSample': this.checkoutData.policy,
      };
      this.preloader = true;
      this.productService.checkout(checkout).subscribe(result => {
        const response = result as Response;
        if (response.ok) {
          const res = response.json() as CheckoutResponse;
          this.toastrService.success(this.translate.instant('checkOut.tostMsg.ordersucess'));
          localStorage.setItem(AppLocalStorageKeys.ORDER_NUMBER, res.order);
          this.getCartCount();
          this.router.navigate([this.webUrl.ORDER_SUCCESS]);
        } else {
          if (response.json()[0]['errors'][0]['message']['inactiveProduct']) {
            this.toastrService.error(this.translate.instant('checkOut.tostMsg.orderFailedcart'));
          } else {
            this.toastrService.error(this.translate.instant('checkOut.tostMsg.orderFail'));
          }
        }
        this.preloader = false;
      },
        (error) => {
          this.toastrService.error(this.translate.instant('checkOut.tostMsg.orderFail'));
          this.preloader = false;
          console.log(error);
        });
    }
  }

  getCartCount() {
    this.productService.getCartCount().subscribe(res => {
      if (res.status) {
        const result = res.data;
        this.cartCount = result.reduce((acc, val) => {
          const productCount = parseInt(val.product_count, 10);
          return acc + productCount;
        }, 0);
        this.cartCountService.cartCountDetailChange(this.cartCount);
      } else {
        console.log('add to cart ' + res);
      }
    });
  }

  copyBillingAdress() {
    if (this.selectedBillingAddress) {
      const shippingAddresses = this.shippingAddressListData.filter(item => item.addressid === this.selectedBillingAddress.addressid);
      if (shippingAddresses.length === 0) {
        this.showShippingAddressForm = false;
        const billingAddress: AddressGet = <AddressGet>{};
        billingAddress.userid = this.selectedBillingAddress.userid;
        billingAddress.channelid = this.selectedBillingAddress.channelid;
        billingAddress.name = this.selectedBillingAddress.name;
        billingAddress.city = this.selectedBillingAddress.city;
        billingAddress.countryid = this.selectedBillingAddress.countryid;
        billingAddress.postalcode = this.selectedBillingAddress.postalcode;
        billingAddress.contactno2 = this.selectedBillingAddress.contactno2;
        billingAddress.contactno1 = this.selectedBillingAddress.contactno1;
        billingAddress.isshippingaddress = this.selectedBillingAddress.isshippingaddress;
        billingAddress.isbillingaddress = this.selectedBillingAddress.isbillingaddress;
        billingAddress.country = this.selectedBillingAddress.country;
        billingAddress.address = this.selectedBillingAddress.address;

        this.isButtonsClicked = true;
        this.showShippingAddressForm = true;
        const addressComp = this.userAddressComponent.toArray().filter(item => item.type === AddressType.SHIPPING)[0];
        if (addressComp) {
          addressComp.setFormData(billingAddress);
        } else {
          this.shippingAddressDetail = billingAddress;
        }
        this.timerId = setTimeout(this.setShippingPanelScollHeight, 500, this);

      } else {
        this.toastrService.error(this.translate.instant('checkOut.tostMsg.billingExists'));
      }
    } else {
      this.toastrService.error(this.translate.instant('checkOut.tostMsg.selectbillingcopyAddress'));
    }
  }

  onBillingItemClicked(index: number, address: AddressGet) {
    this.selectedBillingAddrIndex = index;
    this.selectedBillingAddress = address;

    if (this.shippingAddressListData) {
      if (!this.shippingAddressPanel.style.maxHeight) {
        if (this.shippingAddressListData.length === 0) {
          this.shippingAddressPanel.style.maxHeight = null;
          this.showShippingAddressForm = true;
          this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
        }
      }
    } else {
      if (!this.shippingAddressPanel.style.maxHeight) {
        this.shippingAddressPanel.style.maxHeight = null;
        this.showShippingAddressForm = true;
        this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
      }
    }
  }

  onShippingItemClicked(index: number, address: AddressGet) {
    this.selectedShippingAddrIndex = index;
    this.selectedShippingAddress = address;
  }

  onComponentLoaded(data: UserActionModel) {
    this.isButtonsClicked = true;

    if (data.action === ActionType.ADD) {
      if (data.type === AddressType.BILLING) {
        this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
      } else {
        this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
      }
    } else {
      if (data.type === AddressType.BILLING) {
        delete this.billingAddressDetail;
        this.billingAddressPanel.style.maxHeight = this.billingAddressPanel.scrollHeight + 'px';
      } else {
        delete this.shippingAddressDetail;
        this.shippingAddressPanel.style.maxHeight = this.shippingAddressPanel.scrollHeight + 'px';
      }
    }
  }

  ngOnDestroy() {
    this._checkoutservice.updateData(true);
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  fillCompanyBillingAddress() {
    if (!this.companyBillingAddress) {
      this.sharedService.getCompanyBillingAddress().subscribe(result => {
        if (result.ok) {
          this.companyBillingAddress = result.json() as CompanyBillingAddress;
          this.setCompanyBillingAddress();
        }
      });
    } else {
      this.setCompanyBillingAddress();
    }
  }

  setCompanyBillingAddress() {
    const addressComp = this.userAddressComponent.toArray().filter(item => item.type === AddressType.BILLING)[0];
    const contactInfo = JSON.parse(localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO)) as Contact;
    if (addressComp) {
      const billingAddress: AddressGet = <AddressGet>{};
      billingAddress.name = contactInfo.firstName + ' ' + contactInfo.lastName;
      billingAddress.city = this.companyBillingAddress.city;
      billingAddress.countryid = this.companyBillingAddress.countryId;
      billingAddress.postalcode = this.companyBillingAddress.postalCode;
      billingAddress.contactno2 = contactInfo.phone2 ? contactInfo.phone2 : '';
      billingAddress.contactno1 = contactInfo.mobileNo;
      billingAddress.address = this.companyBillingAddress.address;
      addressComp.setFormValues(billingAddress);
    }
  }

  showSummaryPanel() {
    if (!this.summaryPanel.style.maxHeight) {
      this.summaryPanel.style.maxHeight = this.summaryPanel.scrollHeight + 'px';
    }
  }

  getContactInfo() {
    const result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    let contactId: number;
    contactId = parseInt(result, 10);
    this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_INFO, JSON.stringify(response));
      this.setCompanyBillingAddress();
    },
      (error) => {
        console.log(error);
      });
  }
}

