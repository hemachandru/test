import { Component, OnInit, Input } from '@angular/core';
import { ProductRootObject } from '@app/product/models/product-view';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ScrollOptions } from '@app/config/constant';
@Component({
  selector: 'app-award-details',
  templateUrl: './award-details.component.html',
  styleUrls: ['./award-details.component.scss']
})
export class AwardDetailsComponent implements OnInit {

  _ProductRootObject: ProductRootObject;
  public opts: ISlimScrollOptions;

  constructor() {
    this._ProductRootObject = new ProductRootObject();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  ngOnInit() {
    this.opts = ScrollOptions;
  }
}
