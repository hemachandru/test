import { Component, OnInit, Input } from '@angular/core';
import { ProductRootObject, ProductInfoRootObject } from '@app/product/models/product-view';


@Component({
  selector: 'app-product-information',
  templateUrl: './product-information.component.html',
  styleUrls: ['./product-information.component.scss']
})

export class ProductInformationComponent implements OnInit {
  _ProductRootObject: ProductRootObject;
  _ProductInfoRootObject: ProductInfoRootObject;
  public scrollbarOptionsCnl = { axis: 'y', theme: 'dark' };

  constructor() {
    this._ProductRootObject = new ProductRootObject();
    // this._ProductInfoRootObject = new ProductInfoRootObject();
  }

  @Input() set productDetail(value: ProductRootObject) {
    this._ProductRootObject = value;
  }

  @Input() set productInfo(value: ProductInfoRootObject) {
    this._ProductInfoRootObject = value;
  }

  ngOnInit() {
  }

  setValueProduct() {
  }

}
