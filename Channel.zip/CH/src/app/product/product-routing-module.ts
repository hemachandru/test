import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';
import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { AddProductComponent } from './component/add-product/add-product.component';
import { ViewProductComponent } from './component/view-product/view-product.component';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductImportComponent } from './component/product-import/product-import.component';
import { UserAccountStatus } from '@app/config/constant';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { OrderSuccessMessageComponent } from './component/order-success-message/order-success-message.component';
import { WishListComponent } from './component/wish-list/wish-list.component';
import { CartListComponent } from './component/cart-list/cart-list.component';
import { RatingDetailViewComponent } from '@app/order/rating-detail-view/rating-detail-view.component';

const routes: Routes = [
  {
    path: 'productlist', children:
      [
        {
          path: '', component: ProductListComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'productview/:id', component: ViewProductComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'productmanage', component: AddProductComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'productimport', component: ProductImportComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'productView/:id', component: ViewProductComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
      ],
  },
  {
    path: 'ordersuccess', component: OrderSuccessMessageComponent, canActivate: [AuthGuard],
    data: {
      currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
    }
  },
  {
    path: 'wishlist', children:
      [
        {
          path: '', component: WishListComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        // {
        //   path: 'productview/:id', component: ViewProductComponent, canActivate: [AuthGuard],
        //   data: {
        //     currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
        //   }
        // }
        {
          path: 'productview/:id', children:
              [
                  {
                      path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                      data: {
                          currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                      }
                  },
                  {
                      path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                      data: {
                          currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                      }
                  },
              ]
      },
      ],
  },
  {
    path: 'cart', children:
      [
        {
          path: '', component: CartListComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },

        {
          path: 'productview/:id', component: ViewProductComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'checkout', component: CheckoutComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        }
      ]
  }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: []
})

export class ProductRoutingModule {
}
