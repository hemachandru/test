
export interface ProductGroup {
    productGroupId: string;
    productGroup: string;
    isActive: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt: Date;
}

export interface ProductCategory {
    productCategorieId: string;
    productGroupId: string;
    productCategorie: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt: Date;
}

export interface Document {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface Brand {
    id: number;
    brandName: string;
    documentId: string;
    isAssigned: string;
    isVerified: string;
    isActive: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt?: any;
    document: Document;
}

export interface ProductDetail {
    productdetailid: string;
    productId: string;
    videourl: string;
    productdesc: string;
    usp: string;
    isavaialbleimmediate: string;
    avaialblefrom: Date;
    avaialbilitycomment: string;
    updatedby: string;
    deletedat?: any;
    keyretailers: string;
}

export interface ProductTag {
    producttagid: string;
    productId: string;
    tag: string;
    updatedby: string;
    deletedat?: any;
}

export interface Reviewmagazinelogo {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface ProductArticleReview {
    productarticlereviewid: string;
    productId: string;
    productreviewername: string;
    articleurl: string;
    reviewmagazinelogoid: string;
    updatedby: string;
    deletedat?: any;
    reviewmagazinelogo: Reviewmagazinelogo;
}

export interface ProductExistRating {
    productexistratingid: string;
    productId: string;
    existproductrating: number;
    ratingproofvalidationurl: string;
    updatedby: string;
    deletedat?: any;
}

export interface Image {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface ProductImage {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image;
}

export interface Image2 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface DefaultImage {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image2;
}

export interface ProductSharePreference {
    productsharepreferenceid: string;
    productId: string;
    sharetypeid: string;
    updatedby: string;
    deletedat?: any;
}

export interface ProductUniversalCode {
    productuniversalcodeid: string;
    productId: string;
    productuniversalcodetype: string;
    code: string;
    updatedby: string;
    deletedat?: any;
}

export interface Retailerpriceunitdetail {
    unitid: string;
    unit: string;
}

export interface Samplepriceunitdetail {
    unitid: string;
    unit: string;
}

export interface Distributorunitdetail {
    discountUnitId: string;
    discountUnit: string;
}

export interface Retailerunitdetail {
    discountUnitId: string;
    discountUnit: string;
}

export interface ProductPriceDetail {
    productpricedetailid: string;
    productId: string;
    businesscurrencyid?: any;
    retailerprice: string;
    retailerpriceunitid: string;
    issamplefree: string;
    sampleprice: string;
    samplepriceunitid: string;
    distributormarginpercent: number;
    distributormarginpercentunitid: string;
    retailermarginpercent: number;
    retailermarginpercentunitid: string;
    samplethreshold: string;
    isunlimitsample: string;
    updatedby: string;
    deletedat?: any;
    retailerpriceunitdetail: Retailerpriceunitdetail;
    samplepriceunitdetail: Samplepriceunitdetail;
    distributorunitdetail: Distributorunitdetail;
    retailerunitdetail: Retailerunitdetail;
}

export interface Orderunitdetail {
    unitid: string;
    unit: string;
}

export interface Packageunitdetail {
    unitid: string;
    unit: string;
}

export interface Noofpackageinboxunitdetail {
    unitid: string;
    unit: string;
}

export interface Noofboxinpalletunitdetail {
    unitid: string;
    unit: string;
}

export interface Approximateweightofpalletunitdetail {
    unitid: string;
    unit: string;
}

export interface ProductPackageInfo {
    productpackageinfoid: string;
    productId: string;
    minorderquantity: string;
    orderunitid: string;
    packagesize: string;
    packageunit: string;
    noofboxinpallet: string;
    noofboxinpalletunitid: string;
    noofpackageinbox: string;
    noofpackageinboxunitid: string;
    approximateweightofpallet: string;
    approximateweightofpalletunitid: string;
    length: string;
    breadth: string;
    height: string;
    weight: string;
    updatedby: string;
    deletedat?: any;
    orderunitdetail: Orderunitdetail;
    packageunitdetail: Packageunitdetail;
    noofpackageinboxunitdetail: Noofpackageinboxunitdetail;
    noofboxinpalletunitdetail: Noofboxinpalletunitdetail;
    approximateweightofpalletunitdetail: Approximateweightofpalletunitdetail;
}

export interface ProductCompeting {
    productcompetingid: string;
    productId: string;
    competingproduct: string;
    competitor: string;
    competitorproducturl: string;
    updatedby: string;
    deletedat?: any;
}

export interface ProfileType {
    id: string;
    name: string;
}

export interface ChannelType {
    id: string;
    name: string;
}

export interface PTClas {
    profileTypeClassif: string;
    profileTypeId: string;
    channelTypeId: string;
    isDefault?: any;
    profileType: ProfileType;
    channelType: ChannelType;
}

export interface Profile {
    customerProfileId: string;
    profileTypeId: string;
    profileTypeClassification: string;
    deletedAt?: any;
    pTClas: PTClas;
}

export interface ProductChannelCustomerProfile {
    productchannelcustomerprofileid: string;
    productId: string;
    channelId: string;
    customerProfileId: string;
    updatedby: string;
    deletedat?: any;
    profile: Profile;
}

export interface RetailerImage {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface Country {
    countryId: string;
    country: string;
}

// export interface ProductKeyRetailer {
//     productkeyretailerid: string;
//     productId: string;
//     retailername: string;
//     countryid: string;
//     documentid: string;
//     updatedby: string;
//     deletedat?: any;
//     retailerImage: RetailerImage;
//     country: Country;
// }

export interface ProductKeyRetailer {
    keyretailerid: number;
    active: Active;
    old?: any;
    new?: any;
    isVerified: number;
}

export interface ProductKeyDistributor {
    keyretailerid: number;
    active: Active;
    old?: any;
    new?: any;
    isVerified: number;
}

export interface Active {
    id: number;
    company_name: string;
    country: Country;
    logo: Logo;
    plan: Plan;
}

export interface Country {
    country_id: number;
    country_name: string;
}

export interface Logo {
    logo_id: number;
    documentPath: string;
    documentUrl: string;
}

export interface Plan {
    plan_id: number;
    plan_name: string;
}

export interface Country2 {
    countryId: string;
    country: string;
}

export interface RegionCountryJCT {
    regionCountryJCTId: string;
    regionId: string;
    countryId: string;
    deletedAt?: any;
    country: Country2;
}

export interface ProductLocation {
    productlocationid: string;
    productId: string;
    locationtype: string;
    regionCountryJCTId: string;
    updatedby: string;
    deletedat?: any;
    regionCountryJCT: RegionCountryJCT;
}

export interface RETAILER {
    Channel_Profile_ID: number;
    Channel_Profile_Name: string;
    Channel_Type_ID: number;
    Channel_Type_Name: string;
    Channel_Profile_Type_Classification_ID: number;
    Channel_Customer_Profile_ID: string;
}

export interface Locations {
    SELLING: string[];
    TARGET: string[];
    RETAIL: any[];
}

export interface Image3 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface PRODUCT {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image3;
}

export interface Image4 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface DISPLAY {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image4;
}

export interface Image5 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface PACKING {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image5;
}

export interface Image6 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface BROUCHER {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: Image6;
}

export interface Images {
    PRODUCT: PRODUCT[];
    DISPLAY: DISPLAY[];
    PACKING: PACKING[];
    BROUCHER: BROUCHER[];
}

export class ProductRootObject {
    productId: string;
    channelId: string;
    productGroupId: string;
    productCategorieId: string;
    product: string;
    brandId: string;
    productSKU: string;
    productkey: string;
    isshowtofreesub: string;
    isactive: string;
    hasanyvariant: string;
    variantdetails: string;
    productqualitylevel: string;
    defaultimageid: string;
    updatedBy: string;
    deletedat?: any;
    productGroup: ProductGroup;
    productCategory: ProductCategory;
    brand: Brand;
    productDetail: ProductDetail;
    productTag: ProductTag[];
    productArticleReview: ProductArticleReview[];
    productExistRating: ProductExistRating[];
    productImage: ProductImage[];
    defaultImage: DefaultImage;
    productSharePreference: ProductSharePreference[];
    productUniversalCode: ProductUniversalCode[];
    productPriceDetail: ProductPriceDetail;
    productPackageInfo: ProductPackageInfo;
    productCompeting: ProductCompeting[];
    productChannelCustomerProfile: ProductChannelCustomerProfile[];
    productKeyRetailer: ProductKeyRetailer[];
    productKeyDistributor: ProductKeyDistributor[];
    productLocation: ProductLocation[];
    RETAILER: RETAILER[];
    locations: Locations;
    images: Images;
    channelTypeId: string;
    companyName: string;
    productAwards: ProductAwards[];
}

export class ProductAwards  {
    awardDetail: string;
    isLifeTime: string;
    issuedBy: string;
    productAwardId: number;
    validUpto: Date;
}

export interface Paymentoptiontype {
    paymentoptio?: any;
    paymenttype?: any;
}

export interface ChannelPaymentOptionType {
    paymentoptiontypeid?: any;
    paymentoptiontype: Paymentoptiontype;
}

export interface ChannelPaymentTerm {
    paymenttermid?: any;
    paymentterm?: any;
}


export class ProductInfoRootObject {
    channelPaymentOptionType: ChannelPaymentOptionType[];
    channelPaymentTerm: ChannelPaymentTerm[];
}


export class ProductDismissReasons {
    rejectreasonid: string;
    rejectreason: string;
}
export class ProductRejectObject {
    rejectreasonId: string;
    productId: string;
    comment?: string;
}


