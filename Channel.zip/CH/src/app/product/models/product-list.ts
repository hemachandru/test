  export interface Brand {
      id: number;
      brandName: string;
      documentId: string;
      isAssigned: string;
      isVerified: string;
      isActive: string;
      deletedAt?: any;
      createdAt: Date;
      updatedAt?: any;
  }

  export interface ProductCategory {
      productCategorieId: string;
      productGroupId: string;
      productCategorie: string;
      deletedAt?: any;
      createdAt: Date;
      updatedAt: Date;
  }

  export interface ProductGroup {
      productGroupId: string;
      productGroup: string;
      isActive: string;
      deletedAt?: any;
      createdAt: Date;
      updatedAt: Date;
  }

  export interface ProductPriceDetail {
      productpricedetailid: string;
      productId: string;
      businesscurrencyid?: any;
      retailerprice: string;
      retailerpriceunitid: string;
      issamplefree: string;
      sampleprice: string;
      samplepriceunitid: string;
      distributormarginpercent: number;
      distributormarginpercentunitid?: any;
      retailermarginpercent: number;
      retailermarginpercentunitid?: any;
      samplethreshold: string;
      isunlimitsample: string;
      updatedby: string;
      createdat: Date;
      updatedat: Date;
      deletedat?: any;
      businesscurrency?: any;
  }

  export interface Image {
      documentUrl: string;
      documentId: string;
      documentTypeId: number;
      documentPath: string;
      deletedAt?: any;
  }

  export interface ProductImage {
      productimageid: string;
      productId: string;
      imageid: string;
      productimagetype: string;
      updatedby: string;
      isdefault: string;
      sortorder: string;
      createdat: Date;
      updatedat: Date;
      deletedat?: any;
      image: Image;
  }

  export interface Image2 {
      documentUrl: string;
      documentId: string;
      documentTypeId: number;
      documentPath: string;
      deletedAt?: any;
  }

  export interface DefaultImage {
      productimageid: string;
      productId: string;
      imageid: string;
      productimagetype: string;
      updatedby: string;
      isdefault: string;
      sortorder?: any;
      createdat: Date;
      updatedat: Date;
      deletedat?: any;
      image: Image2;
  }

  export interface Locations {
      TARGET: string[];
      SELLING: string[];
      RETAIL: any[];
  }

  export interface Product {
      productId: string;
      channelId: string;
      productGroupId: string;
      productCategorieId: string;
      product: string;
      brandId: string;
      productSKU: string;
      productkey: string;
      isshowtofreesub: string;
      isactive: string;
      hasanyvariant: string;
      variantdetails?: any;
      productqualitylevel: string;
      defaultimageid: string;
      updatedBy: string;
      createdat: Date;
      updatedat: Date;
      deletedat?: any;
      brand: Brand;
      productCategory: ProductCategory;
      productGroup: ProductGroup;
      productPriceDetail: ProductPriceDetail;
      productImage: ProductImage[];
      defaultImage: DefaultImage;
      locations: Locations;
  }

  export interface ProductListRootObject {
      Products: Product[];
      total: number;
      activeTotal: number;
      inActiveTotal: number;
      offset: number;
      limit: number;
      page: number;
      results?: any[];
  }
