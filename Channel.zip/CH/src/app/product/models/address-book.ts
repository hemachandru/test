import { Pagination } from '@app/shared/models/shared-model';
export class AddressBookAdd {
    name: string;
    primary_phone_code?: string;
    primary_contactno: string;
    alternative_phone_code?: string;
    alternative_contactno: string;
    address: string;
    countryId: number;
    postalCode: string;
    city: string;
    isshippingaddress: boolean;
    isbillingaddress: boolean;
}

export interface AddressGet {
    addressid: string;
    userid: string;
    channelid: string;
    name: string;
    address: string;
    city: string;
    countryid: string;
    postalcode: string;
    contactno1: string;
    contactno2: string;
    isshippingaddress: string;
    isbillingaddress: string;
    country: Country;
}

export interface AddressList {
    pagination: Pagination;
    results: AddressGet[];
}

export interface Country {
    country: string;
}
