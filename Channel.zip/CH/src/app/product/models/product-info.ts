
    export interface Country {
        countryId: string;
        country: string;
    }

    export interface Document {
        documentUrl: string;
        documentId: string;
        documentTypeId: number;
        documentPath: string;
        deletedAt?: any;
    }

    export interface Contact {
        contactId: string;
        firstName: string;
        lastName: string;
        jobTitle: string;
        isDefaultContact: string;
        deletedAt?: any;
        documentId: string;
        document: Document;
    }

    export interface SubscriptionPlan {
        subsc: string;
        isAct: string;
        delet?: any;
    }

    export interface Subscription {
        subscriptionPlanId: string;
        isActive: string;
        deletedAt?: any;
        subscriptionPlan: SubscriptionPlan;
    }

    export interface ChannelSubscription {
        subscriptionId: string;
        actualAmount: string;
        finalAmount: string;
        paymentTransactionId: string;
        startedAt: Date;
        endAt: Date;
        isActive: string;
        subscription: Subscription;
    }

    export interface ChannelBrand {
        channelBrandId: string;
        channelId: string;
        brandId: string;
        deletedAt?: any;
        createdAt: Date;
        updatedAt?: any;
    }

    export interface Document2 {
        documentUrl: string;
        documentId: string;
        documentTypeId: number;
        documentPath: string;
        deletedAt?: any;
    }

    export interface Brand {
        id: number;
        brandName: string;
        documentId: string;
        isAssigned: string;
        isVerified: string;
        isActive: string;
        deletedAt?: any;
        createdAt: Date;
        updatedAt?: any;
        ChannelBrand: ChannelBrand;
        document: Document2;
    }

    export interface Paymentoptiontype {
        paymentoptio?: any;
        paymenttype?: any;
    }

    export interface ChannelPaymentOptionType {
        paymentoptiontypeid?: any;
        paymentoptiontype: Paymentoptiontype;
    }

    export interface ChannelPaymentTerm {
        paymenttermid?: any;
        paymentterm?: any;
    }


export interface ChannelType {
  channelTypeId?: string;
  channelType?: string;
}

    export interface Channel {
        channelId: string;
        companyName: string;
        companyMail: string;
        signUpStatusId: string;
        channelTypeId: string;
        countryId: string;
        profileTypeId: string;
        isActive: string;
        oldChannelId?: any;
        deletedAt?: any;
        country: Country;
        contact: Contact;
        channelSubscription: ChannelSubscription;
        brand: Brand[];
        channelPaymentOptionType: ChannelPaymentOptionType[];
        channelPaymentTerm: ChannelPaymentTerm[];
        channelType: ChannelType;
        isFrenchTech: string;
    }

    export class ProductInfoObject {
        productId: string;
        channelId: string;
        productGroupId: string;
        productCategorieId: string;
        product: string;
        brandId: string;
        productSKU: string;
        productkey: string;
        isshowtofreesub: string;
        isactive: string;
        hasanyvariant: string;
        variantdetails?: any;
        productqualitylevel: string;
        defaultimageid: string;
        updatedBy: string;
        deletedat?: any;
        channel: Channel;
        relation?: any;
    }
