
    export interface ChannelLogo {
        documentUrl: string;
        documentId: string;
        documentTypeId: number;
        documentPath: string;
        deletedAt?: any;
    }

    export interface ChannelIcon {
        documentUrl: string;
        documentId: string;
        documentTypeId: number;
        documentPath: string;
        deletedAt?: any;
    }

    export interface ChannelDetail {
        channelDetailId: string;
        channelLogoId: string;
        channelIconId: string;
        estYear: string;
        regYear: string;
        detailDesc: string;
        webSiteUrl: string;
        channelLogo: ChannelLogo;
        channelIcon: ChannelIcon;
    }

    export interface Country {
        countryId: string;
        country: string;
    }

    export interface PartnerChannel {
        channelId: string;
        companyName: string;
        companyMail: string;
        signUpStatusId: string;
        channelTypeId: string;
        countryId: string;
        profileTypeId: string;
        isActive: string;
        oldChannelId?: any;
        deletedAt?: any;
        channelDetail: ChannelDetail;
        country: Country;
    }

    export interface Channel {
        channelJCTId: string;
        channelId: string;
        partnerChannelId: string;
        connectionStatusTypeId: string;
        deletedat?: any;
        createdAt: Date;
        updatedAt: Date;
        partnerChannel: PartnerChannel;
    }

    export class PartnerChannelObject {
        channel: Channel[];
        total: number;
    }



