export interface ZoneRegionJCT {
    zoneRegionJCTId: string;
}

export interface RegionCountryJCT {
    regionCountryJCTId: string;
}

export interface Country {
    countryId: string;
    country: string;
    deletedAt?: any;
    RegionCountryJCT: RegionCountryJCT;
}

export interface Region {
    regionId: string;
    region: string;
    channelId?: any;
    ZoneRegionJCT: ZoneRegionJCT;
    country: Country[];
}

export interface Zone {
    zoneId: string;
    zone: string;
    region: Region[];
}

export interface ChannelLocation {
    TARGET: Zone[];
    SELLING: Zone[];
    RETAIL: Zone[];
}

export interface ChannelLocationSearchItem {
    parentId?: string;
    id: string;
    name: string;
    isChecked: boolean;
    regioncountryjctid?: string;
  }

  export interface RegionCountryJCT1 {
    regioncountryjctid: string;
}

export interface ChannelLocationDetail {
    currentLocation: ChannelLocation;
    oldLocation: ChannelLocation;
}
