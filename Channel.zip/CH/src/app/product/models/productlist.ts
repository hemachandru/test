export interface Brand {
    id: number;
    brandName: string;
    documentId: string;
    isAssigned: string;
    isVerified: string;
    isActive: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt?: any;
}

export interface ProductCategory {
    productCategorieId: string;
    productGroupId: string;
    productCategorie: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt: Date;
}

export interface ProductGroup {
    productGroupId: string;
    productGroup: string;
    isActive: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt: Date;
}

export interface Businesscurrency {
    currencyid: string;
    currency: string;
}

export interface ProductPriceDetail {
    productpricedetailid: string;
    productId: string;
    businesscurrencyid: string;
    retailerprice: string;
    retailerpriceunitid: string;
    issamplefree: string;
    sampleprice: string;
    samplepriceunitid: string;
    distributormarginpercent?: number;
    distributormarginpercentunitid: string;
    retailermarginpercent?: number;
    retailermarginpercentunitid: string;
    samplethreshold: string;
    isunlimitsample: string;
    updatedby: string;
    createdat?: Date;
    updatedat: Date;
    deletedat?: any;
    businesscurrency: Businesscurrency;
}

export interface Image {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface ProductImage {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    createdat: Date;
    updatedat: Date;
    deletedat?: any;
    image: Image;
}

export interface Locations {
    TARGET: string[];
    SELLING: string[];
    RETAIL: any[];
}

// export interface Product {
//     productId: string;
//     channelId: string;
//     productGroupId: string;
//     productCategorieId: string;
//     product: string;
//     brandId: string;
//     productSKU: string;
//     productkey: string;
//     isshowtofreesub: string;
//     isactive: string;
//     defaultimageid: string;
//     defaultimage: string;
//     hasanyvariant: string;
//     variantdetails: string;
//     productqualitylevel: string;
//     updatedBy: string;
//     createdat?: Date;
//     updatedat: Date;
//     deletedat?: any;
//     defaultImage: DefaultImage;
//     brand: Brand;
//     productCategory: ProductCategory;
//     productGroup: ProductGroup;
//     productPriceDetail: ProductPriceDetail;
//     productImage: ProductImage[];
//     locations: Locations;
//     sellinglocation: string;
//     tragetlocation: string;
// }

export interface DefaultImage {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    isdefault: string;
    sortorder?: any;
    createdat: Date;
    updatedat: Date;
    deletedat?: any;
    image: Image2;
}
export interface Image2 {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}



export interface Pagination {
    limit: number;
    page: number;
    total: number;
}

export interface Code {
    code: string;
    id: number;
    type: string;
}

export interface Retailer {
    margin_price: number;
    margin_unit: string;
}

export interface Currency {
    code: string;
    id: string;
}

export interface Sample {
    unit: string;
    price: string;
}

export interface Distributor {
    margin_price: number;
    margin_unit: string;
}

export interface Retail {
    unit: string;
    price: string;
}

export interface Price {
    is_sample_free: boolean;
    is_unlimited_sample: boolean;
    retailer: Retailer;
    currency: Currency;
    sample_threshold: string;
    sample: Sample;
    distributor: Distributor;
    retail: Retail;
}

export interface Company {
    name: string;
    id: number;
    is_french_tech: boolean;
}

export interface Brand {
    name: string;
    id: number;
}

export interface ProductFamily {
    name: string;
    id: number;
}

export interface Others {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Primary {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Images {
    others: Others[];
    primary: Primary[];
}

export interface Preference {
    name: string;
    id: number;
}

export interface Location {
    name: string;
    id: number;
}

export interface Target {
    locations: Location[];
}

export interface Location2 {
    name: string;
    id: number;
}

export interface Selling {
    locations: Location2[];
}

export interface ProductCategory {
    name: string;
    id: number;
}

export class Product {
    avaialble_from?: any;
    codes: Code[];
    has_variant: boolean;
    created_at: Date;
    usp: string;
    updated_at: Date;
    price: Price;
    company: Company;
    id: number;
    is_avaialble_immediate: boolean;
    sku: string;
    brand: Brand;
    productdesc: string;
    product_family: ProductFamily[];
    images: Images;
    is_active: boolean;
    company_id: number;
    preference: Preference[];
    avaialbility_comment?: any;
    deleted_at?: any;
    quality: string;
    target: Target;
    urlkey: string;
    can_view_free_plan_members: boolean;
    name: string;
    selling: Selling;
    variantdetails?: any;
    product_category: ProductCategory[];
    sellinglocation: string;
    tragetlocation: string;
    defaultimage: string;
    other_info: RatingDetails;
}

export class RatingDetails {
    no_of_evaluations: number;
    rating: number;
    no_of_orders: number;
}
export interface RetailerMinMargin {
    value: number;
}

export interface RetailMaxPrice {
    value: number;
}

export interface Bucket {
    key: number;
    doc_count: number;
}

export interface Brands {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Bucket[];
}

export interface DistributerMinMargin {
    value: number;
}

export interface RetailerMaxMargin {
    value: number;
}

export interface RetailMinPrice {
    value: number;
}

export interface Bucket2 {
    key: number;
    key_as_string: string;
    doc_count: number;
}

export interface FreeSample {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Bucket2[];
}

export interface Bucket3 {
    key: number;
    doc_count: number;
}

export interface Family {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Bucket3[];
}

export interface Bucket4 {
    key: number;
    doc_count: number;
}

export interface Category {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Bucket4[];
}

export interface DistributerMaxMargin {
    value: number;
}

export interface Bucket5 {
    key: string;
    doc_count: number;
}

export interface Quality {
    doc_count_error_upper_bound: number;
    sum_other_doc_count: number;
    buckets: Bucket5[];
}

export interface Aggregations {
    retailer_min_margin: RetailerMinMargin;
    retail_max_price: RetailMaxPrice;
    brands: Brands;
    distributer_min_margin: DistributerMinMargin;
    retailer_max_margin: RetailerMaxMargin;
    retail_min_price: RetailMinPrice;
    free_sample: FreeSample;
    family: Family;
    category: Category;
    distributer_max_margin: DistributerMaxMargin;
    quality: Quality;
    status: ActiveinactiveCount;
}

export class ActiveinactiveCount {
    active: number;
    inactive: number;
}
// export interface RootObject {
//     pagination: Pagination;
//     results: Result[];
//     aggregations: Aggregations;
// }


export class ProductList {
    results: Product[];

    pagination: Pagination;
    aggregations: Aggregations;
}

export class Pagination {
    limit: number;
    page: number;
    total: number;
    offset: number;
}

export class FilterItems {
    isActive: boolean;
    quality: any[];
    brandIds: BrandId[];
    productFamilyIds: GroupId[];
    productCategoryIds: CatgoryId[];
    is_french_tech: boolean;
}
export class BrandId {

}
export class GroupId {
}
export class CatgoryId {

}

export interface ProductListExclude {
    isActive?: boolean;
    excludedProductSku: string[];
    channelId?: 0;
}

export class WishlistFilterItems {
    type: string;
    quality: any[];
    is_sample_free: boolean;
    retail_price_min: number;
    retail_price_max: number;
    retailer_commission_min: number;
    retailer_commission_max: number;
    distributor_commission_min: number;
    distributor_commission_max: number;
    brandIds: BrandId[];
    productFamilyIds: GroupId[];
    productCategoryIds: CatgoryId[];
    is_french_tech?: boolean;
}

