export class AddProduct {
    productBasicInfo: ProductBasicInfoAdd;
    productArticleReview: ProductArticleReview;
    productImages: ProductImages;
    productBrochure: ProductBrochure;
    productPreferences: ProductPreferences;
    productCode: ProductCodeAdd;
    productPrice: ProductPrice;
    productPackageInfo: ProductPackageInfo;
    productCompeting: ProductCompetingAdd;
    productPosition: ProductPosition;
    productRelevantChannel: ProductRelevantChannel;
    // productKeyRetailer: ProductKeyRetailerListAdd;
    productSellingLocation: ProductSellingLocation;
    productTargetLocation: ProductTargetLocation;
    productAvailability: ProductAvailability;
    deletedproducttag?: number[];
    deletedarticlereview?: number[];
    deletedexistingrating?: number[];
    deletedproductimage?: number[];
    deletedproductdisplayimage?: number[];
    deletedproductpackageimage?: number[];
    deletedproductbrochure?: number[];
    deletedcompetingproduct?: number[];
    deletedkeyretailer?: number[];
    deletedkeydistributor?: number[];
    award_details: AwardDetail[];
    deleted_award_details?: number[];
    keyRetailers: KeyRetailerListPost[];
    keyDistributors: KeyRetailerListPost[];
}

export class KeyRetailerListPost {
    channelId?: number;
    oldchannelid?: number;
    // companyName: string;
    documentPath: string;
    keypartnerid?: number;
    countryid: number;
    partnername: string;
    existchannelid?: number;
    image: string;
    channelkeypartnerid?: number;
    imageid?: number;
    documentUrl?: string;
}

export class AwardDetail {
    product_award_id: number;
    details: string;
    issued_by: string;
    valid_upto: Date;
    isLifeTime: string;
    image: string;
    imageId?: number;
}

export class Producttag {
    producttagid?: number;
    tag: string;
}

export class ProductBasicInfo {
    productname: string;
    productstatus: string;
    productgroup: number;
    productcategory: number;
    productbrand: number;
    productdesc: string;
    productusp: string;
}

export class ProductBasicInfoAdd extends ProductBasicInfo {
    producttag: Producttag[];
    keyretailers: string;
    keydistributors: string;
}


export class Review {
    productarticlereviewid?: number;
    imageid?: number;
    reviewername: string;
    logo: string;
    articleurl: string;
}

export class Productexistingrating {
    productexistratingid?: number;
    existproductrating: number;
    ratingproofvalidationurl: string;
    ratingproofvalidationlogo: string;
    ratingproofvalidationlogoid: number;
    ratingproofvalidationname: string;
}

export class ProductArticleReview {
    review: Review[];
    productexistingrating: Productexistingrating[];
}

export class ProductImageClass {
    image: string;
    isdefault: string;
    sortorder: number;
}

export class Productimage extends ProductImageClass {
    productimageid?: number;
    imageid?: number;
}

export class Productdisplayimage extends ProductImageClass {
    productimageid?: number;
    imageid?: number;
}

export class Productpackagingimage extends ProductImageClass {
    productimageid?: number;
    imageid?: number;
}

export class ProductImages {
    productimage: Productimage[];
    productdisplayimage: Productdisplayimage[];
    productpackagingimage: Productpackagingimage[];
    videourl: string;
}

export class Productpdf {
    productimageid?: number;
    imageid?: number;
    image: string;
    isdefault: string;
    sortorder: number;
}

export class ProductBrochure {
    productpdf: Productpdf[];
}

export class Preference {
    sharetypeid: number;
}

export class ProductPreferences {
    preferences: Preference[];
    isshowtofreesub: string;
}

export class ProductCodeType {
    productuniversalcodeid?: number;
    productuniversalcodetype: string;
    code: string;
}

export class ProductCode {
    hasanyvariant: string;
    variantdetails: string;
}

export class ProductCodeAdd extends ProductCode {
    productCodeTypes: ProductCodeType[];
}

export class ProductPrice {
    retailerprice: number;
    retailerpriceunitid: number;
    sampleprice: number;
    samplepriceunitid: number;
    issamplefree: string;
    distributormarginpercent: number;
    distributormarginpercentunitid?: number;
    retailermarginpercent: number;
    retailermarginpercentunitid?: number;
    samplethreshold: number;
    isunlimitsample: string;
    currencyid: number;
}

export class ProductPackageInfo {
    minorderquantity: number;
    orderunitid: number;
    packagesize: number;
    packageunit: number;
    noofpackageinbox: number;
    noofpackageinboxunitid: number;
    noofboxinpallet: number;
    noofboxinpalletunitid: number;
    approximateweightofpallet: number;
    approximateweightofpalletunitid: number;
    length: number;
    breadth: number;
    height: number;
    weight: number;
}

export class Productcompeting {
    productcompetingid?: number;
    competingproduct: string;
    competitor: string;
    competitorproducturl: string;
}

export class ProductCompetingAdd {
    productcompeting: Productcompeting[];
}

export class ProductPosition {
    productqualitylevel: string;
}

export class Distributionchannel {
    customerProfileId: number;
}

export class Retailchannel {
    customerProfileId: number;
}

export class ProductRelevantChannel {
    distributionchannel: Distributionchannel[];
    retailchannel: Retailchannel[];
}

export class Productkeyretailer {
    productkeyretailerid?: number;
    retailername: string;
    countryid: number;
    image: string;
    imageid: number;
}

export class ProductKeyRetailerListAdd {
    productkeyretailer: Productkeyretailer[];
}

export class ProductSellingLocation {
    sellinglocation: Targetlocation[];
}

export class Targetlocation {
    regioncountryjctid: number;
}

export class ProductTargetLocation {
    targetlocation: Targetlocation[];
}

export class ProductAvailability {
    isavaialbleimmediate: string;
    avaialblefrom?: Date;
    avaialbilitycomment?: string;
}

export class PageAction {
    value: string;
    action: string;
}

export class NewKeyRetailer {
    retailername: string;
    countryid: number;
    image: string;
}
