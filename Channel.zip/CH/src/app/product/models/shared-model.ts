export interface CheckoutInput {
    cartId: any;
    requestFreeSample: any;
}

export interface Checkout {
    billingAddressId: number;
    shippingAddressId: number;
    cartId: number;
    requestFreeSample: boolean;
}

export interface CheckoutResponse {
    status: boolean;
    order: string;
}

export interface CompanyBillingAddress {
    addressId: string;
    address: string;
    city: string;
    countryId: string;
    postalCode: string;
}
