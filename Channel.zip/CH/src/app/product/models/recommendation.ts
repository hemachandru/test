export class RegAddress {
    addressId: string;
    address: string;
    city: string;
    countryId: string;
    postalCode: string;
}

export class BillAddress {
    addressId: string;
    address: string;
    city: string;
    countryId: string;
    postalCode: string;
}

export class RecommendationGet {
    channelId: string;
    signUpStatusId: string;
    planId: string;
    subscriptionId: string;
    companyName: string;
    companyMail: string;
    countryId: string;
    showId: string;
    oldChannelId?: any;
    profileTypeId: string;
    channelTypeId: string;
    regAddressId: string;
    billAddressId: string;
    isActive: string;
    deletedAt?: any;
    createdAt: Date;
    updatedAt: Date;
    slug: string;
    profileStrength: number;
    stripeCustomerId: string;
    autoRenewalOff: string;
    regAddress: RegAddress;
    billAddress: BillAddress;
    channelDetail: ChannelDetail;
    user: User[];
}

export interface Regaddress {
    oldAddressId: number;
    address: string;
    city: string;
    countryId: number;
    postalCode: string;
}

export interface Oldchanneldetail {
    webSiteUrl: string;
}

export class Oldchannel {
    oldChannelId: number;
    companyMail: string;
    companyName: string;
    regaddress: Regaddress;
    oldchanneldetail: Oldchanneldetail;
    boolActive: boolean;
}

export interface Regaddress2 {
    addressId: number;
    address: string;
    city: string;
    countryId: number;
    postalCode: string;
}

export interface Channeldetail {
    webSiteUrl: string;
}

export interface Contact {
    contactId: number;
    firstName: string;
    lastName: string;
}

export class Channel {
    channelId: number;
    companyMail: string;
    companyName: string;
    regaddress: Regaddress2;
    channeldetail: Channeldetail;
    contact: Contact;
    boolActive: boolean;
}

export class RecommendationRootObject {
    oldchannel: Oldchannel[];
    channel: Channel[];
}

export class ChannelDetail {
    webSiteUrl: string;
}

export class User {
    contact: Contact;
}

export class Contact {
    firstName: string;
    lastName: string;
}

export class RecomendationPost {
    existchannelid: number;
    oldchannelid: number;
    // vendorchannelid: number;
    suggestedto: number;
    suggestedto_type: number;
    suggested_type: number;
    companyname: string;
    countryid: number;
    city: string;
    postalcode: string;
    mail: string;
    mobileno: string;
    address: string;
    confirm: boolean;
    contactname: string;
    websiteurl: string;
    occasion: string;
    note: string;
}

export class FilterResult {
    locationId?: any[];
    brandId?: any[];
}
