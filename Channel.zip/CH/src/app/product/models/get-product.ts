import {
    Producttag
} from '../models/add-product';
import {
    CountryMaster, RelevantChannel
  } from '@app/shared/models/shared-model';


export class GetProduct {
}
export interface DocumentGet {
    documentUrl: string;
    documentId: string;
    documentTypeId: number;
    documentPath: string;
    deletedAt?: any;
}

export interface ProductDetail {
    productdetailid: string;
    productId: string;
    videourl: string;
    productdesc: string;
    usp: string;
    isavaialbleimmediate: string;
    avaialblefrom?: any;
    avaialbilitycomment?: any;
    updatedby: string;
    deletedat?: any;
    keyretailers: string;
    keydistributors: string;
}

export interface ProductArticleReviewGet {
    productarticlereviewid: string;
    productId: string;
    productreviewername: string;
    articleurl: string;
    reviewmagazinelogoid: string;
    updatedby: string;
    deletedat?: any;
    reviewmagazinelogo: DocumentGet;
}

export interface ProductExistRatingGet {
    productexistratingid: string;
    productId: string;
    existproductrating: number;
    ratingproofvalidationurl: string;
    ratingproofvalidationlogo: DocumentGet;
    ratingproofvalidationlogoid: number;
    ratingproofvalidationname: string;
    updatedby: string;
    deletedat?: any;
}

export interface ProductImageGet {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    updatedby: string;
    deletedat?: any;
    image: DocumentGet;
}

export interface ProductSharePreference {
    productsharepreferenceid: string;
    productId: string;
    sharetypeid: string;
    updatedby: string;
    deletedat?: any;
}

export interface ProductUniversalCode {
    productuniversalcodeid: string;
    productId: string;
    productuniversalcodetype: string;
    code: string;
    updatedby: string;
    deletedat?: any;
}

export interface Samplepriceunitdetail {
    unitid: string;
    unit: string;
}

export interface Distributorunitdetail {
    discountUnitId: string;
    discountUnit: string;
}

export interface ProductPriceDetail {
    productpricedetailid: string;
    productId: string;
    businesscurrencyid: string;
    retailerprice: string;
    retailerpriceunitid: string;
    issamplefree: string;
    sampleprice: string;
    samplepriceunitid: string;
    distributormarginpercent: number;
    distributormarginpercentunitid: string;
    retailermarginpercent: number;
    retailermarginpercentunitid: string;
    samplethreshold: string;
    isunlimitsample: string;
    updatedby: string;
    deletedat?: any;
    retailerpriceunitdetail: Samplepriceunitdetail;
    samplepriceunitdetail: Samplepriceunitdetail;
    distributorunitdetail: Distributorunitdetail;
    retailerunitdetail: Distributorunitdetail;
}

export interface ProductPackageInfoGet {
    productpackageinfoid: string;
    productId: string;
    minorderquantity: string;
    orderunitid: string;
    packagesize: string;
    packageunit: string;
    noofboxinpallet: string;
    noofboxinpalletunitid: string;
    noofpackageinbox: string;
    noofpackageinboxunitid: string;
    approximateweightofpallet: string;
    approximateweightofpalletunitid: string;
    length: string;
    breadth: string;
    height: string;
    weight: string;
    updatedby: string;
    deletedat?: any;
    orderunitdetail: Samplepriceunitdetail;
    packageunitdetail: Samplepriceunitdetail;
    noofpackageinboxunitdetail: Samplepriceunitdetail;
    noofboxinpalletunitdetail: Samplepriceunitdetail;
    approximateweightofpalletunitdetail: Samplepriceunitdetail;
}

export interface ProductCompetingGet {
    productcompetingid: string;
    productId: string;
    competingproduct: string;
    competitor: string;
    competitorproducturl: string;
    updatedby: string;
    deletedat?: any;
}

export interface ProfileType {
    id: string;
    name: string;
}

export interface ChannelType {
    id: string;
    name: string;
}

export interface PTClas {
    profileTypeClassif: string;
    profileTypeId: string;
    channelTypeId: string;
    isDefault: string;
    profileType: ProfileType;
    channelType: ChannelType;
}

export interface Profile {
    customerProfileId: string;
    profileTypeId: string;
    profileTypeClassification: string;
    deletedAt?: any;
    pTClas: PTClas;
}

export interface ProductChannelCustomerProfile {
    productchannelcustomerprofileid: string;
    productId: string;
    channelId: string;
    customerProfileId: string;
    updatedby: string;
    deletedat?: any;
    profile: Profile;
}

export interface ProductKeyRetailerGet {
    productkeyretailerid: string;
    productId: string;
    retailername: string;
    countryid: string;
    documentid: string;
    updatedby: string;
    deletedat?: any;
    retailerImage: DocumentGet;
    country: CountryMaster;
}

export interface RegionCountryJCTGet {
    regionCountryJCTId: string;
    regionId: string;
    countryId: string;
    deletedAt?: any;
    country: CountryMaster;
}

export interface ProductLocationGet {
    productlocationid: string;
    productId: string;
    locationtype: string;
    regionCountryJCTId: string;
    updatedby: string;
    deletedat?: any;
    regionCountryJCT: RegionCountryJCTGet;
}

export interface Locations {
    SELLING: string[];
    TARGET: string[];
    RETAIL: any[];
}

export interface ImagesGet {
    PRODUCT: ProductImageGet[];
    DISPLAY: ProductImageGet[];
    PACKING: ProductImageGet[];
    BROUCHER: ProductImageGet[];
}

export interface ProductGet {
    productId: string;
    channelId: string;
    productGroupId: string;
    productCategorieId: string;
    product: string;
    brandId: string;
    productSKU: string;
    productkey: string;
    isshowtofreesub: string;
    isactive: string;
    hasanyvariant: string;
    variantdetails?: any;
    productqualitylevel: string;
    defaultimageid: string;
    updatedBy: string;
    deletedat?: any;
    productDetail: ProductDetail;
    productTag: Producttag[];
    productArticleReview: ProductArticleReviewGet[];
    productExistRating: ProductExistRatingGet[];
    productImage: ProductImageGet[];
    defaultImage: ProductImageGet;
    productSharePreference: ProductSharePreference[];
    productUniversalCode: ProductUniversalCode[];
    productPriceDetail: ProductPriceDetail;
    productPackageInfo: ProductPackageInfoGet;
    productCompeting: ProductCompetingGet[];
    productChannelCustomerProfile: ProductChannelCustomerProfile[];
    productKeyRetailer: ProductKeyRetailerGet[];
    productKeyDistributor: ProductKeyRetailerGet[];
    productLocation: ProductLocationGet[];
    DISTRIBUTOR: RelevantChannel[];
    RETAILER: RelevantChannel[];
    locations: Locations;
    images: ImagesGet;
    productAwards: ProductAwards[];
}

export class ProductAwards  {
    awardDetail: string;
    isLifeTime: string;
    issuedBy: string;
    productAwardId: string;
    validUpto: Date;
    document: DocumentGet;
    documentId: string;
}
