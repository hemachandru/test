export interface Code {
    code: string;
    id: number;
    type: string;
}

export interface Retailer {
    margin_price: number;
    margin_unit: string;
}

export interface Currency {
    code: string;
    id: string;
}

export interface Sample {
    unit: string;
    price: string;
}

export interface Distributor {
    margin_price: number;
    margin_unit: string;
}

export interface Retail {
    unit: string;
    price: string;
}

export interface Price {
    is_sample_free: boolean;
    is_unlimited_sample: boolean;
    retailer: Retailer;
    currency: Currency;
    sample_threshold: string;
    sample: Sample;
    distributor: Distributor;
    retail: Retail;
}

export interface Company {
    name: string;
    id: number;
}

export interface Brand {
    name: string;
    id: number;
}

export interface ProductFamily {
    name: string;
    id: number;
}

export interface Others {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Primary {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Images {
    others: Others[];
    primary: Primary[];
}

export interface Preference {
    name: string;
    id: number;
}

export interface Location {
    name: string;
    id: number;
}

export interface Target {
    locations: Location[];
}

export interface Location2 {
    name: string;
    id: number;
}

export interface Selling {
    locations: Location2[];
}

export interface ProductCategory {
    name: string;
    id: number;
}

export interface Product {
    avaialble_from?: any;
    codes: Code[];
    has_variant: boolean;
    created_at: Date;
    usp: string;
    updated_at: Date;
    price: Price;
    company: Company;
    id: number;
    is_avaialble_immediate: boolean;
    sku: string;
    brand: Brand;
    productdesc: string;
    product_family: ProductFamily[];
    images: Images;
    is_active: boolean;
    company_id: number;
    preference: Preference[];
    avaialbility_comment?: any;
    deleted_at?: any;
    quality: string;
    target: Target;
    urlkey: string;
    can_view_free_plan_members: boolean;
    name: string;
    selling: Selling;
    variantdetails?: any;
    product_category: ProductCategory[];
}

export interface Item {
    productid: string;
    quantity: string;
    unitprice: string;
    product: Product;
    countError: string;
    count: string;
}

export interface CartModel {
    cartid: string;
    sellerchannelid: string;
    currencyid: string;
    subtotal: string;
    taxcost: string;
    discount: string;
    grandtotal: string;
    items: Item[];
    policy: boolean;
    accept: boolean;
    cartError: boolean;
}
