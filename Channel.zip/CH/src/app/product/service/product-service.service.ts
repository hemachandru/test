// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs/BehaviorSubject';
// import { ApiUrl } from '@app/config/constant_keys';
// import { HttpRequestService} from '../../shared/shared-HTTP-service/HttpRequestService';
// import { IRequestOptions } from '../../shared/shared-HTTP-service/Interface/IRequestOptions';
// import { RequestOptions } from '../../shared/shared-HTTP-service/Interface/RequestOptions';
// import { Observable } from 'rxjs/Observable';


// @Injectable()
// export class ProductService {
//   private apiUrl = ApiUrl;
//   private option = new RequestOptions();
//   constructor(private _httpRequestService: HttpRequestService) {

//   }

//   productList(data) {
//     this.option.observe = 'response';
//     this.option.responseType = 'json';
//     const url: any = this.apiUrl.PRODUCT_LIST;
//     //  + 'search =' + '&page=' + '&limit=' + ;
//     return this._httpRequestService.postHttpClientRequest(url, data, this.option);
//   }

// }

import { Injectable } from '@angular/core';

import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { LocalStorage } from '@ngx-pwa/local-storage';

import { HttpParams } from '@angular/common/http';
import { ApiUrl } from '@app/config/constant_keys';
import { IRequestOptions } from '../../communication/services/Interface/IRequestOptions';
import { RelationStatus } from '@app/config/constant';

@Injectable()
export class ProductService {
  private _option = <IRequestOptions>{};
  private apiUrl = ApiUrl;

  constructor(private _httpReqService: HttpRequestService, protected asyncLocalStorage: LocalStorage) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  getService(url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequest(url, returnFullResponse);
  }

  getServiceHttpClient(url: any, respoType?: any) {
    if (respoType !== undefined) {
      this._option.responseType = respoType;
    }
    return this._httpReqService.getHttpClientRequest(url, this._option);
  }

  postService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.postHttpRequest(data, url, returnFullResponse);
  }

  postServiceHttpClient(data: any, url: any) {
    return this._httpReqService.postHttpClientRequest(data, url, this._option);
  }

  getByIDService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequestWithData(data, url, returnFullResponse);
  }

  putService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.putHttpRequest(data, url, returnFullResponse);
  }

  updateService(data: any, url: string, returnFullResponse: boolean) {
    return this._httpReqService.patchHttpRequest(data, url, returnFullResponse);
  }

  deleteService(url: any, returnFullResponse: boolean) {
    return this._httpReqService.deleteHttpRequest(url, returnFullResponse);
  }

  wishLists(datas, filters, filterDatas, filterToggle) {
    let params = new HttpParams();
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);

    const url: any = this.apiUrl.FAVOURITE_LIST + '?' + params;
    return this._httpReqService.postHttpRequest(filters, url, true).map(res => {
      const response = res as Response;
      if (response.ok ) {
        let lists = (<any>response)._body;
        lists = JSON.parse(lists);
        // load data to localstorage
        this.asyncLocalStorage.setItemSubscribe('product-' + RelationStatus.WISH_LIST, {
          query: datas,
          filter: Object.assign(filters, {
            toogle: filterToggle
          }),
          selected: filterDatas,
          response: lists.pagination,
          collectionIds: lists.results.map(item => (item.sku))
        });
      }

      return res;
    });
  }

  /**
   * Cart List Service
   */
  cartList() {
    const url: any = this.apiUrl.CART_LIST;
    return this._httpReqService.getHttpRequest(url, true);
  }
  // Add to cart
  addToCart(data) {
    const url: any = this.apiUrl.ADDTOCART;
    return this._httpReqService.postHttpRequest(data, url, true);
  }

  // Add to Favotite
  addToFavotite(data) {
    const url: any = this.apiUrl.ADDTOFAVORITE;
    return this._httpReqService.postHttpRequest(data, url, true);
  }

  // Add to Business
  addToBusiness(data) {
    const url: any = this.apiUrl.FAVOURITE_LIST;
    return this._httpReqService.putHttpRequest(data, url, true);
  }

  // gET CART COUNT
  getCartCount() {
    const url: any = this.apiUrl.GETCARTCOUNT;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  // gET CART COUNT
  getCheckoutAmountLimit() {
    const url: any = this.apiUrl.CHECKOUT_LIMIT_AMT + '/' + this.apiUrl.CHECKOUT_LIMIT_AMT_KEY;
    return this._httpReqService.getHttpClientRequest( url, true);
  }

  // gET FAVORITE COUNT
  getFavoriteCount() {
    const url: any = this.apiUrl.FAVORITECOUNT;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  getProductDissmissList() {
    const url: any = this.apiUrl.PRODUCTREJECTREASONLIST;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  productDismissReasons(data) {
    const url: any = this.apiUrl.PRODUCTREJECTREASON;
    return this._httpReqService.postHttpRequest(data, url, true);
  }

  cartUpdate(data) {
    const url: any = this.apiUrl.CART_UPDATE;
    return this._httpReqService.postHttpRequest(data, url, true);
  }

  cartItemdelete(data) {
    const url: any = this.apiUrl.CART_UPDATE + '/' + data;
    return this._httpReqService.deleteHttpRequest(url, true);
  }

  cartListdelete(data) {
    const url: any = this.apiUrl.CART_LIST + '/' + data;
    return this._httpReqService.deleteHttpRequest(url, true);
  }

  cartClear() {
    const url: any = this.apiUrl.CART_LIST;
    return this._httpReqService.deleteHttpRequest(url, true);
  }

  addAddress(addressData: any) {
    const url: any = this.apiUrl.ADDRESS_BOOK;
    return this._httpReqService.postHttpRequest(addressData, url, true)
      .map(res => {
        return res;
      });
  }

  updateAddress(addressData: any, addressId: string) {
    const url: any = this.apiUrl.ADDRESS_BOOK + '/' + addressId;
    return this._httpReqService.putHttpRequest(addressData, url, true)
      .map(res => {
        return res;
      });
  }

  // get address list
  getAddressList() {
    const url: any = this.apiUrl.ADDRESS_BOOK;
    return this._httpReqService.getHttpRequest(url, true);
  }

  // Delete address by id
  deleteAddressById(addressId) {
    const url: any = this.apiUrl.ADDRESS_BOOK + '/' + addressId;
    return this._httpReqService.deleteHttpRequest(url, true);
  }

  checkout(checkoutData: any) {
    const url: any = this.apiUrl.CHECKOUT;
    return this._httpReqService.postHttpRequest(checkoutData, url, true)
      .map(res => {
        return res;
      });
  }

  // get address list
  getProductActionInfo(productSKU) {
    const url: any = this.apiUrl.PRODUCTACTIONINFO + '/' + productSKU;
    return this._httpReqService.getHttpRequest(url, true);
  }

  // Delete Favotite
  deleteToFavotite(data) {
    let params = new HttpParams();
    params = params.set('id', data.id);
    params = params.set('type', data.type);
    const url: any = this.apiUrl.FAVOURITE_LIST + '?' + params;
    return this._httpReqService.deleteHttpRequest(url, data);
  }
}
