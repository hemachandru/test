import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { CheckoutInput } from '../models/shared-model';

@Injectable()
export class CartService {

  cartId: string;
  private cartSource = new BehaviorSubject<string>(this.cartId);
  public currentCartDetail = this.cartSource.asObservable();

  constructor() {
  }

  sendData(_cartId: string) {
    this.cartSource.next(_cartId);
  }
}


