import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { CartModel } from '../models/cart-model';

@Injectable()
export class CheckoutService {

  checkout: CartModel;
  public checkoutSource = new BehaviorSubject<CartModel>(this.checkout);

  currentCheckoutDetail = this.checkoutSource.asObservable();

  constructor() {
  }

  sendData(checkoutDetail: CartModel) {
    this.checkoutSource.next(checkoutDetail);
  }

  updateData(isClosed: boolean) {
    this.checkoutSource.closed = isClosed;
  }

}
