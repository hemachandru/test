import { Injectable } from '@angular/core';
import { ApiUrl } from '@app/config/constant_keys';
import { HttpParams, HttpClient } from '@angular/common/http';
import { ProductService } from '@app/product/service/product-service.service';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { RelationStatus } from '@app/config/constant';


@Injectable()
export class ProductBusiness {
    private apiUrl = ApiUrl;

    constructor(private productService: ProductService, protected asyncLocalStorage: LocalStorage) {
    }

    ProductList(datas, filters, filterDatas, filterToggle) {
        let params = new HttpParams();
        params = params.set('search', datas.searchKey);
        params = params.set('page', datas.pageNumber);
        params = params.set('limit', datas.limit);
        params = params.set('sort', datas.sort);

        const url: any = this.apiUrl.NEWPRODUCT_LIST + '?' + params;
        return this.productService.postService(filters, url, true)
            .map(res => {
                const response = res as Response;
                if (response.ok) {
                  let lists = (<any>response)._body;
                  lists = JSON.parse(lists);
                  // load data to localstorage
                  this.asyncLocalStorage.setItemSubscribe('product-' + RelationStatus.MY_PRODUCTS, {
                    query: datas,
                    filter: Object.assign(filters, {
                      toogle: filterToggle
                    }),
                    selected: filterDatas,
                    response: lists.pagination,
                    collectionIds: lists.results.map(item => (item.sku))
                  });
                }
                return res;
            });
    }

    GetProductDetail(sku) {
        const url: any = this.apiUrl.PRODUCT_DETAIL;
        return this.productService.getByIDService(sku, url, true)
            .map(res => {
                return res;
            });
    }

    GetProductInfo(sku) {
        const url: any = this.apiUrl.PRODUCT_INFO;
        return this.productService.getByIDService(sku, url, true)
            .map(res => {
                return res;
            });
    }

    ProductStatus(productsku, active, returnFullResponse: boolean) {
        const url: any = this.apiUrl.PRODUCT_STATUS + '/' + productsku;
        return this.productService.updateService(active, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    ProductDelete(productsku, returnFullResponse: boolean) {
        const url: any = this.apiUrl.PRODUCT_DETAIL + '/' + productsku;
        return this.productService.deleteService(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    GetProductList(sku) {
        const url: any = this.apiUrl.PRODUCT_LIST;
        return this.productService.postService(sku, url, true)
            .map(res => {
                return res;
            });
    }

    getChannelBrandList(id, data, returnFullResponse: boolean) {
        const url: any = this.apiUrl.CHANNELBRAND + '/' + id;
        return this.productService.postService(data, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getDistributorChannels() {
        const url: any = this.apiUrl.PARTNER_CHANNELS;
        const data = '';
        return this.productService.postService(data, url, true)
            .map(res => {
                return res;
            });
    }

    getProductBySKU(sku: string) {
        const url: any = this.apiUrl.PRODUCT;
        return this.productService.getByIDService(sku, url, true)
            .map(res => {
                return res;
            });
    }

    addProduct(productData: any, skuId?: string) {
        if (skuId && skuId.trim().length > 0) {
            const url: any = this.apiUrl.PRODUCT + '/' + skuId;
            return this.productService.updateService(productData, url, true)
                .map(res => {
                    return res;
                });
        } else {
            const url: any = this.apiUrl.PRODUCT;
            return this.productService.postService(productData, url, true)
                .map(res => {
                    return res;
                });
        }
    }

    isEmailRegisterd(data: any, returnFullResponse: boolean) {
        const url = this.apiUrl.CHECK_EMAIL;
        return this.productService.getByIDService(data, url, returnFullResponse).map(res => {
            return res;
        });
    }

    getChannelListBusiness(channelTypeId, data: any, returnFullResponse: boolean) {
        let params = new HttpParams();
        params = params.set('search', data);
        let url: any = this.apiUrl.DISTRIBUTOR_CHANNEL_SEARCH + '?' + params;
        if (channelTypeId) {
            params = params.set('channeltypeid', channelTypeId);
            url = this.apiUrl.RECOMMENDATION_CHANNEL_SEARCH + '?' + params;
        }
        return this.productService.getService(url, returnFullResponse).map(res => {
            return res;
        });
    }

    postRecommendationBusiness(roleFlag: boolean, data: any, returnFullResponse: boolean) {
        let url: any = this.apiUrl.DISTRIBUTOR_CHANNEL_POST;
        if (roleFlag) {
            url = this.apiUrl.RECOMMENDATION_CHANNEL_POST;
        }
        return this.productService.postService(data, url, true)
            .map(res => {
                return res;
            });
    }

    getTradeKeyRetailerSearch(data: any, returnFullResponse: boolean, typeId: string) {
        let params = new HttpParams();
        params = params.set('partner_type', typeId);
        const url: any = this.apiUrl.KEYRETAILERS_PRODUCT + '/' + data + '?' + params;
        return this.productService.getService(url, true)
            .map(res => {
                return res;
            });
    }

    getKeyRetailerSearch(search: string, typeId: string) {
        let params = new HttpParams();
        params = params.set('search', search);
        params = params.set('partner_type', typeId);
        const url: any = this.apiUrl.KEYRETAILER_SEARCH + '?' + params;
        return this.productService.getService(url, true).map(res => {
            return res;
        });
    }

    postKeyRetailer(data: any) {
        const url: any = this.apiUrl.KEYRETAILER_POST;
        return this.productService.postService(data, url, true)
            .map(res => {
                return res;
            });
    }
}
