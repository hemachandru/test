import { AuthModule } from './auth/auth.module';
import { CoreModule } from './core/core.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ServiceWorkerModule } from '@angular/service-worker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxCarouselModule } from 'ngx-carousel';
import { AppComponent } from './core/containers/app/app.component';
import { environment } from '../environments/environment';
import { HomeModule } from './home/home.module';
import { UserSubscriptionModule } from './user-subscription/user-subscription.module';
import { LoadingModule, ANIMATION_TYPES } from 'ngx-loading';
import { AccountModule } from '@app/account/account.module';
import { ProfileModule } from '@app/profile/profile.module';
import { UserIdleModule } from 'angular-user-idle';
import { Session, CookieConfig, AWSUrl } from './config/constant';
import { ProductModule } from '@app/product/product.module';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { httpInterceptorProviders } from '../app/core/interceptors/index';

// RX imports
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/exhaustMap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/retry';
import { ErrorPageComponent } from '@app/core/components/errorpage/errorpage.component';
import { ChannelModule } from '@app/channel/channel.module';
import { CommunicationModule } from '@app/communication/communication.module';
import { OrderModule } from '@app/order/order.module';
import { GeneralModule } from '@app/general/general.module';
import { ToastrModule } from 'ngx-toastr';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { NgcCookieConsentModule, NgcCookieConsentConfig } from 'ngx-cookieconsent';
import { BreadcrumbModule } from '@app/breadcrumb/breadcrumb.module';
import { BreadcrumbService } from '@app/breadcrumb/breadcrumb/breadcrumb.service';
// app routing module should always be in last
import { AppRoutingModule } from './app-routing.module';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { LocalStorageModule } from '@ngx-pwa/local-storage';
import { localStorageProviders } from '@ngx-pwa/local-storage';

@NgModule({
  declarations: [AppComponent, ErrorPageComponent],
  imports: [
    LocalStorageModule,
    BreadcrumbModule,
    ToastrModule.forRoot({
      closeButton: true,
      timeOut: 10000,
      preventDuplicates: true
    }),
    HttpClientModule,
    BrowserModule,
    ServiceWorkerModule.register('/ngsw-worker.js', {
      enabled: environment.production
    }),
    BrowserAnimationsModule,
    CoreModule.forRoot(),
    AuthModule.forRoot(),
    HomeModule,
    UserSubscriptionModule,
    LoadingModule.forRoot({
      animationType: ANIMATION_TYPES.rectangleBounce,
      primaryColour: '#004877',
      secondaryColour: '#004877',
      tertiaryColour: '#004877',
      backdropBackgroundColour: 'rgba(74,73,73,0.1)',
      fullScreenBackdrop: true
    }),
    AccountModule,
    ProfileModule,
    ProductModule,
    ChannelModule,
    UserIdleModule.forRoot({ idle: Session.IDLE, timeout: Session.TIMEOUT, ping: Session.PING }),
    CommunicationModule,
    OrderModule,
    GeneralModule,
    AppRoutingModule,
    NgxCarouselModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    NgcCookieConsentModule.forRoot(CookieConfig)
  ],
  providers: [httpInterceptorProviders, BreadcrumbService, LocalStorageService, localStorageProviders({ prefix: 'CH-' })],
  bootstrap: [AppComponent],
  exports: [ToastrModule]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
  // const reqDate = new Date();
  // const s3Url = environment.AWS_MULTILING_URL;
  // return new TranslateHttpLoader(http, environment.AWS_DOWNLOAD_URL + AWSUrl.MULTILANGUAGE, '.json');
}
