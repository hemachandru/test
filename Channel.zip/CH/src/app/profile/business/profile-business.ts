import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';

import { ApiUrl } from '@app/config/constant_keys';
import { ProfileService } from '../services/profile.service';

@Injectable()
export class ProfileBusiness {
    private apiUrl = ApiUrl;
    constructor(private profileService: ProfileService) {
    }

    UserManagementList(datas, filters) {
        let params = new HttpParams();
        params = params.set('search', datas.searchKey);
        params = params.set('page', datas.pageNumber);
        params = params.set('limit', datas.limit);
        params = params.set('sort', datas.sort);

        const url: any = this.apiUrl.USER_LIST + '?' + params;
        return this.profileService.usermanagementListService(url, filters)
            .map(res => {
                return res;
            });
    }

    getWorkNatureList(returnFullResponse: boolean) {
        const url: any = this.apiUrl.WORKNATURE_LIST;
        return this.profileService.workNatureListService(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    isEmailRegisterd(data: any) {
        const url = this.apiUrl.CHECK_EMAIL;
        return this.profileService.getHttpRequestWithDataMethod(data, url).map(res => {
        return res;
        });
    }

    getRoleList(returnFullResponse: boolean) {
        const url: any = this.apiUrl.ROLE_LIST;
        return this.profileService.roleListService(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getReportList(returnFullResponse: boolean) {
        const url: any = this.apiUrl.REPORT_LIST;
        return this.profileService.reportListService(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getUserFields(id, returnFullResponse: boolean) {
        const url: any = this.apiUrl.PROFILE;
        return this.profileService.roleListServiceId(id, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    userPasswordReset(userPasswordReset: any, returnFullResponse: boolean) {
        const url: any = this.apiUrl.USER_PASSWORD_RESET;
        return this.profileService.userPasswordReset(userPasswordReset, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getChannelInfo() {
        const url: any = this.apiUrl.CHANNEL_INFO;
        return this.profileService.channelInfoService(url)
            .map(res => {
                return res;
            });
    }

    getMyProfileDetails(returnFullResponse: boolean) {
        const url: any = this.apiUrl.MY_PROFILE;
        return this.profileService.getHttpRequestWithboolean(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getAccesspremission(filter, returnFullResponse: boolean) {
        let params = new HttpParams();
        params = params.set('page', filter.page);
        params = params.set('limit', filter.limit);

        const url: any = this.apiUrl.ACCESSPERMISSION + '?' + params;

        return this.profileService.getHttpRequestWithboolean(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getAccesspremissions(returnFullResponse: boolean) {
        const url: any = this.apiUrl.PERFERENCETREE;

        return this.profileService.getHttpRequestWithboolean(url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getFromElementBusiness(responseType: boolean) {
        const url: any = this.apiUrl.SETTING_MASTER;
        return this.profileService.getFromElementBusinessService(url, responseType)
            .map(res => {
                return res;
            });
    }

    putProfileSetting(postObject: any, responseType: boolean) {
        const url: any = this.apiUrl.PROFILE_SETTING_POST;
        return this.profileService.putProfileSetting(postObject, url, responseType)
            .map(res => {
                return res;
            });
    }

    getProfileSetting(responseType: boolean) {
        const url: any = this.apiUrl.PROFILE_SETTING_GET;
        return this.profileService.getProfileSetting(url, responseType)
            .map(res => {
                return res;
            });
    }

    addUserManagement(data: any, returnFullResponse: boolean) {
        const url: any = this.apiUrl.ADD_USER;
        return this.profileService.putAddUserService(data, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    getUserManagementdetails(responseType: boolean, id: number) {
        const url: any = this.apiUrl.PROFILE + '/' + id;
        return this.profileService.getMyProfileDetails(url, responseType)
            .map(res => {
                return res;
            });
    }

    updateUserManagement(data: any, returnFullResponse: boolean, id: number) {
        const url: any = this.apiUrl.PROFILE + '/' + id;
        return this.profileService.updateMyProfile(data, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    updateMyProfile(data: any, returnFullResponse: boolean) {
        const url: any = this.apiUrl.UPDATE_MY_PROFILE;
        return this.profileService.updateMyProfile(data, url, returnFullResponse)
            .map(res => {
                return res;
            });
    }

    updateChannel(param, data: any, responseBool: boolean) {
        const url: any = this.apiUrl.DEFAULT_CONTACT_CHANNEL + '/' + param;
        return this.profileService.updateAddUserService(data,  url, responseBool).map(res => {
          return res;
        });
      }
}
