import { Component, OnInit, Input, Output, EventEmitter, ViewChildren, AfterViewInit, QueryList } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
// import { CheckProperty } from '../../../shared/models/shared-model';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { Pipe, PipeTransform } from '@angular/core';
import { Config, ChannelType, LocationType, SocialMedia, ProductCategoryTypeEnum } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ScrollToService } from 'ng2-scroll-to-el';
import { ToastrService } from 'ngx-toastr';
import {
  MyProfile, WorkNature,
  ChannelContactSuggestion, UserPasswordReset, CountrySearchItem, TradeRegions, SocialSite,
  ContactUpdateRequest,
  ProductCategoryUpdateRequest,
  Location, MyProfileUpdateRequest, RegionUpdateRequest, UserRole
} from '../../models/my-profile';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { ProfileBusiness } from '../../business/profile-business';
import { Response } from '@angular/http';
import { TitleCasePipe } from '@angular/common';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ChannelInfos, SearchItem, Region, ProductCategorySearchItem, Role } from '../../../shared/models/shared-model';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import {
  ProfileProductCategoryComponent
} from '../../../shared/shared-component/profile-product-category/profile-product-category.component';
import { AccountBusiness } from '../../../account/business/account.bussiness';
import { CommonHelper } from '@app/shared/common-helper';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { APIError, APIError2, Id_Model, ShareType } from '../../../shared/models/shared-model';
import { integer } from 'aws-sdk/clients/cloudfront';
import {
  MultipleSelectWithFilterComponent
} from '../../../shared/shared-component/multiple-select-with-filter/multiple-select-with-filter.component';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { AccessPermissionEnum, UserAccountStatus, RoleIdEnum, ChannelTypeIdEnum } from '@app/config/constant';
import { TranslateService } from '@ngx-translate/core';
import { throwMatDialogContentAlreadyAttachedError } from '@angular/material';
import { CountryMaster } from '@app/account/models/profile';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss']
})
export class MyProfileComponent implements OnInit, AfterViewInit {
  // public regInfo: boolean = true;
  // public countryData: any;
  // public locationScale: boolean = false;
  // comInfo: boolean = false;

  showManagePwd: boolean;
  showAccreferences: boolean;
  userType: string;
  public opts: ISlimScrollOptions;
  selectSharedTooltipMessage: string;
  // Form groups
  profileFormGroup: FormGroup;
  registrationGroup: FormGroup;
  managePasswordGroup: FormGroup;
  // Form controls
  firstNameCtrl: FormControl;
  lastNameCtrl: FormControl;
  employeeIdCtrl: FormControl;
  emailCtrl: FormControl;
  phoneCtrl: FormControl;
  phoneCtrlCode: FormControl;
  mobileNoCtrl: FormControl;
  mobileNoCtrlCode: FormControl;
  jobTitleCtrl: FormControl;
  reportingToCtrl: FormControl;
  linkedInCtrl: FormControl;
  googlePlusUrlCtrl: FormControl;
  // Manage Password Form controls
  currentPwdCtrl: FormControl;
  newPwdCtrl: FormControl;
  confirmPwdCtrl: FormControl;
  errImageUploadCtrl: FormControl;

  selectedRegion: string;

  // profileFormGroup: FormGroup;
  selectedCountryID: integer = 0;
  shareTypes: Array<ShareType>;
  workNatureList: Array<WorkNature>;
  isShared?: number;
  public iserror: boolean;
  public error_message = '';
  private channelInfos: ChannelInfos;
  public errImageUpload = 'fileprofileImg';
  msg_code_image = '';
  urlImage = '';
  location = '';

  public tradeTargetRegions: Array<Region>;
  public tradeSellingRegions: Array<Region>;
  public tradeRetailerRegions: Array<Region>;

  public selectedTargetRegionId: string;
  public selectedSellingRegionId: string;
  public tradeCountries: Array<CountrySearchItem>;
  public tradeTargetSelectedCountries: Array<CountrySearchItem>;
  public searchTargetTradeCountries: Array<CountrySearchItem>;
  public tradeTargetSelectedCountriesByRegion: Array<CountrySearchItem>;

  public tradeSellingSelectedCountries: Array<CountrySearchItem>;
  public searchSellingTradeCountries: Array<CountrySearchItem>;
  public tradeSellingSelectedCountriesByRegion: Array<CountrySearchItem>;

  public tradeRetailerSelectedCountries: Array<CountrySearchItem>;
  public searchRetailerTradeCountries: Array<CountrySearchItem>;

  public productFamiles: Array<SearchItem>;
  public selectedProductfamilies: Array<SearchItem>;
  public productFamilySearchList: Array<SearchItem>;

  public myProfile: MyProfile;

  public channelProductCategoryList: Array<ProductCategorySearchItem>;
  public channelProductCategorySelectedList: Array<ProductCategorySearchItem>;

  public interestedSelectedProductfamilies: Array<SearchItem>;
  public interestedProductFamilySearchList: Array<SearchItem>;

  public interestedProductCategorySelectedList: Array<ProductCategorySearchItem>;
  public interestedProductCategorySearchList: Array<Array<ProductCategorySearchItem>>;

  private productCategoryComponents: Array<ProfileProductCategoryComponent>;
  private interestedProductCategoryComponents: Array<ProfileProductCategoryComponent>;

  private isTargetCountriesDirty;
  private isSellingCountriesDirty;
  private isProductFamiliesDirty;
  private isInterestedProductFamiliesDirty;
  public errWorknature: string;
  public msg_code_worknature: string;
  public errShareType: string;
  public msg_code_ShareType: string;
  public errSellingCounries: string;
  public msg_code_SellingCounries: string;
  public errTargetCounries: string;
  public msg_code_TargetCounries: string;
  public errProductFamilies: string;
  public msg_code_ProductFamilies: string;
  public errProductCategories: string;
  public msg_code_ProductCategories: string;
  public errInteresedProductFamilies: string;
  public msg_code_InteresedProductFamilies: string;
  public errInteresedProductCategories: string;
  public msg_code_InteresedProductCategories: string;
  public errRetilerCounries: string;
  public msg_code_RetilerCounries: string;
  public countryCtrl: string;
  public msg_code_country: string;
  public preLoader = false;
  public _channelTypeEnum = ChannelTypeIdEnum;
  channelType: string;

  linkedInErrControl: string;
  msg_code_linkedIn: string;

  googlePlusErrControl: string;
  msg_code_googlePlus: string;

  public emptyArrayLength: number;

  locationType = LocationType;
  private multipleSelectWithFilterComponents: Array<MultipleSelectWithFilterComponent>;

  public scrollToElementId: string;

  public hasViewAccess: boolean;

  public hasUpdateAccess: boolean;

  public scrollbarOptions = { axis: 'y', theme: 'dark' };
  public scrollbarOptionsIntrested = { axis: 'y', theme: 'dark' };

  public isAccountUser: boolean;
  public showTradeLocation: boolean;
  public showProductFamily: boolean;
  public showProductCategory: boolean;
  public showInterestedProductFamily: boolean;
  public showInterestedProductCategory: boolean;
  private appRole: Role;
  private sellingProfile: Array<number>;
  private sourcingProfile: Array<number>;
  countryMasterList: Array<CountryMaster>;

  @ViewChildren(ProfileProductCategoryComponent) productCategoryViewChildren: QueryList<ProfileProductCategoryComponent>;
  @ViewChildren(MultipleSelectWithFilterComponent) locationChildren: QueryList<MultipleSelectWithFilterComponent>;
  channelTypeId: number;
  constructor(private config: Config, private fb: FormBuilder, private s3UploadFileService: S3UploadFileService,
    private scrollService: ScrollToService, private profileBusiness: ProfileBusiness, private dataBinding: AccountDataService,
    private sharedBusiness: SharedBusiness, private accountBusiness: AccountBusiness,
    private toastr: ToastrService, private authorizeService: AuthorizeService, private translate: TranslateService) {
    this.emptyArrayLength = 0;
    this.selectSharedTooltipMessage = this.translate.instant('myprofile.bodyLabels.tooltipprofile');
    this.tradeCountries = new Array<CountrySearchItem>();
    this.tradeTargetRegions = new Array<Region>();
    this.tradeSellingRegions = new Array<Region>();
    this.tradeRetailerRegions = new Array<Region>();
    // this.tradeTargetSelectedCountries = new Array<CountrySearchItem>();
    // this.searchTargetTradeCountries = new Array<CountrySearchItem>();

    this.productFamiles = new Array<SearchItem>();
    this.selectedProductfamilies = new Array<SearchItem>();
    this.productFamilySearchList = new Array<SearchItem>();

    // this.tradeSellingSelectedCountries = Array<CountrySearchItem>();
    // this.searchSellingTradeCountries = Array<CountrySearchItem>();
    this.tradeSellingSelectedCountriesByRegion = Array<CountrySearchItem>();
    this.channelProductCategoryList = new Array<ProductCategorySearchItem>();
    this.channelProductCategorySelectedList = new Array<ProductCategorySearchItem>();

    this.interestedSelectedProductfamilies = new Array<SearchItem>();
    this.interestedProductFamilySearchList = new Array<SearchItem>();

    this.interestedProductCategorySelectedList = new Array<ProductCategorySearchItem>();
    this.interestedProductCategorySearchList = new Array<Array<ProductCategorySearchItem>>();

    this.tradeRetailerSelectedCountries = Array<CountrySearchItem>();
    this.searchRetailerTradeCountries = Array<CountrySearchItem>();

    this.isTargetCountriesDirty = false;
    this.isSellingCountriesDirty = false;
    this.isProductFamiliesDirty = false;
    this.isInterestedProductFamiliesDirty = false;

    this.errWorknature = '';
    this.msg_code_worknature = '';
    this.errShareType = '';
    this.msg_code_ShareType = '';
    this.errSellingCounries = '';
    this.msg_code_SellingCounries = '';
    this.errTargetCounries = '';
    this.msg_code_TargetCounries = '';
    this.errProductFamilies = '';
    this.msg_code_ProductFamilies = '';
    this.errProductCategories = '';
    this.msg_code_ProductCategories = '';
    this.errInteresedProductFamilies = '';
    this.msg_code_InteresedProductFamilies = '';
    this.errInteresedProductCategories = '';
    this.msg_code_InteresedProductCategories = '';
    this.errRetilerCounries = '';
    this.msg_code_RetilerCounries = '';
    this.countryCtrl = '';
    this.msg_code_country = '';
    this.preLoader = false;
    this.channelType = '';
    this.linkedInErrControl = '';
    this.msg_code_linkedIn = '';
    this.googlePlusErrControl = '';
    this.msg_code_googlePlus = '';
    this.iserror = true;
    this.showManagePwd = true;
    this.showAccreferences = true;
    this.scrollToElementId = '';
  }

  ngOnInit() {
    if (localStorage.getItem(AppLocalStorageKeys.ROLE)) {
      this.appRole = JSON.parse(localStorage.getItem(AppLocalStorageKeys.ROLE)) as Role;
    }

    if (localStorage.getItem(AppLocalStorageKeys.SELLING_PROFILE)) {
      this.sellingProfile = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SELLING_PROFILE)) as Array<number>;
    }

    if (localStorage.getItem(AppLocalStorageKeys.SOURCING_PROFILE)) {
      this.sourcingProfile = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SOURCING_PROFILE)) as Array<number>;
    }

    this.isAccountUser = false;
    this.preLoader = true;
    this.opts = {
      // position: 'right',
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0',
      barOpacity: '1',
      gridOpacity: '1'
    };

    this.selectedTargetRegionId = null;
    this.selectedSellingRegionId = null;
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelTypeId = parseInt(data1, 10);
    if (this.channelTypeId === ChannelTypeIdEnum.DISTRIBUTOR) {
      this.channelType = ChannelType.DISTRIBUTOR.toLowerCase();
    } else if (this.channelTypeId === ChannelTypeIdEnum.RETAILER) {
      this.channelType = ChannelType.RETAILER.toLowerCase();
    } else {
      this.channelType = ChannelType.VENDOR.toLowerCase();
    }

    // this.channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
    // this.channelType = ValidationService.isNullOrEmpty(this.channelType) ? '' : this.channelType.toString().toLowerCase();
    this.showHideWorkNature();
    this.showHideFamilyCategoryLocations();
    this.initForm();
    this.getChannelInfos();
    this.getCountryList();
  }

  stopPreloaderOnPageLoad() {
    if (
      ValidationService.isNullOrEmpty(this.myProfile) === true ||
      ValidationService.isNullOrEmpty(this.channelInfos) === true ||
      ValidationService.isNullOrEmpty(this.shareTypes) === true ||
      (!this.isAccountUser && ValidationService.isNullOrEmpty(this.workNatureList))
    ) {
      this.preLoader = true;
    } else {
      this.preLoader = false;
    }

  }

  ngAfterViewInit() {
    // console.log(`ngAfterViewInit -  is ${this.productCategoryViewChildren}`);
    // const _productCategories: ProfileProductCategoryComponent[] = this.productCategoryViewChildren.toArray();
  }

  stopPreLoaderOnLoad() {

  }

  accountProfileUpload(event, Dimension, codeDime) {
    this.location = '';
    const file = event.target.files.item(0);
    if (file) {
      let fileExtension = file.name.substr((file.name.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString();
      if (CommonHelper.checkValidImage(fileExtension)) {
        if (CommonHelper.checkValidImageSize(file.size)) {
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          reader.onload = (readerEvent: any) => {
            img.src = readerEvent.target.result;
            img.onload = async function () {
              if (img) {
                self.msg_code_image = '';
                const folderName = 'account-s3/';
                const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
                if (resImagePath) {
                  let imageKey = '';
                  if (resImagePath.key) {
                    imageKey = resImagePath.key;
                  } else {
                    imageKey = resImagePath.Key;
                  }
                  self.location = imageKey;
                  self.urlImage = readerEvent.target.result;
                } else {
                  // bucket issue //img.width === Dimension && img.height === Dimension
                  self.msg_code_image = '009';
                  self.urlImage = '';
                }
              } else {
                self.msg_code_image = '0001';
              }
            };
          };
          reader.readAsDataURL(event.target.files[0]);
        } else {
          // for valid image size
          this.msg_code_image = '002';
        }
      } else {
        this.msg_code_image = '0052';
      }
    }
  }

  getWorkNatureList(workNatureId: string): void {
    this.profileBusiness.getWorkNatureList(true).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.workNatureList = <Array<WorkNature>>(response.json());
        this.workNatureList.forEach(workNature => {
          if (workNature.workNatureId === workNatureId) {
            workNature.isChecked = true;
          } else {
            workNature.isChecked = false;
          }
        });

        this.showHideFamilyCategoryLocations(workNatureId);
      }
      this.stopPreloaderOnPageLoad();
    },
      (error) => {
        console.log(error);
      });
  }

  getShareTypeList(channelContactSuggestion: Array<ChannelContactSuggestion>): void {
    this.sharedBusiness.getShareTypeList(true).subscribe(result => {

      const response = result as Response;
      if (response.ok) {

        const _shareTypes = <Array<ShareType>>(response.json());
        this.shareTypes = _shareTypes.filter(res => res.sharetype !== ChannelType.SALESREP);
        if (this.channelType === ChannelType.VENDOR.toLowerCase()) {
          this.shareTypes = this.shareTypes.filter(item => item.sharetype !== ChannelType.VENDOR);
        } else if (this.channelType === ChannelType.RETAILER.toLowerCase()) {
          this.shareTypes = this.shareTypes.filter(item => item.sharetype !== ChannelType.RETAILER);
        }

        this.shareTypes.forEach(shareTypeItem => {
          channelContactSuggestion.forEach(item => {
            if (shareTypeItem.sharetype.toUpperCase() === item.sharetype.sharetype.toUpperCase()) {
              shareTypeItem.isChecked = true;
            }
          });
        });
      }
      this.stopPreloaderOnPageLoad();
    },
      (error) => {
        console.log(error);
      });
  }



  onUserPasswordReset(): void {
    const userPasswordReset: UserPasswordReset = {
      'password': this.newPwdCtrl.value,
      'currentPassword': this.currentPwdCtrl.value
    };
    this.preLoader = true;
    this.profileBusiness.userPasswordReset(userPasswordReset, true).subscribe(result => {
      const response = result as Response;
      this.managePasswordGroup.reset();
      this.preLoader = false;
      if (response.ok) {
        if (response.json().success === true) {
          this.iserror = false;
          this.error_message = this.translate.instant('Password.bodyLabels.passwordUpdated');
        } else {
          this.iserror = true;
          this.error_message = this.translate.instant('Password.bodyLabels.invalidOldPassword');
        }
      } else {
        this.iserror = true;
        this.error_message = this.translate.instant('Password.bodyLabels.passwordResetFailed');
      }

    },
      (error) => {
        this.preLoader = false;
        console.log(error);
      });
  }

  initForm() {
    this.initializeRegistrationGroup();
    this.initializeManagePasswordGroup();
    this.profileFormGroup = this.fb.group({
      registrationGroup: this.registrationGroup,
      managePasswordGroup: this.managePasswordGroup,
    });
  }

  getCountryID(countryId: number) {
    this.selectedCountryID = countryId.toString() === 'null' ? 0 : countryId;
    if (this.selectedCountryID === 0) {
      this.countryCtrl = 'country';
      this.msg_code_country = '0002';
    } else {
      this.countryCtrl = '';
      this.msg_code_country = '';
      this.setRegistrationIsVAT(countryId);
    }
  }

  initializeRegistrationGroup() {
    this.employeeIdCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.firstNameCtrl = new FormControl('', Validators.compose(
      [Validators.required, Validators.minLength(2), Validators.maxLength(30)]
    ));

    this.lastNameCtrl = new FormControl('', Validators.compose(
      [Validators.required, Validators.minLength(1), Validators.maxLength(30)]));
    this.emailCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.config.emailPattern)]));

    // this.phoneCtrl = new FormControl('',
    //   Validators.compose([Validators.required,
    //   Validators.minLength(8),
    //   Validators.maxLength(15),
    //   Validators.pattern(this.config.mobnumPattern)]));

    this.phoneCtrl = new FormControl('',
      Validators.compose([Validators.pattern(this.config.phoneCodeWithOutPlus), Validators.minLength(4),
      Validators.maxLength(20),
        // Validators.pattern(this.config.mobnumPattern)
      ]));

    this.phoneCtrlCode = new FormControl('', Validators.compose([Validators.pattern
      (this.config.phoneCodeWithPlus), Validators.minLength(1), Validators.maxLength(6)]));

    this.mobileNoCtrl = new FormControl('',
      Validators.compose([Validators.required, Validators.pattern(this.config.phoneCodeWithOutPlus),
      Validators.minLength(4), Validators.maxLength(20)
        // Validators.pattern(this.config.mobnumPattern)
      ]));

    this.mobileNoCtrlCode = new FormControl('', Validators.compose([Validators.pattern
      (this.config.phoneCodeWithPlus), Validators.minLength(1), Validators.maxLength(6)]));

    // tslint:disable-next-line:max-line-length
    this.jobTitleCtrl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(50)])); // VJ maxLength 250 --> 50  01/03/2019
    this.reportingToCtrl = new FormControl('');
    this.linkedInCtrl = new FormControl('', Validators.compose([
      // Validators.required,
      // Validators.pattern(this.config.urlPatternWithHttp)
    ]));
    this.googlePlusUrlCtrl = new FormControl('', Validators.compose([
      // Validators.pattern(this.config.urlPatternWithHttp)
    ]));

    this.registrationGroup = new FormGroup({
      employeeId: this.employeeIdCtrl,
      firstName: this.firstNameCtrl,
      lastName: this.lastNameCtrl,
      email: this.emailCtrl,
      phone: this.phoneCtrl,
      phoneCode: this.phoneCtrlCode,
      mobileNo: this.mobileNoCtrl,
      mobileNoCode: this.mobileNoCtrlCode,
      jobTitle: this.jobTitleCtrl,
      reportingTo: this.reportingToCtrl,
      linkedIn: this.linkedInCtrl,
      googlePlusUrl: this.googlePlusUrlCtrl,
    });
  }

  initializeManagePasswordGroup() {
    this.currentPwdCtrl = new FormControl('', Validators.compose([Validators.required, Validators.minLength(8), Validators.maxLength(25)]));
    this.newPwdCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.minLength(8), Validators.maxLength(25), Validators.pattern(this.config.passwordAlphaNumericPattern)]));
    this.confirmPwdCtrl = new FormControl('', Validators.compose([Validators.required]));

    this.managePasswordGroup = new FormGroup({
      currentPassword: this.currentPwdCtrl,
      newPassword: this.newPwdCtrl,
      confirmPassword: this.confirmPwdCtrl,
    });
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      // const isOldChannel = localStorage.getItem(AppLocalStorageKeys.OLD_CHANNEL);
      this.setFormValues();
    });

  }

  setFormValues() {
    this.profileBusiness.getMyProfileDetails(true).subscribe(profileDetail => {
      const response = profileDetail as Response;
      if (response.ok) {
        this.myProfile = response.json() as MyProfile;
        // console.log('myProfile', JSON.stringify(this.myProfile));
        this.userType = CommonHelper.InsertSpaceAfterCapitalLetter(this.myProfile.role.role.role);
        this.selectedCountryID = parseInt(this.myProfile.contact.countryId, 10);
        this.employeeIdCtrl.setValue(this.myProfile.contact.empId);
        this.firstNameCtrl.setValue(this.myProfile.contact.firstName);
        this.lastNameCtrl.setValue(this.myProfile.contact.lastName);
        this.emailCtrl.setValue(this.myProfile.email);
        // if (this.myProfile.contact.phone1) {
        //   this.phoneCtrl.setValue(this.myProfile.contact.phone1);
        // }
        const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
          === this.selectedCountryID);
        let countryCode = '';
        if (countryData[0] && countryData[0].phoneCode) {
          countryCode = countryData[0].phoneCode;
        }

        let contactMob;
        if (this.myProfile.contact.phone1) {
          contactMob = this.myProfile.contact.phone1.replace(/\s/g, '').split('-');
          this.phoneCtrlCode.setValue(!ValidationService.isNullOrEmpty(contactMob[1]) ? contactMob[0] : countryCode);
          this.phoneCtrl.setValue
            (!ValidationService.isNullOrEmpty(contactMob[1]) ? contactMob[1] : this.myProfile.contact.phone1);
        } else {
          this.phoneCtrlCode.setValue(countryCode);
        }
        // this.mobileNoCtrl.setValue(this.myProfile.contact.mobileNo);
        let mobileNo;
        if (this.myProfile.contact.mobileNo) {
          mobileNo = this.myProfile.contact.mobileNo.replace(/\s/g, '').split('-');
          this.mobileNoCtrlCode.setValue(!ValidationService.isNullOrEmpty(mobileNo[1]) ? mobileNo[0] : countryCode);
          this.mobileNoCtrl.setValue
            (!ValidationService.isNullOrEmpty(mobileNo[1]) ? mobileNo[1] : this.myProfile.contact.mobileNo);
        } else {
          this.mobileNoCtrlCode.setValue(countryCode);
        }
        this.jobTitleCtrl.setValue(this.myProfile.contact.jobTitle);
        if (!ValidationService.isNullOrEmpty(this.myProfile.contact.reportPerson) &&
          !ValidationService.isNullOrEmpty(this.myProfile.contact.reportPerson.firstName)) {
          this.reportingToCtrl.setValue(this.myProfile.contact.reportPerson.firstName);
        } else {
          this.reportingToCtrl.setValue('None');
        }

        if (!ValidationService.isNullOrEmpty(this.myProfile.contact.document) &&
          !ValidationService.isNullOrEmpty(this.myProfile.contact.document.documentUrl)) {
          this.urlImage = this.myProfile.contact.document.documentUrl;
        }

        this.myProfile.contact.contactSocialLink.forEach(socialLinkItem => {
          if (socialLinkItem.socialSite.socialSite.toUpperCase() === SocialMedia.GOOGLE_PLUS.toUpperCase()) {
            this.googlePlusUrlCtrl.setValue(socialLinkItem.contactSocialLink);
          } else if (socialLinkItem.socialSite.socialSite.toUpperCase() === SocialMedia.LINKED_IN.toUpperCase()) {
            this.linkedInCtrl.setValue(socialLinkItem.contactSocialLink);
          }
        });

        this.tradeSellingSelectedCountries = new Array<CountrySearchItem>();
        this.tradeTargetSelectedCountries = new Array<CountrySearchItem>();
        this.tradeRetailerSelectedCountries = new Array<CountrySearchItem>();
        if (this.myProfile.contact.contactLocation.length > 0) {
          for (let i = 0; i < this.myProfile.contact.contactLocation.length; i++) {
            const cl = this.myProfile.contact.contactLocation[i];
            const country = new CountrySearchItem();
            country.id = parseInt(cl.RegionCountryJCT.country.countryId, 10);
            country.name = cl.RegionCountryJCT.country.country;
            country.regionCountryJCTId = cl.RegionCountryJCT.regionCountryJCTId;
            country.regionId = cl.RegionCountryJCT.region.regionId;
            if (cl.locationType.toUpperCase() === LocationType.TARGET) {
              this.addSelectedCountries(country, LocationType.TARGET);
              this.addRegionDropdown(cl.RegionCountryJCT.region, LocationType.TARGET);
            } else if (cl.locationType.toUpperCase() === LocationType.SELLING) {
              this.addSelectedCountries(country, LocationType.SELLING);
              this.addRegionDropdown(cl.RegionCountryJCT.region, LocationType.SELLING);
            } else {
              this.addSelectedCountries(country, LocationType.RETAILER);
              this.addRegionDropdown(cl.RegionCountryJCT.region, LocationType.RETAILER);
            }
          }

          // this.filterSellingCountrySearch();
          // this.filterTargetCountrySearch();
          // this.filterRetailCountrySearch();
        } else {
          Object.assign(this.tradeSellingSelectedCountries, this.searchSellingTradeCountries);
          Object.assign(this.tradeTargetSelectedCountries, this.searchTargetTradeCountries);
          Object.assign(this.tradeRetailerSelectedCountries, this.searchRetailerTradeCountries);
        }

        // this.filterSearchCountryListBySelectedCountries(LocationType.SELLING_AND_TARGET);

        this.myProfile.contact.productGroup.forEach(item => {
          const productGroupItem = new SearchItem();
          productGroupItem.id = parseInt(item.productGroupId, 10);
          productGroupItem.name = item.productGroup.productGroup;
          this.selectedProductfamilies.push(productGroupItem);
        });

        this.filterProductFamilySearchListBySelectedProductFamilies();

        if (this.channelType !== ChannelType.VENDOR.toLowerCase()) {
          this.myProfile.contact.IntProductGroup.forEach(item => {
            const productGroupItem = new SearchItem();
            productGroupItem.id = parseInt(item.productGroup.productGroupId, 10);
            productGroupItem.name = item.productGroup.productGroup;
            this.interestedSelectedProductfamilies.push(productGroupItem);
          });

          this.myProfile.contact.IntProductCategory.forEach(item => {
            const productGroupItem = new ProductCategorySearchItem();
            productGroupItem.id = parseInt(item.productCategorie.productCategorieId, 10);
            productGroupItem.name = item.productCategorie.productCategorie;
            productGroupItem.productGroupId = item.productCategorie.productGroupId;
            this.interestedProductCategorySelectedList.push(productGroupItem);
          });

          this.bindInterestedProductFamilySearch();
        }

        if (!this.isAccountUser) {
          this.getWorkNatureList(this.myProfile.contact.workNatureId);
        }

        this.getShareTypeList(this.myProfile.contact.channelContactSuggestion);
        this.myProfile.contact.productCategory.forEach(item => {
          const _searchItem = new ProductCategorySearchItem();
          _searchItem.id = parseInt(item.productCategorieId, 10);
          _searchItem.name = item.productCategorie.productCategorie;
          _searchItem.productGroupId = item.productCategorie.productGroupId;
          this.channelProductCategorySelectedList.push(_searchItem);
        });

        this.filterProductCategorySearch();
        // Manage Password Fields
        if (ValidationService.isNullOrEmpty(this.myProfile.contact.isShared)) {
          this.isShared = null;
        } else if (this.myProfile.contact.isShared === '0') {
          this.isShared = 0;
        } else {
          this.isShared = 1;
        }
      }

      this.stopPreloaderOnPageLoad();
    },
      (error) => {
        console.log(error);
      });
  }

  setRegistrationGroup() {
    // Set account preferences
  }

  onShareTypeChanged(shareType: string, isChecked: boolean) {
    this.shareTypes.find(item => item.sharetype === shareType).isChecked = !isChecked;
  }

  onWorkNatureChanged(workNature: string) {
    this.workNatureList.forEach(result => {
      if (result.workNature === workNature) {
        result.isChecked = true;
        this.showHideFamilyCategoryLocations(result.workNatureId);
      } else {
        result.isChecked = false;
      }
    });
  }

  getChannelInfos() {
    this.sharedBusiness.getChannelInfos(true).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.channelInfos = <ChannelInfos>response.json();
        // console.log('channelInfos', JSON.stringify(this.channelInfos));

        this.channelInfos.locations.forEach(location => {
          const country = new CountrySearchItem();
          country.id = parseInt(location.country.countryId, 10);
          country.name = location.country.country;
          country.regionCountryJCTId = location.regionCountryJCTId;
          country.regionId = location.regionId;
          country.locationType = location.ChannelLocation.locationType;
          this.addTradeCountries(country);
          this.addRegionDropdown(location.region, location.ChannelLocation.locationType);
        });

        this.channelInfos.productGroup.forEach(item => {
          const productGroup = new SearchItem();
          productGroup.id = parseInt(item.productGroupId, 10);
          productGroup.name = item.productGroup;
          this.productFamiles.push(productGroup);
        });

        this.bindTradeCountrySearch('');
        this.bindRetailerCountrySearch('');
        this.bindSellingCountrySearch('');

        this.bindProductFamilySearch('');

        this.channelInfos.productCategory.forEach(item => {
          const _searchItem = new ProductCategorySearchItem();
          _searchItem.productGroupId = item.productGroupId;
          _searchItem.id = parseInt(item.productCategorieId, 10);
          _searchItem.name = item.productCategorie;
          this.channelProductCategoryList.push(_searchItem);
        });
        this.filterProductCategorySearch();
      }

      this.stopPreloaderOnPageLoad();
    },
      (error) => {
        console.log(error);
      });
  }

  public filterSellingCountrySearch() {
    if (this.tradeSellingSelectedCountries) {
      this.tradeSellingSelectedCountries.forEach(sellingItem => {
        this.searchSellingTradeCountries = this.searchSellingTradeCountries.filter(
          item => item.id.toString() !== sellingItem.id.toString());
      });
    }
  }

  public filterTargetCountrySearch() {
    if (this.tradeTargetSelectedCountries) {
      this.tradeTargetSelectedCountries.forEach(targetItem => {
        this.searchTargetTradeCountries = this.searchTargetTradeCountries.filter(item => item.id.toString() !== targetItem.id.toString());
      });
    }
  }

  public filterRetailCountrySearch() {
    if (this.tradeRetailerSelectedCountries) {
      this.tradeRetailerSelectedCountries.forEach(targetItem => {
        this.searchRetailerTradeCountries = this.searchRetailerTradeCountries.filter(
          item => item.id.toString() !== targetItem.id.toString());
      });
    }
  }

  public filterProductCategorySearch() {
    this.channelProductCategorySelectedList.forEach(targetItem => {
      this.channelProductCategoryList = this.channelProductCategoryList.filter(item => item.id.toString() !== targetItem.id.toString());
    });
  }

  public addRegionDropdown(region: Region, locationType) {
    if (locationType === LocationType.TARGET) {
      // tslint:disable-next-line:triple-equals
      const tradeRegion = this.tradeTargetRegions.find(item => item.regionId === region.regionId);
      if (ValidationService.isNullOrEmpty(tradeRegion)) {
        this.tradeTargetRegions.push(region);
      }
    } else if (locationType === LocationType.SELLING) {
      // tslint:disable-next-line:triple-equals
      const tradeRegion = this.tradeSellingRegions.find(item => item.regionId === region.regionId);
      if (ValidationService.isNullOrEmpty(tradeRegion)) {
        this.tradeSellingRegions.push(region);
      }
    } else if (locationType === LocationType.RETAILER) {
      // tslint:disable-next-line:triple-equals
      const tradeRegion = this.tradeRetailerRegions.find(item => item.regionId === region.regionId);
      if (ValidationService.isNullOrEmpty(tradeRegion)) {
        this.tradeRetailerRegions.push(region);
      }
    }
  }

  public addSelectedCountries(country: CountrySearchItem, locationType: string) {
    if (locationType === LocationType.SELLING) {
      const result = this.tradeSellingSelectedCountries.find(item => item.id.toString() === country.id.toString());
      if (ValidationService.isNullOrEmpty(result)) {
        this.tradeSellingSelectedCountries.push(country);
        // this.isSellingCountriesDirty = true;
      }
    } else if (locationType === LocationType.TARGET) {
      const result = this.tradeTargetSelectedCountries.find(item => item.id.toString() === country.id.toString());
      if (ValidationService.isNullOrEmpty(result)) {
        this.tradeTargetSelectedCountries.push(country);
        // this.isTargetCountriesDirty = true;
      }
    } else if (locationType === LocationType.RETAILER) {
      {
        const result = this.tradeRetailerSelectedCountries.find(item => item.id.toString() === country.id.toString());
        if (ValidationService.isNullOrEmpty(result)) {
          this.tradeRetailerSelectedCountries.push(country);
          // this.isRetailerCountriesDirty = true;
        }
      }
    }
  }

  public addTradeCountries(country: CountrySearchItem) {
    const result = this.tradeCountries.find(item => item.id.toString() === country.id.toString());
    if (ValidationService.isNullOrEmpty(result)) {
      this.tradeCountries.push(country);
    }
  }

  public bindTradeCountrySearch(data: string) {
    this.searchTargetTradeCountries = this.tradeCountries.filter(item => item.locationType === LocationType.TARGET);
    this.filterTargetCountrySearch();
  }

  public bindSellingCountrySearch(data: string) {
    this.selectedTargetRegionId = null;
    this.searchSellingTradeCountries = this.tradeCountries.filter(item => item.locationType === LocationType.SELLING);
    this.filterSellingCountrySearch();
  }

  // Retailer countries
  public bindRetailerCountrySearch(data: string) {
    this.searchRetailerTradeCountries = this.tradeCountries.filter(item => item.locationType === LocationType.RETAILER);
    this.filterRetailCountrySearch();
  }

  // Product family.
  onProductfamilySelected(productFamily: SearchItem) {
    this.selectedProductfamilies.push(productFamily);
    this.isProductFamiliesDirty = true;
    if (this.productFamilySearchList.length > 0) {
      this.productFamilySearchList = this.productFamilySearchList.filter(item => item.id.toString() !== productFamily.id.toString());
    }
  }


  private bindProductFamilySearch(data: string) {
    this.productFamilySearchList = this.productFamiles;
    this.filterProductFamilySearchListBySelectedProductFamilies();
  }

  public filterProductFamilySearchListBySelectedProductFamilies() {
    this.selectedProductfamilies.forEach(productFamily => {
      this.productFamilySearchList = this.productFamilySearchList.filter(item => item.id.toString() !== productFamily.id.toString());
    });
  }

  public onProductFamiliesRemoving(data: SearchItem) {
    this.selectedProductfamilies = this.selectedProductfamilies.filter(item => item.id.toString()
      !== data.id.toString());
    this.productFamilySearchList.push(data);
    this.isProductFamiliesDirty = true;
  }

  public onSearchProductFamilySelected(productFamilyItem: SearchItem) {
    const result = this.selectedProductfamilies.find(item => item.id.toString() === productFamilyItem.id.toString());
    if (ValidationService.isNullOrEmpty(result)) {
      this.selectedProductfamilies.push(productFamilyItem);
      this.isProductFamiliesDirty = true;
    }

    if (this.productFamilySearchList.length > 0) {
      this.productFamilySearchList = this.productFamilySearchList.filter(item => item.id.toString() !== productFamilyItem.id.toString());
    }
  }

  // Interested Product families.
  private bindInterestedProductFamilySearch(): void {

    this.accountBusiness.getProductFamily('', true).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.interestedProductFamilySearchList = result.json() as Array<SearchItem>;
        this.filterInterestFamilySearch();
      }
    },
      (error) => {
        console.log(error);
      });
  }

  private filterInterestFamilySearch(): void {
    this.interestedSelectedProductfamilies.forEach(productFamily => {
      this.interestedProductFamilySearchList = this.interestedProductFamilySearchList.filter(item => item.id.toString() !==
        productFamily.id.toString());
    });

    // Hide Filter from product family & category (CR)

    // this.selectedProductfamilies.forEach(productFamily => {
    //   this.interestedProductFamilySearchList = this.interestedProductFamilySearchList.filter(item => item.id.toString() !==
    //     productFamily.id.toString());
    // });

    // this.productFamilySearchList.forEach(productFamily => {
    //   this.interestedProductFamilySearchList = this.interestedProductFamilySearchList.filter(item => item.id.toString() !==
    //     productFamily.id.toString());
    // });

    for (let i = 0; i < this.interestedProductFamilySearchList.length; i++) {
      this.interestedProductCategorySearchList.push(new Array<ProductCategorySearchItem>());
    }
  }

  private onInterestedProductFamiliesRemoving(data: SearchItem) {
    const removedItemindex = this.interestedSelectedProductfamilies.findIndex(item => item.id === data.id);
    if (removedItemindex > -1) {
      this.interestedProductCategorySearchList.splice(removedItemindex, 1);
    }

    this.interestedSelectedProductfamilies = this.interestedSelectedProductfamilies.filter(item => item.id.toString()
      !== data.id.toString());
    this.interestedProductFamilySearchList.push(data);
    this.isInterestedProductFamiliesDirty = true;
  }

  private onInterestedProductFamilySelected(productFamilyItem: SearchItem) {
    const result = this.interestedSelectedProductfamilies.find(item => item.id.toString()
      === productFamilyItem.id.toString());
    if (ValidationService.isNullOrEmpty(result)) {
      this.interestedSelectedProductfamilies.push(productFamilyItem);
      this.isInterestedProductFamiliesDirty = true;
    }

    if (this.interestedProductFamilySearchList.length > 0) {
      this.interestedProductFamilySearchList = this.interestedProductFamilySearchList.filter(item => item.id.toString()
        !== productFamilyItem.id.toString());
    }
  }

  // interested product categories.
  public onAutoCompleteTextEntered(data: ProductCategorySearchItem) {
    if (this.interestedProductCategorySearchList[data.id].length > 0) {
      return;
    }

    this.preLoader = true;
    this.accountBusiness.getProductCategory('', data.productGroupId, true).subscribe(result => {
      const response = result as Response;
      this.preLoader = false;
      if (response.ok) {
        const productCatSearchList = result.json() as Array<ProductCategorySearchItem>;
        this.interestedProductCategorySearchList[data.id] = this.filterInterestedCategorySearchList(productCatSearchList);
      }
    },
      (error) => {
        this.preLoader = false;
        console.log(error);
      });
  }

  public filterInterestedCategorySearchList(productCatSearchList: Array<ProductCategorySearchItem>): Array<ProductCategorySearchItem> {
    this.interestedProductCategorySelectedList.forEach(categoryItem => {
      productCatSearchList = productCatSearchList.filter(item => item.id.toString() !== categoryItem.id.toString());
    });

    return productCatSearchList;
  }

  validateForm(): boolean {
    this.msg_code_image = '';
    let returnVal = true;
    if (!this.registrationGroup.valid) {
      const values = this.registrationGroup.value;
      const keys = Object.keys(values);
      keys.forEach(val => {
        const ctrl = this.registrationGroup.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = val;
          }
        }
      });
      returnVal = false;
    }

    if (this.selectedCountryID === 0) {
      this.countryCtrl = 'country';
      this.msg_code_country = '0002';
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        this.scrollToElementId = 'countryListId';
      }
      returnVal = false;
    } else {
      this.countryCtrl = '';
      this.msg_code_country = '';
    }

    if (this.showTradeLocation) {
      const locations = this.locationChildren.toArray();
      if (locations.length > 0) {
        locations.forEach(locationItem => {
          if (locationItem.type.toLowerCase() === this.locationType.TARGET.toLowerCase()) {
            if (locationItem.viewDataSource.length === 0) {
              this.errTargetCounries = 'tradeTargetCounries';
              this.msg_code_TargetCounries = '0009';
              if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
                this.scrollToElementId = 'targetSelectedCountriesId';
              }
              returnVal = false;
            } else {
              this.errTargetCounries = '';
              this.msg_code_TargetCounries = '';
              // returnVal = true;
            }
          } else if (locationItem.type.toLowerCase() === this.locationType.SELLING.toLowerCase()) {
            if (locationItem.viewDataSource.length === 0) {
              this.errSellingCounries = 'tradeSellingCountries';
              this.msg_code_SellingCounries = '0008';
              if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
                this.scrollToElementId = 'sellingSelectedCountriesId';
              }
              returnVal = false;
            } else {
              this.errSellingCounries = '';
              this.msg_code_SellingCounries = '';
              // returnVal = true;
            }
          } else if (locationItem.type.toLowerCase() === this.locationType.RETAILER.toLowerCase()) {
            if (locationItem.viewDataSource.length === 0) {
              this.errRetilerCounries = 'tradeSellingCountries';
              this.msg_code_RetilerCounries = '0008';
              if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
                this.scrollToElementId = 'retailerSelectedCountriesId';
              }
              returnVal = false;
            } else {
              this.errRetilerCounries = '';
              this.msg_code_RetilerCounries = '';
              // returnVal = true;
            }
          }
        });
      }
    }

    if (this.showProductFamily) {
      if (this.selectedProductfamilies.length === 0) {
        this.errProductFamilies = 'productFamilies';
        this.msg_code_ProductFamilies = '0010';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'productFamiliesId';
        }
        returnVal = false;
      } else {
        this.errProductFamilies = '';
        this.msg_code_ProductFamilies = '';
        // returnVal = true;
      }
    }

    let allProductCategories: ProfileProductCategoryComponent[];
    if (this.showProductFamily) {
      allProductCategories = this.productCategoryViewChildren.toArray();

      this.productCategoryComponents = allProductCategories.filter(item => item.CategoryType === ProductCategoryTypeEnum.PRODUCT_CATEGORY);
      this.productCategoryComponents = this.productCategoryComponents.filter(item => item.selectedProductCategories.length !== 0
        || item._productCategorySearchList.length !== 0);

      const productCategories = this.productCategoryComponents.filter(item => item.selectedProductCategories.length === 0);

      if (productCategories.length > 0) {
        this.errProductCategories = 'productCategories';
        this.msg_code_ProductCategories = '0011';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'productCategoriesId';
        }
        returnVal = false;
      } else {
        this.errProductCategories = '';
        this.msg_code_ProductCategories = '';
        // returnVal = true;
      }
    }

    if (this.channelType !== ChannelType.VENDOR.toLowerCase()) {
      if (this.showInterestedProductFamily) {
        if (this.interestedSelectedProductfamilies.length === 0) {
          this.errInteresedProductFamilies = 'interesedProductFamily';
          this.msg_code_InteresedProductFamilies = '0012';
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = 'interesedProductFamilyId';
          }
          returnVal = false;
        } else {
          this.errInteresedProductFamilies = '';
          this.msg_code_InteresedProductFamilies = '';
          // returnVal = true;
        }
      }

      if (this.showInterestedProductCategory) {
        this.interestedProductCategoryComponents = allProductCategories.filter(
          item => item.CategoryType === ProductCategoryTypeEnum.INTERESTED_PRODUCT_CATEGORY);
        // this.interestedProductCategoryComponents = this.interestedProductCategoryComponents.filter(
        //   item => item.selectedProductCategories.length !== 0
        //     || item.productCategorySearchList.length !== 0);
        const interestproductCategories = this.interestedProductCategoryComponents.filter(
          item => item.selectedProductCategories.length === 0);
        if (interestproductCategories.length > 0) {
          this.errInteresedProductCategories = 'interesedProductCategories';
          this.msg_code_InteresedProductCategories = '0013';
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = 'interesedProductCategoriesId';
          }
          returnVal = false;
        } else {
          this.errInteresedProductCategories = '';
          this.msg_code_InteresedProductCategories = '';
          // returnVal = true;
        }
      }
    }
    // if(this.selectedProductfamilies.length>0)
    // {
    //   this.errWorknature = 'productFamilies';
    //   this.msg_code_worknature = '0010';
    //   return;
    // }

    if (!this.isAccountUser) {
      const result = this.workNatureList.filter(item => item.isChecked === true);
      if (ValidationService.isNullOrEmpty(result) || result.length === 0) {
        this.errWorknature = 'worknature';
        this.msg_code_worknature = '0005';
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          this.scrollToElementId = 'workNatureId';
        }
        returnVal = false;
      } else {
        this.errWorknature = '';
        this.msg_code_worknature = '';
        // returnVal = true;
      }
    }

    if (ValidationService.isNullOrEmpty(this.isShared)) {
      this.errShareType = 'shareType';
      this.msg_code_ShareType = '0006';
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        this.scrollToElementId = 'visibilityId';
      }
      returnVal = false;
    } else {
      if (this.isShared === 1) {
        const result1 = this.shareTypes.filter(item => item.isChecked === true);
        if (ValidationService.isNullOrEmpty(result1) || result1.length === 0) {
          this.errShareType = 'shareType';
          this.msg_code_ShareType = '0007';
          if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
            this.scrollToElementId = 'visibilityId';
          }
          returnVal = false;
        } else {
          this.errShareType = '';
          this.msg_code_ShareType = '';
          // returnVal = true;
        }
      } else {
        this.errShareType = '';
        this.msg_code_ShareType = '';
        // returnVal = true;
      }
    }

    if (this.scrollToElementId === 'interesedProductCategoriesId' || this.scrollToElementId === 'productCategoriesId') {
      this.scrollToElement(-200);
    } else {
      this.scrollToElement();
    }

    return returnVal;
  }

  private scrollToElement(offset: number = -100) {
    this.scrollService.scrollTo(document.getElementById(this.scrollToElementId), 1000, offset);
    this.scrollToElementId = '';
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      this.hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.CONTACT_PROFILE_UPDATE);
      if (!this.hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  onFinalSubmit() {
    if (!this.authorizeBeforeSubmit()) {
      return;
    }

    this.preLoader = true;
    if (this.validateForm()) {
      const myProfileUpdateRequest: MyProfileUpdateRequest = new MyProfileUpdateRequest();
      myProfileUpdateRequest.contact = new ContactUpdateRequest();
      myProfileUpdateRequest.contact.firstName = this.firstNameCtrl.value;
      myProfileUpdateRequest.contact.lastName = this.lastNameCtrl.value;
      myProfileUpdateRequest.contact.email = this.emailCtrl.value;
      myProfileUpdateRequest.contact.countryId = parseInt(this.selectedCountryID.toString(), 10);
      myProfileUpdateRequest.contact.jobTitle = this.jobTitleCtrl.value; // VJ 28/02/2019
      if (!ValidationService.isNullOrEmpty(this.location)) {
        myProfileUpdateRequest.contact.avatar = this.location;
      }

      if (this.phoneCtrl.value) {
        myProfileUpdateRequest.contact.phoneNo = this.phoneCtrlCode.value + '-' + this.phoneCtrl.value;
      }
      if (this.mobileNoCtrl.value) {
        myProfileUpdateRequest.contact.mobileNo = this.mobileNoCtrlCode.value + '-' + this.mobileNoCtrl.value;
      }
      // if (this.linkedInCtrl.dirty && this.linkedInCtrl.value.length > 0) {
      myProfileUpdateRequest.contact.linkedInUrl = this.linkedInCtrl.value;
      // }

      if (this.googlePlusUrlCtrl.dirty && this.googlePlusUrlCtrl.value.length > 0) {
        myProfileUpdateRequest.contact.googlePlusUrl = this.googlePlusUrlCtrl.value;
      }

      if (!this.isAccountUser) {
        const selectedWorknature = this.workNatureList.filter(item =>
          item.isChecked === true);
        myProfileUpdateRequest.contact.workNatureId = parseInt(selectedWorknature[0].workNatureId, 10);
      }

      myProfileUpdateRequest.contact.isShared = this.isShared.toString();

      if (this.showTradeLocation) {
        const locations = this.locationChildren.toArray();
        if (locations.length > 0) {
          myProfileUpdateRequest.locations = Array<Location>();
          locations.forEach(locationItem => {
            if (locationItem.type.toLowerCase() === this.locationType.TARGET.toLowerCase()) {
              if (locationItem.viewDataSource.length > 0) {
                const targetLocation = new Location();
                targetLocation.locationType = LocationType.TARGET;
                targetLocation.isUpdate = true;
                targetLocation.location = new Array<number>();
                locationItem.viewDataSource.forEach(item => {
                  targetLocation.location.push(parseInt(item.regionCountryJCTId, 10));
                });
                myProfileUpdateRequest.locations.push(targetLocation);
              }
            } else if (locationItem.type.toLowerCase() === this.locationType.SELLING.toLowerCase()) {
              if (locationItem.viewDataSource.length > 0) {
                const sellingLocation = new Location();
                sellingLocation.locationType = LocationType.SELLING;
                sellingLocation.isUpdate = true;
                sellingLocation.location = new Array<number>();
                locationItem.viewDataSource.forEach(item => {
                  sellingLocation.location.push(parseInt(item.regionCountryJCTId, 10));
                });
                myProfileUpdateRequest.locations.push(sellingLocation);
              }
            } else if (locationItem.type.toLowerCase() === this.locationType.RETAILER.toLowerCase()) {
              if (locationItem.viewDataSource.length > 0) {
                const retailerLocation = new Location();
                retailerLocation.locationType = LocationType.RETAILER;
                retailerLocation.isUpdate = true;
                retailerLocation.location = new Array<number>();
                locationItem.viewDataSource.forEach(item => {
                  retailerLocation.location.push(parseInt(item.regionCountryJCTId, 10));
                });
                myProfileUpdateRequest.locations.push(retailerLocation);
              }
            }
          });
        }
      }

      if (this.showProductFamily) {
        if (this.isProductFamiliesDirty) {
          const productFamilies = Array<Id_Model>();
          this.selectedProductfamilies.forEach(item => {
            const request = new Id_Model();
            request.id = item.id;
            productFamilies.push(request);
          });

          if (productFamilies.length > 0) {
            myProfileUpdateRequest.productFamilies = productFamilies;
          }
        }
      }

      if (this.showProductCategory) {
        const productCategories = Array<ProductCategoryUpdateRequest>();
        this.productCategoryComponents.forEach(productCategoryComp => {
          // if (productCategoryComp.isDirty) {
          productCategoryComp.selectedProductCategories.forEach(item => {
            const categFamily = new ProductCategoryUpdateRequest();
            categFamily.productCategoriesId = item.id;
            categFamily.productFamilId = parseInt(item.productGroupId, 10);
            productCategories.push(categFamily);
          });
          // }
        });

        if (productCategories.length > 0) {
          myProfileUpdateRequest.productCategories = productCategories;
        }
      }

      if (this.channelType !== ChannelType.VENDOR.toLowerCase() && this.showInterestedProductFamily
        && this.showInterestedProductCategory) {
        if (this.isInterestedProductFamiliesDirty) {
          const intrProductFamilies = Array<Id_Model>();
          this.interestedSelectedProductfamilies.forEach(item => {
            const request = new Id_Model();
            request.id = item.id;
            intrProductFamilies.push(request);
          });

          if (intrProductFamilies.length > 0) {
            myProfileUpdateRequest.interestedProductFamilies = intrProductFamilies;
          }
        }

        const intrProductCategories = Array<ProductCategoryUpdateRequest>();
        this.interestedProductCategoryComponents.forEach(productCategoryComp => {
          // if (productCategoryComp.isDirty) {
          productCategoryComp.selectedProductCategories.forEach(item => {
            const categFamily = new ProductCategoryUpdateRequest();
            categFamily.productCategoriesId = item.id;
            categFamily.productFamilId = productCategoryComp.productFamily.id;
            intrProductCategories.push(categFamily);
          });
          // }
        });

        if (intrProductCategories.length > 0) {
          myProfileUpdateRequest.interestedProductCategories = intrProductCategories;
        }
      }

      if (this.isShared === 1) {
        const sharetypeData = this.shareTypes.filter(item => item.isChecked === true);
        if (sharetypeData.length > 0) {
          myProfileUpdateRequest.channelContactSuggestion = new Array<Id_Model>();
          sharetypeData.forEach(item => {
            const suggestion = new Id_Model();
            suggestion.id = parseInt(item.sharetypeid, 10);
            myProfileUpdateRequest.channelContactSuggestion.push(suggestion);
          });
        }
      }

      this.profileBusiness.updateMyProfile(myProfileUpdateRequest, true).subscribe(result => {
        const response = result as Response;
        if (response.ok) {
          localStorage.setItem(AppLocalStorageKeys.USER_IMAGE_URL, this.urlImage);
          this.dataBinding.changeProfileImg(this.urlImage);
          this.dataBinding.changeUserName(this.registrationGroup.controls['firstName'].value + ' ' +
            this.registrationGroup.controls['lastName'].value);
          localStorage.setItem(AppLocalStorageKeys.USER_NAME, this.registrationGroup.controls['firstName'].value
            + ' ' + this.registrationGroup.controls['lastName'].value);
          this.clearErrorControls();
          this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
          this.toastr.success(this.translate.instant('myprofile.toastMsg.profileDetils'));
        } else {
          // let keys = Object.keys(myProfileUpdateRequest.contact);
          const errorResponse = response.json() as Array<APIError>;
          // console.log('errorResponse', errorResponse);
          errorResponse.forEach(errItem => {
            if (errItem.property === 'contact') {
              const level1Err = errItem.errors as Array<APIError>;
              const linkedInErr = level1Err.filter(x => x.property === 'linkedInUrl');
              if (linkedInErr.length > 0) {
                const linkedInErr1 = linkedInErr[0].errors as Array<APIError2>;
                if (linkedInErr1.length > 0) {
                  this.linkedInErrControl = 'UrlErr';
                  this.msg_code_linkedIn = linkedInErr1[0].code.toString();
                } else {
                  this.linkedInErrControl = '';
                  this.msg_code_linkedIn = '';
                }
              } else {
                this.linkedInErrControl = '';
                this.msg_code_linkedIn = '';
              }

              const googlePlusErr = level1Err.filter(x => x.property === 'googlePlusUrl');
              if (googlePlusErr.length > 0) {
                const googlePlusErr1 = googlePlusErr[0].errors as Array<APIError2>;
                if (googlePlusErr1.length > 0) {
                  this.googlePlusErrControl = 'UrlErr';
                  this.msg_code_googlePlus = googlePlusErr1[0].code.toString();
                } else {
                  this.googlePlusErrControl = '';
                  this.msg_code_googlePlus = '';
                }
              } else {
                this.googlePlusErrControl = '';
                this.msg_code_googlePlus = '';
              }
            }
          });
          this.preLoader = false;
          this.toastr.error(this.translate.instant('myprofile.toastMsg.somthingError'));
        }
        this.preLoader = false;
      });
    } else {
      this.preLoader = false;
    }
  }

  public clearErrorControls() {
    this.linkedInErrControl = '';
    this.msg_code_linkedIn = '';
    this.googlePlusErrControl = '';
    this.msg_code_googlePlus = '';
  }

  private onSharedClick() {
    this.isShared = 1;
  }

  private onConfidentialClick() {
    this.shareTypes.forEach(item => {
      item.isChecked = false;
    });

    this.isShared = 0;
  }

  private showHideWorkNature() {
    if (this.appRole) {
      if (RoleIdEnum.AccountUser === parseInt(this.appRole.roleId, 10)) {
        this.isAccountUser = true;
      } else {
        this.isAccountUser = false;
      }
    } else {
      this.isAccountUser = false;
    }
  }

  private showHideFamilyCategoryLocations(workNatureId = null) {
    if (this.channelType) {
      if (this.channelType.toLowerCase() === ChannelType.RETAILER.toLowerCase()) {
        this.showTradeLocation = false;
        this.showProductFamily = true;
        this.showProductCategory = true;
        this.showInterestedProductFamily = true;
        this.showInterestedProductCategory = true;
      } else if (workNatureId && this.channelType.toLowerCase() === ChannelType.DISTRIBUTOR.toLowerCase() && this.appRole &&
        parseInt(this.appRole.roleId, 10) !== RoleIdEnum.AccountUser) {
        if (this.sourcingProfile.includes(parseInt(workNatureId, 10))) {
          this.showTradeLocation = false;
          this.showProductFamily = true;
          this.showProductCategory = true;
          this.showInterestedProductFamily = true;
          this.showInterestedProductCategory = true;
        } else if (this.sellingProfile.includes(parseInt(workNatureId, 10))) {
          this.showTradeLocation = true;
          this.showProductFamily = false;
          this.showProductCategory = false;
          this.showInterestedProductFamily = false;
          this.showInterestedProductCategory = false;
        }
      } else {
        this.showAllSections();
      }
    } else {
      this.showAllSections();
    }
  }

  showAllSections() {
    this.showTradeLocation = true;
    this.showProductFamily = true;
    this.showProductCategory = true;
    if (this.channelType.toLowerCase() !== ChannelType.VENDOR.toLowerCase()) {
      this.showInterestedProductFamily = true;
      this.showInterestedProductCategory = true;
    } else {
      this.showInterestedProductFamily = false;
      this.showInterestedProductCategory = false;
    }
  }

  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }

  // Function to find isVat & isRegistration
  setRegistrationIsVAT(data) {
    const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
      === parseInt(data, 10));

    if (countryData[0].phoneCode) {
      this.phoneCtrlCode.setValue(countryData[0].phoneCode);
      this.mobileNoCtrlCode.setValue(countryData[0].phoneCode);

    } /*else {
      }*/
  }
}
