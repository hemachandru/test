import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trade-information',
  templateUrl: './trade-information.component.html',
  styleUrls: ['./trade-information.component.scss']
})
export class TradeInformationComponent implements OnInit {
  public updateFlagBoolean: boolean;
  constructor() {
    this.updateFlagBoolean = true;
   }

  ngOnInit() {
  }

}
