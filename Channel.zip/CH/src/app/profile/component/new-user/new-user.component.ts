import { Component, OnInit, ViewChild } from '@angular/core';
import { AddUserdefault, GetUserGeneral, GetAccessPermission, AddUser, ContactGet } from './../../models/addUser';
import { ProfileBusiness } from './../../business/profile-business';
import { UserGeneralComponent } from '@app/profile/component/user-general/user-general.component';
import { UserPreferencesComponent } from '../user-preferences/user-preferences.component';
import { UserTradeinformationComponent } from '../user-tradeinformation/user-tradeinformation.component';
import { UserLocationComponent } from '../user-location/user-location.component';
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { Router } from '@angular/router';
import { UserManagementTab, ChannelTypeIdEnum } from '@app/config/constant';
import { TabsContainer } from 'angular-tabs-component';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { Subscription } from 'rxjs/Subscription';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';
import { ScrollToService } from 'ng2-scroll-to-el';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss']
})

export class NewUserComponent implements OnInit {
  public defaultValue = new AddUserdefault();
  public addUserSubmit = new AddUser();
  public objContact: GetUserGeneral;
  public objTradeInfo: Array<ContactGet>;
  public objLocation: Array<ContactGet>;
  public objAccessPermission: Array<GetAccessPermission>;
  public objTradeproduct: any;
  public userID: number;
  public buttonName: string;
  public addUser: any;
  public userManagementTab;
  public activeTabIndex: number;
  public isTabLoadedFirstTime: boolean;
  public isPrevTabSelected: boolean;
  public title: string;
  private apiUrl = ApiUrl;
  public preloader: boolean;
  private userManageSubscription: Subscription;
  @ViewChild(UserGeneralComponent) userGeneralComponent: UserGeneralComponent;
  @ViewChild(UserPreferencesComponent) userPreferencesComponent: UserPreferencesComponent;
  @ViewChild(UserTradeinformationComponent) userTradeinformationComponent: UserTradeinformationComponent;
  @ViewChild(UserLocationComponent) userLocationComponent: UserLocationComponent;

  @ViewChild(TabsContainer) tabsContainer: TabsContainer;
  public channelTypeIdEnum = ChannelTypeIdEnum;
  public currentChannelTypeId: number;
  private sellingProfile: Array<number>;
  private sourcingProfile: Array<number>;
  public isSellingProfile: boolean;

  constructor(public sharedBusiness: SharedBusiness, private profileBusiness: ProfileBusiness,
    private router: Router, private scrollService: ScrollToService,
    private translate: TranslateService,
    private userDetailService: UserDetailService,
    private toastr: ToastrService) {
    this.addUser = 0;
    this.userManagementTab = UserManagementTab;
    this.activeTabIndex = 0;
    this.isTabLoadedFirstTime = true;
    this.buttonName = 'shared.buttonLabels.next';
    this.isPrevTabSelected = false;
    this.title = 'userManagement.title';
    this.isSellingProfile = false;
  }

  ngOnInit() {
    const _channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    this.currentChannelTypeId = _channelType ? parseInt(_channelType, 10) : 0;
    this.addUserSubmit.channelTypeId = this.currentChannelTypeId;
    this.addUser = 0;

    if (localStorage.getItem(AppLocalStorageKeys.SELLING_PROFILE)) {
      this.sellingProfile = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SELLING_PROFILE)) as Array<number>;
    }

    if (localStorage.getItem(AppLocalStorageKeys.SOURCING_PROFILE)) {
      this.sourcingProfile = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SOURCING_PROFILE)) as Array<number>;
    }

    this.userManagement();
    this.gettradeinfolocation();
  }

  userManagement() {
    this.userManageSubscription = this.userDetailService.currentUserDetail
      .subscribe(data => {
        if (!ValidationService.isNullOrEmpty(data)) {
          if (data.action === this.apiUrl.ADD_USER) {
            this.addUser = data.userId || 0;
            if (this.addUser !== 0) {
              this.title = 'shared.buttonLabels.updateUser';
              localStorage.setItem(AppLocalStorageKeys.USER_ID, this.addUser.toString());
            } else {
              localStorage.setItem(AppLocalStorageKeys.USER_ID, this.addUser.toString());
            }
          } else {
            this.addUser = localStorage.getItem(AppLocalStorageKeys.USER_ID);
            this.title = 'shared.buttonLabels.updateUser';
          }
        } else {
          const userId = localStorage.getItem(AppLocalStorageKeys.USER_ID);
          this.addUser = userId ? userId : this.addUser;
        }
      });
    this.getUserManagement(this.addUser);
    this.buttonName = 'shared.buttonLabels.next';
  }

  onTabChange(event, scroll) {
    if (this.isPrevTabSelected) {
      this.isPrevTabSelected = false;
      return false;
    }

    if (!this.isTabLoadedFirstTime) {
      if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle === UserManagementTab.GENERAL) {
        if (!this.userGeneralComponent.checkValid(scroll)) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }
      } else if (this.tabsContainer.tabs[this.activeTabIndex].getTabTitle() === UserManagementTab.PREFERNCE) {
        if (!this.userPreferencesComponent.checkValid()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }
      } else if (this.tabsContainer.tabs[this.activeTabIndex].getTabTitle() === UserManagementTab.TRADE_INFORMATION) {
        if (!this.userTradeinformationComponent.validation()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }

      } else if (this.tabsContainer.tabs[this.activeTabIndex].getTabTitle() === UserManagementTab.TRADE_LOCATION) {
        if (!this.userLocationComponent.ValidationLocation()) {
          this.isPrevTabSelected = true;
          this.tabsContainer.selectTab(this.tabsContainer.tabs[this.activeTabIndex]);
        } else {
          this.changeButtonName();
        }

      }
    }

    this.isTabLoadedFirstTime = false;
  }

  changeButtonName() {
    this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
    this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
    if (this.activeTabIndex === this.tabsContainer.tabs.length - 1) {
      this.buttonName = 'shared.buttonLabels.save';
    } else {
      this.buttonName = 'shared.buttonLabels.next';
    }
  }

  public async onGeneralChange(data: boolean): Promise<any> {
    this.defaultValue.flagGen = data;
  }

  onBack() {
    this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
    if (this.activeTabIndex > 0) {
      if (this.currentChannelTypeId === ChannelTypeIdEnum.DISTRIBUTOR) {
        if (this.isSellingProfile) {
          if (this.activeTabIndex === 2) {
            this.activeTabIndex = this.activeTabIndex - 1;
          }
        } else {
          if (this.activeTabIndex === 3) {
            this.activeTabIndex = this.activeTabIndex - 1;
          }
        }
      } else if (this.currentChannelTypeId === ChannelTypeIdEnum.RETAILER) {
        if (this.activeTabIndex === 3) {
          this.activeTabIndex = this.activeTabIndex - 1;
        }
      }

      this.activeTabIndex = this.activeTabIndex - 1;
      const prevTab = this.tabsContainer.tabs[this.activeTabIndex];

      this.tabsContainer.selectTab(prevTab);
    } else {
      this.router.navigate(['/profile', { outlets: { 'profileroute': ['usermanagement'] } }]);
    }
  }

  // get User mangement details
  getUserManagement(id: number) {
    this.addUser = id ? id : this.addUser;
    if (this.addUser > 0) {
      this.preloader = true;
      this.profileBusiness.getUserManagementdetails(true, id).subscribe(serviceRes => {
        const response = serviceRes as Response;
        if (response.ok) {
          const data = <any>response.json();
          this.preloader = false;
          if (!ValidationService.isNullOrEmpty(data.userId)) {
            this.objContact = data as GetUserGeneral;
          }
          this.objTradeInfo = data.contact as Array<ContactGet>;
          this.objLocation = data.contact as Array<ContactGet>;
          this.objAccessPermission = data.permissions as Array<GetAccessPermission>;
        } else {
          this.preloader = false;
        }
      },
        (error) => {
          this.preloader = false;
          console.log(error);
        });

    }
  }

  // get trade info and location
  gettradeinfolocation() {
    this.sharedBusiness.getChannelInfos(true).subscribe(serviceRes => {
      const response = serviceRes as Response;
      if (response.ok) {
        const result = response.json();
        this.objTradeproduct = result;
      }
    });
  }

  onSave(scroll) {
    this.preloader = true;
    if (this.validateOnSave(scroll)) {
      if (this.buttonName === 'shared.buttonLabels.save') {
        // if (this.validateOnSave()) {
        this.addUserSubmit.contact = this.userGeneralComponent.getFormData();
        this.addUserSubmit.accessPermissions = this.userPreferencesComponent.getFormData();

        if (this.currentChannelTypeId === ChannelTypeIdEnum.VENDOR) {
          this.addUserSubmit.productFamilies = this.userTradeinformationComponent.onProductFamily();
          this.addUserSubmit.productCategories = this.userTradeinformationComponent.onProductCategory();
          this.addUserSubmit.locations = this.userLocationComponent.onLocation();
        } else if (this.currentChannelTypeId === ChannelTypeIdEnum.DISTRIBUTOR) {
          if (this.isSellingProfile) {
            delete this.addUserSubmit.productFamilies;
            delete this.addUserSubmit.productCategories;
            this.addUserSubmit.locations = this.userLocationComponent.onLocation();
          } else {
            this.addUserSubmit.productFamilies = this.userTradeinformationComponent.onProductFamily();
            this.addUserSubmit.productCategories = this.userTradeinformationComponent.onProductCategory();
            delete this.addUserSubmit.locations;
          }
        } else {
          this.addUserSubmit.productFamilies = this.userTradeinformationComponent.onProductFamily();
          this.addUserSubmit.productCategories = this.userTradeinformationComponent.onProductCategory();
          delete this.addUserSubmit.locations;
        }

        // tslint:disable-next-line:triple-equals
        if (this.addUser == 0) {
          this.preloader = true;
          this.profileBusiness.addUserManagement(this.addUserSubmit, true).subscribe(response => {
            this.preloader = false;
            const responseAddUser = response as Response;
            if (responseAddUser.ok) {
              this.router.navigate(['/profile', { outlets: { profileroute: ['usermanagement'] } }]);
              this.toastr.success(this.translate.instant('userManagement.toastrMsg.userSuccessfully'));
            } else if (response.json()[0]['errors'][0]['code'] === 0) {
              this.toastr.warning(response.json()[0]['errors'][0]['message']);
            }
          });
        } else {
          this.preloader = true;
          this.profileBusiness.updateUserManagement(this.addUserSubmit, true, this.addUser).subscribe(response => {
            this.preloader = false;
            const responseUpdateUser = response as Response;
            if (responseUpdateUser.ok) {
              this.router.navigate(['/profile', { outlets: { profileroute: ['usermanagement'] } }]);
              this.toastr.success(this.translate.instant('userManagement.toastrMsg.userupdatedSuccessfully'));
              localStorage.removeItem(AppLocalStorageKeys.USER_ID);
            } else {
              this.toastr.error(this.translate.instant('userManagement.toastrMsg.somthingwrong'));
            }
          });
        }
        // }
      } else {
        this.activeTabIndex = this.tabsContainer.tabs.findIndex(item => item.active === true);
        if (this.activeTabIndex <= this.tabsContainer.tabs.length - 1) {
          let index = this.activeTabIndex;
          if (this.currentChannelTypeId === ChannelTypeIdEnum.DISTRIBUTOR) {
            if (this.isSellingProfile) {
              if (index === 0) {
                index = this.activeTabIndex + 1;
              }
            } else {
              if (index === 1) {
                index = this.activeTabIndex + 1;
              }
            }
          } else if (this.currentChannelTypeId === ChannelTypeIdEnum.RETAILER) {
            if (index === 1) {
              index = this.activeTabIndex + 1;
            }
          }

          // const nextTab = this.tabsContainer.tabs[this.activeTabIndex + 1];
          const nextTab = this.tabsContainer.tabs[index + 1];
          this.tabsContainer.selectTab(nextTab);
        }
      }
    }
    this.preloader = false;
  }

  validateOnSave(scroll): boolean {
    if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle === UserManagementTab.GENERAL &&
      !this.userGeneralComponent.checkValid(scroll)) {
      return false;
    } else if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle ===
      UserManagementTab.PREFERNCE && !this.userPreferencesComponent.checkValid()) {
      return false;
    } else if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle
      === UserManagementTab.TRADE_INFORMATION && !this.userTradeinformationComponent.validation()) {
      return false;
    } else if (this.tabsContainer.tabs[this.activeTabIndex].tabTitle
      === UserManagementTab.TRADE_LOCATION && !this.userLocationComponent.ValidationLocation()) {
      return false;
    }

    return true;
  }

  ngOnDestory() {
    this.userManageSubscription.unsubscribe();
    this.addUser = 0;
  }

  onWorkNatureChange(workNatureId: number) {
    if (this.sourcingProfile.includes(workNatureId)) {
      this.isSellingProfile = false;
    } else if (this.sellingProfile.includes(workNatureId)) {
      this.isSellingProfile = true;
    }
  }
}
