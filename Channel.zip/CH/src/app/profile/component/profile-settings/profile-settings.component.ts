import { Component, OnInit } from '@angular/core';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ScrollToService } from 'ng2-scroll-to-el';
import { UploadFileService } from '@app/shared/shared-service/upload-file.service';
import { ProfileBusiness } from '../../business/profile-business';
import { AppLocalStorageKeys, UserStatusDetails } from '@app/config/constant_keys';
// tslint:disable-next-line:max-line-length
import { PaymentTypes, PaymentTerms, AccountStauts, UserVisiblity, SampleRequests, IProfileSettingSave, UservisibilityType, SampleRequestsPost, DefaultContact } from '../../models/profile-setting';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { environment } from 'environments/environment';
import { TradeInformationGet } from '@app/account/models/profile';
import { Response } from '@angular/http';
import { ChannelTypeIdEnum } from '@app/config/constant';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { UpdateChannelData } from '@app/channel/models/channel_models';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { AccessPermissionEnum, UserAccountStatus } from '@app/config/constant';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-profile-settings',
  templateUrl: './profile-settings.component.html',
  styleUrls: ['./profile-settings.component.scss']
})
export class ProfileSettingsComponent implements OnInit {
  private isEdit: boolean;
  public channelTypeId: number;
  public channelId: number;
  public channeName: string;
  public isMyChannel: boolean;
  public otherOptions: string;
  error: boolean;
  submitting: boolean;
  submitBtnText: string;
  reqObject: any;
  // to store and view the form element
  public formElements: any;
  public paymentTypes = new Array();
  public paymentTerms = new Array();
  public currencyes = new Array();
  public sampleRequests = new Array();
  public shares = new Array();
  public subscriptionPlan: string;
  public userVisibilitys = new Array();
  public sourcingContact: Array<DefaultContact>;
  public sellingContact: Array<DefaultContact>;
  public contacts = new Array();
  public UserStatus: boolean;
  public profileSetting: any;
  public currency: number;
  public selectedItem = 0;
  public getElements: any;

  // error
  public errPaymentTypes: string;
  public msg_code_paymentTypes: string;
  public errCurrency: string;
  public msg_code_Currency: string;
  public errisMyChannel: string;
  public msg_code_isMyChannel: string;
  public errPaymentTerms: string;
  public msg_code_paymentTerms: string;
  public errVisibilitys: string;
  public msg_code_Visibilitys: string;
  public errSampleRequests: string;
  public msg_code_SampleRequests: string;
  public errSelectMyChannel: string;
  public msg_code_SelectMyChannel: string;

  // Form groups
  paymentOptions: FormGroup;
  accountSetting: FormGroup;
  accountPreffrence: FormGroup;

  public regImgView: any;
  public userImage = false;
  public userIcon = true;
  public isImageError = false;
  public profileImgErr: any;
  public profileImgClassBool: any;
  public loading = false;
  public profileImage: any;
  private folderName = 'profile-setting-s3/';

  public stripeVaue: string;
  public hideStripe = false;
  private stripeToken: any = {};
  public stripDashboard = false;
  public stripId: string;
  public channeltypeId: number = ChannelTypeIdEnum.VENDOR;
  public channelJTCId: number;
  public _UpdateChannelData: UpdateChannelData;
  public planId: number;
  contactType: any;

  constructor(
    private scrollService: ScrollToService,
    private toastr: ToastrService,
    private router: Router,
    public dialog: MatDialog,
    private _profileBusiness: ProfileBusiness,
    private uploadFileService: UploadFileService,
    private accountBusiness: AccountBusiness,
    private activatedRoute: ActivatedRoute, private authorizeService: AuthorizeService,
    private translate: TranslateService) {

    this.sourcingContact = new Array<DefaultContact>();
    this.sellingContact = new Array<DefaultContact>();
    if (localStorage.getItem(AppLocalStorageKeys.CHANNEL_NAME)) {
      this.channeName = localStorage.getItem(AppLocalStorageKeys.CHANNEL_NAME);
    }

    if (localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID)) {
      // tslint:disable-next-line:radix
      this.channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID));
    }

    if (localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID)) {
      // tslint:disable-next-line:radix
      this.channelId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID));
    }

    if (localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS)) {
      const statusDetail = localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS);
      this.planId = parseInt((<UserStatusDetails>JSON.parse(statusDetail)).planId, 10);
    } else {
      this.planId = 0;
    }

    this._getFormElements();
  }

  ngOnInit() {
    this.submitBtnText = this.isEdit ? 'Update' : 'Save';
    this._UpdateChannelData = new UpdateChannelData();
    this.channelJTCId = 1;
    this.stripeConncetion();
    this.tradeinfoGet();

    // Get the Stripe Id form Route value
    this.activatedRoute.queryParams.subscribe((params: Params) => {
      this.stripeToken = {
        code: params.code
      };
      // Post Stripe Connection
      if (this.stripeToken.code !== undefined) {
        this.accountBusiness.postStripeConnect(this.stripeToken).subscribe(res => {
          console.log(res);
          if (res.connected === 1) {
            this.hideStripe = true;
            this.stripDashboard = true;

          }
        });
      }
    });
  }


  tradeinfoGet() {
    this.loading = true;
    this.accountBusiness.getTradeinfo(true).subscribe(result => {

      const response = result as Response;
      if (response.ok) {
        const tradeInformationGet = <TradeInformationGet>response.json();
        // stripe Conncetion Get
        this.stripeVaue = tradeInformationGet.channel.channelDetail.stripeConnectId;
        if (!ValidationService.isNullOrEmpty(this.stripeVaue)) {
          this.stripDashboard = true;
          this.hideStripe = true;
        }

      }
      this.loading = false;
    },
      (error) => {
        console.log(error);
      });
  }

  // Get Stripe Connection Id
  stripeConncetion() {
    const stripeUrl = environment.Stripe_localURL;
    this.accountBusiness.getStripeConnect().subscribe(result => {
      this.stripId = result.connect_url + '&redirect_uri=' + stripeUrl + 'profile/(profileroute:setting)';
    },
      (error) => {
        console.log(error);
      });
  }

  private _getProfileSetting() {
    this._profileBusiness.getProfileSetting(true).subscribe(result => {
      const response = result as Response;
      if (response.status === 200) {
        this.getElements = (<any>response)._body;
        this.getElements = JSON.parse(this.getElements);

        if (this.getElements.paymentType.length) {
          for (let ii = 0; ii < this.getElements.paymentType.length; ii++) {
            for (let kk = 0; kk < this.paymentTypes.length; kk++) {
              if (this.getElements.paymentType[ii].paymentoptiontypeid === this.paymentTypes[kk].paymentoptiontypeid) {
                this.paymentTypes[kk].isChecked = true;
              }
            }
          }
        } else {
          for (let kk = 0; kk < this.paymentTypes.length; kk++) {
            this.paymentTypes[kk].isChecked = true;
          }
        }

        if (this.getElements.paymentTerms.length) {
          for (let ii = 0; ii < this.getElements.paymentTerms.length; ii++) {
            for (let kk = 0; kk < this.paymentTerms.length; kk++) {
              if (this.getElements.paymentTerms[ii].paymenttermid === this.paymentTerms[kk].paymenttermid) {
                this.paymentTerms[kk].isChecked = true;
              }
            }
          }
        } else {
          for (let kk = 0; kk < this.paymentTerms.length; kk++) {
            this.paymentTerms[kk].isChecked = true;
          }
        }

        if (this.channelTypeId === 2) {
          if (this.getElements.sampleRequests.length) {
            for (let ii = 0; ii < this.getElements.sampleRequests.length; ii++) {
              for (let kk = 0; kk < this.sampleRequests.length; kk++) {
                if (this.getElements.sampleRequests[ii].preferencetypeid === this.sampleRequests[kk].preferencetypeid) {
                  this.sampleRequests[kk].isChecked = true;
                }
              }
            }
          } else {
            for (let kk = 0; kk < this.sampleRequests.length; kk++) {
              if (this.sampleRequests[kk].preferencetypeid === 1) {
                this.sampleRequests[kk].isChecked = true;
              }
            }
          }
        }
        if (this.getElements.shareStatus) {
          this.isMyChannel = true;
        } else {
          this.isMyChannel = false;
        }

        if (this.getElements.share.length) {
          for (let ii = 0; ii < this.getElements.share.length; ii++) {
            for (let kk = 0; kk < this.shares.length; kk++) {
              if (this.getElements.share[ii].sharetypeid === this.shares[kk].sharetypeid) {
                this.shares[kk].isChecked = true;
              }
            }
          }
        } else {
          // this.isMyChannel = true;
          for (let kk = 0; kk < this.shares.length; kk++) {
            this.shares[kk].isChecked = true;
          }
        }
        // if (this.getElements.userVisibility.length) {
        //   for (let ii = 0; ii < this.getElements.userVisibility.length; ii++) {
        //     for (let kk = 0; kk < this.userVisibilitys.length; kk++) {
        //       if (this.getElements.userVisibility[ii].uservisibilitytypeid === this.userVisibilitys[kk].uservisibilitytypeid) {
        //         this.userVisibilitys[kk].isChecked = true;
        //       }
        //     }
        //   }
        // } else {
        //   for (let kk = 0; kk < this.userVisibilitys.length; kk++) {
        //     const visiblityId = this.userVisibilitys[kk].uservisibilitytypeid;
        //     if (visiblityId === 3 || visiblityId === 5 || visiblityId === 8) {
        //       this.userVisibilitys[kk].isChecked = true;
        //     }
        //   }
        // }

        if (this.getElements.currencyId) {
          // tslint:disable-next-line:radix
          this.selectedItem = parseInt(this.getElements.currencyId);
          // tslint:disable-next-line:radix
          this.currency = parseInt(this.getElements.currencyId);
        } else {
          this.selectedItem = 2;
          this.currency = 2;
        }

        if (this.getElements.otherOptions) {
          this.otherOptions = this.getElements.otherOptions;
        }

        if (this.getElements.status) {
          this.UserStatus = this.getElements.status;
        }
      } else {
        console.error(response);
      }

    },
      (error) => {
        console.log(error);
      });
  }

  private _getFormElements() {
    this._profileBusiness.getFromElementBusiness(true).subscribe(result => {
      const response = result as Response;
      if (response.status === 200) {
        this.formElements = (<any>response)._body;

        this.formElements = JSON.parse(this.formElements);
        this.paymentTypes = <Array<PaymentTypes>>(this.formElements.paymentType ? this.formElements.paymentType : []);
        this.paymentTerms = <Array<PaymentTerms>>(this.formElements.paymentTerms ? this.formElements.paymentTerms : []);
        this.currencyes = this.formElements.currency ? this.formElements.currency : [];
        if (this.channelTypeId === 2) {
          this.sampleRequests = <Array<SampleRequests>>(this.formElements.sampleRequests ? this.formElements.sampleRequests : []);
        }

        if (this.formElements.share) {
          if (this.channelTypeId === 2) {
            this.shares = <Array<AccountStauts>>(this.formElements.share.filter((item) => item.sharetype !== 'VENDOR'));
          } else if (this.channelTypeId === 5) {
            this.shares = <Array<AccountStauts>>(this.formElements.share.filter((item) => item.sharetype !== 'SALESREP'));
          } else if (this.channelTypeId === 4) {
            // this.shares = <Array<accountStauts>>(this.formElements.share.filter((item) => {
            //   if (item.sharetype === 'RETAILER' || item.sharetype === 'SALESREP') {
            //     return false;
            //   }
            // }));
            this.shares = <Array<AccountStauts>>(this.formElements.share.filter((item) => item.sharetype !== 'RETAILER'));
            this.shares = <Array<AccountStauts>>(this.shares.filter((item) => item.sharetype !== 'SALESREP'));
          } else {
            this.shares = this.formElements.share;
          }
        }

        this.subscriptionPlan = this.formElements.subscriptionPlan ? this.formElements.subscriptionPlan : '';
        // this.userVisibilitys = <Array<UserVisiblity>>(this.formElements.userVisibility ? this.formElements.userVisibility : '');

        this.contacts = this.formElements.contact ? this.formElements.contact : '';
        this.sellingContact = this.formElements.sellingContact ? this.formElements.sellingContact : this.formElements.contact;
        this.sourcingContact = this.formElements.sourcingContact ? this.formElements.sourcingContact : this.formElements.contact;

        // if (this.formElements.contact.document) {
        //   this.regImgView = this.formElements.contact.document.documentUrl ? this.formElements.contact.document.documentUrl : '';
        //   if (this.regImgView !== '') {
        //     this.userImage = true;
        //     this.userIcon = false;
        //   }
        // }

        this.UserStatus = this.formElements.status ? this.formElements.status : '';
        this._getProfileSetting();
      } else {
        console.error(response);
      }
    },
      (error) => {
        console.log(error);
      });
  }

  onpaymentTypesChanged(paymentType: string) {
    if (this.paymentTypes.find(item => item.paymenttype === paymentType).isChecked) {
      this.paymentTypes.find(item => item.paymenttype === paymentType).isChecked = false;
    } else {
      this.paymentTypes.find(item => item.paymenttype === paymentType).isChecked = true;
    }
    this.errPaymentTypes = '';
    this.msg_code_paymentTypes = '';
  }

  onpaymentTermChanged(paymentTerm: string) {
    if (this.paymentTerms.find(item => item.paymentterm === paymentTerm).isChecked) {
      this.paymentTerms.find(item => item.paymentterm === paymentTerm).isChecked = false;
    } else {
      this.paymentTerms.find(item => item.paymentterm === paymentTerm).isChecked = true;
    }
    this.errPaymentTerms = '';
    this.msg_code_paymentTerms = '';
  }

  onuserVisibilitysChanged(userVisibility: any) {
    // userVisibility.isChecked = !userVisibility.isChecked;
    // console.log(userVisibility.isChecked);
    // userVisibility.isChecked = true;
    this.userVisibilitys.forEach(result => {
      if (result.uservisibilitytypeid === userVisibility.uservisibilitytypeid) {
        result.isChecked = true;
      } else {
        result.isChecked = false;
      }
    });

    this.errVisibilitys = '';
    this.msg_code_Visibilitys = '';
  }

  onsharesChanged(sharetypeId: string) {
    if (this.shares.find(item => item.sharetypeid === sharetypeId).isChecked) {
      this.shares.find(item => item.sharetypeid === sharetypeId).isChecked = false;
    } else {
      this.shares.find(item => item.sharetypeid === sharetypeId).isChecked = true;
    }
    this.errSelectMyChannel = '';
    this.msg_code_SelectMyChannel = '';
  }

  onsampleRequestChanged(preferencetypeId: number) {
    // if (this.sampleRequests.find(item => item.preferencetypeid === preferencetypeId).isChecked) {
    //   this.sampleRequests.find(item => item.preferencetypeid === preferencetypeId).isChecked = false;
    // } else {
    //   this.sampleRequests.find(item => item.preferencetypeid === preferencetypeId).isChecked = true;
    // }

    this.sampleRequests.forEach(result => {
      if (result.preferencetypeid === preferencetypeId) {
        result.isChecked = true;
      } else {
        result.isChecked = false;
      }
      /*if (result.preferencetype === '3') {

      }*/
    });

  }

  onOpntionSelect(item: any): void {
    // tslint:disable-next-line:radix
    if (item.target.value && parseInt(item.target.value) > 0) {
      // tslint:disable-next-line:radix
      this.currency = parseInt(item.target.value);
      this.errCurrency = '';
      this.msg_code_Currency = '';
    } else {
      this.currency = 0;
    }
  }

  public _ismychannel(event) {
    this.isMyChannel = event.target.value === 'yes' ? true : false;
    this.errisMyChannel = '';
    this.msg_code_isMyChannel = '';
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.PROFILE_COMPANY_SETTINGS_UPDATE);
      if (!hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  public async profileSettingSave() {
    if (!this.authorizeBeforeSubmit()) {
      return;
    }

    this.loading = true;
    try {
      const postObject: IProfileSettingSave = <IProfileSettingSave>{};

      if (this.otherOptions !== undefined && this.otherOptions !== '') {
        postObject.otherOptions = this.otherOptions;
      }

      if (this.currency) {
        postObject.currencyId = this.currency;
        this.errCurrency = '';
        this.msg_code_Currency = '';
      } else {
        this.errCurrency = 'currency';
        this.msg_code_Currency = '0017';
        this.scrollService.scrollTo(document.getElementById('selectCurrencyId'), 1000, -100);
        this.loading = false;
        return;
      }

      if (this.isMyChannel !== undefined) {
        postObject.shareStatus = this.isMyChannel;
        if (this.isMyChannel) {
          const tmpList = <Array<AccountStauts>>[];

          for (let ii = 0; ii < this.shares.length; ii++) {
            if (this.shares[ii].isChecked) {
              const reqObject = <AccountStauts>{};
              // tslint:disable-next-line:radix
              reqObject.sharetypeid = parseInt(this.shares[ii].sharetypeid);
              tmpList.push(reqObject);
            }
          }
          if (tmpList.length > 0) {
            postObject.share = tmpList;
            this.errSelectMyChannel = '';
            this.msg_code_SelectMyChannel = '';
          } else {
            this.errSelectMyChannel = 'SelectMyChannel';
            this.msg_code_SelectMyChannel = '0016';
            this.loading = false;
            this.scrollService.scrollTo(document.getElementById('isMyChannelId'), 1000, -100);
            return;
          }
        }
        this.errisMyChannel = '';
        this.msg_code_isMyChannel = '';
      } else {
        this.errisMyChannel = 'isMyChannel';
        this.msg_code_isMyChannel = '0016';
        this.loading = false;
        this.scrollService.scrollTo(document.getElementById('isMyChannelId'), 1000, -100);
        return;
      }

      const tmppaymentTypes = <Array<PaymentTypes>>[];
      for (let ii = 0; ii < this.paymentTypes.length; ii++) {
        if (this.paymentTypes[ii].isChecked) {
          const reqObject = <PaymentTypes>{};
          // tslint:disable-next-line:radix
          reqObject.paymentoptiontypeid = parseInt(this.paymentTypes[ii].paymentoptiontypeid);
          tmppaymentTypes.push(reqObject);
        }
      }

      if (tmppaymentTypes.length > 0) {
        postObject.paymentType = tmppaymentTypes;
        this.errPaymentTypes = '';
        this.msg_code_paymentTypes = '';
      } else {
        this.errPaymentTypes = 'paymentType';
        this.msg_code_paymentTypes = '0014';
        this.loading = false;
        this.scrollService.scrollTo(document.getElementById('paymentTypeId'), 1000, -100);
        return;
      }

      const tmpPaymentTerms = <Array<PaymentTerms>>[];
      for (let ii = 0; ii < this.paymentTerms.length; ii++) {
        if (this.paymentTerms[ii].isChecked) {
          const reqObject = <PaymentTerms>{};
          // tslint:disable-next-line:radix
          reqObject.paymenttermid = parseInt(this.paymentTerms[ii].paymenttermid);
          tmpPaymentTerms.push(reqObject);
        }
      }

      if (tmpPaymentTerms.length > 0) {
        postObject.paymentTerms = tmpPaymentTerms;
        this.errPaymentTerms = '';
        this.msg_code_paymentTerms = '';
      } else {
        this.errPaymentTerms = 'errpaymentTream';
        this.msg_code_paymentTerms = '0015';
        this.loading = false;
        this.scrollService.scrollTo(document.getElementById('paymentTermsId'), 1000, -100);
        return;
      }
      // const tmpUserVisibilitys = new UserVisiblity();
      // for (let ii = 0; ii < this.userVisibilitys.length; ii++) {
      //   if (this.userVisibilitys[ii].isChecked) {
      //     // tslint:disable-next-line:radix
      //     this.reqObject = parseInt(this.userVisibilitys[ii].uservisibilitytypeid);
      //     tmpUserVisibilitys.uservisibilitytypeid = this.reqObject;

      //   }
      // }

      // postObject.userVisibility = new Array<UservisibilityType>();
      // if (tmpUserVisibilitys.uservisibilitytypeid !== 0) {
      //   postObject.userVisibility.push({
      //     uservisibilitytypeid: tmpUserVisibilitys.uservisibilitytypeid
      //   });
      //   this.errVisibilitys = '';
      //   this.msg_code_Visibilitys = '';
      // } else {
      //   this.errVisibilitys = 'Visibilitys';
      //   this.msg_code_Visibilitys = '0018';
      //   this.loading = false;
      //   this.scrollService.scrollTo(document.getElementById('accountSettingUserId'), 1000, -100);
      //   return;
      // }
      if (this.channelTypeId === 2) {
        const tmpSampleRequests = new SampleRequests();
        for (let ii = 0; ii < this.sampleRequests.length; ii++) {
          if (this.sampleRequests[ii].isChecked) {
            // const reqObject = <SampleRequests>{};
            // tslint:disable-next-line:radix
            this.reqObject = parseInt(this.sampleRequests[ii].preferencetypeid);
            tmpSampleRequests.preferencetypeid = this.reqObject;
          }
        }
        postObject.sampleRequests = new Array<SampleRequestsPost>();
        if (tmpSampleRequests.preferencetypeid !== 0) {
          postObject.sampleRequests.push({
            preferencetypeid: tmpSampleRequests.preferencetypeid
          });

          this.errSampleRequests = '';
          this.msg_code_SampleRequests = '';
        } else {
          this.errSampleRequests = 'SampleRequests';
          this.msg_code_SampleRequests = '0019';
          this.loading = false;
          return;
        }
      }

      postObject.channelType = this.channelTypeId;
      this.loading = true;
      this._profileBusiness.putProfileSetting(postObject, true).subscribe(result => {
        const response = result as Response;
        if (response.ok) {
          console.log('user-currency', this.currency.toString());
          localStorage.setItem('user-currency', this.currency.toString());
          this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
          this.toastr.success(this.translate.instant('userManagement.toastrMsg.profileSetting'));
        } else {
          this.toastr.error(this.translate.instant('userManagement.toastrMsg.errorMsg'));
          console.error(response);
        }
      }, (error) => {
        console.log(error);
      });
      this.loading = false;
    } catch (error) {
      this.loading = false;
      console.log('Error on save :' + error);
    }
  }

  async selectFile(event, urlLink) {

    const selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    // console.log(event.target.files[0]);
    if (file) {
      const fileName = file.name;
      let fileExtension = fileName.substr((fileName.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString().toLowerCase();
      if (fileExtension === 'jpeg' || fileExtension === 'jpg') {
        this.loading = true;
        const resImagePath: any = await this.uploadFileService.uploadfile(file, this.folderName);
        this.profileImage = resImagePath.key;
        if (this.profileImage) {
          this.profileImgClassBool = 1;
          this.profileImgErr = this.translate.instant('commonError.imageSucess');
          this.isImageError = true;
          this.loading = false;
          this.userImage = true;
          this.userIcon = false;
          const reader = new FileReader();
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            this.regImgView = event.target.result;
          };
          reader.readAsDataURL(event.target.files[0]);
        } else {
          this.profileImgClassBool = 0;
          this.isImageError = false;
          this.userImage = false;
          this.userIcon = true;
          this.profileImgErr = this.translate.instant('commonError.imageuploadError');
          this.loading = false;
        }
      } else {
        this.isImageError = false;
        this.userImage = false;
        this.userIcon = true;
        this.profileImgErr = this.translate.instant('commonError.validImage');
      }
    }
  }

  opendailog(contactType = null) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'shared.buttonLabels.sellContacts',
        type: 2,
        message: '',
        list: [],
        id: 17,
        channelId: this.channelId,
        jtcChannelId: 0,
        contactType: contactType,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this.changeAsDefault(responseType.contactId, contactType);
      }
    });
  }

  changeAsDefault(contactId, contactType) {
    localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'false');
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'CommonUsageLabel.defaultContact',
        type: 2,
        message: 'CommonUsageLabel.defaultcontactAdd',
        list: [],
        id: 15,
        channelId: 0,
        jtcChannelId: 0,
        contactType: contactType,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      localStorage.setItem(AppLocalStorageKeys.CONTACT_POPUP_FLAG, 'true');
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        const data = { 'contactType': responseType.contactType };
        this._profileBusiness.updateChannel(contactId, data, true).subscribe(response => {
          if (response.ok) {
            // console.log(response.json());
            const contactDetailInfo = response.json();
            if (responseType.contactType === 'SELLING') {
              this.sellingContact = contactDetailInfo;
            } else if (responseType.contactType === 'SOURCING') {
              this.sourcingContact = contactDetailInfo;
            } else {
              this.contacts = contactDetailInfo;
            }
            // this.regImgView = contactDetailInfo.document.documentUrl;
            // this.contacts['firstName'] = contactDetailInfo.firstName;
            // this.contacts['lastName'] = contactDetailInfo.lastName;
            // this.contacts['jobTitle'] = contactDetailInfo.firstName;
            // this.contacts['country']['country'] = contactDetailInfo.countryId;
          }
        });
      }
    });
  }

  upgradeFunction() {
    localStorage.setItem('RedirectId', '7');
    this.router.navigate(['/user/subscriptionplan']);
  }
}
