import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import * as io from 'socket.io-client';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import Socket = SocketIOClient.Socket;

@Injectable()
export class NotificatoinService {

  private Environment = environment;
  public socket: Socket;

  constructor(private _http: Http) { }

  public connectSocket(): Socket {
    // tslint:disable-next-line:max-line-length
    this.socket = io(`${this.Environment.SOCKET_ENDPOINT}`, { query: 'accessToken=' + localStorage.getItem(AppLocalStorageKeys.AUTH_Token) });
    return this.socket;
  }

  public joinInRoom(room) {
    this.socket.emit('join', { email: room });

    this.socket.on('reconnect', () => {
      this.socket.emit('join', { email: room });
    });
  }

  public getSocketInstance() {
    return this.socket;
  }

  public disconnet() {
    if (this.socket && this.socket.connected) {
      return this.socket.disconnect();
    } else {
      return true;
    }
  }

  public onMessage(room, socket): Observable<any> {
    return new Observable<any>(observer => {
      socket.on(room, (data: any) => { console.log('message', data); observer.next(data); });
      socket.on('WELCOME', (data: any) => { console.log('message', data); observer.next(data); });
      // this.socket.on('Mymessage', (data: any) => {        console.log('Mymessage', data);        observer.next(data);      });
    });
  }

  public onEvent(event: any): Observable<any> {
    return new Observable<Event>(observer => {
      this.socket.on('event', (data: any) => { console.log('event', data); observer.next(); });
    });
  }
}
