import { TestBed, inject } from '@angular/core/testing';

import { CodeDataTransferService } from './code-data-transfer.service';

describe('CodeDataTransferService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CodeDataTransferService]
    });
  });

  it('should be created', inject([CodeDataTransferService], (service: CodeDataTransferService) => {
    expect(service).toBeTruthy();
  }));
});
