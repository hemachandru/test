import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class CodeDataTransferService {

  private socketConnection = new BehaviorSubject<string>('');
  currentSocketConnection = this.socketConnection.asObservable();

  private notificationReviced = new BehaviorSubject<string>('');
  currentnotificationReviced = this.notificationReviced.asObservable();

  private notificationRead = new BehaviorSubject<string>('');
  currentNotificationRead = this.notificationRead.asObservable();

  private newNotification = new BehaviorSubject<string>('');
  currentNewNotification = this.newNotification.asObservable();

  private logingNotification = new BehaviorSubject<string>('');
  currentLogingNotification = this.logingNotification.asObservable();

  constructor() { }

  changeSocketConnection(message: string) {
    this.socketConnection.next(message);
  }

  changeNotificationReviced(message: string) {
    this.notificationReviced.next(message);
  }

  changeNotificationRead(message: string) {
    this.notificationRead.next(message);
  }

  changeNewNotification(message: string) {
    this.newNotification.next(message);
  }

  changeLogingNotification(message: string) {
    this.logingNotification.next(message);
  }

}
