import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpRequestService } from '../../shared/shared-HTTP-service';
import { IRequestOptions } from './Interface/IRequestOptions';
import { Observable } from 'rxjs/Observable';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';


@Injectable()
export class CoreService {
  private apiUrl = ApiUrl;
  private _option = <IRequestOptions> {};
  constructor(private _httpService: HttpRequestService) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  getNotificationCount(): Observable<any> {
    const url = this.apiUrl.NOTIFICATION_UNREADCOUNT;
    return this._httpService.getHttpClientRequest(url, this._option);
  }
}
