import { SlimScrollModule } from 'ng2-slimscroll';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgProgressModule  } from 'ngx-progressbar';
import { MAT_DIALOG_DEFAULT_OPTIONS, MAT_DIALOG_DATA } from '@angular/material';
import { SharedModule } from './../shared/shared.module';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LeftMenuComponent } from './components/left-menu/left-menu.component';
import { TopMenuComponent } from './components/top-menu/top-menu.component';
import { AuthGuard, AnonymousGuard, RedirectGuard } from '../shared/shared-service/auth-guard.service';
import { SideMenuComponent } from './components/side-menu/side-menu.component';
import { MenuItemsComponent } from './components/menu-items/menu-items.component';
// import { Logger } from './service/logger.service';
import { CoreService } from './service/core.service';
import { NotificatoinService } from './service/notificatoin-service';
import { CodeDataTransferService } from './service/code-data-transfer.service';
import { RouterModule } from '@angular/router';
import {NgcCookieConsentModule} from 'ngx-cookieconsent';

export const COMPONENTS = [
  HeaderComponent,
  FooterComponent,
  TopMenuComponent,
  LeftMenuComponent,
  SideMenuComponent,
  MenuItemsComponent,
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    NgProgressModule,
    SlimScrollModule,
    RouterModule,
    NgcCookieConsentModule
  ],
  declarations: [
    HeaderComponent,
    FooterComponent,
    TopMenuComponent,
    LeftMenuComponent,
    SideMenuComponent,
    MenuItemsComponent
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
    TopMenuComponent,
    LeftMenuComponent,
    SideMenuComponent,
    RouterModule,
    MenuItemsComponent],

  providers: [CoreService, NotificatoinService, CodeDataTransferService,
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: true, closeOnNavigation: true } },
    { provide: MAT_DIALOG_DATA, useValue: {} }
  ],
  entryComponents: []
})
export class CoreModule {
  static forRoot() {
    return {
      ngModule: CoreModule,
      providers: [
        AuthGuard,
        AnonymousGuard,
        RedirectGuard
      ],
    };
  }
}
