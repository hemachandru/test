import { Observable } from 'rxjs/Observable';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserAccountStatus } from '@app/config/constant';
import { Router, NavigationEnd, ActivatedRoute, } from '@angular/router';

import { HomeBusiness } from '../../../home/business/home.business';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { ApiUrl, AppLocalStorageKeys, WebUrl, PageTitles } from '@app/config/constant_keys';
import { UserDetailService } from '@app/shared/shared-service/user-detail.service';
import { UserDetailMessage } from '@app/config/constant';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { Title } from '@angular/platform-browser';
import { NotificatoinService } from '../../service/notificatoin-service';
import { CodeDataTransferService } from '../../service/code-data-transfer.service';
import Socket = SocketIOClient.Socket;
import { SharedService } from '@app/shared/shared-service/shared-service';
import { AppTokenService } from '@app/shared/shared-service/app-token-service';
import { LocationStrategy } from '@angular/common';
import { NgcCookieConsentService, NgcInitializeEvent, NgcStatusChangeEvent } from 'ngx-cookieconsent';
import { Subscription } from 'rxjs/Subscription';
import { Contact } from '@app/shared/models/contact';
import { TranslateService } from '@ngx-translate/core';
import { BreadcrumbService } from '@app/breadcrumb/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit, OnDestroy {
  public webUrl = WebUrl;
  isPopState = false;
  isLoggedIn$: Observable<boolean>;
  menuopen: any;
  public activeURL: string;
  public checklandURLBool: boolean;
  public isTokenExists: boolean;
  public userChannelStatus: number;
  public isSubscriptedUser: any = false;
  public isAccountSetup: boolean;
  public isCmsFlagUser: any = false;
  public loginIdExists: any;
  public loginNameExists: any;
  private isLoginStateUpdated: boolean;
  private isLogoutStateUpdated: boolean;
  public loading = false;
  public srcCompanyLogo: string;
  public srcCompanyFavicon: string;
  public srcProfileLogo: string;
  public jobTitle: string;
  private apiUrl = ApiUrl;
  channelType: string;
  private socket: Socket;
  public userNameUpdate: string;

  // keep refs to subscriptions to be able to unsubscribe later
  private popupOpenSubscription: Subscription;
  private popupCloseSubscription: Subscription;
  private initializeSubscription: Subscription;
  private statusChangeSubscription: Subscription;
  private revokeChoiceSubscription: Subscription;
  navigationSubscription: any;
  isUserApproved: boolean;

  constructor(private userSubscriptionBusiness: UserSubscriptionBusiness,
    private _homeBusiness: HomeBusiness,
    private route: ActivatedRoute,
    private router: Router,
    private userDetailService: UserDetailService,
    private notificatoinService: NotificatoinService,
    private codeDataTransferService: CodeDataTransferService,
    private data: AccountDataService,
    private titleService: Title,
    private sharedService: SharedService,
    private appTokenService: AppTokenService,
    private locStrat: LocationStrategy,
    private ccService: NgcCookieConsentService,
    private translate: TranslateService,
    public breadcrumbService: BreadcrumbService,
    public localStorageService: LocalStorageService
  ) {
    // this.localStorageService.bindObject();
    this.isLoginStateUpdated = false;
    this.isLogoutStateUpdated = false;

    this.locStrat.onPopState(() => {
      this.isPopState = true;
    });

    this.navigationSubscription = this.router.events.subscribe(event => {
      // Scroll to top if accessing a page, not via browser history stack
      if (event instanceof NavigationEnd && !this.isPopState) {
        window.scrollTo(0, 0);
        this.isPopState = false;
      }

      // Ensures that isPopState is reset
      if (event instanceof NavigationEnd) {
        this.isPopState = false;
      }
      const authToken = AppLocalStorageKeys.AUTH_Token;
      const subContactId = AppLocalStorageKeys.SUBSCRIPTION_CONTACTID;
      if (event instanceof NavigationEnd) {
        this.loginNameExists = '';
        this.isTokenExists = localStorage.getItem(authToken) !== null && localStorage.getItem(authToken) !== '' ? true : false;
        const username = localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO);
        const loginNameExistsBool = localStorage.getItem(subContactId) !== null && localStorage.getItem(subContactId) !== '' ? true : false;
        this.userChannelStatus = parseInt(localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS), 10);
        if (loginNameExistsBool === true && (username === '' || username == null)) {
          // tslint:disable-next-line:triple-equals
          if (this.userChannelStatus == 15) {
            this.isUserApproved = true;
          }
          this.loginIdExists = true;
          const result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
          let contactId: number;
          contactId = parseInt(result, 10);
          if (!ValidationService.isNullOrEmpty(contactId)) {
            this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
              localStorage.setItem(AppLocalStorageKeys.CONTACT_INFO, JSON.stringify(response));
              this.loginNameExists = response.firstName + ' ' + response.lastName;
              this.jobTitle = !ValidationService.isNullOrEmpty(response.jobTitle) ? response.jobTitle : '';
              this.srcProfileLogo = !ValidationService.isNullOrEmpty(response.imageUrl) ? response.imageUrl : '';
            },
              (error) => {
                console.log(error);
              });
          } else {
            this.localStorageService.clearAllDataExceptAppToken();
            // this.router.navigate([this.webUrl.LOGIN]);
          }
        } else {
          this.loginIdExists = false;
          // tslint:disable-next-line:triple-equals
          if (username != null) {
            if (this.userChannelStatus == 15) {
              this.isUserApproved = true;
            }
            const contactInfo = JSON.parse(localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO)) as Contact;
            this.loginIdExists = true;
            this.loginNameExists = contactInfo.firstName + ' ' + contactInfo.lastName;
            this.jobTitle = !ValidationService.isNullOrEmpty(contactInfo.jobTitle) ? contactInfo.jobTitle : '';
            this.srcProfileLogo = !ValidationService.isNullOrEmpty(contactInfo.imageUrl) ? contactInfo.imageUrl : '';
          }
        }

        const userStatusdetail: any = JSON.parse(localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS));
        this.activeURL = event.url;

        if (this.userChannelStatus === UserAccountStatus.CHANNEL_APPROVED && localStorage.getItem(AppLocalStorageKeys.AUTH_Token)
          && (userStatusdetail.planId != null) && (userStatusdetail.subscriptionId != null)) {
          this.isSubscriptedUser = true;
        } else {
          this.isSubscriptedUser = false;
        }

        if ((this.userChannelStatus === UserAccountStatus.ACCOUNTSETUP ||
          this.userChannelStatus === UserAccountStatus.ACCOUNTSETUP_COMPANYPROFILE
          || this.userChannelStatus === UserAccountStatus.ACCOUNTSETUP_TRADELOCATION
          || this.userChannelStatus === UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION)
          && localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
          this.isAccountSetup = true;
        } else {
          this.isAccountSetup = false;
        }

        if (localStorage.getItem('static_page_access')) {
          this.isCmsFlagUser = true;
        } else {
          this.isCmsFlagUser = false;
        }

        if (this.activeURL === this.webUrl.LOGIN || this.activeURL === this.webUrl.SIGNUP) {
          this.checklandURLBool = true;
        } else {
          this.checklandURLBool = false;
        }

        // Page title handlinh globally
        const pageTitle = PageTitles.filter(pg => pg.path === this.activeURL);
        const appTitle = 'Channel Hub';
        if (pageTitle && pageTitle.length > 0 && pageTitle[0]['title'] !== '') {
          this.titleService.setTitle(appTitle + ' - ' + pageTitle[0]['title']);
        } else {
          this.titleService.setTitle(appTitle);
        }

      }
    });
    this.sharedService.invokeEvent.subscribe(value => {
      if (value === 'MenuOpen') {
        this.MenuOpen(this.menuopen);
      } else if (value === 'Open') {
        this.menuopen = true;
      }
    });

    // Hide breadcrumb for pages
    breadcrumbService.hideRoute('/user/transaction');
    breadcrumbService.hideRoute('/user/subscriptionplan');
    breadcrumbService.hideRoute('/account');
    breadcrumbService.hideRouteRegex('/account/*');

    // static pages
    breadcrumbService.hideRoute('/dashboard');
    breadcrumbService.addFriendlyNameForRoute('/notification', 'My Notification');
    breadcrumbService.addFriendlyNameForRoute('/user_profile_selection', 'User Profile Selection');

    // Cart page
    breadcrumbService.addFriendlyNameForRoute('/cart', 'My Cart');
    breadcrumbService.hideRoute('/cart/productview');
    breadcrumbService.addCallbackForRouteRegex('^/cart/productview/[SKU0-9]*$', this.getProductNameForSku);

    // Checkout page
    breadcrumbService.addFriendlyNameForRoute('/cart/checkout', 'Checkout');

    // Wishlist page
    breadcrumbService.addFriendlyNameForRoute('/wishlist', 'My Wishlist');
    breadcrumbService.hideRoute('/wishlist/productview');
    breadcrumbService.addCallbackForRouteRegex('^/wishlist/productview/[SKU0-9]*$', this.getProductNameForSku);
    breadcrumbService.hideRouteRegex('^/wishlist/productview/[SKU0-9]*/rating$');
    breadcrumbService.addFriendlyNameForRouteRegex('^/wishlist/productview/[SKU0-9]*/rating/[0-9]*$', 'Rating detail view');

    // Public profile
    breadcrumbService.addFriendlyNameForRoute('/public-profile', 'My Public Profile');
    // Profile
    breadcrumbService.hideRoute('/profile');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:myprofile)', 'My Profile');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:companyprofile)', 'Company Profile');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:tradeinformation)', 'Trade Information');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:tradelocation)', 'Trade Location');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:usermanagement)', 'User Management');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:setting)', 'Settings');
    breadcrumbService.addFriendlyNameForRoute('/profile/(profileroute:newuser)', 'User Management');

    // My suggestion
    breadcrumbService.hideRoute('/channel');
    breadcrumbService.hideRoute('/channel/suggestions/channelView');
    breadcrumbService.addFriendlyNameForRoute('/channel/suggestions', 'My Suggestion');
    breadcrumbService.addCallbackForRouteRegex('^/channel/suggestions/channelView/[0-9]*$', this.getChannelNameForId);
    breadcrumbService.addFriendlyNameForRouteRegex('^/channel/suggestions/*', 'My Suggestion');

    // My Prospects
    breadcrumbService.hideRoute('/channel/myprospects/channelView');
    breadcrumbService.addFriendlyNameForRoute('/channel/myprospects', 'My Network');
    breadcrumbService.addCallbackForRouteRegex('^/channel/myprospects/channelView/[0-9]*$', this.getChannelNameForId);
    // breadcrumbService.addFriendlyNameForRouteRegex('^/channel/myprospects/*', 'My Prospects');
    breadcrumbService.hideRoute('/channel/myprospects/approvals/channelView');
    breadcrumbService.addFriendlyNameForRoute('/channel/myprospects/approvals', 'My Pending Connections');
    breadcrumbService.addCallbackForRouteRegex('^/channel/myprospects/approvals/channelView/[0-9]*$', this.getChannelNameForId);

    // breadcrumbService.hideRoute('/channel/approvals/channelView');
    // breadcrumbService.addFriendlyNameForRoute('/channel/approvals', 'My Approvals');
    // breadcrumbService.addCallbackForRouteRegex('^/channel/approvals/channelView/[0-9]*$', this.getChannelNameForId);
    // breadcrumbService.addFriendlyNameForRouteRegex('^/channel/approvals/*', 'My Approvals');

    // My channels
    breadcrumbService.hideRoute('/channel/mychannels/channelView');
    breadcrumbService.addFriendlyNameForRoute('/channel/mychannels', 'My Channels');
    breadcrumbService.addCallbackForRouteRegex('^/channel/mychannels/channelView/[0-9]*$', this.getChannelNameForId);
    // breadcrumbService.addFriendlyNameForRouteRegex('^/channel/mychannels/*', 'My Channels');
    breadcrumbService.hideRoute('/channel/mychannels/approvals/channelView');
    breadcrumbService.addFriendlyNameForRoute('/channel/mychannels/approvals', 'My Channels approvals');
    breadcrumbService.addCallbackForRouteRegex('^/channel/mychannels/approvals/channelView/[0-9]*$', this.getChannelNameForId);
    breadcrumbService.addFriendlyNameForRoute('/channel/mychannels/invitations', 'Invitations');

    // morelist
    breadcrumbService.hideRoute('/channel/morelist/channelView');
    breadcrumbService.addCallbackForRouteRegex('^/channel/morelist/channelView/[0-9]*$', this.getChannelNameForId);
    // morelist Previous & Next
    breadcrumbService.hideRoute('/channel/morelist/channelview');
    breadcrumbService.addCallbackForRouteRegex('^/channel/morelist/channelview/[0-9]*$', this.getChannelNameForId);
    breadcrumbService.addFriendlyNameForRouteRegex('^/channel/morelist/*', 'More matching items');

    breadcrumbService.broswerBackRouteRegex('^/channel/morelist/channelview/[0-9]*$');

    breadcrumbService.broswerBackRouteRegex('^/channel/morelist/channelView/[0-9]*$');
    breadcrumbService.broswerBackRouteRegex('^/product/morelist/productview/[SKU0-9]*$');

    breadcrumbService.addFriendlyNameForRouteRegex('^/product/morelist/*', 'More matching items');
    // breadcrumbService.addFriendlyNameForRoute('product/morelist', 'More matching items');
    breadcrumbService.hideRoute('/product/morelist/productview');
    breadcrumbService.addCallbackForRouteRegex('^/product/morelist/productview/[SKU0-9]*$', this.getProductNameForSku);

    // Search results
    breadcrumbService.hideRoute('/searchResult/channelView');
    breadcrumbService.hideRoute('/searchResult/productview');
    breadcrumbService.hideRoute('/searchResult/product');
    breadcrumbService.addFriendlyNameForRoute('/searchResult', 'Search');
    breadcrumbService.addCallbackForRouteRegex('^/searchResult/channelView/[0-9]*$', this.getChannelNameForId);
    breadcrumbService.addCallbackForRouteRegex('^/searchResult/productview/[SKU0-9]*$', this.getProductNameForSku);
    breadcrumbService.addFriendlyNameForRouteRegex('^/searchResult/*', 'Search');

    // My product suggestion
    breadcrumbService.hideRoute('/product');
    breadcrumbService.addFriendlyNameForRoute('/product/suggestions', 'Product Suggestion');
    breadcrumbService.hideRoute('/product/suggestions/productview');
    breadcrumbService.addCallbackForRouteRegex('^/product/suggestions/productview/[SKU0-9]*$', this.getProductNameForSku);

    // My product suggestion rating
    breadcrumbService.hideRouteRegex('^/product/suggestions/productview/[SKU0-9]*/rating$');
    breadcrumbService.addFriendlyNameForRouteRegex('^/product/suggestions/productview/[SKU0-9]*/rating/[0-9]*$', 'Rating detail view');

    // Product previous & next
    breadcrumbService.hideRoute('/product/suggestions/productView');
    breadcrumbService.addCallbackForRouteRegex('^/product/suggestions/productView/[SKU0-9]*$', this.getProductNameForSku);

    // My product suggestion rating previous & next
    breadcrumbService.hideRouteRegex('^/product/suggestions/productView/[SKU0-9]*/rating$');
    breadcrumbService.addFriendlyNameForRouteRegex('^/product/suggestions/productView/[SKU0-9]*/rating/[0-9]*$', 'Rating detail view');
    // My products
    breadcrumbService.hideRoute('/productview');
    breadcrumbService.addCallbackForRouteRegex('^/productlist/productview/[SKU0-9]*$', this.getProductNameForSku);

    // My product suggestion rating
    breadcrumbService.hideRouteRegex('^/product/productview/[SKU0-9]*/rating$');
    breadcrumbService.addFriendlyNameForRouteRegex('^/product/productview/[SKU0-9]*/rating/[0-9]*$', 'Rating detail view');

    // breadcrumbService.hideRoute('/channel');
    breadcrumbService.hideRoute('/productlist/productview');
    breadcrumbService.addFriendlyNameForRoute('/productlist', 'Products');

    breadcrumbService.addFriendlyNameForRouteRegex('^/productlist/productmanage/*', 'Product Manage');

    // Static cms pages
    breadcrumbService.hideRoute('/help');
    breadcrumbService.addFriendlyNameForRoute('/help/support', 'Support');
    breadcrumbService.addFriendlyNameForRoute('/help/tutorials', 'Tutorials');
    breadcrumbService.addFriendlyNameForRoute('/help/complaint', 'Complaint');
    breadcrumbService.addFriendlyNameForRoute('/help/ipr', 'IPR');

    // sample order page
    breadcrumbService.hideRoute('/order');
    // breadcrumbService.addFriendlyNameForRoute('/order', 'Sampe Orders');
    this.channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
    if (this.channelType === 'DISTRIBUTOR') {
      breadcrumbService.addFriendlyNameForRoute('/order/buyerrequest', 'Your orders');
      breadcrumbService.addFriendlyNameForRoute('/order/sellerrequest', 'Received Orders');
    } else {
      breadcrumbService.addFriendlyNameForRoute('/order/buyerrequest', 'Sample order Request');
      breadcrumbService.addFriendlyNameForRoute('/order/sellerrequest', 'Sample order');
    }
    breadcrumbService.hideRoute('/order/buyerrequest/productview');
    breadcrumbService.addCallbackForRouteRegex('^/order/buyerrequest/productview/[SKU0-9]*$', this.getProductNameForSku);

    // Hide breadcrumb for coming soon pages
    breadcrumbService.hideRouteRegex('/coming-soon/*');

    // Hide breadcrumb transaction page
    breadcrumbService.hideRoute('/user/transaction');
    breadcrumbService.hideRoute('/user');

    // Channel view page from product view page
    breadcrumbService.hideRoute('/channel/channelView');
    breadcrumbService.addCallbackForRouteRegex('^/channel/channelView/[0-9]*$', this.getChannelNameForId);

    // Manage and import product
    breadcrumbService.addFriendlyNameForRoute('/productlist/productmanage', 'Manage Products');
    breadcrumbService.addFriendlyNameForRoute('/productlist/productimport', 'Import Product');

    // My Invitations
    breadcrumbService.addFriendlyNameForRoute('/channel/invitations', 'My Invitations');
  }

  ngOnInit() {
    this.loading = true;
    // this.getAuthrozationCode();
    this.data.currentImageUrl.subscribe(data => this.onCurrentImageUrl(data));
    this.data.currentFaviconUrl.subscribe(data => this.onCurrentFaviconUrl(data));
    this.data.currentProfileImg.subscribe(data => this.srcProfileLogo = data);
    this.data.currentJobTitle.subscribe(data => this.jobTitle = data);
    this.data.currentUserName.subscribe(data => this.userNameUpdate = data);
    this.listenVerificationSuccess();

    this.codeDataTransferService.currentSocketConnection.subscribe(message => {
      if (message === '') {
        const contactInfo = JSON.parse(localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO)) as Contact;
        if (contactInfo && contactInfo.email) {
          message = contactInfo.email;
        }
      }

      if (message.length > 0) {
        this.socket = this.notificatoinService.connectSocket();
        this.notificatoinService.joinInRoom(message);

        this.socket.on(message, data => {
          this.codeDataTransferService.changeNotificationReviced(message);
        });
      }
    });

    setTimeout(() => {
      /** loading spinner ends after 1 seconds */
      this.loading = false;
    }, 1000);

    // subscribe to cookieconsent observables to react to main events
    this.popupOpenSubscription = this.ccService.popupOpen$.subscribe(
      () => {
        // you can use this.ccService.getConfig() to do stuff...
      });

    this.popupCloseSubscription = this.ccService.popupClose$.subscribe(
      () => {
        // you can use this.ccService.getConfig() to do stuff...
      });

    this.initializeSubscription = this.ccService.initialize$.subscribe(
      (event: NgcInitializeEvent) => {
        // you can use this.ccService.getConfig() to do stuff...
      });

    this.statusChangeSubscription = this.ccService.statusChange$.subscribe(
      (event: NgcStatusChangeEvent) => {
        // you can use this.ccService.getConfig() to do stuff...
      });

    this.revokeChoiceSubscription = this.ccService.revokeChoice$.subscribe(
      () => {
        // you can use this.ccService.getConfig() to do stuff...
      });

    // For Cookie
    this.translate//
      .get(['cookie.content.header', 'cookie.content.message', 'cookie.content.dismiss',
        'cookie.content.allow', 'cookie.content.deny', 'cookie.content.link'])
      .subscribe(data => {

        this.ccService.getConfig().content = this.ccService.getConfig().content || {};
        // Override default messages with the translated ones
        this.ccService.getConfig().content.header = data['cookie.content.header'];
        this.ccService.getConfig().content.message = data['cookie.content.message'];
        this.ccService.getConfig().content.dismiss = data['cookie.content.dismiss'];
        this.ccService.getConfig().content.allow = data['cookie.content.allow'];
        this.ccService.getConfig().content.deny = data['cookie.content.deny'];
        this.ccService.getConfig().content.link = data['cookie.content.link'];

        this.ccService.destroy(); // remove previous cookie bar (with default messages)
        this.ccService.init(this.ccService.getConfig()); // update config with translated messages
      });

  }

  getChannelNameForId(id: string): string {
    return 'Channel View';
  }

  getProductNameForSku(sku: string): string {
    // return sku; // If we replace the SKU in url with product name then we need to uncomment this
    return 'Product View';
  }

  onCurrentImageUrl(response) {
    this.srcCompanyLogo = response;
  }

  onCurrentFaviconUrl(response) {
    this.srcCompanyFavicon = response.data;
    if (response.action === true) {
      this._homeBusiness.getCompanyLogoIconUrl().subscribe(res => {
        if (!ValidationService.isNullOrEmpty(res.channel.channelDetail)) {
          this.data.changeImageUrl(res.channel.channelDetail.channelLogo.documentUrl);
          this.data.changeFaviconUrl({ data: res.channel.channelDetail.channelIcon.documentUrl, action: false });
        }
      });
    }
  }

  MenuOpen(menuopen) {
    this.menuopen = !menuopen;
  }

  listenVerificationSuccess() {
    this.userDetailService.currentUserDetail.subscribe(data => {
      const _userDetailMessage = data as UserDetailMessage;
      if (_userDetailMessage !== undefined && _userDetailMessage !== null && _userDetailMessage.action !== undefined
        && _userDetailMessage.action !== null) {
        if (_userDetailMessage.action === this.apiUrl.VERIFICATIONSUCCESS) {
          this.clearHeaderDetails();
          const authToken = AppLocalStorageKeys.AUTH_Token;
          const tokenExists = localStorage.getItem(authToken) != null && localStorage.getItem(authToken) !== '' ? true : false;
          if (tokenExists) {
            const result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
            let contactId: number;
            contactId = parseInt(result, 10);
            this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
              this.loginIdExists = true;
              if (!ValidationService.isNullOrEmpty(response.firstName)) {
                this.loginNameExists = response.firstName;
              }

              this.isTokenExists = tokenExists;
            },
              (error) => {
                console.log(error);
                this.loginIdExists = false;
                this.loginNameExists = '';
              });
          } else {
            this.loginNameExists = '';
            this.loginIdExists = false;
            this.isTokenExists = false;
          }
        } else if (_userDetailMessage.action === this.apiUrl.VERIFIED_ALREADY || _userDetailMessage.action === this.apiUrl.CHANGED_MAIL) {
          this.clearForLogout();
        } /*else if (_userDetailMessage.action === this.apiUrl.CHANGED_MAIL) {
          LocalStorageService.clearAllDataExceptAppToken();
          this.loginNameExists = '';
          this.loginIdExists = false;
          this.isTokenExists = false;
          this.isSubscriptedUser = false;
        }*/
      }
    });
  }

  ngOnDestroy() {
    // unsubscribe to cookieconsent observables to prevent memory leaks
    this.popupOpenSubscription.unsubscribe();
    this.popupCloseSubscription.unsubscribe();
    this.initializeSubscription.unsubscribe();
    this.statusChangeSubscription.unsubscribe();
    this.revokeChoiceSubscription.unsubscribe();
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  clearForLogout() {
    this.localStorageService.clearAllDataExceptAppTokenLocally();
    this.loginNameExists = '';
    this.clearHeaderDetails();
  }

  clearHeaderDetails() {
    this.loginIdExists = false;
    this.isTokenExists = false;
    this.isSubscriptedUser = false;
  }
}
