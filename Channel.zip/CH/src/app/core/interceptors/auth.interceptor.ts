import { environment } from './../../../environments/environment';
import { Injectable, Injector } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { AuthService } from '../../auth/services/auth.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private auth: AuthService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler) {

    // Clone the request and set the new header in one step.
    const authReq = req.clone({
      headers: this.auth.getTokenHeader()
    });

    // send cloned request with header to the next handler.
    if (req.url.indexOf('i18n') < 0) {
      // console.log("Api Request: ",req);
      return next.handle(authReq);
    } else {
      // console.log("Local Request: ",req);
      return next.handle(req);
    }
  }
}
