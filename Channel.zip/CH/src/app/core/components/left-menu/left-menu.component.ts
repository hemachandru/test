import { Component } from '@angular/core';

import { SIDEMENU } from '../../../config/constant';

@Component({
  selector: 'app-left-menu',
  templateUrl: './left-menu.component.html',
  styleUrls: ['./left-menu.component.scss']
})
export class LeftMenuComponent {
  public menuValue =  SIDEMENU;
  constructor() { }
}
