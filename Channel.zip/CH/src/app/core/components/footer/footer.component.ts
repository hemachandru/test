import { Component, OnInit } from '@angular/core';
import { WebUrl, ConfigKeys } from '@app/config/constant_keys';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  public liveChatEnable: boolean;
  public webUrl = WebUrl;
  public tawkId: string = ConfigKeys.TAWK_ID;
  constructor() {
    if (environment.LIVE_CHAT_ENABLE) {
      this.liveChatEnable = false;

    } else {
      this.liveChatEnable = true;
    }
  }

  ngOnInit() {
  }

}
