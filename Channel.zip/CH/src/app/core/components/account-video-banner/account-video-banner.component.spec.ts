import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountVideoBannerComponent } from './account-video-banner.component';

describe('AccountVideoBannerComponent', () => {
  let component: AccountVideoBannerComponent;
  let fixture: ComponentFixture<AccountVideoBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountVideoBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountVideoBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
