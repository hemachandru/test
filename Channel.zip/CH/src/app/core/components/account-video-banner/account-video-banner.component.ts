import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-video-banner',
  templateUrl: './account-video-banner.component.html',
  styleUrls: ['./account-video-banner.component.scss']
})
export class AccountVideoBannerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
