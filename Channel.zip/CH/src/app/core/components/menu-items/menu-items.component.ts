import { Component, Input } from '@angular/core';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
  selector: 'app-menu-items',
  templateUrl: './menu-items.component.html',
  styleUrls: ['./menu-items.component.scss']
})
export class MenuItemsComponent {
  @Input() menuItem: any;
  constructor(private sharedService: SharedService, protected asyncLocalStorage: LocalStorage) { }

  onHoverItem(obj) { }

  onToggleSubMenu(menuItem) {
    this.menuCollapse(this.sharedService.menu, menuItem);
    menuItem.selected = !menuItem.selected;
    menuItem.expanded = !menuItem.expanded;
    this.sharedService.callMethodOfSubscribedComponent('Open');
    // this.allMenuClosed = false;
  }

  tileMenuClick() {
    if (!this.menuItem.expanded) {
      this.sharedService.callMethodOfSubscribedComponent('MenuOpen');
    }
  }

  menuCollapse(menuMain: any, targetMenu: any) {
    menuMain.forEach(menu => {
      if (menu.title !== targetMenu.title) {
        menu.selected = false;
        menu.expanded = false;
      }
    });
  }

  onClearStorage(clearStorage: number) {
    if (clearStorage) {
      this.asyncLocalStorage.clear().subscribe(() => { });
    }
  }

}
