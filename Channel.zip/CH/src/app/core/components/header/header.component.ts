import {
  Component, OnInit, OnDestroy, OnChanges, Input, Output, EventEmitter, AfterViewInit,
  ElementRef, HostListener
} from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { RoleMenu, ChannelTypeIdEnum, AccessPermissionEnum } from '../../../config/constant';
import { UserAccountStatus } from '@app/config/constant';
import { UserSubscriptionBusiness } from '@app/user-subscription/business/user-subscription.business';
import { menuList } from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { Subject } from 'rxjs/Subject';
import { MatDialog } from '@angular/material';
import { CoreService } from '../../service/core.service';
import { CodeDataTransferService } from '../../service/code-data-transfer.service';
import Socket = SocketIOClient.Socket;
import { CartCountService } from '@app/shared/shared-service/cart-count';
import { ISubscription } from 'rxjs/Subscription';
import { FavoriteCountService } from '@app/shared/shared-service/product-favorite-count';
import { ProductService } from '@app/product/service/product-service.service';
import { TranslateService } from '@ngx-translate/core';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ToastrService } from 'ngx-toastr';
import { NgcCookieConsentService } from 'ngx-cookieconsent';
import { LocalStorage } from '@ngx-pwa/local-storage';
import { NotificatoinService } from '../../service/notificatoin-service';

/*@Directive({
  selector: '[clickOutside]',
})*/

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit, OnDestroy, OnChanges, AfterViewInit {
  public webUrl = WebUrl;
  private menuValue: any = [];
  public inputClass: any = 'headerSearch';
  public blockClass: any = 'headerSearch-container';
  public isSubscriptedUser: any = false;
  public isCmsFlagUser: any = false;
  public userdropdown: any = false;
  public imgURL: string;
  public userName: string;
  private unsubscribe = new Subject<void>();
  public cartCount;
  public favoriteCount;
  public subscription: ISubscription;
  public favsubscription: ISubscription;
  public menuArray = menuList;
  public menuValues: any = [];
  public filtershow: boolean;

  @Input() isGuestUser: any = false;
  @Input() userChannelStatus: any;
  @Input() userLoged: any;
  @Input() userLogedProfileBool: any;
  @Input() userLogedProfileName: any;
  @Input() profileLogo: string;
  @Input() profileJobTitle: string;
  @Output() logoutClick = new EventEmitter<boolean>();
  @Output() clickOutside = new EventEmitter<boolean>();
  @Input() loginName: string;
  public userChannelid: string;
  navigationSubscription: any;
  @Input() set profileUser(value: boolean) {
    this.isSubscriptedUser = value;
  }

  @HostListener('document:click', ['$event.target'])
  public onClick(targetElement) {
    const clickedInside = this._elementRef.nativeElement.contains(targetElement);
    if (!clickedInside) {
      this.clickOutside.emit(null);
      if (this.userdropdown === true) {
        this.toggledropdown(this.userdropdown);
      }
    }
  }

  constructor(private router: Router,
    public dialog: MatDialog,
    private userSubscriptionBusiness: UserSubscriptionBusiness,
    private codeDataTransferService: CodeDataTransferService,
    private _coreService: CoreService,
    private sharedService: SharedService,
    private _elementRef: ElementRef,
    private cartCountService: CartCountService,
    private favoriteCountService: FavoriteCountService,
    private productService: ProductService,
    private translate: TranslateService,
    private authorizeService: AuthorizeService,
    private toastrService: ToastrService,
    private ccService: NgcCookieConsentService,
    private notificatoinService: NotificatoinService,
    protected asyncLocalStorage: LocalStorage,
    public localStorageService: LocalStorageService
  ) {

    this.sharedService.invokeEvent.subscribe(value => {
      if (value === 'logout') {
        this.userLogout();
      }
    });

    translate.setDefaultLang('en');
  }

  switchLanguage($event) {
    // console.log($event.target.value);
    const language: string = $event.target.value;
    this.translate.use(language);
  }

  ngOnInit() {
    this.initializeServices();
    for (let i = 0; i < this.menuArray.length; i++) {
      this.menuValues.push(this.menuArray[i]);
    }

    const AUTH_Token = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    // const USER_CHANNEL_STATUS = parseInt(localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS), 10);
    // const CHANNEL_TYPE_ID = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);

    // if (AUTH_Token !== undefined && AUTH_Token !== null && USER_CHANNEL_STATUS === UserAccountStatus.CHANNEL_APPROVED
    // 	&& (CHANNEL_TYPE_ID === ChannelTypeIdEnum.DISTRIBUTOR || CHANNEL_TYPE_ID === ChannelTypeIdEnum.RETAILER)) {
    // 	this.getCartCountService();
    // 	this.getFavoriteCountService();
    // 	this.getNotificationCount();
    // 	this.getCartCount();
    // 	this.getFavoriteCount();
    // }

    // get the notification count after Notification Reviced.
    this.codeDataTransferService.currentnotificationReviced.takeUntil(this.unsubscribe).subscribe(message => {
      if (AUTH_Token !== undefined && AUTH_Token !== null) {
        this.getNotificationCount();
        this.codeDataTransferService.changeNewNotification(message);
      }
    });

    // get the notification count after read the notificaton.
    this.codeDataTransferService.currentNotificationRead.takeUntil(this.unsubscribe).subscribe(message => {
      if (AUTH_Token !== undefined && AUTH_Token !== null) {
        this.getNotificationCount();
      }
    });

    // get the notification count after read the notificaton.
    this.codeDataTransferService.currentLogingNotification.takeUntil(this.unsubscribe).subscribe(message => {
      // setTimeout(() => {
      if (AUTH_Token !== undefined && AUTH_Token !== null) {
        this.getNotificationCount();
      }
      // }, 10000);
    });


  }

  ngOnChanges() {
    const CHANNEL_TYPE_ID = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
    if (CHANNEL_TYPE_ID !== ChannelTypeIdEnum.VENDOR) {
      this.getCartCount();
      this.getFavoriteCount();
    }
  this.headderLoadEvent();
  }

  ngAfterViewInit() {

  }

  initializeServices() {
    const AUTH_Token = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    const USER_CHANNEL_STATUS = parseInt(localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS), 10);
    const CHANNEL_TYPE_ID = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);

    if (AUTH_Token !== undefined && USER_CHANNEL_STATUS === UserAccountStatus.CHANNEL_APPROVED) {
      if (CHANNEL_TYPE_ID !== ChannelTypeIdEnum.VENDOR) {
        this.getCartCountService();
        this.getFavoriteCountService();
        this.getCartCount();
        this.getFavoriteCount();
      }

      this.getNotificationCount();
    }
  }

  headderLoadEvent() {
    this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    // if (ValidationService.isNullOrEmpty(this.profileLogo)) {
    this.profileLogo = localStorage.getItem(AppLocalStorageKeys.USER_IMAGE_URL);
    // }
    // if (ValidationService.isNullOrEmpty(this.profileJobTitle)) {
    this.profileJobTitle = localStorage.getItem(AppLocalStorageKeys.JOB_TITLE);
    // }
    this.userName = localStorage.getItem(AppLocalStorageKeys.USER_NAME);
    // this.profileJobTitle = localStorage.getItem(AppLocalStorageKeys.JOB_TITLE);
    // if (ValidationService.isNullOrEmpty(this.loginName)) {
    this.loginName = localStorage.getItem(AppLocalStorageKeys.USER_NAME);
    // }

    this.navigationSubscription = this.router.events.subscribe(event => {

      if (event instanceof NavigationEnd) {
        const userStatusdetail: any = JSON.parse(localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS));
        this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
        if (parseInt(this.userChannelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED && (userStatusdetail.planId != null)
          && (userStatusdetail.subscriptionId != null)) {
          this.isSubscriptedUser = true;
        } else {
          this.isSubscriptedUser = false;
        }

        if (localStorage.getItem('static_page_access')) {
          this.isCmsFlagUser = true;
        } else {
          this.isCmsFlagUser = false;
        }
      }
    });
    this.menuValue = RoleMenu;

    /** Menu filter for user role */
    this.userChannelid = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    if (this.userChannelid === '2') {
      this.showMenus('buyer', true);
    }
    this.userLoged = !ValidationService.isNullOrEmpty(localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) ? true : false;
    // this.getUserInfo();
  }

  showMenus(data, value) {
    this.menuValue = this.menuValue.filter(item => item[data] !== value);
  }

  getUserInfo() {
    const result = localStorage.getItem('user_subscription_contactId');
    if (!ValidationService.isNullOrEmpty(result)) {
      let contactId: number;
      contactId = parseInt(result, 10);
      this.userSubscriptionBusiness.getContactInfo(contactId).subscribe(response => {
        if (!ValidationService.isNullOrEmpty(response.firstName)) {
          this.loginName = response.firstName;
        }
        if (!ValidationService.isNullOrEmpty(response.lastName)) {
          this.loginName = this.loginName + ' ' + response.lastName;
        }

        this.profileJobTitle = !ValidationService.isNullOrEmpty(response.jobTitle) ? response.jobTitle : '';
        this.profileLogo = !ValidationService.isNullOrEmpty(response.imageUrl) ? response.imageUrl : '';
      },
        (error) => {
          console.log(error);
        });
    }
  }

  public userLogout() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      this.notificatoinService.disconnet();
    }
    this.localStorageService.clearAllDataExceptAppToken();
    this.isGuestUser = false;
    this.userdropdown = false;
    // this.router.navigate([this.webUrl.LOGIN]);
  }

  toggledropdown(userdropdown) {
    this.userdropdown = !this.userdropdown;
  }

  getNotificationCount() {
    this._coreService.getNotificationCount().subscribe(response => {
      if (response.ok) {
        RoleMenu[4].count = response.body.unread;
      }
    }, (error) => {
      console.log(error);
    });
  }

  logout() { this.logoutClick.emit(); }


  headerRedirect(navigate) {
    let canNavigate = false;
    if (navigate === 'myprofile') {
      canNavigate = this.authorizeBeforeNavigate(AccessPermissionEnum.CONTACT_PROFILE);
    } else if (navigate === 'setting') {
      canNavigate = this.authorizeBeforeNavigate(AccessPermissionEnum.PROFILE_COMPANY_SETTINGS);
    }

    if (canNavigate) {
      this.router.navigate(['/profile', { outlets: { 'profileroute': [navigate] } }]);
    }
  }

  getCartCount() {
    // console.log('getCartCount');
    if (!this.subscription) {
      this.subscription = this.cartCountService.getCartItems().subscribe(response => {
        this.cartCount = response;
        // tslint:disable-next-line:triple-equals
        if (this.cartCount == 0) {
          this.getCartCountService();
        }
        // console.log('cartCount', this.cartCount);
      });
    }
  }

  getFavoriteCount() {
    // console.log('getFavoriteCount');
    if (!this.favsubscription) {
      this.favsubscription = this.favoriteCountService.favoriteCount().subscribe(response => {
        this.favoriteCount = response;
        // tslint:disable-next-line:triple-equals
        if (this.favoriteCount == 0) {
          this.getFavoriteCountService();
        }

        // console.log('favoriteCount', this.favoriteCount);
      });
    }
  }

  // Cart count
  getCartCountService() {
    this.productService.getCartCount().subscribe(res => {
      if (res.status) {
        const result = res.data;
        this.cartCount = result.reduce((acc, val) => {
          const productCount = parseInt(val.product_count, 10);
          return acc + productCount;
        }, 0);
        // return this.cartCount;
      } else {
        console.log('add to cart ' + res);
      }
    });
  }

  // Favorite count
  getFavoriteCountService() {
    this.productService.getFavoriteCount().subscribe(res => {
      if (res.status) {
        this.favoriteCount = res.count;
      } else {
        console.log('add to cart ' + res);
      }
    });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  /**Open user profile popup */

  userprofileOpen() {
    this.userdropdown = true;
  }

  userprofileClose(e) {
    e.stopPropagation();
    if (e.relatedTarget && e.relatedTarget.classList.value !== '') {
      if (e.relatedTarget.href) {
        setTimeout(() => { this.userdropdown = false; }, 500);
      }
      if (e.currentTarget.className === 'user-profile') {
        this.userdropdown = true;
      }
    } else {
      if ((e.relatedTarget && e.relatedTarget.localName === 'input') ||
      (e.relatedTarget && e.relatedTarget.localName === 'a') || (e.relatedTarget && e.relatedTarget.localName === 'li')) {
        setTimeout(() => { this.userdropdown = false; }, 500);
      } else {
        this.userdropdown = false;
      }
      // this.userdropdown = false;
    }
  }

  navigateProductActionTo(navObject: any) {
    let canNavigate = false;
    if (navObject.type === 'WISHLIST') {
      canNavigate = this.authorizeBeforeNavigate(AccessPermissionEnum.PRODUCTS_WISHLIST);
    } else if (navObject.type === 'CART') {
      canNavigate = this.authorizeBeforeNavigate(AccessPermissionEnum.PRODUCTS_ADD_TO_CART);
    } else {
      canNavigate = true;
    }

    if (canNavigate) {
      this.asyncLocalStorage.clear().subscribe(() => { });
      this.router.navigate([navObject.link]);
    }
  }

  authorizeBeforeNavigate(accessId: number) {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(accessId);
      if (!hasUpdateAccess) {
        this.toastrService.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  // Emit Event for text search validation
  emitOnClick(event) {
    this.userdropdown = false;
  }
}
