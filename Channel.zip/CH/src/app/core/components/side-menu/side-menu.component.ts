import { Component, OnInit, Input, ViewChild, QueryList, ViewChildren, AfterViewInit } from '@angular/core';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { SIDEMENU_ITEMS, MenuItem } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { MenuItemsComponent } from '@app/core/components/menu-items/menu-items.component';


@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent implements OnInit, AfterViewInit {

  public menu: MenuItem[];
  public opts: ISlimScrollOptions;
  profileLogoUrl: string;
  @Input() profileLogo: string;
  @Input() profileFavicon: string;
  @ViewChildren(MenuItemsComponent) menuListComponent: QueryList<MenuItemsComponent>;

  public userChannelStatus: string;

  constructor(private sharedService: SharedService, private authorizeService: AuthorizeService) { }

  ngOnInit() {
    this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    localStorage.setItem(AppLocalStorageKeys.SIDE_MENU_LIST, JSON.stringify(SIDEMENU_ITEMS));
    this.menu = JSON.parse(localStorage.getItem(AppLocalStorageKeys.SIDE_MENU_LIST));
    this.authorizeMenus();
    if (this.userChannelStatus !== '2') {
      this.showMenus('vendor', true);
    } else {
      this.showMenus('distributor', true);
    }
    if (this.userChannelStatus === '4') {
      this.showMenus('retailer', 'hide');
    }
    if (this.userChannelStatus === '3') {
      this.showMenus('distributor', false);
    }
    localStorage.removeItem(AppLocalStorageKeys.SIDE_MENU_LIST);

    this.profileLogoUrl = 'url(' + this.profileLogo + ') no-repeat center';
    this.opts = {
      barBackground: 'trasparent',
      gridBackground: 'trasparent',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };

    this.sharedService.getMenuItem(this.menu);
  }

  ngAfterViewInit(): void {
    // console.log("ss************", this.menuListComponent.toArray());
  }

  showMenus(data, value) {
    for (let i = 0; i < this.menu.length; i++) {
      if (this.menu[i].children) {
        this.menu[i].children = this.menu[i].children.filter(child => child[data] !== value);
      }
    }
    this.menu = this.menu.filter(item => item[data] !== value);
  }

  public tileMenuClick() {
    this.sharedService.callMethodOfSubscribedComponent('MenuOpen');
  }

  public authorizeMenus() {
    for (let i = 0; i < this.menu.length; i++) {
      if (this.menu[i].isAuthorize) {
        if (!this.authorizeService.hasAccessPermissions(this.menu[i].authorizeVal)) {
          this.menu.splice(i, 1);
          --i;
        } else {
          if (this.menu[i].children) {
            for (let j = 0; j < this.menu[i].children.length; j++) {
              if (this.menu[i].children[j].isAuthorize
                && !this.authorizeService.hasAccessPermissions(this.menu[i].children[j].authorizeVal)) {
                this.menu[i].children.splice(j, 1);
                --j;
              }
            }
          }
        }
      }
    }
  }
}
