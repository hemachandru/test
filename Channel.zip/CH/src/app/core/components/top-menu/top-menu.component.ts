import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';

import { menuList } from '../../../config/constant';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AppLocalStorageKeys } from '@app/config/constant_keys';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})

export class TopMenuComponent implements OnInit {
  public menuArray = menuList;
  public menuValue: any = [];
  public exact = false;
  toggleMenu = false;
  public userLogged: boolean;
  navigationSubscription: any;

  constructor(private route: ActivatedRoute, private router: Router) {
    this.navigationSubscription = this.router.events.subscribe((e: any) => {

      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.userLogged = !ValidationService.isNullOrEmpty(localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) ? true : false;
      }
    });
  }

  ngOnInit() {
    for (let i = 0; i < this.menuArray.length; i++) {
      this.menuValue.push(this.menuArray[i]);
    }
  }
  onToggleMenu() {
    if (this.toggleMenu === true) {
      document.querySelector('body').classList.remove('overflowhide');
    } else {
      document.querySelector('body').classList.add('overflowhide');
    }
    this.toggleMenu = !this.toggleMenu;

  }

  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }
}
