export interface Oldregaddresscountry {
    countryId: number;
    country: string;
}

export interface Oldchanneldetail {
    documentId: number;
    documentPath: string;
    documentUrl: string;
}

export interface Oldchannel {
    oldChannelId: number;
    companyName: string;
    oldregaddresscountry: Oldregaddresscountry;
    oldchanneldetail: Oldchanneldetail;
}

export interface Regaddresscountry {
    countryId: number;
    country: string;
}

export interface Companylogo {
    documentId: number;
    documentPath: string;
    documentUrl: string;
}

export interface Channel {
    channelId: number;
    oldChannelId?: any;
    companyName: string;
    regaddresscountry: Regaddresscountry;
    companylogo: Companylogo;
}

export class KeyRetailerRootObject {
    oldchannel: Oldchannel[];
    channel: Channel[];
}

export class KeyRetailerFilterList {
    channelId?: number;
    oldchannelid?: number;
    companyName?: string;
    documentPath: string;
    keypartnerid?: number;
    countryid: number;
    partnername?: string;
    existchannelid?: number;
    image?: string;
    channelkeypartnerid?: number;
    imageid?: number;
    documentUrl?: string;
    countryName?: string;
}

export class KeyRetailerListPost {
    channelId?: number;
    oldchannelid?: number;
    // companyName: string;
    documentPath: string;
    keypartnerid?: number;
    countryid: number;
    partnername: string;
    existchannelid?: number;
    image: string;
    channelkeypartnerid?: number;
    imageid?: number;
    documentUrl?: string;
}

export class KeyRetailerSelectedList {
    channelId?: number;
    oldchannelid?: number;
    companyName: string;
    documentPath: string;
    keypartnerid?: number;
    countryid: number;
    partnername: string;
    existchannelid?: number;
    image?: string;
    channelkeypartnerid?: number;
    imageid?: number;
    documentUrl?: string;
    countryName?: string;
    country: number;
}

export interface ChannelKeyRetailerObject {
    keypartnerid: number;
    active: Active;
    old?: any;
    new?: any;
    isVerified: number;
}

export class ChannelKeyretailersDescription {
    channelKeyRetailers: ChannelKeyRetailerObject[];
    keyretailerDescription: string;
    keydistributorDescription: string;
}

export interface Active {
    id: number;
    company_name: string;
    country: Country;
    logo: Logo;
    plan: Plan;
}

export interface Country {
    country_id: number;
    country_name: string;
}

export interface Logo {
    logo_id: number;
    documentPath: string;
    documentUrl: string;
}

export interface Plan {
    plan_id: number;
    plan_name: string;
}

