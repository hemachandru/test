import { Email } from 'aws-sdk/clients/guardduty';
import { ChannelKeyRetailerGet } from '@app/shared/models/shared-model';

export class MultiCertificate {
    accCertiNameId: Array<Certify> = [];
    public editorConfig = {
        editable: true,
        spellcheck: false,
        height: '20rem',
        minHeight: '5rem',
        placeholder: 'Enter About Company',
        translate: 'no',
        background: '#ffffff',
        imageEndPoint: 'fileUpload'
    };
    public arrImage = [{ 'src': 'assets/images/pro-logo.jpg', 'loc': '' },
    { 'src': 'assets/images/pro-logo.jpg', 'loc': '' }, { 'src': '', 'loc': '' }];
    public arrMultipleLable = ['regcertificate', 'accCerficateId', 'profileTaxCertiId', 'profileTaxCertno', 'profileAwardDtl'
        , 'profileIssuedBy', 'profileValidTill', 'profileb2b', 'profileemail',
        'profileabout', 'profilelinkedURL', 'profileGoogleURL', 'profileInstaURL', 'profileAuthmob'
        , 'fileprofileImg', 'regcertificate', 'profileTaxCertno', 'profileb2b', 'fileprofileLogo', 'fileprofileFavicon'
        , 'country', 'establishYear', 'registrationYear', 'profilePhone2', 'profileAuthEmail', 'registerCountry', 'expectation'];

    public txtLable = [0, 0, 0, 0];
    public txtindex = [-1, -1, -1, -1];
    public flag_mandatory = 1;
    public htmlContent: string;
    public preloader: boolean;
    public jsonData: any;
    public folderName = 'contact-s3/';
    profileImgErr = '';
    profileImage = '';
    userImage: boolean;
    userIcon: boolean;
    regImgView = '';
    errorResponse = '';
    lblResponse = 'companyProfile';
    recordNotSave = '';
    socialLink = null;
    socialGoogle = null;
    socialInsta = null;
    contactLinkedin = null;
    txtLableLifeTime = '';
    public establishYear: string;
    public registrationYear: string;
    public errorCodeArr = {
        'company_email': '', 'company_about': '', 'social_linkedin_url': '', 'social_googleplus_url': '',
        'social_instagram_url': '', 'contact_mobile_no': '', 'contact_profile_image_url': '', 'registration_certificate': '',
        'tax_certificate': '', 'B2B_url': '', 'fileprofile_image': '', 'fileprofileFavicon': '', 'coutry_bill': '', 'phone2': '',
        'regiser_coutry_bill': '', 'expectation': ''
    };
    public lifeTimeText = 'Life Time Validity';

    constructor() {
        this.establishYear = '';
        this.registrationYear = '';
        this.htmlContent = '';
    }
}

export class ProfileAddress {
    address: string;
    postalCode: number;
    city: string;
    countryId: number;
}

export class CustomerSearchItem {
    Channel_Profile_Type_Classification_ID: number;
    Channel_Profile_ID: number;
    Channel_Profile_Name: string;
    Channel_Type_ID: number;
    Channel_Type_Name: string;
    Default: null;
}

export class CustomerTypeList {
    isDefault: number;
    id: number;
    name: string;
}

export class DistributorSearchItem {
    id: number;
    name: string;
}
export class BrandListItem {
    id: number;
    Name: string;
    documentPath: string;
    isAssigned: number;
    isVerified: number;
}

export class KeyRetailerListItem {
    id: number;
    Name: string;
    documentPath: string;
    isAssigned: number;
    isVerified: number;
}

export class Certify {
    certi: Array<Certificate> = [];
    deleteId: Array<DeleteID> = [];
}

export class DeleteID {
    id: number;
}

export class BrandListPost {
    id: number;
    name: string;
    documentPath: string;
}

// tslint:disable-next-line:class-name
export class listOfServicesPost {
    id: number;
}

// tslint:disable-next-line:class-name
export class distributorSpecialityPost {
    specialityId: number;
}
// tslint:disable-next-line:class-name
export class specialityPost {
    specialityId: number;
}

// tslint:disable-next-line:class-name
export class productFamiliesPostarray {
    id: number;
}

// tslint:disable-next-line:class-name
export class productCategoriesPostarray {
    productFamilId: number;
    productCategoriesId: number;
}
// tslint:disable-next-line:class-name
export class customerProfilesPostarray {
    id: number;
    profileTypeClassificationId: number;
}

// tslint:disable-next-line:class-name
export class tradeInformationVendorPost {
    brand: Array<BrandListPost>;
    employeesRange: string;
    employeesCount: number;
    domesticSales: number;
    internationalSales: number;
    domesticMarketing: number;
    internationalMarketing: number;
    annualTurnoverRange: string;
    annualTurnover: number;
    domesticRevenue: number;
    internationalRevenue: number;
    profileTypeId: number;
    startup: string;
    maturitylevel: any;
    channelKeyRetailer: Array<KeyRetailerListPost>;
    channelKeyDistributor: Array<KeyRetailerListPost>;
    deletedkeyretailer: Array<Deletedkeyretailer>;
    deletedkeydistributor: Array<Deletedkeyretailer>;
    keyretailers: string;
    no_of_retailers: number;
    no_of_skus: number;
    no_of_distributors: number;
    keydistributors: string;
}

export class Deletedkeyretailer {

}
// tslint:disable-next-line:class-name
export class tradeInformationDistributorPost {
    brand: Array<BrandListPost>;
    listOfServices: Array<listOfServicesPost>;
    distributorSpeciality: Array<distributorSpecialityPost>;
    profileTypeId: number;
    employeesRange: string;
    employeesCount: number;
    domesticSales: number;
    internationalSales: number;
    domesticMarketing: number;
    internationalMarketing: number;
    annualTurnoverRange: string;
    annualTurnover: number;
    domesticRevenue: number;
    internationalRevenue: number;
    startup: string;
    maturitylevel: any;
    channelKeyRetailer: Array<KeyRetailerListPost>;
    deletedkeyretailer: Array<Deletedkeyretailer>;
    keyretailers: string;
    no_of_retailers: number;
}

export class KeyRetailerListPost {
    channelId?: number;
    oldchannelid?: number;
    // companyName: string;
    documentPath: string;
    keypartnerid?: number;
    countryid: number;
    partnername: string;
    existchannelid?: number;
    image: string;
    channelkeypartnerid?: number;
    imageid?: number;
    documentUrl?: string;
}

// tslint:disable-next-line:class-name
export class tradeInformationRetailerPost {
    speciality: Array<specialityPost>;
    profileTypeId: number;
    employeesRange: string;
    employeesCount: number;
    annualTurnoverRange: string;
    annualTurnover: number;
    physicalStore: number;
    OnlineStore: number;
    startup: string;
    maturitylevel: any;
    storeCount: number;
}

export class Profile {

    company_logo_url: string;
    company_icon_url: string;
    company_name: string;
    company_owner_first_name: string;
    company_owner_last_name: string;
    company_email: string;
    company_website_url: string;
    company_phone1: string;
    company_phone2: string;
    company_mobile_no: string;
    company_about: string;
    company_expectation: string;

    registration_certificate: Array<Certificate>;
    year_of_estabilishment: number;
    year_of_registration: number;
    reg_address_id: number;
    reg_address: string;
    reg_country_id: number;
    reg_postal_code: string;
    reg_city: string;
    bill_address_id: number;
    bill_address: string;
    bill_postal_code: number;
    bill_city: string;
    bill_country_id: number;
    is_same_address: number;

    tax_certificate: Array<Certificate>;
    award_details: Array<Certificate>;

    social_linkedin_url: string;
    social_googleplus_url: string;
    social_instagram_url: string;
    B2B_url: Array<Certificate>;

    contact_first_name: string;
    contact_last_name: string;
    contact_phone1: string;
    contact_phone2: string;
    contact_mobile_no: string;
    contact_email: string;
    contact_job_title: string;
    contact_linkedin_url: string;
    contact_profile_image_url: string;

    deleted_registration_certificate: Array<DeleteID>;
    deleted_tax_certificate: Array<DeleteID>;
    deleted_award_details: Array<DeleteID>;
    deleted_B2B: Array<DeleteID>;

    social_linkedin_id: number;
    social_googleplus_id: number;
    social_instagram_id: number;
    contact_linkedin_id: number;
    channel_document: Array<ChannelDocument>;
    deleted_channel_documents: number[];

    company_log_id: string;
    contact_profile_image_id: string;

}

export class Certificate {
    name: string;
    id: string;
    details: string;
    issued_by: string;
    valid_upto: Date;
    B2B_url: string;
    channel_certificate_id: number;
    channel_award_id: number;
    channel_B2B_id: number;
    isLifeTime: string;
}

export class TradeInformationData {
    productFamilies: Array<productFamiliesPostarray>;
    productCategories: Array<productCategoriesPostarray>;
    customerProfiles: Array<customerProfilesPostarray>;
    channelType: number;
    tradeInformationVendor: tradeInformationVendorPost;
    tradeInformationDistributor: tradeInformationDistributorPost;
    tradeInformationRetailer: tradeInformationRetailerPost;
    is_french_tech: string;
}

export class TradeInformationGet {
    userId: number;
    contactId: number;
    channelId: number;
    channel: ChannelGet; // Object
}
export class ChannelGet {
    channelId: number;
    signUpStatusId: number;
    channelTypeId: number;
    profileTypeId: number;
    channelDetail: channelDetailGet; // Object
    channelType: channelTypeGet; // Object
    profileType: ProfileTypeGet; // Object
    channelBrand: Array<channelBrandGet>;
    channelCustomerProfile: Array<channelCustomerProfileGet>;
    channelProductGroup: Array<channelProductGroupGet>;
    channelServiceList: Array<channelServiceListGet>;
    channelProductCategorie: Array<channelProductCategorieGet>;
    channelSpeciality: Array<channelSpecialityGet>;
    channelKeyRetailer: Array<ChannelKeyRetailerGet>;
    regAddress: RegisterAddress;
    isFrenchTech: string;
}

export class RegisterAddress {
    address: string;
    addressId: number;
    city: string;
    countryId: string;
    postalCode: string;
}

// tslint:disable-next-line:class-name
export class channelDetailGet {
    channelDetailId: number;
    channelId: number;
    channelLogoId: number;
    channelIconId: number;
    phone1: string;
    phone2: string;
    mobileNo: string;
    webSiteUrl: string;
    estYear: string;
    regYear: string;
    detailDesc: string;
    empCntRange: string;
    empCnt: number;
    empCntDSale: number;
    empCntISale: number;
    empCntDMar: number;
    empCntIMar: number;
    turnoverRange: string;
    turnover: number;
    revD: number;
    revI: number;
    turnoverPhyStore: number;
    turnoverOnStore: number;
    stripeConnectId: string;
    paymentoptionothers: string;
    currencyid: number;
    ownerFirstName: string;
    ownerLastName: string;
    startup: string;
    maturitylevel: string;
}

export class ChannelkeyRetailer {
    channelkeyretailerid?: number;
    retailername: string;
    countryid: number;
    imageid?: number;
    image: string;
    existchannelid?: number;
    oldchannelid?: number;
    keyretailerid?: number;
}
// tslint:disable-next-line:class-name
export class channelTypeGet {
    channelTypeId: number;
    channelType: string;
}

export class ProfileTypeGet {
    profileTypeId: number;
    profileType: string;
}
// tslint:disable-next-line:class-name
export class channelBrandGet {
    channelBrandId: number;
    channelId: number;
    brandId: number;
    brand: brandGet; // Oject

}
// tslint:disable-next-line:class-name
export class documentGet {
    documentUrl: string;
}
// tslint:disable-next-line:class-name
export class brandGet {
    id: number;
    brandName: string;
    documentId: number;
    isAssigned: string;
    isVerified: string;
    isActive: string;
    document: documentGet; // Oject
}
// tslint:disable-next-line:class-name
export class channelCustomerProfileGet {
    customerProfileId: number;
    channelId: number;
    profileTypeId: number;
    profileTypeClassificationId: number;
    profileType: profileTypeGet; // Object
    pTClas: PTClasGet; // Object
}

export class PTClasGet {
    channelType: ChannelTypeGet;
    channelTypeId: number;
    isDefault: number;
    profileTypeClassification: number;
    profileTypeId: number;
}
export class ChannelTypeGet {
    channelType: string;
    channelTypeId: number;

}
// tslint:disable-next-line:class-name
export class profileTypeGet {
    profileTypeId: number;
    profileType: string;
}

// tslint:disable-next-line:class-name
export class productGroupGet {
    productGroupId: number;
    productGroup: string;
    isActive: string;
}
// tslint:disable-next-line:class-name
export class channelProductGroupGet {
    channelProductGroupId: number;
    channelId: number;
    productGroupId: number;
    productGroup: productsGroupGet; // Object
}

// tslint:disable-next-line:class-name
export class productsGroupGet {
    productGroupId: number;
    productGroup: string;
    isActive: string;
}
// tslint:disable-next-line:class-name
export class channelServiceListGet {
    channelServiceListId: number;
    channelId: number;
    serviceListId: number;
    serviceList: serviceListGet; // Object
}

// tslint:disable-next-line:class-name
export class serviceListGet {
    serviceListId: number;
    serviceList: string;
}
// tslint:disable-next-line:class-name
export class channelSpecialityGet {
    channelSpecialityId: number;
    channelId: number;
    productGroupId: number;
    productGroup: productsGroupGet; // Object
}

// tslint:disable-next-line:class-name
export class channelProductCategorieGet {
    channelProductCategorieId: number;
    channelId: number;
    productCategorieId: number;
    productCategorie: productCategorieGet; // Object
}
// tslint:disable-next-line:class-name
export class productCategorieGet {
    productCategor: string;
    productGroupId: number;
    isActive: string;
    productGroup: productGroupGetsimple; // Object
}

// tslint:disable-next-line:class-name
export class productGroupGetsimple {
    p: string;
    i: number;
}

// tslint:disable-next-line:class-name
export class imageAction {
    data: string;
    action: boolean;
}

export interface CountryMaster {
    countryId: string;
    country: string;
    isVat: string;
    isoCode: string;
    phoneCode: string;
    registrationcertificate: string;
}
export class ChannelDocument {
    channelDocumentId: number;
    documentId: number;
    document: string;
}
