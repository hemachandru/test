export class Zone {
    zoneId: number;
    zone: string;
    region: Region[];
}

export class Region {
    regionId: number;
    region: string;
    channelId: number;
    ZoneRegionJCT: ZoneRegionJCT;
    country: Country[];
}

export class Country {
    countryId?: number;
    country: string;
    RegionCountryJCT?: RegionCountryJCT;
}

export class RegionCountryJCT {
    regionCountryJCTId: number;
    regionId: number;
    countryId: number;
}

export class ZoneRegionJCT {
    zoneRegionJCTId: number;
    zoneId: number;
    regionId: number;
}

export class RegionCountry {
    zoneId: number;
    zone: string;
    region: Region[];
}
/*export class ChannelLocation {
    channelLocationId: number;
    channelId: number;
    locationType: string;
    regionCountryJCTId: number;
}*/

export class ChannelLocation {
    locationType: string;
    location: Zone[];
}

export class ZoneDTO {
    zoneId: number;
    zone: string;
    region: Region[];
    isMapped: Boolean;
    constructor() {
        this.isMapped = false;
    }
}

export class LocationSearchRegionDTO {
    zone: number [];
    region: string;
    locationType: string;
    exclude: boolean;
}

export class LocationSearchCountryDTO {
    zone: Zone [];
    region: Region [];
    country: string;
    locationType: string;
}

export class LocationCountrySaveDTO {
    locationType: string;
    location: number[];
}

export class CustomRegion {
    zoneId: number;
    region: string;
    countryId: number[];
}
