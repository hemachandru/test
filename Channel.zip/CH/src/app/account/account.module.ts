import { NgModule, } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material';
import { DateAdapter } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { AccountRoutingModule } from './account-routing.module';
import { CompanyTitleComponent } from './component/company-title/company-title.component';
import { AccountComponent } from './container/account/account.component';
import { SharedModule } from './../shared/shared.module';
import { AccountBusiness } from './business/account.bussiness';
import { AccountService } from './services/account.service';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';

// Import ng-circle-progress
import { NgCircleProgressModule } from 'ng-circle-progress';
import { ScrollToModule } from 'ng2-scroll-to-el';
import { TabModule } from 'angular-tabs-component';
import { TooltipModule } from 'ng2-tooltip';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { ProfileAddElementComponent } from './container/profile-add-element/profile-add-element.component';
import { AccountProfileComponent } from './component/account-profile/account-profile.component';
import { ProfileImageUploadComponent } from './container/profile-image-upload/profile-image-upload.component';
import { NgxEditorModule } from 'ngx-editor';
import { InputTrimModule } from 'ng2-trim-directive';
import { TradeLocationComponent } from './component/trade-location/trade-location.component';
import { AccountTradeInformationComponent } from './component/account-trade-information/account-trade-information.component';
import { AccountVerificationComponent } from './component/account-verification/account-verification.component';
import { AccountModalConfirmComponent } from './component/account-modal-confirm/account-modal-confirm.component';
import { MatDialogModule, MAT_DIALOG_DEFAULT_OPTIONS, MAT_DIALOG_DATA } from '@angular/material';
import { LocationMapComponent } from './component/location-map/location-map.component';

import { SlimScrollModule } from 'ng2-slimscroll';
import { AddBrandComponent } from './component/add-brand/add-brand.component';
import { AccountModalSuccessComponent } from './component/account-modal-success/account-modal-success.component';
import { MessageDialogComponent } from '../shared/shared-component/message-dialog/message-dialog.component';
import { ConfirmDialogComponent } from '../shared/shared-component/confirm-dialog/confirm-dialog.component';
import { ProfileSettingsComponent } from '../profile/component/profile-settings/profile-settings.component';
import { AddCertificateComponent } from './component/add-certificate/add-certificate.component';
import { QuillEditorModule } from 'ngx-quill-editor';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AccountRoutingModule,
    // Specify ng-circle-progress as an import
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 40,
      space: -2,
      outerStrokeWidth: 3,
      innerStrokeWidth: 3,
      outerStrokeColor: '#ea6a24',
      innerStrokeColor: '#a8a8a8',
      animationDuration: 300,
      showSubtitle: false,
      titleFontSize: '20',
      titleColor: '#000000'
    }),
    TabModule,
    FormsModule,
    MatDatepickerModule, MatNativeDateModule, NgxEditorModule,
    ScrollToModule,
    SlimScrollModule,
    TooltipModule,
    BsDatepickerModule.forRoot(),
    InputTrimModule,
    NgxEditorModule,
    QuillEditorModule
  ],
  declarations: [
    CompanyTitleComponent,
    AccountComponent,
    ProfileAddElementComponent,
    AccountProfileComponent,
    ProfileImageUploadComponent,
    TradeLocationComponent,
    AccountModalConfirmComponent,
    AccountTradeInformationComponent,
    AccountVerificationComponent,
    LocationMapComponent,
    AddBrandComponent,
    AccountModalSuccessComponent,
    AddCertificateComponent],
  providers: [AccountBusiness, AccountService, AccountDataService,
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: true, closeOnNavigation: true } },
    { provide: MAT_DIALOG_DATA, useValue: {} }],
  exports: [ProfileAddElementComponent, AccountProfileComponent, AccountTradeInformationComponent],
  entryComponents: [
    AccountModalConfirmComponent,
    TradeLocationComponent,
    AddBrandComponent,
    AccountTradeInformationComponent,
    AccountModalSuccessComponent,
    MessageDialogComponent,
    ProfileSettingsComponent,
    ConfirmDialogComponent
  ]
})

export class AccountModule { }
