import { Injectable } from '@angular/core';

import { ApiUrl } from '@app/config/constant_keys';

import { AccountService } from './../services/account.service';
import { Profile, TradeInformationData } from './../models/profile';
import { HttpParams } from '@angular/common/http';

@Injectable()
export class AccountBusiness {
  private apiUrl = ApiUrl;
  constructor(private _accountService: AccountService) {
  }

  getSellingZoneBusiness() {
    const url: any = this.apiUrl.ZONE_LIST;
    return this._accountService.getAccountListServiceHttpClient(url).map(res => {
      return res;
    });
  }

  getStripeConnect() {
    const url: any = this.apiUrl.STRIPE_CONNECT;
    return this._accountService.getAccountListService(url).map(res => {
      return res;
    });
  }

  // post stripe connection
  postCreateCustomRegion(data) {
    const url: any = this.apiUrl.CREATEREGION;
    return this._accountService.postAccountService(data, url, true).map(res => {
      return res;
    });
  }

  // post stripe connection
  postStripeConnect(code) {
    const url: any = this.apiUrl.STRIPE_CONNECT;
    return this._accountService.postAccountService(code, url).map(res => {
      return res;
    });
  }
  getscoreList() {
    const url: any = this.apiUrl.SCORE_LIST;
    return this._accountService.getAccountListService(url).map(res => {
      return res;
    });
  }

  postZoneRegionCompanyBusiness(zoneID_list) {
    const url: any = this.apiUrl.ZONE_BASED_REGION_COUNTRY;
    return this._accountService.postAccountService(zoneID_list, url).map(res => {
      return res;
    });
  }

  postProfile(profile: Profile, returnFullResponse: boolean, updateFlag) {
    let url: any = this.apiUrl.POST_COMPANY;
    if (updateFlag === true) {
      url = this.apiUrl.POST_UPDATE_COMPANY;
    }
    return this._accountService.postAccountService(profile, url, returnFullResponse).map(res => {
      return res;
    });
  }

  postTradeInformation(trade: TradeInformationData, returnFullResponse: boolean, updateFlag) {
    const url: any = this.apiUrl.POST_TRADEINFORMATION;
    return this._accountService.postAccountService(trade, url, returnFullResponse).map(res => {
      return res;
    });
  }

  putTradeInformation(trade: TradeInformationData, returnFullResponse: boolean, updateFlag) {
    const url: any = this.apiUrl.UPDATE_TRADEINFORMATION;
    return this._accountService.putTradeinfoService(trade, url, returnFullResponse).map(res => {
      return res;
    });
  }




  getUserProfileBusiness() {
    const url: any = this.apiUrl.COMPANY;
    return this._accountService.getAccountListService(url)
      .map(res => {
        return res;
      });
  }

  // Get Old Channel for Account Setup
  getOldChannelBusiness(returnFullResponse: boolean) {
    const url: any = this.apiUrl.OLD_COMPANY;
    return this._accountService.getAccountListService(url, returnFullResponse)
      .map(res => {
        return res;
      });
  }

  // Get Old Channel for Account Setup Trade Information
  getOldChannelTradeBusiness(returnFullResponse: boolean) {
    const url: any = this.apiUrl.OLD_TRADE_INFORMATION;
    return this._accountService.getAccountListService(url, returnFullResponse)
      .map(res => {
        return res;
      });
  }

  getUserTypeProfileBusiness() {
    const url: any = this.apiUrl.PROFILE;
    return this._accountService.getAccountListService(url)
      .map(res => {
        return res;
      });
  }

  getChannelStatusIDBusiness() {
    const url: any = this.apiUrl.GETUSERSTATUS;
    return this._accountService.getAccountListService(url)
      .map(res => {
        return res;
      });
  }

  // Trade Information

  getTradeinfo(returnFullResponse: boolean) {
    const url: any = this.apiUrl.POST_TRADEINFORMATION;
    return this._accountService.getAccountListService(url, returnFullResponse)
      .map(res => {
        return res;
      });
  }

  // Customer Profile Search
  getCustomerProfile(name: string, channelId: number) {
    const url = this.apiUrl.CUSTOMER_PROFILE;
    return this._accountService.getradeInfoGetcustomerProfile(url, channelId, name).map(res => {
      return res;
    });
  }

  // List of Service Search
  getListService(searchkey: string) {
    const url = this.apiUrl.LIST_SERVICE;
    return this._accountService.getradeInfoGetService(searchkey, url).map(res => {
      return res;
    });
  }

  // Product Family
  getProductFamily(searchkey: string, returnFullResponse: boolean = false) {
    const url = this.apiUrl.PRODUCT_FAMILY;
    return this._accountService.getradeInfoGetService(searchkey, url, returnFullResponse).map(res => {
      return res;
    });
  }

  // Product Family
  getProductCategory(searchkey: string, subsearchkey: string, returnFullResponse: boolean = false) {
    const url = this.apiUrl.PRODUCT_CATEGORY;
    return this._accountService.getradeInfoGetsubService(searchkey, url, subsearchkey, returnFullResponse).map(res => {
      return res;
    });
  }

  // Brand List Tradeinfo
  gettradeBrandList(name: string, channelId: number) {
    const url = this.apiUrl.CHANNEL_BRAND;
    return this._accountService.getradeInfobrand(url, channelId, name).map(res => {
      return res;
    });
  }

  // Brand List
  getBrandList(name: string, channelId: number) {
    const url = this.apiUrl.CHANNEL_BRAND;
    return this._accountService.getradeInfoGetcustomerProfile(url, channelId, name).map(res => {
      return res;
    });
  }

  //  Brand duplication
  getbrandDuplication(name: string) {
    const url: string = this.apiUrl.BRAND_DUPLICATION + '/' + name;
    return this._accountService.getAccountListServiceHttpClient(url).map(res => {
      return res;
    });
  }

  // Account Setup - Trade Location
  getChannelLocation(channelId: number) {
    const url: string = this.apiUrl.GETCHANNELLOCATION + '/' + channelId;
    return this._accountService.getAccountListServiceHttpClient(url).map(res => {
      return res;
    });
  }

  // Distributed and retailer based Customer Type
  getCustomerType(searchkey: string) {
    const url = this.apiUrl.CUSTOMER_TYPE;
    return this._accountService.getradeInfoCustomerTypeService(searchkey, url).map(res => {
      return res;
    });
  }

  searchZoneRegionCompanyBusiness(zoneID_list) {
    const url: any = this.apiUrl.LOCATION_ZONE_REGION_SEARCH;
    return this._accountService.postAccountService(zoneID_list, url).map(res => {
      return res;
    });
  }

  searchHttpZoneRegionCompanyBusiness(zoneID_list) {
    const url: any = this.apiUrl.LOCATION_ZONE_REGION_SEARCH;
    return this._accountService.postAccountServiceHttpClient(zoneID_list, url).map(res => {
      return res;
    });
  }

  searchZoneCountryCompanyBusiness(regionID_list) {
    const url: any = this.apiUrl.LOCATION_ZONE_COUNTRY_SEARCH;
    return this._accountService.postAccountService(regionID_list, url).map(res => {
      return res;
    });
  }

  searchHttpZoneCountryCompanyBusiness(regionID_list) {
    const url: any = this.apiUrl.LOCATION_ZONE_COUNTRY_SEARCH;
    return this._accountService.postAccountServiceHttpClient(regionID_list, url).map(res => {
      return res;
    });
  }

  saveLocationCountry(Counrty_list) {
    const url: any = this.apiUrl.LOCATION_COUNTRY_SAVE;
    return this._accountService.postAccountService(Counrty_list, url).map(res => {
      return res;
    });
  }

  saveHttpLocationCountry(Counrty_list) {
    const url: any = this.apiUrl.LOCATION_COUNTRY_SAVE;
    return this._accountService.postAccountServiceHttpClient(Counrty_list, url).map(res => {
      return res;
    });
  }

  getKeyRetailerSearch(search: string, partnertype: string) {
    let params = new HttpParams();
    params = params.set('search', search);
    params = params.set('partner_type', partnertype);
    const url: any = this.apiUrl.KEYRETAILER_SEARCH + '?' + params;
    return this._accountService.getAccountListService(url, true).map(res => {
      return res;
    });
  }

}
