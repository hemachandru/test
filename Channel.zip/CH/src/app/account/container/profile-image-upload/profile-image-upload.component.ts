import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-image-upload',
  templateUrl: './profile-image-upload.component.html',
  styleUrls: ['./profile-image-upload.component.scss']
})
export class ProfileImageUploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
