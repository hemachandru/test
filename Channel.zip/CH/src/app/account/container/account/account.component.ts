import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { Config, UserAccountStatus } from '@app/config/constant';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})

export class AccountComponent implements OnInit {
  // profilePercentage :any = ;
  profilePercentage: number;
  srcCompanyLogo: string;
  tabBoolProfile: boolean;
  tabBoolInfo: boolean;
  tabBoolLoc: boolean;
  // statusCheck:boolean = true;
  // statusCheckInfo:boolean = true;
  // statusCheckLoc:boolean = true;
  // selectSharedTooltipMessage: string =;
  userStatus: string;
  constructor(private router: Router, private Const: Config, private activeRoute: ActivatedRoute, private data: AccountDataService) {
    this.initLoad();
  }

  ngOnInit() {
    if (!this.data) {
      this.data = new AccountDataService();
    }
    this.initLoad();
  }

  initLoad() {
    this.srcCompanyLogo = '';
    this.userStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    this.data.currentMessage.subscribe(message => this.profilePercentage = message);
    this.data.currentImageUrl.subscribe(image => { this.srcCompanyLogo = image; });
    this.data.currentBoolProfile.subscribe(flag => this.tabBoolProfile = flag);
    this.data.currentBoolTrade.subscribe(flag => this.tabBoolInfo = flag);
    this.data.currentBoolInfo.subscribe(flag => this.tabBoolLoc = flag);
    this.statusCheckFunc();
  }

  statusCheckFunc() {
    if (parseInt(this.userStatus, 10) === UserAccountStatus.ACCOUNTSETUP) {
      this.tabBoolProfile = true;
      this.tabBoolInfo = false;
      this.tabBoolLoc = false;
    } else if (parseInt(this.userStatus, 10) === UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION) {
      this.tabBoolProfile = false;
      this.tabBoolInfo = true;
      this.tabBoolLoc = false;
    } else if (parseInt(this.userStatus, 10) === UserAccountStatus.ACCOUNTSETUP_TRADELOCATION) {
      this.tabBoolProfile = false;
      this.tabBoolInfo = false;
      this.tabBoolLoc = true;
    }
  }

  updatePercent(percentage: any) {
    this.profilePercentage = percentage;
  }
}
