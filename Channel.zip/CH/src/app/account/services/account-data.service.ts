import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { imageAction } from './../models/profile';
@Injectable()
export class AccountDataService {

  private messageSource = new BehaviorSubject<number>(0);
  private imgSource = new BehaviorSubject<string>('/assets/images/pro-logo.jpg');
  private imgSourceIcon = new BehaviorSubject<imageAction>({data: '/assets/images/pro-logo.jpg' , action: false});
  private tabBoolProfile = new BehaviorSubject<boolean>(false);
  private tabBoolInfo = new BehaviorSubject<boolean>(false);
  private tabBoolLoc = new BehaviorSubject<boolean>(false);
  private imgProfile = new BehaviorSubject<string>('');
  private jobTitle = new BehaviorSubject<string>('');

  currentMessage = this.messageSource.asObservable();
  currentImageUrl = this.imgSource.asObservable();
  currentFaviconUrl = this.imgSourceIcon.asObservable();
  currentBoolProfile = this.tabBoolProfile.asObservable();
  currentBoolTrade = this.tabBoolInfo.asObservable();
  currentBoolInfo = this.tabBoolLoc.asObservable();
  currentProfileImg = this.imgProfile.asObservable();
  currentJobTitle = this.jobTitle.asObservable();
  constructor() { }

  changeMessage(message: number) {
    this.messageSource.next(message);
  }

  changeImageUrl(data: string) {
    this.imgSource.next(data);
  }

  changeFaviconUrl(data: imageAction) {
    this.imgSourceIcon.next(data);
  }

  changeBoolProfile(flag: boolean) {
    this.tabBoolProfile.next(flag);
  }

  changeBoolTrade(flag: boolean) {
    this.tabBoolInfo.next(flag);
  }

  changeBoolLoc(flag: boolean) {
    this.tabBoolLoc.next(flag);
  }

  changeProfileImg(profile: string) {
    this.imgProfile.next(profile);
  }

  changeJobTitle(job: string) {
    this.jobTitle.next(job);
  }
}
