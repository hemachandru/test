import { Injectable } from '@angular/core';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { HttpParams, HttpClient } from '@angular/common/http';
import { IfObservable } from 'rxjs/observable/IfObservable';
import { IRequestOptions } from '../../communication/services/Interface/IRequestOptions';


@Injectable()
export class AccountService {

  private _option = <IRequestOptions>{};

  constructor(private _httpRequestService: HttpRequestService, ) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  getAccountListService(url: string, returnFullResponse: boolean = false) {
    return this._httpRequestService.getHttpRequest(url, returnFullResponse);
  }

  getAccountListServiceHttpClient(url: string) {
    return this._httpRequestService.getHttpClientRequest(url, this._option);
  }

  postAccountService(dataparams: any, url: string, returnFullResponse: boolean = false) {
    return this._httpRequestService.postHttpRequest(dataparams, url, returnFullResponse);
  }

  postAccountServiceHttpClient(dataparams: any, url: string) {
    return this._httpRequestService.postHttpClientRequest(url, dataparams, this._option);
  }

  putTradeinfoService(dataparams: any, url: string, returnFullResponse: boolean = false) {
    return this._httpRequestService.putHttpRequest(dataparams, url, returnFullResponse);
  }

  getradeInfoGetService(searchparams: any, url: string, returnFullResponse: boolean = false) {
    let params = new HttpParams();
    params = params.set('name', searchparams);
    return this._httpRequestService.getHttpRequestWithQueryString(params, url, returnFullResponse);
  }

  getradeInfoGetcustomerProfile(url: string, channelId: any, name: any) {
    let params = new HttpParams();
    params = params.set('channelTypeId', channelId);
    params = params.set('name', name);
    return this._httpRequestService.getHttpRequestWithSubQueryString(params, url);
  }

  getradeInfobrand(url: string, channelId: any, name: any) {
    let params = new HttpParams();
    params = params.set('channelTypeId', channelId);
    params = params.set('name', name);
    params = params.set('limit', '50');
    return this._httpRequestService.getHttpRequestWithSubQueryString(params, url);
  }

  getradeInfoGetsubService(searchparams: any, url: string, searchsubparams: any, returnFullResponse: boolean = false) {
    let params = new HttpParams();
    params = params.set('productFamilyId', searchsubparams);
    params = params.set('name', searchparams);
    return this._httpRequestService.getHttpRequestWithSubQueryString(params, url, returnFullResponse);
  }

  getradeInfoCustomerTypeService(searchparams: any, url: string) {
    let params = new HttpParams();
    params = params.set('channelTypeId', searchparams);
    return this._httpRequestService.getHttpRequestWithQueryString(params, url);
  }
}

