import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Profile, MultiCertificate, Certificate, Certify, ProfileAddress } from './../../models/profile';


@Component({
  selector: 'app-add-certificate',
  templateUrl: './add-certificate.component.html',
  styleUrls: ['./add-certificate.component.scss']
})

export class AddCertificateComponent implements OnInit {

  @Input()
  public index: number;

  @Input()
  public item: FormGroup;

  @Output()
  public removed: EventEmitter<number> = new EventEmitter<number>();

  static buildItem(val: string) {
    let controls = {};
     controls = {
      name: new FormControl(val, Validators.required),
      quantity: new FormControl(100)
  };

return new FormGroup(controls);

    // return new FormGroup({
    //   name: new FormControl(val, Validators.required),
    //   quantity: new FormControl(100)
    // });
}
  constructor(private fb: FormBuilder) {

   }

  ngOnInit() {
    // this.certificateForm = this.fb.group({
    //   customerName: '',
    //   email: '',
    //   items: this.fb.array([ this.createItem() ])
    // });
  }

}
