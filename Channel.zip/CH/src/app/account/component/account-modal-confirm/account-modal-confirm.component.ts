import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { Zone, ZoneDTO, CustomRegion } from '@app/account/models/location';
import { FormControl } from '@angular/forms/src/model';
import { FormGroup } from '@angular/forms';
import { Response } from '@angular/http';

@Component({
  selector: 'app-account-modal-confirm',
  templateUrl: './account-modal-confirm.component.html',
  styleUrls: ['./account-modal-confirm.component.scss']
})
export class AccountModalConfirmComponent implements OnInit {
  public zoneListBindable: ZoneDTO[] = [];
  public countryMultiple = true;
  public countryId: any = [];
  public loading = false;
  public countryDrop: any = 0;
  public customRegion: CustomRegion = new CustomRegion();
  public regionName: FormControl;
  createCustomRegion: FormGroup;

  constructor(
    private accountBusiness: AccountBusiness,
    public dialogRef: MatDialogRef<AccountModalConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.data.firstName = '';
    document.getElementsByTagName('html').item(0).style.setProperty('top', '0px');
    this.getSellingZone();
  }

  onZoneChange(value: string) {
    this.customRegion.zoneId = parseInt(value, null);
  }

  getSellingZone() {
    try {
      this.loading = true;
      const resetMessage = this.accountBusiness.getSellingZoneBusiness().subscribe((result: ZoneDTO[]) => {
        if (result) {
          this.loading = false;
          result.forEach(zone => {
            const mapped = false;
            this.zoneListBindable.push({ zoneId: zone.zoneId, zone: zone.zone, region: null, isMapped: mapped });
          });
          this.loading = false;
        }
      },
        (error) => {
          this.loading = false;
          console.log(error);
        });
    } catch (error) {
      console.log(error);
    }
  }

  scaleDropdownOutside() {
    if (this.countryDrop === 1) {
      this.countryDrop = 0;
    } else {
      this.countryDrop = 1;
    }
  }

  scaleDropdown() {
    if (this.countryDrop === 0) {
      this.countryDrop = 1;
    } else {
      this.countryDrop = 0;
    }
  }


  saveCustomRegion(title: string) {
    this.customRegion.region = title;
    const data = {
      'zoneId': this.customRegion.zoneId,
      'countryId': this.customRegion.countryId,
      'region': this.customRegion.region
    };

    try {
      this.loading = true;
      const resetMessage = this.accountBusiness.postCreateCustomRegion(data).subscribe(result => {

        const response = result as Response;
        if (response.ok) {
          // console.log(result.json());
        }
      },
        (error) => {
          this.loading = false;
          console.log(error);
        });
    } catch (error) {
      console.log(error);
    }
  }

  public async getContryID(data: string): Promise<any> {
    this.countryId = data;
    this.customRegion.countryId = this.countryId;
  }

  close() {
    this.dialogRef.close(this.data);
  }
}
