import { Component, OnInit, Input, AfterViewInit, ViewChild, ElementRef  } from '@angular/core';
import { Country } from '@app/account/models/location';
import { GoogleChart } from '@app/shared/directives/angular2-google-chart.directive';


@Component({
  selector: 'app-location-map',
  templateUrl: './location-map.component.html',
  styleUrls: ['./location-map.component.scss']
})

export class LocationMapComponent implements AfterViewInit {

  @ViewChild('map_chart') map_chart: ElementRef;

  @ViewChild(GoogleChart) googleChart: GoogleChart;

  @Input() mapCountryListData = [];

  // public map_ChartDatas = [];

  public map_ChartData = [
    ['Country']
  ];

public map_ChartOptions = {};
  public org_ChartOptions = {
      // allowHtml: true,
      defaultColor: '#7fa3bb'
  };
  constructor() { }

  ngAfterViewInit() {
     // this.map_chart.nativeElement.click();
  }

  setMap(country: Country[]) {

    this.map_ChartData = [
      ['Country']
    ];

    country.forEach(cntry => {
      this.map_ChartData.push([cntry.country]);
    });

    this.refreshMap();

  }

  async refreshMap(): Promise<any> {
    this.googleChart.onResize(event);
  }

}
