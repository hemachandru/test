import { Component, OnInit, Input, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { CommonHelper } from '@app/shared/common-helper';
import { BrandListPost, MultiCertificate } from '@app/account/models/profile';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Config } from '@app/config/constant';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ToastrService } from 'ngx-toastr';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { TranslateService } from '@ngx-translate/core';
import { KeyRetailerSelectedList } from '@app/account/models/trade-information';
@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.component.html',
  styleUrls: ['./add-brand.component.scss']
})
export class AddBrandComponent implements OnInit {
  public templocation: any;
  public folderName: string;
  public brandimg: any;
  public profileImgErr: any;
  public brandimgkey: any;
  public isImageError = false;
  public popupbrand: any;
  public loading = false;
  public brandname = false;
  public keyRetailerForm: FormGroup;
  public getCountryIdReg: number;
  public regCountry: string;
  public defaultConfig: MultiCertificate;
  public errorCountry: string;
  public ctrlCountry: string;
  public opts: ISlimScrollOptions;
  textmaxErr: string;
  constructor(public dialogRef: MatDialogRef<AddBrandComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private Const: Config,
    private uploadService: UploadFileService, private formbuilder: FormBuilder, private toastr: ToastrService,
    private accountBusiness: AccountBusiness,
    private translate: TranslateService, private fb: FormBuilder) {
    this.folderName = 'contact-s3/';
  }

  ngOnInit() {
    this.opts = {
      barBackground: 'trasparent',
      gridBackground: 'trasparent',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this.getCountryIdReg = 0;
    this.defaultConfig = new MultiCertificate();
    document.getElementsByTagName('html').item(0).style.setProperty('top', '0px');
    if (this.data.type === 2) {
      this.formValidators();
      this.errorCountry = '';
      this.ctrlCountry = 'country';
    }
  }

  // file upload
  async accountBrandUpload(event, urlLink) {
    const selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    if (file) {
      const fileName = file.name;
      let fileExtension = fileName.substr((fileName.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString().toLowerCase();
      if (fileExtension === 'jpeg' || fileExtension === 'jpg' || fileExtension === 'png') {
        if (CommonHelper.checkValidImageSize(file.size)) {
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            img.src = event.target.result;
            img.onload = async function () {
              self.loading = true;
              // img.width >= 300 && img.height >= 300 && img.width <= 400 && img.height <= 400
              if (img) {
                const resImagePath: any = await self.uploadService.uploadfile(file, self.folderName);
                self.brandimgkey = resImagePath.Key;
                self.templocation = event.target.value;
                self.brandimg = event.target.result;
                if (self.brandimgkey) {
                  self.profileImgErr = self.translate.instant('commonError.imageSucess');
                  self.isImageError = true;
                  self.loading = false;
                } else {
                  self.isImageError = false;
                  self.profileImgErr = self.translate.instant('commonError.imageuploadError');
                  self.brandimg = '';
                }
              } else {
                self.isImageError = false;
                self.profileImgErr = self.translate.instant('commonError.validImage');
                self.brandimg = '';
              }
              self.loading = false;
            };
          };
          reader.readAsDataURL(event.target.files[0]);
        } else {
          this.brandimg = '';
          this.isImageError = false;
          this.profileImgErr = this.translate.instant('commonError.imagesizexceed');
        }
      } else {
        this.isImageError = false;
        this.profileImgErr = this.translate.instant('commonError.correctFormat');
        this.brandimg = '';
      }
    }
  }

  // Set Country with Registration Id
  public async getContryID(data: string): Promise<any> {
    // this.profileAdd.countryId = parseInt(data, 10);
    this.getCountryIdReg = (data === 'null') ? 0 : parseInt(data, 10);
    if (this.getCountryIdReg === 0) {
      this.errorCountry = '0002';
    } else {
      this.errorCountry = '';
    }
  }

  add(name, img) {
    if (this.validation()) {
      this.accountBusiness.getbrandDuplication(name).subscribe(result => {
        const response = result as Response;
        if (response.ok) {
          this.popupbrand = {
            id: 0,
            name: name,
            documentPath: this.brandimgkey,
            temppath: this.brandimg
          };
          this.dialogRef.close(this.popupbrand);
        }
      },
        (error) => {
          this.toastr.error(this.translate.instant('tradeinformation.validationMessage.sameBrand'));
          this.popupbrand = {};
          this.dialogRef.close(this.popupbrand);
        });
    }
  }

  close() {
    this.dialogRef.close(this.data);
  }

  validation(): boolean {
    let returnVal = true;
    if ((ValidationService.isNullOrEmpty(this.data.name))) {
      // this.data.name = this.data.name; Sonar bug
      returnVal = false;
    }
    if (this.data.name.length >= 255) {
      this.textmaxErr = 'Maximum Value Should Be 255';
      returnVal = false;
    } else {
      this.textmaxErr = '';
    }

    if ((ValidationService.isNullOrEmpty(this.brandimgkey))) {
      this.profileImgErr = this.translate.instant('tradeinformation.validationMessage.uploadBrandImage');
      returnVal = false;
    } else {
      this.profileImgErr = '';
    }

    return returnVal;
  }

  formValidators() {
    this.keyRetailerForm = this.fb.group({
      retailerName: [this.data.name, Validators.compose([Validators.required, Validators.maxLength(255)])],
    });
  }

  keyRetailerClose(boolClose) {
    this.data.boolClose = boolClose;
    if (boolClose) {
      this.data.keyretailer = {
        channelId: null,
        oldchannelId: null,
        companyName: this.keyRetailerForm.controls['retailerName'].value,
        country: this.getCountryIdReg,
        documentPath: this.brandimgkey,
        documentUrl: this.brandimg,
        keypartnerid: null,
        oldchannelid: null,
        channelid: null,
        countryid: this.getCountryIdReg,
        partnername: this.keyRetailerForm.controls['retailerName'].value,
        existchannelid: null
      } as KeyRetailerSelectedList;
      if (this.keyRetailerForm.invalid || this.getCountryIdReg === 0) {
        if (this.keyRetailerForm.invalid) {
          this.keyRetailerForm.controls['retailerName'].markAsTouched();
        }
        if (this.getCountryIdReg === 0) {
          this.errorCountry = '0002';
        }
        return false;
      }
    }
    this.dialogRef.close(this.data);
  }
}
