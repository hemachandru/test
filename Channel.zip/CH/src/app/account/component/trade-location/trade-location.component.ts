import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { AccountModalConfirmComponent } from '../account-modal-confirm/account-modal-confirm.component';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { LocationMapComponent } from '../location-map/location-map.component';
import { ScrollToService } from 'ng2-scroll-to-el';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import 'rxjs/add/observable/throw';
import {
  Country, Zone, ZoneDTO, Region, LocationSearchRegionDTO,
  LocationSearchCountryDTO, LocationCountrySaveDTO,
} from '@app/account/models/location';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { ActivatedRoute, Router } from '@angular/router';
import { ChannelTypeIdEnum, UserAccountStatus, TradeLocationTitle, AccessPermissionEnum } from '@app/config/constant';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ToastrService } from 'ngx-toastr';
import { FeatureAccessEnum, AWSUrl, TradeLocFrameOption } from '@app/config/constant';
import { TranslateService } from '@ngx-translate/core';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-trade-location',
  templateUrl: './trade-location.component.html',
  styleUrls: ['./trade-location.component.scss']
})

export class TradeLocationComponent implements OnInit, AfterViewInit {

  public locationKey: string; // default value

  public toggle: boolean;

  public opts: ISlimScrollOptions;

  public regionData: Region[] = [];

  public regionUnMappedData: Region[] = [];

  public countryData: Country[] = [];

  public countryUnmappedData: Country[] = [];

  public countryMapData: string[] = [];

  private channelLocation: any = [];

  private channelLocationByTrade: any = [];

  private locationByTrade: any;

  public zoneListBindable: ZoneDTO[] = [];

  private zoneMapped: any;

  private zoneID_list: any = {};

  private region_list: any[] = [];

  private country_list: any[] = [];

  private channelId: number;

  public loading = false;

  public locationScale: Boolean = false;

  private zoneIDs = [];

  private regionIDs = [];

  public channelTypeId: number = ChannelTypeIdEnum.VENDOR; // default vendor

  public locationTitle: any;

  isRedirect: boolean;

  public targetStatus: boolean;
  public sellingStatus: boolean;

  formMessage: string;
  isZoneLimted: boolean;
  isTargetSaved: boolean;

  // Region/Country pre fill flag
  isPreFillRegion: boolean;
  isPreFillCountry: boolean;

  @ViewChild(LocationMapComponent) locationMapComponent: LocationMapComponent;
  locationurl: string;
  first_load: boolean;

  constructor(private dialog: MatDialog, private accountBusiness: AccountBusiness, private dataBinding: AccountDataService,
    private route: ActivatedRoute, private router: Router, private authorizeService: AuthorizeService
    , private toastr: ToastrService, private scrollService: ScrollToService, private translate: TranslateService) {
    this.isZoneLimted = false;
    this.isTargetSaved = false;
    this.isPreFillRegion = false;
    this.isPreFillCountry = true;
    if (!this.channelId) {
      this.initLoad();
    }
    this.locationurl = environment.AWS_DOWNLOAD_URL + AWSUrl.PRODUCT_LOCATION;
  }

  initLoad() {
    this.first_load = true;
    // console.log('Init loaded');
    this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
    this.isRedirect = true;
    this.toggle = false;
    this.targetStatus = false;
    this.locationTitle = { 'locTitle': TradeLocationTitle.LOCATION_TITLE_TARGET };
    this.sellingStatus = true;
    this.formMessage = '';
    this.locationKey = TradeLocationTitle.LOCATION_KEY_TARGET;

    this.isRedirect = this.route.snapshot.data.redirect;

    const channelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    if (channelId) {
      this.channelId = channelId != '' ? parseFloat(channelId) : 0;
    }

    const channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);

    if (channelType) {
      this.channelTypeId = channelType != '' ? parseFloat(channelType) : ChannelTypeIdEnum.VENDOR; // default vendor
    }

    if (this.channelTypeId === ChannelTypeIdEnum.RETAILER) {
      this.locationTitle = { 'locTitle': '' };
      this.locationKey = TradeLocationTitle.LOCATION_KEY_RETAIL;
    }

    this.getChannelLocation();

    if (this.isRedirect === true) {
      this.targetStatus = false;
      this.sellingStatus = false;
    }

  }

  ngOnInit() {
    this.dataBinding.changeBoolProfile(false);
    this.dataBinding.changeBoolTrade(false);
    this.dataBinding.changeBoolLoc(true);
    this.opts = TradeLocFrameOption;
    if (!this.channelId) {
      this.initLoad();
    }

  }

  ngAfterViewInit() {
    console.log(`ngAfterViewInit - jokeViewChild is ${this.locationMapComponent}`);
  }

  private async getLocationDataBtnClick(): Promise<any> {
    this.first_load = true;
    this.zoneIDs = [];
    this.zoneListBindable = [];
    this.regionData = [];
    this.regionUnMappedData = [];
    this.countryData = [];
    this.countryUnmappedData = [];
    if (this.isRedirect === false) {
      // console.log("this.isTargetSaved", this.isTargetSaved);
      if (this.isTargetSaved === true) {
        this.targetStatus = true;
        this.sellingStatus = true;
      } else if (this.locationKey === TradeLocationTitle.LOCATION_KEY_TARGET) {
        this.targetStatus = false;
        this.sellingStatus = true;
        // Specific business rule as per BA
        this.zoneListBindable = this.zoneListBindable.filter(rl => rl.zone == 'EMEA');
      } else if (this.locationKey === TradeLocationTitle.LOCATION_KEY_SELLING) {
        this.sellingStatus = false;
        this.targetStatus = true;
      }
    }

    if (this.locationKey === TradeLocationTitle.LOCATION_KEY_TARGET) {
      this.initLoad();
      this.locationTitle = { 'locTitle': TradeLocationTitle.LOCATION_TITLE_TARGET };
    } else if (this.locationKey === TradeLocationTitle.LOCATION_KEY_SELLING) {
      this.locationTitle = { 'locTitle': TradeLocationTitle.LOCATION_TITLE_SELLING };
      this.getLocationByTrade(this.locationKey);
    }

  }

  private async getLocationByTrade(locationkey: string): Promise<any> {
    if (this.channelLocation) {
      this.channelLocationByTrade = this.channelLocation[this.locationKey];
    }
    this.getSellingZone();
    this.getMppedData();
  }

  private async getChannelLocation(): Promise<any> {
    try {
      this.loading = true;
      if (this.channelId) {
        const loadLocation = this.accountBusiness.getChannelLocation(this.channelId).subscribe(result => {
          const response = result as Response;
          if (response.ok) {
            this.loading = false;
            const locationCollection = result.body;

            if (locationCollection.currentLocation && locationCollection.currentLocation.TARGET.length > 0) {
              this.channelLocation.TARGET = locationCollection.currentLocation.TARGET;
            } else if (locationCollection.oldLocation) {
              this.channelLocation.TARGET = locationCollection.oldLocation.TARGET;
            }

            if (locationCollection.currentLocation && locationCollection.currentLocation.SELLING.length > 0) {
              this.channelLocation.SELLING = locationCollection.currentLocation.SELLING;
            } else if (locationCollection.oldLocation) {
              this.channelLocation.SELLING = locationCollection.oldLocation.SELLING;
            }

            if (locationCollection.currentLocation && locationCollection.currentLocation.RETAIL.length > 0) {
              this.channelLocation.RETAIL = locationCollection.currentLocation.RETAIL;
            } else if (locationCollection.oldLocation) {
              this.channelLocation.RETAIL = locationCollection.oldLocation.RETAIL;
            }

            if (locationCollection.currentLocation && locationCollection.currentLocation.TARGET.length > 0) {
              // console.log("this.channelLocation",this.channelLocation);
              this.isTargetSaved = true;
              this.targetStatus = true;
              this.sellingStatus = true;
            }

            this.getLocationByTrade(this.locationKey);
          }
        },
          (error) => {
            this.loading = false;
            console.log('Error on get channel location info');
          });
      }
    } catch (error) {
      console.log('Error on getChannelLocation(): ' + error);
    }
  }

  private async getSellingZone(): Promise<any> {
    try {
      this.loading = true;
      const resetMessage = this.accountBusiness.getSellingZoneBusiness().subscribe(result => {
        const response = result as Response;
        if (response.ok) {
          // const zone: ZoneDTO[] = result;
          // console.log('result', result);
          this.loading = false;
          result.body.forEach(zone => {
            let mapped = false;

            if (this.zoneExists(this.channelLocationByTrade, zone) == true) {
              mapped = true;
              this.zoneIDs.push(parseInt(zone.zoneId, null));
            }

            this.zoneListBindable.push({ zoneId: zone.zoneId, zone: zone.zone, region: null, isMapped: mapped });
            // Specific business rule as per BA
            if (this.locationKey === TradeLocationTitle.LOCATION_KEY_TARGET) {
              this.zoneListBindable = this.zoneListBindable.filter(rl => rl.zone == 'EMEA');
            }
          });
          this.getUnmappedRegionData(this.zoneIDs, false);

          this.loading = false;
        }
      },
        (error) => {
          this.loading = false;
          console.log(error);
        });
    } catch (error) {
      console.log(error);
    }
  }

  private zoneExists(channelLocationByTrade: Zone[], zone: Zone) {
    let exists: Boolean = false;
    if (this.channelLocationByTrade) {
      channelLocationByTrade.forEach(zonS => {
        if (zonS.zoneId == zone.zoneId) {
          return exists = true;
        }
      });
    }
    return exists;
  }

  private async getMppedData(): Promise<any> {
    this.regionData = [];
    this.countryData = [];
    this.zoneIDs = [];
    this.regionIDs = [];
    if (this.channelLocationByTrade) {
      this.channelLocationByTrade.forEach((zone: Zone) => {
        this.zoneIDs.push(parseInt(zone.zoneId.toString(), null));
        zone.region.forEach(region => {
          this.regionData.push(region);
          region.country.forEach(country => {
            this.countryData.push(country);
          });
        });
      });

      this.regionData.forEach(reg => {
        this.regionIDs.push(reg.regionId);
      });

      this.getUnmappedCountryData(this.zoneIDs, this.regionIDs);
    }
    this.locationMapComponent.setMap(this.countryData);
  }

  private async getUnmappedRegionData(zoneIds, isZoneChecked): Promise<any> {
    this.regionUnMappedData = [];
    const locationSearch: LocationSearchRegionDTO = new LocationSearchRegionDTO();
    locationSearch.zone = zoneIds;
    locationSearch.region = '';
    locationSearch.locationType = this.locationKey;
    if (isZoneChecked == true) {
      locationSearch.exclude = false;
    } else {
      locationSearch.exclude = true;
    }
    // this.loading = true;
    // console.log('locationSearch', locationSearch);
    this.accountBusiness.searchHttpZoneRegionCompanyBusiness(locationSearch).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.loading = false;
        const regionCompany = result.body;
        // console.log('regionCompany', regionCompany);
        regionCompany.forEach(zone => {
          if (zone.region) {
            zone.region.map((region: Region) => {
              this.regionIDs.push(region.regionId);
              // For preload data
              if (isZoneChecked == true) {
                this.loadRegions(region);
              } else {
                this.regionUnMappedData.push(region);
              }
            });
          }
        });
        if (isZoneChecked == true) {
          this.getUnmappedCountryData(this.zoneIDs, this.regionIDs);
        }
        if (!this.first_load && this.locationKey === TradeLocationTitle.LOCATION_TITLE_SELLING.toUpperCase()) {
          const unmappedRegion = JSON.parse(localStorage.getItem('selected_region'));
          if (unmappedRegion) {
            unmappedRegion.forEach(region => {
              this.regionUnMappedData = this.regionUnMappedData.filter(item => item.regionId != region.regionId);
            });
          }
        }
        this.first_load = false;

      } else {
        this.loading = false;
        console.log('Api resulted error: ', result);
      }
    },
      (error) => {
        this.loading = false;
        console.log(error);
      });
  }

  private async getUnmappedCountryData(zoneIds, regionIds): Promise<any> {
    this.countryUnmappedData = [];
    const locationSearch: LocationSearchCountryDTO = new LocationSearchCountryDTO();
    locationSearch.zone = zoneIds;
    locationSearch.region = regionIds;
    locationSearch.country = '';
    locationSearch.locationType = this.locationKey;
    this.loading = true;
    this.accountBusiness.searchHttpZoneCountryCompanyBusiness(locationSearch).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.loading = false;
        const zoneCountry: Zone[] = result.body;
        zoneCountry.forEach(zone => {
          if (zone.region) {
            const countryData = this.countryData;
            zone.region.forEach(region => {
              if (region.country) {
                region.country.forEach(country => {
                  this.countryUnmappedData = this.countryUnmappedData.filter(item => item.countryId != country.countryId);
                  this.countryUnmappedData.push(country);
                });
              }
            });
            // console.log('this.countryUnmappedData');
            countryData.forEach(country => {
              this.countryUnmappedData = this.countryUnmappedData.filter(cntry => cntry.RegionCountryJCT.countryId
                != country.RegionCountryJCT.countryId);
            });
          }
        });
      } else {
        console.log('Api resulted error: ', result);
      }
    },
      (error) => {
        this.loading = false;
        console.log(error);
      });
  }

  private async checkZone(event): Promise<any> {
    this.loading = true;
    const chkZone = event.target.id;
    if (event.target.checked == true) {
      this.zoneIDs = this.zoneIDs.filter(item => item != chkZone);
      const chkZoneID = parseInt(chkZone, null);
      this.zoneIDs.push(chkZoneID);
      // For preloading data
      this.getUnmappedRegionData(this.zoneIDs, this.isPreFillRegion);
    } else if (event.target.checked == false) {
      this.zoneIDs = this.zoneIDs.filter(zoneid => zoneid != chkZone);
      let ZoneDel: Zone[];
      if (this.channelLocationByTrade) {
        ZoneDel = this.channelLocationByTrade.filter(zone => zone.zoneId == chkZone);
        if (ZoneDel.length > 0) {
          this.zoneDelete(ZoneDel[0]);
        }
      }

      this.regionDeleteUnMapped(chkZone);
      this.regionDeleteMapped(chkZone);
      this.loading = false;
    }
    this.zoneIDs = Array.from(new Set(this.zoneIDs));
    // this.getUnmappedRegionData(this.zoneIDs);

  }

  public openAccountModalDialog(data): void {
    const dialogRef = this.dialog.open(AccountModalConfirmComponent, {
      data
    });

    dialogRef.afterClosed().subscribe(result => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    });
  }

  public optionRegionSelected(item: Region) {
    this.regionData.push(item);
    this.regionUnMappedData = this.regionUnMappedData.filter(delItem => delItem.regionId != item.regionId);

    if (this.isPreFillCountry === true) {
      item.country.forEach(element => {
        this.optionCountrySelected(element, false);
      });
    }
    // To Load Unmapped country data
    let locregionIDs = [];
    this.regionData.forEach(rgn => {
      locregionIDs.push(rgn.regionId);
    });
    this.regionIDs = this.regionIDs.filter(itm => itm != item.regionId);
    this.regionIDs.push(item.regionId);
    locregionIDs = locregionIDs.filter(itm => itm != item.regionId);
    locregionIDs.push(item.regionId);
    this.getUnmappedCountryData(this.zoneIDs, locregionIDs);
    if (this.locationKey === TradeLocationTitle.LOCATION_TITLE_SELLING.toUpperCase()) {
      localStorage.setItem('selected_region', JSON.stringify(this.regionData));
    }
    this.locationMapComponent.setMap(this.countryData);
  }

  private loadRegions(item: Region) {
    this.regionData.push(item);
    this.regionUnMappedData = this.regionUnMappedData.filter(delItem => delItem.regionId != item.regionId);

    item.country.forEach(element => {
      this.optionCountrySelected(element, false);
    });

    this.locationMapComponent.setMap(this.countryData);
  }

  public async clickData(data: string): Promise<any> {
    // this.testData = data;
    // console.log('Region : ', this.testData);
  }

  public async clickCountryData(data: string): Promise<any> {
    // this.testData = data;
  }
  public optionCountrySelected(item: Country, isUserInteract: boolean) {
    this.countryData.push(item);
    this.countryUnmappedData = this.countryUnmappedData.filter(delItem => delItem.countryId != item.countryId);
    if (isUserInteract == true) {
      this.locationMapComponent.setMap(this.countryData);
    }
  }

  async zoneDelete(item: Zone) {
    if (item && item.zone) {
      item.region.forEach(region => {
        region.country.forEach(country => {
          this.countryData = this.countryData.filter(delItem => delItem.countryId != country.countryId);
          this.countryUnmappedData = this.countryUnmappedData.filter(delItem => delItem.countryId != country.countryId);
          // this.locationMapComponent.setMap(this.countryData);
        });
        this.regionData = this.regionData.filter(delItem => delItem.regionId != region.regionId);
        this.regionUnMappedData = this.regionUnMappedData.filter(delItem => delItem.regionId != region.regionId);
      });
      this.channelLocationByTrade = this.channelLocationByTrade.filter(delItem => delItem.zoneId != item.zoneId);
      this.locationMapComponent.setMap(this.countryData);
    }
  }

  private async regionDeleteMapped(zoneId: number): Promise<any> {
    this.regionData.forEach((region: Region) => {
      if (region.ZoneRegionJCT.zoneId == zoneId) {
        this.countryData = this.countryData.filter(cItem => cItem.RegionCountryJCT.regionId != region.ZoneRegionJCT.regionId);
        this.regionData = this.regionData.filter(remItm => remItm.ZoneRegionJCT.zoneId != zoneId);
      }
    });
    if (this.locationKey === TradeLocationTitle.LOCATION_TITLE_SELLING.toUpperCase()) {
      localStorage.setItem('selected_region', JSON.stringify(this.regionData));
    }

    this.locationMapComponent.setMap(this.countryData);
  }

  private async regionDeleteUnMapped(zoneId: number): Promise<any> {
    this.regionUnMappedData.forEach((region: Region) => {
      this.regionUnMappedData = this.regionUnMappedData.filter(remItm => remItm.ZoneRegionJCT.zoneId != zoneId);
    });

    this.regionData.forEach((region: Region) => {
      this.countryUnmappedData.forEach((country: Country) => {
        this.countryUnmappedData = this.countryUnmappedData.filter(
          cItem => cItem.RegionCountryJCT.regionId
            != region.ZoneRegionJCT.regionId
        );
      });
    });

  }

  private async countryDeleteMapped(): Promise<any> {
    this.countryData = [];
    this.regionData.forEach((region: Region) => {
      let RemovableCountry: Country[] = [];
      RemovableCountry = this.countryData.filter(item => item.RegionCountryJCT.regionId == region.regionId);
      return this.countryUnmappedData.concat(RemovableCountry);
    });
  }

  public async regionDelete(item: Region): Promise<any> {
    this.regionUnMappedData = this.regionUnMappedData.filter(delItem => delItem.regionId != item.regionId);
    this.regionUnMappedData.push(item);

    for (let i = 0; i < item.country.length; i++) {
      this.countryData = this.countryData.filter(delItem => delItem.RegionCountryJCT.regionId
        != item.country[i].RegionCountryJCT.regionId);
      this.countryUnmappedData = this.countryUnmappedData.filter(delItem => delItem.RegionCountryJCT.regionId
        != item.country[i].RegionCountryJCT.regionId);
    }

    this.regionData = this.regionData.filter(delItem => delItem.regionId != item.regionId);
    if (this.locationKey === TradeLocationTitle.LOCATION_TITLE_SELLING.toUpperCase()) {
      localStorage.setItem('selected_region', JSON.stringify(this.regionData));
    }
    this.locationMapComponent.setMap(this.countryData);
  }

  public async countryDelete(item: Country): Promise<any> {
    this.countryUnmappedData = this.countryUnmappedData.filter(delItem => delItem.countryId != item.countryId);
    this.countryUnmappedData.push(item);
    this.countryData = this.countryData.filter(delItem => delItem.RegionCountryJCT.countryId != item.RegionCountryJCT.countryId);
    this.locationMapComponent.setMap(this.countryData);
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.PROFILE_TRADE_LOCATION_UPDATE);
      if (!hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  public async tradeLocationSave(item): Promise<any> {

    if (!this.authorizeBeforeSubmit()) {
      return;
    }

    await this.zoneLimitation();
    // console.log("isZoneLimted ", this.isZoneLimted);
    if (this.isZoneLimted === true) {
      // console.log('Entered after zone limitation');
      this.formMessage = '';
      this.loading = true;
      try {
        const locationCountrySave: LocationCountrySaveDTO = new LocationCountrySaveDTO();
        locationCountrySave.locationType = this.locationKey;
        if (this.countryData && this.countryData.length > 0) {
          const location: number[] = [];
          this.countryData.forEach((country: Country) => {
            const regionCountryJCT: any = country.RegionCountryJCT;
            const regionCountryJCTId = regionCountryJCT.regionCountryJCTId;
            location.push(regionCountryJCTId);
            locationCountrySave.location = location;
          });

          const resetMessage = this.accountBusiness.saveHttpLocationCountry(locationCountrySave).subscribe(result => {
            const response = result as Response;
            if (response.ok && result.body === true) {
              this.loading = false;

              if (this.isRedirect === true) {
                this.toggle = true;
                this.locationKey = TradeLocationTitle.LOCATION_KEY_SELLING;
                this.locationTitle = { 'locTitle': TradeLocationTitle.LOCATION_TITLE_SELLING };
                this.getLocationDataBtnClick();
              }
              
              if(this.locationKey == TradeLocationTitle.LOCATION_KEY_SELLING) {
                this.toastr.success(TradeLocationTitle.SAVE_DIALOG_TEXT);
              } else {
                this.toastr.success(TradeLocationTitle.SAVE_DIALOG_TEXT_WITH_SUGGESTION);                
              }
              
              // this.OpenDialog(TradeLocationTitle.SAVE_DIALOG_TITLE, TradeLocationTitle.SAVE_DIALOG_TEXT);
              this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
              // let dialogRef = this.dialog.open(AccountModalSuccessComponent, { data: { message: "Saved Susseccfully" } });

            } else {
              // Redirection
              if (this.isRedirect === true) {
                this.router.navigate(['/accountverify']);
              } else {
                this.loading = false;
                this.toastr.success(TradeLocationTitle.SAVE_DIALOG_TEXT);
                this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
              }
            }
          });
        } else {
          this.loading = false;
          this.toastr.info(TradeLocationTitle.NO_LOCATION_DIALOG_TEXT);
          // this.OpenDialog(TradeLocationTitle.NO_LOCATION_DIALOG_TITLE, TradeLocationTitle.NO_LOCATION_DIALOG_TEXT);
        }
      } catch (error) {
        this.loading = false;
        console.log('Error on save :' + error);
      }
    }
  }

  private async OpenDialog(title: string, message: string): Promise<any> {
    const dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: 1,
        message: message
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
    });
  }

  private async zoneLimitation() {
    this.loading = false;
    // let zoneCnt;
    this.isZoneLimted = true;
    // this.authorizeService.hasFeatureAccess(FeatureAccessEnum.ZONE_INCLUDES).then(item => {
    //   zoneCnt = item;
    //   this.zoneIDs = Array.from(new Set(this.zoneIDs));
    //   const selectZone = this.zoneIDs.length;
    //   if (selectZone > zoneCnt) {
    // tslint:disable-next-line:max-line-length
    //     this.OpenDialog(TradeLocationTitle.NO_LOCATION_DIALOG_TITLE, TradeLocationTitle.ZONE_LIMIT_MESSAGE.replace('[zoneCnt]', zoneCnt));
    //     this.isZoneLimted = false;
    //   } else {
    //     this.isZoneLimted = true;
    //   }
    // });

  }

}
