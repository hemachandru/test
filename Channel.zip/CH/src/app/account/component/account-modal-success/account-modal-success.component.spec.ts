import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountModalSuccessComponent } from './account-modal-success.component';

describe('AccountModalSuccessComponent', () => {
  let component: AccountModalSuccessComponent;
  let fixture: ComponentFixture<AccountModalSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountModalSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountModalSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
