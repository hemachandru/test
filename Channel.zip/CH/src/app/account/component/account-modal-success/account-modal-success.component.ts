import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-account-modal-success',
  templateUrl: './account-modal-success.component.html',
  styleUrls: ['./account-modal-success.component.scss']
})
export class AccountModalSuccessComponent implements OnInit {
public successData = '';
  constructor(public dialogRef: MatDialogRef<AccountModalSuccessComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
    this.successData = this.data.message;
  }

  cancel() {
    this.dialogRef.close();
  }

}
