import { Component, OnInit, Input, AfterViewInit, OnChanges } from '@angular/core';
import { AccountBusiness } from './../../business/account.bussiness';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';

@Component({
  selector: 'app-company-title',
  templateUrl: './company-title.component.html',
  styleUrls: ['./company-title.component.scss']
})

export class CompanyTitleComponent implements OnInit, OnChanges {
  public title: any;
  public type: string;
  public channelName: string;
  public country: string;
  public plan: string;

  @Input() profilePercentages: number;
  @Input() public profileLogo: string;
  constructor(private _accountBusiness: AccountBusiness) { }

  ngOnInit() {
    this.title = 'tradeinformation.accountsetup';
    this.type = 'Distributor';
    this.channelName = 'MyKronoz';
    this.country = '';
    this.plan = '';
    this.getChannelType();
  }

  ngOnChanges() {
    // this.getChannelType();
  }

  getChannelType() {
    this._accountBusiness.getUserTypeProfileBusiness().subscribe(data => {
      if (!ValidationService.isNullOrEmpty(data.channel)) {
        this.type = data.channel.channelType.channelType;
        this.profilePercentages = data.channel.profileStrength;
        if (!ValidationService.isNullOrEmpty(data.channel.channelDetail)) {
          if (!ValidationService.isNullOrEmpty(data.channel.channelDetail.channelLogo)) {
            this.profileLogo = data.channel.channelDetail.channelLogo.documentUrl;
          }
        }
        this.channelName = data.channel.companyName;
        if (!ValidationService.isNullOrEmpty(data.channel.country)) {
          this.country = data.channel.country.country;
        }
        if (!ValidationService.isNullOrEmpty(data.channel.plan)) {
          this.plan = data.channel.plan.subscriptionPlanType;
        }
        localStorage.setItem(AppLocalStorageKeys.CHANNEL_NAME, this.type);
        localStorage.setItem(AppLocalStorageKeys.CHANNEL_TYPE_ID, data.channel.channelType.channelTypeId);
      }
    });
  }

}
