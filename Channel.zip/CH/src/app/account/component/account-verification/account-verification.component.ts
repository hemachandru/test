import { Component, OnInit } from '@angular/core';
import { SuccesErrorMessage, UserDetailMessage, Config, UserAccountStatus, ChannelHubCommon } from '@app/config/constant';

@Component({
  selector: 'app-account-verification',
  templateUrl: './account-verification.component.html',
  styleUrls: ['./account-verification.component.scss']
})
export class AccountVerificationComponent implements OnInit {
  public verificationObject: SuccesErrorMessage;
  public title = '';
  channelHubContactMail: string = ChannelHubCommon.channelHubContactEmail;
  constructor() { }

  ngOnInit() {
    this.title = 'verification.title';
    this.bindVerificationPage();
  }

  bindVerificationPage() {
    this.verificationObject = {
      errorId: '2',
      errorType: 'Verified',
      errorTitle: 'Verification',
      icon: '',
      iconMessage: '',
      messages: [
        {
          messageContent: '',
        },
        {
          messageContent: 'verification.messageContent1',
        }
        ,
        {
          messageContent: 'verification.messageContent2',
        }
        ,
        {
          messageContent: 'verification.messageContent3',
        },
        {
          // tslint:disable-next-line:max-line-length
          messageContent: '<font size="2">For more details, <span class="bold-text"><a href="/help/support">' + this.channelHubContactMail + '</a></span></font>',
        }
      ],
      button: [{
        buttonType: '',
        buttonName: '',
        buttonValue: '',
        buttonLink: ''
      }],
      showButtonBlock: false
    };

  }
}
