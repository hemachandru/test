import {
  Component, OnInit, Input, Output, EventEmitter, AfterViewChecked, Pipe,
  PipeTransform, ViewChild, ElementRef
} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl, FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Response } from '@angular/http';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ScrollToService } from 'ng2-scroll-to-el';
import * as moment from 'moment';
import { CommonHelper } from '@app/shared/common-helper';
import { AbstractControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import {
  Config, UserAccountStatus, AccessPermissionEnum,
  ChannelTypeIdEnum, UploadNotifyEnum
} from '@app/config/constant';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import { LinkedinComponent } from '../../../shared/shared-component/linkedin/linkedin.component';
import { ConfirmDialogComponent } from '../../../shared/shared-component/confirm-dialog/confirm-dialog.component';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { Linkedin } from '../../../shared/models/linkedin';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { AccountBusiness } from './../../business/account.bussiness';
import { Profile, MultiCertificate, Certificate, Certify, ProfileAddress, CountryMaster, ChannelDocument } from './../../models/profile';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { AuthBusiness } from '@app/auth/business/auth.business';
import { PublicUploadRequest } from '../../../user-subscription/models/subscription';
import { AddCertificateComponent } from '../../component/add-certificate/add-certificate.component';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { TranslateService } from '@ngx-translate/core';
import { MultipleFileUploadModel, FileUploadModel, MessageNotify } from '@app/shared/models/multiple-file-upload-model';

@Component({
  selector: 'app-account-profile',
  templateUrl: './account-profile.component.html',
  styleUrls: ['./account-profile.component.scss']
})

export class AccountProfileComponent implements OnInit {
  public profileForm: FormGroup;
  msgCodeImg = '';
  public phoneValid: string;
  public submitData: Profile;
  public defaultConfig: MultiCertificate;
  public certificate: Certificate = new Certificate();
  public profileAdd: ProfileAddress = new ProfileAddress();
  countryMasterList: Array<CountryMaster>;

  formSubmit = false;
  public regCountry: string;
  public billCountry: string;
  public profileGetData: any = [];
  public profileLogo: string;
  public getCountryId: string;
  public getCountryIdReg: number;
  public getCountryIdBill: number;
  public flagValid: number;
  public getProperty: string;
  public billAddressFlag: boolean;
  public isSameAddress: boolean;
  public _ChannelTypeIdEnum = ChannelTypeIdEnum;
  @Input() updateFlag: Boolean;
  @Input() getCountry: any = '';
  public regInfo: Boolean = true;
  comInfo: Boolean;
  collapsed3: Boolean;
  taxInfo: Boolean;
  awardsInfo: Boolean;
  socialInfo: Boolean;
  authorizedInfo: Boolean;
  companyInfo: Boolean;
  sameBillAdd: Boolean;
  flagLifePlan: Boolean;
  result: any;
  linkedin: Linkedin;
  flagProfileImg: Boolean;
  percent: number;
  emptyString: string;
  public items: FormArray;
  public itemsTax: FormArray;
  public itemsAward: FormArray;
  public itemsB2B: FormArray;
  public hasUpdateAccess: boolean;
  public linkedinURL: string;
  public editor;
  public isRegister: boolean;
  public isVAT: boolean;
  public channelTypeId: number;
  public officialDocsAllowedFileTypes: string[] = ['pdf', 'jpg', 'jpeg', 'png'];
  // public editorContent = `<h3>I am Example content</h3>`;
  @Input() public ToastMsg1 = '';
  public defaultModules = {
    toolbar: [
      ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
      ['blockquote', 'code-block'],

      [{ 'header': 1 }, { 'header': 2 }],               // custom button values
      [{ 'list': 'ordered' }, { 'list': 'bullet' }],
      [{ 'script': 'sub' }, { 'script': 'super' }],      // superscript/subscript
      [{ 'indent': '-1' }, { 'indent': '+1' }],          // outdent/indent
      [{ 'direction': 'rtl' }],                         // text direction

      [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
      [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

      [{ 'color': new Array<any>() }, { 'background': new Array<any>() }],          // dropdown with defaults from theme
      [{ 'font': new Array<any>() }],
      [{ 'align': new Array<any>() }],

      ['clean'],                                         // remove formatting button

      ['link']                         // link add  ['link', 'image', 'video'] for all
    ]
  };

  public editorOptions = {
    placeholder: 'Enter About Company',
    modules: this.defaultModules
  };
  public editorExceptation = {
    placeholder: 'Enter Expectation',
    modules: this.defaultModules
  };
  isPopupOpened = false;
  channel_document: Array<ChannelDocument>;
  deleted_channel_documents: Array<number>;
  officialDocs: Array<FileUploadModel>;
  officialDocsTitle: string;
  officialDocCtrl: string;
  officialDocErrorCode: string;
  officialDocMaxSize = 4000000;
  constructor(private router: Router, private Const: Config, private fb: FormBuilder,
    private uploadService: S3UploadFileService, private _accountBusiness: AccountBusiness,
    private scrollService: ScrollToService, private dataBinding: AccountDataService,
    public dialog: MatDialog, public sharedBusiness: SharedBusiness,
    private elementRef: ElementRef, private authBusiness: AuthBusiness,
    private toastr: ToastrService, private authorizeService: AuthorizeService,
    private formsModule: FormsModule,
    private translate: TranslateService
  ) {
  }

  // @ViewChild('firstNameInput') nameInputRef: ElementRef;

  ngOnInit() {
    this.channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
    this.officialDocsTitle = 'companyprofile.bodyLabels.officialDocTitle';
    this.profileLogo = '';
    this.isRegister = false;
    this.isVAT = false;
    this.regCountry = 'profileRegCountry';
    this.billCountry = 'profileBillCountry';
    this.submitData = new Profile();
    this.defaultConfig = new MultiCertificate();
    this.initForm();
    // this.for.get('profilePhone2').setErrors( {MisMatchPhone: false} );
    this.dataBinding.changeBoolProfile(true);
    this.dataBinding.changeBoolTrade(false);
    this.dataBinding.changeBoolLoc(false);
    this.getCountryList();
    this.getChannelType();
    for (let i = 0; i < 4; i++) {
      this.defaultConfig.accCertiNameId.push(new Certify());
    }
    this.officialDocCtrl = 'officialDocuments';
    this.sameBillAdd = true;
  }

  openDialogLinkedin(): void {
    this.linkedin = new Linkedin();
    this.linkedin.firstName = '';
    this.linkedin.lastName = '';
    this.linkedin.email = '';
    this.linkedin.jobTitle = '';
    this.linkedin.profileUrl = '';
    let uid = '';
    this.sharedBusiness.socialLogin('linkedin').subscribe(response => {
      this.linkedin = response as Linkedin;
      const names = this.linkedin.name.split(' ', 2);
      this.linkedin.firstName = names[0];
      this.linkedin.lastName = names[1];
      uid = this.linkedin.uid;

      if (this.isPopupOpened) {
        return;
      } else {
        this.isPopupOpened = true;
      }
      const dialogRef = this.dialog.open(LinkedinComponent, {
        data: {
          name: this.linkedin.name,
          firstName: this.linkedin.firstName, lastName: this.linkedin.lastName,
          email: this.linkedin.email, jobTitle: this.linkedin.jobTitle,
          profileUrl: this.linkedin.profileUrl,
          image: this.linkedin.image
        }
      });

      dialogRef.afterClosed().subscribe(result => {
        this.isPopupOpened = false;
        this.defaultConfig.preloader = true;
        this.sharedBusiness.logout();
        document.getElementsByTagName('html').item(0).style.removeProperty('top');
        if (result) {
          this.linkedin = result as Linkedin;
          if (!ValidationService.isNullOrEmpty(this.linkedin.firstName)) {
            this.profileForm.controls['profileFirstName'].setValue(this.linkedin.firstName);
          }
          if (!ValidationService.isNullOrEmpty(this.linkedin.lastName)) {
            this.profileForm.controls['profileLastname'].setValue(this.linkedin.lastName);
          }
          if (!ValidationService.isNullOrEmpty(this.linkedin.jobTitle)) {
            this.profileForm.controls['profileJobtitle'].setValue(this.linkedin.jobTitle);
          }
          if (!ValidationService.isNullOrEmpty(this.linkedin.profileUrl)) {
            this.profileForm.controls['profileAuthLink'].setValue(this.linkedin.profileUrl);
          }
          if (!ValidationService.isNullOrEmpty(this.linkedin.image)) {
            const publicUploadRequest: PublicUploadRequest = {
              'path': this.defaultConfig.folderName + uid + '.jpeg',
              'url': this.linkedin.image
            };
            this.sharedBusiness.uploadLinkedInImageBusiness(publicUploadRequest).subscribe(responseLink => {
              if (responseLink.length) {
                this.defaultConfig.profileImgErr = this.translate.instant('companyprofile.validationMessage.profileimgError');
                this.defaultConfig.userImage = false;
                this.defaultConfig.userIcon = true;
              } else { // success
                this.defaultConfig.userImage = true;
                this.defaultConfig.userIcon = false;
                this.defaultConfig.arrImage[2].loc = publicUploadRequest.path;
                this.defaultConfig.profileImgErr = this.translate.instant('companyprofile.validationMessage.profileimageSuccess');
                this.defaultConfig.arrImage[2].src = this.linkedin.image;
                this.profileLogo = this.linkedin.image;
              }
              this.defaultConfig.preloader = false;
            },
              (error) => {
                this.defaultConfig.profileImgErr = this.translate.instant('companyprofile.validationMessage.profileimgError');
                this.defaultConfig.preloader = false;
              });
          } else {
            this.defaultConfig.preloader = false;
          }
        } else {
          this.defaultConfig.preloader = false;
        }
      }, (error) => {
        console.log(error);

      });
    });
  }

  getChannelType() {
    this.percent = 18;
    this._accountBusiness.getUserTypeProfileBusiness().subscribe(res => {
      if (!ValidationService.isNullOrEmpty(res.channel)) {
        this.percent = res.channel.profileStrength;
        const status = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
        if (parseInt(status, 10) === 7) {
          // this.percent = this.percent; Sonar bugs
          this.dataBinding.changeMessage(this.percent);
        }
        if (!ValidationService.isNullOrEmpty(res.channel.channelDetail)) {
          let channelLog = 'assets/images/pro-logo.jpg';
          if (res.channel.channelDetail.channelLogo && res.channel.channelDetail.channelLogo.documentUrl) {
            channelLog = res.channel.channelDetail.channelLogo.documentUrl;
          }
          this.dataBinding.changeImageUrl(channelLog);
          let channelIcon = 'assets/images/pro-logo.jpg';
          if (res.channel.channelDetail.channelIcon && res.channel.channelDetail.channelIcon.documentUrl) {
            channelIcon = res.channel.channelDetail.channelIcon.documentUrl;
          }
          this.dataBinding.changeFaviconUrl({ data: channelIcon, action: false });
        } else {
          this.dataBinding.changeImageUrl('/assets/images/pro-logo.jpg');
        }
        // if (!ValidationService.isNullOrEmpty(res.channel.channelType)) {
        //   this.channelTypeId = parseInt(res.channel.channelType.channelType, 10);
        // } else {
        //   this.channelTypeId = parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID), 10);
        // }
      }
    });
  }

  getOldChannel() {
    this._accountBusiness.getOldChannelBusiness(true).subscribe(res => {
      if (res.length > 0) {
        return false;
      } else {
        this.defaultConfig.jsonData = res.json();
        this.profileGetData = this.defaultConfig.jsonData;
        this.preFillData(res.json());
      }
    });
  }

  onChangePercentage(event, flag, flagValid: boolean = false) {
    if (flag === 0 && this.updateFlag) {
      flag = 1;
    }
    if (flag === 0) {
      this.onCheckNewPercent(event, flagValid);
    }
    // else {
    //   this.onCheckUpdatePercent(event, flagValid);
    // }
  }

  onCheckNewPercent(event, flagField) {
    let flagControlValid = true;
    let formFieldName;
    if (flagField) {
      flagControlValid = flagField;
      formFieldName = event;
    } else {
      flagControlValid = this.profileForm.controls[event.target.name].valid;
      formFieldName = event.target.name;
    }
    if (flagControlValid && this.Const.flag_percent[formFieldName][1] === 1) {
      this.percent = this.percent + this.Const.flag_percent[formFieldName][0];
      this.Const.flag_percent[formFieldName][1] = 0;
    } else if (!flagControlValid && this.Const.flag_percent[formFieldName][1] === 0) {
      this.percent = this.percent - this.Const.flag_percent[formFieldName][0];
      this.Const.flag_percent[formFieldName][1] = 1;
    }
    this.dataBinding.changeMessage(this.percent);
  }

  onCheckUpdatePercent(event, flagField) {
    let flagControlValid = true;
    let formFieldName;
    if (flagField) {
      flagControlValid = flagField;
      formFieldName = event;
    } else {
      flagControlValid = this.profileForm.controls[event.target.name].valid;
      formFieldName = event.target.name;
    }
    if (flagControlValid && this.Const.flag_percent[formFieldName][1] === 0) {
      this.percent = this.percent + this.Const.flag_percent[formFieldName][0];
      this.Const.flag_percent[formFieldName][1] = 1;
    } else if (!flagControlValid && this.Const.flag_percent[formFieldName][1] === 1) {
      this.percent = this.percent - this.Const.flag_percent[formFieldName][0];
      this.Const.flag_percent[formFieldName][1] = 0;
    }
    this.dataBinding.changeMessage(this.percent);
  }

  deleteCertificateIdName(type, arr, index, id) {
    if (type === 1) {
      this.items.removeAt(index);
    } else if (type === 2) {
      this.itemsTax.removeAt(index);
    } else if (type === 3) {
      this.itemsAward.removeAt(index);
    } else if (type === 4) {
      this.itemsB2B.removeAt(index);
    }
    if (id !== 0) {
      this.defaultConfig.accCertiNameId[arr].deleteId.push(id);
    }
  }

  onChangeSameBill() {
    if (this.sameBillAdd === true) {
      this.profileForm.controls['profileRegAdd'].setValue(this.profileForm.controls['profileAddress'].value);
      this.profileForm.controls['profileRegZip'].setValue(this.profileForm.controls['profileZip'].value);
      this.profileForm.controls['profileRegcity'].setValue(this.profileForm.controls['profileCity'].value);
      this.getCountryIdBill = this.getCountryIdReg;
      this.defaultConfig.errorCodeArr['coutry_bill'] = '';
    }
  }

  onClickSameBill(check: number = 0) {
    if (this.sameBillAdd === true) {
      this.profileForm.controls['profileRegAdd'].setValue(this.profileForm.controls['profileAddress'].value);
      this.profileForm.controls['profileRegZip'].setValue(this.profileForm.controls['profileZip'].value);
      this.profileForm.controls['profileRegcity'].setValue(this.profileForm.controls['profileCity'].value);
      this.getCountryIdBill = this.getCountryIdReg;
      this.defaultConfig.errorCodeArr['coutry_bill'] = '';
    } else if (!this.updateFlag) {
      this.profileForm.controls['profileRegAdd'].reset();
      this.profileForm.controls['profileRegZip'].reset();
      this.profileForm.controls['profileRegcity'].reset();
      this.getCountryIdBill = 0;
    } else if (this.updateFlag) {
      if (this.billAddressFlag) {
        this.profileForm.controls['profileRegAdd'].setValue(this.profileGetData.channel.billAddress.address);
        this.profileForm.controls['profileRegZip'].setValue(this.profileGetData.channel.billAddress.postalCode);
        this.profileForm.controls['profileRegcity'].setValue(this.profileGetData.channel.billAddress.city);
        this.getCountryIdBill = parseInt(this.profileGetData.channel.billAddress.countryId, 10);
      }
    }

    if (!this.sameBillAdd && this.isSameAddress) {
      this.profileForm.controls['profileRegAdd'].reset();
      this.profileForm.controls['profileRegZip'].reset();
      this.profileForm.controls['profileRegcity'].reset();
      this.getCountryIdBill = 0;
    }
  }

  // Set Country with Registration Id
  public async getContryID(data: string): Promise<any> {
    this.profileAdd.countryId = parseInt(data, 10);
    this.getCountryIdReg = (data === 'null') ? 0 : parseInt(data, 10);
    if (data && data !== 'null') {
      this.getCountryIdBill = (this.sameBillAdd) ? this.getCountryIdReg : this.getCountryIdBill;
      this.setRegistrationIsVAT(data);
      this.defaultConfig.errorCodeArr['regiser_coutry_bill'] = '';
    } else {
      this.defaultConfig.errorCodeArr['regiser_coutry_bill'] = '0002';
    }
  }

  // Function to find isVat & isRegistration
  setRegistrationIsVAT(data) {
    const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
      === parseInt(data, 10));
    if (countryData[0].registrationcertificate) {
      this.items.controls[0].get('name').setValue(countryData[0].registrationcertificate);
      this.isRegister = true;
    } else {
      this.isRegister = false;
    }
    if (countryData[0].phoneCode) {
      this.profileForm.controls['profilePhoneCode'].setValue(countryData[0].phoneCode);
      this.profileForm.controls['profilePhone2Code'].setValue(countryData[0].phoneCode);
      this.profileForm.controls['profileMobileCode'].setValue(countryData[0].phoneCode);
      this.profileForm.controls['profileContactnoCode'].setValue(countryData[0].phoneCode);
      this.profileForm.controls['profileAuthCont2Code'].setValue(countryData[0].phoneCode);
      this.profileForm.controls['profileAuthmobCode'].setValue(countryData[0].phoneCode);
    } /*else {
    }*/
    if (countryData[0].isVat === '1' && this.channelTypeId !== ChannelTypeIdEnum.RETAILER) {
      this.isVAT = true;
      if (!this.itemsTax) {
        this.addItemTax('', '', 0);
      }
      this.itemsTax.controls[0].get('name').setValidators([Validators.required, Validators.minLength(3), Validators.maxLength(100)]);
      this.itemsTax.controls[0].get('id').setValidators([Validators.required, Validators.minLength(3), Validators.maxLength(70)]);
      this.itemsTax.controls[0].get('name').setValue(this.translate.instant('companyprofile.bodyLabels.vatName'));
    } else {
      this.isVAT = false;
      if (this.itemsTax) {
        this.itemsTax.controls[0].get('name').clearValidators();
        this.itemsTax.controls[0].get('id').clearValidators();
        this.itemsTax.controls[0].get('name').setErrors(null);
        this.itemsTax.controls[0].get('id').setErrors(null);
      }
    }
  }

  public async getContryIDBill(data: string): Promise<any> {
    this.profileAdd.countryId = parseInt(data, 10);
    this.getCountryIdBill = (data === 'null') ? 0 : parseInt(data, 10);
    this.defaultConfig.errorCodeArr['coutry_bill'] = '';
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      this.hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.COMPANY_PROFILE_UPDATE);
      if (!this.hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  onSubmit() {
    this.flagValid = 1;
    this.profileValidate();
    const htmlContent = this.profileForm.controls['profileHtmlContent'].value;
    const expectationContent = this.profileForm.controls['profileExpectationContent'].value;
    let channelLog = '';
    if (this.profileGetData.channel.channelDetail && this.profileGetData.channel.channelDetail.channelLogo) {
      channelLog = this.profileGetData.channel.channelDetail.channelLogo.documentUrl;
    }
    // let contactProfile = '';
    // if (this.profileGetData.contact.document) {
    //   contactProfile = this.profileGetData.contact.document[0].documentUrl ? this.profileGetData.contact.document[0].documentUrl :
    //     this.profileGetData.contact.document[0].documentPath;
    // }
    if (htmlContent === null || htmlContent.length === 0) {
      this.defaultConfig.errorCodeArr['company_about'] = '1651';
    }
    if (this.profileForm.invalid || (this.defaultConfig.arrImage[0].loc === '' && this.updateFlag && channelLog === '')
      || this.defaultConfig.errorCodeArr['company_about'] !== '' || this.msgCodeImg !== '' || this.getCountryIdBill === 0
      || this.getCountryIdReg === 0 || this.defaultConfig.errorCodeArr['expectation']) {
      if (this.defaultConfig.arrImage[0].loc === '' && this.updateFlag && channelLog === '') {
        this.defaultConfig.errorCodeArr['fileprofileLogo'] = '0056';
      }
      // if (this.updateFlag  && this.defaultConfig.arrImage[2].loc === '' && contactProfile === '') {
      //   this.defaultConfig.errorCodeArr['contact_profile_image_url'] = '0056';
      // }
      // if (this.defaultConfig.arrImage[1].loc === '' && !this.updateFlag) {
      //   this.defaultConfig.errorCodeArr['fileprofileFavicon'] = '0057';
      // }
      if (this.getCountryIdBill === 0) {
        this.defaultConfig.errorCodeArr['coutry_bill'] = '0002';
      }
      if (this.getCountryIdReg === 0) {
        this.defaultConfig.errorCodeArr['regiser_coutry_bill'] = '0002';
      }
      let flagScrollImg = 0;
      if (this.msgCodeImg !== '' || this.defaultConfig.arrImage[0].loc === '' && this.updateFlag && channelLog === '') {
        this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -100);
        flagScrollImg = 1;
      } else if (this.profileForm.invalid) {
        const scrollInvalid = this.profileValidate();
        this.scrollService.scrollTo(document.getElementById(scrollInvalid + 'Id'), 1000, -100);
      }
      // if (this.profileForm.controls['ownerFirstName'].valid && this.profileForm.controls['ownerLastName'].valid
      // && flagScrollImg === 0 && this.items.valid) {
      if (flagScrollImg === 0 && this.items.valid) {
        if (this.profileForm.controls['establishYear'].invalid || this.defaultConfig['establishYear'] !== ''
          || this.getCountryIdBill === 0 || this.getCountryIdReg === 0) {
          flagScrollImg = 1;
          if (this.getCountryIdReg === 0) {
            this.scrollService.scrollTo(document.getElementById('profileAddressId'), 1000, -70);
          } else if (this.getCountryIdBill === 0) {
            this.scrollService.scrollTo(document.getElementById('accCountryId'), 1000, -250);
          } else if (this.profileForm.controls['establishYear'].invalid || this.defaultConfig['establishYear'] !== '') {
            this.scrollService.scrollTo(document.getElementById('establishYearId'), 1000, -70);
          }
        }
        // else if (flagScrollImg === 0 && this.profileForm.valid && this.defaultConfig.arrImage[2].loc === '' && contactProfile === '') {
        //   this.scrollService.scrollTo(document.getElementById('profileJobtitleId'), 1000, -200);
        // }
      }

      if (flagScrollImg === 0 && this.defaultConfig.errorCodeArr['company_about'] !== '' && this.profileForm.valid) {
        this.scrollService.scrollTo(document.getElementById('profileHtmlContentId'), 1000, -70);
      }
      this.flagValid = 0;
      return false;
    }
    const isOldChannel = localStorage.getItem(AppLocalStorageKeys.OLD_CHANNEL);
    if (this.defaultConfig.arrImage[0].loc !== '') {
      this.submitData.company_logo_url = this.defaultConfig.arrImage[0].loc;
    } else if (!this.updateFlag && isOldChannel === 'true' && this.profileGetData.channel.channelDetail.channelLogo) {
      this.submitData.company_log_id = this.profileGetData.channel.channelDetail.channelLogo.documentId;
    }
    if (this.defaultConfig.arrImage[1].loc !== '') {
      this.submitData.company_icon_url = this.defaultConfig.arrImage[1].loc;
    }
    this.submitData.company_name = this.profileForm.controls['legalName'].value;
    this.submitData.registration_certificate = this.items.value;
    if (this.profileForm.controls['establishYear'].value !== '') {
      this.submitData.year_of_estabilishment = parseInt(this.profileForm.controls['establishYear'].value, 10);
    }
    // if (this.profileForm.controls['registrationYear'].value !== '') {
    //   this.submitData.year_of_registration = parseInt(this.profileForm.controls['registrationYear'].value, 10);
    // }
    this.submitData.reg_address = this.profileForm.controls['profileAddress'].value;
    this.submitData.reg_country_id = this.getCountryIdReg;
    this.submitData.bill_country_id = this.getCountryIdBill;
    this.submitData.reg_postal_code = this.profileForm.controls['profileZip'].value;
    this.submitData.reg_city = this.profileForm.controls['profileCity'].value;

    if (!this.updateFlag && isOldChannel === 'true') {
      this.submitData.reg_address_id = 0;
    } else {
      this.submitData.reg_address_id = this.defaultConfig.jsonData.channel.regAddress ?
        parseInt(this.defaultConfig.jsonData.channel.regAddress.addressId, 10) : 0;
    }
    this.submitData.company_phone1 = this.profileForm.controls['profilePhoneCode'].value +
      '-' + this.profileForm.controls['profilePhone'].value;
    this.submitData.company_phone2 = '';
    if (this.profileForm.controls['profilePhone2'].value !== '') {
      this.submitData.company_phone2 = this.profileForm.controls['profilePhone2Code'].value +
        '-' + this.profileForm.controls['profilePhone2'].value;
    }
    this.submitData.company_mobile_no = '';
    if (this.profileForm.controls['profileMobile'].value !== '') {
      this.submitData.company_mobile_no = this.profileForm.controls['profileMobileCode'].value +
        '-' + this.profileForm.controls['profileMobile'].value;
    }
    if (this.profileForm.controls['profileemail'].value !== '') {
      this.submitData.company_email = this.profileForm.controls['profileemail'].value;
    }
    this.submitData.company_about = this.profileForm.controls['profileHtmlContent'].value;
    if (expectationContent !== '' && this.channelTypeId === ChannelTypeIdEnum.DISTRIBUTOR
      || expectationContent !== '' && this.channelTypeId === ChannelTypeIdEnum.RETAILER) {
      this.submitData.company_expectation = expectationContent;
    }
    this.submitData.bill_address = this.profileForm.controls['profileRegAdd'].value;
    this.submitData.bill_postal_code = this.profileForm.controls['profileRegZip'].value;
    this.submitData.bill_city = this.profileForm.controls['profileRegcity'].value;
    this.submitData.is_same_address = this.sameBillAdd === true ? 1 : 0;
    if (this.billAddressFlag && this.submitData.is_same_address === 1) {
      this.submitData.bill_address_id = parseInt(this.defaultConfig.jsonData.channel.billAddress.addressId, 10);
    }
    this.submitData.company_website_url = this.urlFormatting(this.profileForm.controls['profileWebsiteURL'].value);
    if (this.isVAT) {
      this.submitData.tax_certificate = this.itemsTax.value;
    }
    if (this.itemsAward.value[0].details.length > 0) {
      this.submitData.award_details = this.itemsAward.value;
      if (this.itemsAward.invalid) {
        this.scrollService.scrollTo(document.getElementById('itemsAwardId'), 1000, -100);
      } else {
        this.submitData.award_details.forEach(x => {
          if (x.valid_upto !== null) {
            x.valid_upto = moment(x.valid_upto, 'YYYY/MM/DD').toDate();
          }
        });
      }
    }
    if (this.profileForm.controls['profilelinkedURL'].value !== '') {
      this.submitData.social_linkedin_url = this.urlFormatting(this.profileForm.controls['profilelinkedURL'].value);
    }
    // if (this.profileForm.controls['profileGoogleURL'].value !== '') {
    //   this.submitData.social_googleplus_url = this.urlFormatting(this.profileForm.controls['profileGoogleURL'].value);
    // }
    if (this.profileForm.controls['profileInstaURL'].value !== '') {
      this.submitData.social_instagram_url = this.urlFormatting(this.profileForm.controls['profileInstaURL'].value);
    }
    if (this.itemsB2B.value[0].B2B_url.length > 0) {
      this.submitData.B2B_url = this.itemsB2B.value;
      if (this.itemsB2B.invalid) {
        this.scrollService.scrollTo(document.getElementById('itemsB2BId'), 1000, -100);
      }
    }
    if (this.updateFlag) {
      this.submitData.social_linkedin_id = this.defaultConfig.socialLink;
      this.submitData.social_googleplus_id = this.defaultConfig.socialGoogle;
      this.submitData.social_instagram_id = this.defaultConfig.socialInsta;
      this.submitData.contact_linkedin_id = this.defaultConfig.contactLinkedin;
    } else {
      if (!this.submitData.contact_linkedin_id) {
        delete this.submitData.contact_linkedin_id;
      }
    }
    if (this.defaultConfig.accCertiNameId[0].deleteId.length > 0) {
      this.submitData.deleted_registration_certificate = this.defaultConfig.accCertiNameId[0].deleteId;
    }
    if (this.defaultConfig.accCertiNameId[1].deleteId.length > 0) {
      this.submitData.deleted_tax_certificate = this.defaultConfig.accCertiNameId[1].deleteId;
    }
    if (this.defaultConfig.accCertiNameId[2].deleteId.length > 0) {
      this.submitData.deleted_award_details = this.defaultConfig.accCertiNameId[2].deleteId;
    }
    if (this.defaultConfig.accCertiNameId[3].deleteId.length > 0) {
      this.submitData.deleted_B2B = this.defaultConfig.accCertiNameId[3].deleteId;
    }
    this.submitData.contact_first_name = this.profileForm.controls['profileFirstName'].value;
    this.submitData.contact_last_name = this.profileForm.controls['profileLastname'].value;
    if (this.profileForm.controls['profileContactno'].value !== '') {
      this.submitData.contact_phone1 = this.profileForm.controls['profileContactnoCode'].value +
        '-' + this.profileForm.controls['profileContactno'].value;
    }
    if (this.profileForm.controls['profileAuthCont2'].value !== '') {
      this.submitData.contact_phone2 = this.profileForm.controls['profileAuthCont2Code'].value +
        '-' + this.profileForm.controls['profileAuthCont2'].value;
    }
    this.submitData.contact_mobile_no = this.profileForm.controls['profileAuthmobCode'].value +
      '-' + this.profileForm.controls['profileAuthmob'].value;
    this.submitData.contact_email = this.profileForm.controls['profileAuthEmail'].value;
    this.submitData.contact_job_title = this.profileForm.controls['profileJobtitle'].value;
    if (this.profileForm.controls['profileAuthLink'].value !== '') {
      this.submitData.contact_linkedin_url = this.profileForm.controls['profileAuthLink'].value;
    }
    if (this.defaultConfig.arrImage[2].loc !== '') {
      this.submitData.contact_profile_image_url = this.defaultConfig.arrImage[2].loc;
    } else if (!this.updateFlag && isOldChannel === 'true' && this.profileGetData.contact.document) {
      this.submitData.contact_profile_image_id = this.profileGetData.contact.document.documentId;
    }

    // this.submitData.company_owner_first_name = this.profileForm.controls['ownerFirstName'].value;
    // this.submitData.company_owner_last_name = this.profileForm.controls['ownerLastName'].value;
    if (this.items.value[0].name.length === 0 || this.isVAT && this.itemsTax.value[0].name.length === 0) {
      if (this.items.value[0].name.length === 0) {
        this.defaultConfig.errorCodeArr['registration_certificate'] = '1730';
        this.scrollService.scrollTo(document.getElementById('regcertificateId'), 1000, -100);
      }
      if (this.isVAT && this.itemsTax.value[0].name.length === 0) {
        this.defaultConfig.errorCodeArr['tax_certificate'] = '1731';
        this.scrollService.scrollTo(document.getElementById('taxCertificateId'), 1000, -100);
      }
      this.flagValid = 0;
      return false;
    }

    if (this.updateFlag) {
      if (this.channel_document && this.channel_document.length > 0) {
        this.submitData.channel_document = this.channel_document;
      }

      if (this.deleted_channel_documents && this.deleted_channel_documents.length > 0) {
        this.submitData.deleted_channel_documents = this.deleted_channel_documents;
      }
    } else {
      if (this.channel_document && this.channel_document.length > 0) {
        this.submitData.channel_document = this.channel_document;
      }
    }

    if (!this.authorizeBeforeSubmit()) {
      return;
    }
    if (this.flagValid === 1) {
      this.defaultConfig.preloader = true;
      this._accountBusiness.postProfile(this.submitData, true, this.updateFlag).subscribe(res => {
        this.defaultConfig.preloader = false;
        const responseProfile = res as Response;
        if (responseProfile.ok) {
          this.officialDocErrorCode = '';
          if (this.updateFlag) {
            this.dataBinding.changeFaviconUrl({ data: '', action: true });
            this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -200);
            // this.toastr.success('Profile details updated successfully');
            this.toastr.success(this.translate.instant('companyprofile.toastMsg.saveSuccess'));
          } else {
            this.router.navigate(['/account', { outlets: { 'accountroute': ['information'] } }]);
          }
          if (this.profileLogo !== '') {
            this.dataBinding.changeProfileImg(this.profileLogo);
            localStorage.setItem(AppLocalStorageKeys.USER_IMAGE_URL, this.profileLogo);
          }
          this.dataBinding.changeJobTitle(this.profileForm.controls['profileJobtitle'].value);
          this.dataBinding.changeUserName(this.profileForm.controls['profileFirstName'].value + ' ' +
            this.profileForm.controls['profileLastname'].value);
          localStorage.setItem(AppLocalStorageKeys.JOB_TITLE, this.profileForm.controls['profileJobtitle'].value);
          localStorage.setItem(AppLocalStorageKeys.USER_NAME, this.profileForm.controls['profileFirstName'].value
            + ' ' + this.profileForm.controls['profileLastname'].value);
        } else if (responseProfile.json().length > 0) {
          this.toastr.error('Something went wrong, try again.', 'Account Setup');
          Object.keys(responseProfile.json()).forEach(key => {
            if (responseProfile.json()[key].errors[0] !== null) {
              if (responseProfile.json()[key].errors[0].code === '1668') {
                this.defaultConfig.recordNotSave = this.translate.instant('companyprofile.validationMessage.companysave');
              }
              this.defaultConfig.errorCodeArr[responseProfile.json()[key].property] = responseProfile.json()[key].errors[0].code;
            }
          });
        }
      });
    } else {
      const scrollInvalid = this.profileValidate();
      this.scrollService.scrollTo(document.getElementById(scrollInvalid + 'Id'), 1000, -100);
      if (this.defaultConfig.errorCodeArr['company_about'] !== '') {
        this.scrollService.scrollTo(document.getElementById('fileprofileImg'), 1000, -100);
      }
    }
  }

  profileValidate() {
    for (const Obj in this.profileForm.controls) {
      if (Obj !== '') {
        if (this.flagValid === 1) {
          this.flagValid = this.profileForm.controls[Obj].valid ? 1 : 0;
          this.getProperty = Obj;
        }
        if (!this.profileForm.controls[Obj].valid) {
          if (Obj === 'items' || Obj === 'itemsTax' || Obj === 'itemsAward' || Obj === 'itemsB2B') {
            if (Obj === 'items') {
              this.items.controls.forEach(x => {
                const group = x as FormGroup;
                group.get('name').markAsTouched();
                group.get('id').markAsTouched();
              });
            }
            if (this.isVAT && Obj === 'itemsTax') {
              this.itemsTax.controls.forEach(x => {
                const group = x as FormGroup;
                group.get('name').markAsTouched();
                group.get('id').markAsTouched();
              });
            }
            if (Obj === 'itemsAward') {
              this.itemsAward.controls.forEach(x => {
                const group = x as FormGroup;
                group.get('details').markAsTouched();
                group.get('issued_by').markAsTouched();
              });
            }
            if (Obj === 'itemsB2B') {
              this.itemsB2B.controls.forEach(x => {
                const group = x as FormGroup;
                group.get('B2B_url').markAsTouched();
              });
            }
          } else {
            this.profileForm.controls[Obj].markAsTouched();
          }
        }
      }
    }
    return this.getProperty;
  }

  getUserProfile() {
    this._accountBusiness.getUserProfileBusiness().subscribe(data => {
      this.defaultConfig.preloader = false;
      if (data.length > 0) {
        return false;
      } else {
        this.defaultConfig.jsonData = data;
        this.profileGetData = this.defaultConfig.jsonData;
        this.preFillData(data);
      }
    }, (error) => {
      this.defaultConfig.preloader = false;
    });
  }

  async accountProfileUpload(event, urlLink, width, code, codeDime, max) {
    this.defaultConfig.errorCodeArr['fileprofileLogo'] = '';
    // this.defaultConfig.errorCodeArr['fileprofileFavicon'] = '';
    const selectedFiles = event.target.files;
    const file = selectedFiles.item(0);
    let msgCode = '';
    const elementName = event.target.name;
    if (file) {
      const fileName = file.name;
      let fileExtension = fileName.substr((fileName.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString();
      if (CommonHelper.checkValidImage(fileExtension)) {
        if (CommonHelper.checkValidImageSize(file.size)) {
          this.defaultConfig.preloader = true;
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            img.src = event.target.result;
            img.onload = async function () {
              if (img) {
                // img.width === width && img.height === max
                msgCode = '';
                self.defaultConfig.arrImage[urlLink].src = event.target.result;
                if (elementName === 'fileprofileLogo') {
                  self.dataBinding.changeImageUrl(event.target.result);
                  if (!self.defaultConfig.arrImage[urlLink].loc) {
                    self.percent = self.percent + 5;
                    self.dataBinding.changeMessage(self.percent);
                  }
                }
                if (urlLink === 1) {
                  self.dataBinding.changeFaviconUrl({ data: event.target.result, action: false });
                } else if (urlLink === 2) {
                  self.profileLogo = event.target.result;
                }
                const folderName = 'account-s3/';
                const resImagePath: any = await self.uploadService.uploadfile(file, folderName);
                self.defaultConfig.arrImage[urlLink].loc = resImagePath.key;
              } else {
                msgCode = codeDime;
                self.defaultConfig.errorCodeArr[elementName] = codeDime;
              }
              self.defaultConfig.preloader = false;
            };
          };
          reader.readAsDataURL(event.target.files[0]);
          if (event.target.name === '') {
            this.flagProfileImg = true;
          }
        } else {
          msgCode = '002';
        }
      } else {
        msgCode = code;
      }
      this.defaultConfig.errorCodeArr[event.target.name] = msgCode;
      this.msgCodeImg = msgCode;
    }
  }



  onEditorBlured(quill) {
  }

  onEditorFocused(quill) {
  }

  onEditorCreated(quill) {
    this.editor = quill;
  }

  onContentChanged({ quill, html, text }) {
    this.defaultConfig.htmlContent = html;
    this.contentChange(html);
  }

  contentChange(obj) {
    const htmlContent = this.profileForm.controls['profileHtmlContent'].value;
    if (htmlContent === null || htmlContent.length === 0) {
      this.defaultConfig.errorCodeArr['company_about'] = '1651';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length < 5) {
      this.defaultConfig.errorCodeArr['company_about'] = '1652';
    } else if (String(htmlContent).replace(/<[^>]+>/gm, '').length > 1500) {
      this.defaultConfig.errorCodeArr['company_about'] = '1653';
    } else {
      this.defaultConfig.errorCodeArr['company_about'] = '';
    }
    if (htmlContent !== null && this.Const.flag_percent['aboutCompany'][1] === 1 ||
      htmlContent !== '' && this.Const.flag_percent['aboutCompany'][1] === 1) {
      this.percent = this.percent + this.Const.flag_percent['aboutCompany'][0];
      this.Const.flag_percent['aboutCompany'][1] = 0;
    } else if (htmlContent === null && this.Const.flag_percent['aboutCompany'][1] === 0 ||
      htmlContent === '' && this.Const.flag_percent['aboutCompany'][1]) {
      this.percent = this.percent - this.Const.flag_percent['aboutCompany'][0];
      this.Const.flag_percent['aboutCompany'][1] = 1;
    }
    this.dataBinding.changeMessage(this.percent);
  }

  // Retailer & Distributor Content Expectaion on Change
  contentExpectationChange(obj) {
    const expectationContent = this.profileForm.controls['profileExpectationContent'].value;
    if (expectationContent === null || expectationContent.length === 0) {
      this.defaultConfig.errorCodeArr['expectation'] = '';
    } else if (String(expectationContent).replace(/<[^>]+>/gm, '').length < 5) {
      this.defaultConfig.errorCodeArr['expectation'] = '1661';
    } else if (String(expectationContent).replace(/<[^>]+>/gm, '').length > 1500) {
      this.defaultConfig.errorCodeArr['expectation'] = '1662';
    } else {
      this.defaultConfig.errorCodeArr['expectation'] = '';
    }
  }

  checkFutureYear(controlName: string) {
    if (this.profileForm.controls[controlName].valid &&
      this.profileForm.controls[controlName].value > moment(new Date(), 'DD/MM/YYY').year() ||
      this.profileForm.controls[controlName].valid && this.profileForm.controls[controlName].value < 1830) {
      this.defaultConfig[controlName] = 'futureDate';
    } else {
      this.defaultConfig[controlName] = '';
    }
  }

  initForm() {
    this.Const.alphaNumericPattern = '^[A-Za-z0-9- ]+';
    this.profileForm = this.fb.group({
      profileHtmlContent: [''],
      fileprofileLogo: [''],
      fileprofileImg: [''],
      // ownerFirstName: ['', Validators.compose([Validators.required])],
      // ownerLastName: ['', Validators.compose([Validators.required])],

      profileAuthEmail: [''],
      // fileprofileFavicon: [],
      legalName: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
      // registrationYear: [, Validators.compose([Validators.required, Validators.minLength(4),
      // Validators.maxLength(4), Validators.pattern(this.Const.yearPattern)])],
      profileAddress: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      profileZip: ['', Validators.compose([Validators.required, Validators.minLength(3),
      Validators.maxLength(12)])],
      profileCity: ['', Validators.compose([Validators.required,
        // Validators.pattern(this.Const.alphaNumericPattern)
      ])],
      profileRegAdd: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      profileRegZip: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(12)])],
      profileRegcity: ['', Validators.compose([Validators.required,
        //  Validators.pattern(this.Const.alphaNumericPattern)
      ])],
      items: this.fb.array([]),
      establishYear: [, Validators.compose([Validators.required, Validators.minLength(4),
      Validators.maxLength(4), Validators.pattern(this.Const.yearPattern)])],
      profilePhone: ['',
        Validators.compose([Validators.required, Validators.pattern(this.Const.phoneCodeWithOutPlus), Validators.minLength(4),
        Validators.maxLength(20)
          // , Validators.pattern(this.Const.withoutspace) -- Commenting due to old channel phone no. validation
        ])],
      profilePhoneCode: ['', Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus), Validators.minLength(1),
      Validators.maxLength(6)])],
      profilePhone2: ['',
        Validators.compose([Validators.pattern(this.Const.phoneCodeWithOutPlus), Validators.minLength(4), Validators.maxLength(20),
        ])],
      profilePhone2Code: ['', Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus), Validators.minLength(1),
      Validators.maxLength(6)])],
      profileMobile: ['',
        Validators.compose([Validators.pattern(this.Const.phoneCodeWithOutPlus), Validators.minLength(4), Validators.maxLength(20)
        ])],
      profileMobileCode: ['', Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus), Validators.minLength(1),
      Validators.maxLength(6)])],
      profileemail: ['', Validators.compose([Validators.pattern(this.Const.emailPattern)])],
      profileWebsiteURL: ['', Validators.compose([Validators.required, Validators.minLength(4), Validators.maxLength(253),
        // Validators.pattern(this.Const.urlPatternWithHttp)
      ])],
      itemsTax: this.fb.array([]),
      itemsAward: this.fb.array([]),
      profilelinkedURL: ['', Validators.compose([Validators.minLength(8), Validators.maxLength(254),
        // Validators.pattern(this.Const.urlPatternWithHttp)
      ])],
      // profileGoogleURL: ['', Validators.compose([Validators.minLength(8), Validators.maxLength(254),
      // Validators.pattern(this.Const.urlPatternWithHttp)])],
      profileInstaURL: ['', Validators.compose([Validators.minLength(4), Validators.maxLength(254),
        // Validators.pattern(this.Const.urlPatternWithHttp)
      ])],
      itemsB2B: this.fb.array([]),
      profileFirstName: [''],
      profileLastname: [''],
      profileContactnoCode: [''],
      profileContactno: [''],
      profileAuthContCode: [''],
      profileAuthCont2: [''],
      profileAuthCont2Code: [''],
      profileAuthmob: [''],
      profileAuthmobCode: [''],
      profileJobtitle: [''],
      profileAuthLink: [''],
      profileExpectationContent: [''],
    });
    /** set manitory for profile update */
    if (this.updateFlag) {
      // Task #52251
      // this.profileForm.controls['profileemail'].setValidators([Validators.compose([Validators.required,
      // Validators.pattern(this.Const.emailPattern)])]); 
      // Task #52251

      // this.profileForm.controls['profileAuthLink'].setValidators([Validators.compose([Validators.required,
      // Validators.minLength(2), Validators.pattern(this.Const.urlPattern)])]);
    }
    if (!this.updateFlag) {
      this.profileForm.controls['profileFirstName'].setValidators
        ([Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(30)])]);
      this.profileForm.controls['profileLastname'].setValidators
        ([Validators.compose([Validators.required, Validators.minLength(1), Validators.maxLength(30)])]);
      this.profileForm.controls['profileContactno'].setValidators
        ([Validators.pattern(this.Const.phoneCodeWithOutPlus), Validators.compose([Validators.minLength(4), Validators.maxLength(20)])]);
      this.profileForm.controls['profileAuthCont2'].setValidators
        ([Validators.compose([Validators.pattern(this.Const.phoneCodeWithOutPlus), Validators.minLength(4), Validators.maxLength(20)
        ])]);
      this.profileForm.controls['profileAuthmob'].setValidators
        ([Validators.compose([Validators.required, Validators.pattern(this.Const.phoneCodeWithOutPlus),
        Validators.minLength(4), Validators.maxLength(20)
        ])]);
      this.profileForm.controls['profileContactnoCode'].setValidators
        ([Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus),
        Validators.minLength(1), Validators.maxLength(6)])]);
      this.profileForm.controls['profileAuthCont2Code'].setValidators
        ([Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus),
        Validators.minLength(1), Validators.maxLength(6)])]);
      this.profileForm.controls['profileAuthmobCode'].setValidators
        ([Validators.compose([Validators.pattern(this.Const.phoneCodeWithPlus), Validators.minLength(1), Validators.maxLength(6)])]);
      this.profileForm.controls['profileJobtitle'].setValidators
        // tslint:disable-next-line:max-line-length
        ([Validators.compose([Validators.required, Validators.minLength(2), Validators.maxLength(50)])]);   // VJ maxLength 250 --> 50  01/03/2019
      this.profileForm.controls['profileAuthLink'].setValidators
        ([Validators.compose([Validators.minLength(2),
          // Validators.pattern(this.Const.urlPattern)
        ])]);
      this.profileForm.controls['profileAuthEmail'].setValidators
        ([, Validators.compose([Validators.required, Validators.pattern(this.Const.emailPattern)])]);
    }
  }

  MisMatchPhone(AC: AbstractControl, controlName) {
    const _phone1 = AC.get('profilePhone'); // to get value in input tag
    const _phone2 = AC.get('profilePhone2'); // to get value in input tag
    if ((_phone1.value !== '') && (_phone1.value === _phone2.value)) {
      AC.get(controlName).setErrors({ MisMatchPhone: true });
      // AC.get('profilePhone').setErrors({ MisMatchPhone: true });
    } else {
      // AC.get('profilePhone2').setErrors({ MisMatchPhone: false });
      // AC.get('profilePhone').setErrors({ MisMatchPhone: false });
      return null;
    }
  }

  MisMatchContact(AC: AbstractControl, controlName) {
    const _contact1 = AC.get('profileContactno'); // to get value in input tag
    const _contact2 = AC.get('profileAuthCont2'); // to get value in input tag
    if (_contact1.value !== null && _contact1.value !== '' && _contact1.value === _contact2.value) {
      AC.get(controlName).setErrors({ MisMatchPhone: true });
      // AC.get('profileAuthCont2').setErrors({ MisMatchPhone: true });
    } else {
      return null;
    }
  }

  addItem(name: string, id: string, row_id: number) {
    this.items = this.profileForm.get('items') as FormArray;
    this.items.push(this.buildItem(this.items.length, 1, name, id, row_id, new Date(), ''));
  }

  addItemTax(name: string, id: string, row_id: number) {
    this.itemsTax = this.profileForm.get('itemsTax') as FormArray;
    this.itemsTax.push(this.buildItem(this.itemsTax.length, 2, name, id, row_id, new Date(), ''));
  }

  addItemAward(name: string, id: string, row_id: number, valid_upto: Date, lifeTime: string) {
    this.itemsAward = this.profileForm.get('itemsAward') as FormArray;
    this.itemsAward.push(this.buildItem(this.itemsAward.length, 3, name, id, row_id, valid_upto, lifeTime));
  }

  addItemB2B(name: string, row_id: number) {
    this.itemsB2B = this.profileForm.get('itemsB2B') as FormArray;
    this.itemsB2B.push(this.buildItem(this.itemsB2B.length, 4, name, '', row_id, new Date(), ''));
  }

  LifeTimeToogle(index: number) {
    if (this.itemsAward.controls[index].get('isLifeTime').value === '1') {
      this.itemsAward.controls[index].get('isLifeTime').setValue('0');
    } else {
      this.itemsAward.controls[index].get('isLifeTime').setValue('1');
      this.itemsAward.controls[index].get('valid_upto').setValue(null);
    }
  }

  buildItem(index, type: number, name: string, id: string, row_id: number, valid_upto: Date, isLifeTime: string) {
    let controls = {};
    if (type === 1 || type === 2) {
      if (type === 1) {
        controls = {
          name: new FormControl(name, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(100)])),
          id: new FormControl(id, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(70)])),
        };
      } else {
        controls = {
          name: new FormControl(name),
          id: new FormControl(id),
        };
      }

      if (row_id !== 0) {
        controls['channel_certificate_id'] = new FormControl(row_id);
      }
    } else if (type === 3) {
      let validRequired = null;
      if (index !== 0) {
        validRequired = Validators.required;
      }

      controls = {
        details: new FormControl(name, Validators.compose([validRequired, Validators.minLength(3), Validators.maxLength(254)])),
        issued_by: new FormControl(id, Validators.compose([validRequired, Validators.minLength(3), Validators.maxLength(254)])),
        valid_upto: new FormControl(valid_upto !== null ? moment(valid_upto).format('DD/MM/YYYY') : null),
        isLifeTime: new FormControl(isLifeTime),
        // channel_award_id: new FormControl(row_id),
      };
      if (row_id !== 0) {
        controls['channel_award_id'] = new FormControl(row_id);
      }
    } else if (type === 4) {
      let validRequired = null;
      if (index !== 0) {
        validRequired = Validators.required;
      }
      controls = {
        B2B_url: new FormControl(name, Validators.compose([validRequired, Validators.minLength(3), Validators.maxLength(254)])),
        // channel_B2B_id: new FormControl(row_id)
      };
      if (row_id !== 0) {
        controls['channel_B2B_id'] = new FormControl(row_id);
      }
    }
    return new FormGroup(controls);
  }

  public urlFormatting(unFormattedUrl) {
    if (unFormattedUrl.indexOf('http')) {
      return '//' + unFormattedUrl;
    } else {
      return unFormattedUrl;
    }
  }

  public RemoveLink(link) {
    if (link.indexOf('//')) {
      return '//' + link;
    } else {
      return link;
    }
  }

  preFillData(data) {
    this.channelTypeId = data.channel.channelTypeId ? data.channel.channelTypeId : this.channelTypeId;
    let countryCode = '';
    if (data.channel.regAddress) {
      const countryId = data.channel.regAddress.countryId;
      if (countryId) {
        const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
          === parseInt(countryId, 10));
        countryCode = countryData[0].phoneCode;
        if (countryData[0].isVat && countryData[0].isVat === '1' && this.channelTypeId !== ChannelTypeIdEnum.RETAILER) {
          this.isVAT = true;
        } else {
          this.isVAT = false;
        }
      }
    }
    if (!ValidationService.isNullOrEmpty(data.channel.channelCertificate) && data.channel.channelCertificate.length > 0) {
      Object.keys(data.channel.channelCertificate).forEach(key => {
        const tempData = data.channel.channelCertificate[key];
        (data.channel.channelCertificate[key].cerificateTypeId === 1) ?
          this.addItem(tempData.cerificateName, tempData.cerificateNumber, tempData.channelCerificateId) :
          this.addItemTax(tempData.cerificateName, tempData.cerificateNumber, tempData.channelCerificateId);
      });
    } else {
      this.addItem('', '', 0);
      this.addItemTax('', '', 0);
    }
    if (!ValidationService.isNullOrEmpty(data.channel.channelAward) && data.channel.channelAward.length > 0) {
      Object.keys(data.channel.channelAward).forEach(key => {
        const tempDataAward = data.channel.channelAward[key];
        this.addItemAward(tempDataAward.awardDetail, tempDataAward.issuedBy, tempDataAward.channelAwardId, tempDataAward.validUpto,
          tempDataAward.isLifeTime);
      });
    } else {
      this.addItemAward('', '', 0, null, '0');
    }
    if (!ValidationService.isNullOrEmpty(data.channel.channelB2B) && data.channel.channelB2B.length > 0) {
      Object.keys(data.channel.channelB2B).forEach(key => {
        const tempDataB2B = data.channel.channelB2B[key];
        this.addItemB2B(tempDataB2B.channelB2B, tempDataB2B.channelB2BId);
      });
    } else {
      this.addItemB2B('', 0);
    }
    this.profileGetData = this.defaultConfig.jsonData;
    this.profileForm.controls['legalName'].setValue(this.profileGetData.channel.companyName);
    const channelDetailObj = this.profileGetData.channel.channelDetail;
    if (!ValidationService.isNullOrEmpty(channelDetailObj)) {
      // this.profileForm.controls['ownerFirstName'].setValue
      //   (!ValidationService.isNullOrEmpty(channelDetailObj.ownerFirstName) ? channelDetailObj.ownerFirstName : '');
      // this.profileForm.controls['ownerLastName'].setValue
      //   (!ValidationService.isNullOrEmpty(channelDetailObj.ownerLastName) ? channelDetailObj.ownerLastName : '');
      let phone1 = '';
      if (!ValidationService.isNullOrEmpty(channelDetailObj.phone1)) {
        phone1 = channelDetailObj.phone1.replace(/\s/g, '').split('-');
        this.profileForm.controls['profilePhoneCode'].setValue
          (!ValidationService.isNullOrEmpty(phone1[1]) ? phone1[0] : countryCode);
        this.profileForm.controls['profilePhone'].setValue
          (!ValidationService.isNullOrEmpty(phone1[1]) ? phone1[1] : channelDetailObj.phone1.replace(/\s/g, ''));
      } else {
        this.profileForm.controls['profilePhoneCode'].setValue(countryCode);
      }
      let phone2 = '';
      if (!ValidationService.isNullOrEmpty(channelDetailObj.phone2)) {
        phone2 = channelDetailObj.phone2.replace(/\s/g, '').split('-');
        this.profileForm.controls['profilePhone2Code'].setValue
          (!ValidationService.isNullOrEmpty(phone2[1]) ? phone2[0] : countryCode);
        this.profileForm.controls['profilePhone2'].setValue
          (!ValidationService.isNullOrEmpty(phone2[1]) ? phone2[1] : channelDetailObj.phone2.replace(/\s/g, ''));
      } else {
        this.profileForm.controls['profilePhone2Code'].setValue(countryCode);
      }
      let mobileNo = '';
      if (!ValidationService.isNullOrEmpty(channelDetailObj.mobileNo)) {
        mobileNo = channelDetailObj.mobileNo.replace(/\s/g, '').split('-');
        this.profileForm.controls['profileMobileCode'].setValue
          (!ValidationService.isNullOrEmpty(mobileNo[1]) ? mobileNo[0] : countryCode);
        this.profileForm.controls['profileMobile'].setValue
          (!ValidationService.isNullOrEmpty(mobileNo[1]) ? mobileNo[1] : channelDetailObj.mobileNo.replace(/\s/g, ''));
      } else {
        this.profileForm.controls['profileMobileCode'].setValue(countryCode);
      }
      this.profileForm.controls['establishYear'].setValue
        (!ValidationService.isNullOrEmpty(channelDetailObj.estYear) ? channelDetailObj.estYear : '');
      // this.profileForm.controls['registrationYear'].setValue
      //   (!ValidationService.isNullOrEmpty(channelDetailObj.regYear) ? channelDetailObj.regYear : '');
    }
    this.profileForm.controls['profileAddress'].setValue
      ((!ValidationService.isNullOrEmpty(this.profileGetData.channel.regAddress) ? this.profileGetData.channel.regAddress.address : ''));
    this.profileForm.controls['profileZip'].setValue
      ((!ValidationService.isNullOrEmpty(this.profileGetData.channel.regAddress) ? this.profileGetData.channel.regAddress.postalCode : ''));
    this.profileForm.controls['profileCity'].setValue
      ((!ValidationService.isNullOrEmpty(this.profileGetData.channel.regAddress) ? this.profileGetData.channel.regAddress.city : ''));
    this.profileForm.controls['profileemail'].setValue(this.profileGetData.channel.companyMail);
    this.billAddressFlag = !ValidationService.isNullOrEmpty(this.profileGetData.channel.billAddress);
    this.isSameAddress = (this.billAddressFlag) ?
      (this.profileGetData.channel.regAddress.addressId !==
        this.profileGetData.channel.billAddress.addressId ? false : true) : false;
    this.sameBillAdd = this.updateFlag ? this.isSameAddress : true;
    if (this.billAddressFlag) {
      this.profileForm.controls['profileRegAdd'].setValue(this.profileGetData.channel.billAddress.address);
      this.profileForm.controls['profileRegZip'].setValue(this.profileGetData.channel.billAddress.postalCode);
      this.profileForm.controls['profileRegcity'].setValue(this.profileGetData.channel.billAddress.city);
    }

    let temp_unfromatted_url = '';
    if (!ValidationService.isNullOrEmpty(this.profileGetData.channel.channelDetail)) {
      temp_unfromatted_url = this.profileGetData.channel.channelDetail.webSiteUrl;
      if (temp_unfromatted_url) {
        while (temp_unfromatted_url.charAt(0) === '/') {
          temp_unfromatted_url = temp_unfromatted_url.substring(2);
        }
      }

    }

    this.profileForm.controls['profileWebsiteURL'].setValue(temp_unfromatted_url);
    if (!ValidationService.isNullOrEmpty(this.profileGetData.contact)) {
      // const contactPh1 = this.profileGetData.contact.phone1 ? this.profileGetData.contact.phone1.replace(/\s/g, '') : '';
      // this.profileForm.controls['profileContactno'].setValue(contactPh1);
      let contactPh1 = '';
      if (!ValidationService.isNullOrEmpty(this.profileGetData.contact.phone1)) {
        contactPh1 = this.profileGetData.contact.phone1.replace(/\s/g, '').split('-');
      }
      this.profileForm.controls['profileContactnoCode'].setValue
        (!ValidationService.isNullOrEmpty(contactPh1[1]) ? contactPh1[0] : countryCode);
      this.profileForm.controls['profileContactno'].setValue
        (!ValidationService.isNullOrEmpty(contactPh1[1]) ? contactPh1[1] :
          this.profileGetData.contact.phone1 ? this.profileGetData.contact.phone1.replace(/\s/g, '') : '');
      // const contactPh2 = this.profileGetData.contact.phone2 ? this.profileGetData.contact.phone2.replace(/\s/g, '') : '';
      // this.profileForm.controls['profileAuthCont2'].setValue(contactPh2);
      let contactPh2 = '';
      if (!ValidationService.isNullOrEmpty(this.profileGetData.contact.phone2)) {
        contactPh2 = this.profileGetData.contact.phone2.replace(/\s/g, '').split('-');
        this.profileForm.controls['profileAuthCont2Code'].setValue
          (!ValidationService.isNullOrEmpty(contactPh2[1]) ? contactPh2[0] : countryCode);
        this.profileForm.controls['profileAuthCont2'].setValue
          (!ValidationService.isNullOrEmpty(contactPh2[1]) ? contactPh2[1] : this.profileGetData.contact.phone2.replace(/\s/g, ''));
      } else {
        this.profileForm.controls['profileAuthCont2Code'].setValue(countryCode);
      }
      let contactMob = '';
      if (!ValidationService.isNullOrEmpty(this.profileGetData.contact.mobileNo)) {
        contactMob = this.profileGetData.contact.mobileNo.replace(/\s/g, '').split('-');
        this.profileForm.controls['profileAuthmobCode'].setValue
          (!ValidationService.isNullOrEmpty(contactMob[1]) ? contactMob[0] : countryCode);
        this.profileForm.controls['profileAuthmob'].setValue
          (!ValidationService.isNullOrEmpty(contactMob[1]) ? contactMob[1] : this.profileGetData.contact.mobileNo.replace(/\s/g, ''));
      } else {
        this.profileForm.controls['profileAuthmobCode'].setValue(countryCode);
      }

      this.profileForm.controls['profileFirstName'].setValue(this.profileGetData.contact.firstName);
      this.profileForm.controls['profileLastname'].setValue(this.profileGetData.contact.lastName);
      this.profileForm.controls['profileJobtitle'].setValue(this.profileGetData.contact.jobTitle);
      if (!ValidationService.isNullOrEmpty(this.profileGetData.contact.document)) {
        const documentPathObj = this.profileGetData.contact.document[0];
        const documentPath = documentPathObj.documentUrl ?
          documentPathObj.documentUrl : documentPathObj.documentPath;
        this.defaultConfig.arrImage[2].src = documentPath;
        this.dataBinding.changeProfileImg(documentPath);
        localStorage.setItem(AppLocalStorageKeys.USER_IMAGE_URL, documentPath);
      }
    }
    // const isOldChannel = localStorage.getItem(AppLocalStorageKeys.OLD_CHANNEL);

    let channelLog = 'assets/images/pro-logo.jpg';
    if (this.profileGetData.channel.channelDetail && this.profileGetData.channel.channelDetail.channelLogo) {
      const channelLogo = this.profileGetData.channel.channelDetail.channelLogo;
      channelLog = channelLogo.documentUrl ? channelLogo.documentUrl : channelLogo.documentPath;
    }

    this.defaultConfig.arrImage[0].src =
      !ValidationService.isNullOrEmpty(this.profileGetData.channel.channelDetail) ?
        channelLog : 'assets/images/pro-logo.jpg';

    // let channelIcon = 'assets/images/pro-logo.jpg';
    // if (this.profileGetData.channel.channelDetail.channelIcon && this.profileGetData.channel.channelDetail.channelIcon.documentUrl) {
    //   channelIcon = this.profileGetData.channel.channelDetail.channelIcon.documentUrl;
    // }

    // this.defaultConfig.arrImage[1].src =
    //   !ValidationService.isNullOrEmpty(this.profileGetData.channel.channelDetail) ?
    //     channelIcon : 'assets/images/pro-logo.jpg';
    this.profileForm.controls['profileAuthEmail'].setValue(this.profileGetData.contact.email);
    this.getCountryId = this.profileGetData.channel.countryId;
    this.getCountryIdReg = parseInt((this.profileGetData.channel.regAddress &&
      this.profileGetData.channel.regAddress.countryId) ? this.profileGetData.channel.regAddress.countryId : 0, 10);
    if (this.profileGetData.channel.regAddress && this.profileGetData.channel.regAddress.countryId) {
      const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
        === parseInt(this.profileGetData.channel.regAddress.countryId, 10));
      if (countryData[0].registrationcertificate) {
        this.isRegister = true;
      }
    }
    this.getCountryIdBill = parseInt(this.billAddressFlag ?
      this.profileGetData.channel.billAddress.countryId : 0, 10);
    if (!ValidationService.isNullOrEmpty(data.channel.channelSocial) && data.channel.channelSocial.length > 0) {
      Object.keys(data.channel.channelSocial).forEach(key => {
        if (data.channel.channelSocial[key].socialSite.socialSite === 'Linkedin') {
          let temp_profilelinkedURL = '';
          if (data.channel.channelSocial[key].channelSocialLink) {
            temp_profilelinkedURL = data.channel.channelSocial[key].channelSocialLink;
            if (temp_profilelinkedURL) {
              while (temp_profilelinkedURL.charAt(0) === '/') {
                temp_profilelinkedURL = temp_profilelinkedURL.substring(2);
              }
            }
          }
          this.profileForm.controls['profilelinkedURL'].setValue(temp_profilelinkedURL);
          this.defaultConfig.socialLink = this.profileGetData.channel.channelSocial[key].channelSocialLinkId;
          // } else if (data.channel.channelSocial[key].socialSite.socialSite === 'Googleplus') {
          //   let temp_profileGoogleURL = '';
          //   if (data.channel.channelSocial[key].channelSocialLink) {
          //     temp_profileGoogleURL = data.channel.channelSocial[key].channelSocialLink;
          //     if (temp_profileGoogleURL) {
          //       while (temp_profileGoogleURL.charAt(0) === '/') {
          //         temp_profileGoogleURL = temp_profileGoogleURL.substring(2);
          //       }
          //     }
          //   }
          //   this.profileForm.controls['profileGoogleURL'].setValue(temp_profileGoogleURL);
          //   this.defaultConfig.socialGoogle = this.profileGetData.channel.channelSocial[key].channelSocialLinkId;
        } else if (data.channel.channelSocial[key].socialSite.socialSite === 'Instagram') {
          let temp_profileInstaURL = '';
          if (data.channel.channelSocial[key].channelSocialLink) {
            temp_profileInstaURL = data.channel.channelSocial[key].channelSocialLink;
            if (temp_profileInstaURL) {
              while (temp_profileInstaURL.charAt(0) === '/') {
                temp_profileInstaURL = temp_profileInstaURL.substring(2);
              }
            }
          }
          this.profileForm.controls['profileInstaURL'].setValue(temp_profileInstaURL);
          this.defaultConfig.socialInsta = this.profileGetData.channel.channelSocial[key].channelSocialLinkId;
        }
      });
    }
    if (!ValidationService.isNullOrEmpty(data.contact.contactSocialLink) && data.contact.contactSocialLink.length > 0) {
      Object.keys(data.contact.contactSocialLink).forEach(key => {
        if (data.contact.contactSocialLink[key].socialSite.socialSite === 'Linkedin') {
          this.profileForm.controls['profileAuthLink'].setValue(data.contact.contactSocialLink[key].contactSocialLink);
          this.defaultConfig.contactLinkedin = this.profileGetData.contact.contactSocialLink[key].contactSocialLinkId;
        }
      });
    }
    if (this.profileGetData.channel.channelDetail) {
      this.profileForm.controls['profileHtmlContent'].setValue
        (!ValidationService.isNullOrEmpty(this.profileGetData.channel.channelDetail.detailDesc)
          ? this.profileGetData.channel.channelDetail.detailDesc : '');
      this.profileForm.controls['profileExpectationContent']
        .setValue(!ValidationService.isNullOrEmpty(this.profileGetData.channel.channelDetail.expectations)
          ? this.profileGetData.channel.channelDetail.expectations : '');
    }
    if (data.channel.channelDocument && data.channel.channelDocument.length) {
      this.officialDocs = new Array<FileUploadModel>();
      data.channel.channelDocument.forEach(item => {
        const fileModel = new FileUploadModel();
        fileModel.fileId = item.channelDocumentId;
        fileModel.fileUrl = item.documentPath;
        this.officialDocs.push(fileModel);
      });
    }

    // if (data.channel.regAddress.countryId) {
    //   this.getContryID(data.channel.regAddress.countryId);
    // }

    this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -300);
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      const isOldChannel = localStorage.getItem(AppLocalStorageKeys.OLD_CHANNEL);
      if (isOldChannel === 'true' && !this.updateFlag) {
        this.getOldChannel();
      } else {
        this.getUserProfile();
      }
    });
  }

  onMultipleFileUploaded(event: MultipleFileUploadModel) {
    const channeldocuments: Array<ChannelDocument> = new Array<ChannelDocument>();
    event.source.filter(filterItem => !filterItem.fileId).forEach(item => {
      const channelDocument = new ChannelDocument();
      channelDocument.document = item.fileUploadKey;
      channeldocuments.push(channelDocument);
    });
    this.channel_document = channeldocuments;
    this.defaultConfig.preloader = false;
  }

  onMultipleFileRemoved(event: MultipleFileUploadModel) {
    // this.officialDocErrorCode = '';
    const deletedDocs = new Array<number>();
    event.removedItems.forEach(item => {
      deletedDocs.push(item.fileId);
    });

    if (deletedDocs.length > 0) {
      this.deleted_channel_documents = deletedDocs;
    }

    if (event.source && event.source.length > 0) {
      this.onMultipleFileUploaded(event);
    }
  }

  onMultipleUploadMessageNotify(arg: MessageNotify) {
    if (arg.code === UploadNotifyEnum.UploadedFailed) {
      this.officialDocErrorCode = '0003';
    } else if (arg.code === UploadNotifyEnum.MaximumReached) {
      this.officialDocErrorCode = '0002';
    } else if (arg.code === UploadNotifyEnum.FilesNotAllowed) {
      this.officialDocErrorCode = '0001';
    } else if (arg.code === UploadNotifyEnum.BeforeUpload) {
      this.defaultConfig.preloader = true;
      this.officialDocErrorCode = '';
    } else if (arg.code === UploadNotifyEnum.FileSizeNotAllowed) {
      this.officialDocErrorCode = '0004';
    }
  }

  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }

  // Award Validation Function
  awardValidation(index) {
    const details = this.itemsAward.controls[index].get('details');
    const issuedby = this.itemsAward.controls[index].get('issued_by');
    const islifetime = this.itemsAward.controls[index].get('isLifeTime');
    const validupto = this.itemsAward.controls[index].get('valid_upto');
    if (!details.value && !issuedby.value && islifetime.value === '0' && !validupto.value) {
      details.clearValidators();
      details.setErrors(null);
      issuedby.clearValidators();
      issuedby.setErrors(null);
      islifetime.clearValidators();
      islifetime.setErrors(null);
      validupto.clearValidators();
      validupto.setErrors(null);
    } else {
      details.setValidators([
        Validators.required, Validators.minLength(3), Validators.maxLength(254)]);
      details.setValue(details.value);
      details.markAsTouched();
      issuedby.setValidators([
        Validators.required, Validators.minLength(3), Validators.maxLength(254)]);
      issuedby.setValue(issuedby.value);
      issuedby.markAsTouched();
      if (islifetime.value === '0') {
        validupto.setValidators([
          Validators.required]);
        validupto.setValue(validupto.value);
        validupto.markAsTouched();
      } else {
        validupto.clearValidators();
        validupto.setErrors(null);
      }
    }
  }
}
