import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountTradeInformationComponent } from './account-trade-information.component';

describe('AccountTradeInformationComponent', () => {
  let component: AccountTradeInformationComponent;
  let fixture: ComponentFixture<AccountTradeInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountTradeInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountTradeInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
