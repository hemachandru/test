import { Component, OnInit, ViewChildren, AfterViewInit, QueryList, Input, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { UploadFileService } from '../../../shared/shared-service/upload-file.service';
import {
  TradeInformationData, CustomerSearchItem, DistributorSearchItem,
  distributorSpecialityPost, productCategoriesPostarray,
  TradeInformationGet, BrandListPost,
  tradeInformationDistributorPost,
  specialityPost, tradeInformationRetailerPost,
  tradeInformationVendorPost, listOfServicesPost,
  CustomerTypeList, BrandListItem, customerProfilesPostarray, productFamiliesPostarray, ChannelGet,
  ChannelkeyRetailer, KeyRetailerListItem
} from '@app/account/models/profile';
import {
  Channel, KeyRetailerFilterList, KeyRetailerListPost, KeyRetailerRootObject,
  KeyRetailerSelectedList, ChannelKeyRetailerObject
} from '@app/account/models/trade-information';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { AccountBusiness } from '@app/account/business/account.bussiness';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { environment } from 'environments/environment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AddBrandComponent } from '../add-brand/add-brand.component';
import { ProductCategoryComponent } from '../../../shared/shared-component/product-category/product-category.component';
import {
  Config, tradeLists, ActionType, tradeannualOvers,
  MaturityLevel, UserAccountStatus, AccessPermissionEnum, CountryList
} from '@app/config/constant';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AccountDataService } from '@app/shared/shared-service/account-data.service';
import { Location } from '@angular/common';
import { ScrollToService } from 'ng2-scroll-to-el';
import { Response } from '@angular/http';
import { CommonHelper } from '@app/shared/common-helper';

import {
  ProductCategorySearchItem, SearchItem, CountryMaster, ChannelKeyRetailerGet,
  ErrorCustomModel
} from '@app/shared/models/shared-model';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { MessageDialogComponent } from '../../../shared/shared-component/message-dialog/message-dialog.component';
import { ChannelTypeIdEnum, S3Buckets, AddProductSectionMaxLimit, AWSUrl } from '@app/config/constant';
import { ToastrService } from 'ngx-toastr';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { TranslateService } from '@ngx-translate/core';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { SharedService } from '../../../shared/shared-service/shared-service';
import { ProductKeyRetailerListAdd, Productkeyretailer } from '@app/product/models/add-product';
import { ProductKeyRetailerGet, ProductLocationGet } from '@app/product/models/get-product';

@Component({
  selector: 'app-account-trade-information',
  templateUrl: './account-trade-information.component.html',
  styleUrls: ['./account-trade-information.component.scss']
})
export class AccountTradeInformationComponent implements OnInit, AfterViewInit {
  public scoreClear: boolean;
  public onlinestore: any;
  public physicalstore: any;
  public internationalRevenue: any;
  public demesticRevenue: any;
  public internationalMarket: any;
  public domesticmarketSales: any;
  // public demesticRevenue: any;
  public internationalSales: any;
  public domesticSales: any;
  public distributorTypeclear: number;
  public maturitylevelerror: string;
  public msg_code_ProductCategories: string;
  public errProductCategories: string;
  public specialityerror: string;
  public annualerror: string;
  public empdetailserror: string;
  public retailerError: string;
  public distributorlistError: string;
  public CustomerError: string;
  public ProductFamilycategoryError: string;
  public PrpductFamilyError: string;
  public brandListPostError: string;
  public ProductFamilyError: string;
  @Input() updateFlag = false;
  public maturityShow = false;
  public frenchTechShow: boolean;

  public a: any = 0;
  public b: any = 0;
  public c: any = 0;
  public d: any = 0;
  public opts: ISlimScrollOptions;
  public percent = 0;
  private scoreData: any;
  public annualCount: number;
  public empcount: number;
  public repeatBrand: boolean;
  // public showDetails = false;
  // public showannualDetails = false;
  private channelName: string;
  public channelId: number;
  public activeannualMenu: string;
  public activeMenu: string;
  public retailerType: number;
  public distributorType: number;
  public tradeinfoForm: FormGroup;
  public loading = false;
  formSubmit = false;
  public tradebtnLists: Array<any> = tradeLists;
  public tradeannualOversLists: Array<any> = tradeannualOvers;

  public customerProfileData: Array<CustomerSearchItem> = [];
  public productFamilyData: Array<DistributorSearchItem> = [];
  public productCategoryData: Array<DistributorSearchItem> = [];
  public distributorlistData: Array<DistributorSearchItem> = [];
  public retailerTypeData: Array<DistributorSearchItem> = [];
  public listofservicesData: Array<DistributorSearchItem>;
  public brandlistData: Array<BrandListItem> = [];
  public CustomerType: Array<CustomerTypeList>;
  public brandListSelectedData: Array<any> = [];
  public keyRetailerSelectedData: Array<KeyRetailerSelectedList> = [];
  public keyRetailerUpdatedData: Array<KeyRetailerSelectedList> = [];

  public customerProfileSelectedData: Array<any> = [];
  public productFamilySelectedData: Array<DistributorSearchItem>;
  public productCategorySelectedData: any = [];
  public distributorlistSelectedData: any = [];
  public retailerTypeSelectedData: any = [];
  public listlistofservicesSelectedData: any = [];
  public productCategorylist: any = [];
  private tradeInformationData: TradeInformationData;
  private TradeInformationGetData: TradeInformationGet;

  public customerProfileSelectedId: Array<customerProfilesPostarray> = [];
  public productFamilySelectedId: Array<productFamiliesPostarray> = [];
  public listofservicesSelectedId: Array<listOfServicesPost> = [];
  public distributorSpecialitySelectedId: Array<distributorSpecialityPost> = [];
  public retailerTypeSelectedId: Array<specialityPost> = [];
  public selectedProductcategiesId: Array<productCategoriesPostarray> = [];
  public brandListPost: Array<BrandListPost> = [];
  public keyRetailerPostData: Array<KeyRetailerListPost> = [];
  public scrollbarOptionsl_tradeinfobrand = { axis: 'y', theme: 'dark' };
  public actionType: number;
  public retailerItemsArray: FormArray;
  public retailerGroup: FormGroup;
  // private maxRetailerAllowed: number;
  public urlRetailImg: Array<any>;
  public loaderNotify: EventEmitter<boolean> = new EventEmitter<boolean>();
  public scrollToElementId: string;
  countryMasterList: Array<CountryMaster>;
  public keyRetailerFilterDataChannel: Array<KeyRetailerFilterList> = [];
  public isFrenchCountry: boolean;
  @ViewChildren(ProductCategoryComponent) productCategoryViewChildren: QueryList<ProductCategoryComponent>;

  public _channelTypeEnum = ChannelTypeIdEnum;
  autoCompleteTextEntered: EventEmitter<SearchItem> = new EventEmitter();
  brandListInitialData: Array<any>;
  brandSearchOldValue: string;
  brandSearchNewValue: string;
  // brandPopup: HTMLElement;
  msg_code_retailer;
  dropBox: boolean;
  imageArraytemp = [];
  public scrollbarOptionsTInfo = { axis: 'y', theme: 'dark' };
  public scrollbarOptionsBrand = { axis: 'y', theme: 'dark' };
  deletedkeyretailer: Array<number>;
  userStatus: string;
  storeError: string;
  public isActivatedFirstTime: boolean;
  productKeyRetailerAdd: any;
  channelKeyRetailer: ChannelkeyRetailer[];
  demesticRevenueError: string;
  physicalstoreError: string;
  producturl: string;
  minannualerror: any;
  minempdetailserror: any;
  tempDistributor: any = [];
  domesticSalesError: string;
  internationalSalesError: any;
  domesticmarketSalesError: string;
  internationalMarketError: any;
  retailername: any;
  countryid: any;
  resetFlag: boolean;
  branddisable: any;
  public keyRetailerFilterData: Array<KeyRetailerFilterList> = [];
  public searchKeyretailer: string;
  public _MaturityLevel = MaturityLevel;
  public partnerObjects: object;
  constructor(private dialog: MatDialog, private activatedRoute: ActivatedRoute,
    private router: Router, private scorechangedata: AccountDataService,
    private Const: Config, private formbuilder: FormBuilder, private _location: Location,
    private uploadService: UploadFileService, private scrollService: ScrollToService,
    private accountBusiness: AccountBusiness, private authorizeService: AuthorizeService,
    private toastr: ToastrService, private translate: TranslateService,
    private sharedBusiness: SharedBusiness, private s3UploadFileService: S3UploadFileService,
    private _sharedService: SharedService
  ) {
    this.frenchTechShow = false;
    this.resetFlag = false;
    this.demesticRevenueError = '';
    this.physicalstoreError = '';
    this.brandSearchOldValue = '';
    this.brandSearchNewValue = '';
    // this.tradeInformationData = new TradeInformationData();
    this.TradeInformationGetData = new TradeInformationGet();
    this.customerProfileData = new Array<CustomerSearchItem>();
    this.customerProfileSelectedData = new Array<CustomerSearchItem>();
    this.listlistofservicesSelectedData = new Array<any>();
    this.listofservicesData = new Array<DistributorSearchItem>();
    this.productFamilyData = new Array<DistributorSearchItem>();
    this.productFamilySelectedData = new Array<DistributorSearchItem>();
    // this.keyRetailers = new Array<ChannelKeyRetailerGet>();
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    const data2 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_NAME);
    this.channelName = data2;

    this.opts = {
      barBackground: 'trasparent',
      gridBackground: 'trasparent',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };

    this.errProductCategories = '';
    this.brandListInitialData = new Array<any>();
    this.repeatBrand = false;
    this.channelKeyRetailer = [];
    this.deletedkeyretailer = [];
    this.msg_code_retailer = '';
    this.producturl = environment.AWS_DOWNLOAD_URL + AWSUrl.PRODUCT_CATEGORY;
    this.CustomerType = [];
    this.branddisable = false;
  }

  ngOnInit() {
    this.partnerObjects = {
      '3': {
        'keyRetailerSelectedData': this.keyRetailerSelectedData,
        'keyRetailerFilterData': this.keyRetailerFilterData,
        'keyRetailerPostData': this.keyRetailerPostData,
        'keyRetailerFilterDataChannel': this.keyRetailerFilterDataChannel,
        'keyRetailerUpdatedData': this.keyRetailerUpdatedData,
        'deletedkeyretailer': this.deletedkeyretailer
      },
      '4': {
        'keyRetailerSelectedData': this.keyRetailerSelectedData,
        'keyRetailerFilterData': this.keyRetailerFilterData,
        'keyRetailerPostData': this.keyRetailerPostData,
        'keyRetailerFilterDataChannel': this.keyRetailerFilterDataChannel,
        'keyRetailerUpdatedData': this.keyRetailerUpdatedData,
        'deletedkeyretailer': this.deletedkeyretailer
      }
    };
    this.isFrenchCountry = false;
    this.partnerObjects[3].keyRetailerFilterDataChannel = [];
    this.partnerObjects[4].keyRetailerFilterDataChannel = [];
    this.partnerObjects[3].keyRetailerSelectedData = [];
    this.partnerObjects[4].keyRetailerSelectedData = [];
    this.partnerObjects[3].keyRetailerPostData = [];
    this.partnerObjects[4].keyRetailerPostData = [];

    this.searchKeyretailer = '';
    this.scorechangedata.changeBoolProfile(false);
    this.scorechangedata.changeBoolTrade(true);
    this.scorechangedata.changeBoolLoc(false);
    this.initForm();
    this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -100);
    this.customerType(this.channelId);
    this.changeSearchcustomerProfile('');
    this.scorelist();
    this.getChannelType();
    this.changeretailerType('');
    this.tradeinfoprofileStrength();
    this.changeSearchproductfamily('');
    this.changebrandList('');
    this.getKeyRetailer('', '3');
    this.getKeyRetailer('', '4');
    this.changelistofServices('');
    this.changeretailerType('');
    this.changeDistributorList('');
    // this.listenBrandScrollChange();
    const isOldChannel = localStorage.getItem(AppLocalStorageKeys.OLD_CHANNEL);
    this.userStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS).toString();

    // tslint:disable-next-line:triple-equals
    if (this.userStatus == UserAccountStatus.CHANNEL_APPROVED || isOldChannel === 'true') {
      this.actionType = ActionType.UPDATE;
    } else {
      this.actionType = ActionType.ADD;
    }

    // tslint:disable-next-line:triple-equals
    if (isOldChannel === 'true' && this.userStatus != UserAccountStatus.CHANNEL_APPROVED) {
      this.getOldChannel();
    } else {
      this.tradeinfoGet();
    }

    this.urlRetailImg = [];
    // this.maxRetailerAllowed = 20;
    this.initializeDistributionGroup();
    this.getCountryList();
    // this.preFillKeyRetailers(ChannelKeyRetailerGet[0]);

    if (this.actionType === ActionType.UPDATE) {
      this.partnerObjects[3].deletedkeyretailer = new Array<number>();
      this.partnerObjects[4].deletedkeyretailer = new Array<number>();
    }
  }

  initializeDistributionGroup() {
    this.retailerItemsArray = new FormArray([]);
    this.retailerGroup = new FormGroup({
      retailerItemsArray: this.retailerItemsArray
    });
    this.addRetailerItem('', '', '');
  }

  addRetailerItem(name: string, countryId: string, image: string, retailerId: number = 0, imageId: number = 0) {
    this.retailerItemsArray = this.retailerGroup.get('retailerItemsArray') as FormArray;
    if (this.retailerItemsArray.length < AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit) {
      this.retailerItemsArray.push(this.buildItem(this.retailerItemsArray.length, name, countryId, image, imageId, retailerId));
      this.urlRetailImg.push('');
    } else {
      const error = new ErrorCustomModel();
      error.displayName = this.translate.instant('addProduct.distributionchannelTab.keyRetailer');
      error.requiredLength = AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit;
      this.toastr.warning(this.translate.instant('addProduct.validationMessage.multipleSectionMaxReached', error));
    }
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      const response = data as Response;
      if (response.ok) {
        this.countryMasterList = data;
      }
    });
  }

  buildItem(index, name: string, countryId: string, image: string, imageId: number, retailerId: number) {
    let controls = {};
    controls = {
      retailername: new FormControl(name, Validators.compose([Validators.maxLength(255),
        //  Validators.required
      ])),
      countryid: new FormControl(countryId, Validators.compose([
        // Validators.required
      ])),
      image: new FormControl(image, Validators.compose([
        // Validators.required
      ]))
    };
    // controls['image'] = new FormControl(image);
    // controls['image'] = new FormControl(image, Validators.compose([Validators.required]));
    controls['imageValue'] = new FormControl();
    if (imageId !== 0) {
      controls['productkeyretailerid'] = new FormControl(retailerId);
      controls['documentid'] = new FormControl(imageId);
    }
    return new FormGroup(controls);
  }

  // deleteItem(type, index, id) {
  //   this.retailerItemsArray.removeAt(index);
  //   this.urlRetailImg.splice(index, 1);
  //   if (id !== undefined && id.toString().length > 0 && id !== 0 && this.actionType === ActionType.UPDATE) {
  //     this.deletedkeyretailer.push(id);
  //   }
  // }

  userProfileRetailerUpload(e, Dimension, indexArr) {
    this.addOrRemoveKeyRetailerValidation(indexArr);
    const file = e.target.files.item(0);
    if (file) {
      let fileExtension = file.name.substr((file.name.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString().toLowerCase();
      // if (fileExtension === 'jpeg' || fileExtension === 'jpg' || fileExtension === 'png') {
      if (CommonHelper.checkValidImage(fileExtension)) {
        if (CommonHelper.checkValidImageSize(file.size)) {
          this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: true });
          const reader = new FileReader();
          const img = new Image();
          const self = this;
          // tslint:disable-next-line:no-shadowed-variable
          reader.onload = (event: any) => {
            img.src = event.target.result;
            img.onload = async function () {
              // img.width === Dimension && img.height === Dimension
              if (img) {
                self.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: true });
                self.urlRetailImg[indexArr] = event.target.result;
                const folderName = S3Buckets.ACCOUNT_S3 + '/';
                self.loaderNotify.emit(true);
                const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
                self.loaderNotify.emit(false);
                let imageKey = '';
                if (resImagePath.key) {
                  imageKey = resImagePath.key;
                } else {
                  imageKey = resImagePath.Key;
                }
                self.retailerItemsArray.controls[indexArr].get('imageValue').setValue(imageKey);
                self.retailerItemsArray.controls[indexArr].get('image').setErrors(null);
                self.retailerItemsArray.controls[indexArr].get('image').markAsDirty();
                // return null;
              } else {
                self.urlRetailImg[indexArr] = '';
                self.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFailure: false });
              }
            };
          };
          reader.readAsDataURL(e.target.files[0]);
        } else {
          this.urlRetailImg[indexArr] = '';
          this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadSize: false });
        }
      } else {
        this.urlRetailImg[indexArr] = '';
        this.retailerItemsArray.controls[indexArr].get('image').setErrors({ imageUploadFormat: false });
      }
    }
  }

  getProductRetailer() {
    this.channelKeyRetailer = new Array<ChannelkeyRetailer>();
    for (let i = 0; i < this.retailerItemsArray.controls.length; i++) {
      const tempFormGroup = this.retailerItemsArray.controls[i] as FormGroup;
      const name = tempFormGroup.controls['retailername'].value;
      const countryID = tempFormGroup.controls['countryid'].value;
      const retailermage = tempFormGroup.controls['imageValue'].value;
      const retailer = new ChannelkeyRetailer();
      if (this.actionType === ActionType.UPDATE && tempFormGroup.controls['productkeyretailerid']
        && tempFormGroup.controls['productkeyretailerid'].value) {
        // if (tempFormGroup.dirty) {
        retailer.retailername = name;
        retailer.countryid = parseInt(countryID, 10);
        retailer.channelkeyretailerid = tempFormGroup.controls['productkeyretailerid'].value;
        if (tempFormGroup.controls['documentid'] && tempFormGroup.controls['documentid'].value) {
          retailer.imageid = parseInt(tempFormGroup.controls['documentid'].value, 10);
          retailer.image = retailermage;
        } else {
          if (retailermage) {
            retailer.image = retailermage;
          }
        }

        if (retailer.retailername || retailer.imageid || retailer.image || retailer.countryid || retailer.channelkeyretailerid) {
          this.channelKeyRetailer.push(retailer);
        }
        // else {
        //   delete this.channelKeyRetailer;
        // }

        // }
      } else {
        if (name && countryID) {
          retailer.retailername = name;
          if (retailermage) {
            retailer.image = retailermage;
          }
          retailer.countryid = parseInt(countryID, 10);
          this.channelKeyRetailer.push(retailer);
        } else {
          if (this.channelKeyRetailer.length === 0) {
            delete this.channelKeyRetailer;
          }

        }

      }
    }

    // if (this.channelKeyRetailer.length > 0) {
    return this.channelKeyRetailer;
    // } else {
    // return delete this.channelKeyRetailer;
    // }

  }

  getKeyRetailersList(typeId: string) {
    this.partnerObjects[typeId].keyRetailerPostData = [];
    let count = 0;
    this.partnerObjects[typeId].keyRetailerSelectedData.forEach(item => {
      const keyRetailer = new KeyRetailerListPost();
      if (item.channelId && item.channelId !== null) {
        keyRetailer['existchannelid'] = item.channelId;
      } else if (item.oldchannelid && item.oldchannelid !== null) {
        keyRetailer['oldchannelid'] = item.oldchannelid;
      }
      if (item.keypartnerid) {
        keyRetailer['keypartnerid'] = item.keypartnerid;
      }
      keyRetailer['countryid'] = item.countryid;
      keyRetailer['partnername'] = item.companyName;
      keyRetailer['image'] = item.documentPath;
      keyRetailer['imageid'] = item.imageid;
      const countKeyRetailer = this.partnerObjects[typeId].keyRetailerUpdatedData.
        filter(retailer => retailer.keypartnerid === item.keypartnerid);
      if (countKeyRetailer.length !== 0) {
        count++;
      }
      this.partnerObjects[typeId].keyRetailerPostData.push(keyRetailer);
    });
    if (count === this.partnerObjects[typeId].keyRetailerSelectedData.length) {
      this.partnerObjects[typeId].keyRetailerPostData = [];
    }
  }

  preFillKeyRetailesUpdate(keyRetailers: ChannelKeyRetailerObject[], typeId: string = '3') {
    this.partnerObjects[typeId].keyRetailerUpdatedData = [];
    if (keyRetailers && keyRetailers.length > 0) {
      keyRetailers.forEach(item => {
        const keyRetailerList = new KeyRetailerSelectedList();
        let retailers;
        if (item.active) {
          retailers = item.active;
          keyRetailerList.existchannelid = retailers.id;
          keyRetailerList.channelId = retailers.id;
          this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData.filter
            (key => key.channelId !== retailers.id);
        } else if (item.new) {
          retailers = item.new;
        } else if (item.old) {
          retailers = item.old;
          keyRetailerList.oldchannelid = retailers.id;
          this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData.filter
            (key => key.oldchannelid !== retailers.id);
        }
        if (retailers.company_name) {
          keyRetailerList.companyName = retailers.company_name;
        }
        if (retailers.country) {
          keyRetailerList.countryid = retailers.country.country_id;
          keyRetailerList.countryName = retailers.country.country_name;
        }
        if (retailers.logo) {
          if (item.new) {
            keyRetailerList.documentPath = retailers.logo.logo_name;
          } else {
            keyRetailerList.documentPath = retailers.logo.documentPath;
          }
          keyRetailerList.documentUrl = retailers.logo.documentUrl;
          keyRetailerList.imageid = retailers.logo.logo_id;
        }
        keyRetailerList.keypartnerid = item.keypartnerid;
        this.partnerObjects[typeId].keyRetailerSelectedData.push(keyRetailerList);
        this.partnerObjects[typeId].keyRetailerUpdatedData.push(keyRetailerList);
      });
    }
    this.getKeyRetailer('', '3');
    this.getKeyRetailer('', '4');
  }

  preFillKeyRetailers(keyRetailers: ChannelKeyRetailerGet[]) {
    if (keyRetailers && keyRetailers.length > 0) {
      for (let j = 0; j < this.retailerItemsArray.length; j++) {
        this.retailerItemsArray.removeAt(j);
        this.urlRetailImg.splice(j, 1);
      }
      for (let i = 0; i < keyRetailers.length; i++) {
        const prefillretailerImg = keyRetailers[i].retailerImage ? keyRetailers[i].retailerImage.documentUrl : '';
        this.addRetailerItem(keyRetailers[i].partnername,
          keyRetailers[i].countryid,
          prefillretailerImg,
          parseInt(keyRetailers[i].channelkeyretailerid, 10),
          parseInt(keyRetailers[i].documentid, 10));
        // if (this.actionType === ActionType.UPDATE) {
        this.urlRetailImg[i] = prefillretailerImg;
        // }
      }
      this.setKeyRetailerValidation();
    }
  }

  async onUploadFinished(event) {
    this.dropBox = true;
    const file = event.file;
    const folderName = S3Buckets.ACCOUNT_S3 + '/';
    const resImagePath: any = await this.s3UploadFileService.uploadfile(file, folderName);
    if (resImagePath) {

      // this.imageArraytemp.push({
      //   's3UploadImage': resImagePath.key,
      //   'uploadImage': file.name
      // });
    } else {
      this.onRemoved(event);
      // console.log('s3 srror');
    }
    // if (this.imageArraytemp.length > 0) {
    //   this.claimDocError = '';
    //   this.msg_code = '';
    // }
  }

  // Remove image
  onRemoved(event) {
    this.imageArraytemp.forEach((item, index) => {
      const deleteItem = item.uploadImage === event.file.name;
      if (deleteItem) {
        this.imageArraytemp.splice(index, 1);
      }
    });
  }


  scrollToElement() {
    this.scrollService.scrollTo(document.getElementById(this.scrollToElementId), 1000, -100);
    this.scrollToElementId = '';
  }

  markFormArrayTouched(formarrray) {
    if (formarrray && formarrray.controls) {
      if (formarrray.controls.length) {
        formarrray.controls.forEach(control => {
          if (control) { // control is a FormGroup
            this.markFormArrayTouched(control);
          } else { // control is a FormControl
            control.markAsTouched();
          }
        });
      } else {
        const keys = Object.keys(formarrray.controls);
        keys.forEach(val => {
          const ctrl = formarrray.controls[val];
          if (!ctrl.valid) {
            ctrl.markAsTouched();
          }
        });
      }
    }
  }

  addOrRemoveKeyRetailerValidation(index) {
    const retailernameCtrl = this.retailerItemsArray.controls[index].get('retailername') as FormControl;
    const countryidCtrl = this.retailerItemsArray.controls[index].get('countryid') as FormControl;
    const imageCtrl = this.retailerItemsArray.controls[index].get('image') as FormControl;
    // const retailermagePathCtrl = this.retailerItemsArray.controls['imageValue'];

    if (!retailernameCtrl.value && !countryidCtrl.value && !imageCtrl.value) {
      retailernameCtrl.clearValidators();
      retailernameCtrl.setErrors(null);
      countryidCtrl.clearValidators();
      countryidCtrl.setErrors(null);
      // imageCtrl.setValue('');
      // imageCtrl.clearValidators();
      // imageCtrl.setErrors(null);
    } else {
      retailernameCtrl.setValidators([Validators.required, Validators.maxLength(255)]);
      retailernameCtrl.setValue(retailernameCtrl.value);
      retailernameCtrl.markAsTouched();

      countryidCtrl.setValidators([Validators.required]);
      countryidCtrl.setValue(countryidCtrl.value);
      countryidCtrl.markAsTouched();

      // imageCtrl.setValidators([Validators.required]);
      // if (!imageCtrl.value) {
      //   imageCtrl.setErrors({ required: true });
      // }
      // imageCtrl.markAsTouched();
      // imageCtrl.setValue(imageCtrl.value);
      // imageCtrl.markAsTouched();
    }
  }

  setKeyRetailerValidation() {
    this.retailerItemsArray.controls.forEach(item => {
      const retailername = (item as FormGroup).controls['retailername'] as FormControl;
      const countryid = (item as FormGroup).controls['countryid'] as FormControl;
      const image = (item as FormGroup).controls['image'] as FormControl;

      if (retailername.value || countryid.value || image.value) {
        retailername.setValidators([
          // Validators.required,
          Validators.maxLength(255)]);
        countryid.setValidators([
          // Validators.required
        ]);
        image.setValidators([
          // Validators.required
        ]);
      }
    });
  }

  getOldChannel() {
    this.accountBusiness.getOldChannelTradeBusiness(true).subscribe(res => {
      if (res) {
        const response = res as Response;
        const tradeInformationGet = response.json() as TradeInformationGet;
        this.prefillFunction(tradeInformationGet);
      }
    });
  }
  // Keyboard event prevent e value
  preventkeyValue(id = '') {
    const keyevent = document.getElementById(id);
    if (!ValidationService.isNullOrEmpty(keyevent)) {
      keyevent.addEventListener('keydown', function (e) {
        // prevent: "e", "=", ",", "-", "."
        if ([69, 187, 188, 189, 190].includes(e.keyCode)) {
          e.preventDefault();
        }
      });

    }
  }

  ngAfterViewInit() {
    this.preventkeyValue('domesticSalesId');
    this.preventkeyValue('empcountId');
    this.preventkeyValue('internationalSalesId');
    this.preventkeyValue('domesticmarketSalesId');
    this.preventkeyValue('internationalMarketId');
    // this.preventkeyValue('annualCountId');
    this.preventkeyValue('demesticRevenueId');
    this.preventkeyValue('internationalRevenue');
    this.preventkeyValue('physicalstore');
    this.preventkeyValue('onlinestore');
    // this.tradeinfoGet();
  }

  initForm() {
    this.tradeinfoForm = this.formbuilder.group({
      brandName: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(1),
          Validators.maxLength(255),
          Validators.pattern(this.Const.alphaNumericPattern)
        ]
      )],
      productFamily: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(1),
          Validators.pattern(this.Const.alphaNumericPattern)
        ]
      )],
      customerProfile: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(1),
          Validators.pattern(this.Const.alphaNumericPattern)
        ]
      )],
      distributorName: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(1),
          Validators.pattern(this.Const.alphaNumericPattern)
        ]
      )],
      typedata: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      typeretailerdata: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      emprange: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      empcount: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.minLength(1),
            Validators.pattern(this.Const.numberPattern)
          ]
        )
      ],
      domesticSales: ['',
        Validators.compose(
          [
            Validators.minLength(1),
            Validators.maxLength(6),
            Validators.pattern(this.Const.excludeZeroPattern),
          ]
        )
      ],
      internationalSales: ['',
        Validators.compose(
          [
            Validators.minLength(1),
            Validators.maxLength(6),
            Validators.pattern(this.Const.excludeZeroPattern),
          ]
        )
      ],
      domesticmarketSales: ['',
        Validators.compose(
          [
            Validators.minLength(1),
            Validators.maxLength(6),
            Validators.pattern(this.Const.excludeZeroPattern),
          ]
        )
      ],
      internationalMarket: ['',
        Validators.compose(
          [
            Validators.minLength(1),
            Validators.maxLength(6),
            Validators.pattern(this.Const.excludeZeroPattern),
          ]
        )
      ],
      annualRange: ['',
        Validators.compose(
          [
            Validators.required,
          ]
        )
      ],
      annualCount: ['',
        Validators.compose(
          [
            Validators.required,
            // Validators.minLength(1),
            // Validators.pattern(this.Const.numberPattern)
          ]
        )
      ],
      demesticRevenue: ['',
        Validators.compose(
          [
            Validators.maxLength(2),
            Validators.pattern(this.Const.numberPattern),
            Validators.pattern(this.Const.percentagePattern)
          ]
        )
      ],
      internationalRevenue: ['',
        Validators.compose(
          [
            Validators.maxLength(2),
            Validators.pattern(this.Const.numberPattern),
            Validators.pattern(this.Const.percentagePattern)
          ]
        )
      ],
      physicalstore: ['',
        Validators.compose(
          [
            Validators.maxLength(2),
            Validators.pattern(this.Const.numberPattern),
            Validators.pattern(this.Const.percentagePattern)
          ]
        )
      ],
      onlinestore: ['',
        Validators.compose(
          [
            Validators.maxLength(2),
            Validators.pattern(this.Const.numberPattern),
            Validators.pattern(this.Const.percentagePattern)
          ]
        )
      ],
      nostore: [
        '',
        Validators.compose(
          [
            Validators.required,
            // Validators.minLength(4),
            Validators.maxLength(9),
            Validators.pattern(this.Const.excludeZeroPattern),
          ]
        )
      ],
      retailername: [
        '',
        Validators.compose(
          [
            // Validators.required,
          ]
        )
      ],
      countryid: [
        '',
        Validators.compose(
          [
            // Validators.required,
          ]
        )
      ],
      image: [
        '',
        Validators.compose(
          [
            // Validators.required,
          ]
        )
      ],
      stripId: ['',
        Validators.compose(
          [
            Validators.minLength(1),
            Validators.pattern(this.Const.numberPattern)
          ]
        )
      ],
      maturitylevel: ['',
        Validators.compose(
          [

          ]
        )
      ],
      retailernameDescription: ['',
        Validators.compose(
          [
            Validators.maxLength(2000)
          ]
        )
      ],
      distributornameDescription: ['',
        Validators.compose(
          [
            Validators.maxLength(2000)
          ]
        )
      ],
      maturitylevelPrototype: [false, Validators.compose([])],
      maturitylevelSbackers: [false, Validators.compose([])],
      maturitylevelSvolume: [false, Validators.compose([])],
      keyDistNoOfSKU: [''],
      keyDistNoOfDist: [''],
      keyDistNoOfRetailer: [''],
    }
    );
    if (this.channelId === this._channelTypeEnum.VENDOR) {
      this.tradeinfoForm.controls['keyDistNoOfSKU'].setValidators([Validators.required, Validators.maxLength(4)]);
      this.tradeinfoForm.controls['keyDistNoOfDist'].setValidators([Validators.required, Validators.maxLength(4)]);
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].setValidators([Validators.required, Validators.maxLength(4)]);
    } else if (this.channelId === this._channelTypeEnum.DISTRIBUTOR) {
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].setValidators([Validators.required, Validators.maxLength(4)]);
      this.tradeinfoForm.controls['keyDistNoOfSKU'].clearValidators();
      this.tradeinfoForm.controls['keyDistNoOfDist'].clearValidators();
      this.tradeinfoForm.controls['keyDistNoOfSKU'].setErrors(null);
      this.tradeinfoForm.controls['keyDistNoOfDist'].setErrors(null);
    } else {
      this.tradeinfoForm.controls['keyDistNoOfSKU'].clearValidators();
      this.tradeinfoForm.controls['keyDistNoOfDist'].clearValidators();
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].clearValidators();
      this.tradeinfoForm.controls['keyDistNoOfSKU'].setErrors(null);
      this.tradeinfoForm.controls['keyDistNoOfDist'].setErrors(null);
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].setErrors(null);
    }
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      const hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.PROFILE_TRADE_INFORMATION_UPDATE);
      if (!hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  onSubmit() {
    if (!this.authorizeBeforeSubmit()) {
      return;
    }
    if (this.validation()) {
      delete this.selectedProductcategiesId;
      this.selectedProductcategiesId = new Array<productCategoriesPostarray>();
      const _productCategories: ProductCategoryComponent[] = this.productCategoryViewChildren.toArray();
      _productCategories.forEach(productCategorycomponent => {
        const productfamily = productCategorycomponent.getCategoryId();
        const productfamilycategory = productCategorycomponent.getSelectedCategoryData();
        productfamilycategory.forEach(category => {
          this.selectedProductcategiesId.push({
            productFamilId: parseInt(productfamily.id.toString(), null),
            productCategoriesId: parseInt(category.id.toString(), null)
          });
        });

      });
      this.tradeInformationData = new TradeInformationData();
      if (this.productFamilySelectedId.length > 0
        // && this.customerProfileSelectedId.length > 0
        && this.selectedProductcategiesId.length > 0) {

        this.tradeInformationData.channelType = this.channelId;

        this.tradeInformationData.productFamilies = this.productFamilySelectedId;
        this.tradeInformationData.productCategories = this.selectedProductcategiesId;

        // tradeInformation Distributor Post
        if (this.channelId === 3) {
          this.tradeInformationData.tradeInformationDistributor = new tradeInformationDistributorPost();

          if (this.brandListPost.length > 0 && !ValidationService.isNullOrEmpty(this.distributorType) &&
            this.customerProfileSelectedId.length > 0) {
            this.getKeyRetailersList('4');
            // this.tradeInformationData.tradeInformationDistributor.channelKeyRetailer = this.getProductRetailer();
            if (this.partnerObjects[4].keyRetailerPostData.length > 0) {
              this.tradeInformationData.tradeInformationDistributor.channelKeyRetailer = this.partnerObjects[4].keyRetailerPostData;
            }

            // if (this.tradeinfoForm.controls['retailernameDescription'].value !== null) {
            this.tradeInformationData.tradeInformationDistributor.keyretailers =
              this.tradeinfoForm.controls['retailernameDescription'].value;
            // }

            if (this.partnerObjects[4].deletedkeyretailer.length > 0) {
              this.tradeInformationData.tradeInformationDistributor.deletedkeyretailer = this.partnerObjects[4].deletedkeyretailer;
            }
            this.tradeInformationData.customerProfiles = this.customerProfileSelectedId;
            if (this.distributorType !== 3 && this.distributorSpecialitySelectedId.length > 0) {// broadliner
              if (!ValidationService.isNullOrEmpty(this.distributorSpecialitySelectedId)) {
                this.tradeInformationData.tradeInformationDistributor.distributorSpeciality = this.distributorSpecialitySelectedId;
              }
            }
            if (!ValidationService.isNullOrEmpty(this.distributorType)) {
              if (this.distributorType === 0) {
                this.tradeInformationData.tradeInformationDistributor.profileTypeId = this.distributorTypeclear;
                this.distributorlistSelectedData = [];
                this.distributorSpecialitySelectedId = [];
              } else {
                this.tradeInformationData.tradeInformationDistributor.profileTypeId = this.distributorType;
              }

            }

            if (!ValidationService.isNullOrEmpty(this.brandListPost)) {
              this.tradeInformationData.tradeInformationDistributor.brand = this.brandListPost;
            }
            if (!ValidationService.isNullOrEmpty(this.listofservicesSelectedId)) {
              this.tradeInformationData.tradeInformationDistributor.listOfServices = this.listofservicesSelectedId;
            }


            if (this.activeMenu !== '') {
              this.tradeInformationData.tradeInformationDistributor.employeesRange = this.activeMenu;

            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['empcount'].value)) {
              this.tradeInformationData.tradeInformationDistributor.employeesCount
                = parseInt(this.tradeinfoForm.controls['empcount'].value, null);

            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['domesticSales'].value)) {
              this.tradeInformationData.tradeInformationDistributor.domesticSales
                = parseInt(this.tradeinfoForm.controls['domesticSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.domesticSales = null;
            }


            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalSales'].value)) {
              this.tradeInformationData.tradeInformationDistributor.internationalSales
                = parseInt(this.tradeinfoForm.controls['internationalSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.internationalSales = null;
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['domesticmarketSales'].value)) {
              this.tradeInformationData.tradeInformationDistributor.domesticMarketing
                = parseInt(this.tradeinfoForm.controls['domesticmarketSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.domesticMarketing = null;
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalMarket'].value)) {
              this.tradeInformationData.tradeInformationDistributor.internationalMarketing
                = parseInt(this.tradeinfoForm.controls['internationalMarket'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.internationalMarketing = null;
            }

            if (this.activeannualMenu !== '') {
              this.tradeInformationData.tradeInformationDistributor.annualTurnoverRange = this.activeannualMenu;

            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['annualCount'].value)) {
              this.tradeInformationData.tradeInformationDistributor.annualTurnover
                = parseFloat(this.tradeinfoForm.controls['annualCount'].value);

            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['demesticRevenue'].value)) {
              this.tradeInformationData.tradeInformationDistributor.domesticRevenue
                = parseInt(this.tradeinfoForm.controls['demesticRevenue'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.domesticRevenue = null;
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalRevenue'].value)) {
              this.tradeInformationData.tradeInformationDistributor.internationalRevenue
                = parseInt(this.tradeinfoForm.controls['internationalRevenue'].value, null);
            } else {
              this.tradeInformationData.tradeInformationDistributor.internationalRevenue = null;
            }


            if (this.maturityShow === true) {
              this.tradeInformationData.tradeInformationDistributor.startup = '1';

              if (this.getMaturityList().length) {
                this.tradeInformationData.tradeInformationDistributor.maturitylevel = this.getMaturityList();
              }
            }
            if (this.maturityShow === false) {
              this.tradeInformationData.tradeInformationDistributor.startup = '0';
            }
          }
          this.tradeInformationData.tradeInformationDistributor.no_of_retailers =
            parseInt(this.tradeinfoForm.controls['keyDistNoOfRetailer'].value, 10);
        }
        // // tradeInformation Vendor Post
        if (this.channelId === 2) {
          if (this.brandListPost.length > 0 && this.customerProfileSelectedId.length > 0) {
            this.tradeInformationData.customerProfiles = this.customerProfileSelectedId;
            this.tradeInformationData.tradeInformationVendor = new tradeInformationVendorPost();
            this.getKeyRetailersList('3');
            this.getKeyRetailersList('4');
            // if (this.retailerItemsArray.length < AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit) {
            // this.tradeInformationData.tradeInformationVendor.channelKeyRetailer = this.getProductRetailer();
            if (this.partnerObjects[3].keyRetailerPostData.length > 0) {
              this.tradeInformationData.tradeInformationVendor.channelKeyDistributor = this.partnerObjects[3].keyRetailerPostData;
            }
            if (this.partnerObjects[4].keyRetailerPostData.length > 0) {
              this.tradeInformationData.tradeInformationVendor.channelKeyRetailer = this.partnerObjects[4].keyRetailerPostData;
            }
            // if (this.tradeinfoForm.controls['retailernameDescription'].value !== null) {
            this.tradeInformationData.tradeInformationVendor.keyretailers =
              this.tradeinfoForm.controls['retailernameDescription'].value;
            this.tradeInformationData.tradeInformationVendor.keydistributors =
              this.tradeinfoForm.controls['distributornameDescription'].value;
            // }
            // } else {
            //   const error = new ErrorCustomModel();
            //   error.displayName = this.translate.instant('addProduct.distributionchannelTab.keyRetailer');
            //   error.requiredLength = AddProductSectionMaxLimit.ProductKeyRetailerMaxLimit;
            //   this.toastr.warning(this.translate.instant('addProduct.validationMessage.multipleSectionMaxReached', error));
            // }

            if (this.partnerObjects[4].deletedkeyretailer.length > 0) {
              const deletedKeys = this.partnerObjects[4].deletedkeyretailer;
              for (let _i = 0; _i < deletedKeys.length; _i++) {
                if (this.filterDeletedRecordswithSelectedKeyRetailers
                  ('4', deletedKeys[_i], this.partnerObjects[4].keyRetailerUpdatedData)) {
                  deletedKeys.splice(_i);
                }
              }
              if (deletedKeys.length > 0) {
                this.tradeInformationData.tradeInformationVendor.deletedkeyretailer = deletedKeys;
              }
              // this.tradeInformationData.tradeInformationVendor.deletedkeyretailer = this.partnerObjects[4].deletedkeyretailer;
            }
            if (this.partnerObjects[3].deletedkeyretailer.length > 0) {
              const deletedKeys = this.partnerObjects[3].deletedkeyretailer;
              for (let _i = 0; _i < deletedKeys.length; _i++) {
                if (this.filterDeletedRecordswithSelectedKeyRetailers('3', deletedKeys[_i],
                 this.partnerObjects[3].keyRetailerUpdatedData)) {
                  deletedKeys.splice(_i);
                }
              }
              if (deletedKeys.length > 0) {
                this.tradeInformationData.tradeInformationVendor.deletedkeydistributor = deletedKeys;
              }
              // this.tradeInformationData.tradeInformationVendor.deletedkeydistributor = this.partnerObjects[3].deletedkeyretailer;
            }
            this.tradeInformationData.tradeInformationVendor.profileTypeId = 1;
            if (this.brandListPost.length > 0) {
              this.tradeInformationData.tradeInformationVendor.brand = this.brandListPost;
            }
            if (this.activeMenu !== '') {
              this.tradeInformationData.tradeInformationVendor.employeesRange = this.activeMenu;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['empcount'].value)) {
              this.tradeInformationData.tradeInformationVendor.employeesCount
                = parseInt(this.tradeinfoForm.controls['empcount'].value, null);
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['domesticSales'].value)) {
              this.tradeInformationData.tradeInformationVendor.domesticSales
                = parseInt(this.tradeinfoForm.controls['domesticSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.domesticSales = null;
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalSales'].value)) {
              this.tradeInformationData.tradeInformationVendor.internationalSales
                = parseInt(this.tradeinfoForm.controls['internationalSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.internationalSales = null;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['domesticmarketSales'].value)) {
              this.tradeInformationData.tradeInformationVendor.domesticMarketing
                = parseInt(this.tradeinfoForm.controls['domesticmarketSales'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.domesticMarketing = null;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalMarket'].value)) {
              this.tradeInformationData.tradeInformationVendor.internationalMarketing
                = parseInt(this.tradeinfoForm.controls['internationalMarket'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.internationalMarketing = null;
            }
            if (this.activeannualMenu !== '') {
              this.tradeInformationData.tradeInformationVendor.annualTurnoverRange = this.activeannualMenu;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['annualCount'].value)) {
              this.tradeInformationData.tradeInformationVendor.annualTurnover
                = parseFloat(this.tradeinfoForm.controls['annualCount'].value);
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['demesticRevenue'].value)) {
              this.tradeInformationData.tradeInformationVendor.domesticRevenue
                = parseInt(this.tradeinfoForm.controls['demesticRevenue'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.domesticRevenue = null;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['internationalRevenue'].value)) {
              this.tradeInformationData.tradeInformationVendor.internationalRevenue
                = parseInt(this.tradeinfoForm.controls['internationalRevenue'].value, null);
            } else {
              this.tradeInformationData.tradeInformationVendor.internationalRevenue = null;
            }
            if (this.maturityShow === true) {
              this.tradeInformationData.tradeInformationVendor.startup = '1';

              if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['maturitylevel'].value)) {
                this.tradeInformationData.tradeInformationVendor.maturitylevel = [this.tradeinfoForm.controls['maturitylevel'].value];
              }
            }
            if (this.maturityShow === false) {
              this.tradeInformationData.tradeInformationVendor.startup = '0';
            }
          }
          this.tradeInformationData.tradeInformationVendor.no_of_retailers =
            parseInt(this.tradeinfoForm.controls['keyDistNoOfRetailer'].value, 10);
          this.tradeInformationData.tradeInformationVendor.no_of_skus =
            parseInt(this.tradeinfoForm.controls['keyDistNoOfSKU'].value, 10);
          this.tradeInformationData.tradeInformationVendor.no_of_distributors =
            parseInt(this.tradeinfoForm.controls['keyDistNoOfDist'].value, 10);

        }
        //  tradeInformation Retailer Post
        if (this.channelId === 4) {
          if (!ValidationService.isNullOrEmpty(this.retailerType)) {
            this.tradeInformationData.tradeInformationRetailer = new tradeInformationRetailerPost();
            // this.retailerTypeSelectedId.length > 0 &&
            // if (!ValidationService.isNullOrEmpty(this.retailerTypeSelectedId)) {
            //   this.tradeInformationData.tradeInformationRetailer.speciality = this.retailerTypeSelectedId;
            // }
            if (!ValidationService.isNullOrEmpty(this.retailerType)) {
              this.tradeInformationData.tradeInformationRetailer.profileTypeId = this.retailerType;
            }
            delete this.tradeInformationData.tradeInformationRetailer.speciality;
            delete this.tradeInformationData.customerProfiles;
            if (this.activeMenu !== '') {
              this.tradeInformationData.tradeInformationRetailer.employeesRange = this.activeMenu;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['empcount'].value)) {
              this.tradeInformationData.tradeInformationRetailer.employeesCount
                // tslint:disable-next-line:radix
                = parseInt(this.tradeinfoForm.controls['empcount'].value);
            }

            if (this.activeannualMenu !== '') {
              this.tradeInformationData.tradeInformationRetailer.annualTurnoverRange = this.activeannualMenu;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['annualCount'].value)) {
              this.tradeInformationData.tradeInformationRetailer.annualTurnover
                // tslint:disable-next-line:radix
                = parseFloat(this.tradeinfoForm.controls['annualCount'].value);
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['physicalstore'].value)) {
              this.tradeInformationData.tradeInformationRetailer.physicalStore
                = parseInt(this.tradeinfoForm.controls['physicalstore'].value, null);
            } else {
              this.tradeInformationData.tradeInformationRetailer.physicalStore = null;
            }
            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['onlinestore'].value)) {
              this.tradeInformationData.tradeInformationRetailer.OnlineStore
                = parseInt(this.tradeinfoForm.controls['onlinestore'].value, null);
            } else {
              this.tradeInformationData.tradeInformationRetailer.OnlineStore = null;
            }

            if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['nostore'].value)) {
              this.tradeInformationData.tradeInformationRetailer.storeCount
                = parseInt(this.tradeinfoForm.controls['nostore'].value, null);
            } else {
              this.tradeInformationData.tradeInformationRetailer.storeCount = null;
            }

            if (this.maturityShow === true) {
              this.tradeInformationData.tradeInformationRetailer.startup = '1';

              if (this.getMaturityList().length) {
                this.tradeInformationData.tradeInformationRetailer.maturitylevel = this.getMaturityList();
              }
            }
            if (this.maturityShow === false) {
              this.tradeInformationData.tradeInformationRetailer.startup = '0';
            }
          }
        }
        this.tradeInformationData.is_french_tech = this.frenchTechShow ? '1' : '0';
        if (this.updateFlag) {
          this.loading = true;
          this.accountBusiness.putTradeInformation(this.tradeInformationData, true, this.updateFlag).subscribe(res => {
            const response = res as Response;
            this.loading = false;
            if (response.ok) {
              this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -100);
              this.toastr.success(this.translate.instant('tradeinformation.toastMsg.tradeSuccess'));
              // this.tradeinfoGet();
              this.tradeinfoGet();
            } else {
              this.toastr.error(this.translate.instant('tradeinformation.toastMsg.tradeinfoerror'));
            }
          });
        } else {
          this.loading = true;
          this.accountBusiness.postTradeInformation(this.tradeInformationData, true, this.updateFlag).subscribe(res => {
            const response = res as Response;
            this.loading = false;
            if (response.ok) {
              this.router.navigate(['/account', { outlets: { 'accountroute': ['location'] } }]);
              this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000);
              this.tradeinfoGet();
            }
          });
        }
      }
    }
  }

  // Get Previous Profile Strength
  getChannelType() {
    this.accountBusiness.getUserTypeProfileBusiness().subscribe(data => {
      if (!ValidationService.isNullOrEmpty(data.channel)) {
        this.percent = data.channel.profileStrength;
      }

      if (!ValidationService.isNullOrEmpty(data.channel.channelDetail.channelLogo)) {
        this.scorechangedata.changeImageUrl(data.channel.channelDetail.channelLogo.documentUrl);
      }
    });
  }


  tradeMaturityYes() {
    this.maturityShow = true;
  }

  tradeMaturityNO() {
    this.maturityShow = false;
    if (this.channelId === this._channelTypeEnum.VENDOR) {
      this.maturity('');
    }
  }


  // Remove the Customer Profile
  removecustomerProfileData(item: CustomerSearchItem) {
    const index: number = this.customerProfileSelectedData.indexOf(item, 0);
    if (index !== -1) {
      this.customerProfileSelectedData.splice(index, 1);
      this.customerProfileSelectedId.splice(index, 1);
      this.customerProfileData = this.customerProfileData.filter(ite =>
        ite.Channel_Profile_Type_Classification_ID.toString() !== item.Channel_Profile_Type_Classification_ID.toString());
      this.customerProfileData.push(item);
    }
  }

  // Select the Customer Profile
  selectedProfile(profileitem: CustomerSearchItem) {
    this.commonselectedItem(profileitem, this.customerProfileSelectedData);
    if (this.customerProfileSelectedData.length > 0) {
      this.CustomerError = '';
    }
    // Post Push
    this.customerProfileSelectedId.push({
      // tslint:disable-next-line:radix
      id: parseInt(profileitem.Channel_Profile_ID.toString()),
      profileTypeClassificationId: profileitem.Channel_Profile_Type_Classification_ID
    });

    if (this.customerProfileData.length > 0) {
      this.customerProfileData = this.customerProfileData.filter(item =>
        item.Channel_Profile_Type_Classification_ID.toString() !== profileitem.Channel_Profile_Type_Classification_ID.toString());
    }

  }

  // Search the Customer Profile
  changeSearchcustomerProfile(event) {
    this.customerProfileData = new Array<CustomerSearchItem>();
    this.accountBusiness.getCustomerProfile(event, this.channelId).subscribe(result => {

      // for Distributor
      if (this.channelId === 3) {
        if (result.RETAILER.length > 0) {
          (<Array<CustomerSearchItem>>(result.RETAILER)).forEach(ret => {
            const retItem = new CustomerSearchItem();
            retItem.Channel_Profile_ID = ret.Channel_Profile_ID;
            retItem.Channel_Profile_Name = ret.Channel_Profile_Name + ' ' + '-' + ' ' + ret.Channel_Type_Name.toLocaleLowerCase();
            retItem.Channel_Profile_Type_Classification_ID = ret.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(retItem);
          });
        }

        // if (result.DISTRIBUTOR.length > 0) {
        //   (<Array<CustomerSearchItem>>(result.DISTRIBUTOR)).forEach(des => {
        //     const desItem = new CustomerSearchItem();
        //     desItem.Channel_Profile_ID = des.Channel_Profile_ID;
        //     desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
        //     desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
        //     this.customerProfileData.push(desItem);
        //   });
        // }

        // if (result.SALESREP.length > 0) {
        //   (<Array<CustomerSearchItem>>(result.SALESREP)).forEach(sal => {
        //     const salItem = new CustomerSearchItem();
        //     salItem.Channel_Profile_ID = sal.Channel_Profile_ID;
        //     salItem.Channel_Profile_Name = sal.Channel_Profile_Name + ' ' + '-' + ' ' + sal.Channel_Type_Name.toLocaleLowerCase();
        //     salItem.Channel_Profile_Type_Classification_ID = sal.Channel_Profile_Type_Classification_ID;
        //     this.customerProfileData.push(salItem);
        //   });
        // }
      } else if (this.channelId === 2) {
        // if (result.DISTRIBUTOR.length > 0) {
        //   (<Array<CustomerSearchItem>>(result.DISTRIBUTOR)).forEach(des => {
        //     const desItem = new CustomerSearchItem();
        //     desItem.Channel_Profile_ID = des.Channel_Profile_ID;
        //     desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
        //     desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
        //     this.customerProfileData.push(desItem);
        //   });
        // }

        if (result.RETAILER.length > 0) {
          (<Array<CustomerSearchItem>>(result.RETAILER)).forEach(des => {
            const desItem = new CustomerSearchItem();
            desItem.Channel_Profile_ID = des.Channel_Profile_ID;
            desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
            desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(desItem);
          });
        }

        // if (result.SALESREP.length > 0) {
        //   (<Array<CustomerSearchItem>>(result.SALESREP)).forEach(sal => {
        //     const salItem = new CustomerSearchItem();
        //     salItem.Channel_Profile_ID = sal.Channel_Profile_ID;
        //     salItem.Channel_Profile_Name = sal.Channel_Profile_Name + ' ' + '-' + ' ' + sal.Channel_Type_Name.toLocaleLowerCase();
        //     salItem.Channel_Profile_Type_Classification_ID = sal.Channel_Profile_Type_Classification_ID;
        //     this.customerProfileData.push(salItem);
        //   });
        // }
      } else if (this.channelId === 4) {
        if (result.VENDOR.length > 0) {
          (<Array<CustomerSearchItem>>(result.VENDOR)).forEach(sal => {
            const salItem = new CustomerSearchItem();
            salItem.Channel_Profile_ID = sal.Channel_Profile_ID;
            salItem.Channel_Profile_Name = sal.Channel_Profile_Name + ' ' + '-' + ' ' + sal.Channel_Type_Name.toLocaleLowerCase();
            salItem.Channel_Profile_Type_Classification_ID = sal.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(salItem);
          });
        }

        if (result.DISTRIBUTOR.length > 0) {
          (<Array<CustomerSearchItem>>(result.DISTRIBUTOR)).forEach(des => {
            const desItem = new CustomerSearchItem();
            desItem.Channel_Profile_ID = des.Channel_Profile_ID;
            desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
            desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(desItem);
          });
        }
      } else {

        if (result.VENDOR.length > 0) {
          (<Array<CustomerSearchItem>>(result.VENDOR)).forEach(sal => {
            const salItem = new CustomerSearchItem();
            salItem.Channel_Profile_ID = sal.Channel_Profile_ID;
            salItem.Channel_Profile_Name = sal.Channel_Profile_Name + ' ' + '-' + ' ' + sal.Channel_Type_Name.toLocaleLowerCase();
            salItem.Channel_Profile_Type_Classification_ID = sal.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(salItem);
          });
        }

        if (result.DISTRIBUTOR.length > 0) {
          (<Array<CustomerSearchItem>>(result.DISTRIBUTOR)).forEach(des => {
            const desItem = new CustomerSearchItem();
            desItem.Channel_Profile_ID = des.Channel_Profile_ID;
            desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
            desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(desItem);
          });
        }

        if (result.RETAILER.length > 0) {
          (<Array<CustomerSearchItem>>(result.RETAILER)).forEach(des => {
            const desItem = new CustomerSearchItem();
            desItem.Channel_Profile_ID = des.Channel_Profile_ID;
            desItem.Channel_Profile_Name = des.Channel_Profile_Name + ' ' + '-' + ' ' + des.Channel_Type_Name.toLocaleLowerCase();
            desItem.Channel_Profile_Type_Classification_ID = des.Channel_Profile_Type_Classification_ID;
            this.customerProfileData.push(desItem);
          });
        }
      }

    },
      (error) => {
        console.log(error);
      });

  }

  // Remove the List of Service
  removelistofServicesData(data) {
    const index: number = this.listlistofservicesSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.listlistofservicesSelectedData.splice(index, 1);
      this.listofservicesSelectedId.splice(index, 1);
      this.listofservicesData = this.listofservicesData.filter(ite => ite.id.toString() !== data.id.toString());
      this.listofservicesData.push(data);
    }
  }

  // Select the List of Service
  selectedlistofServices(profileitem: DistributorSearchItem) {
    this.commonselectedItem(profileitem, this.listlistofservicesSelectedData);
    this.listofservicesSelectedId.push({
      // tslint:disable-next-line:radix
      id: parseInt(profileitem.id.toString())
    });
    if (this.listofservicesData.length > 0) {
      this.listofservicesData = this.listofservicesData.filter(item => item.id.toString() !== profileitem.id.toString());
    }
  }

  // common flag item
  commonselectedItem(selectItem, selectArray) {
    const flage = 1;

    for (let i = 0; i < selectArray.length; i++) {
      if (selectItem.Channel_Profile_ID !== 0 && selectItem.Channel_Profile_ID !== undefined) {
        if (selectArray[i].id === selectItem.Channel_Profile_ID) {
          return false;
        }
      } else {
        if (selectArray[i].id === selectItem.id) {
          return false;
        }
      }
    }

    if (flage === 1) {
      selectArray.push(selectItem);
    }

  }

  // Search the List of Service
  changelistofServices(event) {
    this.accountBusiness.getListService(event).subscribe(result => {
      this.listofservicesData = result as Array<DistributorSearchItem>;
      // if (this.listofservicesData.length > 0) {
      //   this.listofservicesData = this.listofservicesData;
      // }
    },
      (error) => {
        console.log(error);
      });
  }

  // Remove the Product Family
  public async removeproductfamilyData(data: DistributorSearchItem): Promise<any> {
    this.productFamilySelectedData = this.productFamilySelectedData.filter(item => item.id.toString() !== data.id.toString());
    this.productFamilySelectedId = this.productFamilySelectedId.filter(item => item.id.toString() !== data.id.toString());
    this.productCategorylist = this.productCategorylist.filter(item => item.id.toString() !== data.id.toString());
    this.productFamilyData = this.productFamilyData.filter(ite => ite.id.toString() !== data.id.toString());
    this.productFamilyData.push(data);
    // remove specific product family and categories
    this.productCategorySelectedData = this.productCategorySelectedData.filter(category => category.productGroupId !== data.id.toString());
    if (this.productFamilySelectedData.length === 0) {
      this.scoreClear = true;
      this.percent = this.percent - this.scoreData.productGroup;
      this.scorechangedata.changeMessage(this.percent);
    }
    this.scoreClear = false;
  }

  // Select the Product Family
  selectedproductfamily(profileitem: DistributorSearchItem) {
    // Profile Score
    if (this.productFamilySelectedData.length === 1 && !this.scoreClear) {
      this.percent = this.percent + this.scoreData.productGroup;
      this.scorechangedata.changeMessage(this.percent);
    }
    this.commonselectedItem(profileitem, this.productFamilySelectedData);
    if (this.productFamilySelectedData.length > 0) {
      this.ProductFamilyError = '';
    }

    // Post Push
    this.productFamilySelectedId.push({
      // tslint:disable-next-line:radix
      id: parseInt(profileitem.id.toString())
    });
    if (this.productFamilyData.length > 0) {

      this.productFamilyData = this.productFamilyData.filter(item => item.id.toString() !== profileitem.id.toString());
    }

    this.commonselectedItem(profileitem, this.productCategorylist);
    this.resetFlag = true;

  }

  // Search the  Product Family
  changeSearchproductfamily(event) {

    this.accountBusiness.getProductFamily(event).subscribe(result => {

      if (result.length > 0) {
        this.productFamilyData = result as Array<DistributorSearchItem>;
        if (this.productFamilyData.length > 0) {
          this.productFamilySelectedData.forEach(selectitem => {
            this.productFamilyData = this.productFamilyData.filter(item => item.id.toString() !== selectitem.id.toString());
          });
        }
      }
    },
      (error) => {
        console.log(error);
      });

  }

  // Remove the Distributor List
  removedistributorlistData(data) {
    const index: number = this.distributorlistSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.distributorlistSelectedData.splice(index, 1);
      this.distributorSpecialitySelectedId.splice(index, 1);
      this.distributorlistData = this.distributorlistData.filter(ite => ite.id.toString() !== data.id.toString());
      this.distributorlistData.push(data);
      if (this.distributorlistSelectedData.length === 0) {
        this.scoreClear = true;
        this.percent = this.percent - this.scoreData.speciality;
        this.scorechangedata.changeMessage(this.percent);
      }
      this.scoreClear = false;
    }
  }

  // Select the Distributor List
  selectedDistributorlist(profileitem: DistributorSearchItem) {
    if (this.distributorlistSelectedData.length < 3) {
      this.commonselectedItem(profileitem, this.distributorlistSelectedData);
      if (this.distributorlistSelectedData.length > 0) {
        this.distributorlistError = '';
      }
      this.distributorSpecialitySelectedId.push({
        // tslint:disable-next-line:radix
        specialityId: parseInt(profileitem.id.toString()),
      });

      // profile score
      if (this.distributorlistSelectedData.length === 1 && !this.scoreClear) {
        this.percent = this.percent + this.scoreData.speciality;
        this.scorechangedata.changeMessage(this.percent);
      }
      if (this.distributorlistData.length > 0) {
        this.distributorlistData = this.distributorlistData.filter(item => item.id.toString() !== profileitem.id.toString());
      }

      // add the my speciality to my product group Task #52467
      if (!this.productFamilySelectedId.some(item => item.id === +profileitem.id)) {
        this.selectedproductfamily(profileitem);
      }
    } else {
      this.toastr.warning(this.translate.instant('tradeinformation.validationMessage.specialitymax'));
    }
  }

  // Search the Distributor List
  changeDistributorList(event) {
    this.accountBusiness.getProductFamily(event).subscribe(result => {
      this.distributorlistData = result as Array<DistributorSearchItem>;
      // if (this.distributorlistData.length > 0) { Sonar bugs
      //   this.distributorlistData = this.distributorlistData;
        if (this.distributorlistData.length > 0) {
          this.distributorlistSelectedData.forEach(selectitem => {
            this.distributorlistData = this.distributorlistData.filter(item => item.id.toString() !== selectitem.id.toString());
          });
        }
      // }
    },
      (error) => {
        console.log(error);
      });
  }

  // Remove the Retailer Types
  removeretailerTypeData(data) {
    const index: number = this.retailerTypeSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.retailerTypeSelectedData.splice(index, 1);
      this.retailerTypeSelectedId.splice(index, 1);
      this.retailerTypeData = this.retailerTypeData.filter(ite => ite.id.toString() !== data.id.toString());
      this.retailerTypeData.push(data);
      if (this.retailerTypeSelectedData.length === 0) {
        this.scoreClear = true;
        this.percent = this.percent - this.scoreData.speciality;
        this.scorechangedata.changeMessage(this.percent);
      }
      this.scoreClear = false;
    }
  }

  // Select the Retailer Types
  selectedretailerType(profileitem: DistributorSearchItem) {
    if (this.retailerTypeSelectedData.length < 3) {
      this.commonselectedItem(profileitem, this.retailerTypeSelectedData);

      if (this.retailerTypeSelectedData.length > 0) {
        this.retailerError = '';
      }

      this.retailerTypeSelectedId.push({
        // tslint:disable-next-line:radix
        specialityId: parseInt(profileitem.id.toString())
      });

      // profile score
      if (this.retailerTypeSelectedData.length === 1 && !this.scoreClear) {
        this.percent = this.percent + this.scoreData.speciality;
        this.scorechangedata.changeMessage(this.percent);
      }
    } else {
      this.toastr.warning(this.translate.instant('tradeinformation.validationMessage.specialitymax'));
    }
    if (this.retailerTypeData.length > 0) {
      this.retailerTypeData = this.retailerTypeData.filter(item => item.id.toString() !== profileitem.id.toString());
    }

  }

  // Search the Retailer Types
  changeretailerType(event) {
    this.accountBusiness.getProductFamily(event).subscribe(result => {
      this.retailerTypeData = result as Array<DistributorSearchItem>;
      // if (this.retailerTypeData.length > 0) {
      //   this.retailerTypeData = this.retailerTypeData;
        if (this.retailerTypeData.length > 0) {
          this.retailerTypeSelectedData.forEach(selectitem => {
            this.retailerTypeData = this.retailerTypeData.filter(item => item.id.toString() !== selectitem.id.toString());
          });
        }
      // }
    },
      (error) => {
        console.log(error);
      });
  }

  // Search the Brand List
  changebrandList(event) {
    delete this.brandlistData;
    this.accountBusiness.gettradeBrandList(event, this.channelId).subscribe(result => {
      // this.brandlistData = new Array<BrandListItem>();
      const _brandlistData = result as Array<BrandListItem>;
      if (_brandlistData.length > 0) {
        this.brandlistData = _brandlistData;
        this.brandListSelectedData.forEach(selectitem => {
          this.brandlistData = this.brandlistData.filter(item => item.id.toString() !== selectitem.id.toString());
        });
      }
    },
      (error) => {
        console.log(error);
      });
  }

  // Search Key Retailer List
  getKeyRetailer(event, typeId: string) {
    // delete this.keyRetailerFilterData;
    this.loaderNotify.emit(true);
    this.accountBusiness.getKeyRetailerSearch(this.searchKeyretailer, typeId).subscribe(result => {
      const response = result as Response;
      this.loaderNotify.emit(false);
      if (response.ok) {
        const _keyRetailerListResponse = response.json() as KeyRetailerRootObject;
        this.partnerObjects[typeId].keyRetailerFilterData = [];
        if (_keyRetailerListResponse.channel) {
          _keyRetailerListResponse.channel.forEach(item => {
            this.partnerObjects[typeId].keyRetailerFilterData.push({
              channelId: item.channelId ? item.channelId : null,
              oldchannelid: item.oldChannelId ? item.oldChannelId : null,
              companyName: item.companyName,
              documentPath: item.companylogo ? item.companylogo.documentPath : null,
              documentUrl: item.companylogo ? item.companylogo.documentUrl : null,
              countryid: item.regaddresscountry.countryId,
              existchannelid: item.channelId ? item.channelId : null,
              countryName: item.regaddresscountry.country
            });
          });
          this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
            if (selectitem.channelId !== null) {
              this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId]
                .keyRetailerFilterData.filter(item => item.channelId
                  !== selectitem.channelId);
            }
          });
        }

        if (_keyRetailerListResponse.oldchannel) {
          _keyRetailerListResponse.oldchannel.forEach(item => {
            this.partnerObjects[typeId].keyRetailerFilterData.push({
              channelId: null,
              oldchannelid: item.oldChannelId ? item.oldChannelId : null,
              companyName: item.companyName,
              documentPath: item.oldchanneldetail ? item.oldchanneldetail.documentPath : null,
              documentUrl: item.oldchanneldetail ? item.oldchanneldetail.documentUrl : null,
              countryid: item.oldregaddresscountry.countryId,
              existchannelid: null,
              countryName: item.oldregaddresscountry.country
            });
          });
          this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
            if (selectitem.oldchannelid !== null) {
              this.partnerObjects[typeId].keyRetailerFilterData
                = this.partnerObjects[typeId].keyRetailerFilterData.filter(item => item.oldchannelid
                  !== selectitem.oldchannelid);
            }
          });
        }
        this.partnerObjects[typeId].keyRetailerFilterDataChannel.forEach(selectitem => {
          let checkDuplicates;
          if (selectitem.channelId !== null || selectitem.oldchannelid !== null
            || (selectitem.keypartnerid === null && selectitem.keypartnerid !== undefined)) {
            if (selectitem.channelId !== null && selectitem.channelId !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.findIndex(item => item.channelId
                === selectitem.channelId);
            } else if (selectitem.oldchannelid !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.findIndex(item => item.oldchannelid
                === selectitem.oldchannelid);
            } else if (selectitem.keypartnerid === null && selectitem.keypartnerid !== undefined) {
              checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterData.findIndex(item => item.companyName
                === selectitem.companyName);
            }
          }
          if (checkDuplicates < 0 || checkDuplicates === undefined) {
            this.partnerObjects[typeId].keyRetailerFilterData.push(selectitem);
          } else {
            if (selectitem.keypartnerid) {
              this.partnerObjects[typeId].keyRetailerFilterData[checkDuplicates].keypartnerid = selectitem.keypartnerid;
            }
          }
        });
        this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
          if (selectitem.keypartnerid !== null && selectitem.keypartnerid !== undefined) {
            this.partnerObjects[typeId].keyRetailerFilterData =
              this.partnerObjects[typeId].keyRetailerFilterData.filter(item => item.keypartnerid
                !== selectitem.keypartnerid);
          }
        });
      }
    });
  }

  // Search Key Retailer
  onSearchKeyRetailer(search: string, typeId: string) {
    this.searchKeyretailer = search;
    this.getKeyRetailer('', typeId);
  }

  public onSearchTextEntered(data: string) {
    this.brandSearchOldValue = this.brandSearchNewValue;
    this.brandSearchNewValue = data;
    if (this.brandSearchOldValue.toLowerCase() !== this.brandSearchNewValue.toLowerCase()) {
      this.changebrandList(data);
      this.repaeatBrand(data);
      if (this.repeatBrand) {
        this.toastr.error(this.translate.instant('tradeinformation.validationMessage.sameBrand'));
        this.repeatBrand = false;
      }
    }
  }

  repaeatBrand(data) {
    this.brandListSelectedData.forEach(selectitem => {
      if (selectitem.Name.toLowerCase() === data.toLowerCase()) {
        this.repeatBrand = true;
        return;
      }
    });
  }
  // Select the Brand List
  selectedbrandlist(categoryitem: BrandListItem) {
    this.commonselectedItem(categoryitem, this.brandListSelectedData);
    if (this.brandListSelectedData.length > 0) {
      this.brandListPostError = '';
    }

    this.brandListPost.push({
      id: categoryitem.id,
      name: categoryitem.Name,
      documentPath: categoryitem.documentPath
    });
    // profile score
    if (this.brandListSelectedData.length === 1 && !this.scoreClear) {
      this.percent = this.percent + this.scoreData.brand;
      this.scorechangedata.changeMessage(this.percent);
    }

    if (this.brandlistData.length > 0) {
      this.brandlistData = this.brandlistData.filter(item => item.id.toString() !== categoryitem.id.toString());
    }
  }

  // Remove the Brand List
  removeBrandList(data) {
    const index: number = this.brandListSelectedData.indexOf(data, 0);
    if (index !== -1) {
      this.brandListSelectedData.splice(index, 1);
      this.brandListPost.splice(index, 1);
      this.brandlistData = this.brandlistData.filter(ite => ite.id.toString() !== data.id.toString());
      if (data.id !== 0) {
        this.brandlistData.push(data);
      }
      if (this.brandListSelectedData.length === 0) {
        this.scoreClear = true;
        this.percent = this.percent - this.scoreData.brand;
        this.scorechangedata.changeMessage(this.percent);
      }
      this.scoreClear = false;
    }
  }

  // Remove the Key Retailer List
  removeKeyRetailerList(data: KeyRetailerSelectedList, index, typeId: string = '3') {
    if (index !== -1) {
      if (data.keypartnerid) {
        this.partnerObjects[typeId].deletedkeyretailer.push(data.keypartnerid);
        this.partnerObjects[typeId].keyRetailerSelectedData
          = this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.keypartnerid !== data.keypartnerid);
        const checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel.filter(item => item.keypartnerid
          === data.keypartnerid);
        if (checkDuplicates.length === 0) {
          this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(data);
          this.partnerObjects[typeId].keyRetailerFilterData.push(data);
          // const deletedKeypartners = data;
          // delete deletedKeypartners.keypartnerid;
          // this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(data);
          // this.partnerObjects[typeId].keyRetailerFilterData.push(data);
        }
      } else if (data.existchannelid || data.oldchannelid) {
        let checkDuplicates = [null];

        if (data.existchannelid) {
          this.partnerObjects[typeId].keyRetailerSelectedData =
            this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.existchannelid !== data.existchannelid);
          checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel
            .filter(item => item.existchannelid === data.existchannelid);
        } else {
          this.partnerObjects[typeId].keyRetailerSelectedData =
            this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.oldchannelid !== data.oldchannelid);
          checkDuplicates = this.partnerObjects[typeId].keyRetailerFilterDataChannel
            .filter(item => item.oldchannelid === data.oldchannelid);
        }
        if (checkDuplicates[0] === null) {
          this.partnerObjects[typeId].keyRetailerFilterDataChannel.push(data);
        }
        this.partnerObjects[typeId].keyRetailerFilterData.push(data);
      } else if (data.existchannelid === null && data.oldchannelid === null) {
        this.partnerObjects[typeId].keyRetailerSelectedData.splice(index, 1);
      }
    }
  }

  // Customer Type
  customerType(channelId) {
    this.accountBusiness.getCustomerType(channelId).subscribe(result => {
      this.CustomerType = result as Array<CustomerTypeList>;
    },
      (error) => {
        console.log(error);
      });
  }

  // Trade Information Get
  tradeinfoGet() {
    this.loading = true;
    this.accountBusiness.getTradeinfo(true).subscribe(result => {

      const response = result as Response;

      if (response.ok) {
        const tradeInformationGet = response.json() as TradeInformationGet;
        if (tradeInformationGet.channel) {
          this.isFrenchCountry = tradeInformationGet.channel.regAddress && tradeInformationGet.channel.regAddress.countryId
            === CountryList.FRANCE ? true : false;
          this.frenchTechShow = this.isFrenchCountry && tradeInformationGet.channel.isFrenchTech === '1' ? true : false;
        }
        if (this.updateFlag) {
          this.prefillFunction(tradeInformationGet);
        }
      }
      this.loading = false;
    },
      (error) => {
        console.log(error);
      });
  }

  // Common Function to pre fill data
  prefillFunction(tradeInformationGet) {

    // emprange
    this.tradebtnLists.forEach(item => {
      if (item.name === tradeInformationGet.channel.channelDetail.empCntRange) {
        this.activeMenu = tradeInformationGet.channel.channelDetail.empCntRange;
      }
    });



    // emp Count
    this.tradeinfoForm.controls['empcount'].setValue(tradeInformationGet.channel.channelDetail.empCnt);


    // Emp Additional Details
    this.tradeinfoForm.controls['domesticSales'].setValue(tradeInformationGet.channel.channelDetail.empCntDSale);

    this.tradeinfoForm.controls['internationalSales'].setValue(tradeInformationGet.channel.channelDetail.empCntISale);

    this.tradeinfoForm.controls['domesticmarketSales'].setValue(tradeInformationGet.channel.channelDetail.empCntDMar);

    this.tradeinfoForm.controls['internationalMarket'].setValue(tradeInformationGet.channel.channelDetail.empCntIMar);

    // turnoverRange
    this.tradeannualOversLists.forEach(item => {
      if (item.name === tradeInformationGet.channel.channelDetail.turnoverRange) {
        this.activeannualMenu = tradeInformationGet.channel.channelDetail.turnoverRange;
        // this.empcount = tradeInformationGet.channel.channelDetail.empCnt;
      }
    });

    // annual Count
    this.tradeinfoForm.controls['annualCount'].setValue(tradeInformationGet.channel.channelDetail.turnover);
    // display with $
    this.annualCount = tradeInformationGet.channel.channelDetail.turnover;

    // turnoverRange Additional Details
    this.tradeinfoForm.controls['demesticRevenue'].setValue(tradeInformationGet.channel.channelDetail.revD);

    this.tradeinfoForm.controls['internationalRevenue'].setValue(tradeInformationGet.channel.channelDetail.revI);

    // turnoverRange Additional Details for Retailer
    if (this.channelId === 4) {
      this.tradeinfoForm.controls['physicalstore'].setValue(tradeInformationGet.channel.channelDetail.turnoverPhyStore);

      this.tradeinfoForm.controls['onlinestore'].setValue(tradeInformationGet.channel.channelDetail.turnoverOnStore);

      this.tradeinfoForm.controls['nostore'].setValue(tradeInformationGet.channel.channelDetail.storeCount);

    }
    // maturity Level
    if (tradeInformationGet.channel.channelDetail.startup === '0') {
      this.maturityShow = false;
    } else {
      this.maturityShow = true;
      if (this.channelId === this._channelTypeEnum.VENDOR) {
        if (tradeInformationGet.channel.channelDetail.maturitylevel.length) {
          this.tradeinfoForm.controls['maturitylevel'].setValue(tradeInformationGet.channel.channelDetail.maturitylevel[0]);
        }
      } else {
        if (tradeInformationGet.channel.channelDetail.maturitylevel.length) {
          const maturityLevelList = tradeInformationGet.channel.channelDetail.maturitylevel;
          for (let m = 0; m < maturityLevelList.length; m++) {
            if (maturityLevelList[m] === MaturityLevel.PROTOTYPE) {
              this.tradeinfoForm.controls['maturitylevelPrototype'].setValue(true);
            }
            if (maturityLevelList[m] === MaturityLevel.S_BACKER) {
              this.tradeinfoForm.controls['maturitylevelSbackers'].setValue(true);
            }
            if (maturityLevelList[m] === MaturityLevel.S_VOLUME) {
              this.tradeinfoForm.controls['maturitylevelSvolume'].setValue(true);
            }
          }
        }
      }
    }
    // Brand List
    this.brandListSelectedData = [];
    this.brandListPost = [];
    this.partnerObjects[3].keyRetailerSelectedData = [];
    this.partnerObjects[4].keyRetailerSelectedData = [];

    this.partnerObjects[3].keyRetailerPostData = [];
    this.partnerObjects[4].keyRetailerPostData = [];

    this.partnerObjects[3].deletedkeyretailer = [];
    this.partnerObjects[4].deletedkeyretailer = [];

    this.partnerObjects[3].keyRetailerFilterDataChannel = [];
    this.partnerObjects[4].keyRetailerFilterDataChannel = [];

    if (tradeInformationGet.channel.channelBrand) {
      tradeInformationGet.channel.channelBrand.forEach(item => {
        this.brandListSelectedData.push(
          {
            id: item.brand.id,
            Name: item.brand.brandName,
            documentPath: item.brand.document ? item.brand.document.documentUrl : ''
          }
        );
        this.brandListPost.push({
          // tslint:disable-next-line:radix
          id: parseInt(item.brand.id.toString()),
          name: item.brand.brandName,
          documentPath: item.brand.document ? item.brand.document.documentUrl : ''
        });
      });
    }

    if (this.brandlistData && this.brandlistData.length > 0) {
      this.brandListSelectedData.forEach(selectitem => {
        this.brandlistData = this.brandlistData.filter(item => item.id.toString() !== selectitem.id.toString());
      });
    }
    // Product Family
    this.productFamilySelectedData = [];
    this.productFamilySelectedId = [];
    if (tradeInformationGet.channel.channelProductGroup) {
      tradeInformationGet.channel.channelProductGroup.forEach(item => {
        this.productFamilySelectedData.push({
          // tslint:disable-next-line:radix
          id: parseInt(item.productGroup.productGroupId.toString()),
          name: item.productGroup.productGroup
        });

        this.productFamilySelectedId.push({
          // tslint:disable-next-line:radix
          id: parseInt(item.productGroup.productGroupId.toString())
        });
      });
    }

    if (this.productFamilyData.length > 0) {
      this.productFamilySelectedData.forEach(selectitem => {
        this.productFamilyData = this.productFamilyData.filter(item => item.id.toString() !== selectitem.id.toString());
      });
    }

    // Product Catgory
    //  this.productCategorySelectedData = [];
    const categorySelectedData = new Array<ProductCategorySearchItem>();
    if (tradeInformationGet.channel.channelProductCategorie) {
      tradeInformationGet.channel.channelProductCategorie.forEach(item => {
        const _searchItem = new ProductCategorySearchItem();
        // tslint:disable-next-line:radix
        _searchItem.id = parseInt(item.productCategorieId.toString());
        _searchItem.name = item.productCategorie.productCategor;
        _searchItem.productGroupId = item.productCategorie.productGroupId.toString();
        this.productCategorylist = this.productFamilySelectedData;
        categorySelectedData.push(_searchItem);
      });

      this.productCategorySelectedData = categorySelectedData;
    }

    // Get CustomerType
    // Vendor
    if (tradeInformationGet.channel.channelDetail && tradeInformationGet.channel.channelDetail.keyretailers) {
      this.tradeinfoForm.controls['retailernameDescription'].setValue(tradeInformationGet.channel.channelDetail.keyretailers);
    }
    if (tradeInformationGet.channel.channelDetail && tradeInformationGet.channel.channelDetail.keydistributors) {
      this.tradeinfoForm.controls['distributornameDescription'].setValue(tradeInformationGet.channel.channelDetail.keydistributors);
    }
    if (this.channelId === 2) {
      tradeInformationGet.channel.profileTypeId = 1;
      // this.preFillKeyRetailers(tradeInformationGet.channel.channelKeyRetailer);
      this.preFillKeyRetailesUpdate(tradeInformationGet.channel.channelKeyDistributor, '3');
      this.preFillKeyRetailesUpdate(tradeInformationGet.channel.channelKeyRetailer, '4');
      this.tradeinfoForm.controls['keyDistNoOfSKU'].setValue(tradeInformationGet.channel.channelDetail.no_of_skus);
      this.tradeinfoForm.controls['keyDistNoOfDist'].setValue(tradeInformationGet.channel.channelDetail.no_of_distributors);
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].setValue(tradeInformationGet.channel.channelDetail.no_of_retailers);


    } else if (this.channelId === 3) {
      // this.preFillKeyRetailers(tradeInformationGet.channel.channelKeyRetailer);
      this.preFillKeyRetailesUpdate(tradeInformationGet.channel.channelKeyRetailer, '4');
      this.tradeinfoForm.controls['keyDistNoOfRetailer'].setValue(tradeInformationGet.channel.channelDetail.no_of_retailers);

      this.CustomerType.forEach(item => {
        // tslint:disable-next-line:radix
        if (item.id === parseInt(tradeInformationGet.channel.profileType.profileTypeId.toString())) {
          this.tradeinfoForm.controls['typedata'].setValue(tradeInformationGet.channel.profileType.profileTypeId);
          // tslint:disable-next-line:radix
          this.distributorType = parseInt(tradeInformationGet.channel.profileType.profileTypeId.toString());
          this.distributorTypeclear = parseInt(tradeInformationGet.channel.profileType.profileTypeId.toString(), 10);
          // tslint:disable-next-line:triple-equals
          if (this.distributorType == 3) {
            this.distributorType = 0;
          }
        }

      });
    } else if (this.channelId === 4) {
      this.CustomerType.forEach(item => {
        // tslint:disable-next-line:radix
        if (item.id === parseInt(tradeInformationGet.channel.profileType.profileTypeId.toString())) {
          this.tradeinfoForm.controls['typeretailerdata'].setValue(tradeInformationGet.channel.profileType.profileTypeId);
          // tslint:disable-next-line:radix
          this.retailerType = parseInt(tradeInformationGet.channel.profileType.profileTypeId.toString());
        }

      });
    }
    // List of services
    this.listlistofservicesSelectedData = [];
    this.listofservicesSelectedId = [];
    if (tradeInformationGet.channel.channelServiceList) {
      tradeInformationGet.channel.channelServiceList.forEach(item => {
        this.listlistofservicesSelectedData.push({
          id: item.serviceList.serviceListId,
          name: item.serviceList.serviceList
        });
        this.listofservicesSelectedId.push({
          // tslint:disable-next-line:radix
          id: parseInt(item.serviceList.serviceListId.toString())
        });
      });
    }

    if (this.listofservicesData.length > 0) {
      this.listlistofservicesSelectedData.forEach(selectitem => {
        this.listofservicesData = this.listofservicesData.filter(item => item.id.toString() !== selectitem.id.toString());
      });
    }
    // Speciality List
    if (this.channelId === 4) {
      this.retailerTypeSelectedData = [];
      this.retailerTypeSelectedId = [];
      if (tradeInformationGet.channel.channelSpeciality) {
        tradeInformationGet.channel.channelSpeciality.forEach(item => {
          this.retailerTypeSelectedData.push({
            id: item.productGroup.productGroupId,
            name: item.productGroup.productGroup
          });
          this.retailerTypeSelectedId.push({
            // tslint:disable-next-line:radix
            specialityId: parseInt(item.productGroup.productGroupId.toString())
          });
        });
      }


      if (this.retailerTypeData.length > 0) {
        this.retailerTypeSelectedData.forEach(selectitem => {
          this.retailerTypeData = this.retailerTypeData.filter(item => item.id.toString() !== selectitem.id.toString());
        });
      }

    }
    if (this.channelId === 3) {
      this.distributorlistSelectedData = [];
      this.distributorSpecialitySelectedId = [];

      if (tradeInformationGet.channel.channelSpeciality && tradeInformationGet.channel.channelSpeciality.length > 0) {
        tradeInformationGet.channel.channelSpeciality.forEach(item => {
          this.distributorlistSelectedData.push({
            id: item.productGroup.productGroupId,
            name: item.productGroup.productGroup
          });
          this.distributorSpecialitySelectedId.push({
            // tslint:disable-next-line:radix
            specialityId: parseInt(item.productGroup.productGroupId.toString()),
          });

          this.tempDistributor.push({
            id: item.productGroup.productGroupId,
            name: item.productGroup.productGroup
          });
        });

        if (this.distributorType === 0) {
          this.distributorlistSelectedData = [];
          this.distributorSpecialitySelectedId = [];
        }

        if (this.distributorlistData.length > 0) {
          this.distributorlistSelectedData.forEach(selectitem => {
            this.distributorlistData = this.distributorlistData.filter(item => item.id.toString() !== selectitem.id.toString());
          });
        }
      }
    }

    // Customer Profile
    this.customerProfileSelectedData = [];
    this.customerProfileSelectedId = [];
    if (tradeInformationGet.channel.channelCustomerProfile) {
      tradeInformationGet.channel.channelCustomerProfile.forEach(item => {
        this.customerProfileSelectedData.push({
          Channel_Profile_ID: item.profileType.profileTypeId,
          Channel_Profile_Name: item.profileType.profileType + ' ' + '-' + ' ' + item.pTClas.channelType.channelType.toLocaleLowerCase()
        });
        this.customerProfileSelectedId.push({
          // tslint:disable-next-line:radix
          id: parseInt(item.profileType.profileTypeId.toString()),
          profileTypeClassificationId: item.profileTypeClassificationId
        });
      });
    }
    if (this.customerProfileData.length > 0) {
      this.customerProfileSelectedData.forEach(selectitem => {
        this.customerProfileData = this.customerProfileData.filter(item =>
          item.Channel_Profile_ID.toString() !== selectitem.Channel_Profile_ID.toString());
      });
    }
  }


  // Trade Information Previous Profile Strength
  tradeinfoprofileStrength() {
    this.accountBusiness.getUserTypeProfileBusiness().subscribe(result => {
      this.percent = result.channel.profileStrength;
    },
      (error) => {
        console.log(error);
      });
  }

  // Score List
  scorelist() {
    this.accountBusiness.getscoreList().subscribe(result => {
      this.scoreData = result;
    },
      (error) => {
        console.log(error);
      });
  }

  // Popup for add brand details
  clickNewBrand(brandtextlength): void {
    this.branddisable = true;
    const dialogRef = this.dialog.open(AddBrandComponent, {
      data: {
        id: 0, name: brandtextlength, documentpath: '', temppath: '', selectedValue: this.brandListSelectedData, type: 1
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.changebrandList('');
        if (!ValidationService.isNullOrEmpty(result.documentPath) && !ValidationService.isNullOrEmpty(result.name)) {
          this.brandListPost.push({
            id: result.id,
            name: result.name,
            documentPath: result.documentPath
          });
        }

        if (!ValidationService.isNullOrEmpty(result.temppath)) {
          this.brandListSelectedData.push({
            id: result.id,
            Name: result.name,
            documentPath: result.temppath
          });
        }
      }
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      this.branddisable = false;
    });
  }

  // Popup for add brand details
  addNewKeyRetailer(keyRetailer, typeId: string): void {
    this.branddisable = true;
    const dialogRef = this.dialog.open(AddBrandComponent, {
      data: {
        type: 2,
        boolClose: false,
        name: this.searchKeyretailer,
        title: typeId === '4' ? ['tradeinformation.bodyLabels.addkeyretailer', 'addProduct.distributionchannelTab.retailerName',
          'Retailer.pageTitle', '4']
          : ['tradeinformation.bodyLabels.addkeydistributor', 'addProduct.distributionchannelTab.distributorName', 'Distributor.pageTitle'
            , '3']
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result.boolClose) {
        delete result.boolClose;
        this.checkDuplicatesKeyretailers(result.keyretailer, typeId);
      }
      this.branddisable = false;
    });
  }

  onSelectKeyRetailer(event: KeyRetailerSelectedList, typeId: string = '3') {
    if (!event.keypartnerid) {
      event['keypartnerid'] = null;
    }
    // event['countryName'] = null;
    this.partnerObjects[typeId].keyRetailerSelectedData.push(event);
    this.partnerObjects[typeId].keyRetailerSelectedData.forEach(selectitem => {
      if (selectitem.existchannelid !== null) {
        this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData.filter(item =>
          item.existchannelid !== selectitem.existchannelid);
      } else if (selectitem.oldchannelid !== null) {
        this.partnerObjects[typeId].keyRetailerFilterData = this.partnerObjects[typeId].keyRetailerFilterData.filter(item =>
          item.oldchannelid !== selectitem.oldchannelid);
      }
    });
    const deletedKeys = this.partnerObjects[typeId].deletedkeyretailer;
    for (let _i = 0; _i < deletedKeys.length; _i++) {
      if (!this.filterDeletedRecordswithSelectedKeyRetailers
        (typeId, deletedKeys[_i], this.partnerObjects[typeId].keyRetailerSelectedData)) {
        this.partnerObjects[typeId].deletedkeyretailer.splice(_i);
      }
    }
  }

  btncolorChange(emp) {
    this.activeMenu = emp;
    this.tradeinfoForm.controls['empcount'].reset();
    this.empdetailserror = '';
    // profile score
    if (((this.a === 0) || (this.b === 1)) && !ValidationService.isNullOrEmpty(emp)) {
      this.percent = this.percent + this.scoreData.detail.empCnt;
      if (this.b === 1) {
        this.percent = this.percent - this.scoreData.detail.empCnt;
      }
      this.scorechangedata.changeMessage(this.percent);
      this.a = 1;
      this.b = 0;
    }
  }

  empcountvalue(event) {
    this.activeMenu = '';
    this.minempdetailserror = '';
    // this.tradeinfoForm.controls['empcount'].value
    // this.tradeinfoForm.controls['empcount'].setValue('$' + event);
    // profile score
    if (((this.a === 1) || (this.b === 0)) && !ValidationService.isNullOrEmpty(event)) {
      this.percent = this.percent + this.scoreData.detail.empCnt;
      if (this.a === 1) {
        this.percent = this.percent - this.scoreData.detail.empCnt;
      }
      this.scorechangedata.changeMessage(this.percent);
      this.a = 0;
      this.b = 1;
    }
  }

  tradeannualoverbtnChange(annualover) {
    this.activeannualMenu = annualover;
    this.tradeinfoForm.controls['annualCount'].reset();
    this.annualerror = '';
    // profile score
    if (((this.c === 0) || (this.d === 1)) && !ValidationService.isNullOrEmpty(annualover)) {
      this.percent = this.percent + this.scoreData.detail.turnover;
      if (this.d === 1) {
        this.percent = this.percent - this.scoreData.detail.turnover;
      }
      this.scorechangedata.changeMessage(this.percent);
      this.c = 1;
      this.d = 0;
    }
  }

  annualCountvalue(event) {
    this.activeannualMenu = '';
    this.minannualerror = '';
    // profile score
    if (((this.c === 1) || (this.d === 0)) && !ValidationService.isNullOrEmpty(event)) {
      this.percent = this.percent + this.scoreData.detail.turnover;
      if (this.c === 1) {
        this.percent = this.percent - this.scoreData.detail.turnover;
      }
      this.scorechangedata.changeMessage(this.percent);
      this.c = 0;
      this.d = 1;
    }
    // else{
    //   this.percent = this.percent - this.scoreData.detail.turnover;
    //   this.scorechangedata.changeMessage(this.percent);
    // }
  }

  onChangeretailer(retailer) {
    // tslint:disable-next-line:radix
    this.retailerType = parseInt(retailer.toString());
    this.specialityerror = '';
  }

  onChangedistributor(distributor) {
    // tslint:disable-next-line:radix
    this.distributorType = parseInt(distributor.toString());
    // tslint:disable-next-line:radix
    this.distributorTypeclear = parseInt(distributor.toString());
    if (this.distributorType === 3) {
      this.distributorType = 0;
      this.distributorlistSelectedData = [];
    } else {
      this.distributorlistSelectedData = this.tempDistributor;
    }
    this.specialityerror = '';
  }

  // productcategory clear event
  productchange() {
    this.errProductCategories = '';
    this.msg_code_ProductCategories = '';
  }

  validation(): boolean {
    let returnVal = true;
    if (this.channelId === 3) {
      if ((ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['typedata'].value))) {
        this.specialityerror = this.translate.instant('tradeinformation.validationMessage.selectSpeciality');
        if (returnVal === true) {

          this.scrollService.scrollTo(document.getElementById('scrolltop'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.specialityerror = '';
      }
    }

    if (this.channelId === 4) {
      if ((ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['typeretailerdata'].value))) {
        this.specialityerror = this.translate.instant('tradeinformation.validationMessage.selectSpeciality');
        if (returnVal === true) {

          this.scrollService.scrollTo(document.getElementById('typeretailerdataId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.specialityerror = '';
      }
    }

    if (this.distributorType !== 0) {// for boradline
      if (this.channelId === 3) {
        if (this.distributorlistSelectedData.length === 0) {
          this.distributorlistError = this.translate.instant('tradeinformation.validationMessage.distributorSpeciality');
          if (returnVal === true) {

            this.scrollService.scrollTo(document.getElementById('distributorlistId'), 1000, -100);
          }
          returnVal = false;
        } else {
          this.distributorlistError = '';
        }
      }
    }
    if (this.channelId === 2 || this.channelId === 3) {
      if (this.brandListSelectedData.length === 0) {
        this.brandListPostError = this.translate.instant('tradeinformation.validationMessage.selectBrand');
        // this.brandListPostError = 'tradeinformation.validationMessage.selectBrand';
        if (returnVal === true) {

          this.scrollService.scrollTo(document.getElementById('brandErrorId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.brandListPostError = '';
      }
    }

    if (this.productFamilySelectedData.length === 0) {
      this.ProductFamilyError = this.translate.instant('tradeinformation.validationMessage.selectProductfamily');
      if (returnVal === true) {

        this.scrollService.scrollTo(document.getElementById('ProductFamilyErrorId'), 1000, -100);
      }
      returnVal = false;
    } else {
      this.ProductFamilyError = '';
    }

    const _productCategories: ProductCategoryComponent[] = this.productCategoryViewChildren.toArray();

    const productCategories = _productCategories.filter(item => item.productCategorySelectedData.length === 0);
    if (productCategories.length > 0) {
      this.errProductCategories = 'productCategories';
      this.msg_code_ProductCategories = '0011';
      if (returnVal === true) {

        this.scrollService.scrollTo(document.getElementById('errProductCategoriesId'), 1000, -100);
      }
      returnVal = false;
    } else {
      this.errProductCategories = '';
      this.msg_code_ProductCategories = '';
    }
    if (this.channelId === 3 || this.channelId === 2) {
      this.markFormArrayTouched(this.retailerItemsArray);
      if (this.retailerItemsArray.invalid) {
        for (let i = 0; i < this.retailerItemsArray.controls.length; i++) {
          const tempFormGroup = this.retailerItemsArray.controls[i] as FormGroup;
          this.retailername = tempFormGroup.controls['retailername'].value;
          this.countryid = tempFormGroup.controls['countryid'].value;
          // const imageKeyretailer = tempFormGroup.controls['image'].value;
          if ((!this.retailername || this.retailername === '' || this.retailername === undefined) ||
            (!this.countryid || this.countryid === null || this.countryid === 0)) {
            if (returnVal === true) {
              this.scrollService.scrollTo(document.getElementById('retailerId'), 1000, -100);
              returnVal = false;
            }
          } else {
            this.msg_code_retailer = '';
          }
        }
      }
      if (this.channelId === 2) {
        if (this.tradeinfoForm.controls['keyDistNoOfSKU'].invalid || this.tradeinfoForm.controls['keyDistNoOfDist'].invalid
          || this.tradeinfoForm.controls['keyDistNoOfRetailer'].invalid) {
          this.tradeinfoForm.controls['keyDistNoOfSKU'].markAsTouched();
          this.tradeinfoForm.controls['keyDistNoOfDist'].markAsTouched();
          this.tradeinfoForm.controls['keyDistNoOfRetailer'].markAsTouched();
          const scrollElementId = this.tradeinfoForm.controls['keyDistNoOfSKU'].invalid ? 'SKUBlockId' : 'NoOfDistributorBlockId';
          if (returnVal === true) {
            this.scrollService.scrollTo(document.getElementById(scrollElementId), 1000, -100);
            returnVal = false;
          }
        }
      } else {
        if (this.tradeinfoForm.controls['keyDistNoOfRetailer'].invalid) {
          this.tradeinfoForm.controls['keyDistNoOfRetailer'].markAsTouched();
          if (returnVal === true) {
            this.scrollService.scrollTo(document.getElementById('NoOfRetailerId'), 1000, -100);
            returnVal = false;
          }
        }
      }
    }

    if (this.customerProfileSelectedData.length === 0 && this.channelId !== 4) {
      this.CustomerError = this.translate.instant('tradeinformation.validationMessage.selectcustomerProfile');
      if (returnVal === true) {
        this.scrollService.scrollTo(document.getElementById('CustomerErrorId'), 1000, -100);
      }
      returnVal = false;
    } else {
      this.CustomerError = '';
    }

    if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['empcount'].value) &&
      this.tradeinfoForm.controls['empcount'].value !== 0) {
      this.empdetailserror = '';
    } else if (!ValidationService.isNullOrEmpty(this.activeMenu)) {
      this.empdetailserror = '';
    } else {
      this.empdetailserror = this.translate.instant('tradeinformation.validationMessage.selectEmployee');
      this.minempdetailserror = '';
      if (this.tradeinfoForm.controls['empcount'].value === 0) {
        this.minempdetailserror = this.translate.instant('tradeinformation.validationMessage.minvalue');
        this.empdetailserror = '';
      }
      if (returnVal === true) {

        this.scrollService.scrollTo(document.getElementById('empcountId'), 1000, -100);
      }
      returnVal = false;
    }


    this.tradeinfoForm.controls['domesticSales'].markAsTouched();
    if (this.tradeinfoForm.controls['domesticSales'].invalid) {
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('domesticSalesId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.domesticSalesError = '';
      }
    }

    // if (this.tradeinfoForm.controls['domesticSales'].value === 0) {
    //   this.domesticSalesError = this.translate.instant('tradeinformation.validationMessage.minvalue');
    //   if (returnVal === true) {

    //     this.scrollService.scrollTo(document.getElementById('domesticSalesId'), 1000, -100);
    //   }
    //   returnVal = false;
    // } else {
    //   this.domesticSalesError = '';
    // }

    // if (this.tradeinfoForm.controls['domesticmarketSales'].value === 0) {
    //   this.domesticmarketSalesError = this.translate.instant('tradeinformation.validationMessage.minvalue');
    //   if (returnVal === true) {
    //     this.scrollService.scrollTo(document.getElementById('domesticmarketSalesId'), 1000, -100);
    //   }
    //   returnVal = false;
    // } else {
    //   this.domesticmarketSalesError = '';
    // }

    this.tradeinfoForm.controls['domesticmarketSales'].markAsTouched();
    if (this.tradeinfoForm.controls['domesticmarketSales'].invalid) {
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('domesticmarketSalesId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.domesticmarketSalesError = '';
      }
    }

    if ((this.tradeinfoForm.controls['demesticRevenue'].value + this.tradeinfoForm.controls['internationalRevenue'].value) > 100) {
      this.demesticRevenueError = this.translate.instant('tradeinformation.validationMessage.totalDomestic');
      if (returnVal === true) {
        this.scrollService.scrollTo(document.getElementById('demesticRevenueId'), 1000, -100);
      }
      returnVal = false;
    } else {
      this.demesticRevenueError = '';
    }

    // this.tradeinfoForm.controls['demesticRevenue'].markAsTouched();
    // if (this.tradeinfoForm.controls['demesticRevenue'].invalid) {
    //   if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
    //     if (returnVal === true) {
    //       this.scrollService.scrollTo(document.getElementById('demesticRevenueId'), 1000, -100);
    //     }
    //     returnVal = false;
    //   } else {
    //     this.demesticRevenueError = '';
    //   }
    // }


    if ((this.tradeinfoForm.controls['physicalstore'].value + this.tradeinfoForm.controls['onlinestore'].value) > 100) {
      this.physicalstoreError = this.translate.instant('tradeinformation.validationMessage.totalPhysical');
      if (returnVal === true) {
        this.scrollService.scrollTo(document.getElementById('physicalstore'), 1000, -100);
      }
      returnVal = false;
    } else {
      this.physicalstoreError = '';
    }

    if (this.channelId === 4) {
      this.tradeinfoForm.controls['nostore'].markAsTouched();
      if (this.tradeinfoForm.controls['nostore'].invalid) {
        if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
          if (returnVal === true) {
            this.scrollService.scrollTo(document.getElementById('nostoreId'), 1000, -100);
          }
          returnVal = false;
        }
      }
    }

    // if (this.tradeinfoForm.controls['internationalSales'].value === 0) {
    //   this.internationalSalesError = this.translate.instant('tradeinformation.validationMessage.minvalue');
    //   if (returnVal === true) {
    //     this.scrollService.scrollTo(document.getElementById('internationalSalesId'), 1000, -100);
    //   }
    //   returnVal = false;
    // } else {
    //   this.internationalSalesError = '';
    // }

    this.tradeinfoForm.controls['internationalSales'].markAsTouched();
    if (this.tradeinfoForm.controls['internationalSales'].invalid) {
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('internationalSalesId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.internationalSalesError = '';
      }
    }

    // if (this.tradeinfoForm.controls['internationalMarket'].value === 0) {
    //   this.internationalMarketError = this.translate.instant('tradeinformation.validationMessage.minvalue');
    //   if (returnVal === true) {
    //     this.scrollService.scrollTo(document.getElementById('internationalMarketId'), 1000, -100);
    //   }
    //   returnVal = false;
    // } else {
    //   this.internationalMarketError = '';
    // }

    this.tradeinfoForm.controls['internationalMarket'].markAsTouched();
    if (this.tradeinfoForm.controls['internationalMarket'].invalid) {
      if (ValidationService.isNullOrEmpty(this.scrollToElementId)) {
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('internationalMarketId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.internationalMarketError = '';
      }
    }


    if (this.userStatus === '15') {

      if (!ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['annualCount'].value)
        && this.tradeinfoForm.controls['annualCount'].value !== 0) {
        this.annualerror = '';
      } else if (!ValidationService.isNullOrEmpty(this.activeannualMenu)) {
        this.annualerror = '';
      } else {
        this.annualerror = this.translate.instant('tradeinformation.validationMessage.selectAnnualover');
        this.minannualerror = '';
        if (this.tradeinfoForm.controls['annualCount'].value === 0) {
          this.minannualerror = this.translate.instant('tradeinformation.validationMessage.minvalueAnnual');
          this.annualerror = '';
        }
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('annualCountId'), 1000, -100);
        }
        returnVal = false;
      }
    }

    if (this.maturityShow === true) {
      if (this.channelId === this._channelTypeEnum.VENDOR &&
        (ValidationService.isNullOrEmpty(this.tradeinfoForm.controls['maturitylevel'].value))
        || this.channelId === this._channelTypeEnum.DISTRIBUTOR && this.getMaturityList().length === 0
        || this.channelId === this._channelTypeEnum.RETAILER && this.getMaturityList().length === 0) {
        this.maturitylevelerror = this.translate.instant('tradeinformation.validationMessage.chooseMaturitylevel');
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('maturitylevelId'), 1000, -100);
        }
        returnVal = false;
      } else {
        this.maturitylevelerror = '';
      }
    }
    if (this.channelId !== this._channelTypeEnum.RETAILER) {
      if (this.tradeinfoForm.controls['retailernameDescription'].invalid) {
        if (returnVal === true) {
          this.scrollService.scrollTo(document.getElementById('retailernameDescriptionId'), 1000, -100);
        }
        returnVal = false;
      }
    }
    return returnVal;
  }

  maturity(data) {
    if (data) {
      this.maturitylevelerror = '';
    } else {
      this.tradeinfoForm.controls['maturitylevel'].reset();
    }
  }

  // number only for all browser
  numberOnly(event): boolean {
    const charCode = (window.event) ? event.keyCode : event.which;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    // return true;
  }

  // listenBrandScrollChange() {
  //   if (!this.brandPopup) {
  //     this.brandPopup = document.getElementById('mat-autocomplete-2');
  //     this.brandPopup.onscroll = function (event) {
  //       console.log('onscroll', event);
  //     };
  //   }
  // }

  getMaturityList() {
    const maturityList = [];
    if (this.tradeinfoForm.controls['maturitylevelSbackers'].value) {
      maturityList.push(this._MaturityLevel.S_BACKER);
    }
    if (this.tradeinfoForm.controls['maturitylevelPrototype'].value) {
      maturityList.push(this._MaturityLevel.PROTOTYPE);
    }
    if (this.tradeinfoForm.controls['maturitylevelSvolume'].value) {
      maturityList.push(this._MaturityLevel.S_VOLUME);
    }
    return maturityList;
  }

  checkDuplicatesKeyretailers(keyRetailer, typeId: string) {
    this.loaderNotify.emit(true);
    this._sharedService.checkDuplicatesKeyretailerService(keyRetailer.partnername, typeId).subscribe(res => {
      const response = res as Response;
      this.loaderNotify.emit(false);
      const checkDuplicateSelected = this.partnerObjects[typeId].keyRetailerSelectedData.filter(item => item.partnername !== undefined
        && item.partnername.toUpperCase() === keyRetailer.partnername.toUpperCase());
      if (response.ok && checkDuplicateSelected.length === 0) {
        const getCountryName = this.countryMasterList.filter(country => parseInt(country.countryId, 10) === keyRetailer.country);
        if (getCountryName.length) {
          keyRetailer.countryName = getCountryName[0].country;
        }
        this.partnerObjects[typeId].keyRetailerSelectedData.push(keyRetailer);
      } else {
        this.toastr.error(this.translate.instant(typeId === '4' ? 'CommonUsageLabel.keyRetailer' : 'CommonUsageLabel.keyDistributor'));
      }
    });
  }

  filterDeletedRecordswithSelectedKeyRetailers(typeId: string, deletedKeys, objects) {
    let count = 0;
    objects.forEach(item => {
        if (item.keypartnerid === deletedKeys) {
          count++;
        }
      });
    return count === 0 ? true : false;
  }

}
