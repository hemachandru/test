import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { AccountComponent } from './container/account/account.component';
import { AccountVerificationComponent } from './component/account-verification/account-verification.component';
import { AccountTradeInformationComponent } from './component/account-trade-information/account-trade-information.component';
import { AccountProfileComponent } from './component/account-profile/account-profile.component';
import { TradeLocationComponent } from './component/trade-location/trade-location.component';
import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';


const routes: Routes = [
  {
    path: 'account', component: AccountComponent, children:
      [
        {
          path: 'profile', component: AccountProfileComponent, outlet: 'accountroute', canActivate: [AuthGuard],
          data: {
            currentStatus: [
              UserAccountStatus.ACCOUNTSETUP,
              UserAccountStatus.CLAIM_APPROVED]
          }
        },
        {
          path: 'information', component: AccountTradeInformationComponent, outlet: 'accountroute', canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION]
          }
        },
        {
          path: 'location', component: TradeLocationComponent,
          data: {
            redirect: true,
            currentStatus: [UserAccountStatus.ACCOUNTSETUP_TRADELOCATION]
          },
          outlet: 'accountroute', canActivate: [AuthGuard]
        },
      ]
  },
  {
    path: 'accountverify', component: AccountVerificationComponent, canActivate: [AuthGuard],
    data: {
      currentStatus: [UserAccountStatus.CHANNEL_APPROVAL]
    }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class AccountRoutingModule { }
