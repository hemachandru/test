import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { Config } from '../../config/constant';
import { Login, Register, Token } from '../models/user';
// import { AuthService } from '../services/auth.service';
import { AuthService } from '../services/auth.service';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { Response } from '@angular/http';

@Injectable()

export class AuthBusiness {
  private apiUrl = ApiUrl;

  constructor(private authService: AuthService) { }
  // SignUp

  // getDecodedAccessToken(token: string): any {
  //   try {
  //       return jwt_decode(token);
  //   } catch (Error) {
  //       return null;
  //   }
  // }

  login(login: Login) {
    const url = this.apiUrl.LOGIN;
    return this.authService.authServicePostMethod(login, url).map(res => {
      this.setAuthenticateDetails(res);
      return res;
    });
  }

  forgetPasswordBusiness(forgetPass: Login, returnFullResponse: boolean = false) {
    const url = this.apiUrl.FORGETPASSWORD;
    return this.authService.authServicePostMethod(forgetPass, url, returnFullResponse).map(res => {
      return res;
    });
  }

  resetPasswordTokenCheckBusiness(Tokenkey) {
    const url = this.apiUrl.RESETPASSWORD;
    return this.authService.resetPasswordTokenCheckService(Tokenkey, url).map(res => {
      return res;
    });
  }

  resetPasswordBusiness(userId, passValue) {
    const url = this.apiUrl.RESETPASSWORDUPDATE;
    const apiUrl = url + '/' + userId;
    return this.authService.authServicePostMethod(passValue, apiUrl).map(res => {
      return res;
    });
  }

  register(data: any) {
    const url = this.apiUrl.SIGNUP;
    return this.authService.authServicePostMethod(data, url).map(res => {
      return res;
    });
  }

  isEmailRegisterd(data: any) {
    const url = this.apiUrl.CHECK_EMAIL;
    return this.authService.getHttpRequestWithDataMethod(data, url).map(res => {
      return res;
    });
  }

  verifyValidUserBusiness(key, returnFullResponse) {
    const url = this.apiUrl.VERIFYUSER;
    // let headers = this.config.APIKey;
    return this.authService.verifyValidUserBusiness(key, url, returnFullResponse).map(serviceRes => {
      const response = serviceRes as Response;
      if (response.ok) {
        const res = response.json();
        if (res.token) {
          localStorage.setItem(AppLocalStorageKeys.AUTH_Token, res.token);
          localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID, res.contactId);
          localStorage.setItem(AppLocalStorageKeys.USER_CHANNEL_STATUS, res.channelStatusId);
          if (!ValidationService.isNullOrEmpty(res.profile) &&
            !ValidationService.isNullOrEmpty(res.profile.channel) &&
            !ValidationService.isNullOrEmpty(res.profile.channel.channelTypeId)) {
            localStorage.setItem(AppLocalStorageKeys.CHANNEL_TYPE_ID, res.profile.channel.channelTypeId);
          }
        }
      }

      return serviceRes;
    });
  }

  resendEmail(returnFullResponse: boolean = false) {
    const url = this.apiUrl.RESENDEMAIL;
    return this.authService.resendEmail(url, returnFullResponse).map(res => {
      return res;
    });
  }

  changeAndResendEmail(email: string) {
    const url = this.apiUrl.CHANGEANDRESENDEMAIL;
    return this.authService.changeAndResendEmail(email, url).map(res => {
      return res;
    });
  }

  setAuthenticateDetails(res) {
    if (res.token) {
      localStorage.setItem(AppLocalStorageKeys.AUTH_Token, res.token);
      localStorage.setItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID, res.contactId);
      localStorage.setItem(AppLocalStorageKeys.USER_CHANNEL_STATUS, res.channelStatusId);
      localStorage.setItem(AppLocalStorageKeys.CHANNEL_ID, res.channelId);
      localStorage.setItem(AppLocalStorageKeys.CHANNEL_TYPE_ID, res.profile.channel.channelTypeId);
      localStorage.setItem(AppLocalStorageKeys.OLD_CHANNEL, res.oldChannel);
      if (res.profile && res.profile.channel && res.profile.channel.channelSubscription &&
        res.profile.channel.channelSubscription.subscriptionId) {
        localStorage.setItem(AppLocalStorageKeys.CURRENT_SUBSCRIPTION_PLAN, res.profile.channel.channelSubscription.subscriptionId);
        localStorage.setItem(AppLocalStorageKeys.CURRENT_SUBSCRIPTION_PLAN_ORDER, res.profile.channel.plan.rankOrder);
      }

      if (!ValidationService.isNullOrEmpty(res.profile.document)) {
        localStorage.setItem(AppLocalStorageKeys.USER_IMAGE_URL, res.profile.document.documentUrl);
      } else {
        localStorage.setItem(AppLocalStorageKeys.USER_IMAGE_URL, '');
      }
      if (!ValidationService.isNullOrEmpty(res.profile.channel.channelType)
        && !ValidationService.isNullOrEmpty(res.profile.channel.channelType.channelType)) {
        localStorage.setItem(AppLocalStorageKeys.CHANNEL_TYPE, res.profile.channel.channelType.channelType);
      } else {
        localStorage.setItem(AppLocalStorageKeys.CHANNEL_TYPE, '');
      }
      if (!ValidationService.isNullOrEmpty(res.profile.firstName)) {
        localStorage.setItem(AppLocalStorageKeys.USER_NAME, res.profile.firstName + ' ' + res.profile.lastName);
      } else {
        localStorage.setItem(AppLocalStorageKeys.USER_NAME, '');
      }
      if (!ValidationService.isNullOrEmpty(res.profile.jobTitle)) {
        localStorage.setItem(AppLocalStorageKeys.JOB_TITLE, res.profile.jobTitle);
      } else {
        localStorage.setItem(AppLocalStorageKeys.JOB_TITLE, '');
      }

      if (!ValidationService.isNullOrEmpty(res.role)) {
        localStorage.setItem(AppLocalStorageKeys.ROLE, JSON.stringify(res.role));
      }

      if (!ValidationService.isNullOrEmpty(res.permissions)) {
        localStorage.setItem(AppLocalStorageKeys.PERMISSIONS, JSON.stringify(res.permissions));
      }

      if (!ValidationService.isNullOrEmpty(res.sellingProfile)) {
        localStorage.setItem(AppLocalStorageKeys.SELLING_PROFILE, JSON.stringify(res.sellingProfile));
      }

      if (!ValidationService.isNullOrEmpty(res.sourcingProfile)) {
        localStorage.setItem(AppLocalStorageKeys.SOURCING_PROFILE, JSON.stringify(res.sourcingProfile));
      }
      // For local session handling
      localStorage.setItem(AppLocalStorageKeys.AUTH_LOCAL_TIME, new Date().toString());
    }
  }
}
