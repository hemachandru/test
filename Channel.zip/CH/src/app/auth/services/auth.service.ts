import { Observable } from 'rxjs/Observable';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { _throw } from 'rxjs/observable/throw';
import { User, Authenticate } from '../models/user';
import { of } from 'rxjs/observable/of';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ToastyService } from 'ng2-toasty';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { IRequestOptions } from '../../communication/services/Interface/IRequestOptions';

@Injectable()

export class AuthService {

  private _option = <IRequestOptions>{};

  constructor(private http: HttpClient, private toastyService: ToastyService, private _httpReqService: HttpRequestService) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  authServicePostMethod(dataparams: any, url: string, returnFullResponse: boolean = false) {
    return this._httpReqService.postHttpRequestWithoutToken(dataparams, url, returnFullResponse);
  }

  resetPasswordTokenCheckService(dataparams: any, url: string) {
    return this._httpReqService.getHttpRequestWithoutTokenWithData(dataparams, url);
  }

  verifyValidUserBusiness(dataparams: any, url: string, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequestWithoutTokenWithData(dataparams, url, returnFullResponse);
  }

  resendEmail(url: string, returnFullResponse: boolean = false) {
    return this._httpReqService.getHttpRequest(url, returnFullResponse);
  }

  changeAndResendEmail(dataparams: any, url: string) {
    return this._httpReqService.getHttpRequestWithData(dataparams, url);
  }

  getHttpRequestWithDataMethod(dataparams: any, url: string) {
    return this._httpReqService.getHttpRequestWithData(dataparams, url);
  }

  /**
   * @returns {HttpHeaders}
   * @memberof AuthService
   */

  getTokenHeader(): HttpHeaders {
    const headerObject = {};
    headerObject['Content-Type'] = 'application/json';

    const AUTH_Token = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    const APP_Token = localStorage.getItem(AppLocalStorageKeys.APP_Token);

    if (AUTH_Token !== undefined) {
      headerObject['Authorization'] = AUTH_Token;
    } else {
      headerObject['Authorization'] = APP_Token;
    }
    return new HttpHeaders(headerObject);
  }

  private setTokenInLocalStorage(res): void {
    const user_data = {
      ...res.body.data,
      access_token: res.headers.get('access-token'),
      client: res.headers.get('client')
    };
    const jsonData = JSON.stringify(user_data);
    localStorage.setItem(AppLocalStorageKeys.USER, jsonData);
  }

  getServiceHttpClient(url: string) {
    return this._httpReqService.getHttpClientRequest(url, this._option);
  }


}
