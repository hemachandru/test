import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidKeyTokenComponent } from './invalid-key-token.component';

describe('InvalidKeyTokenComponent', () => {
  let component: InvalidKeyTokenComponent;
  let fixture: ComponentFixture<InvalidKeyTokenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvalidKeyTokenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidKeyTokenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
