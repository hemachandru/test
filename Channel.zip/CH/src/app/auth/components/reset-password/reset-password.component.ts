import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

import { SharedModule } from '../../../shared/shared.module';
import { AuthBusiness } from '../../business/auth.business';
import { Login } from '../../models/user';

import { Router, NavigationStart, NavigationEnd, ActivatedRoute, Event as NavigationEvent } from '@angular/router';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { Config, UserAccountStatus } from '@app/config/constant';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
import { NotificatoinService } from '../../../core/service/notificatoin-service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  resetPassForm: FormGroup;
  formSubmit = false;
  private queryParams: any;
  private userId: any;
  public iserror: boolean;
  private error_message = '';
  public error_Message_Token_block: any;
  public loading = false;
  public resetPwdtoken: string;
  passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,15}$';
  private notificatoinService: NotificatoinService;
  public webUrl = WebUrl;

  constructor(private router: Router, private fb: FormBuilder, private toastrService: ToastrService,
    private translate: TranslateService, public authBusiness: AuthBusiness,
    private activeRoute: ActivatedRoute, public config: Config, public localStorageService: LocalStorageService) {
    this.iserror = false;
    this.resetPwdtoken = '';
  }

  ngOnInit() {
    this.activeRoute.params.subscribe(params => {
      this.queryParams = params;
    });

    this.resetPwdtoken = this.queryParams.key;
    this.loading = true;
    this.authBusiness.resetPasswordTokenCheckBusiness(this.resetPwdtoken).subscribe(result => {
      this.resetPassForm.reset();
      this.loading = false;
      if (result.length) {
        const errors = result;
        if (errors) {
          errors.forEach(val => {
            if (val.errors[0].code === 1404) {
              this.router.navigate(['auth/invalidkey']);
            }
          });
        }
      } else {
        this.userId = result.userId;
        localStorage.setItem(AppLocalStorageKeys.USER_ID, this.userId);
      }
    },
      (error) => {
        this.resetPassForm.reset();
        console.log(error);
      });

    this.initForm();
  }

  initForm() {
    const password = '';
    const retypePassword = '';

    this.resetPassForm = this.fb.group({
      password: ['', Validators.compose(
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(25)
          , Validators.pattern(this.config.passwordAlphaNumericPattern)
          // Validators.maxLength(10)
        ]
      )],
      retypePassword: ['', Validators.required]
    }, { validator: this.matchingPasswords('password', 'retypePassword') }
    );
  }

  matchingPasswords(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      const password = group.controls[passwordKey];
      const confirmPassword = group.controls[confirmPasswordKey];

      if (password.value !== confirmPassword.value) {
        return {
          mismatchedPasswords: true
        };
      }
    };
  }

  onSubmit() {
    const password = this.resetPassForm.value.password;
    Object.keys(password);
    this.formSubmit = true;
    // const uid = localStorage.getItem(AppLocalStorageKeys.USER_ID);
    if (this.resetPassForm.valid) {
      this.loading = true;
      const values = { 'password': password };
      this.authBusiness.resetPasswordBusiness(this.resetPwdtoken, JSON.stringify(values)).subscribe(result => {
        if (!ValidationService.isNullOrEmpty(result.message)) {
          this.resetPassForm.reset();
          this.iserror = true;
          this.localStorageService.clearAllDataExceptAppToken();
          // this.router.navigate([this.webUrl.LOGIN]);
          this.toastrService.info(this.translate.instant('verification.resetPassword'));
          // tslint:disable-next-line:max-line-length
          // this.error_message = 'Your password has been updated, please kindly' + '<a class=\'orange_text\' href=\'/auth/login\'>LOGIN</a>';
        } else {
          this.iserror = true;
          this.error_message = result[0].errors[0].message;
        }
        this.loading = false;
      },
        (error) => {
          this.loading = false;
          console.log(error);
        });
    } else {
      console.log('error');
    }
  }

}
