import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { SharedModule } from '../../../shared/shared.module';
import { AuthBusiness } from '../../business/auth.business';
import { Login } from '../../models/user';
import { Config } from '@app/config/constant';
import { Response } from '@angular/http';
import { ValidationService } from '@app/shared/shared-service/validation-service';


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  public forgetpassword_message: any;
  public loading = false;
  public isError: boolean;

  forgetForm: FormGroup;
  formSubmit = false;

  constructor(private fb: FormBuilder, public authBusiness: AuthBusiness, public config: Config,
    private translate: TranslateService) { }

  ngOnInit() {
    this.initForm();
    this.isError = false;
  }

  initForm() {
    const email = '';
    this.forgetForm = this.fb.group({
      email: ['', Validators.compose(
        [Validators.required,
        Validators.email,
        Validators.pattern(this.config.emailPattern)]
      )]
    }
    );
  }

  onSubmit() {
    const values = this.forgetForm.value;
    this.formSubmit = true;

    if (this.forgetForm.valid) {
      this.loading = true;
      this.forgetForm.reset();
      this.authBusiness.forgetPasswordBusiness(values, true).subscribe(serviceRes => {
        const response = serviceRes as Response;
        this.loading = false;
        const result = response.json();
        if (response.ok) {
          this.isError = false;
          this.forgetpassword_message = response.json().message;
        } else {
          this.isError = true;
          this.forgetpassword_message = this.translate.instant
          (ValidationService.getSignUpValidatorErrorMessage('email', result[0].errors[0].code));
          // this.forgetpassword_message = 'Mail Sending failed..!';
        }
      },
        (error) => {
          this.forgetForm.reset();
          console.log(error);
        });

    } else {
      console.log('form filling error');
    }
  }

  clearError() {
    this.forgetpassword_message = '';
  }
}
