import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthBusiness } from '../../business/auth.business';

import { Router } from '@angular/router';
import { RoleMenu, Config, UserAccountStatus, ChannelTypeIdEnum } from '../../../config/constant';
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { UserDetailMessage } from '@app/config/constant';
import { ApiUrl, WebUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { CodeDataTransferService } from '@app/core/service/code-data-transfer.service';
import { ProductService } from '@app/product/service/product-service.service';
import { CartCountService } from '@app/shared/shared-service/cart-count';
import { FavoriteCountService } from '@app/shared/shared-service/product-favorite-count';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { UserStatusDetail } from '@app/shared/models/shared-model';
import Json from '*.json';
import { CoreService } from '@app/core/service/core.service';
import { TranslateService } from '@ngx-translate/core';
import { LocalStorage } from '@ngx-pwa/local-storage';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  public webUrl = WebUrl;
  private apiUrl = ApiUrl;

  public favoriteCount;
  loginForm: FormGroup;
  formSubmit = false;
  public errorMessage: any;
  msg_code;
  controlEmail;
  controlPassword;
  private userDetailMessage: UserDetailMessage;
  public loading = false;
  public cartCount;

  public userData: any;
  public mytoken: any;

  constructor(
    private _coreService: CoreService,
    private config: Config,
    private fb: FormBuilder,
    public authBusiness: AuthBusiness,
    public codeDataTransferService: CodeDataTransferService,
    private router: Router,
    private userDetailService: UserDetailService,
    private productService: ProductService,
    private favoriteCountService: FavoriteCountService,
    private cartCountService: CartCountService, private sharedService: SharedService,
    private translate: TranslateService,
    protected asyncLocalStorage: LocalStorage) {
    this.userDetailMessage = new UserDetailMessage();
  }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    const email = '';
    const password = '';
    this.loginForm = this.fb.group({
      email: ['',
        Validators.compose(
          [
            Validators.required,
            Validators.pattern(this.config.emailPattern)
          ]
        )
      ],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(25)
      ]
      )]
    }
    );
  }

  onSubmit() {
    const values = this.loginForm.value;
    const keys = Object.keys(values);
    this.formSubmit = true;
    if (this.loginForm.valid) {
      this.loading = true;
      this.authBusiness.login(values).subscribe(result => {
        this.mytoken = result._body;
        this.loading = false;
        if (result.token) {
          // unset localstage
          this.asyncLocalStorage.clear().subscribe(() => {});
  
          const userStatusdetail: UserStatusDetail = {
            companyName: result.profile.channel.companyName,
            channelStatusId: result.profile.channel.signUpStatusId,
            subscriptionId: result.profile.channel.subscriptionId,
            planId: result.profile.channel.planId,
            features: {}
          };
          localStorage.setItem(AppLocalStorageKeys.USER_STATUS_DETAILS, JSON.stringify(userStatusdetail));

          result.channelStatusId = parseInt(result.channelStatusId, 10);
          const CHANNEL_TYPE_ID = parseInt(result.profile.channel.channelTypeId, 10);
          if (result.channelStatusId >= UserAccountStatus.CHANNEL_APPROVED) {
            if (CHANNEL_TYPE_ID === ChannelTypeIdEnum.DISTRIBUTOR || CHANNEL_TYPE_ID === ChannelTypeIdEnum.RETAILER) {
              this.getCartCount();
              this.getFavoriteCount();
            }
            this.codeDataTransferService.changeSocketConnection(result.profile.email);
            this.getNotificationCount();

            this.getCurrencyConverionTable();

            localStorage.setItem(AppLocalStorageKeys.USER_CURRENCY, result.currency);
          }

          this.errorMessage = '';
          if (result.channelStatusId !== undefined) {

            const mailRedirectURL = localStorage.getItem(AppLocalStorageKeys.MAIL_REDIRECTION);

            if (result.channelStatusId === UserAccountStatus.VERIFICATION ||
              result.channelStatusId === UserAccountStatus.REVERIFICATION ||
              result.channelStatusId === UserAccountStatus.REVERIFICATION_MAILCHANGE) {
              this.userDetailMessage.email = values.email;
              this.userDetailMessage.action = this.apiUrl.VERIFICATIONPENDING;
              this.userDetailService.onUserDetailChange(this.userDetailMessage);
              this.router.navigate(['auth/accountverify']);
            } else if (result.channelStatusId === UserAccountStatus.SUBSCRIPTION) {
              this.router.navigate([this.webUrl.USER_PROFILE_SELECTION]);
            } else if (parseInt(result.channelStatusId, 10) === UserAccountStatus.PAYMENT_PENDING) {
              this.router.navigate(['user/subscriptionplan']);
            } else if (result.channelStatusId === UserAccountStatus.ACCOUNTSETUP) {
              this.router.navigate(['/account', { outlets: { 'accountroute': ['profile'] } }]);
            } else if (result.channelStatusId === UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION) {
              this.router.navigate(['/account', { outlets: { 'accountroute': ['information'] } }]);
            } else if (result.channelStatusId === UserAccountStatus.ACCOUNTSETUP_TRADELOCATION) {
              this.router.navigate(['/account', { outlets: { 'accountroute': ['location'] } }]);
              // tslint:disable-next-line:max-line-length
            } else if ((result.channelStatusId === UserAccountStatus.CHANNEL_APPROVAL)
              && (CHANNEL_TYPE_ID !== ChannelTypeIdEnum.SALESREP)) {
              this.router.navigate(['/accountverify']);
            } else if (CHANNEL_TYPE_ID === ChannelTypeIdEnum.SALESREP) {
              this.router.navigate(['/salesrepinfo']);
            } else if (result.channelStatusId === UserAccountStatus.CLAIM) {
              this.router.navigate(['/claiminfo']);
            } else if (result.channelStatusId === UserAccountStatus.CLAIM_APPROVED) {
              this.router.navigate(['/account', { outlets: { 'accountroute': ['profile'] } }]);
            } else if (mailRedirectURL) {
              this.router.navigate([mailRedirectURL]);
              localStorage.removeItem(AppLocalStorageKeys.MAIL_REDIRECTION);
            } else if (result.channelStatusId === UserAccountStatus.CHANNEL_APPROVED) {
              // const userStatusdetail = JSON.parse(localStorage.getItem(AppLocalStorageKeys.USER_STATUS_DETAILS));

              if ((userStatusdetail.planId == null) && (userStatusdetail.subscriptionId == null)) {
                this.router.navigate(['/user/landing']);
              } else if (CHANNEL_TYPE_ID !== ChannelTypeIdEnum.SALESREP) {
                localStorage.setItem(AppLocalStorageKeys.USER_CHANNEL_STATUS, JSON.stringify(UserAccountStatus.CHANNEL_APPROVED));
                this.router.navigate(['/channel/suggestions']);
              }
            }
          }
          // this.router.navigate(['home']);
        } else {
          this.errorMessage = this.translate.instant(ValidationService.getApplicationMessage('003'));
        }
      },
        (error) => {
          this.loading = false;
          console.log('Error on login: ', error);
        });


    } else {
      keys.forEach(val => {
        const ctrl = this.loginForm.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        }
      });
    }
  }

  // Cart count
  getCartCount() {
    this.cartCount = 0;
    this.cartCountService.cartCountDetailChange(this.cartCount);
    // this.productService.getCartCount().subscribe(res => {
    //   if (res.status) {
    //     const result = res.data;

    //     this.cartCount = result.reduce((acc, val) => {
    //       const productCount = parseInt(val.product_count, 10);
    //       return acc + productCount;
    //     }, 0);
    //     this.cartCountService.cartCountDetailChange(this.cartCount);
    //   } else {
    //     console.log('add to cart ' + res);
    //   }
    // });
  }

  // Favorite count
  getFavoriteCount() {
    this.favoriteCount = 0;
    this.favoriteCountService.favoriteCountDetailChange(this.favoriteCount);
    // this.productService.getFavoriteCount().subscribe(res => {
    //   if (res.status) {
    //     this.favoriteCount = res.count;
    //     this.favoriteCountService.favoriteCountDetailChange(this.favoriteCount);
    //   } else {
    //     console.log('add to cart ' + res);
    //   }
    // });
  }

  // To get currency convertions
  getCurrencyConverionTable() {
    this.sharedService.getCurrencyConversionList().subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        localStorage.setItem(AppLocalStorageKeys.CURRENCY_CONVERTION_TABLE, JSON.stringify(result.body));
      }
    },
      (error) => {
        console.log(error);
      });
  }

  getNotificationCount() {
    this._coreService.getNotificationCount().subscribe(response => {
      if (response.ok) {
        RoleMenu[4].count = response.body.unread;
      }
    }, (error) => {
      console.log(error);
    });
  }
}
