import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { SharedModule } from '../../../shared/shared.module';
import { Login, Register } from '../../models/user';
import { AuthBusiness } from '@app/auth/business/auth.business';
import { Router } from '@angular/router';
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { UserDetailMessage } from '@app/config/constant';
import { PasswordValidation } from '@app/shared/shared-service/confirm-password.service';
import { Config } from '@app/config/constant';
import { WebUrl } from '@app/config/constant_keys';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.scss']
})
export class SignupFormComponent implements OnInit {
  public webUrl = WebUrl;
  signUpForm: FormGroup;
  formSubmit = false;
  // countryId;
  public loading = false;
  ctrl_name;
  msg_code;
  registerSubs;
  controlFirstName;
  controlLastName;
  controlEmail;
  controlPassword;
  controlRetypePassword;
  // controlCountry; /** just hide country related function for new CR */
  userDetailMessage: UserDetailMessage;
  showPassword: boolean;
  showRePassword: boolean;
  public selectClass: any = 'grey-selectbox';
  public errorAccept: boolean;
  public conditionCheck: boolean;

  constructor(
    private fb: FormBuilder,
    private authBusiness: AuthBusiness,
    private router: Router,
    private userDetailService: UserDetailService, public config: Config) {
    this.userDetailMessage = new UserDetailMessage();
  }

  ngOnInit() {
    this.initForm();
  }


  initForm() {
    const firstName = '';
    const lastName = '';
    const email = '';
    const password = '';
    const retypePassword = '';
    // const country = '';

    this.signUpForm = this.fb.group({
      firstName: ['', Validators.compose(
        [Validators.required,
        Validators.minLength(2),
        Validators.maxLength(30)]
      )],
      lastName: ['', Validators.compose(
        [Validators.required,
        Validators.minLength(1),
        Validators.maxLength(30)]
      )],
      email: ['', [
        Validators.required,
        Validators.pattern(this.config.emailPattern)]
        , this.isEmailUnique.bind(this)
      ],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(25),
        Validators.pattern(this.config.passwordAlphaNumericPattern)]
      )],
      retypePassword: ['', Validators.compose([
        Validators.required
      ]
      )]
    });
  }

  onSubmit() {
    const values = this.signUpForm.value;
    const keys = Object.keys(values);
    this.formSubmit = true;
    // const self = this;

    const registerData = {
      'firstname': values.firstName,
      'lastname': values.lastName,
      'email': values.email,
      'password': values.password
      // 'country': this.countryId
    };
    if (this.signUpForm.valid && values.password === values.retypePassword) { //Validation for password match
      if (this.errorAccept) {
        this.errorAccept = true;
        this.conditionCheck = false;
        this.loading = true;
        this.authBusiness.register(registerData).subscribe(data => {
          this.loading = false;
          if (data.length) {
            const errors = data;
            if (errors) {
              console.log(errors);
              errors.forEach(val => {
                if (val.firstname) {
                  this.controlFirstName = 'firstname';
                  this.msg_code = val.password[0].code;
                }
                if (val.lastname) {
                  this.controlLastName = 'lastname';
                  this.msg_code = val.lastname[0].code;
                }
                if (val.email) {
                  this.controlEmail = 'email';
                  this.msg_code = val.email[0].code;
                }
                if (val.password) {
                  this.controlPassword = 'password';
                  this.msg_code = val.password[0].code;
                }
                // if (val.country) {
                //   this.controlCountry = 'country';
                //   this.msg_code = val.country[0].code;
                // }
                if (val.errors) {
                  this.controlEmail = 'email';
                  this.msg_code = val.errors[0].code;
                }
              });
            }
          } else {
            const LoginData = {
              'email': values.email,
              'password': values.password
            };
            this.loginUser(LoginData);
          }

        });
      } else {
        this.errorAccept = false;
        this.conditionCheck = true;
      }
    } else {
      keys.forEach(val => {
        const ctrl = this.signUpForm.controls[val];
        if (!ctrl.valid) {
          ctrl.markAsTouched();
        }
        // if (!this.countryId) {
        //   this.controlCountry = 'country';
        //   this.msg_code = '0002';
        // }
      });
    }
  }

  loginUser(data: Login) {
    this.authBusiness.login(data).subscribe(res => {
      this.userDetailMessage.email = data.email;
      this.userDetailMessage.action = 'SubscriptionSuccess';
      this.userDetailService.onUserDetailChange(this.userDetailMessage);
      this.router.navigate(['auth/accountverify']);
    }, (err) => {
      this.router.navigate([this.webUrl.LOGIN]);
    });
  }

  // public async getContryID(data: string): Promise<any> {
  //   this.countryId = parseInt(data, 10);
  //   if (data) {
  //     this.controlCountry = '';
  //     this.msg_code = '';
  //   }
  // }

  signUpReset() {
    this.signUpForm.reset();
  }

  // Exisitng Email validation
  isEmailUnique(control: FormControl) {
    const q = new Promise((resolve, reject) => {
      this.authBusiness.isEmailRegisterd(control.value).subscribe((res: any) => {
        if (res.isavialble === false) {
          resolve({ 'isEmailUnique': true });
        } else {
          resolve(null);
        }
      });
    });
    return q;
  }

  herebyAccept(event) {
    this.errorAccept = !this.errorAccept;
  }
}
