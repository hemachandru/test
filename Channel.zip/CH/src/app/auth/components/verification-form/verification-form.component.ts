import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthBusiness } from '../../business/auth.business';
// import { UserDetailService } from "../../services/user-detail.service";
import { UserDetailService } from '../../../shared/shared-service/user-detail.service';
import {
  SuccesErrorMessage, UserDetailMessage, Config, UserAccountStatus
  , SuccesErrorButton, MessageContent, VerificationButtonTypes, EmailMessage
} from '@app/config/constant';
import { SharedBusiness } from '../../../shared/shared-business/shared-business';
import { ApiUrl, AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { Response } from '@angular/http';
import { ToastrService } from 'ngx-toastr';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { TranslateService } from '@ngx-translate/core';
import { LocalStorageService } from '@app/shared/shared-service/local-storage-service';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'accountverify',
  templateUrl: './verification-form.component.html',
  styleUrls: ['./verification-form.component.scss']
})
export class VerificationFormComponent implements OnInit {
  public webUrl = WebUrl;
  private apiUrl = ApiUrl;
  public loading = false;
  private email: string;
  isChangeEmailHidden: boolean;
  verifyContentMessage: string;
  private queryParams: any;

  // Verification constants
  subscriptionSuccessAction: string;
  verificationExpiredAction: string;
  resendVerificationAction: string;
  changeAndResendVerificationAction: string;
  verificationPendingAction: string;
  resendVerificationBtnName: string;
  loginToVerifyBtnName: string;
  goToSubscriptionBtnName: string;
  resendEmailBtnName: string;
  changeEmailBtnName: string;
  changeAndResendEmailBtnName: string;
  public verificationObject: SuccesErrorMessage;
  private userDetailMessage: UserDetailMessage;
  private emailId: EmailMessage;
  loginBtnName: string;
  changeEmail: string;

  constructor(private activeRoute: ActivatedRoute, private router: Router,
    private authBusiness: AuthBusiness, private userDetailService: UserDetailService,
    private config: Config, private sharedBusiness: SharedBusiness,
    private translate: TranslateService,
    private toastr: ToastrService, private sharedService: SharedService, public localStorageService: LocalStorageService) {
    this.email = '';
    this.isChangeEmailHidden = true;
    this.userDetailMessage = new UserDetailMessage();
    this.verifyContentMessage = '';
    this.subscriptionSuccessAction = 'SubscriptionSuccess';
    this.verificationExpiredAction = 'VerificationExpired';
    this.resendVerificationAction = 'ResendVerification';
    this.changeAndResendVerificationAction = 'ChangeAndResendVerification';
    this.verificationPendingAction = 'VerificationPending';
    this.resendVerificationBtnName = 'ResendVerification';
    this.loginToVerifyBtnName = 'LoginToVerify';
    this.goToSubscriptionBtnName = 'GoToSubscription';
    this.resendEmailBtnName = 'ResendEmail';
    this.changeEmailBtnName = 'ChangeEmail';
    this.changeAndResendEmailBtnName = 'ChangeAndResendEmail';
    this.loginBtnName = 'Login';
    this.changeEmail = '';
    this.verificationObject = new SuccesErrorMessage();
    this.verificationObject.messages = new Array<MessageContent>();
    this.verificationObject.button = new Array<SuccesErrorButton>();
  }

  ngOnInit() {
    if (localStorage.getItem(AppLocalStorageKeys.APP_Token)) {
      this.loadVerificationForm();
    } else {
      this.getApptoken();
    }
  }

  async getApptoken() {
    let result;
    result = await this.sharedService.getApptoken();
    const response = result as Response;
    if (response.ok) {
      result = result.json();
      // For refresing app auth token
      localStorage.setItem(AppLocalStorageKeys.APP_AUTH_LOCAL_TIME, new Date().toString());
      localStorage.setItem(AppLocalStorageKeys.APP_Token, result.Authorization);
      this.loadVerificationForm();
    } else {
      this.toastr.info(this.translate.instant('commonError.tryAgain'));
      this.router.navigate(['auth/login']);
    }
  }

  loadVerificationForm(): void {
    this.activeRoute.params.subscribe(params => {
      this.queryParams = params;
    });
    const key = this.queryParams.key;
    if (!ValidationService.isNullOrEmpty(key) && key.trim().length > 0) {
      this.authBusiness.verifyValidUserBusiness(key, true).subscribe(serviceRes => {
        const response = serviceRes as Response;
        if (response.ok) {
          const result = response.json();
          if (result && result.token !== undefined && result.token.length > 0) {
            // this.userDetailMessage.email = '';
            // this.userDetailMessage.action = this.apiUrl.VERIFIED_ALREADY;
            // this.userDetailService.onUserDetailChange(this.userDetailMessage);
            this.localStorageService.clearAllDataExceptAppTokenLocally();
            this.authBusiness.setAuthenticateDetails(result);
            this.userDetailMessage.email = '';
            this.userDetailMessage.action = this.apiUrl.VERIFICATIONSUCCESS;
            this.userDetailService.onUserDetailChange(this.userDetailMessage);
            this.setVerificationUITemplate(true, true);
          }
        } else {
          const result = response.json();
          if (result[0] !== null && result[0].errors !== undefined) {
            const errors = result[0].errors;
            if (errors[0].code === 1209 || errors[0].code === 1426) {
              this.setVerificationUITemplate(true, false);
            } else if (errors[0].code === 1001 || errors[0].code === 1002 || errors[0].code === 1002
              || errors[0].code === 1425 || errors[0].code === 1427) {
              localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
              this.router.navigate([this.webUrl.LOGIN]);
            } else if (errors[0].code === 1425) {
              this.setVerificationUITemplate(true, false);
            } else if (errors[0].code === 1428) {
              this.userDetailMessage.email = '';
              this.userDetailMessage.action = this.apiUrl.VERIFIED_ALREADY;
              this.userDetailService.onUserDetailChange(this.userDetailMessage);
              this.setVerificationUITemplate(true, true, true);
            } else {
              this.setVerificationUITemplate(true, false);
            }
          } else {
            this.setVerificationUITemplate(true, false);
          }
        }
      },
        (error) => {
          // const errors = error[0].errors;
          if (error) {
            localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
            this.router.navigate([this.webUrl.LOGIN]);
          } else {
            this.setVerificationUITemplate(true, false);
          }
        });
    } else {
      this.sharedBusiness.getUserStatus(true).subscribe(serviceRes => {
        const response = serviceRes as Response;
        if (response.ok) {
          const _channelStatusId = response.json().channelStatusId;
          if (_channelStatusId.toString() !== undefined) {
            if (_channelStatusId.toString() === UserAccountStatus.VERIFICATION.toString() ||
              _channelStatusId.toString() === UserAccountStatus.REVERIFICATION.toString() ||
              _channelStatusId.toString() === UserAccountStatus.REVERIFICATION_MAILCHANGE.toString()) {
              this.loadAccountVerifyChangeorResendEmailPage();
            } else if (_channelStatusId === UserAccountStatus.SUBSCRIPTION.toString()) {
              this.router.navigate([this.webUrl.USER_PROFILE_SELECTION]);
            } else {
              this.loadAccountVerifyChangeorResendEmailPage();
            }
          } else {
            this.loadAccountVerifyChangeorResendEmailPage();
          }
        } else {
          this.loadAccountVerifyChangeorResendEmailPage();
        }
      },
        (error) => {
          if (error) {
            localStorage.setItem(AppLocalStorageKeys.AUTH_Token, '');
            this.router.navigate([this.webUrl.LOGIN]);
          } else {
            this.loadAccountVerifyChangeorResendEmailPage();
          }
        });
    }
  }

  loadAccountVerifyChangeorResendEmailPage() {
    if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== null && localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== '') {
      this.userDetailService.currentUserDetail.subscribe(response => {
        this.userDetailMessage = response;
      });
      if (this.userDetailMessage !== undefined && this.userDetailMessage !== null
        && this.userDetailMessage.action !== undefined && this.userDetailMessage.action !== null) {
        this.email = this.userDetailMessage.email;
        if (this.userDetailMessage.action === this.apiUrl.SUBSCRIPTIONSUCCESS) {
          this.getVerifyContentMessage(this.subscriptionSuccessAction);
        } else if (this.userDetailMessage.action === this.apiUrl.VERIFICATIONPENDING) {
          this.getVerifyContentMessage(this.verificationPendingAction);
        } else {
          this.getVerifyContentMessage('');
        }

        this.setVerificationUITemplate(false, false);
      } else {
        this.getVerifyContentMessage('');
        this.setVerificationUITemplate(false, false);
      }
    } else {
      // go to login
      this.router.navigate([this.webUrl.LOGIN]);
      // this.setVerificationUITemplate(false, false);
    }
  }

  setVerificationUITemplate(isVerificationLanding: boolean, isVerificationLinkSuccess: boolean, isAlreadyVerified: boolean = false) {
    if (isVerificationLanding) {
      this.verificationObject.errorTitle = 'Account Verification';
      this.verificationObject.showButtonBlock = true;
      if (isAlreadyVerified || isVerificationLinkSuccess) {
        this.verificationObject.errorId = '1';
        this.verificationObject.errorType = 'success';
        this.verificationObject.icon = 'fa-check';
      } else {
        this.verificationObject.icon = 'fa-times';
      }

      if (isAlreadyVerified) {
        this.verificationObject.iconMessage = 'verification.verifiedalready';
        let messageContent = new MessageContent();
        messageContent.messageContent = 'verification.youVerifiedalready';
        this.verificationObject.messages.push(messageContent);
        messageContent = new MessageContent();
        messageContent.messageContent = 'verification.tocontinue';
        this.verificationObject.messages.push(messageContent);
        const successErrBtn = new SuccesErrorButton();

        const authToken = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
        const channelStatusId = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
        if (!ValidationService.isNullOrEmpty(authToken) && !ValidationService.isNullOrEmpty(channelStatusId)
          && parseInt(channelStatusId, 10) <= UserAccountStatus.SUBSCRIPTION) {
          successErrBtn.buttonType = VerificationButtonTypes.Success;
          successErrBtn.buttonName = this.goToSubscriptionBtnName;
          successErrBtn.buttonValue = 'verification.gotoSetup';
        } else {
          this.userDetailMessage.email = '';
          this.userDetailMessage.action = this.apiUrl.VERIFIED_ALREADY;
          this.userDetailService.onUserDetailChange(this.userDetailMessage);

          successErrBtn.buttonType = VerificationButtonTypes.Success;
          successErrBtn.buttonName = this.loginBtnName;
          successErrBtn.buttonValue = 'verification.gotoLogin';
        }

        this.verificationObject.button.push(successErrBtn);
      } else if (isVerificationLinkSuccess) {
        this.verificationObject.iconMessage = 'verification.verifiedSuccessfully';
        let messageContent = new MessageContent();
        messageContent.messageContent = 'verification.welcomehub';
        this.verificationObject.messages.push(messageContent);
        messageContent = new MessageContent();
        messageContent.messageContent = 'verification.worldsb2b';
        this.verificationObject.messages.push(messageContent);
        const successErrBtn = new SuccesErrorButton();
        if (localStorage.getItem(AppLocalStorageKeys.ROLE)) {
          successErrBtn.buttonType = VerificationButtonTypes.Success;
          successErrBtn.buttonName = this.goToSubscriptionBtnName;
          successErrBtn.buttonValue = 'verification.gotoSetup';
        } else {
          this.userDetailMessage.email = '';
          this.userDetailMessage.action = this.apiUrl.VERIFIED_ALREADY;
          this.userDetailService.onUserDetailChange(this.userDetailMessage);

          successErrBtn.buttonType = VerificationButtonTypes.Success;
          successErrBtn.buttonName = this.loginBtnName;
          successErrBtn.buttonValue = 'verification.gotoLogin';
        }
        this.verificationObject.button.push(successErrBtn);
      } else {
        this.verificationObject.errorId = '2';
        this.verificationObject.errorType = 'failure';
        this.verificationObject.iconMessage = 'verification.verificationFailed';
        let messageContent = new MessageContent();
        messageContent.messageContent = 'verification.expiredurl';
        this.verificationObject.messages.push(messageContent);
        messageContent = new MessageContent();
        messageContent.messageContent = 'verification.tocontinue';
        this.verificationObject.messages.push(messageContent);
        const successErrBtn = new SuccesErrorButton();
        successErrBtn.buttonType = VerificationButtonTypes.Success;
        // successErrBtn.buttonName = localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== null &&
        //   localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== '' ? this.resendVerificationBtnName : this.loginToVerifyBtnName;
        // successErrBtn.buttonValue = localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== null &&
        //   localStorage.getItem(AppLocalStorageKeys.AUTH_Token) !== '' ? 'Resend Verification' : 'Login To Verify';
        // this.verificationObject.button.push(successErrBtn);
        if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
          this.userDetailMessage.email = '';
          this.userDetailMessage.action = this.apiUrl.VERIFIED_ALREADY;
          this.userDetailService.onUserDetailChange(this.userDetailMessage);
        }

        successErrBtn.buttonType = VerificationButtonTypes.Success;
        successErrBtn.buttonName = this.loginBtnName;
        successErrBtn.buttonValue = 'verification.gotoLogin';
        this.verificationObject.button.push(successErrBtn);
      }
    } else {
      this.verificationObject.errorId = '3';
      this.verificationObject.errorType = 'Verified';
      this.verificationObject.errorTitle = 'Verification';
      this.verificationObject.icon = '';
      this.verificationObject.iconMessage = '';
      const messageContent = new MessageContent();
      messageContent.messageContent = this.verifyContentMessage;
      delete this.verificationObject.messages;
      this.verificationObject.messages = new Array<MessageContent>();
      this.verificationObject.messages.push(messageContent);
      delete this.verificationObject.button;
      this.verificationObject.button = new Array<SuccesErrorButton>();
      let successErrBtn = new SuccesErrorButton();
      successErrBtn.buttonType = VerificationButtonTypes.Change;
      successErrBtn.buttonName = this.changeEmailBtnName;
      successErrBtn.buttonValue = 'verification.changeemail';
      this.verificationObject.button.push(successErrBtn);

      successErrBtn = new SuccesErrorButton();
      successErrBtn.buttonType = VerificationButtonTypes.Retry;
      successErrBtn.buttonName = this.resendEmailBtnName;
      successErrBtn.buttonValue = 'verification.resendemail';
      this.verificationObject.button.push(successErrBtn);
    }
  }

  onVerificationCallback(obj: any): void {
    if (obj.name === this.changeAndResendEmailBtnName) {
      // this.verifyContentMessage = "Your request is processing";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = true;
      this.changeAndResendEmail();

    } else if (obj.name === this.resendEmailBtnName) {
      // this.verifyContentMessage = "Your request is processing";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = true;
      this.resendEmail();
    } else if (obj.name === this.loginToVerifyBtnName || obj.name === this.loginBtnName) {
      this.isChangeEmailHidden = true;
      this.router.navigate([this.webUrl.LOGIN]);
    } else if (obj.name === this.goToSubscriptionBtnName) {
      this.isChangeEmailHidden = true;
      this.router.navigate([this.webUrl.USER_PROFILE_SELECTION]);
    } else if (obj.name === this.resendVerificationBtnName) {
      this.isChangeEmailHidden = true;
      this.resendEmail();
      // this.router.navigate(['auth/accountverify']);
    } else if (obj.name === this.changeEmailBtnName) {
      // this.verifyContentMessage = "";
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      this.isChangeEmailHidden = false;
    } else {
      this.isChangeEmailHidden = true;
    }
  }

  resendEmail(): void {
    this.isChangeEmailHidden = true;
    this.loading = true;
    this.authBusiness.resendEmail(true).subscribe(serviceRes => {
      this.loading = false;
      const response = serviceRes as Response;
      if (response.ok) {
        this.onResendEmailSuccess();
      } else {
        const result = response.json();
        if (!ValidationService.isNullOrEmpty(result[0]) &&
          !ValidationService.isNullOrEmpty(result[0].errors[0]) && !ValidationService.isNullOrEmpty(result[0].errors[0].code)) {
          if (result[0].errors[0].code === 1003) {
            document.getElementById('btnLogout').click();
          } else {
            this.onResendEmailFailure('');
          }
        } else {
          this.onResendEmailSuccess();
        }
      }
    },
      (error) => {
        this.onResendEmailFailure(error);
      });
  }

  onResendEmailSuccess(): void {
    this.getVerifyContentMessage(this.resendVerificationAction);
    if (this.verificationObject.errorId !== '3') {
      this.setVerificationUITemplate(false, false);
    } else {
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    }
  }

  onResendEmailFailure(error: any): void {
    this.verifyContentMessage = 'verification.failedResend';
    if (this.verificationObject.errorId !== '3') {
      this.setVerificationUITemplate(false, false);
    } else {
      this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    }

  }

  changeAndResendEmail() {
    this.loading = true;
    this.verifyContentMessage = '';
    this.authBusiness.isEmailRegisterd(this.changeEmail).subscribe((res: any) => {
      this.loading = false;
      let isEmailExists = false;
      if (res.isavialble === false) {
        isEmailExists = true;
      } else {
        isEmailExists = false;
      }
      this.verifyContentMessage = '';
      if (!isEmailExists) {
        this.isChangeEmailHidden = true;
        this.loading = true;
        this.authBusiness.changeAndResendEmail(this.changeEmail).subscribe(result => {
          this.loading = false;
          if (!ValidationService.isNullOrEmpty(result) && !ValidationService.isNullOrEmpty(result.email)) {
            this.email = this.changeEmail;
            this.onChangeAndResendEmailSuccess();
          } else {
            if (!ValidationService.isNullOrEmpty(result[0]) &&
              !ValidationService.isNullOrEmpty(result[0].errors[0]) && !ValidationService.isNullOrEmpty(result[0].errors[0].code)) {
              if (result[0].errors[0].code === 1003) {
                document.getElementById('btnLogout').click();
              } else {
                this.onChangeAndResendEmailFailure(result[0].errors[0].message);
              }
            } else {
              this.onChangeAndResendEmailFailure('');
            }
          }
        },
          (error) => {
            this.onChangeAndResendEmailFailure(error);
          });
      } else {
        this.verifyContentMessage = this.changeEmail + ' already exists.';
        this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
      }
    });
  }

  onChangeAndResendEmailSuccess(): void {
    this.getVerifyContentMessage(this.changeAndResendVerificationAction);
    localStorage.removeItem(AppLocalStorageKeys.AUTH_Token);
    localStorage.removeItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    localStorage.removeItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    this.verificationObject.showButtonBlock = false;
    this.verificationObject.button = new Array<SuccesErrorButton>();
    const successErrBtn = new SuccesErrorButton();
    successErrBtn.buttonType = VerificationButtonTypes.Success;
    successErrBtn.buttonName = this.loginBtnName;
    successErrBtn.buttonValue = 'verification.gotoLogin';
    this.verificationObject.button.push(successErrBtn);

    this.userDetailMessage.email = '';
    this.userDetailMessage.action = this.apiUrl.CHANGED_MAIL;
    this.userDetailService.onUserDetailChange(this.userDetailMessage);

    this.verificationObject.showButtonBlock = true;
    this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    this.email = '';
    this.loading = false;
  }

  onChangeAndResendEmailFailure(error: any): void {
    this.verifyContentMessage = 'verification.failedChange';
    this.verificationObject.messages[0].messageContent = this.verifyContentMessage;
    this.email = '';
  }

  getVerifyContentMessage(forAction: string): void {
    this.emailId = new EmailMessage();
    this.emailId.email = this.email;
    if (forAction === this.subscriptionSuccessAction) {
      this.verifyContentMessage = this.translate.instant('verification.verificationSubscription', this.userDetailMessage);
    } else if (forAction === this.verificationExpiredAction) {
      this.verifyContentMessage = 'verification.emailExpired';
    } else if (forAction === this.resendVerificationAction) {
      this.verifyContentMessage = this.translate.instant('verification.resendEmail', this.emailId);
    } else if (forAction === this.changeAndResendVerificationAction) {
      this.verifyContentMessage = this.translate.instant('verification.changeresendEmail', this.emailId);
    } else if (forAction === this.verificationPendingAction) {
      this.verifyContentMessage = this.translate.instant('verification.verificationPending', this.emailId);
    } else {
      this.verifyContentMessage = this.translate.instant('verification.resendVerification');
    }
  }
}
