import { SignupFormComponent } from './components/signup-form/signup-form.component';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { VerificationFormComponent } from './components/verification-form/verification-form.component';
import { AnonymousGuard, AuthGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';

const routes: Routes = [
  {
    path: 'auth', children:
      [
        { path: '', redirectTo: 'login', pathMatch: 'full' },
        { path: 'login', component: LoginComponent, canActivate: [AnonymousGuard] },
        { path: 'signup', component: SignupFormComponent, canActivate: [AnonymousGuard] },
        { path: 'resetpassword/:key', component: ResetPasswordComponent, canActivate: [AnonymousGuard] },
        { path: 'forgetpassword', component: ForgetPasswordComponent, canActivate: [AnonymousGuard] },
        {
          path: 'accountverify', component: VerificationFormComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.VERIFICATION,
            UserAccountStatus.REVERIFICATION,
            UserAccountStatus.REVERIFICATION_MAILCHANGE]
          }
        },
        {
          path: 'accountverify/:key', component: VerificationFormComponent
        },
      ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
