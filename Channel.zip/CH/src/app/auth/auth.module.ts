import { FormGroup, FormControl, Validators, FormsModule } from '@angular/forms';
import { SignupFormComponent } from './components/signup-form/signup-form.component';
import { SharedModule } from './../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthRoutingModule } from './auth-routing.module';
import { ApiUrl } from '@app/config/constant_keys';
import { AuthBusiness } from './business/auth.business';
import { HttpModule } from '@angular/http';
import { Config } from '../config/constant';
import { LoginComponent } from './components/login/login.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ForgetPasswordComponent } from './components/forget-password/forget-password.component';
import { InvalidKeyTokenComponent } from './components/invalid-key-token/invalid-key-token.component';
import { AuthService } from './services/auth.service';
import { VerificationFormComponent } from './components/verification-form/verification-form.component';
import { AccountVideoBannerComponent } from './../core/components/account-video-banner/account-video-banner.component';

export const COMPONENTS = [
  LoginComponent,
  SignupFormComponent,
  ForgetPasswordComponent,
  ResetPasswordComponent,
  VerificationFormComponent,
  InvalidKeyTokenComponent,
  AccountVideoBannerComponent,
];

@NgModule({
  imports: [CommonModule, SharedModule, FormsModule, HttpModule],
  declarations: COMPONENTS
})
export class AuthModule {
  static forRoot() {
    return {
      ngModule: RootAuthModule,
      providers: [AuthBusiness, AuthService, Config] // AuthGuard
    };
  }
}

@NgModule({
  imports: [
    AuthModule,
    AuthRoutingModule
  ],
})
export class RootAuthModule { }
