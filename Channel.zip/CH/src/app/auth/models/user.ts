export interface Authenticate {
  name?: string;
  username: string;
  password: string;
}

export interface User {
  id: number;
  email: string;
  provider: string;
  uid: string;
  name: string;
  nickname: string | null;
  image: string | null;
  role: string;
}


export interface Login {
  email: string;
  password: string;
}

export interface Token {
  secretKey: string;
  clientKey: string;
}

export interface ResetPassword {
  password: string;
  confirm_password: string;
}

export interface Register {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmpassword: string;
  country: number;
}
