import { environment } from '../../environments/environment';
import { WebUrl } from '@app/config/constant_keys';
export class Config {
  // validation patterns
  alphaNumericwithoutSpace;
  alphaNumericPattern = '[a-zA-Z0-9]+';
  percentagePattern = '^0*(?:[1-9][0-9]?|100)$';
  floatingNumberPattern = /^(0|[1-9]\d*)(\.\d+)?$/;
  // passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,25}$';
  passwordAlphaNumericPattern = '^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,25}$';
  mobnumPattern = '^[0-9_.,!()+=`,"@$#%*-]*$';
  webPattern = '^[a-z0-9._%+-]+.[a-z0-9.-]+\.[a-z]{2,4}$';
  numberPattern = '^[0-9]+$';
  excludeZeroPattern = '^(?!0+$)[0-9]{0,10}$';
  yearPattern = '^[1-9][0-9]*$';
  urlPattern = '^(https?://)?(www\\.)?([-a-z0-9]{1,63}\\.)*?[a-z0-9][-a-z0-9]{0,61}[a-z0-9]\\.[a-z]{2,6}(/[-\\w@\\+\\.~#\\?&/=%]*)?$';
  // tslint:disable-next-line:max-line-length
  urlPatternWithHttp = '^(http://|https://)?(www\\.)?([-a-z0-9]{1,63}\\.)*?[a-z0-9][-a-z0-9]{0,61}[a-z0-9]\\.[a-z]{2,6}(/[-\\w@\\+\\.~#\\?&/=%]*)?$';
  flag_percent = {
    'legalName': [2, 1], 'certificateNo': [2, 1],
    'profileAddress': [2, 1], 'profileMobile': [1, 1]
    , 'profileemail': [1, 1], 'profilelinkedURL': [1, 1],
    'profileGoogleURL': [1, 1], 'profileInstaURL': [1, 1],
    'profileJobtitle': [2, 1], 'profileFirstName': [1, 1],
    'profileAuthmob': [2, 1], 'profileLastname': [1, 1],
    'fileprofileLogo': [3, 1], 'accCerficateId': [2, 1], 'profileTaxCertno': [3, 1]
    , 'profileIssuedBy': [2, 1], 'fileprofileFavicon': [2, 1], 'fileprofileImg': [2, 1]
    , 'profileWebsiteURL': [2, 1], 'establishYear': [2, 1],
    'aboutCompany': [2, 1]
  };

  // tslint:disable-next-line:max-line-length
  // emailPattern = /^(?!\.)((?!.*\.{2})[a-zA-Z0-9\u0080-\u00FF\u0100-\u017F\u0180-\u024F\u0250-\u02AF\u0300-\u036F\u0370-\u03FF\u0400-\u04FF\u0500-\u052F\u0530-\u058F\u0590-\u05FF\u0600-\u06FF\u0700-\u074F\u0750-\u077F\u0780-\u07BF\u07C0-\u07FF\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F\u0D80-\u0DFF\u0E00-\u0E7F\u0E80-\u0EFF\u0F00-\u0FFF\u1000-\u109F\u10A0-\u10FF\u1100-\u11FF\u1200-\u137F\u1380-\u139F\u13A0-\u13FF\u1400-\u167F\u1680-\u169F\u16A0-\u16FF\u1700-\u171F\u1720-\u173F\u1740-\u175F\u1760-\u177F\u1780-\u17FF\u1800-\u18AF\u1900-\u194F\u1950-\u197F\u1980-\u19DF\u19E0-\u19FF\u1A00-\u1A1F\u1B00-\u1B7F\u1D00-\u1D7F\u1D80-\u1DBF\u1DC0-\u1DFF\u1E00-\u1EFF\u1F00-\u1FFFu20D0-\u20FF\u2100-\u214F\u2C00-\u2C5F\u2C60-\u2C7F\u2C80-\u2CFF\u2D00-\u2D2F\u2D30-\u2D7F\u2D80-\u2DDF\u2F00-\u2FDF\u2FF0-\u2FFF\u3040-\u309F\u30A0-\u30FF\u3100-\u312F\u3130-\u318F\u3190-\u319F\u31C0-\u31EF\u31F0-\u31FF\u3200-\u32FF\u3300-\u33FF\u3400-\u4DBF\u4DC0-\u4DFF\u4E00-\u9FFF\uA000-\uA48F\uA490-\uA4CF\uA700-\uA71F\uA800-\uA82F\uA840-\uA87F\uAC00-\uD7AF\uF900-\uFAFF\.!#$%&'*+-/=?^_`{|}~\-\d]+)@(?!\.)([a-zA-Z0-9\u0080-\u00FF\u0100-\u017F\u0180-\u024F\u0250-\u02AF\u0300-\u036F\u0370-\u03FF\u0400-\u04FF\u0500-\u052F\u0530-\u058F\u0590-\u05FF\u0600-\u06FF\u0700-\u074F\u0750-\u077F\u0780-\u07BF\u07C0-\u07FF\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F\u0D80-\u0DFF\u0E00-\u0E7F\u0E80-\u0EFF\u0F00-\u0FFF\u1000-\u109F\u10A0-\u10FF\u1100-\u11FF\u1200-\u137F\u1380-\u139F\u13A0-\u13FF\u1400-\u167F\u1680-\u169F\u16A0-\u16FF\u1700-\u171F\u1720-\u173F\u1740-\u175F\u1760-\u177F\u1780-\u17FF\u1800-\u18AF\u1900-\u194F\u1950-\u197F\u1980-\u19DF\u19E0-\u19FF\u1A00-\u1A1F\u1B00-\u1B7F\u1D00-\u1D7F\u1D80-\u1DBF\u1DC0-\u1DFF\u1E00-\u1EFF\u1F00-\u1FFF\u20D0-\u20FF\u2100-\u214F\u2C00-\u2C5F\u2C60-\u2C7F\u2C80-\u2CFF\u2D00-\u2D2F\u2D30-\u2D7F\u2D80-\u2DDF\u2F00-\u2FDF\u2FF0-\u2FFF\u3040-\u309F\u30A0-\u30FF\u3100-\u312F\u3130-\u318F\u3190-\u319F\u31C0-\u31EF\u31F0-\u31FF\u3200-\u32FF\u3300-\u33FF\u3400-\u4DBF\u4DC0-\u4DFF\u4E00-\u9FFF\uA000-\uA48F\uA490-\uA4CF\uA700-\uA71F\uA800-\uA82F\uA840-\uA87F\uAC00-\uD7AF\uF900-\uFAFF\-\.\d]+)((\.([a-zA-Z\u0080-\u00FF\u0100-\u017F\u0180-\u024F\u0250-\u02AF\u0300-\u036F\u0370-\u03FF\u0400-\u04FF\u0500-\u052F\u0530-\u058F\u0590-\u05FF\u0600-\u06FF\u0700-\u074F\u0750-\u077F\u0780-\u07BF\u07C0-\u07FF\u0900-\u097F\u0980-\u09FF\u0A00-\u0A7F\u0A80-\u0AFF\u0B00-\u0B7F\u0B80-\u0BFF\u0C00-\u0C7F\u0C80-\u0CFF\u0D00-\u0D7F\u0D80-\u0DFF\u0E00-\u0E7F\u0E80-\u0EFF\u0F00-\u0FFF\u1000-\u109F\u10A0-\u10FF\u1100-\u11FF\u1200-\u137F\u1380-\u139F\u13A0-\u13FF\u1400-\u167F\u1680-\u169F\u16A0-\u16FF\u1700-\u171F\u1720-\u173F\u1740-\u175F\u1760-\u177F\u1780-\u17FF\u1800-\u18AF\u1900-\u194F\u1950-\u197F\u1980-\u19DF\u19E0-\u19FF\u1A00-\u1A1F\u1B00-\u1B7F\u1D00-\u1D7F\u1D80-\u1DBF\u1DC0-\u1DFF\u1E00-\u1EFF\u1F00-\u1FFF\u20D0-\u20FF\u2100-\u214F\u2C00-\u2C5F\u2C60-\u2C7F\u2C80-\u2CFF\u2D00-\u2D2F\u2D30-\u2D7F\u2D80-\u2DDF\u2F00-\u2FDF\u2FF0-\u2FFF\u3040-\u309F\u30A0-\u30FF\u3100-\u312F\u3130-\u318F\u3190-\u319F\u31C0-\u31EF\u31F0-\u31FF\u3200-\u32FF\u3300-\u33FF\u3400-\u4DBF\u4DC0-\u4DFF\u4E00-\u9FFF\uA000-\uA48F\uA490-\uA4CF\uA700-\uA71F\uA800-\uA82F\uA840-\uA87F\uAC00-\uD7AF\uF900-\uFAFF]){2,63})+)$/i;
  emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  phoneCodeWithPlus = '^[+]?[()0-9()]+$';
  phoneCodeWithOutPlus = '^[()0-9()]+$';
}

export const RelationStatus = {
  SUGGESTION: 1,
  PROSPECT: 2,
  MYCHANNEL_APPROVALS: 3,
  MYCHANNEL: 4,
  MYPROSPECT_APPROVALS: 7,
  TOP_SEARCH: 5,
  MORE_MATCHING: 6,
  WISH_LIST: 10,
  MY_PRODUCTS: 8,
  PRODUCTS_SUGGESTION: 9,
  TOP_SEARCH_PRODUCT: 11
};

export const RedirectChannelList = {
  '1': WebUrl.CHANNEL_SUGGESTION,
  '2': WebUrl.CHANNEL_MYPROSPECTS,
  '3': WebUrl.MYCHANNEL_APPROVALS,
  '4': WebUrl.CHANNEL_MYCHANNELS,
  '6': WebUrl.MORE_MATCHING_CHANNEL,
  '7': WebUrl.MYPROSPECTS_APPROVALS,
  '5': WebUrl.CHANNEL_SEARCHRESULT,
  '8': WebUrl.MY_PRODUCT_VIEW,
  '9': WebUrl.PRODUCT_SUGGESTION_VIEW,
  '10': WebUrl.WISHLIST_PRODUCT_VIEW,
  '11': WebUrl.PRODUCT_SEARCHRESULT_VIEW
};

export const ChannelStatusTypeName = {
  SUGGESTION: 'suggestions',
  PROSPECT: 'prospect',
  CHANNEL: 'Channel',
  CHANNEL_APPROVAL: 'Channel Approvels',
  PROSPECT_APPROVAL: 'Prospect Approvels'
};

export declare abstract class MenuItem {
  /**
   * Item Title
   * @type {string}
   */
  title: string;
  /**
   * Item relative link (for routerLink)
   * @type {string}
   */
  link?: string;
  /**
   * Item URL (absolute)
   * @type {string}
   */
  url?: string;
  /**
   * Icon class name
   * @type {string}
   */
  icon?: string;
  /**
   * Expanded by defaul
   * @type {boolean}
   */
  expanded?: boolean;
  /**
   * Children items
   * @type {List<MenuItem>}
   */
  children?: MenuItem[];
  /**
   * Children items height
   * @type {number}
   */
  subMenuHeight?: number;
  /**
   * HTML Link target
   * @type {string}
   */
  target?: string;
  /**
   * Hidden Item
   * @type {boolean}
   */
  hidden?: boolean;
  /**
   * Item is selected when partly or fully equal to the current url
   * @type {string}
   */
  pathMatch?: string;
  /**
   * Where this is a home item
   * @type {boolean}
   */
  home?: boolean;
  /**
   * Whether the item is just a group (non-clickable)
   * @type {boolean}
   */
  group?: boolean;
  parent?: MenuItem;
  selected?: boolean;
  data?: any;
  fragment?: string;
  queryparam?: any;
  vendor?: boolean;
  distributor?: boolean;
  class?: string;
  retailer?: string;
  isAuthorize: boolean;
  authorizeVal?: number[];
  clearStorage?: number;
}


export enum AccessPermissionEnum {
  PROFILE = 1,
  COMPANY_PROFILE = 2,
  COMPANY_PROFILE_UPDATE = 3,
  CONTACT_PROFILE = 4,
  CONTACT_PROFILE_UPDATE = 5,
  PROFILE_REQUEST_PASSWORD = 6,
  PROFILE_REQUEST_PASSWORD_UPDATE = 7,
  PROFILE_TRADE_INFORMATION = 8,
  PROFILE_TRADE_INFORMATION_UPDATE = 9,
  PROFILE_TRADE_LOCATION = 10,
  PROFILE_TRADE_LOCATION_UPDATE = 11,
  PROFILE_USER_MANAGEMENT = 12,
  PROFILE_USER_MANAGEMENT_UPDATE = 13,
  PROFILE_COMPANY_SETTINGS = 14,
  PROFILE_COMPANY_SETTINGS_UPDATE = 15,

  MY_CHANNELS = 16,
  MY_CHANNELS_CHANNEL_APPROVAL = 17,
  MY_CHANNELS_VENDOR = 18,
  MY_CHANNELS_RETAILER = 19,
  MY_CHANNELS_DISTRIBUTOR = 20,

  MY_PROSPECTS = 21,
  MY_PROSPRCTS_APPROVAL = 51,
  MY_PROSPECTS_VENDOR = 22,
  MY_PROSPECTS_RETAILER = 23,
  MY_PROSPECTS_DISTRIBUTOR = 24,

  MY_SUGGESSIONS = 25,
  MY_SUGGESSIONS_VENDOR = 26,
  MY_SUGGESSIONS_RETAILER = 27,
  MY_SUGGESSIONS_DISTRIBUTOR = 28,

  MY_CONTACTS = 29,
  MY_CONTACTS_VENDOR = 30,
  MY_CONTACTS_RETAILER = 31,
  MY_CONTACTS_DISTRIBUTOR = 32,

  SAMPLE_REQUESTS = 33,
  SAMPLE_REQUESTS_PENDING_APPROVAL = 34,
  SAMPLE_REQUESTS_APPROVED = 35,
  SAMPLE_REQUESTS_PACKED = 36,
  SAMPLE_REQUESTS_SHIPPED = 37,
  SAMPLE_REQUESTS_DELIVERED = 38,
  SAMPLE_REQUESTS_EVALUATION = 39,
  SAMPLE_REQUESTS_CANCELLED = 40,
  SAMPLE_REQUESTS_REFUNDS = 41,

  PRODUCTS = 42,
  PRODUCTS_ADD_TO_CART = 43,
  PRODUCTS_WISHLIST = 44,

  SAMPLE_ORDERS = 45,
  SAMPLE_ORDERS_PENDING_APPROVAL = 46,
  SAMPLE_ORDERS_PENDING_CONFIRMATION = 47,
  SAMPLE_ORDERS_PENDING_EVALUATIONS = 48,
  SAMPLE_ORDERS_COMPLETE_SAMPLE_ORDER_MANAGMENT = 49,

  MY_PRODUCTS = 50
}

export const SIDEMENU_ITEMS: MenuItem[] = [
  {
    title: 'Profile',
    icon: 'fa-user',
    link: '/profile',
    home: true,
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.PROFILE]
  },
  {
    title: 'Suggestion',
    icon: 'fa-lightbulb-o',
    link: WebUrl.CHANNEL_SUGGESTION,
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.MY_SUGGESSIONS],
    children: [
      {
        title: 'Members',
        link: WebUrl.CHANNEL_SUGGESTION,
        class: 'level2',
        isAuthorize: true,
        authorizeVal: [AccessPermissionEnum.MY_SUGGESSIONS_VENDOR,
        AccessPermissionEnum.MY_SUGGESSIONS_RETAILER,
        AccessPermissionEnum.MY_SUGGESSIONS_DISTRIBUTOR],
        clearStorage: RelationStatus.SUGGESTION
      },
      {
        title: 'Products',
        link: WebUrl.PRODUCT_SUGGESTION,
        distributor: true,
        isAuthorize: false,
        class: 'level2',
        clearStorage: RelationStatus.PRODUCTS_SUGGESTION
      }
    ],
  },
  {
    title: 'My Network',
    icon: 'fa-wifi',
    link: WebUrl.CHANNEL_MYPROSPECTS,
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.MY_PROSPECTS],
    children: [{
      title: 'Pending',
      link: WebUrl.MYPROSPECTS_APPROVALS,
      class: 'level2',
      isAuthorize: true,
      authorizeVal: [AccessPermissionEnum.MY_PROSPRCTS_APPROVAL],
      clearStorage: RelationStatus.MYPROSPECT_APPROVALS
    }, {
      title: 'Confirmed',
      link: WebUrl.CHANNEL_MYPROSPECTS,
      class: 'level2',
      isAuthorize: true,
      authorizeVal: [AccessPermissionEnum.MY_PROSPECTS_VENDOR,
        , AccessPermissionEnum.MY_PROSPECTS_RETAILER, AccessPermissionEnum.MY_PROSPECTS_DISTRIBUTOR],
      clearStorage: RelationStatus.PROSPECT
    }]
  },
  // {
  //   title: 'My Channels',
  //   icon: 'fa-star',
  //   link: WebUrl.CHANNEL_MYCHANNELS,
  //   isAuthorize: true,
  //   authorizeVal: [AccessPermissionEnum.MY_CHANNELS],
  //   children: [{
  //     title: 'Members',
  //     link: WebUrl.CHANNEL_MYCHANNELS,
  //     class: 'level2',
  //     isAuthorize: true,
  //     authorizeVal: [AccessPermissionEnum.MY_CHANNELS_VENDOR,
  //       , AccessPermissionEnum.MY_CHANNELS_RETAILER, AccessPermissionEnum.MY_CHANNELS_DISTRIBUTOR],
  //     clearStorage: RelationStatus.MYCHANNEL
  //   },
  //   {
  //     title: 'Approvals',
  //     link: WebUrl.MYCHANNEL_APPROVALS,
  //     class: 'level2',
  //     isAuthorize: true,
  //     authorizeVal: [AccessPermissionEnum.MY_CHANNELS_CHANNEL_APPROVAL],
  //     clearStorage: RelationStatus.MYCHANNEL_APPROVALS
  //   },
  //   {
  //     title: 'Invitations',
  //     link: WebUrl.MY_INVITATIONS,
  //     class: 'level2',
  //     isAuthorize: false,
  //   }]
  // },
  // {
  //   title: 'Spot Deal',
  //   icon: 'fa-tags',
  //   link: 'coming-soon',
  //   queryparam: { 'connectionid': 1 },
  //   // link: '/channel/Recommendations',
  //   distributor: true,
  //   retailer: 'hide',
  //   isAuthorize: false,
  //   class: 'coming-soon',
  // },
  {
    title: 'My Products',
    icon: 'fa-product-hunt',
    link: WebUrl.MY_PRODUCTLIST,
    vendor: true,
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.MY_PRODUCTS],
    clearStorage: RelationStatus.MY_PRODUCTS
  },
  {
    title: 'My Invitations',
    icon: 'fa-address-book-o',
    link: WebUrl.MY_INVITATIONS,
    isAuthorize: false,
  },
  {
    title: 'Sample Order',
    icon: 'fa-first-order',
    link: WebUrl.ORDER_SELLER_REQUEST,
    distributor: false,
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.SAMPLE_REQUESTS],
    // children: [{
    //   title: 'Conference',
    //   link: 'coming-soon',
    //   queryparam: { 'connectionid': 3 },
    //   // link: '/channel/Support/Conference',
    //   class: 'coming-soon level2',
    //   isAuthorize: false,
    // },
    // {
    //   title: 'Sample Request',
    //   link: WebUrl.ORDER_SELLER_REQUEST,
    //   class: 'level2',
    //   retailer: 'hide',
    //   isAuthorize: false,
    // }
    // ]
  },
  {
    title: 'Sample Orders',
    icon: 'fa-first-order',
    link: '/channel/orders',
    distributor: true,
    retailer: 'hide',
    isAuthorize: true,
    authorizeVal: [AccessPermissionEnum.SAMPLE_ORDERS],
    children: [{
      title: 'Your orders',
      link: WebUrl.ORDER_BUYER_REQUEST,
      class: 'level2',
      isAuthorize: false,
    },
    {
      title: 'Received Orders',
      link: WebUrl.ORDER_SELLER_REQUEST,
      class: 'level2',
      isAuthorize: false,
    }
    ]
  },
  {
    title: 'Help / Report',
    icon: 'fa-info-circle',
    isAuthorize: false,
    children: [
      {
        title: 'Tutorials',
        class: 'level2',
        link: '/help/tutorials',
        isAuthorize: false,
      },
      {
        title: 'Support',
        link: '/help/support',
        class: 'level2',
        isAuthorize: false,
      },
      {
        title: 'Complaint',
        link: '/help/complaint',
        class: 'level2',
        isAuthorize: false,
      },
      {
        title: 'IPR',
        class: 'level2',
        link: '/help/ipr',
        isAuthorize: false,
      }
    ]
  }];

export const SIDEMENU: any = [
  { 'id': '1', 'menuname': 'Profile', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '2', 'menuname': 'Suggestion', 'icon': 'glyphicon  glyphicon-user' },
  { 'id': '3', 'menuname': 'My Prospects', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '4', 'menuname': 'My Channels', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '5', 'menuname': 'Spot Deal', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '6', 'menuname': 'My Products', 'icon': 'glyphicon glyphicon-home' },
  { 'id': '7', 'menuname': 'My Contacts', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '8', 'menuname': 'My Requests', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '9', 'menuname': 'Sample Order', 'icon': 'glyphicon glyphicon-user' },
  { 'id': '10', 'menuname': 'Help / Report', 'icon': 'glyphicon glyphicon-exclamation-sign' }
];

export const menuList: any = [
  // { id: '1', menuName: 'home.menuName', menuLink: '', icon: 'fa fa-home' },
  // { id: '4', menuName: 'news.menuName', menuLink: 'newslist', icon: 'fa fa-newspaper-o' },
  { id: '5', menuName: 'About.menuName', menuLink: 'aboutus' },
  { id: '6', menuName: 'vendor.menuName', menuLink: 'vendor' },
  { id: '7', menuName: 'Distributor.menuName', menuLink: 'distributor' },
  { id: '8', menuName: 'Retailer.menuName', menuLink: 'retailer' },
  { id: '8', menuName: 'salesrep.menuName', menuLink: 'business-developer' },
  { id: '2', menuName: 'Pricing.menuName', menuLink: 'user_profile_selection', class: 'notcmsUseronly' },
  { id: '3', menuName: 'myChannelHub.menuName', menuLink: 'dashboard', class: 'cmsUseronly', icon: 'fa fa-group' }
  // { id: '4', menuName: 'news.menuName', menuLink: 'newslist', icon: 'fa fa-newspaper-o' },
];

export const RoleMenu: any = [
  { id: 1, menuName: 'Home', icon: 'fa fa-home', count: '', link: '' },
  { id: 2, menuName: 'WishList', icon: 'fa fa-heart', count: '', link: '/wishlist', buyer: true, type: 'WISHLIST' },
  { id: 3, menuName: 'My Cart', icon: 'fa fa-shopping-cart', count: '', link: '/cart', buyer: true, type: 'CART' },
  // { id: 4, menuName: 'Message', icon: 'fa fa-envelope', count: '3', class: 'coming-soon', link: '/coming-soon' /*link: '/messages'*/ },
  { id: 5, menuName: 'Notification', icon: 'fa fa-bell', count: '', link: 'notification', type: 'NOTIFICATION' }
];

export const userSelctionList: any = [
  {
    id: 2,
    UserName: 'userProfileSelection.vendor.menuName',
    className: 'vendor',
    CmsPageUrl: '/vendor',
    value: 'Vendor',
    message: [
      { msg: 'userProfileSelection.vendor.msg1' },
      { msg: 'userProfileSelection.vendor.msg2' },
      { msg: 'userProfileSelection.vendor.msg3' },
      { msg: 'userProfileSelection.vendor.msg4' }
    ]
  },
  {
    id: 3,
    UserName: 'userProfileSelection.Distributor.menuName',
    className: 'distributor',
    CmsPageUrl: '/distributor',
    value: 'Distributor',
    message: [
      { msg: 'userProfileSelection.Distributor.msg1' },
      { msg: 'userProfileSelection.Distributor.msg2' },
      { msg: 'userProfileSelection.Distributor.msg3' },
      { msg: 'userProfileSelection.Distributor.msg4' }
    ]
  },
  {
    id: 4,
    UserName: 'userProfileSelection.Retailer.menuName',
    className: 'retailer',
    CmsPageUrl: '/retailer',
    value: 'Retailer',
    message: [
      { msg: 'userProfileSelection.Retailer.msg1' },
      { msg: 'userProfileSelection.Retailer.msg2' },
      { msg: 'userProfileSelection.Retailer.msg3' },
      { msg: 'userProfileSelection.Retailer.msg4' }
    ]
  },
  {
    id: 5,
    UserName: 'userProfileSelection.salesrep.menuName',
    className: 'sales-rep',
    CmsPageUrl: '/business-developer',
    value: 'Business Developer',
    message: [
      { msg: 'userProfileSelection.salesrep.msg1' },
      { msg: 'userProfileSelection.salesrep.msg2' },
      { msg: 'userProfileSelection.salesrep.msg3' },
      { msg: 'userProfileSelection.salesrep.msg4' }
    ]
  },
];

export class MessageContent {
  messageContent: string;
}

export class SuccesErrorButton {
  buttonType: string;
  buttonName: string;
  buttonValue: string;
  buttonLink: string;
}

export class SuccesErrorMessage {
  constructor() {
    this.showButtonBlock = true;
  }

  errorId: string;
  errorType: string;
  errorTitle: string;
  icon: string;
  iconMessage: string;
  messages: Array<MessageContent>;
  button: Array<SuccesErrorButton>;
  showButtonBlock: boolean;
}

export class UserDetailMessage {
  email: string;
  action: string;
  tag: string;
  userId: number;
}

export class EmailMessage {
  email: string;
}
export class SubscriptionPlan {
  planName: string;
  period: string;
  email?: string;
}


export enum UserAccountStatus {
  VERIFICATION = 1,
  REVERIFICATION = 2,
  REVERIFICATION_MAILCHANGE = 3,
  SUBSCRIPTION = 4,
  PAYMENT_PENDING = 5,
  PAYMENT_FAILURE = 6,
  ACCOUNTSETUP = 7,
  ACCOUNTSETUP_COMPANYPROFILE = 8,
  ACCOUNTSETUP_TRADEINFORMATION = 9,
  ACCOUNTSETUP_TRADELOCATION = 10,
  CLAIM = 11,
  CLAIM_APPROVED = 12,
  CLAIM_REJECTED = 13,
  CHANNEL_APPROVAL = 14,
  CHANNEL_APPROVED = 15,
  UPGRADE = 'UPGRADE',
}

export const channelStatusURLRedirect: any = [
  { id: UserAccountStatus.VERIFICATION, url: WebUrl.ACCOUNTVERIFY },
  { id: UserAccountStatus.REVERIFICATION, url: WebUrl.ACCOUNTVERIFY },
  { id: UserAccountStatus.SUBSCRIPTION, url: WebUrl.USER_PROFILE_SELECTION },
  { id: UserAccountStatus.PAYMENT_PENDING, url: WebUrl.USER_SUBSCRIPTION_PLAN },
  { id: UserAccountStatus.PAYMENT_FAILURE, url: WebUrl.USER_SUBSCRIPTION_PLAN },
  { id: UserAccountStatus.ACCOUNTSETUP, url: '/account/(accountroute:profile)' },
  { id: UserAccountStatus.ACCOUNTSETUP_TRADEINFORMATION, url: '/account/(accountroute:information)' },
  { id: UserAccountStatus.ACCOUNTSETUP_TRADELOCATION, url: '/account/(accountroute:location)' },
  { id: UserAccountStatus.CHANNEL_APPROVAL, url: WebUrl.ACCOUNT_VERIFY_URL },
  { id: UserAccountStatus.CHANNEL_APPROVED, url: WebUrl.DASHBOARD }
];

export class OrderDetails {
  id: string;
  status: string;
  paymentMethod?: number;
}

export const ChannelType = {
  VENDOR: 'VENDOR',
  DISTRIBUTOR: 'DISTRIBUTOR',
  RETAILER: 'RETAILER',
  SALESREP: 'SALESREP',
  SIGNUP: 'SIGNUP',
  GUEST: 'GUEST',
  HUB: 'HUB'
};

export const ChannelTypeIdEnum = {
  HUB: 1,
  VENDOR: 2,
  DISTRIBUTOR: 3,
  RETAILER: 4,
  SALESREP: 5,
  SIGNUP: 6,
};

export const ProductQuality = {
  Entry: 'Entry',
  Mid: 'Mid',
  High: 'High'
};

export const LocationType = {
  SELLING: 'SELLING',
  TARGET: 'TARGET',
  SELLING_AND_TARGET: 'SELLING_AND_TARGET',
  RETAILER: 'RETAIL'
};

export const SocialMedia = {
  LINKED_IN: 'Linkedin',
  GOOGLE_PLUS: 'Googleplus',
  INSTAGRAM: 'Instagram'
};

export enum ProductCategoryTypeEnum {
  PRODUCT_CATEGORY = 1,
  INTERESTED_PRODUCT_CATEGORY = 2
}

export const Session = {
  TIMEOUT: 10,
  IDLE: 28800, // 8hrs
  PING: 1000,
  APPTOKEN_TIMEOUT_SEC: 43200 // 12 Hrs (12*60*60)
};

export enum couponDiscountUnit {
  DISCOUNT_UNIT_AMT = 1,
  DISCOUNT_UNIT_PER = 2
}

export enum AWSUrl {
  MULTILANGUAGE = '/i18n/',
  PRODUCT_CATEGORY = '/masterDownload/List-Categories.pdf',
  PRODUCT_LOCATION = '/masterDownload/List-Countries.pdf',
  PRODUCT_GUIDELINE = '/Latest/Guides/Guideline for product creation.pdf'
}

export const channelHubUrls: any = [
  { VERIFICATION: WebUrl.ACCOUNTVERIFY },
  { CLAIM_CONTACT_INFO: WebUrl.ACCOUNTVERIFY },
  { CLAIM_COMPNAY_SUCCESS: '/user/claim_company_success' },
  { VERIFICATION: WebUrl.ACCOUNTVERIFY },
  { REVERIFICATION: WebUrl.ACCOUNTVERIFY },
  { SUBSCRIPTION: WebUrl.USER_PROFILE_SELECTION },
  { PAYMENT_PENDING: WebUrl.USER_SUBSCRIPTION_PLAN },
  { PAYMENT_FAILURE: WebUrl.USER_SUBSCRIPTION_PLAN },
  { ACCOUNTSETUP: '/account/(accountroute:profile)' },
  { ACCOUNTSETUP_TRADEINFORMATION: '/account/(accountroute:information)' },
  { ACCOUNTSETUP_TRADELOCATION: '/account/(accountroute:location)' },
  { CHANNEL_APPROVAL: '/account/verify' },
  { CHANNEL_APPROVED: '/profile/(profileroute:companyprofile)' }
];

export const UserManagementTab = {
  GENERAL: 'General',
  TRADE_INFORMATION: 'Trade Information',
  TRADE_LOCATION: 'Trade Location',
  PREFERNCE: 'Preference',
};

export const ProductTab = {
  GENERAL: 'General',
  TRADE_DETAILS: 'Trade Details',
  DISTRIBUTION_CHANNEL: 'Distribution Channel',
};

export const ChannelStatus = [
  { STATUS_ID: 1, STATUS_TYPE: 'suggesion', STATUS_DATA: 'Add to Prospect', STATUS_CONTENT: '' },
  { STATUS_ID: 2, STATUS_TYPE: 'prospect', STATUS_DATA: 'Add to channel', STATUS_CONTENT: '' },
  { STATUS_ID: 3, STATUS_TYPE: 'PendingApproval', STATUS_DATA: 'PendingApproval', STATUS_CONTENT: '' },
  { STATUS_ID: 4, STATUS_TYPE: 'Channel', STATUS_DATA: 'Edit Rating', STATUS_CONTENT: '' },
  { STATUS_ID: 5, STATUS_TYPE: 'Dismiss', STATUS_DATA: 'Dismiss Channel', STATUS_CONTENT: '' }
];

export const PopUpTitle = {
  '3': 'popupText.addprospect',
  '2': 'popupText.addsuggestion1',
  '6': 'popupText.rejectcontact',
  '7': 'popupText.addmyprospect',
  '4': 'popupText.approveChannel',
  '10': 'popupText.allContacts',
  '11': 'popupText.contactDetail',
  '12': 'popupText.deleteProduct',
  '13': 'popupText.inactiveProduct',
  '14': 'popupText.activeProduct',
  '15': 'popupText.dismissProduct',
  '16': 'popupText.interestProduct',
  '17': 'popupText.acceptcontact',
  '18': 'popupText.editinterestLevel'
};

export const PopUpSuccessMsg = {
  '2': 'popupText.successmyProspect',
  '3': 'popupText.successaddedChannel',
  '4': 'popupText.channelapprovel',
  '5': 'popupText.channeldismissed',
  '6': 'popupText.contactRejected',
  '7': 'popupText.successprospect',
  '17': 'popupText.contactaccepted',
  '10': 'popupText.allContacts',
  '11': 'popupText.contactDetail',
  '12': 'popupText.productDeleted',
  '13': 'popupText.productdeActive',
  '14': 'popupText.productActive',
  '51': 'popupText.successCart',
  '18': 'popupText.interestlevelsuccess',
  '19': 'popupText.tryagain',
  '20': 'popupText.upgrade'
};

export const ScrollOptions = {
  barBackground: 'rgba(132, 136, 132, 0.8)',
  gridBackground: 'rgba(77, 77, 77, 0.27)',
  barBorderRadius: '10px',
  barWidth: '4',
  gridWidth: '4',
  gridMargin: '1px 0'
};


export enum mailType {
  PROMOTION = 1,
  SUGGESTION = 2,
  COMMUNICATION = 3,
  ACTION = 4
}


export enum ChannelCompanyDetailTitle {
  DISTRIBUTORPROFILE = 'Distributors Profile',
  VENDORSPROFILE = 'Vendors Profile',
  RETAILERSPROFILE = 'Retailers Profile',
  SPECIALIZED = 'Speciality In',
  INTERESTCATEGORY = 'Interested Categories',
  EXISTINGCATEGORY = 'Existing Categories',
  CUSTOMERPROFILES = 'Customer Profiles',
  LISTOFSERVICE = 'List of Services',
  SELLINGCOUNTRY = 'Selling Countries',
  TARGETCOUNTRY = 'Target Countries',
  RETAILERCOUNTRY = 'Retailer Countries',
  VENDORS = 'Vendors',
  RETAILERS = 'Retailers',
  SAMPLEORDERS = 'Sample Orders',
  ANNUALTURNOVER = 'Annual Turn Over',
  NOOFEMPLOYEES = 'No. of employees',
  EVALUATEDSAMPLES = 'Evaluvated Samples',
  BRAND = 'Brand'
}

export enum ActionType {
  ADD = 1,
  EDIT = 2,
  VIEW = 3,
  UPDATE = 4,
  COPYORDUPLICATE = 5,
  DELETE = 6,
  ACTIVE = 7,
  INACTIVE = 8
}

export const S3Buckets = {
  ACCOUNT_S3: 'account-s3',
};

export enum UnitEnum {
  BOX = 1,
  KGS = 2,
  GRAM = 3,
  PACK = 4,
  PCS = 5,
}

export enum TradeLocationTitle {
  LOCATION_KEY_SELLING = 'SELLING',
  LOCATION_TITLE_SELLING = 'Selling',
  LOCATION_KEY_TARGET = 'TARGET',
  LOCATION_TITLE_TARGET = 'Target',
  LOCATION_KEY_RETAIL = 'RETAIL',
  LOCATION_TITLE_RETAIL = 'Retail',
  SAVE_DIALOG_TITLE = 'Trade Location',
  SAVE_DIALOG_TEXT = 'Saved Successfully!',
  // tslint:disable-next-line:max-line-length
  SAVE_DIALOG_TEXT_WITH_SUGGESTION = 'Trade Location updated successfully. If there are any new suggestions, based on the updates, you shall see the  additions to your suggestion list in next 2 - 3 minutes',
  NO_LOCATION_DIALOG_TITLE = 'Trade Location',
  NO_LOCATION_DIALOG_TEXT = 'No location has been selected to save.',
  ZONE_LIMIT_MESSAGE = 'As per your current subscription plan, you are eligible to add location for only [zoneCnt] zone(s).'
}

export const DiscountUnit = {
  AMOUNT: 'Amount',
  PERCENTAGE: 'Percentage'
};

export const UniversalCodeType = {
  HSN: 'HSN',
  EAN: 'EAN',
  UPC: 'UPC'
};

export const ChannelLocationUniqueKeys = {
  SELLING_ZONES: 'SellingZones',
  SELLING_REGIONS: 'SellingRegions',
  SELLING_COUNTRIES: 'SellingCountries',
  TARGET_ZONES: 'TargetZones',
  TARGET_REGIONS: 'TargetRegions',
  TARGET_COUNTRIES: 'TargetCountries'
};

export const TradeLocFrameOption = {
  barBackground: '#08314e',
  barBorderRadius: '0',
  barWidth: '4',
  gridWidth: '4',
  gridMargin: '1px 0'
};

export interface IRedirectUrl {
  RedirectId: number;
  MessageContent?: string[];
  Url: any;
  queryparam?: any;
}

export const RedirectUrlList = <Array<IRedirectUrl>>[
  {
    RedirectId: 1,
    Url: WebUrl.CHANNEL_SUGGESTION
  },
  {
    RedirectId: 2,
    Url: WebUrl.CHANNEL_MYPROSPECTS
  },
  {
    RedirectId: 3,
    Url: WebUrl.MYCHANNEL_APPROVALS
  },
  {
    RedirectId: 4,
    Url: WebUrl.CHANNEL_MYCHANNELS
  },
  {
    RedirectId: 5,
    Url: WebUrl.CHANNEL_SEARCHRESULT
  },
  {
    RedirectId: 6,
    Url: ['/profile', { outlets: { 'profileroute': ['usermanagement'] } }]
  },
  {
    RedirectId: 7,
    Url: ['/profile', { outlets: { 'profileroute': ['setting'] } }]
  },
  {
    RedirectId: 8,
    Url: WebUrl.ORDER_SELLER_REQUEST
  },
  {
    RedirectId: 9,
  },
  {
    RedirectId: 10,
    Url: '/channel/channellist',
    queryparam: { 'connectionid': 1, 'connectionStatusTypeName': 'suggestion' }
  },
  {
    RedirectId: 11,
    Url: WebUrl.ORDER_BUYER_REQUEST
  },
  {
    RedirectId: 12,
    Url: '/product/productview',
    queryparam: { 'connectionid': 1, 'connectionStatusTypeName': 'suggestion' }
  },
  {
    RedirectId: 13,
    Url: WebUrl.MY_INVITATIONS,
  }
];

export const DialogConfirmMessage = {
  delete: 'popupText.deletesampleRequest',
  transfer: 'popupText.selectsampleOrder',
  cancel: 'popupText.cancelSampleOrder',
  mail: 'popupText.printMail',
  approve: 'popupText.confirmpayOrder',
  pack: 'popupText.markorderPacked',
  ship: 'popupText.markshipOrder',
  reject: 'popupText.rejectrefund',
  deliver: 'popupText.markorderDelivered',
  refund: 'popupText.markorderRefunded',
  sendback: 'popupText.sendOrderApproval',
  cancelrefund: 'popupText.cancelRefundOrder',
  retransfer: 'popupText.retransferOrder',
  requestrefund: 'popupText.refundOrder'
};

export enum RequestStatus {
  CONFIRMATION = 1,
  APPROVAL = 2,
  PACKING = 3,
  SHIPPING = 4,
  DELIVERY = 5,
  EVALUATION = 6,
  EVALUATED = 7,
  REFUND = 8,
  REFUNDED = 9,
  REFUNDCANCELED = 10,
  CANCELED = 11,
}

export interface RequestParams {
  statusId: number;
  actionBtn: Object;
  actionIcon: Object;
  title: string;
}

export enum ActionIconSampleRequest {
  SEND = 1,
  PRINT = 3,
  TRACK = 4,
  MAIL = 5,
  VIEW = 2,
  APPROVE = 6,
  REFUND = 7,
  TRANSFER = 8,
  DELETE = 9
}

export const SampleRequestObj = {
  1: {
    status: 'Pending Confirmation',
    statusId: 1,
    actionBtn: [
      { action: 'cancel', value: 'Close', actionId: 2, confirm: '' },
      { action: 'delete', value: 'Cancel', actionId: 9, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      { action: 'send', value: 'Send Proforma', actionId: 1, confirm: 'Do you wish to approve this request?', postAction: 'SEND_PROFORMA' },
      { action: 'transfer', value: 'Transfer', actionId: 8, confirm: DialogConfirmMessage.transfer, postAction: 'TRANSFER' },
      { action: 'retransfer', value: 'Retransfer', actionId: 1, confirm: DialogConfirmMessage.retransfer, postAction: 'RETRANSFER' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-arrows-h', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      { action: 'delete', value: 'Cancel', icon: 'fa-eye', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      {
        action: 'send', value: 'Send Proforma', icon: 'fa-check-square', actionId: 1, confirm: 'Do you wish to approve this request?',
        postAction: 'SEND_PROFORMA'
      },
      {
        action: 'transfer', value: 'Transfer', icon: 'fa-times-circle-o', actionId: 1,
        confirm: DialogConfirmMessage.transfer, postAction: 'TRANSFER'
      },
      {
        action: 'retransfer', value: 'Retransfer', icon: 'fa-times-circle-o', actionId: 1,
        confirm: DialogConfirmMessage.retransfer, postAction: 'RETRANSFER'
      }]
  },
  2: {
    status: 'Pending Approval',
    statusId: 2,
    actionBtn: [
      { action: 'cancel', value: 'Close', actionId: 2, confirm: '' },
      { action: 'delete', value: 'Cancel', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        action: 'delete', value: 'Cancel', icon: 'fa-times-circle-o', actionId: 1, confirm: DialogConfirmMessage.cancel,
        postAction: 'CANCEL'
      }]
  },
  3: {
    status: 'Pending Packing',
    statusId: 3,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'delete', value: 'Cancel', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      { action: 'print', value: 'Print Packing Checklist', confirm: '', postAction: '' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' },
      { action: 'pack', value: 'Mark as Packed', confirm: DialogConfirmMessage.pack, postAction: 'MARK_AS_PACKED' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        action: 'print', value: 'Print Packing Checklist', icon: 'fa-dropbox', actionId: ActionIconSampleRequest.PRINT,
        confirm: '', postAction: ''
      },
      {
        action: 'pack', icon: 'fa-check-square', value: 'Mark as Packed',
        actionId: 1, confirm: DialogConfirmMessage.pack, postAction: 'MARK_AS_PACKED'
      }]
  },
  4: {
    status: 'Pending Shipping',
    statusId: 4,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'print', value: 'Print Shipping label', confirm: '', postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' },
      { action: 'ship', value: 'Mark as Shipped', confirm: DialogConfirmMessage.ship, postAction: 'MARK_AS_SHIPPED' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        action: 'mail', value: 'Print & Mail Invoice', icon: 'fa-truck', actionId: ActionIconSampleRequest.MAIL,
        confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE'
      },
      {
        action: 'ship', value: 'Mark as Shipped', icon: 'fa-print',
        actionId: 2, confirm: DialogConfirmMessage.ship, postAction: 'MARK_AS_SHIPPED'
      }]
  },

  5: {
    status: 'Pending Delivered',
    statusId: 5,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' },
      { action: 'track', value: 'Track Shipment', confirm: '', postAction: '' },
      { action: 'deliver', value: 'Mark as Delivered', confirm: DialogConfirmMessage.deliver, postAction: 'MARK_AS_DELIVERED' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        action: 'deliver', icon: 'fa-print', actionId: 1, value: 'Mark as Delivered',
        confirm: DialogConfirmMessage.deliver, postAction: 'MARK_AS_DELIVERED'
      }]
  },

  6: {
    status: 'Pending Evaluation',
    statusId: 6,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: '' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },

  7: {
    status: 'Evaluated',
    statusId: 7,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        action: 'mail', icon: 'fa-eye', actionId: ActionIconSampleRequest.MAIL,
        confirm: DialogConfirmMessage.mail, value: 'Print & Mail Invoice', postAction: 'PRINT_MAIL_INVOICE'
      }]
  },

  8: {
    status: 'Pending Refund',
    statusId: 8,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'refund', value: 'Mark as refunded', confirm: DialogConfirmMessage.refund, postAction: 'MARK_AS_REFUNDED' },
      { action: 'reject', value: 'Reject Refund request', confirm: DialogConfirmMessage.reject, postAction: 'REJECT_REFUND_REQUEST' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },
  9: {
    status: 'Refunded',
    statusId: 9,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },
  10: {
    status: 'Refund Canceled',
    statusId: 10,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },

  11: {
    status: 'Canceled',
    statusId: 11,
    actionBtn: [
      { action: 'send', value: 'Send for Approval', confirm: DialogConfirmMessage.sendback, postAction: 'SEND_BACK_TO_APPROVAL' },
      { action: 'cancel', value: 'Close', confirm: '', postAction: 'CANCEL' },
      // { action: 'delete-req', value: 'Delete Sample Request', confirm: '' }
    ],
    actionIcon: [
      { action: 'cancel', value: 'View', icon: 'fa-eye', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },
};

export const SampleRequestBuyerObj = {
  1: {
    status: 'Pending Vendor Confirmation',
    statusId: 1,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'delete', value: 'Cancel', confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' }
    ],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW },
      { icon: 'fa-times-circle', value: 'Cancel', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' }]
  },
  2: {
    status: 'Pending Proforma Confirmation',
    statusId: 2,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'delete', value: 'Cancel', confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      { action: 'approve', value: 'Approve & Pay', confirm: DialogConfirmMessage.approve, postAction: 'APPROVE_PAY' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      { icon: 'fa-times-circle', value: 'Cancel', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      {
        icon: 'fa-hand-o-right', value: 'Approve & Pay', actionId: ActionIconSampleRequest.APPROVE,
        confirm: DialogConfirmMessage.approve, postAction: 'APPROVE_PAY'
      }
    ]
  },
  3: {
    status: 'Pending Packing',
    statusId: 3,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'delete', value: 'Cancel', confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      { icon: 'fa-times-circle', value: 'Cancel', actionId: 1, confirm: DialogConfirmMessage.cancel, postAction: 'CANCEL' },
      {
        icon: 'fa-envelope', value: 'Print & Mail Invoice', actionId: ActionIconSampleRequest.MAIL,
        confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE'
      }]
  },
  4: {
    status: 'Pending Shipping',
    statusId: 4,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: 2, confirm: '' }]
  },

  5: {
    status: 'Pending Delivery',
    statusId: 5,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' },
      // { action: 'print', value: 'Print Packing Checklist', confirm: '' }, As per tester told removed this
      { action: 'track', value: 'Track Shipment', confirm: '' }
    ],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        icon: 'fa-envelope', actionId: ActionIconSampleRequest.MAIL, confirm: DialogConfirmMessage.mail,
        value: 'Print & Mail Invoice', postAction: 'PRINT_MAIL_INVOICE'
      },
      // { icon: 'fa-truck', actionId: ActionIconSampleRequest.TRACK, confirm: '' }
    ]
  },

  6: {
    status: 'Pending Evaluation',
    statusId: 6,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'refund', value: 'Request Refund', confirm: DialogConfirmMessage.requestrefund, postAction: 'REQUEST_REFUND' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      { icon: 'fa-star', value: 'Evaluate', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        icon: 'fa-exchange', value: 'Request Refund', actionId: ActionIconSampleRequest.REFUND,
        confirm: DialogConfirmMessage.requestrefund, postAction: 'REQUEST_REFUND'
      }]
  },

  7: {
    status: 'Evaluated',
    statusId: 7,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      { action: 'refund', value: 'Request Refund', confirm: DialogConfirmMessage.requestrefund, postAction: 'REQUEST_REFUND' },
      { action: 'mail', value: 'Print & Mail Invoice', confirm: DialogConfirmMessage.mail, postAction: 'PRINT_MAIL_INVOICE' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        icon: 'fa-exchange', value: 'Request Refund', actionId: ActionIconSampleRequest.REFUND,
        confirm: DialogConfirmMessage.requestrefund, postAction: 'REQUEST_REFUND'
      },
      {
        icon: 'fa-envelop', value: 'Print & Mail Invoice', actionId: ActionIconSampleRequest.MAIL,
        confirm: '', postAction: 'PRINT_MAIL_INVOICE'
      }]
  },

  8: {
    status: 'Pending Refund',
    statusId: 8,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' },
      {
        action: 'reject', value: 'Cancel Refund Request',
        confirm: DialogConfirmMessage.cancelrefund, postAction: 'CANCEL_REFUND_REQUEST'
      }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' },
      {
        icon: 'fa-ban ', value: 'Cancel Refund Request', actionId: 1,
        confirm: DialogConfirmMessage.cancelrefund, postAction: 'CANCEL_REFUND_REQUEST'
      }]
  },

  9: {
    status: 'Refunded',
    statusId: 9,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },

  10: {
    status: 'Refund Canceled',
    statusId: 10,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },

  11: {
    status: 'Canceled',
    statusId: 11,
    actionBtn: [
      { action: 'cancel', value: 'Close', confirm: '' }],
    actionIcon: [
      { icon: 'fa-eye', value: 'View', actionId: ActionIconSampleRequest.VIEW, confirm: '' }]
  },
};

export const ProductStrings = {
  PRODUCT_IMPORT_TITLE: 'Import Products',
  PRODUCT_IMPORT_DESC: 'Import your products in bulk, Add your preferred product details with your family, categories,' + '<br>' +
    'locations and other parameters.',
  PRODUCT_IMPORT_VIDEO_URL: 'https://www.youtube.com/embed/9B7te184ZpQ?rel=0'
};

export enum RequestStatusBuyer {
  PENDING_APPROVAL = 1,
  PENDING_CONFIRMATION = 2,
  PENDING_PACKING = 3,
  PENDING_SHIPPING = 4,
  PENDING_DELIVERY = 5,
  PENDING_EVALUATION = 6,
  EVALUATED = 7,
  PENDING_REFUND = 8,
  REFUNDED = 9,
  REFUND_CANCELED = 10,
  CANCELED = 11,
}

export enum AddressType {
  SHIPPING = 1,
  BILLING = 2,
}

export const SubscriptionPlanDetails = {
  '1': { plan: 'Free' },
  '2': { plan: 'Basic1' },
  '3': { plan: 'Basic2' },
  '4': { plan: 'Basic3' },
  '5': { plan: 'Pro' }
};

export const CaroselType = {
  ADDRESS: 'ADDRESS',
};

export enum ButtonTypes {
  Ok = 1,
  OkCancel = 2,
  ConfirmCancel = 3,
  UpgradeCancel = 4,
  Continue = 5,
}

export const TransferTypes = {
  COMPANY_USERS: 'COMPANY_USERS',
  MY_DISTRIBUTOR: 'MY_DISTRIBUTOR',
  MY_SALES_REP: 'MY_SALES_REP'
};

export const SampleRequestAction = {
  CANCEL: 'cancel',
  DELETE: 'delete',
  SEND: 'send',
  TRANSFER: 'transfer',
  PRINT: 'print',
  MAIL: 'mail',
  PACK: 'pack',
  SHIP: 'ship',
  TRACK: 'track',
  DELIVER: 'deliver',
  REFUND: 'refund',
  REJECT: 'reject',
  DELETE_REQ: 'delete-req',
  MARKREFUND: 'markrefund',
  APPROVE: 'approve',
  EVALUATE: 'evaluate',
  EVALUATE_UPDATE: 'updateevaluate',
  VIEWREPORT: 'viewreport',
  RETRANSFER: 'retransfer'
};

export const StripeCardType = {
  Visa: 'visa',
  Discover: 'discover',
  JCB: 'jcb',
  Maestro: 'maestro',
  Master: 'master',
  Clubs: 'clubs',
  AmericanExpress: 'american'
};

export const ComplainType = {
  CONTACT_TYPE: 'ContactType',
  COMPLAINT: 'Complaint',
  IPR: 'IPR',
  SUPPORT: 'Support',
  TUTORIALS: 'Tutorials'
};

export const CurrencyType = {
  1: { type: 'Eur.', symbol: '€' },
  2: { type: 'Dollar', symbol: '$' }
};

export const ChannelHubCommon = {
  channelHubContactEmail: 'contact us',
  channelHubsalesRepContactEmail: 'Support'
};

export enum RoleEnum {
  AccountUser = 'Account User',
  Admin = 'Admin',
  Primary = 'Primary'
}

export enum RoleIdEnum {
  AccountUser = 1,
  Admin = 2,
  Primary = 3
}

export const tradeLists = [
  {
    'id': '1',
    'name': '1 - 10'
  },
  {
    'id': '2',
    'name': '11 - 50'
  },
  {
    'id': '3',
    'name': '51 - 100'
  },
  {
    'id': '4',
    'name': '101 - Above'
  }
];


export const tradeannualOvers = [
  {
    'id': '1',
    'name': '<1M€'
  },
  {
    'id': '2',
    'name': '1-10M€'
  },
  {
    'id': '3',
    'name': '10-100M€'
  },
  {
    'id': '4',
    'name': '>100M€'
  }
];

export enum FeatureAccessEnum {
  TOP_SEARCH = 1,
  PRODUCT_IMPORT = 32,
  MULTI_USER_ACCESS = 2,
  SAMPLE_REQUEST = 11,
  SAMPLE_ORDER_MGMT = 12,
  SAMPLE_ORDER_WIHT_TRANSFER = 13,
  ZONE_INCLUDES = 16,
  ADD_PRODUCT = 28,
  PRODUCT_IMAGE_BY_SHEET = 29,
  PRODUCT_VIDEO_BY_SHEET = 30,
}

export const SocialLinkConfig = {
  'Linkedin': { 'icon': 'fa-linkedin', 'block': 'linkedInBox' },
  'Googleplus': { 'icon': 'fa-google-plus', 'block': 'googlePlusBox' },
  'Instagram': { 'icon': 'fa-instagram', 'block': 'instagramBox' }
};

export const SampleCartCalculation = {
  DISCOUNT: 'Provide discount From 1 to 100',
  SHIPPING: 'Provide Valid price',
  OTHER_CHARGES: 'Provide Valid price',
  QUANTITY: 'Provide Valid Quantity',
  QUANTITY_GREATER: 'Qauntity should not greater',
  QUANTITY_VALID: 'Provide Valid Quantity',
};

export enum MoreListViewEnum {
  SUGGESTION_VIEW = 1,
  PRODUCT_LIST_VIEW = 2,
  BRAND_LIST_VIEW = 3,
  OFFICIAL_DISTRIBUTOR_VIEW = 4
}

export const CartMessage = {
  succesMessage: 'popupText.updatedSuccessfully',
  validNumber: 'popupText.validNumber',
  limitedMessage: 'popupText.productlimit',
  itemdeleted: 'popupText.cartItemDeleted',
  listdeleted: 'popupText.cartDeleted',
  confirmMessage: 'popupText.clearCart',
  cartdeleted: 'popupText.cartItemdeleted',
  cartEmpty: 'popupText.cartEmpty'
};

export const SampleRequestPreference = {
  SAMPLE_REQUESTS_PENDING_APPROVAL: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_PENDING_APPROVAL, 'permission': false,
    'status': RequestStatus.CONFIRMATION
  },
  SAMPLE_REQUESTS_APPROVED: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_APPROVED, 'permission': false,
    'status': RequestStatus.PACKING
  },
  SAMPLE_REQUESTS_PACKED: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_PACKED, 'permission': false,
    'status': RequestStatus.SHIPPING
  },
  SAMPLE_REQUESTS_SHIPPED: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_SHIPPED, 'permission': false,
    'status': RequestStatus.DELIVERY
  },
  SAMPLE_REQUESTS_DELIVERED: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_DELIVERED, 'permission': false,
    'status': RequestStatus.EVALUATION
  },
  SAMPLE_REQUESTS_EVALUATION: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_EVALUATION, 'permission': false,
    'status': RequestStatus.EVALUATED
  },
  SAMPLE_REQUESTS_CANCELLED: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_CANCELLED, 'permission': false,
    'status': RequestStatus.CANCELED
  },
  SAMPLE_REQUESTS_REFUNDS: {
    'preference': AccessPermissionEnum.SAMPLE_REQUESTS_REFUNDS, 'permission': false,
    'status': RequestStatus.REFUND
  },
};

export enum UploadNotifyEnum {
  Uploaded = 1,
  UploadedFailed = 2,
  MaximumReached = 3,
  FilesNotAllowed = 4,
  BeforeUpload = 5,
  FileSizeNotAllowed = 6
}

export const CookieConfig: any = {
  'cookie': {
    'domain': environment.HOST
  },
  'position': 'bottom-left',
  'theme': 'block',
  'palette': {
    'popup': {
      'background': '#000000',
      'text': '#ffffff',
      'link': '#ffffff'
    },
    'button': {
      'background': '#f1d600',
      'text': '#000000',
      'border': 'transparent'
    }
  },
  'type': 'opt-out',
  'content': {
    'message': 'cookie.content.message',
    'dismiss': 'cookie.content.dismiss',
    'deny': 'cookie.content.deny',
    'link': '',
    'href': 'https://channel-hub.io/privacy'
  }
};

export const LeadManagement: any = [
  { tag: 'High' },
  { tag: 'Medium' },
  { tag: 'Low' }
];

export const VerificationButtonTypes = {
  Success: 'success',
  Retry: 'retry',
  Change: 'change',
};

export enum AddProductSectionMaxLimit {
  ReviewsMaxLimit = 4,
  ProductExistingRatingMaxLimit = 4,
  ProductKeyRetailerMaxLimit = 5
}

export const RecommendationsList = [
  {
    id: 2,
    type: 'Vendor'
  },
  {
    id: 3,
    type: 'Distributor'
  },
  {
    id: 4,
    type: 'Retailer'
  }
];

export const NotificationFormatContact = {
  ORDER_REFUND_APPROVED: 'ORDER_REFUND_APPROVED',
  ORDER_REFUND_CANCEL: 'ORDER_REFUND_CANCEL',
  MYCHANNEL_DECLINE: 'MYCHANNEL_DECLINE',
  MYPROSPECT_APPROVAL: 'MYPROSPECT_APPROVAL',
  MYPROSPECT_DECLINE: 'MYPROSPECT_DECLINE',
  ORDER_PAID: 'ORDER_PAID',
  ORDER_RE_CREATION: 'ORDER_RE_CREATION',
  MYCHANNEL_APPROVAL: 'MYCHANNEL_APPROVAL',
  MESSAGING: 'MESSAGING',
  SUGGESTION_PRODUCT: 'SUGGESTION_PRODUCT',
  ORDER_REFUND_REJECTED: 'ORDER_REFUND_REJECTED',
  COMPLAINTS_REPLAY: 'COMPLAINTS_REPLAY',
  DISMISS_CHANNEL: 'DISMISS_CHANNEL',
  MAIL_MESSAGE: 'MAIL_MESSAGE',
  ORDER_REFUND_PENDDING: 'ORDER_REFUND_PENDDING',
  CLAIM_APPROVED: 'CLAIM_APPROVED',
  CHANNEL_APPROVED: 'CHANNEL_APPROVED',
  ORDER_CANCEL: 'ORDER_CANCEL',
  ORDER_PACKED: 'ORDER_PACKED',
  CLAIM_REJECTED: 'CLAIM_REJECTED',
  REQUEST_TO_MYPROSPECT: 'REQUEST_TO_MYPROSPECT',
  ORDER_MAIL_INVOICE: 'ORDER_MAIL_INVOICE',
  SUGGESTION_CHANNEL: 'SUGGESTION_CHANNEL',
  ORDER_DELIVERED: 'ORDER_DELIVERED',
  CHANNEL_REJECT: 'CHANNEL_REJECT',
  RATING: 'RATING',
  CHANNEL_RECOMMENDED: 'CHANNEL_RECOMMENDED',
  ORDER_RE_TRANSFER: 'ORDER_RE_TRANSFER',
  COMPLAINTS: 'COMPLAINTS',
  ADD_TO_PROSPECTS: 'ADD_TO_PROSPECTS',
  ORDER_EVALUATED: 'ORDER_EVALUATED',
  ORDER_CHECKOUT: 'ORDER_CHECKOUT',
  ORDER_SHIPPED: 'ORDER_SHIPPED',
  NOT_INTEREST_IN_THIS_PRODUCT: 'NOT_INTEREST_IN_THIS_PRODUCT',
  REQUEST_TO_MYCHANNEL: 'REQUEST_TO_MYCHANNEL',
  ORDER_TRANSFER: 'ORDER_TRANSFER',
  ORDER_APPROVAL: 'ORDER_APPROVAL',
  CHANGE_OF_CONTACT: 'CHANGE_OF_CONTACT',
  CHANNEL_APPROVAL_PENDING: 'CHANNEL_APPROVAL_PENDING'
};

export const SenderReceiverObject = {
  SENDER: 'SENDER',
  RECEIVER: 'RECEIVER'
};

export const PageNames = {
  CHANNEL_DETAIL_VIEW: 'CHANNEL_DETAIL_VIEW',
  PRODUCT_DETAIL_VIEW: 'PRODUCT_DETAIL_VIEW'
};

export const ProductListActiveInactive = {
  ACTIVE: 1,
  INACTIVE: 0
};

export const MaturityLevel = {
  PROTOTYPE: 'PROTOTYPE',
  S_BACKER: 'S_BACKER',
  S_VOLUME: 'S_VOLUME',
};

export const CountryList = {
  FRANCE: '' + environment.FRANCE_COUNTRY_ID,
};

export const errorListInvitation = {
  '10001': 'recommendation.errorMessage.requestSent',
  '10002': 'recommendation.errorMessage.cannotaccess',
  '10003': 'recommendation.errorMessage.alreadyList',
  '10004': 'recommendation.errorMessage.waitList',
  '10005': 'recommendation.errorMessage.alreadyRequestList',
  '10006': 'recommendation.errorMessage.suggestion',
  '3031': 'recommendation.errorMessage.subscription'
};

