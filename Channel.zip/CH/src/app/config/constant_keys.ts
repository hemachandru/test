export const ApiUrl = {
    APP: 'app',
    LOGIN: 'authenticate',
    COUNTRYLIST: 'country',
    SIGNUP: 'signup',
    FORGETPASSWORD: 'forgotPassword',
    RESETPASSWORD: 'resetPassword',
    RESETPASSWORDUPDATE: 'resetPassword',
    VERIFYUSER: 'signUpVerify',
    RESENDEMAIL: 'emailResend',
    CHANGEANDRESENDEMAIL: 'mailchange',
    SUBSCRIPTIONSUCCESS: 'SubscriptionSuccess',
    VERIFICATIONPENDING: 'VerificationPending',
    CHANNELTYPE: 'channelType',
    GETUSERSTATUS: 'userStatus?',
    GETSUBSCRIPTIONPERIOD: 'subscriptionPeriod',
    GETSUBSCRIPTIONPLAN: 'subscriptionPlanAllPeriod',
    USERSUBSCRIPTION: 'subscription',
    COUPONCODECHECKING: 'coupon',
    CONTACTINFO: 'contact',
    PAYMENT: 'subscription/pay',
    SUBSCRIPTION_TYPE_OLD: 'old',
    SUBSCRIPTION_TYPE_NEW: 'new',
    SUBSCRIPTION_TYPE_CLAIM: 'claim',
    COMPANY: 'company',
    POST_COMPANY: 'company/profile',
    POST_UPDATE_COMPANY: 'user/company/profile',
    GETCHANNELLOCATION: 'getChannelLocation',
    ZONE_LIST: 'zone',
    ZONE_BASED_REGION_COUNTRY: 'regionCountry',
    LOCATION_ZONE_REGION_SEARCH: 'searchRegion',
    LOCATION_ZONE_COUNTRY_SEARCH: 'searchCountry',
    LOCATION_COUNTRY_SAVE: 'updateChannelLocation',
    CHECK_EMAIL: 'checkmail',
    CHANNEL_SUBSCRIBE: 'channel/subscribe',
    VERIFICATIONSUCCESS: 'VerificationSuccess',
    CUSTOMER_PROFILE: 'customer-profile',
    LIST_SERVICE: 'list-service',
    PRODUCT_FAMILY: 'productfamily',
    PRODUCT_CATEGORY: 'productcategory',
    DISTRIBUTOR_LIST: 'distributor-list',
    CHANNEL_BRAND: 'channel-brand',
    BRAND_DUPLICATION: 'channelBrandCheck',
    CUSTOMER_TYPE: 'customer-type',
    POST_TRADEINFORMATION: 'tradeInformation',
    UPDATE_TRADEINFORMATION: 'tradeInformation',
    STRIPE_CONNECT: 'stripe/connect',
    SCORE_LIST: 'channel/profile/scorelist',
    PUBLICUPLOAD: 'publicUpload',
    PROFILE: 'profile',
    USER_LIST: 'contacts',
    WORKNATURE_LIST: 'workNatureList',
    ROLE_LIST: 'role',
    REPORT_LIST: 'reportUserList',
    SHARE_TYPE_LIST: 'shareTypeList',
    USER_PASSWORD_RESET: 'userPasswordReset',
    CHANNEL_INFO: 'channel-infos',
    MY_PROFILE: 'user/profile',
    SETTING_MASTER: 'settingsMaster',
    ACCESSPERMISSION: 'preference',
    PERFERENCETREE: 'preference/tree',
    PROFILE_SETTING_POST: 'settings',
    PROFILE_SETTING_GET: 'settings',
    CREATEREGION: 'createRegion',
    PAID_USER: 'paid',
    FREE_USER: 'free',
    ADD_USER: 'contact/add',
    UPDATE_MY_PROFILE: 'profile',
    DISMISS_REASONS: 'dimissReasons',
    UPDATE_CHANNEL: 'updateChannel',
    UPDATE_INTERSET_LEVEL: 'updateLeadManagementTag',
    CONTACT_LIST: 'contacts',
    CHANNELIST: 'channelHub',
    DEFAULT_CONTACT: 'updateChannelDefaultContact',
    PREESET_MESSAGE: 'preset-message',
    CONTACT_MAIL: 'contact/sendMail',
    NOTIFICATION_UNREADCOUNT: 'notification-unreadcount',
    NOTIFICATION_READ: 'notification-read',
    NOTIFICATION: 'notification',
    PRODUCT_LIST: 'products',
    PRODUCT: 'product',
    PRODUCT_DETAIL: 'product',
    CHANNELBRAND: 'channelBrands',
    CHANNELDETAILVIEW: 'channelDetailView',
    MYCHANNELDETAIL: 'myChannelDetail',
    MATCHINGCHANNELS: 'matchingChannels',
    SEARCH_RESULT: 'search/company',
    PRODUCT_INFO: 'product/info',
    UNIT: 'unit',
    PRODUCT_STATUS: 'product/status',
    PARTNER_CHANNELS: 'partnerChannels',
    CHANNEL_CONTACT_LIST: 'channelContacts',
    CHANNELUPGRADE: 'channel/upgradeable',
    PRODUCT_SEARCH: 'suggested/product',
    PRODUCT_TOP_SEARCH: 'search/product',
    CONTACT_DETAIL: 'contactDetails',
    DISCOUNT_UNIT: 'disCountUnit',
    SEARCHSUGGESSION: 'search/sugessions',
    DEFAULT_CONTACT_CHANNEL: 'defaultContact',
    CHANNELCONTACTS: 'channelcontacts',
    OFFICIALDISTRIBUTORS: 'officialdistributors',
    COMPANY_LIST: 'company',
    NEWPRODUCT_LIST: 'my-products',
    FAVOURITE_LIST: 'favorite',
    PRODUCT_IMPORT_SAMPLE: 'productImportSample',
    PRODUCT_IMPORT_SAMPLE_FOLDER: 'temp',
    PRODUCT_IMPORT: 'productImport',
    ORDER_LIST_SELLER: 'seller/orders',
    ORDER_INFO_DETAILS: 'order/info',
    ORDER_DETAILS: 'order',
    CART_LIST: 'cart',
    ADDTOCART: 'cart/item',
    ADDTOFAVORITE: 'favorite/add',
    GETCARTCOUNT: 'cart/item/count',
    FAVORITECOUNT: 'favorite/count',
    PRODUCTREJECTREASON: 'reject',
    PRODUCTREJECTREASONLIST: 'rejectreason',
    CART_UPDATE: 'cart/item',
    HOME: 'home',
    NEWSLIST: 'newsList',
    PRODUCTRATINGDETAILS: 'product/ratingdetails',
    PRODUCTRATINGCOMMENT: 'product/ratingcommentsdetails',
    PRODUCTRATINGSTATICTIS: 'product/ratingdetailsstatistics',
    ADDRESS_BOOK: 'addressbook',
    SAMPLE_BUYER_REQUEST: 'buyer/samples',
    SAMPLE_BUYER_ORDERDETAILS: 'buyer/sample',
    SAMPLE_BUYER_ACTION: 'buyer/sample',
    CHECKOUT: 'checkout',
    STATUS_LIST: 'orderStatus',
    EVALUATION_ATTRIBUTE: 'evaluationattribute',
    SAMPLE_SELLER_ORDERDETAILS: 'seller/order',
    SAMPLE_SELLER_STATUS_COUNT: 'seller/order/status/counts',
    MY_CHANNELS: 'mychannels',
    PRODUCTACTIONINFO: 'productActionInfo',
    FAQ_HEADER: 'faqCategoryList',
    FAQ_LIST: 'faqList',
    NEWS_LIST: 'newsList',
    NEWS_ITEM: 'news',
    PRODUCT_IMPORT_UPLOAD: 'productImageUpload',
    COMPLAINT_CATEGORY_LIST: 'complain/category',
    COMPLAINT: 'complain',
    PRODUCT_EVALUATE: 'product/evaluate',
    ORDER_DETAIL_ID: 'orderDetailId',
    CMS_PAGE: 'cms/page',
    ABOUT_US: 'about',
    OUR_TEAM: 'ourteam',
    PRIVACY: 'privacy',
    VENDOR: 'vendor',
    RETAILER: 'retailer',
    DISTRIBUTOR: 'distributor',
    SALES_REP: 'sales-rep',
    TERMS_CONDITIONS: 'termsconditions',
    LEGAL_INFORMATION: 'legalInforamtion',
    VERIFIED_ALREADY: 'VerifiedAlready',
    SAMPLE_REQUEST_UPGRADE: 'seller/order/queued/count',
    BILLINGADDRESS: 'billingAddress',
    STRIPE_CONNECT_CHECK: 'stripeConnectCheck',
    CHANGED_MAIL: 'changedMail',
    OFFICIAL_DOCUMENTS: 'officationDocumentDownload',
    CHANNEL_CLAIM: 'channelDetail',
    CURRENCY_CONVERTION: 'currency',
    OLD_CONTACT: 'oldContact',
    OLD_COMPANY: 'oldCompany',
    OLD_TRADE_INFORMATION: 'oldTradeInformation',
    SIMILAR_COMPANY: 'similar/company',
    CHECKOUT_LIMIT_AMT: 'master/settings',
    CHECKOUT_LIMIT_AMT_KEY: 'ORDER_GRAND_TOTAL_AMOUNT_LIMIT',
    CHANNEL_PRODUCTS_LIST: 'channel-products',
    OVERALL_RATING_EVALUATE: 'product/evaluationreport',
    SAVE_COMPANY: 'choose-company',
    DISTRIBUTOR_CHANNEL_SEARCH: 'distributorChannelSearch',
    RECOMMENDATION_CHANNEL_SEARCH: 'recommendationChannelSearch',
    DISTRIBUTOR_CHANNEL_POST: 'channelRecommended',
    RECOMMENDATION_CHANNEL_POST: 'channelInvitation',
    UPDATE_PRODUCT_EVALUATION: 'Product/evaluate',
    PRODUCT_EDIT_EVALUATE: 'product/evaluate/edit',
    LOGOUT: 'logout',
    KEYRETAILER_SEARCH: 'partnerChannelSearch',
    KEYRETAILERS_PRODUCT: 'KeyPartners',
    KEYRETAILER_POST: 'newKeyRetailer',
    KEYRETAILER_DUPLICATES: 'channelKeyPartnerCheck',
    
    // invitations
    MY_INVITATION_LIST: 'myRecommendationList',
    ADD_TO_PARTNER: 'addtopartner'
};

export const AppLocalStorageKeys = {
    APP_Token: 'appToken',
    AUTH_Token: 'authToken',
    SUBSCRIPTION_DATA: 'SubscrpitionData',
    USER_CHANNEL_STATUS: 'user_channelstatus',
    SUBSCRIPTION_CONTACTID: 'user_subscription_contactId',
    CHANNEL_NAME: 'channelName',
    CHANNEL_TYPE_ID: 'channelTypeId',
    CHANNEL_ID: 'user_channelId',
    USER_ID: 'userId',
    USER: 'user',
    SUBSCRIPTION_PLAN_DETAIL: 'SubscrpitionPlanDetail',
    CHANNEL_TYPE: 'channelType',
    USER_IMAGE_URL: 'userImage',
    USER_NAME: 'username',
    JOB_TITLE: 'jobtitle',
    CONTACT_TEMP_DATA: 'contactTempData',
    REF_CONTACT_TEMP_DATA: 'refContactTempData',
    CONTACT_POPUP_FLAG: 'contactPopupFlag',
    CURRENT_SUBSCRIPTION_PLAN: 'currentSubscrpitionPlan',
    ORDER_NUMBER: 'OrderNo',
    SIDE_MENU_LIST: 'sideMenuList',
    CURRENT_SUBSCRIPTION_PLAN_ORDER: 'currentSubscrpitionPlanOrder',
    PERMISSIONS: 'permissions',
    ROLE: 'role',
    USER_STATUS_DETAILS: 'user_status_details',
    CONTACT_INFO: 'contactInfo',
    GUEST_CHANNEL_TYPE_ID: 'guestChannelTypeId',
    REDIRECT_ID: 'RedirectId',
    STRIPE_CHECK: 'stripeCheck',
    AUTH_LOCAL_TIME: 'AuthTokenSessionTime',
    OLD_CHANNEL: 'oldChannel',
    CURRENCY_CONVERTION_TABLE: 'currency_conversion_table',
    USER_CURRENCY: 'user-currency',
    MAIL_REDIRECTION: 'mailRedirection',
    SELLING_PROFILE: 'sellingProfile',
    SOURCING_PROFILE: 'sourcingProfile',
    MULTIPLE_FILE_UPLOAD: 'multipleFileUpload',
    APP_AUTH_LOCAL_TIME: 'AppAuthTokenSessionTime',
    SUBSCRIPTION_PAY_FLAG: 'SubscriptionPayFlag',
    TEMP_CHANNEL_TYPE_ID: 'tempChannelTypeId',
    TEMP_CHANNEL_TYPE: 'tempChannelType',
    IS_SALES_REP: 'isSalesRep',
    RELATION_COUNT: 'relation_counts'
};

export interface UserStatusDetails {
    channelStatusId: string;
    planId: string;
    subscriptionId: string;
    features: any;
}

export const WebUrl = {
    // cms pages
    ABOUT_US: 'aboutus',
    DISTRIBUTOR: 'distributor',
    VENDOR: 'vendor',
    RETAILER: 'retailer',
    SALES_REP: 'business-developer',
    OUR_TEAM: 'ourteam',
    PRIVACY: 'privacy',
    HOW_DOES_IT_WORK: 'howdoesitwork',
    NEWS_LIST: 'newslist',
    TERMS_CONDITIONS: 'termsconditions',
    HELP_SUPPORT: '/help/support',
    FAQ_LIST: 'faq',
    LEGAL_INFORMATION: 'legal-information',

    // Internal pages
    ACCOUNT_VERIFY_URL: '/account/verify',
    DASHBOARD: '/dashboard',
    USER_PROFILE_SELECTION: '/user_profile_selection',
    LOGIN: '/auth/login',
    SIGNUP: '/auth/signup',
    FORGETPASSWORD: '/auth/forgetpassword',
    ACCOUNTVERIFY: '/auth/accountverify',
    USER_SUBSCRIPTION_PLAN: '/user/subscriptionplan',

    // LOGIN: '/login',
    // SIGNUP: '/signup',
    // FORGETPASSWORD: '/forgetpassword',
    // ACCOUNTVERIFY: '/accountverify',
    //  Order pages
    ORDER_SELLER_REQUEST : '/order/sellerrequest',
    ORDER_BUYER_REQUEST : '/order/buyerrequest',

    CART_LIST: '/cart',
    CART_LIST_VIEW: '/cart/productview/',
    CHECKOUT: '/cart/checkout',
    ORDER_SUCCESS: '/ordersuccess',

    // channel routing
    CHANNEL_SUGGESTION: '/channel/suggestions',
    CHANNEL_SUGGESTION_VIEW: '/channel/suggestions/channelView/',

    CHANNEL_VIEW_PAGE: '/channel/channelView/',

    // My prospects
    CHANNEL_MYPROSPECTS: '/channel/myprospects',
    CHANNEL_MYPROSPECTS_VIEW: '/channel/myprospects/channelView/',
    MYPROSPECTS_APPROVALS: '/channel/myprospects/approvals',
    MYPROSPECTS_APPROVALS_VIEW: '/channel/myprospects/approvals/channelView/',

    // My channels
    CHANNEL_MYCHANNELS: '/channel/mychannels',
    CHANNEL_MYCHANNELS_VIEW: '/channel/mychannels/channelView/',
    MYCHANNEL_APPROVALS: '/channel/mychannels/approvals',
    MYCHANNEL_APPROVALS_VIEW: '/channel/mychannels/approvals/channelView/',

    CHANNEL_CONTACTLIST: '/channel/contactlist',

    // search
    CHANNEL_SEARCHRESULT: '/searchResult',
    PRODUCT_SEARCHRESULT: '/searchResult/product',
    CHANNEL_SEARCHRESULT_VIEW: '/searchResult/channelView/',
    PRODUCT_SEARCHRESULT_VIEW: '/searchResult/productview/',

    // more matching resuslts
    MORE_MATCHING_PRODUCT: '/product/morelist',
    MORE_MATCHING_PRODUCT_VIEW: '/product/morelist/productview/',

    MORE_MATCHING_CHANNEL_VIEW: '/channel/morelist/channelView/',
    MORE_MATCHING_CHANNEL: '/channel/morelist/',
    MORE_MATCHING_CHANNEL_VIEW_PREV_NEXT: '/channel/morelist/channelview/',


    // profile pages
    PROFILE: '/profile/',
    PUBLIC_PROFILE: '/public-profile/',

    // wishlist
    WISHLIST: '/wishlist/',
    WISHLIST_PRODUCT_VIEW: '/wishlist/productview/',

    // MY_PRODUCTLIST: '/channel/productlist',
    // MY_PRODUCTLIST_VIEW: '/channel/productlist/productview/',
    // CHANNEL_PRODUCT_VIEW: '/channel/productlist/productview/',

    // product routing
    PRODUCT_SUGGESTION: '/product/suggestions',
    PRODUCT_SUGGESTION_VIEW: '/product/suggestions/productview/',
    PRODUCT_SUGGESTION_VIEW_PREV_NEXT: '/product/suggestions/productView/',

    PRODUCT_IMPORT: '/productlist/productimport',
    PRODUCT_MANAGE: '/productlist/productmanage',
    MY_PRODUCTLIST: '/productlist',
    MY_PRODUCT_VIEW: '/productlist/productview/',
    MY_PRODUCT_VIEW_PREV_NEXT: '/productlist/productView/',
    MY_PRODUCTVIEW: '/product/productview/',

    // My invitations
    // MY_INVITATIONS: '/channel/mychannels/invitations',
    MY_INVITATIONS: '/channel/invitations',
};

export const PageTitles = [
    {
        path: WebUrl.LOGIN,
        title: 'Login'
    },
    {
        path: WebUrl.SIGNUP,
        title: 'Signup'
    },
    {
        path: WebUrl.FORGETPASSWORD,
        title: 'Forget Password'
    },
    {
        path: WebUrl.USER_PROFILE_SELECTION,
        title: 'Profile Selection'
    },
    {
        path: '/user/search',
        title: 'Company Search'
    },
    {
        path: '/user/register',
        title: 'Company Information'
    },
    {
        path: '/user/subscription_contact_info',
        title: 'Contact Information'
    },
    {
        path: WebUrl.USER_SUBSCRIPTION_PLAN,
        title: 'Subscription Plan'
    },
    {
        path: '/user/confirmplan',
        title: 'Subscribe'
    },
    {
        path: '/user/transaction',
        title: 'Transaction'
    },
    {
        path: '/account/(accountroute:profile)',
        title: 'Company Profile Setup'
    },
    {
        path: '/account/(accountroute:information)',
        title: 'Company Trade Information Setup'
    },
    {
        path: '/account/(accountroute:location)',
        title: 'Company Trade Location Setup'
    },
    {
        path: '/profile/(profileroute:companyprofile)',
        title: 'Company Profile'
    },
];

export const ConfigKeys = {
    TAWK_ID: '5b699d11e21878736ba2b3be',
};
