import { Injectable } from '@angular/core';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { HttpParams } from '@angular/common/http';
import { ApiUrl } from '@app/config/constant_keys';

@Injectable()
export class OrderServiceService {
  private apiUrl = ApiUrl;

  constructor(private _httpReqService: HttpRequestService) { }

  getService(url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequest(url, returnFullResponse);
  }

  getServicewithoutToken(url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequestWithoutToken(url, returnFullResponse);
  }

  postService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.postHttpRequest(data, url, returnFullResponse);
  }

  getByIDService(data: any, url: any, returnFullResponse: boolean) {
    return this._httpReqService.getHttpRequestWithData(data, url, returnFullResponse);
  }

  getProductRatingDetails(data: any) {
    const url: any = this.apiUrl.PRODUCTRATINGDETAILS + '/' + data;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  getProductRatingComment(data: any) {
    const url: any = this.apiUrl.PRODUCTRATINGCOMMENT + '/' + data;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  getProductRatingStatictis(data: any) {
    const url: any = this.apiUrl.PRODUCTRATINGSTATICTIS + '/' + data;
    return this._httpReqService.getHttpClientRequest(url, true);
  }

  getMyChannels(typeid: number, search: string, channelId: number, page: number = 1, limit: number = 10) {
    const url: any = this.apiUrl.MY_CHANNELS;
    let params = new HttpParams();
    params = params.set('skipid', channelId.toString());
    params = params.set('typeid', typeid.toString());
    if (search.toString().trim().length > 0) {
      params = params.set('search', search);
    }
    params = params.set('page', page.toString());
    params = params.set('limit', limit.toString());

    return this._httpReqService.getHttpRequestWithSubQueryString(params, url, true);
  }

  postTransferOrder(data: any, orderNo: any) {
    const url = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS + '/' + orderNo;
    return this._httpReqService.postHttpRequest(data, url, true);
  }

  getSampleOrders(datas, filters) {
    let params = new HttpParams();
    params = params.set('search', datas.searchKey);
    params = params.set('page', datas.pageNumber);
    params = params.set('limit', datas.limit);
    params = params.set('sort', datas.sort);

    const url: any = this.apiUrl.SAMPLE_BUYER_REQUEST + '?' + params;
    return this._httpReqService.postHttpRequest(filters, url, true)
      .map(res => {
        return res;
      });
  }

  putService(dataparams: any, url: string, returnFullResponse: boolean = false) {
    return this._httpReqService.putHttpRequest(dataparams, url, returnFullResponse);
  }
}
