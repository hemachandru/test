export interface Pagination {
    limit: number;
    page: number;
    total: string;
}

export interface Buyerchannel {
    channelId: number;
    companyName: string;
    planId: number;
}

export interface Result {
    sampleorderid: string;
    currencyid: string;
    ordernumber: string;
    userid: string;
    sellerchannelid: string;
    buyerchannelid: string;
    orderdate: Date;
    requestfreesample: string;
    ordertotalprice: string;
    statusid: string;
    buyerchannel: Buyerchannel;
    no_of_items: string;
    total_quantities: string;
    invoiced: string;
    ordered_quantities: string;
    ordered_price: string;
}

export interface BuyerOrderList {
    pagination: Pagination;
    results: Result[];
}

/*
**ORDER DETAILS
*/
export interface Country {
    countryId: string;
    country: string;
    deletedAt?: any;
}

export interface Shippingaddress {
    addressid: string;
    name: string;
    address: string;
    city: string;
    countryid: string;
    postalcode: string;
    contactno1: string;
    contactno2: string;
    country: Country;
}

export interface Country2 {
    countryId: string;
    country: string;
    deletedAt?: any;
}

export interface Billingaddress {
    addressid: string;
    name: string;
    address: string;
    city: string;
    countryid: string;
    postalcode: string;
    contactno1: string;
    contactno2: string;
    country: Country2;
}

export interface Code {
    code: string;
    id: number;
    type: string;
}

export interface Retailer {
    margin_price: number;
    margin_unit: string;
}

export interface Currency {
    code: string;
    id: string;
}

export interface Sample {
    unit: string;
    price: string;
}

export interface Distributor {
    margin_price: number;
    margin_unit: string;
}

export interface Retail {
    unit: string;
    price: string;
}

export interface Price {
    is_sample_free: boolean;
    is_unlimited_sample: boolean;
    retailer: Retailer;
    currency: Currency;
    sample_threshold: string;
    sample: Sample;
    distributor: Distributor;
    retail: Retail;
}

export interface Company {
    name: string;
    id: number;
}

export interface Brand {
    name: string;
    id: number;
}

export interface ProductFamily {
    name: string;
    id: number;
}

export interface Others {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Primary {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Images {
    others: Others[];
    primary: Primary[];
}

export interface Preference {
    name: string;
    id: number;
}

export interface Location {
    name: string;
    id: number;
}

export interface Target {
    locations: Location[];
}

export interface Location2 {
    name: string;
    id: number;
}

export interface Selling {
    locations: Location2[];
}

export interface ProductCategory {
    name: string;
    id: number;
}

export interface Product {
    avaialble_from?: any;
    codes: Code[];
    has_variant: boolean;
    created_at: Date;
    usp: string;
    updated_at: Date;
    price: Price;
    company: Company;
    id: number;
    is_avaialble_immediate: boolean;
    sku: string;
    brand: Brand;
    productdesc: string;
    product_family: ProductFamily[];
    images: Images;
    is_active: boolean;
    company_id: number;
    preference: Preference[];
    avaialbility_comment?: any;
    deleted_at?: any;
    quality: string;
    target: Target;
    urlkey: string;
    can_view_free_plan_members: boolean;
    name: string;
    selling: Selling;
    variantdetails?: any;
    product_category: ProductCategory[];
}

export interface OrderDetail {
    evaluated: boolean;
    sampleorderdetailid: string;
    sampleorderid: string;
    productid: string;
    quantity: string;
    finalquantity: string;
    samplepriceperquantity: any;
    finaltotalprice: string;
    totalprice: string;
    createdat: Date;
    updatedat?: any;
    deletedat?: any;
    product: Product;
    boolQty: boolean;
    orginQty: string;
}

export interface Shipment {
    ordershipmentid: string;
    trackingno: string;
    trackingurl: string;
    comments: string;
    name: string;
}

export interface PaymentTranscation {
    paymentTransactionId: number;
    paymentTransactionAt: Date;
    transactionNumber: string;
    cardType: string;
    cardLastFourDigit: string;
    currencyid: string;
}

export class OrderDetailObject {
    sampleorderid: string;
    ordernumber: string;
    userid: string;
    sellerchannelid: string;
    buyerchannelid: string;
    billingaddressid: string;
    shippingaddressid: string;
    statusid: string;
    currencyid: string;
    subtotalprice: string;
    shippingprice: any;
    discount: any;
    discountunitid?: any;
    othercharge: any;
    ordertotalprice: string;
    paymenttranscationid?: any;
    requestfreesample: string;
    comments?: any;
    orderdate: Date;
    updatedat?: any;
    sellerchannel: Sellerchannel;
    shippingaddress: Shippingaddress;
    billingaddress: Billingaddress;
    shipments: Shipment[];
    contact?: any;
    orderDetails: OrderDetail[];
    paymentTranscation: PaymentTranscation;
    buyer_contact: BuyerContact;
}

export interface BuyerContact {
    firstName: string;
    lastName: string;
}

export interface Country {
    countryId: string;
    country: string;
    deletedAt?: any;
    isVat: string;
    registrationcertificate?: any;
    phoneCode: string;
    isoCode: string;
}

export interface RegAddress {
    addressId: string;
    address: string;
    city: string;
    countryId: string;
    postalCode: string;
    country: Country;
}

export interface ChannelLogo {
    documentUrl: string;
    documentPath: string;
}

export interface ChannelDetail {
    channelLogoId: string;
    phone1: string;
    phone2?: any;
    mobileNo?: any;
    webSiteUrl: string;
    channelLogo: ChannelLogo;
}

export interface Sellerchannel {
    channelId: string;
    channelTypeId: string;
    companyName: string;
    planId: string;
    regAddress: RegAddress;
    channelDetail: ChannelDetail;
}

export interface ChannelLogo {
    documentUrl: string;
    documentPath: string;
}

export interface ChannelDetail {
    channelLogoId: string;
    channelLogo: ChannelLogo;
}

// export interface Sellerchannel {
//     channelId: string;
//     channelTypeId: string;
//     companyName: string;
//     planId: string;
//     channelDetail: ChannelDetail;
// }


/*
**Post Action
*/
export interface SampleOrder {
    transactionId: number;
    token: string;
    amount: number;
}

export interface ProductEvaluationRating {
    ratingattributeid: number;
    rating: number;
}

export interface Evaluate {
    sampleorderdetailid: number;
    productid: number;
    evaluatedby: number;
    review: string;
    productEvaluationRating: ProductEvaluationRating[];
}

export interface UpdateEvaluate {
    sampleorderdetailid: number;
    productid: number;
    evaluatedby: number;
    review: string;
    productevaluationid: number;
    productEvaluationRating: ProductEvaluationRating[];
}

export class PostAction {
    action: string;
    sampleOrder: SampleOrder;
    evaluate: Evaluate;
}

/*
**APPROVE AND PAY
*/
export interface Currency {
    currencyid: string;
    currency: string;
    currencycode: string;
}

export interface OrderTransaction {
    transactionId: number;
    currency: Currency;
    amount: number;
}
