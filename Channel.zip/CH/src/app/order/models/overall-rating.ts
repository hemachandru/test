export interface Ratingtotal {
    evaluationattribute: string;
    totrating: number;
}

export interface Channel {
    channelTypeId: number;
    channelType: string;
    perc: number;
}

export interface Country {
    countryId: number;
    country: string;
    count: number;
}

export interface Statistics {
    ratingtotal: Ratingtotal[];
    channel: Channel[];
    country: Country[];
}

export interface EvaluationAttribute {
    eva: string;
}

export interface RatingAttribute {
    ratingattributeid: string;
    evaluationattributeid: string;
    rating: string;
    evaluationAttribute: EvaluationAttribute;
}

export interface ProductEvaluationRating {
    productevaluationratingid: string;
    productevaluationid: string;
    ratingattributeid: string;
    rating: number;
    ratingAttribute: RatingAttribute;
}

export interface Country2 {
    country: string;
    countryId: string;
}

export interface Document {
    documentUrl: string;
    documentPath: string;
}

export interface ChannelType {
    channelTypeId: string;
    channelType: string;
}

export interface Plan {
    subscriptionPlanId: string;
    subscriptionPlanType: string;
}

export interface Channel2 {
    channelId: string;
    companyName: string;
    companyMail: string;
    subscriptionId: string;
    channelType: ChannelType;
    plan: Plan;
}

export interface Contact {
    contactId: string;
    firstName: string;
    lastName: string;
    jobTitle: string;
    countryId: string;
    documentId: string;
    channelId: string;
    country: Country2;
    document: Document;
    channel: Channel2;
}

export interface CommentList {
    productevaluationid: string;
    productid: string;
    review: string;
    evaluatedby: string;
    createdat: Date;
    productEvaluationRating: ProductEvaluationRating[];
    contact: Contact;
}

export interface Comments {
    total: number;
    commentList: CommentList[];
}

export interface RootObjectOverallRating {
    statistics: Statistics;
    comments: Comments;
}
