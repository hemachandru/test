export class MyChannels {
    pagination: Pagination;
    results: ChannelDetail[];
}


export interface Pagination {
    limit: number;
    page: number;
    total: string;
}

export interface ChannelDetail {
    channelId: string;
    companyName: string;
    channelTypeId: string;
}
