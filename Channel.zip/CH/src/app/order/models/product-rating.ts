export interface EvaluationAttribute {
    ratingName: string;
}

export interface ProductRatingList {
    ratingId: string;
    evaluationAttribute: EvaluationAttribute;
}

export class EvaluateProductDetail {
    name: string;
    code: string;
    documentUrl: string;
    level: string;
    productId: number;
    sampleOrderId: number;
    userId: number;
    ratingAttribute: any;
    review: string;
}

// export class GetProductRating {
//     evaluationattribute: string;
//     totrating: number;
// }

export interface Rating {
    evaluationattribute: string;
    totrating: number;
    productevaluationratingid: number;
    ratingattributeid: number;
}

export class GetProductRating {
    review: string;
    rating: Rating[];
    productevaluationid: number;
}


