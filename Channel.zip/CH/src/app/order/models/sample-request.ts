import { float } from 'aws-sdk/clients/lightsail';

export class ShowHide {
    toggle: boolean;
}

export class PostOrderList {
    status: number[];
}

export class ConfirmDialogData {
    action: boolean;
    list: ProductEvaluationRating[];
    review: string;
    transfer: Transfer;
}

export interface ProductEvaluationRating {
    ratingattributeid: number;
    rating: number;
    productevaluationratingid?: number;
    productevaluationid?: number;
}

export class MultiSelectList {
    id: number;
    itemName: string;
    count?: any;
}

export class StatusId {

}

export class FilterDataList {
    status: StatusId;
}

/*
** Update Action
*/
export interface Shipment {
    name: string;
    trackingno: string;
    trackingurl: string;
    comments: string;
}

export interface OrderDetail {
    sampleorderdetailid: number;
    finalquantity: number;
}

export interface Order {
    shippingprice: number;
    discount: number;
    discountunitid: number;
    othercharge: number;
    orderDetail: OrderDetail[];
}

export interface Transfer {
    to: string;
    channelId: number;
    userId?: number;
}


export class PostActionSeller {
    action: string;
    shipment: Shipment;
    order: Order;
    transfer: Transfer;
}

export interface StatusCount {
    status: string;
    statusid: string;
    count: string;
}

export interface StatusCountSeller {
    statusid: StatusDetailCount;
}

export interface StatusDetailCount {
    status: string;
    count: number;
}

export class EmitUpdateQtyData {
    qty: number;
    total: float;
    action: boolean;
    cancel: CancelOrderData;
}

export interface CancelOrderData {
    cancelBool: boolean;
    orderNo: string;
    buyerChannelId: number;
}

