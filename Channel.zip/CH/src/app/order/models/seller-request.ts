export interface Pagination {
    limit: number;
    page: number;
    total: string;
}

export interface Buyerchannel {
    channelId: number;
    companyName: string;
    planId: number;
}

export interface Result {
    sampleorderid: string;
    currencyid: string;
    ordernumber: string;
    userid: string;
    sellerchannelid: string;
    buyerchannelid: string;
    orderdate: Date;
    requestfreesample: string;
    ordertotalprice: string;
    statusid: string;
    buyerchannel: Buyerchannel;
    no_of_items: string;
    total_quantities: string;
    invoiced: string;
    ordered_quantities: string;
    ordered_price: string;
}

export interface SellerRequestObject {
    pagination: Pagination;
    results: Result[];
}

/*
** ORDER DETAIL
*/
export interface Country {
    countryId: string;
    country: string;
    deletedAt?: any;
}

export interface Shippingaddress {
    addressid: string;
    name: string;
    address: string;
    city: string;
    countryid: string;
    postalcode: string;
    contactno1: string;
    contactno2: string;
    country: Country;
}

export interface Country2 {
    countryId: string;
    country: string;
    deletedAt?: any;
}

export interface Billingaddress {
    addressid: string;
    name: string;
    address: string;
    city: string;
    countryid: string;
    postalcode: string;
    contactno1: string;
    contactno2: string;
    country: Country2;
}

export interface Country3 {
    country: string;
}

export interface Document {
    documentUrl: string;
    documentPath: string;
}

export interface Contact {
    channelId: string;
    firstName: string;
    lastName: string;
    jobTitle: string;
    countryId: string;
    documentId: string;
    country: Country3;
    document: Document;
    relation?: any;
}

export interface Code {
    code: string;
    id: number;
    type: string;
}

export interface Retailer {
    margin_price: number;
    margin_unit: string;
}

export interface Currency {
    code: string;
    id: string;
}

export interface Sample {
    unit: string;
    price: string;
}

export interface Distributor {
    margin_price: number;
    margin_unit: string;
}

export interface Retail {
    unit: string;
    price: string;
}

export interface Price {
    is_sample_free: boolean;
    is_unlimited_sample: boolean;
    retailer: Retailer;
    currency: Currency;
    sample_threshold: string;
    sample: Sample;
    distributor: Distributor;
    retail: Retail;
}

export interface Company {
    name: string;
    id: number;
}

export interface Brand {
    name: string;
    id: number;
}

export interface ProductFamily {
    name: string;
    id: number;
}

export interface Others {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Primary {
    documentUrl: string;
    documentId: string;
    documentPath: string;
}

export interface Images {
    others: Others[];
    primary: Primary[];
}

export interface Preference {
    name: string;
    id: number;
}

export interface Location {
    name: string;
    id: number;
}

export interface Target {
    locations: Location[];
}

export interface Location2 {
    name: string;
    id: number;
}

export interface Selling {
    locations: Location2[];
}

export interface ProductCategory {
    name: string;
    id: number;
}

export interface Product {
    avaialble_from?: any;
    codes: Code[];
    has_variant: boolean;
    created_at: Date;
    usp: string;
    updated_at: Date;
    price: Price;
    company: Company;
    id: number;
    is_avaialble_immediate: boolean;
    sku: string;
    brand: Brand;
    productdesc: string;
    product_family: ProductFamily[];
    images: Images;
    is_active: boolean;
    company_id: number;
    preference: Preference[];
    avaialbility_comment?: any;
    deleted_at?: any;
    quality: string;
    target: Target;
    urlkey: string;
    can_view_free_plan_members: boolean;
    name: string;
    selling: Selling;
    variantdetails?: any;
    product_category: ProductCategory[];
}

export interface OrderDetail {
    sampleorderdetailid: string;
    sampleorderid: string;
    productid: string;
    quantity: string;
    finalquantity: string;
    samplepriceperquantity: string;
    finaltotalprice: string;
    totalprice: string;
    createdat: Date;
    updatedat?: any;
    deletedat?: any;
    product: Product;
    evaluated: boolean;
}

export interface OrderDetailObject {
    sampleorderid: string;
    ordernumber: string;
    userid: string;
    sellerchannelid: string;
    buyerchannelid: string;
    billingaddressid: string;
    shippingaddressid: string;
    statusid: string;
    currencyid: string;
    subtotalprice: string;
    shippingprice: string;
    discount: string;
    discountunitid?: any;
    othercharge: string;
    ordertotalprice: string;
    paymenttranscationid?: any;
    requestfreesample: string;
    comments?: any;
    orderdate: Date;
    updatedat?: any;
    buyerchannel: Buyerchannel;
    shippingaddress: Shippingaddress;
    billingaddress: Billingaddress;
    contact: Contact;
    shipments: any[];
    orderDetails: OrderDetail[];
    sellerchannel: Sellerchannel;
    paymentTranscation: PaymentTranscation;
    seller_contact: SellerContact;
}

export interface SellerContact {
    firstName: string;
    lastName: string;
}

export interface PaymentTranscation {
    paymentTransactionId: number;
    paymentTransactionAt: Date;
    transactionNumber: string;
    cardType: string;
    cardLastFourDigit: string;
    currencyid: string;
}

export interface Country {
    countryId: string;
    country: string;
    deletedAt?: any;
    isVat: string;
    registrationcertificate?: any;
    phoneCode: string;
    isoCode: string;
}

export interface RegAddress {
    addressId: string;
    address: string;
    city: string;
    countryId: string;
    postalCode: string;
    country: Country;
}

export interface ChannelLogo {
    documentUrl: string;
    documentPath: string;
}

export interface ChannelDetail {
    channelLogoId: string;
    phone1: string;
    phone2?: any;
    mobileNo?: any;
    webSiteUrl: string;
    channelLogo: ChannelLogo;
}

export interface Sellerchannel {
    channelId: string;
    channelTypeId: string;
    companyName: string;
    planId: string;
    regAddress: RegAddress;
    channelDetail: ChannelDetail;
}

export interface ChannelLogo {
    documentUrl: string;
    documentPath: string;
}

export interface ChannelDetail {
    channelLogoId: string;
    channelLogo: ChannelLogo;
}

export interface Buyerchannel {
    channelDetail: ChannelDetail;
}

// export interface Sellerchannel {
//     channelDetail: ChannelDetail;
// }


/*
** Order detail cart list
*/
export interface ProductGroup {
    productGroup: string;
}

export interface ProductCategory {
    productCategorie: string;
}

export interface Brand {
    brandName: string;
}

export interface Image {
    documentUrl: string;
    documentPath: string;
}

export interface DefaultImage {
    productimageid: string;
    productId: string;
    imageid: string;
    productimagetype: string;
    sortorder: string;
    updatedby: string;
    deletedat?: any;
    image: Image;
}

export interface Product {
    productId: string;
    product: string;
    productSKU: string;
    productGroupId: string;
    productCategorieId: string;
    brandId: string;
    defaultimageid: string;
    productGroup: ProductGroup;
    productCategory: ProductCategory;
    brand: Brand;
    defaultImage: DefaultImage;
}

export interface Retailerpriceunitdetail {
    unitid: string;
    unit: string;
}

export interface Distributorunitdetail {
    discountUnitId: string;
    discountUnit: string;
}

export interface Retailerunitdetail {
    discountUnitId: string;
    discountUnit: string;
}

export interface OrderCartDetailObject {
    sampleorderdetailid: string;
    sampleorderid: string;
    productid: string;
    retailerprice: string;
    retailerpriceunitid: string;
    distributormarginpercent: string;
    distributormarginpercentunitid: string;
    retailermarginpercent: string;
    retailermarginpercentunitid: string;
    quantity: string;
    finalquantity: string;
    samplepriceperquantity: string;
    finaltotalprice: string;
    totalprice: string;
    product: Product;
    retailerpriceunitdetail: Retailerpriceunitdetail;
    distributorunitdetail: Distributorunitdetail;
    retailerunitdetail: Retailerunitdetail;
}

