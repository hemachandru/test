import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RatingDetailViewComponent } from './rating-detail-view/rating-detail-view.component';
import { OverallRatingComponent } from './overall-rating/overall-rating.component';

import { SampleRequestComponent } from '@app/order/sample-request/sample-request.component';
import { SampleRequestBuyerComponent } from '@app/order/sample-request-buyer/sample-request-buyer.component';
import { CartListOrderComponent } from '@app/order/cart-list-order/cart-list-order.component';
import { ConfirmRequestComponent } from '@app/order/confirm-request/confirm-request.component';

import { OrderRoutingModule } from '@app/order/order-routing-module';
import { SharedModule } from '@app/shared/shared.module';
import { OrderServiceService } from '@app/order/service/order-service.service';
import { MatDialogModule } from '@angular/material';
import { MyDateRangePickerModule } from 'mydaterangepicker';
import { SlimScrollModule } from 'ng2-slimscroll';

export const COMPONENTS = [
  RatingDetailViewComponent,
  SampleRequestComponent,
  CartListOrderComponent,
  SampleRequestBuyerComponent,
  ConfirmRequestComponent,
  OverallRatingComponent
];

@NgModule({
  imports: [
    CommonModule,
    OrderRoutingModule,
    SharedModule,
    MatDialogModule,
    FormsModule,
    MyDateRangePickerModule,
    SlimScrollModule
   ],
  declarations: COMPONENTS,
  providers: [OrderServiceService],
  entryComponents: [ConfirmRequestComponent, SampleRequestComponent]
})
export class OrderModule { }
