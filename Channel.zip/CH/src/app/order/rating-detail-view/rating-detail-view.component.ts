import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { NoDataFound } from '@app/shared/models/shared-model';
import { ChannelTypeIdEnum } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { LocationMapComponent } from '@app/shared/shared-component/location-map/location-map.component';
import { OrderServiceService } from '@app/order/service/order-service.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-rating-detail-view',
  templateUrl: './rating-detail-view.component.html',
  styleUrls: ['./rating-detail-view.component.scss']
})
export class RatingDetailViewComponent implements OnInit {
  public _NoDataFound: NoDataFound;
  public title = 'order.VentorTitleRating';
  public rating = 0;
  public productRatingDetail;
  public productRatingComment;
  public productRatingStatictis;
  public commentTotal;
  public commentList: Array<any>;
  public ratingList: Array<any>;
  public channelStatistic;
  public channelCountryStatistic;
  public preloader = false;
  public productId;
  public countryData;
  public _channelTypeEnum = ChannelTypeIdEnum;
  public productID: number; // need to remove;
  public channelId: number;
  @ViewChild(LocationMapComponent) locationMapComponent: LocationMapComponent;

  public pieChartLabels: string[] = [];
  public pieChartData: number[] = [];
  public pieChartType: string;
  public chartColors: any[] = [{
    backgroundColor: ['#37B4A9', '#004878', '#337ab7', '#FFFCC4', '#B9E8E0']
  }];
  public pieChartOptions;
  // public pieChartLabels: string[];
  // public pieChartData: number[];
  // public pieChartType = 'pie';
  noresult: boolean;
  public empty: string;

  constructor(public _OrderService: OrderServiceService, private translate: TranslateService,
    private route: ActivatedRoute, private _location: Location) {
    this._NoDataFound = new NoDataFound();
    this.commentList = [];
    this.ratingList = [];
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
  }

  ngOnInit() {
    this.pieChartType = 'pie';
    this._NoDataFound.noDataMsg = this.translate.instant('productView.noProduct');
    this.getChannelCompanyID();
    this.empty = '../assets/images/no-product.png';
    this.pieChartOptions = {
      tooltips: {
        enabled: true,
        mode: 'single',
        callbacks: {
          label: function (tooltipItem, data) {
            const allData = data.datasets[tooltipItem.datasetIndex].data;
            const tooltipLabel = data.labels[tooltipItem.index];
            const tooltipData = allData[tooltipItem.index];
            const isInt = tooltipData % 1 === 0;
            const labeldisplay = (isInt) ? tooltipData + '%' : tooltipData.toFixed(2) + '%';
            return tooltipLabel + ': ' + labeldisplay;
          }
        }
      },
      labels: {

      }
    };
  }

  // Get Product Id in params
  getChannelCompanyID() {
    this.route.params.subscribe(
      (params: any) => {
        this.productId = parseInt(params.id, 10);
        this.getProductRatingList(this.productId);
        this.productID = this.productId;
      },
      (error) => {
        console.log(error);
      });
  }

  // Get Product rating detail
  getProductRatingList(productId) {
    this.preloader = true;
    this._OrderService.getProductRatingDetails(productId).subscribe(response => {
      const result = response;
      if (result) {
        this.getProductRatingComment(this.productId);
        this.getProductRatingStatictis(this.productId);
        this.productRatingDetail = result;
        this.preloader = false;
      }
    }, (error) => {
      this.noresult = true;
      console.log(error);
    });
  }

  // Get Product rating detail
  getProductRatingComment(productId) {
    this.preloader = true;
    this._OrderService.getProductRatingComment(productId).subscribe(response => {
      const result = response;
      if (result) {
        this.productRatingComment = result;
        this.commentTotal = this.productRatingComment.total;
        this.commentList = this.productRatingComment.commentList;
        this.preloader = false;
      }
    }, (error) => {
      console.log(error);
    });
  }

  // Get Product rating STATICTIS
  getProductRatingStatictis(productId) {
    this.preloader = true;
    this._OrderService.getProductRatingStatictis(productId).subscribe(response => {
      const result = response;
      if (result) {
        this.productRatingStatictis = result;
        this.ratingList = this.productRatingStatictis.ratingtotal;
        this.channelStatistic = this.productRatingStatictis.channel;
        this.channelCountryStatistic = this.productRatingStatictis.country;
        if (this.channelStatistic) {
          // this.pieChartLabels = result.channel.map(item => {
          //   return item.channelType;
          // });

          // this.pieChartData = result.channel.map(item => {
          //   return item.perc;
          // });
          let index = 0;
          this.channelStatistic.forEach(item => {
            if (item.channelTypeId === 2) {
              this.pieChartData[index] = item.perc;
              this.pieChartLabels[index] = item.channelType;
            } if (item.channelTypeId === 3) {
              this.pieChartData[index] = item.perc;
              this.pieChartLabels[index] = item.channelType;
            } if (item.channelTypeId === 4) {
              this.pieChartData[index] = item.perc;
              this.pieChartLabels[index] = item.channelType;
            }
            index++;
          });
        } else {
          // this.empty = '../assets/images/no-product.png';
        }
        if (this.channelCountryStatistic) {
          this.countryData = this.channelCountryStatistic.map(item => ({ country: item.country }));
          this.locationMapComponent.setMap(this.countryData);
        } else {
          // this.empty = '../assets/images/no-product.png';
        }

        this.preloader = false;
      }
    }, (error) => {
      console.log(error);
    });
  }

  /** history back */
  backClicked() {
    this._location.back();
  }

}
