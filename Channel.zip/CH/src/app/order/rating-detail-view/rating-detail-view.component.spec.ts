import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatingDetailViewComponent } from './rating-detail-view.component';

describe('RatingDetailViewComponent', () => {
  let component: RatingDetailViewComponent;
  let fixture: ComponentFixture<RatingDetailViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatingDetailViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatingDetailViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
