import { Component, OnInit, Input, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Response } from '@angular/http';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { SampleRequestAction, ChannelTypeIdEnum } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { RootObjectContact, UpdateDefaultContact } from '@app/shared/models/contact-list-models';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { ConfirmDialogData } from './../models/sample-request';
import { OrderServiceService } from '../service/order-service.service';
import { MyChannels, ChannelDetail } from './../models/my-channels';
import { Transfer, PostActionSeller } from '../models/sample-request';

@Component({
  selector: 'app-confirm-request',
  templateUrl: './confirm-request.component.html',
  styleUrls: ['./confirm-request.component.scss']
})
export class ConfirmRequestComponent implements OnInit {
  public confirmForm: FormGroup;
  public _ConfirmDialogData = new ConfirmDialogData();
  // public _ContactList = new RootObjectContact();
  // public _ContactlistFilter = new ContactList();
  // public _ContactData = new ContactListPost();
  public opts: ISlimScrollOptions;
  public _colorCode: boolean;
  public _UpdateDefaultContact = new UpdateDefaultContact();
  public reviewRating;
  public sampleRequestAction;
  public selectedChannelTypeId: number;
  public channelDetails: Array<ChannelDetail>;
  public selectedChanelDetail: ChannelDetail;
  public preLoader: boolean;
  public transferOptionText: string;
  public transferOptionValue: string;

  constructor(private fb: FormBuilder, public dialog: MatDialog,
    public dialogRef: MatDialogRef<ConfirmRequestComponent>,
    private sharedBusiness: SharedBusiness, public orderServiceService: OrderServiceService,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.sampleRequestAction = SampleRequestAction;
    this.selectedChannelTypeId = 0;
    this.selectedChanelDetail = null;
    this.preLoader = false;
  }

  ngOnInit() {
    this.transferOptionText = 'companyName';
    this.transferOptionValue = 'channelId';
    this._colorCode = true;
    this.reviewRating = [1, 1, 1, 1, 1];
    this.opts = {
      barBackground: 'rgba(132, 136, 132, 0.8)',
      gridBackground: 'rgba(77, 77, 77, 0.27)',
      barBorderRadius: '10px',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this._ConfirmDialogData.list = [];
    // this._ConfirmDialogData.dismissId =  0;
    // this._ConfirmDialogData.others = '';
    document.getElementsByTagName('html').item(0).style.setProperty('top', '0px');
    this.confirmForm = this.fb.group({
      review: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      reasonControl: []
    });
    if (this.data.action === this.sampleRequestAction.VIEWREPORT
      || this.data.action === this.sampleRequestAction.EVALUATE_UPDATE) {
        this.confirmForm.controls['review'].setValue(this.data.list.ratingAttribute.review);
      }
  }

  evaluateRating() {
    let index = 0;
    let evaluatedList;
    if (this.data.action.toUpperCase() === SampleRequestAction.EVALUATE.toUpperCase() ) {
      evaluatedList = this.data.list.ratingAttribute;
      evaluatedList.forEach(item => {
        this._ConfirmDialogData.list.push({ 'ratingattributeid': parseInt(item.ratingId, 10), 'rating': this.reviewRating[index] });
        index++;
      });
      // this._ConfirmDialogData.list = evaluatedList;
    } else {
      evaluatedList = this.data.list.ratingAttribute.rating;
      evaluatedList.forEach(item => {
        this._ConfirmDialogData.list.push(
          {
            'ratingattributeid': parseInt(item.ratingattributeid, 10),
            'rating': item.totrating,
            'productevaluationid': parseInt(this.data.list.ratingAttribute.productevaluationid, 10),
            'productevaluationratingid': item.productevaluationratingid
           });
        index++;
      });
      // this._ConfirmDialogData.list = evaluatedList;
    }
    console.log(this._ConfirmDialogData.list);
    // this._ConfirmDialogData.list = this.data.list.ratingAttribute;
    this._ConfirmDialogData.review = this.confirmForm.controls['review'].value;
  }

  ontransferMyDistributorsChange(event) {
    if (event.target.checked) {
      this.selectedChannelTypeId = ChannelTypeIdEnum.DISTRIBUTOR;
    } else {
      this.selectedChannelTypeId = 0;
    }
    this.callGetMyChannels('');
  }

  onTransferOptionSelected(data: ChannelDetail) {
    this.selectedChanelDetail = data;
  }

  onSearchTextEntered(searchText: string) {
    if (searchText && searchText.length > 0) {
      this.callGetMyChannels(searchText);
    } else {
      this.selectedChanelDetail = null;
    }
  }

  callGetMyChannels(searchText: string) {
    if (this.selectedChannelTypeId > 0) {
      this.preLoader = true;
      this.orderServiceService.getMyChannels(this.selectedChannelTypeId, searchText, this.data.transferBuyerId).subscribe(response => {
        const _response = <Response>response;
        if (_response.ok) {
          const myChannels = _response.json() as MyChannels;
          this.channelDetails = myChannels.results;
        }
        this.preLoader = false;
      },
        (error) => {
          console.log(error);
          this.preLoader = false;
        });
    } else {
      delete this.channelDetails;
    }
  }

  onTransferNoDataClicked() {
    this.selectedChanelDetail = null;
  }

  onConfirm() {
    this._ConfirmDialogData.action = true;
    if (this.data.action.toUpperCase() === SampleRequestAction.TRANSFER.toUpperCase()) {
      const transfer = <Transfer>{
        'to': 'MY_DISTRIBUTOR',
        'channelId': parseInt(this.selectedChanelDetail.channelId, 10)
      };
      this._ConfirmDialogData.transfer = transfer;
    } else if (this.data.action.toUpperCase() === SampleRequestAction.EVALUATE.toUpperCase() ||
    this.data.action.toUpperCase() === SampleRequestAction.EVALUATE_UPDATE.toUpperCase()) {
      if (this.data.list && this.confirmForm.controls['review'].valid) {
        this.evaluateRating();
      } else {
        this.confirmForm.controls['review'].markAsTouched();
        return false;
      }
    }
    console.log(this._ConfirmDialogData);
    this.dialogRef.close(this._ConfirmDialogData);
  }
}
