import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartListOrderComponent } from './cart-list-order.component';

describe('CartListOrderComponent', () => {
  let component: CartListOrderComponent;
  let fixture: ComponentFixture<CartListOrderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartListOrderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartListOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
