import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import {
  SampleRequestObj, RequestStatus, SampleRequestAction, Config, StripeCardType,
  CurrencyType, SampleCartCalculation, DialogConfirmMessage, PopUpTitle
} from '@app/config/constant';
import { OrderServiceService } from '@app/order/service/order-service.service';
import { BuyerOrderList, OrderDetailObject, PostAction, Evaluate, UpdateEvaluate } from './../models/buyer-request';
import { PostActionSeller, Order, OrderDetail, Shipment, EmitUpdateQtyData, CancelOrderData } from './../models/sample-request';
import { ProductRatingList, EvaluateProductDetail, GetProductRating } from './../models/product-rating';
import { ConfirmRequestComponent } from '../../order/confirm-request/confirm-request.component';
import { TranslateService } from '@ngx-translate/core';
import { RequestSuggestionComponent } from '@app/shared/shared-component/request-suggestion/request-suggestion.component';
import { ProductService } from '@app/product/service/product-service.service';
import { FavoriteCountService } from '@app/shared/shared-service/product-favorite-count';
import { ProductDismissReasons, ProductRejectObject } from '@app/product/models/product-view';
import { ProductRejectReasonComponent } from '@app/shared/shared-component/product-reject-reason/product-reject-reason.component';
import { RejectInput } from '@app/shared/models/shared-model';

@Component({
  selector: 'app-cart-list-order',
  templateUrl: './cart-list-order.component.html',
  styleUrls: ['./cart-list-order.component.scss']
})
export class CartListOrderComponent implements OnInit {
  shipmentForm: FormGroup;
  public _OrderCartDetailObject: OrderDetailObject;
  public _ProductRatingList: ProductRatingList;
  public _EvaluateProductDetail = new EvaluateProductDetail();
  public _PostAction: PostAction;
  public _PostActionSeller: PostActionSeller;
  public boolAction: boolean;
  public boolQtyValidate: boolean;
  public _RequestStatus;
  public sampleRequestAction;
  public _GetProductRating: GetProductRating;
  public _StripeCardType;
  public _CurrencyType = CurrencyType;
  private apiUrl = ApiUrl;
  public _EmitUpdateQtyData;
  public subtotalCalc;
  public preLoader: boolean;
  public currencySymbol = '';
  public _SampleCartCalculation = SampleCartCalculation;
  public booleanDiscount: boolean;
  public booleanShipping: boolean;
  public booleanOthers: boolean;
  public userChannelId;
  public qtyCheck: boolean;
  public _DismissReasons: Array<ProductDismissReasons>;
  public _ProductDismissReasons: ProductRejectObject;

  constructor(private toastr: ToastrService, private Const: Config, private router: Router,
    private productService: ProductService, private favoriteCountService: FavoriteCountService,
    public dialog: MatDialog, public _OrderService: OrderServiceService, private fb: FormBuilder, private translate: TranslateService) {
    this._OrderCartDetailObject = new OrderDetailObject();
    this._RequestStatus = RequestStatus;
  }

  @Input() set cart(value: OrderDetailObject) {
    this._OrderCartDetailObject = value;
    let subtotalprice = 0;
    this._OrderCartDetailObject.orderDetails.forEach(item => {
      subtotalprice = parseFloat(item.quantity) * parseFloat(item.samplepriceperquantity) + subtotalprice;
      item.orginQty = item.quantity;
    });
    this.subtotalCalc = subtotalprice.toFixed(2);
    this.currencySymbol = this._CurrencyType[this._OrderCartDetailObject.currencyid].symbol;
  }

  @Input() sellerFlag: Boolean;
  @Input() evaluateFlag: Boolean;
  @Input() orderNumber: string;
  @Input() statusId: number;
  @Input() invoiced: string;
  @Input() transferred: string;
  @Input() requestfreesample: number;
  @Output() flagUpdateOrder = new EventEmitter();
  @Output() EvaluateProduct = new EventEmitter();


  ngOnInit() {
    this._PostAction = new PostAction();
    this._PostActionSeller = new PostActionSeller();
    // const dfdfd = new GetProductRating();
    this._GetProductRating = new GetProductRating();
    this._EmitUpdateQtyData = new EmitUpdateQtyData();
    this._EmitUpdateQtyData.cancel = {};
    this.boolAction = true;
    this.boolQtyValidate = true;
    this._EmitUpdateQtyData.qty = 0;
    this._EmitUpdateQtyData.total = 0;
    this._EmitUpdateQtyData.action = this.boolAction;
    this._EmitUpdateQtyData.cancel.cancelBool = false;
    this._EmitUpdateQtyData.cancel.orderNo = '';
    this._EmitUpdateQtyData.cancel.buyerChannelId = 0;
    this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
    this._RequestStatus = RequestStatus;
    this._StripeCardType = StripeCardType;
    this.userChannelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);

    this.getEvaluationAttr();
    this.shipmentForm = this.fb.group({
      name: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      trackno: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
      // tslint:disable-next-line:max-line-length
      trackurl: ['', Validators.compose([Validators.required,
        //  Validators.pattern(this.Const.urlPatternWithHttp)
         , Validators.maxLength(255)])],
      comments: ['', Validators.compose([Validators.required, Validators.maxLength(255)])],
    });
    this.sampleRequestAction = SampleRequestAction;
    this.preLoader = false;
    this.booleanDiscount = false;
    this.booleanShipping = false;
    this.booleanOthers = false;
    this.qtyCheck = true;
  }

  public urlFormatting(unFormattedUrl) {
    if (unFormattedUrl.indexOf('http')) {
      return '//' + unFormattedUrl;
    } else {
      return unFormattedUrl;
    }
  }

  public getDataShipment() {
    return <Shipment>{
      'name': this.shipmentForm.controls['name'].value,
      'trackingno': this.shipmentForm.controls['trackno'].value,
      'trackingurl': this.urlFormatting(this.shipmentForm.controls['trackurl'].value),
      'comments': this.shipmentForm.controls['comments'].value,
    };
  }

  openDialogEvaluate(product, order, userId) {
    this.OpenConfirmDialog(this.sellerFlag ? 'Review' : 'Submit Review', '', product, order, userId);
  }

  getEvaluationAttr() {
    const url: any = this.apiUrl.EVALUATION_ATTRIBUTE + '/PRODUCT';
    this._OrderService.getService(url, true).subscribe(response => {
      // const evaluationlist = response as Response;
      this._ProductRatingList = response.json();
    });
  }

  getEvaluatedRating(cartlist) {
    this.preLoader = true;
    const productId = cartlist.productid;
    // const contactId = this._OrderCartDetailObject.userid;
    const orderDetailId = cartlist.sampleorderdetailid;
    const url: any = this.apiUrl.PRODUCT_EVALUATE + '/' + productId + '/' + this.apiUrl.ORDER_DETAIL_ID + '/' + orderDetailId;
    // const url: any = this.apiUrl.PRODUCT_EDIT_EVALUATE + '/' + productId + '/' + this.apiUrl.ORDER_DETAILS + '/' + orderDetailId;
    this._OrderService.getService(url, true).subscribe(response => {
      this.preLoader = false;
      // const orderDetail = response as Response;
      this._GetProductRating = response.json();
      this.openDialogEvaluate(cartlist.product, cartlist, this._OrderCartDetailObject.userid);
    });
  }

  private OpenConfirmDialog(title: string, message: string, product, order, userId) {
    this._EvaluateProductDetail.ratingAttribute = this.sellerFlag ||
    !this.sellerFlag && order.evaluated ? this._GetProductRating : this._ProductRatingList;
    this._EvaluateProductDetail.name = product.company.name;
    this._EvaluateProductDetail.code = product.codes[0].code;
    this._EvaluateProductDetail.level = product.quality;
    this._EvaluateProductDetail.documentUrl = product.images.primary.length ? product.images.primary[0].documentUrl : '';
    this._EvaluateProductDetail.productId = parseInt(order.productid, 10);
    this._EvaluateProductDetail.sampleOrderId = parseInt(order.sampleorderdetailid, 10);
    this._EvaluateProductDetail.userId = parseInt(userId, 10);

    const dialogRef = this.dialog.open(ConfirmRequestComponent, {
      data: {
        title: title,
        message: message,
        list: this._EvaluateProductDetail,
        action: this.sellerFlag  ? SampleRequestAction.VIEWREPORT : order.evaluated ?
        SampleRequestAction.EVALUATE_UPDATE : SampleRequestAction.EVALUATE
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        if (!order.evaluated) {
          this.updateEvaluate(responseType, order);
        } else {
          this.updateProductEvaluation(responseType, order, this._GetProductRating.productevaluationid);
        }
      }
    });
  }

  // Update Evaluation
  updateProductEvaluation(response, order, evaluationId) {
     this._PostAction.action = 'EVALUATE';
    const url: any = this.apiUrl.UPDATE_PRODUCT_EVALUATION; // + this._OrderCartDetailObject.ordernumber;
    this._PostAction.evaluate = <UpdateEvaluate>{
      'sampleorderdetailid': this._EvaluateProductDetail.sampleOrderId,
      'productid': this._EvaluateProductDetail.productId,
      'evaluatedby': this._EvaluateProductDetail.userId,
      'review': response.review,
      'productEvaluationRating': response.list,
      'productevaluationid': parseInt(evaluationId, 10),
    };
    this.preLoader = true;
    this._OrderService.putService(this._PostAction.evaluate, url, true).subscribe(res => {
      const orderaction = res as Response;
      this.preLoader = false;
      if (orderaction.ok) {
        this.toastr.success(this.translate.instant('cart.productEvaluated'));
      }
    });
  }

  updateEvaluate(response, order) {
    this._PostAction.action = 'EVALUATE';
    const url: any = this.apiUrl.SAMPLE_BUYER_ACTION + '/' + this.orderNumber; // + this._OrderCartDetailObject.ordernumber;
    this._PostAction.evaluate = <Evaluate>{
      'sampleorderdetailid': this._EvaluateProductDetail.sampleOrderId,
      'productid': this._EvaluateProductDetail.productId,
      'evaluatedby': this._EvaluateProductDetail.userId,
      'review': response.review,
      'productEvaluationRating': response.list
    };
    this.preLoader = true;
    this._OrderService.postService(this._PostAction, url, true).subscribe(res => {
      const orderaction = res as Response;
      if (orderaction.ok) {
        this.toastr.success(this.translate.instant('cart.productEvaluated'));
        order.evaluated = true;
        this.EvaluateProduct.emit(true);
        this.getDismissReasonList();
        this.OpenRequestDialig(this._EvaluateProductDetail.productId, true);
      }
      this.preLoader = false;
    });
  }

  private OpenRequestDialig(productId, order) {
    const title = 'sharedcomponentText.reviewTitle';
    const dialogRef = this.dialog.open(RequestSuggestionComponent, {
      data: {
        title: this.translate.instant(title),
        type: 2,
        // message: this.translate.instant(message),
        message: 'message',
        order: order
      },
      panelClass: 'modalPointer'
    });

    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        if (responseType.status === 1) {
          this.addToBusiness(productId);
        } else if (responseType.status === 3) {
          this.productDismissReasons();
        } else {
          this.toastr.success(this.translate.instant('sharedcomponentText.toastr.successEvaluate'));
        }
      }
    });
  }

  /** Add to Business */

  addToBusiness(productId) {
    const productid = parseInt(productId, 10);
    const addFavoriteData = {
      'id': productid,
      'from_type': 'EVALVATED',
      'to_type': 'BUSINESS'
    };

    this.productService.addToBusiness(addFavoriteData).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        // const result = response.json();
        this.toastr.success(this.translate.instant('sharedcomponentText.toastr.successBusiness'));
        this.getFavoriteCount();
        this.EvaluateProduct.emit(true);
      } else {
        this.toastr.error('error');
      }
    });
  }

  // Favorite count
  getFavoriteCount() {
    this.productService.getFavoriteCount().subscribe(res => {
      if (res.status) {
        const favoriteCount = res.count;
        this.favoriteCountService.favoriteCountDetailChange(favoriteCount);
      } else {
        console.log('add to cart ' + res);
      }
    });
  }

  orderChangeEvent() {
    this.boolAction = false;
    let subtotalprice = 0;
    let totalQty = 0;
    let qtyCheckValidate = 0;
    this._EmitUpdateQtyData.cancel.cancelBool = false;
    this._OrderCartDetailObject.orderDetails.forEach(item => {
      if (item.finalquantity !== '' && parseInt(item.finalquantity, 10) <= parseInt(item.orginQty, 10) && !item.boolQty) {
        if (item.finalquantity !== '0') {
          qtyCheckValidate++;
        }
        this.boolQtyValidate = true;
        const finaltotal = parseInt(item.finalquantity, 10) * parseFloat(item.samplepriceperquantity);
        item.finaltotalprice = finaltotal.toFixed(2);
        subtotalprice = parseFloat(item.finalquantity) * parseFloat(item.samplepriceperquantity) + subtotalprice;
        totalQty = totalQty + parseInt(item.finalquantity, 10);
      } else {
        this.boolQtyValidate = false;
        return false;
      }
    });
    if (qtyCheckValidate > 0) {
      this.qtyCheck = true;
    } else {
      this.qtyCheck = false;
    }
    if (this.boolQtyValidate && !this.booleanDiscount && !this.booleanShipping && !this.booleanOthers) {
      this._OrderCartDetailObject.subtotalprice = subtotalprice.toFixed(2);
      let total = subtotalprice + parseFloat(this._OrderCartDetailObject.shippingprice)
        + parseFloat(this._OrderCartDetailObject.othercharge);
      const discountValue = subtotalprice * parseFloat(this._OrderCartDetailObject.discount) / 100;
      total = total - discountValue;
      this._OrderCartDetailObject.ordertotalprice = total.toFixed(2);
    }
    this._EmitUpdateQtyData.qty = 0;
    this._EmitUpdateQtyData.total = 0;
    this._EmitUpdateQtyData.action = this.boolAction;
    this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
  }

  patternValidateQty(event, cartlist) {
    // event.target.value = event.target.value.replace('$', '');
    if (event.target.value.match('^((?!(00))(?!(0[1-9]))[0-9]+)$') === null) {
      // event.target.value = '';
      this.boolQtyValidate = false;
      this._EmitUpdateQtyData.action = this.boolQtyValidate;
      this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
      cartlist.boolQty = true;
        this._SampleCartCalculation.QUANTITY = this._SampleCartCalculation.QUANTITY_VALID;
    } else if ( parseInt(event.target.value, 10) > parseInt(cartlist.orginQty, 10))  {
      this._SampleCartCalculation.QUANTITY = this._SampleCartCalculation.QUANTITY_GREATER;
      this.boolQtyValidate = false;
      this._EmitUpdateQtyData.action = this.boolQtyValidate;
      this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
      cartlist.boolQty = true;
    }  else {
      // this.boolQtyValidate = true;
      this.orderChangeEvent();
      cartlist.boolQty = false;
    }
  }

  patternValidate(event, type) {
    if (event.target.value.match('^[0-9]*\.?[0-9]+$') === null && event.target.value !== ''
      || parseFloat(event.target.value) < 0 && event.target.value !== '') {
      this._EmitUpdateQtyData.action = false;
      this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
      if (type === 1) {
        this.booleanShipping = true;
      } else {
        this.booleanOthers = true;
      }
    } else {
      if (type === 1) {
        this.booleanShipping = false;
      } else {
        this.booleanOthers = false;
      }
      this.orderChangeEvent();
    }
  }

  patternValidateDiscount(event) {
    if (event.target.value.match('^[0-9]*\.?[0-9]+$') === null && event.target.value !== '' ||
      parseFloat(event.target.value) > 100 && event.target.value !== ''
      || parseFloat(event.target.value) < 0 && event.target.value !== '') {
      // event.target.value = '';
      this._EmitUpdateQtyData.action = false;
      this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
      this.booleanDiscount = true;
    } else {
      this.booleanDiscount = false;
      this.orderChangeEvent();
    }
  }

  updateOrder(_OrderCart: OrderDetailObject) {
    if (this.qtyCheck) {
      this.orderChangeEvent();
      this._PostActionSeller.action = 'UPDATE';
      const orderDetailList = Array<OrderDetail>();
      let totalQty = 0;
      _OrderCart.orderDetails.forEach(item => {
        orderDetailList.push({
          'sampleorderdetailid': parseInt(item.sampleorderdetailid, 10),
          'finalquantity': parseInt(item.finalquantity, 10)
        });
        totalQty = totalQty + parseInt(item.finalquantity, 10);
      });
      this._PostActionSeller.order = <Order>{
        'shippingprice': parseFloat(_OrderCart.shippingprice),
        'discount': parseFloat(_OrderCart.discount),
        'discountunitid': 1,
        'othercharge': parseFloat(_OrderCart.othercharge),
        'orderDetail': orderDetailList
      };
      const url: any = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS + '/' + this.orderNumber;
      this.preLoader = true;
      this._OrderService.postService(this._PostActionSeller, url, true).subscribe(response => {
        const orderaction = response as Response;
        this.preLoader = false;
        if (orderaction.ok) {
          this.boolAction = true;
          this._EmitUpdateQtyData.cancel.cancelBool = false;
          this.toastr.success(this.translate.instant('sampleRequest.orderUpdated'));
          this._EmitUpdateQtyData.qty = totalQty;
          this._EmitUpdateQtyData.total = this._OrderCartDetailObject.ordertotalprice;
          this._EmitUpdateQtyData.action = this.boolAction;
          this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
        } else {
          this.toastr.error(orderaction.json()[0].errors[0].message);
          this._EmitUpdateQtyData.action = false;
          this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
        }
      });
    } else {
      this.toastr.error(this.translate.instant('sampleRequest.cantupdatereject'));
      this._EmitUpdateQtyData.cancel.cancelBool = true;
      this._EmitUpdateQtyData.cancel.orderNo = this.orderNumber;
      this._EmitUpdateQtyData.cancel.buyerChannelId = _OrderCart.buyerchannelid;
      this.flagUpdateOrder.emit(this._EmitUpdateQtyData);
      // this.OpenConfirmDialog('Cancel', DialogConfirmMessage.cancel, 'CANCEL', this.orderNumber, _OrderCart.buyerchannelid );
    }

  }

  markFormGroupTouched(formGroup: FormGroup) {
    // (<any>Object).values(formGroup.controls).forEach(control => {
    for (const field in formGroup.controls) {
      const control = formGroup.get(field);
      /*if (control) { // control is a FormGroup
        this.markFormGroupTouched(control);
      } else { // control is a FormControl*/
      //this.markFormGroupTouched(formGroup);
      control.markAsTouched();
      // }
    }
  }

  overAllreport(productId: number) {
    this.router.navigate(['/order/overallrating/', productId]);
  }

  focusFunction(event: string, key: number = 0) {
    if (event === 'discount') {
      this._OrderCartDetailObject.discount = parseFloat(this._OrderCartDetailObject.discount).toString() !== 'NaN' ?
        parseFloat(this._OrderCartDetailObject.discount).toFixed(2) : this._OrderCartDetailObject.discount;
    } else if (event === 'ship') {
      // this._OrderCartDetailObject.shippingprice = this._OrderCartDetailObject.shippingprice.replace('$', '');
      this._OrderCartDetailObject.shippingprice = parseFloat(this._OrderCartDetailObject.shippingprice).toString() !== 'NaN' ?
        parseFloat(this._OrderCartDetailObject.shippingprice) : this._OrderCartDetailObject.shippingprice;
    } else if (event === 'other') {
      this._OrderCartDetailObject.othercharge = parseFloat(this._OrderCartDetailObject.othercharge).toString() !== 'NaN' ?
        parseFloat(this._OrderCartDetailObject.othercharge) : this._OrderCartDetailObject.othercharge;
    } else if (event === 'price') {
      this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity =
        parseFloat(this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity).toString() !== 'NaN' ?
          parseFloat(this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity) : '0';
    }
  }

  focusOutFunction(event: string, key: number = 0) {
    if (event === 'discount') {
      this._OrderCartDetailObject.discount = parseFloat(this._OrderCartDetailObject.discount).toString() !== 'NaN'
        ? parseFloat(this._OrderCartDetailObject.discount).toFixed(2) :
        this._OrderCartDetailObject.discount === '' ? '0.00' : this._OrderCartDetailObject.discount;
    } else if (event === 'ship') {
      this._OrderCartDetailObject.shippingprice = parseFloat(this._OrderCartDetailObject.shippingprice).
        toFixed(2) !== 'NaN' ? parseFloat(this._OrderCartDetailObject.shippingprice).toFixed(2) :
        this._OrderCartDetailObject.shippingprice === '' ? '0.00' : this._OrderCartDetailObject.shippingprice;
    } else if (event === 'other') {
      this._OrderCartDetailObject.othercharge = parseFloat(this._OrderCartDetailObject.othercharge).toFixed(2) !== 'NaN' ?
        parseFloat(this._OrderCartDetailObject.othercharge).toFixed(2) :
        this._OrderCartDetailObject.othercharge === '' ? '0.00' : this._OrderCartDetailObject.othercharge;
    } else if (event === 'price') {
      this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity =
        parseFloat(this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity).toFixed(2) !== 'NaN' ?
          parseFloat(this._OrderCartDetailObject.orderDetails[key].samplepriceperquantity).toFixed(2) : '0.00';
    }
    this.orderChangeEvent();
  }

  // DISMISS LIST
  getDismissReasonList() {
    this.productService.getProductDissmissList().subscribe(response => {
      this._DismissReasons = response;
    });
  }

  productDismissReasons() {
    this.OpenProductDismissDialog(this.translate.instant('sharedcomponentText.dismissProduct'), PopUpTitle['16']
      , this._DismissReasons, this._EvaluateProductDetail.productId);
  }

  private OpenProductDismissDialog(title: string, message: string, data: Array<ProductDismissReasons>, productId) {

    const dialogRef = this.dialog.open(ProductRejectReasonComponent, {
      data: {
        title: title,
        type: 2,
        message: this.translate.instant(message),
        list: data,
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      let dismissProduct;
      if (responseType.action === true) {
        this.preLoader = true;
        dismissProduct = <RejectInput>{
          'productId': parseInt(productId.toString(), 10),
          'rejectreasonId': parseInt(responseType.dismissId, 10),
        };
        if (responseType.dismissId === '7') {
          dismissProduct.comment = responseType.others;
        } else {
          dismissProduct.comment = '';
        }

        this.productService.productDismissReasons(dismissProduct).subscribe(response => {
          if (response.ok) {
            this.toastr.success(this.translate.instant('sharedcomponentText.toastr.productdelete'));
            this.getFavoriteCount();
            // this.getCartCount();
            // this.router.navigate(['channel/channellist']);
          } else {
            console.log('error' + response);
          }
          this.preLoader = false;
        });
      }
    });
  }

  // Link for Product Detail page
  gotoProductView(sku: string) {
    this.router.navigate(['order/buyerrequest/productview/', sku]);
  }

}
