import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';
import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';
import { RatingDetailViewComponent } from '@app/order/rating-detail-view/rating-detail-view.component';
import { OverallRatingComponent } from './overall-rating/overall-rating.component';
import { SampleRequestComponent } from '@app/order/sample-request/sample-request.component';
import { SampleRequestBuyerComponent } from '@app/order/sample-request-buyer/sample-request-buyer.component';
import { ViewProductComponent } from '@app/product/component/view-product/view-product.component';

const routes: Routes = [
  {
    path: 'order', children:
      [
        // {
        //   path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
        //   data: {
        //     currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
        //   }
        // },
        {
          path: 'overallrating/:id', component: OverallRatingComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'sellerrequest', component: SampleRequestComponent, canActivate: [AuthGuard],
          data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
          }
        },
        {
          path: 'buyerrequest', children:
            [
              {
                path: '', component: SampleRequestBuyerComponent, canActivate: [AuthGuard],
                data: {
                  currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                }
              },
              {
                path: 'productview/:id', children:
                  [
                    {
                      path: '', component: ViewProductComponent, canActivate: [AuthGuard],
                      data: {
                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                      }
                    },
                    {
                      path: 'rating/:id', component: RatingDetailViewComponent, canActivate: [AuthGuard],
                      data: {
                        currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
                      }
                    },
                  ]
              }
            ]
        },
      ]
  },
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: []
})

export class OrderRoutingModule {
}
