import { Component, OnInit, ViewChild } from '@angular/core';
import {
  SampleRequestObj, RequestStatus, SampleRequestAction, SampleRequestPreference, DialogConfirmMessage, ButtonTypes, ChannelTypeIdEnum,
  PopUpSuccessMsg, SubscriptionPlanDetails, SampleRequestBuyerObj, PopUpTitle, CurrencyType, ActionIconSampleRequest
} from '@app/config/constant';
import {
  ShowHide, PostOrderList, PostActionSeller, Order,
  MultiSelectList, FilterDataList, ConfirmDialogData, StatusCount, EmitUpdateQtyData
} from './../models/sample-request';

import { SellerRequestObject, OrderDetailObject } from './../models/seller-request';

import { Router } from '@angular/router';
import { HttpParams } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import * as jsPDF from 'jspdf';
import { ScrollToService } from 'ng2-scroll-to-el';
import { IMyDrpOptions } from 'mydaterangepicker';
import { Response, Http } from '@angular/http';
import { MatDialog, MatDialogRef } from '@angular/material';
import * as moment from 'moment';

import { ApiUrl, AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { UserAccountStatus, AccessPermissionEnum, RoleEnum, RoleIdEnum } from '@app/config/constant';
import { OrderServiceService } from '@app/order/service/order-service.service';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { NoDataFound } from '@app/shared/models/shared-model';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { CommonHelper } from '@app/shared/common-helper';
import { ConfirmRequestComponent } from '../../order/confirm-request/confirm-request.component';
import { CartListOrderComponent } from '../../order/cart-list-order/cart-list-order.component';
import { AuthorizeService } from '@app/shared/shared-service/authorize.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { Role } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { RequestSuggestionComponent } from '@app/shared/shared-component/request-suggestion/request-suggestion.component';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';

@Component({
  selector: 'app-sample-request',
  templateUrl: './sample-request.component.html',
  styleUrls: ['./sample-request.component.scss']
})
export class SampleRequestComponent implements OnInit {
  public webUrl = WebUrl;
  public filtershow: boolean;
  title: string;
  titlemsg: string;
  reviewRating: any;
  public statusDetail;
  public toggleObj: Array<ShowHide>;
  public actionCustomObj: Array<ShowHide>;
  public order;
  public orderStatusID: number;
  public _RequestStatus;
  public _PostOrderList = new PostOrderList();
  public _SellerRequestObject: SellerRequestObject;
  public _OrderDetailObject: OrderDetailObject;
  public _SubscriptionPlanDetails = SubscriptionPlanDetails;
  public _PostAction: PostActionSeller;
  public boolAction: boolean;
  public _ChannelTypeIdEnum = ChannelTypeIdEnum;
  public channelTypeId;
  dialogRef: MatDialogRef<MessageDialogComponent>;

  public AllStatus;
  public statusIdList;
  public datefilterend;
  public datefilterstart;
  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };
  public searchValue;
  public _NoDataFound: NoDataFound;

  private apiUrl = ApiUrl;
  public preloader;
  public evaluate: boolean;
  public sellerFlagValue: boolean;

  public statusList: Array<MultiSelectList>;
  public statusMultiSelection: Array<any>;
  public dropdownSettingsStatus: Object;
  public orderMultiSelection: Array<any>;
  public dropdownSettingsOrder: Object;
  public sortToggle: boolean;
  public _StatusCountSeller;
  public _SampleRequestPreference;
  public pager: any = {};
  public resultCount: number;
  public offSet = 1;
  public pageSize = 10;
  public channelUserId: number;
  public _CurrencyType = CurrencyType;
  public _SampleRequestObj = SampleRequestObj;
  public filterToggle: boolean;
  public userChannelId;
  public upgradeCount;
  public currencySymbol;
  public searchdata;
  public doc: any;
  public hasUpdateAccess: boolean;
  public _AccessPermissionEnum = AccessPermissionEnum;
  public unauthorized: string;
  public subscription: boolean;

  @ViewChild(CartListOrderComponent) cartListOrderComponent: CartListOrderComponent;
  subtitle: any;

  constructor(private toastr: ToastrService, private router: Router, private scrollService: ScrollToService,
    public dialog: MatDialog, public _OrderService: OrderServiceService, private http: Http,
    private _pagination: PaginationService, private authorizeService: AuthorizeService, private _channelBusiness: ChannelBusiness,
    private translate: TranslateService, private sharedService: SharedService) {
  }

  ngOnInit() {
    this.unauthorized = '';
    this.filtershow = false;
    this.order = ['', '', ''];
    this.toggleObj = [];
    this.actionCustomObj = [];
    this.searchValue = '';
    this.datefilterstart = '';
    this.datefilterend = '';
    this.evaluate = false;
    this.sellerFlagValue = true;
    this.boolAction = true;
    this._NoDataFound = new NoDataFound();
    this._NoDataFound.noDataImageSrc = '../assets/images/empty-order.png';
    this._NoDataFound.noDataMsg = this.translate.instant('sampleRequest.noOrder');


    this.channelTypeId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);

    if (this.channelTypeId !== '3') {
      this.title = 'sampleRequest.title';
      this.subtitle = this.translate.instant('sampleRequest.subtitleMsg');
    } else {
      this.title = 'sampleRequest.Distributortitle';
      this.subtitle = this.translate.instant('sampleRequest.subtitleMsgDistributor');
    }
    this.statusDetail = SampleRequestObj[RequestStatus.CONFIRMATION];
    this._RequestStatus = RequestStatus;
    this.statusIdList = [];
    this.AllStatus = [];
    this.orderStatusID = RequestStatus.CONFIRMATION;
    this.dropdownSettingsStatus = {
      singleSelection: false,
      text: 'Select Status',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '150',
      badgeShowLimit: 1
    };
    this.dropdownSettingsOrder = {
      singleSelection: false,
      text: 'Select Order',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class custom-overflow',
      maxHeight: '100'
    };
    this.upgradeCount = 0;
    // this.getOrderList(this.offSet, this.pageSize);
    // this.onChangeStatus(RequestStatus.CONFIRMATION);
    this.getStatusCount();
    this.getUpgradeDetails();
    this._PostAction = new PostActionSeller();
    this.sortToggle = true;
    this._StatusCountSeller = [{}];
    this._SampleRequestPreference = SampleRequestPreference;
    this.channelUserId = parseInt(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID), 10);
    this.userChannelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    this.reviewRating = 0;
    // this.currencySymbol = this._CurrencyType[this._OrderCartDetailObject.currencyid].symbol;
    this.searchdata = '';
    this.getChildAccess();
    this.validateAndSetStripeId();
  }

  // Stripe check functionality
  validateAndSetStripeId() {
    this.sharedService.stripeConnectCheck().subscribe(item => {
      if (item.ok) {
        localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '1');
      } else {
        localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '0');
      }
    });
  }

  authorizeBeforeSubmit() {
    const channelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    if (channelStatus && parseInt(channelStatus, 10) === UserAccountStatus.CHANNEL_APPROVED) {
      this.hasUpdateAccess = this.authorizeService.hasAccess(AccessPermissionEnum.CONTACT_PROFILE_UPDATE);
      if (!this.hasUpdateAccess) {
        this.toastr.warning(this.translate.instant('userAccess.actionAccessDenied'));
        return false;
      } else {
        return true;
      }
    } else {
      return true;
    }
  }

  getChildAccess() {
    const role = localStorage.getItem(AppLocalStorageKeys.ROLE);
    if (role) {
      const _role = JSON.parse(role) as Role;
      if (parseInt(_role.roleId, 10) !== RoleIdEnum.AccountUser) {
        const _permissions = this.authorizeService.getActiveChilds(AccessPermissionEnum.SAMPLE_REQUESTS);
        if (_permissions.length === 0) {
          this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
          this.router.navigate(['/dashboard']);
        } else if (_permissions.length < 9) {
          // this.toastr.info(this.translate.instant('userAccess.tabInfo'));
          let statusIdPreference = RequestStatus.CONFIRMATION;
          Object.keys(SampleRequestPreference).forEach(key => {
            let flagpreference = 0;
            Object.keys(_permissions).forEach(keyCount => {
              if (SampleRequestPreference[key].preference === parseInt(_permissions[keyCount].accesspermissionid, 10)) {
                this._SampleRequestPreference[key].permission = false;
                flagpreference++;
              }
            });
            if (flagpreference === 0) {
              this._SampleRequestPreference[key].permission = true;
            }
            if (parseInt(_permissions[0].accesspermissionid, 10) === SampleRequestPreference[key].preference) {
              statusIdPreference = SampleRequestPreference[key].status;
            }
          });
          this.onChangeStatus(statusIdPreference);
        }
      } else {
        this.onChangeStatus(RequestStatus.CONFIRMATION);
      }
    }
  }

  toastCustomMessage() {
    this.toastr.warning(this.translate.instant('userAccess.pageAccessDenied'));
  }

  public sendEmail(contactId, permission, count, orderNo) {
    if (permission.relationId && (permission.relationId === 5 || permission.relationId === 6)) {
      this.toastr.error(this.translate.instant('order.dismissError'));
    } else if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
      this.OpenRequestDialig(permission, count, orderNo);
    } else {
      this.dialog.closeAll();
      this.dialog.open(EmailPopupComponent, {
        data: {
          senderId: this.channelUserId,
          receiverId: contactId
        },
        width: '600px',
        height: 'auto'
      });
    }
  }

  public OpenContactDialog(contactId, channelId, permission) {
    if (permission && (permission === 5 || permission === 6)) {
      this.toastr.error(this.translate.instant('order.dismissError'));
    } else {
      this.dialog.open(ContactViewDialogComponent, {
        data: {
          id: contactId,
          channelId: channelId,
          jtcChannelId: 1,
          order: true,
          // tslint:disable-next-line:max-line-length
          approvalstauts: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.request && this._OrderDetailObject.contact.relation.request === 'IN') ? 2 : 1,
          // tslint:disable-next-line:max-line-length
          relation_tag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
        }
      });
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    }
  }


  getStatusCount() {
    this._StatusCountSeller = [{}];
    const url: any = this.apiUrl.SAMPLE_SELLER_STATUS_COUNT;
    this._OrderService.getService(url, true).subscribe(response => {
      const resCountList = response.json() as StatusCount;
      Object.keys(SampleRequestObj).forEach(key => {
        let flag = 0;
        Object.keys(resCountList).forEach(keyCount => {
          if (SampleRequestObj[key].statusId === parseInt(resCountList[keyCount].statusid, 10)) {
            this._StatusCountSeller.push({
              'status': SampleRequestObj[key].status,
              'count': parseInt(resCountList[keyCount].count, 10)
            });
            flag++;
          }
        });
        if (flag === 0) {
          this._StatusCountSeller.push({ 'status': SampleRequestObj[key].status, 'count': 0 });
          flag++;
        }
      });
    });
  }

  searchFunction(value: string) {
    this.filterToggle = false;
    const valueReplace = this.searchdata.replace('#', '');
    this.searchValue = valueReplace;
    this.getOrderList(this.offSet, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getOrderList(1, this.pageSize);
  }

  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
  }

  paginationFunction(data: number) {
    this.getOrderList(data, this.pageSize);
  }

  statusUpdationIcon(order, actionId: number, count: number, actionCount: number, permission) {
    if (actionId === ActionIconSampleRequest.SEND && this.orderStatusID === this._RequestStatus.CONFIRMATION
      || actionId === ActionIconSampleRequest.DELETE && this.orderStatusID === this._RequestStatus.CONFIRMATION) {
      const url: any = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS;
      if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
        this._OrderService.getByIDService(order.ordernumber, url, true).subscribe(response => {
          this._OrderDetailObject = response.json();
          this.OpenRequestDialig(permission, count, order.ordernumber);
        });
        return false;
      }
    }
    if (actionId === ActionIconSampleRequest.SEND && CommonHelper.getStripeIDLocally() === '0' ||
      actionId === ActionIconSampleRequest.TRANSFER && CommonHelper.getStripeIDLocally() === '0') {
      this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
      this.validateAndSetStripeId();
    } else {
      if (actionId === 2) {
        this.getOrderDetail(order.ordernumber, count);
      } else if (actionId === ActionIconSampleRequest.TRACK) {
        window.open(this._OrderDetailObject.shipments[0].trackingurl, '_blank');
      } else if (actionId === ActionIconSampleRequest.PRINT || actionId === ActionIconSampleRequest.MAIL) {
        const url: any = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS;
        this._OrderService.getByIDService(order.ordernumber, url, true).subscribe(response => {
          this._OrderDetailObject = response.json();
          if (actionId === ActionIconSampleRequest.PRINT) {
            this.invoiceDownload(order.ordernumber);
          } else if (actionId === ActionIconSampleRequest.MAIL) {
            this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order.ordernumber, order.buyerchannelid);
          }
        });
      }
      const request = SampleRequestObj[order.statusid].actionIcon[actionCount];
      if (actionId !== 2 && request.confirm !== '' && actionId !== ActionIconSampleRequest.MAIL) {
        this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order.ordernumber, order.buyerchannelid);
      }
    }
  }

  statusUpdationButton(order, action: string, count: number, actionCount: number, permission) {
    // if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
    //   permission.order = true;
    //   this.OpenRequestDialig(permission, count, order.ordernumber);
    // } else {
    if (action === 'send' && this.orderStatusID === this._RequestStatus.CONFIRMATION
      || action === 'delete' && this.orderStatusID === this._RequestStatus.CONFIRMATION) {
      if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
        this.OpenRequestDialig(permission, count, order.ordernumber);
        return false;
      }
    }
    if (action === 'send' && CommonHelper.getStripeIDLocally() === '0'
      || action === 'transfer' && CommonHelper.getStripeIDLocally() === '0') {
      this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
      this.validateAndSetStripeId();
    } else {
      if (action === 'cancel') {
        this.toggleObj[count].toggle = false;
      } else if (action === 'track') {
        window.open(this._OrderDetailObject.shipments[0].trackingurl, '_blank');
      } else if (action === 'print') {
        if (this.orderStatusID === this._RequestStatus.PACKING) {
          this.packingInvoice(this._OrderDetailObject);
        } else {
          this.invoiceDownload(order.ordernumber);
        }
      }
      const request = SampleRequestObj[order.statusid].actionBtn[actionCount];
      if (request.confirm !== '') {
        if (action === 'ship' && this.cartListOrderComponent.shipmentForm.invalid) {
          this.cartListOrderComponent.markFormGroupTouched(this.cartListOrderComponent.shipmentForm);
          this.scrollService.scrollTo(document.getElementById('order_list_elem_' + count), 1000, 500);
          return false;
        }
        console.log(request.value, request.confirm, request.postAction, order.ordernumber, order.buyerchannelid);
        this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order.ordernumber, order.buyerchannelid);
      } else if (action !== 'track' && action !== 'print' && action !== 'cancel' && action !== 'mail') {
        this.updateAction(request.postAction, order.ordernumber);
      }
    }
    // }

  }

  private OpenConfirmDialog(title: string, message: string, action, orderno, buyerChannelId: number = 0) {
    const dialogRef = this.dialog.open(ConfirmRequestComponent, {
      data: {
        title: title,
        message: message,
        list: '',
        action: action,
        transferBuyerId: buyerChannelId
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(response => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (response.action === true) {
        this.updateAction(action, orderno, response);
      }
    });
  }

  clearFilter() {
  }

  onChangeStatus(status: number) {
    this.orderStatusID = status;
    this.searchdata = '';
    this.searchValue = '';
    this.statusDetail = SampleRequestObj[status];
    this.statusIdList = [];
    this.AllStatus = [];
    this.AllStatus.push(this.orderStatusID);
    if (this.orderStatusID === RequestStatus.CONFIRMATION) {
      this.AllStatus.push(RequestStatus.APPROVAL);
    } else if (this.orderStatusID === RequestStatus.REFUND) {
      this.AllStatus.push(RequestStatus.REFUNDCANCELED);
      this.AllStatus.push(RequestStatus.REFUNDED);
    }
    this.statusList = [];
    this.AllStatus.forEach(item => {
      this.statusList.push({ 'id': item, 'itemName': SampleRequestBuyerObj[item].status });
    });
    this.getUpgradeDetails();
    this.getOrderList(this.offSet, this.pageSize);
  }

  getOrderList(offSet, pageSize) {
    this.preloader = true;
    const orderStatus = {
      'start': this.datefilterstart,
      'end': this.datefilterend
    };
    if (this.AllStatus.length) {
      orderStatus['status'] = this.AllStatus;
      if (this.statusIdList.length) {
        orderStatus['status'] = this.statusIdList;
      }
    }
    let params = new HttpParams();
    params = params.set('search', this.searchValue);
    params = params.set('page', offSet);
    params = params.set('limit', pageSize);
    params = params.set('sortorder', this.sortToggle ? 'DESC' : 'ASC');
    const url: any = this.apiUrl.ORDER_LIST_SELLER + '?' + params;
    this._OrderService.postService(orderStatus, url, true).subscribe(response => {
      // const orderList = response as Response;
      this._SellerRequestObject = response.json();
      this.resultCount = parseInt(this._SellerRequestObject.pagination.total, 10);
      for (let i = 0; i < parseInt(this._SellerRequestObject.pagination.total, 10); i++) {
        this.toggleObj[i] = { 'toggle': false };
        this.actionCustomObj[i] = { 'toggle': false };
      }
      this.pager = this._pagination.setPage(offSet, this.resultCount, pageSize);
      this.getStatusCount();
      this.preloader = false;
    });
  }

  getOrderDetail(orderId: string, count: number) {
    this.preloader = true;
    for (let i = 0; i < this.toggleObj.length; i++) {
      this.toggleObj[i] = { 'toggle': false };
    }
    const url: any = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS;
    this._OrderService.getByIDService(orderId, url, true).subscribe(response => {
      // const orderDetail = response as Response;
      this._OrderDetailObject = response.json();
      this.toggleObj[count].toggle = true;
      this.preloader = false;
    });
  }

  updateAction(action: string, orderno: string, updateData: ConfirmDialogData = null) {
    action = action.toUpperCase();
    // const postData = { 'action': action };
    if (action === 'UPDATE') {
      this._PostAction.action = action;
      this._PostAction.order = <Order>{
      };
    } else if (action === 'MARK_AS_SHIPPED') {
      this._PostAction.action = action;
      this._PostAction.shipment = this.cartListOrderComponent.getDataShipment();
      if (this.cartListOrderComponent.shipmentForm.invalid) {
        this.cartListOrderComponent.markFormGroupTouched(this.cartListOrderComponent.shipmentForm);
        this.scrollService.scrollTo(document.getElementById('order_list_elem_0'), 1000, -100);
        return false;
      }
    } else if (action === SampleRequestAction.TRANSFER.toUpperCase()) {
      this._PostAction.action = action;
      this._PostAction.transfer = updateData.transfer;
    } else {
      this._PostAction.action = action;
      // if (action === 'PRINT_MAIL_INVOICE') {
      //   this.invoiceDownload(orderno);
      // }
    }
    this.preloader = true;
    const url: any = this.apiUrl.SAMPLE_SELLER_ORDERDETAILS + '/' + orderno;
    this._OrderService.postService(this._PostAction, url, true).subscribe(response => {
      const orderaction = response as Response;
      if (orderaction.ok) {
        if (action === 'PRINT_MAIL_INVOICE') {
          this.toastr.success(this.translate.instant('sampleRequest.mailsent'));
          this.invoiceDownload(orderno);
        } else {
          this.toastr.success(this.translate.instant('sampleRequest.sampleSuccess'));
          this.getOrderList(this.offSet, this.pageSize);
        }
      } else {
        this.toastr.error(this.translate.instant('sampleRequest.failedtoOrder'));
        this.getOrderList(this.offSet, this.pageSize);
      }
      this.preloader = false;
    });
  }

  onCheckOrderUpdate(updateData: EmitUpdateQtyData, order) {
    if (!updateData.cancel.cancelBool) {
      if (updateData.qty !== 0) {
        order.total_quantities = updateData.qty;
      }
      if (updateData.qty !== 0) {
        order.ordertotalprice = updateData.total;
      }
      this.boolAction = updateData.action;
    } else {
      this.OpenConfirmDialog('Cancel', DialogConfirmMessage.cancel, 'CANCEL', updateData.cancel.orderNo, updateData.cancel
        .buyerChannelId);
    }
  }

  checkList(event) {
    this.statusIdList.push(parseInt(event.id, 10));
    this.getOrderList(this.offSet, this.pageSize);
  }

  uncheckList(event) {
    this.statusIdList = this.statusIdList.filter(x => x !== parseInt(event.id, 10));
    if (this.statusIdList.length === 0) {
      this.statusIdList = [this.orderStatusID];
    }
    this.getOrderList(this.offSet, this.pageSize);
  }

  onSelectAll(event) {
    event.forEach(selectItem => {
      this.checkList(selectItem);
    });
    this.getOrderList(this.offSet, this.pageSize);
  }

  onDeSelectAll(event) {
    this.statusIdList = [this.orderStatusID];
    this.getOrderList(this.offSet, this.pageSize);
  }

  onDateRangeChanged(event) {
    if (event.beginDate.year !== 0 && event.beginDate.month && event.beginDate.day !== 0) {
      this.datefilterstart = event.beginDate.year + '-' + event.beginDate.month + '-' + event.beginDate.day;
    } else {
      this.datefilterstart = '';
    }
    if (event.endDate.year !== 0 && event.endDate.month && event.endDate.day !== 0) {
      this.datefilterend = event.endDate.year + '-' + event.endDate.month + '-' + event.endDate.day;
    } else {
      this.datefilterend = '';
    }
    this.getOrderList(this.offSet, this.pageSize);
  }

  invoiceDownload(obj) {
    const doc = new jsPDF();
    let currency = this._CurrencyType[this._OrderDetailObject.currencyid].symbol;
    if (parseInt(this._OrderDetailObject.currencyid, 10) === 1) {
      currency = this._CurrencyType[this._OrderDetailObject.currencyid].type + ' ';
      // currency = '';
    }
    const vendorName = this._OrderDetailObject.seller_contact.firstName + ' ' + this._OrderDetailObject.seller_contact.lastName;
    // const imgData = this._OrderDetailObject.sellerchannel.channelDetail.channelLogo.documentUrl;
    // const img = new Image;
    const self = this;
    // img.onload = function () {
    // doc.addImage(this, 10, 13, 50, 20);

    const topx = 5;
    // Title Design
    doc.setFontSize(15);
    doc.setTextColor(0, 0, 0);
    doc.setFontType('bold');
    doc.text('Seller Details', topx, 10, 'left');
    doc.text('Buyer Details:', 200, 10, 'right');

    // Left Content
    doc.setFontSize(12);
    // doc.text('Invoice#', topx, 25, 'left');
    // doc.text('Order id', topx, 25, 'left');
    // doc.text('Date', topx, 32, 'left');
    // doc.text('Order Value', topx, 40, 'left');

    doc.setFontType('bold');
    // doc.text('-', 40, 25, 'left');
    // doc.text(obj, 40, 25, 'left');
    // doc.text(this._OrderDetailObject.orderdate, 40, 32, 'left');
    // doc.setTextColor(39, 167, 254);
    // doc.text(currency + ' ' + this._OrderDetailObject.ordertotalprice, 40, 40, 'left');

    // Right Content
    doc.setTextColor(0, 0, 0);
    doc.text(this._OrderDetailObject.buyerchannel.companyName, 200, 20, 'right');
    doc.setFontType('normal');
    doc.text(this._OrderDetailObject.contact.firstName + ' ' + this._OrderDetailObject.contact.lastName, 200, 25, 'right');
    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.address, 200, 30, 'right');

    let addressY = 30;
    doc.setFontSize(10);
    // Address Part
    if (this._OrderDetailObject.shippingaddress) {
      const splitTitle = doc.splitTextToSize(this._OrderDetailObject.shippingaddress.address, 20);
      for (let c = 0, stlength = splitTitle.length; c < stlength - 1; c++) {
        doc.text(splitTitle[c], 200, addressY, 'right');
        addressY = addressY + 5;
      }
      doc.text(this._OrderDetailObject.shippingaddress.city + ' - ' +
        this._OrderDetailObject.shippingaddress.postalcode, 200, addressY, 'right');
      // doc.text('ph:' + this._OrderDetailObject.sellerchannel.channelDetail.phone1, 200, addressY + 5, 'right');
    }
    // doc.text('Date', 200, addressY + 10, 'right');

    // Seller Details
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.setFontType('bold');
    doc.text(this._OrderDetailObject.sellerchannel.companyName, 5, 20, 'left');
    doc.setFontType('normal');
    doc.text(vendorName, 5, 25, 'left');
    let addressSellerY = 30;
    doc.setFontSize(10);
    // Address Part
    if (this._OrderDetailObject.sellerchannel.regAddress) {
      const splitTitle = doc.splitTextToSize(this._OrderDetailObject.sellerchannel.regAddress.address, 20);
      for (let c = 0, stlength = splitTitle.length; c < stlength - 1; c++) {
        doc.text(splitTitle[c], 5, addressSellerY, 'left');
        addressSellerY = addressSellerY + 5;
      }
      doc.text(this._OrderDetailObject.sellerchannel.regAddress.city + ' - ' +
        this._OrderDetailObject.sellerchannel.regAddress.postalCode, 5, addressSellerY, 'left');
      // doc.text('ph:' + this._OrderDetailObject.sellerchannel.channelDetail.phone1, 200, addressY + 5, 'right');
    }
    doc.setFontType('bold');
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    doc.text('Order id:', topx, addressSellerY + 15, 'left');
    doc.setFontType('normal');
    doc.text(obj, 30, addressSellerY + 15, 'left');
    doc.setFontType('bold');
    doc.text(moment(this._OrderDetailObject.orderdate).format('DD/MM/YYYY'), 200, addressY + 13, 'right');
    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.city, 200, 35, 'right');
    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.country.country + ' - ' +
    // this._OrderDetailObject.sellerchannel.regAddress.postalCode, 200, 45, 'right');

    let x = 0;
    let y = addressSellerY > addressY ? addressSellerY + 20 : addressY + 20;

    doc.setFontSize(13);
    doc.setDrawColor(0);
    doc.setFillColor(39, 167, 254);
    doc.rect(x, y, 210, 5, 'F');
    doc.setFontType('bold');
    doc.text('Order Summary', topx, y + 12);

    doc.setFontSize(12);
    doc.setFontType('bold');
    doc.setTextColor(39, 167, 254);

    doc.text('S.No', x + 13, y + 30);
    doc.text('Product Details', x + 40, y + 30);
    doc.text('Quantity', x + 103, y + 30);
    doc.text('Sample Price / Qty', x + 138, y + 30);
    doc.text('Total', x + 188, y + 30);

    doc.setFontSize(10);
    doc.setFontType('normal');
    doc.setTextColor(0, 0, 0);
    const startValue = y;

    y = y + 40;
    x = x + 3;

    for (let i = 0; i < self._OrderDetailObject.orderDetails.length; i++) {
      const index = i + 1;
      doc.text(index.toString(), x + 13, y);
      doc.text(x + 53, y, self._OrderDetailObject.orderDetails[i].product.name, null, null, 'center');
      doc.text(self._OrderDetailObject.orderDetails[i].finalquantity, x + 103, y);
      doc.text(currency + self._OrderDetailObject.orderDetails[i].samplepriceperquantity, x + 137, y);
      doc.text(currency + self._OrderDetailObject.orderDetails[i].finaltotalprice, x + 176, y);
      y = y + 15;
    }
    doc.setDrawColor(128, 128, 128);
    doc.rect(5, startValue + 17, 200, y - startValue - 17);



    // doc.setFontType('bold');
    doc.setFontSize(12);
    doc.text('Thank for your business', topx, y + 10);
    // Payment Information
    if (this._OrderDetailObject.paymentTranscation) {
      doc.setFontType('bold');
      doc.setTextColor(39, 167, 254);
      doc.text('Payment Info', topx, y + 20);
      doc.setFontSize(11);
      doc.setTextColor(0, 0, 0);
      doc.text('Transaction No. :', topx, y + 30);
      doc.text('Payment Method :', topx, y + 40);
      doc.setFontType('normal');
      doc.text(this._OrderDetailObject.paymentTranscation.transactionNumber ?
        this._OrderDetailObject.paymentTranscation.transactionNumber : '', topx + 35, y + 30);
      doc.text(this._OrderDetailObject.paymentTranscation.cardType ?
        this._OrderDetailObject.paymentTranscation.cardType : '', topx + 35, y + 40);
    }

    doc.text('Sub Total :', 140, y + 10);
    doc.text('Discount % :', 140, y + 20);
    doc.text('Shipping Cost :', 140, y + 30);
    doc.text('Other Charges :', 140, y + 40);
    doc.setDrawColor(0, 0, 0);
    doc.line(135, y + 45, 200, y + 45); // horizontal line
    doc.text('Total :', 140, y + 53);
    doc.line(135, y + 60, 200, y + 60); // horizontal line

    doc.text(currency + self._OrderDetailObject.subtotalprice, 200, y + 10, 'right');
    doc.text(self._OrderDetailObject.discount, 200, y + 20, 'right');
    doc.text(currency + self._OrderDetailObject.shippingprice, 200, y + 30, 'right');
    doc.text(currency + self._OrderDetailObject.othercharge, 200, y + 40, 'right');
    doc.text(currency + self._OrderDetailObject.ordertotalprice, 200, y + 53, 'right');

    doc.setDrawColor(0);
    doc.setFillColor(201, 205, 208);
    doc.rect(0, y + 80, 210, 20, 'F');
    doc.setFontSize(17);
    doc.setFontType('normal');
    doc.text('Invoice Total : ' + currency + ' ' + self._OrderDetailObject.ordertotalprice, 80, y + 93);
    doc.setFontSize(13);
    doc.setFontType('normal');
    doc.text('Document sent by ChannelHub on behalf of ' + vendorName, 5, y + 115);
    doc.text('For Information only - No legal value', 5, y + 122);

    const dfd = doc.output('blob');
    if (window.navigator && window.navigator.msSaveOrOpenBlob) { // for IE
      window.navigator.msSaveOrOpenBlob(dfd, 'file_name.pdf');
    } else {
      const fileURL = URL.createObjectURL(dfd);
      window.open(fileURL, '_blank');
    }
    // };
    //   img.crossOrigin = '*';  // for demo as we are at different origin than image
    //   img.src = imgData;
  }



  // invoiceDownload(obj) {
  //   const doc = new jsPDF();
  //   let currency = this._CurrencyType[this._OrderDetailObject.currencyid].symbol;
  //   if (parseInt(this._OrderDetailObject.currencyid, 10) === 1) {
  //     currency = this._CurrencyType[this._OrderDetailObject.currencyid].type + ' ';
  //   }
  //   doc.text(obj, 10, 50);
  //   doc.setFontSize(12);
  //   doc.setFontType('bold');
  //   doc.text('Product Details', 10, 60);
  //   doc.text('Quantity', 120, 60);
  //   doc.text('Price', 150, 60);
  //   doc.text('Total', 180, 60);
  //   doc.setFontSize(10);
  //   doc.setFontType('normal');
  //   let lineno = 70;
  //   for (let i = 0; i < this._OrderDetailObject.orderDetails.length; i++) {

  //     doc.text(this._OrderDetailObject.orderDetails[i].product.sku, 10, lineno);
  //     doc.text(this._OrderDetailObject.orderDetails[i].product.name, 10, lineno = lineno + 5);
  //     doc.text(this._OrderDetailObject.orderDetails[i].finalquantity, 120, lineno);
  //     doc.text(currency + this._OrderDetailObject.orderDetails[i].samplepriceperquantity, 150, lineno);
  //     doc.text(currency + this._OrderDetailObject.orderDetails[i].finaltotalprice, 180, lineno);
  //     lineno = lineno + 10;
  //   }
  //   lineno = lineno + 10;
  //   doc.setFontType('bold');
  //   doc.text('Sub Total', 150, lineno + 10);
  //   doc.text('Discount %', 150, lineno);
  //   doc.text('Shipping Cost', 150, lineno + 20);
  //   doc.text('Other Charges', 150, lineno + 30);
  //   doc.text('Total', 150, lineno + 40);
  //   doc.text(currency + this._OrderDetailObject.subtotalprice, 180, lineno + 10);
  //   doc.text(this._OrderDetailObject.discount, 180, lineno);
  //   doc.text(currency + this._OrderDetailObject.shippingprice, 180, lineno + 20);
  //   doc.text(currency + this._OrderDetailObject.othercharge, 180, lineno + 30);
  //   doc.text(currency + this._OrderDetailObject.ordertotalprice, 180, lineno + 40);
  //   const dfd = doc.output('blob');
  //   const fileURL = URL.createObjectURL(dfd);
  //   window.open(fileURL, '_blank');

  // }

  packingInvoice(obj) {
    const doc = new jsPDF({ lineHeight: 1 });
    const img = new Image;
    img.onload = function () {
      doc.addImage(this, 10, 13, 50, 20);
      doc.setFont('Roboto');
      doc.setFontSize(15);
      doc.setFontType('bold');
      // Person Details
      doc.setLineJoin(1);
      doc.text(obj.sellerchannel.companyName, 185, 20, 'right');
      doc.setFontSize(12);
      doc.setFontType('normal');
      let y = 24;
      if (obj.sellerchannel) {
        const splitTitle = doc.splitTextToSize(obj.sellerchannel.regAddress.address, 20);
        for (let c = 0, stlength = splitTitle.length; c < stlength - 1; c++) {
          doc.text(splitTitle[c], 185, y, 'right');
          y = y + 5;
        }
        doc.text(obj.sellerchannel.regAddress.city + ' ' + obj.sellerchannel.regAddress.postalCode, 185, y, 'right');
        doc.text('ph:' + obj.sellerchannel.channelDetail.phone1, 185, y + 5, 'right');
      }


      // order id
      doc.setFontSize(12);
      doc.text('1. For Order Id' + ' ' + obj.ordernumber, 10, y + 20);
      doc.setDrawColor(192, 192, 192);
      doc.rect(155, y + 15, 5, 5);
      doc.text('Packed Status', 162, y + 18);

      doc.setFontSize(12);
      doc.setFontType('bold');
      doc.text('S.No', 10, y + 30);
      doc.text('Product Details', 50, y + 30);
      doc.text('Quantity', 120, y + 30);
      doc.text('Verify', 150, y + 30);
      doc.setFontSize(13);
      doc.setFontType('normal');

      let lineno = y + 40;
      let colorlinenoeven = y + 32;
      let colorlinenold = y + 32;
      for (let i = 0; i < obj.orderDetails.length; i++) {

        if (i % 2 === 0) {
          doc.setDrawColor(0);
          doc.setFillColor(175, 176, 175);
          doc.rect(9, colorlinenoeven, 177, 18, 'F');
        } else {
          doc.setDrawColor(0);
          doc.setFillColor(206, 206, 206);
          doc.rect(9, colorlinenold, 177, 18, 'F');
        }

        const serialNo = i + 1;
        doc.text(serialNo.toString(), 12, lineno + 2);
        doc.text(obj.orderDetails[i].product.name, 50, lineno + 2);
        doc.text(obj.orderDetails[i].finalquantity, 120, lineno + 2);
        doc.setDrawColor(128, 128, 128);
        doc.rect(150, lineno = lineno - 4, 15, 10);
        lineno = lineno + 26;
        colorlinenoeven = colorlinenoeven + 22;
        colorlinenold = colorlinenold + 22;
      }
      const dfd = doc.output('blob');
      if (window.navigator && window.navigator.msSaveOrOpenBlob) { // for IE
        window.navigator.msSaveOrOpenBlob(dfd, 'file_name.pdf');
      } else {
        const fileURL = URL.createObjectURL(dfd);
        window.open(fileURL, '_blank');
      }
    };

    img.crossOrigin = '*';  // for demo as we are at different origin than image
    if (obj.sellerchannel.channelDetail.channelLogo) {
      img.src = obj.sellerchannel.channelDetail.channelLogo.documentUrl;
      img.src = img.src.replace('https://', 'http://');
    } else {
      img.src = 'assets/images/channel_hub_logo.png';
    }
  }

  upgradeFunction() {
    localStorage.setItem('RedirectId', '8');
    this.router.navigate(['/user/subscriptionplan']);
  }

  getUpgradeDetails() {
    const url: any = this.apiUrl.SAMPLE_REQUEST_UPGRADE;
    this._OrderService.getService(url, true).subscribe(response => {
      const upgradeCount = response as Response;
      if (upgradeCount.ok) {
        this.upgradeCount = upgradeCount.json().count;
      }
    });
  }

  filterClk() {
    if (!this.filterToggle) {
      this.filterToggle = true;
    } else {
      this.filterToggle = false;
    }
  }

  filterreset() {
    const element: HTMLElement = document.getElementsByClassName('btnclear')[0] as HTMLElement;
    if (element) {
      element.click();
    }
    this.searchdata = '';
    this.searchValue = '';
    this.datefilterstart = '';
    this.datefilterend = '';
    this.statusIdList = [];
    this.statusList = [];
    this.onChangeStatus(RequestStatus.CONFIRMATION);
    this.getStatusCount();
    this.getUpgradeDetails();
  }

  // Link for buyer detail view
  goToChannelDetail(channelId) {
    this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, channelId]);
  }


  /** Request suggestion */
  public OpenRequestDialig(relationData, count, orderNo) {
    const dialogRef = this.dialog.open(RequestSuggestionComponent, {
      data: {
        title: 'UPDATE',
        type: 2,
        // message: this.translate.instant(message),
        message: 'message',
        relation: relationData,
        channelId: parseInt(this._OrderDetailObject.sellerchannelid, 10),
        approvalstauts: this._OrderDetailObject.contact.relation.request === 'IN' ? 2 : 1,
        // tslint:disable-next-line:max-line-length
        relation_tag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this.changeChannelStatus(responseType, this._OrderDetailObject.buyerchannelid, count, orderNo);
      }
    });
  }

  /** Update channel status */
  changeChannelStatus(UpdateStatusData, id, count, orderNo) {
    const channelStatus = {
      // tslint:disable-next-line:max-line-length
      connectionStatusTypeId: (UpdateStatusData.relation && UpdateStatusData.relation.relationId && UpdateStatusData.relation.relationId === 1) ? 7 : 2,
      channelJCTId: UpdateStatusData.relation.channelJCTId,
      // tslint:disable-next-line:max-line-length
      leadManagementTag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
    };
    this._channelBusiness.updateChannel(channelStatus, true, id).subscribe(response => {
      if (response.ok) {
        // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
        const msg = this.translate.instant(PopUpSuccessMsg[channelStatus.connectionStatusTypeId]);
        this.toastr.success(msg);
        this.getOrderDetail(orderNo, count);
      } else {
        this.preloader = false;
        if (response.json()[0]['errors'][0]['code'] === 3031) {
          this.openUpgradePopup();
        } else {
          const msg = this.translate.instant(PopUpSuccessMsg[19]);
          this.toastr.error(msg);
        }
      }
    });
  }

  // Upgrade popup
  public openUpgradePopup() {
    const title = this.translate.instant('productList.upgradetitle');
    const message = this.translate.instant('searchList.upgradeMsg');
    const dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.subscriptionPlan();
      } else {
        this.unauthorized = this.translate.instant('searchList.upgradeMsg');
        this.subscription = true;
      }
    });
  }

  /** call subscription plan */
  subscriptionPlan() {
    localStorage.setItem('RedirectId', '8');
    this.router.navigate(['/user/subscriptionplan']);
  }
}
