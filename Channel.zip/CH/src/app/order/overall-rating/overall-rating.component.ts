import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { HttpParams } from '@angular/common/http';
import { IMyDrpOptions } from 'mydaterangepicker';
import { TranslateService } from '@ngx-translate/core';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { NoDataFound } from '@app/shared/models/shared-model';
import { RootObjectOverallRating } from '@app/order/models/overall-rating';
import { ChannelTypeIdEnum } from '@app/config/constant';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { LocationMapComponent } from '@app/shared/shared-component/location-map/location-map.component';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-overall-rating',
  templateUrl: './overall-rating.component.html',
  styleUrls: ['./overall-rating.component.scss']
})

export class OverallRatingComponent implements OnInit {
  public opts: ISlimScrollOptions;
  public _NoDataFound: NoDataFound;
  public title = 'order.titlerating';
  public rating = 3.7;
  public productRatingDetail;
  public productRatingComment;
  public productRatingStatictis;
  public commentTotal;
  public commentList: Array<any>;
  public ratingList: Array<any>;
  public channelStatistic;
  public channelCountryStatistic;
  public preloader = false;
  public productId;
  public countryData;
  public _channelTypeEnum = ChannelTypeIdEnum;
  public productID: number; // need to remove;
  public channelId: number;
  public _RootObjectOverallRating: RootObjectOverallRating;
  public pager: any = {};
  public resultCount: number;

  private _locationComponent: LocationMapComponent;
  @ViewChild(LocationMapComponent) set locationMapComponent(elRef) {
    if (elRef && this.resultCount > 0) {
      this._locationComponent = elRef as LocationMapComponent;
      this.setMap();
    }
  }

  get locationMapComponent(): LocationMapComponent {
    return this._locationComponent;
  }


  public pieChartLabels: string[] = [];
  public pieChartData: number[] = [];
  public pieChartType: string;
  public chartColors: any[] = [{
    backgroundColor: ['#37B4A9', '#004878', '#337ab7', '#FFFCC4', '#B9E8E0']
  }];
  public pieChartOptions;
  // public pieChartLabels: string[];
  // public pieChartData: number[];
  // public pieChartType = 'pie';
  noresult: boolean;
  public empty: string;
  private apiUrl = ApiUrl;
  public offSet = 1;
  public pageSize = 10;
  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd mmm yyyy',
  };
  public datefilterend;
  public datefilterstart;

  constructor(public _OrderService: OrderServiceService,
    private route: ActivatedRoute, private _location: Location,
    private _pagination: PaginationService, private translate: TranslateService) {
    this._NoDataFound = new NoDataFound();
    this.commentList = [];
    this.ratingList = [];
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    this.channelId = parseInt(data1);
    this.resultCount = 0;
  }

  ngOnInit() {
    this.pieChartType = 'pie';
    this._NoDataFound.noDataMsg = this.translate.instant('order.noRating');
    this._NoDataFound.noDataImageSrc = '../assets/images/no-rating.png';
    this.getChannelCompanyID();
    this.getListOVerallRatingDetail(this.offSet, this.pageSize);
    this.empty = '../assets/images/no-rating.png';
    this.pieChartOptions = {
      tooltips: {
        enabled: true,
        mode: 'single',
        callbacks: {
          label: function (tooltipItem, data) {
            const allData = data.datasets[tooltipItem.datasetIndex].data;
            const tooltipLabel = data.labels[tooltipItem.index];
            const tooltipData = allData[tooltipItem.index];
            const isInt = tooltipData % 1 === 0;
            const labeldisplay = (isInt) ? tooltipData + '%' : tooltipData.toFixed(2) + '%';
            return tooltipLabel + ': ' + labeldisplay;
          }
        }
      },
      labels: {
      }
    };

    this.datefilterstart = '';
    this.datefilterend = '';
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
  }

  // Get Product Id in params
  getChannelCompanyID() {
    this.route.params.subscribe(
      (params: any) => {
        this.productId = parseInt(params.id, 10);
        this.getProductRatingList(this.productId);
        this.productID = this.productId;
      },
      (error) => {
        console.log(error);
      });
  }

  // Get Product rating detail
  getProductRatingList(productId) {
    this.preloader = true;
    this._OrderService.getProductRatingDetails(productId).subscribe(response => {
      const result = response;
      if (result) {
        // this.getProductRatingComment(this.productId);
        // this.getProductRatingStatictis(this.productId);
        this.productRatingDetail = result;
        this.preloader = false;
      }
    }, (error) => {
      this.noresult = true;
      console.log(error);
    });
  }

  // Get Product rating detail
  // getProductRatingComment(productId) {
  //   this.preloader = true;
  //   this._OrderService.getProductRatingComment(productId).subscribe(response => {
  //     const result = response;
  //     if (result) {
  //       this.productRatingComment = result;
  //       this.commentTotal = this.productRatingComment.total;
  //       this.commentList = this.productRatingComment.commentList;
  //       this.preloader = false;
  //     }
  //   }, (error) => {
  //     console.log(error);
  //   });
  // }

  // Get Product rating STATICTIS
  // getProductRatingStatictis(productId) {
  //   this.preloader = true;
  //   this._OrderService.getProductRatingStatictis(productId).subscribe(response => {
  //     const result = response;
  //     if (result) {
  //       this.productRatingStatictis = result;
  //       this.ratingList = this.productRatingStatictis.ratingtotal;
  //       this.channelStatistic = this.productRatingStatictis.channel;
  //       this.channelCountryStatistic = this.productRatingStatictis.country;
  //       if (this.channelStatistic) {
  //         let index = 0;
  //         this.channelStatistic.forEach(item => {
  //           if (item.channelTypeId === 2) {
  //             this.pieChartData[index] = item.perc;
  //             this.pieChartLabels[index] = item.channelType;
  //           } if (item.channelTypeId === 3) {
  //             this.pieChartData[index] = item.perc;
  //             this.pieChartLabels[index] = item.channelType;
  //           } if (item.channelTypeId === 4) {
  //             this.pieChartData[index] = item.perc;
  //             this.pieChartLabels[index] = item.channelType;
  //           }
  //           index++;
  //         });
  //       } else {
  //         // this.empty = '../assets/images/no-product.png';
  //       }
  //       if (this.channelCountryStatistic) {
  //         this.countryData = this.channelCountryStatistic.map(item => ({ country: item.country }));
  //         this.locationMapComponent.setMap(this.countryData);
  //       } else {
  //         // this.empty = '../assets/images/no-product.png';
  //       }
  //       this.preloader = false;
  //     }
  //   }, (error) => {
  //     console.log(error);
  //   });
  // }

  // Overall Rating service for listing the Evaluation detail
  getListOVerallRatingDetail(offSet, pageSize) {
    this.preloader = true;
    const filterData = {
      'start': this.datefilterstart,
      'end': this.datefilterend
    };
    let params = new HttpParams();
    params = params.set('page', offSet);
    params = params.set('limit', pageSize);
    const url: any = this.apiUrl.OVERALL_RATING_EVALUATE + '/' + this.productId + '?' + params;
    this._OrderService.postService(filterData, url, true).subscribe(response => {
      const result = response;
      if (result) {
        this._RootObjectOverallRating = result.json();
        this.resultCount = this._RootObjectOverallRating.comments.total;
        if (this.resultCount > 0) {
          this.channelStatistic = this._RootObjectOverallRating.statistics.channel;
          this.channelCountryStatistic = this._RootObjectOverallRating.statistics.country;
          this.ratingList = this._RootObjectOverallRating.statistics.ratingtotal;
          this.setChart();
          // this.setMap();
        }
        this.pager = this._pagination.setPage(offSet, this.resultCount, pageSize);
        this.preloader = false;
      }
    }, (error) => {
      console.log(error);
    });
  }

  // Date picker validation
  onDateRangeChanged(event) {
    if (event.beginDate.year !== 0 && event.beginDate.month && event.beginDate.day !== 0) {
      this.datefilterstart = event.beginDate.year + '-' + event.beginDate.month + '-' + event.beginDate.day;
    } else {
      this.datefilterstart = '';
    }
    if (event.endDate.year !== 0 && event.endDate.month && event.endDate.day !== 0) {
      this.datefilterend = event.endDate.year + '-' + event.endDate.month + '-' + event.endDate.day;
    } else {
      this.datefilterend = '';
    }
    this.getListOVerallRatingDetail(this.offSet, this.pageSize);
  }

  // Pagination Function
  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getListOVerallRatingDetail(1, this.pageSize);
  }

  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }
    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
  }

  paginationFunction(data: number) {
    this.getListOVerallRatingDetail(data, this.pageSize);
  }

  // Set Chart value
  setChart() {
    if (this.channelStatistic) {
      let index = 0;
      this.channelStatistic.forEach(item => {
        if (item.channelTypeId === 2) {
          this.pieChartData[index] = item.perc;
          this.pieChartLabels[index] = item.channelType;
        } if (item.channelTypeId === 3) {
          this.pieChartData[index] = item.perc;
          this.pieChartLabels[index] = item.channelType;
        } if (item.channelTypeId === 4) {
          this.pieChartData[index] = item.perc;
          this.pieChartLabels[index] = item.channelType;
        }
        index++;
      });
    }
  }

  // Set Map Value
  setMap() {
    if (this.channelCountryStatistic) {
      this.countryData = this.channelCountryStatistic.map(item => ({ country: item.country }));
      this.locationMapComponent.setMap(this.countryData);
    }
  }

  /** history back */
  backClicked() {
    this._location.back();
  }
}
