import { Component, OnInit } from '@angular/core';
import { Response } from '@angular/http';
import { IMyDrpOptions, IMyDateRangeModel } from 'mydaterangepicker';
import { MatDialog } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import * as jsPDF from 'jspdf';
import { Router } from '@angular/router';
import * as moment from 'moment';

import { environment } from '../../../environments/environment';
import { ApiUrl, AppLocalStorageKeys, ConfigKeys, WebUrl } from '@app/config/constant_keys';
import {
  RequestStatusBuyer, SubscriptionPlanDetails, SampleRequestBuyerObj, CurrencyType,
  ActionIconSampleRequest, PopUpSuccessMsg, ButtonTypes, RequestStatus
} from '@app/config/constant';
import { PaginationService } from '@app/shared/shared-service/pagination.service';
import { OrderServiceService } from '@app/order/service/order-service.service';
import { NoDataFound } from '@app/shared/models/shared-model';
import { Contact } from '@app/shared/models/contact';
import { EmailPopupComponent } from '@app/shared/shared-component/email-popup/email-popup.component';
import { ContactViewDialogComponent } from '@app/shared/shared-component/contact-view-dialog/contact-view-dialog.component';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { CommonHelper } from '@app/shared/common-helper';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { ShowHide, PostOrderList, MultiSelectList } from './../models/sample-request';
import { OrderDetailObject, PostAction, SampleOrder, OrderTransaction } from './../models/buyer-request';
import { ConfirmRequestComponent } from '../../order/confirm-request/confirm-request.component';
import { datatable, SampleOrderFilterResult } from '@app/channel/models/channel_models';
import { TranslateService } from '@ngx-translate/core';
import { RequestSuggestionComponent } from '@app/shared/shared-component/request-suggestion/request-suggestion.component';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { MessageDialogComponent } from '@app/shared/shared-component/message-dialog/message-dialog.component';

@Component({
  selector: 'app-sample-request-buyer',
  templateUrl: './sample-request-buyer.component.html',
  styleUrls: ['./sample-request-buyer.component.scss']
})

export class SampleRequestBuyerComponent implements OnInit {
  public webUrl = WebUrl;
  public filtershow: boolean;
  filterToogle: boolean;
  title: string;
  titlemsg: string;
  reviewRating: any;
  public statusDetail;
  public toggleObj: Array<ShowHide>;
  public actionCustomObj: Array<ShowHide>;
  public order;
  public orderStatusID: number;
  public _RequestStatusBuyer = RequestStatusBuyer;
  public _PostOrderList = new PostOrderList();
  public _PostAction: PostAction;
  public _OrderTransaction: OrderTransaction;
  public listresult: any;
  public _OrderDetailObject: OrderDetailObject;
  public _SubscriptionPlanDetails = SubscriptionPlanDetails;
  public _SampleRequestBuyerObj = SampleRequestBuyerObj;
  public sellerFlagValue: boolean;
  public evaluateFlagValue: boolean;
  public preloader: boolean;
  public filterToggle: boolean;
  public statusList: Array<MultiSelectList>;

  public statusMultiSelection: Array<any>;
  public dropdownSettingsStatus: Object;
  public orderMultiSelection: Array<any>;

  public transaction_id: number;
  public order_amount: number;

  private apiUrl = ApiUrl;
  public statusIdList;
  public datefilterend;
  public datefilterstart;

  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };
  public _NoDataFound: NoDataFound;

  public sortToggle: boolean;
  public pager: any = {};
  public resultCount: number;
  public offSet = 1;
  public pageSize = 10;
  public channelUserId: number;
  public _CurrencyType = CurrencyType;
  noresult: boolean;
  public tableresult: datatable;
  searchdata: string;
  filteractive: boolean;
  filterresult: SampleOrderFilterResult;
  search: string;
  pagedItems: any[];
  public result: any = [];
  aggregations: any;
  defaultstatusList: any;
  subtitle: any;
  public unauthorized: string;
  public subscription: boolean;
  public _RequestStatus = RequestStatus;

  constructor(private toastr: ToastrService,
    public dialog: MatDialog, public _OrderService: OrderServiceService,
    private _pagination: PaginationService, private _channelBusiness: ChannelBusiness,
    private translate: TranslateService, private router: Router, private sharedService: SharedService) {
    this.filterresult = new SampleOrderFilterResult();
  }

  ngOnInit() {
    this.unauthorized = '';
    this.filtershow = false;
    this.filterToogle = false;

    this._PostAction = new PostAction();
    this._NoDataFound = new NoDataFound();

    this.order = ['', '', ''];
    this.toggleObj = [];
    this.actionCustomObj = [];
    this.statusIdList = [];
    this.datefilterstart = '';
    this.datefilterend = '';
    this._NoDataFound.noDataImageSrc = '../assets/images/empty-order.png';
    this._NoDataFound.noDataMsg = this.translate.instant('sampleRequest.noOrder');
    this.title = 'sampleRequest.title';
    this.subtitle = this.translate.instant('sampleRequest.subtitlebuyerMsg');
    this.reviewRating = 0;
    this.statusDetail = SampleRequestBuyerObj[RequestStatusBuyer.PENDING_APPROVAL];
    this.sellerFlagValue = false;
    this.sortToggle = true;

    this.dropdownSettingsStatus = {
      singleSelection: false,
      text: 'Select Status',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-dropdown-class custom-overflow',
      maxHeight: '150',
      badgeShowLimit: 1
    };

    this.statusList = [];
    this.statusMultiSelection = [];
    this.searchdata = '';
    this.getOrderList(this.searchdata, this.offSet, this.pageSize);

    this.getEvaluationAttr();
    this.channelUserId = parseInt(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID), 10);
    this.validateAndSetStripeId();
  }

  // Stripe check functionality
  validateAndSetStripeId() {
    this.sharedService.stripeConnectCheck().subscribe(item => {
      if (item.ok) {
        localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '1');
      } else {
        localStorage.setItem(AppLocalStorageKeys.STRIPE_CHECK, '0');
      }
    });
  }

  filterClk() {
    if (!this.filterToogle) {
      this.filterToogle = true;
    } else {
      this.filterToogle = false;
    }
  }

  public sendEmail(contactId, permission?: any, count?, orderNo?) {
    if (permission.relationId && (permission.relationId === 5 || permission.relationId === 6)) {
      this.toastr.error(this.translate.instant('order.dismissError'));
    } else if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
      this.OpenRequestDialig(permission, count, orderNo);
    } else {
      this.dialog.closeAll();
      this.dialog.open(EmailPopupComponent, {
        data: {
          senderId: this.channelUserId,
          receiverId: contactId
        },
        width: '600px',
        height: 'auto'
      });
    }
  }

  public OpenContactDialog(contactId, channelId, permission?: any) {
    if (permission && (permission === 5 || permission === 6)) {
      this.toastr.error(this.translate.instant('order.dismissError'));
    } else {
      this.dialog.open(ContactViewDialogComponent, {
        data: {
          id: contactId,
          channelId: channelId,
          jtcChannelId: 1,
          order: true,
          // tslint:disable-next-line:max-line-length
          approvalstauts: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.request === 'IN') ? 2 : 1,
          // tslint:disable-next-line:max-line-length
          relation_tag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
        },
      });
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
    }
  }

  searchFunction(data) {
    const valueReplace = data.replace('#', '');
    this.searchdata = valueReplace;
    this.getOrderList(this.searchdata, this.offSet, this.pageSize);
  }

  paginationFunction(data: number) {
    this.getOrderList(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.getOrderList(this.searchdata, 1, pageSize);
  }

  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);

    // get current page of items
    // this.pagedItems = this.result.slice(this.pager.startIndex, this.pager.endIndex + 1);
    this.pagedItems = this.result;
  }

  statusUpdationIcon(order, actionId: number, count: number, actionCount: number, permission) {
    // if (actionId === ActionIconSampleRequest.APPROVE && CommonHelper.getStripeIDLocally() === '0') {
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   this.validateAndSetStripeId();
    // } else {
    if (actionId === 1) {
      if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
        const url: any = this.apiUrl.SAMPLE_BUYER_ORDERDETAILS;
        this._OrderService.getByIDService(order.ordernumber, url, true).subscribe(response => {
          this._OrderDetailObject = response.json();
          this.OpenRequestDialig(permission, count, order.ordernumber);
        });
        return false;
      }
    }
    if (actionId === ActionIconSampleRequest.VIEW) {
      this.getOrderDetail(order.ordernumber, count);
    } else if (actionId === ActionIconSampleRequest.TRACK) {
      window.open(this._OrderDetailObject.shipments[0].trackingurl, '_blank');
    }
    if (actionId === ActionIconSampleRequest.APPROVE && order.ordertotalprice !== '0.00') {
      this.updateAction('APPROVE_PAY', order.ordernumber);
    } else if (actionId === ActionIconSampleRequest.MAIL || actionId === ActionIconSampleRequest.PRINT) {
      const url: any = this.apiUrl.SAMPLE_BUYER_ORDERDETAILS;
      this._OrderService.getByIDService(order.ordernumber, url, true).subscribe(response => {
        this._OrderDetailObject = response.json();
        if (actionId === ActionIconSampleRequest.PRINT) {
          this.invoiceDownload(order.ordernumber);
        } else if (actionId === ActionIconSampleRequest.MAIL) {
          this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order);
        }
      });
    }
    const request = SampleRequestBuyerObj[order.statusid].actionIcon[actionCount];
    if (actionId !== 2 && actionId !== ActionIconSampleRequest.MAIL && request.confirm !== '' && request.confirm !== undefined) {
      this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order);
    }
    // }
  }

  statusUpdationButton(order, action: string, count: number, actionCount: number, permission) {
    const request = SampleRequestBuyerObj[order.statusid].actionBtn[actionCount];
    // if (action === 'approve' && CommonHelper.getStripeIDLocally() === '0') {
    //   this.toastr.warning(this.translate.instant(ValidationService.getApplicationMessage('014')));
    //   this.validateAndSetStripeId();
    // } else {
    if (action === 'delete') {
      if (!permission.relationId || permission.relationId === 1 || permission.relationId === 7) {
        this.OpenRequestDialig(permission, count, order.ordernumber);
        return false;
      }
    }
    if (action === 'cancel') {
      this.toggleObj[count].toggle = false;
    } else if (action === 'track') {
      window.open(this._OrderDetailObject.shipments[0].trackingurl, '_blank');
    }
    if (action === 'approve' && order.ordertotalprice !== '0.00') {
      this.updateAction('APPROVE_PAY', order.ordernumber);
    } else if (action === 'print') {
      this.invoiceDownload(order.ordernumber);
    }
    if (request.confirm !== '' && request.confirm !== undefined) {
      this.OpenConfirmDialog(request.value, request.confirm, request.postAction, order);
    }
    // }
  }

  private OpenConfirmDialog(title: string, message: string, action: string, order) {
    const listRating = '';
    const dialogRef = this.dialog.open(ConfirmRequestComponent, {
      data: {
        title: title,
        message: message,
        list: listRating,
        action: action
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType.action === true) {
        if (action === 'APPROVE_PAY' && order.ordertotalprice !== '0.00') {
          this.openCheckout('APPROVE_PAY', order.ordernumber, order.ordertotalprice);
        } else if (action === 'EVALUATE') {
          this.getOrderList(this.searchdata, this.offSet, this.pageSize);
        } else if (action !== '') {
          this.updateAction(action, order.ordernumber);
        }
      }
    });
  }

  onChangeStatus(status: number) {
    this.orderStatusID = status;
    this.statusDetail = SampleRequestBuyerObj[status];
  }

  filterreset() {
    const element: HTMLElement = document.getElementsByClassName('btnclear')[0] as HTMLElement;
    if (element) {
      element.click();
    }
    this.filterresult.end = '';
    this.filterresult.start = '';
    this.filteractive = false;
    this.searchdata = '';
    this.search = '';
    this.statusMultiSelection = [];
    delete this.filterresult.status;

    this.getOrderList(this.searchdata, this.offSet, this.pageSize);
  }


  filterData() {
    this.filteractive = true;

    if (this.statusMultiSelection.length) {
      this.filterresult.status = this.statusMultiSelection.map(x => parseInt(x.id, 10));
    } else {
      delete this.filterresult.status;
    }
    this.getOrderList(this.searchdata, this.offSet, this.pageSize);
  }

  getOrderList(searchdata, offSet, pageSize) {
    this.noresult = false;
    this.tableresult = {
      searchKey: searchdata,
      pageNumber: offSet,
      limit: pageSize,
      sort: this.sortToggle ? 'desc' : 'asc'
    };
    this.result = [];
    this.resultCount = 0;
    this.preloader = true;
    this.callOrderList();
  }

  callOrderList() {
    this._OrderService.getSampleOrders(this.tableresult, this.filterresult).subscribe(response => {
      this.listresult = response.json();
      this.result = this.listresult.results;

      this.aggregations = this.listresult.aggregations;

      this.statusList = [];
      if (this.listresult.aggregations['status']) {
        this.defaultstatusList = this.listresult.aggregations['status'];
        for (let i = 0; i < this.defaultstatusList.length; i++) {
          this.statusList.push({
            'id': this.defaultstatusList[i].id,
            'itemName': this.defaultstatusList[i].status,
            'count': this.defaultstatusList[i].doc_count
          });
        }
      }

      this.resultCount = parseInt(this.listresult.pagination.total, 10);
      for (let i = 0; i < parseInt(this.listresult.pagination.total, 10); i++) {
        this.toggleObj[i] = { 'toggle': false };
        this.actionCustomObj[i] = { 'toggle': false };
      }
      this.setPage(this.tableresult.pageNumber);
      this.preloader = false;
    });
  }

  getOrderDetail(orderId: string, count: number) {
    this.preloader = true;
    for (let i = 0; i < this.toggleObj.length; i++) {
      this.toggleObj[i] = { 'toggle': false };
    }
    const url: any = this.apiUrl.SAMPLE_BUYER_ORDERDETAILS;
    this._OrderService.getByIDService(orderId, url, true).subscribe(response => {
      this._OrderDetailObject = response.json();
      this.toggleObj[count].toggle = true;
      this.preloader = false;
    });
  }

  updateAction(action: string, orderno: string) {
    this.preloader = true;
    if (action === 'APPROVE_PAY') {
      this._PostAction.action = action;
      this._PostAction.sampleOrder = <SampleOrder>{
      };
    } else {
      this._PostAction.action = action;
    }
    const url: any = this.apiUrl.SAMPLE_BUYER_ACTION + '/' + orderno;
    this._OrderService.postService(this._PostAction, url, true).subscribe(response => {
      const orderaction = response as Response;
      if (orderaction.ok) {
        if (action === 'APPROVE_PAY') {
          if (orderaction.json().status !== undefined && orderaction.json().status === true) {
            this.toastr.success(this.translate.instant('sampleRequest.orderUpdated'));
            this.getOrderList(this.searchdata, this.offSet, this.pageSize);
          } else {
            this._OrderTransaction = response.json();
          }
        } else if (action === 'PRINT_MAIL_INVOICE') {
          this.toastr.success(this.translate.instant('sampleRequest.mailsent'));
          this.invoiceDownload(orderno);
        } else {
          this.toastr.success(this.translate.instant('sampleRequest.orderUpdated'));
          this.getOrderList(this.searchdata, this.offSet, this.pageSize);
        }
      } else {
        this.toastr.error(this.translate.instant('sampleRequest.failedtoOrder'));
        this.getOrderList(this.searchdata, this.offSet, this.pageSize);
      }
      this.preloader = false;
    });
  }

  getEvaluationAttr() {
    this.preloader = true;
    const url: any = this.apiUrl.EVALUATION_ATTRIBUTE + '/PRODUCT';
    this._OrderService.getService(url, true).subscribe(response => {
      // const evaluationlist = response as Response;
      this.preloader = false;
    });
  }

  onDateRangeChanged(data: IMyDateRangeModel) {
    if (data.beginDate.year !== 0 && data.beginDate.month && data.beginDate.day !== 0) {
      this.filterresult.start = data.beginDate.year + '-' + data.beginDate.month + '-' + data.beginDate.day;
    } else {
      delete this.filterresult.start;
    }
    if (data.endDate.year !== 0 && data.endDate.month && data.endDate.day !== 0) {
      this.filterresult.end = data.endDate.year + '-' + data.endDate.month + '-' + data.endDate.day;
    } else {
      delete this.filterresult.end;
    }
    this.filterData();
  }

  openCheckout(action: string, orderno: string, orderPrice: string) {
    this.preloader = true;
    const self = this;
    const contactInfo = JSON.parse(localStorage.getItem(AppLocalStorageKeys.CONTACT_INFO)) as Contact;
    const handler = (<any>window).StripeCheckout.configure({
      key: environment.STRIPE_KEY,
      locale: 'auto',
      image: 'assets/images/logo-icon.png',
      email: contactInfo.email,
      token: function (token: any) {
        if (action === 'APPROVE_PAY') {
          self._PostAction.action = action;
          self._PostAction.sampleOrder = <SampleOrder>{
            'transactionId': self._OrderTransaction.transactionId,
            'token': token.id,
            'amount': self._OrderTransaction.amount
          };
        } else {
          self._PostAction.action = action;
        }
        const url: any = self.apiUrl.SAMPLE_BUYER_ACTION + '/' + orderno;
        this.preloader = true;
        self._OrderService.postService(self._PostAction, url, true).subscribe(response => {
          const orderaction = response as Response;
          if (orderaction.ok) {
            self.toastr.success(self.translate.instant('sampleRequest.orderUpdated'));
            this.preloader = false;
            self.getOrderList(self.searchdata, self.offSet, self.pageSize);
          }
        });
      }
    }, function (err, charge) {
      self.order.id = 'WERF5345GFDG40';
      self.order.status = 'failed';
    });
    handler.open({
      name: 'ChannelHub',
      description: 'Payment Process',
      amount: self._OrderTransaction.amount,
      currency: this._OrderTransaction.currency.currencycode,
      closed: function () {
        self.preloader = false;
      }
    });
    // amount: parseInt(this._OrderDetailObject.ordertotalprice, 10),
  }

  onSuccessEvaluate(event) {
    // if (event) {
    //   this.getOrderList(this.searchdata, this.offSet, this.pageSize);
    // }
  }

  // invoiceDownload(obj) {
  //   const doc = new jsPDF();
  //   let currency = this._CurrencyType[this._OrderDetailObject.currencyid].symbol;
  //   if (parseInt(this._OrderDetailObject.currencyid, 10) === 1) {
  //     currency = this._CurrencyType[this._OrderDetailObject.currencyid].type + ' ';
  //   }
  //   doc.text(obj, 10, 50);
  //   doc.setFontSize(12);
  //   doc.setFontType('bold');
  //   doc.text('Product Details', 10, 60);
  //   doc.text('Quantity', 120, 60);
  //   doc.text('Price', 150, 60);
  //   doc.text('Total', 180, 60);
  //   doc.setFontSize(10);
  //   doc.setFontType('normal');
  //   let lineno = 70;
  //   for (let i = 0; i < this._OrderDetailObject.orderDetails.length; i++) {
  //     doc.text(this._OrderDetailObject.orderDetails[i].product.sku, 10, lineno);
  //     doc.text(this._OrderDetailObject.orderDetails[i].product.name, 10, lineno = lineno + 5);
  //     doc.text(this._OrderDetailObject.orderDetails[i].finalquantity, 120, lineno);
  //     doc.text(currency + this._OrderDetailObject.orderDetails[i].samplepriceperquantity, 150, lineno);
  //     doc.text(currency + this._OrderDetailObject.orderDetails[i].finaltotalprice, 180, lineno);
  //     lineno = lineno + 10;
  //   }
  //   lineno = lineno + 10;
  //   doc.setFontType('bold');
  //   doc.text('Sub Total', 150, lineno + 10);
  //   doc.text('Discount %', 150, lineno);
  //   doc.text('Shipping Cost', 150, lineno + 20);
  //   doc.text('Other Charges', 150, lineno + 30);
  //   doc.text('Total', 150, lineno + 40);
  //   doc.text(currency + this._OrderDetailObject.subtotalprice, 180, lineno + 10);
  //   doc.text(this._OrderDetailObject.discount , 180, lineno);
  //   doc.text(currency + this._OrderDetailObject.shippingprice, 180, lineno + 20);
  //   doc.text(currency + this._OrderDetailObject.othercharge, 180, lineno + 30);
  //   doc.text(currency + this._OrderDetailObject.ordertotalprice, 180, lineno + 40);
  //   const dfd = doc.output('blob');
  //   const fileURL = URL.createObjectURL(dfd);
  //   window.open(fileURL, '_blank');
  // }

  invoiceDownload(obj) {
    const doc = new jsPDF();
    let currency = this._CurrencyType[this._OrderDetailObject.currencyid].symbol;
    if (parseInt(this._OrderDetailObject.currencyid, 10) === 1) {
      currency = this._CurrencyType[this._OrderDetailObject.currencyid].type + ' ';
    }
    const vendorName = this._OrderDetailObject.contact.firstName + ' ' + this._OrderDetailObject.contact.lastName;
    // const imgData = this._OrderDetailObject.sellerchannel.channelDetail.channelLogo.documentUrl;
    // const img = new Image;
    const self = this;
    // img.onload = function () {
    // doc.addImage(this, 10, 13, 50, 20);

    const topx = 5;
    // Title Design
    doc.setFontSize(15);
    doc.setTextColor(0, 0, 0);
    doc.setFontType('bold');
    doc.text('Seller Details', topx, 10, 'left');
    doc.text('Buyer Details:', 200, 10, 'right');

    // Left Content
    doc.setFontSize(12);
    // doc.text('Invoice#', topx, 25, 'left');
    // doc.text('Order id', topx, 25, 'left');
    // doc.text('Date', topx, 32, 'left');
    // doc.text('Order Value', topx, 40, 'left');

    doc.setFontType('bold');
    // doc.text('Invoice#', 40, 25, 'left');
    // doc.text(obj, 40, 25, 'left');
    // doc.text(this._OrderDetailObject.orderdate, 40, 32, 'left');
    // doc.setTextColor(39, 167, 254);
    // doc.text(currency + ' ' + this._OrderDetailObject.ordertotalprice, 40, 40, 'left');

    // Right Content
    doc.setTextColor(0, 0, 0);
    // doc.text(this._OrderDetailObject.buyerchannel.companyName, 200, 20, 'right');
    doc.setFontType('normal');
    doc.text(this._OrderDetailObject.buyer_contact.firstName + ' ' + this._OrderDetailObject.buyer_contact.lastName, 200, 25, 'right');

    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.address, 200, 30, 'right');

    let addressY = 30;
    doc.setFontSize(10);
    // Address Part
    if (this._OrderDetailObject.shippingaddress) {
      const splitTitle = doc.splitTextToSize(this._OrderDetailObject.shippingaddress.address, 20);
      for (let c = 0, stlength = splitTitle.length; c < stlength - 1; c++) {
        doc.text(splitTitle[c], 200, addressY, 'right');
        addressY = addressY + 5;
      }
      doc.text(this._OrderDetailObject.shippingaddress.city + ' - ' +
        this._OrderDetailObject.shippingaddress.postalcode, 200, addressY, 'right');
      // doc.text('ph:' + this._OrderDetailObject.sellerchannel.channelDetail.phone1, 200, addressY + 5, 'right');
    }

    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.city, 200, 35, 'right');
    // doc.text(this._OrderDetailObject.sellerchannel.regAddress.country.country + ' - ' +
    // this._OrderDetailObject.sellerchannel.regAddress.postalCode, 200, 45, 'right');

    // Seller Details
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);
    doc.setFontType('bold');
    doc.text(this._OrderDetailObject.sellerchannel.companyName, 5, 20, 'left');
    doc.setFontType('normal');
    doc.text(this._OrderDetailObject.contact.firstName + ' ' + this._OrderDetailObject.contact.lastName, 5, 25, 'left');
    let addressSellerY = 30;
    doc.setFontSize(10);
    // Address Part
    if (this._OrderDetailObject.sellerchannel.regAddress) {
      const splitTitle = doc.splitTextToSize(this._OrderDetailObject.sellerchannel.regAddress.address, 20);
      for (let c = 0, stlength = splitTitle.length; c < stlength - 1; c++) {
        doc.text(splitTitle[c], 5, addressSellerY, 'left');
        addressSellerY = addressSellerY + 5;
      }
      doc.text(this._OrderDetailObject.sellerchannel.regAddress.city + ' - ' +
        this._OrderDetailObject.sellerchannel.regAddress.postalCode, 5, addressSellerY, 'left');
      // doc.text('ph:' + this._OrderDetailObject.sellerchannel.channelDetail.phone1, 200, addressY + 5, 'right');
    }
    doc.setFontType('bold');
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);
    doc.text('Order id:', topx, addressSellerY + 15, 'left');
    doc.setFontType('normal');
    doc.text(obj, 30, addressSellerY + 15, 'left');
    doc.setFontType('bold');
    doc.text(moment(this._OrderDetailObject.orderdate).format('DD/MM/YYYY'), 200, addressY + 13, 'right');

    let x = 0;
    let y = addressSellerY > addressY ? addressSellerY + 20 : addressY + 20;

    doc.setFontSize(13);
    doc.setDrawColor(0);
    doc.setFillColor(39, 167, 254);
    doc.rect(x, y, 210, 5, 'F');
    doc.setFontType('bold');
    doc.text('Order Summary', topx, y + 12);

    doc.setFontSize(12);
    doc.setFontType('bold');
    doc.setTextColor(39, 167, 254);

    doc.text('S.No', x + 13, y + 30);
    doc.text('Product Details', x + 40, y + 30);
    doc.text('Quantity', x + 103, y + 30);
    doc.text('Sample Price / Qty', x + 138, y + 30);
    doc.text('Total', x + 188, y + 30);

    doc.setFontSize(10);
    doc.setFontType('normal');
    doc.setTextColor(0, 0, 0);
    const startValue = y;

    y = y + 40;
    x = x + 3;

    for (let i = 0; i < self._OrderDetailObject.orderDetails.length; i++) {
      const index = i + 1;
      doc.text(index.toString(), x + 13, y);
      doc.text(x + 53, y, self._OrderDetailObject.orderDetails[i].product.name, null, null, 'center');
      doc.text(self._OrderDetailObject.orderDetails[i].finalquantity, x + 103, y);
      doc.text(currency + self._OrderDetailObject.orderDetails[i].samplepriceperquantity, x + 137, y);
      doc.text(currency + self._OrderDetailObject.orderDetails[i].finaltotalprice, x + 176, y);
      y = y + 15;
    }
    doc.setDrawColor(128, 128, 128);
    doc.rect(5, startValue + 17, 200, y - startValue - 17);

    // doc.setFontType('bold');
    doc.setFontSize(12);
    doc.text('Thank for your business', topx, y + 10);
    // Payment Information
    doc.setFontType('bold');
    doc.setTextColor(39, 167, 254);
    doc.text('Payment Info', topx, y + 20);
    doc.setFontSize(11);
    doc.setTextColor(0, 0, 0);
    doc.text('Transaction No. :', topx, y + 30);
    doc.text('Payment Method :', topx, y + 40);
    doc.setFontType('normal');
    doc.text(this._OrderDetailObject.paymentTranscation.transactionNumber, topx + 35, y + 30);
    doc.text(this._OrderDetailObject.paymentTranscation.cardType, topx + 35, y + 40);

    doc.setFontSize(11);
    doc.text('Sub Total :', 140, y + 10);
    doc.text('Discount % :', 140, y + 20);
    doc.text('Shipping Cost :', 140, y + 30);
    doc.text('Other Charges :', 140, y + 40);
    doc.setDrawColor(0, 0, 0);
    doc.line(135, y + 45, 200, y + 45); // horizontal line
    doc.text('Total :', 140, y + 53);
    doc.line(135, y + 60, 200, y + 60); // horizontal line

    doc.text(currency + self._OrderDetailObject.subtotalprice, 200, y + 10, 'right');
    doc.text(self._OrderDetailObject.discount, 200, y + 20, 'right');
    doc.text(currency + self._OrderDetailObject.shippingprice, 200, y + 30, 'right');
    doc.text(currency + self._OrderDetailObject.othercharge, 200, y + 40, 'right');
    doc.text(currency + self._OrderDetailObject.ordertotalprice, 200, y + 53, 'right');

    doc.setDrawColor(0);
    doc.setFillColor(201, 205, 208);
    doc.rect(0, y + 80, 210, 20, 'F');
    doc.setFontSize(17);
    doc.setFontType('normal');
    doc.text('Invoice Total : ' + currency + ' ' + self._OrderDetailObject.ordertotalprice, 80, y + 93);

    doc.setFontSize(13);
    doc.setFontType('normal');
    doc.text('Document sent by ChannelHub on behalf of ' + vendorName , 5, y + 115);
    doc.text('For Information only - No legal value' , 5, y + 122);
    if (window.navigator && window.navigator.msSaveOrOpenBlob) { // for IE
      // const dfd = new Blob([doc], { type: 'application/pdf' });
      const dfd = doc.output('blob');
      window.navigator.msSaveOrOpenBlob(dfd, '/file_name.pdf');
    } else {
      const dfd = doc.output('blob');
      const fileURL = URL.createObjectURL(dfd);
      window.open(fileURL, '_blank');
    }
    // };
    //   img.crossOrigin = '*';  // for demo as we are at different origin than image
    //   img.src = imgData;
  }

  // Link for seller detail view
  goToChannelDetail(channelId) {
    this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, channelId]);
  }

  /** Request suggestion */
  public OpenRequestDialig(relationData, count, orderNo) {
    const dialogRef = this.dialog.open(RequestSuggestionComponent, {
      data: {
        title: 'UPDATE',
        type: 2,
        // message: this.translate.instant(message),
        message: 'message',
        relation: relationData,
        channelId: parseInt(this._OrderDetailObject.sellerchannelid, 10),
        approvalstauts: this._OrderDetailObject.contact.relation.request === 'IN' ? 2 : 1,
        // tslint:disable-next-line:max-line-length
        relation_tag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
      },
      panelClass: 'modalPointer'
    });
    dialogRef.afterClosed().subscribe(responseType => {
      document.getElementsByTagName('html').item(0).style.removeProperty('top');
      if (responseType && responseType.action === true) {
        this.changeChannelStatus(responseType, responseType.channelId, count, orderNo);
      }
    });
  }

  /** Update channel status */
  changeChannelStatus(UpdateStatusData, id, count, orderNo) {
    const channelStatus = {
      connectionStatusTypeId: UpdateStatusData.relation.relationId === 1 ? 7 : 2,
      channelJCTId: UpdateStatusData.relation.channelJCTId,
      // tslint:disable-next-line:max-line-length
      leadManagementTag: (this._OrderDetailObject.contact && this._OrderDetailObject.contact.relation && this._OrderDetailObject.contact.relation.tag) ? this._OrderDetailObject.contact.relation.tag : 'Low'
    };
    this._channelBusiness.updateChannel(channelStatus, true, id).subscribe(response => {
      if (response.ok) {
        // this.getChannelList(this.searchdata, this.offSet, this.pageSize);
        const msg = this.translate.instant(PopUpSuccessMsg[channelStatus.connectionStatusTypeId]);
        this.toastr.success(msg);
        this.getOrderDetail(orderNo, count);
      } else {
        this.preloader = false;
        if (response.json()[0]['errors'][0]['code'] === 3031) {
          this.openUpgradePopup();
        } else {
          const msg = this.translate.instant(PopUpSuccessMsg[19]);
          this.toastr.error(msg);
        }
      }
    });
  }

  public openUpgradePopup() {
    const title = this.translate.instant('productList.upgradetitle');
    const message = this.translate.instant('searchList.upgradeMsg');
    const dialogRef = this.dialog.open(MessageDialogComponent, {
      data: {
        title: title,
        type: ButtonTypes.UpgradeCancel,
        message: message
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.subscriptionPlan();
      } else {
        this.unauthorized = this.translate.instant('searchList.upgradeMsg');
        this.subscription = true;
      }
    });
  }

  /** call subscription plan */
  subscriptionPlan() {
    localStorage.setItem('RedirectId', '11');
    this.router.navigate(['/user/subscriptionplan']);
  }
}
