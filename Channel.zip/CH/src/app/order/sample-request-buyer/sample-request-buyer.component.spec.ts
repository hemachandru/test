import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SampleRequestBuyerComponent } from './sample-request-buyer.component';

describe('SampleRequestBuyerComponent', () => {
  let component: SampleRequestBuyerComponent;
  let fixture: ComponentFixture<SampleRequestBuyerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SampleRequestBuyerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SampleRequestBuyerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
