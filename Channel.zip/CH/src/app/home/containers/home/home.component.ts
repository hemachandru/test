import { Component } from '@angular/core';
import { HomeBusiness } from '../../business/home.business';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  constructor( private _homeBusiness: HomeBusiness) { }
}
