import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxCarouselModule, NgxCarousel } from 'ngx-carousel';
import { Response } from '@angular/http';

import { UserAccountStatus } from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { LocationMapComponent } from '@app/shared/shared-component/location-map/location-map.component';
import { HomeService } from '@app/home/service/home.service';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-home-banner',
  templateUrl: './home-banner.component.html',
  styleUrls: ['./home-banner.component.scss']
})
export class HomeBannerComponent implements OnInit {
  public webUrl = WebUrl;
  public isTokenExists: boolean;
  public userChannelStatus: any;
  public isSubscriptedUser: any = false;
  public generalData;
  public carouselTile: any;
  public imagelist: any;
  public mapTitle = 'home.bodyLabels.mapTitle';
  // Count timer config
  public count = {
    from: 0,
    duration: 1
  };
  public countsData;
  public countryData;
  public lastestNews;
  @ViewChild(LocationMapComponent) locationMapComponent: LocationMapComponent;
  loader: boolean;
  public showVideo: boolean;
  @ViewChild('videoPlayer') videoplayer: any;
  video_img: string;

  constructor(private homeService: HomeService) {
  }

  ngOnInit() {
    const AwsUrl = environment.AWS_URL;
    this.video_img = AwsUrl + 'Latest/Video_image%20.png';
    this.loader = true;
    this.userChannelStatus = localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS);
    const userChannelStatusId = parseInt(this.userChannelStatus, 10);
    this.isTokenExists = localStorage.getItem('authToken') != null && localStorage.getItem('authToken') !== '' ? true : false;
    if (userChannelStatusId >= UserAccountStatus.PAYMENT_PENDING) {
      this.isSubscriptedUser = true;
    } else {
      this.isSubscriptedUser = false;
    }
    // this.locationMapComponent.setMap(this.countryData);
    this.getGeneralData();
    this.getLastestNews();
    this.imagelist = [
      { imageUrl: AwsUrl + 'Latest/1.png' },
      { imageUrl: AwsUrl + 'Latest/2.png' },
      { imageUrl: AwsUrl + 'Latest/3.png' },
      { imageUrl: AwsUrl + 'Latest/4.png' },
      { imageUrl: AwsUrl + 'Latest/5.png' },
      { imageUrl: AwsUrl + 'Latest/6.png' },
      { imageUrl: AwsUrl + 'Latest/7.png' },
      { imageUrl: AwsUrl + 'Latest/8.png' },
      { imageUrl: AwsUrl + 'Latest/9.png' },
      { imageUrl: AwsUrl + 'Latest/10.png' },
      { imageUrl: AwsUrl + 'Latest/11.png' },
      { imageUrl: AwsUrl + 'Latest/12.png' },
    ];

    this.carouselTile = {
      grid: { xs: 4, sm: 6, md: 8, lg: 8, all: 0 },
      slide: 4,
      speed: 400,
      animation: 'lazy',
      point: {
        visible: true,
        hideOnSingleSlide: true
      },
      load: 4,
      touch: true,
      easing: 'ease'
    };
  }

  playVideo(event: any) {
    this.videoplayer.nativeElement.paused ? this.videoplayer.nativeElement.play() : this.videoplayer.nativeElement.pause();
  }

  toggleVideo(event: any) {
    this.showVideo = !this.showVideo;
  }

  // Get home data
  getGeneralData() {
    this.homeService.getGeneralData().subscribe(res => {
      this.loader = true;
      const response = res as Response;
      if (response.ok) {
        this.generalData = response.json();
        this.countsData = this.generalData.counts;
        this.countryData = this.generalData.countries;
        /** restrict for new CR - don't remove this code */
        // this.locationMapComponent.setMap(this.countryData);
      } else {
        console.log('error');
      }
      this.loader = false;
    });
  }

  // get Lastes News
  getLastestNews() {
    this.homeService.getLastestNews().subscribe(response => {
      this.loader = true;
      const res = response as Response;
      if (res.ok) {
        const resJson = response.json();
        this.lastestNews = resJson.results;
      } else {
        console.log('error');
      }
      this.loader = false;
    });
  }

}
