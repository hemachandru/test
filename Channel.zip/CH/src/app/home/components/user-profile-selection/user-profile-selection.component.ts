import { Component, OnInit, Input } from '@angular/core';
import { userSelctionList } from '@app/config/constant';
import { HomeBusiness } from '../../business/home.business';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-profile-selection',
  templateUrl: './user-profile-selection.component.html',
  styleUrls: ['./user-profile-selection.component.scss']
})
export class UserProfileSelectionComponent implements OnInit {

  public title: any = 'userProfileSelection.title';
  public userlist: any = userSelctionList;
  public result: any;
  isUpgrade: boolean;
  @Input() public isHomePage: boolean;
  loader: boolean;

  constructor(private _homeBusiness: HomeBusiness,
    private router: Router) {
    this.loader = true;
    const authToken = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    // const redirectId = parseInt(localStorage.getItem(AppLocalStorageKeys.REDIRECT_ID), 10);
    let userChannelStatus = parseInt(localStorage.getItem(AppLocalStorageKeys.USER_CHANNEL_STATUS), 10);
    userChannelStatus = userChannelStatus ? userChannelStatus : 10;
    this.isHomePage = false;
    this.isUpgrade = false;
    // if ((!authToken || !redirectId) && (userChannelStatus > 6)) {
    if (!authToken || (userChannelStatus >= 15)) {
      this.isUpgrade = true;
    }

    if (!this.isUpgrade) {

      const localChannelTypeId = localStorage.getItem(AppLocalStorageKeys.TEMP_CHANNEL_TYPE_ID);

      const tempChannelTypeId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
      const tempChannelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
      if (tempChannelTypeId !== '6') {
        // tslint:disable-next-line:max-line-length
        this.router.navigate(['/user/search'], { queryParams: { channelTypeId: tempChannelTypeId, channelTypeName: tempChannelType }, queryParamsHandling: 'merge' });
      } else if (localChannelTypeId) {
        let localChannelType = localStorage.getItem(AppLocalStorageKeys.TEMP_CHANNEL_TYPE);
        localChannelType = localChannelType.toLowerCase();
        localChannelType = localChannelType.charAt(0).toUpperCase() + localChannelType.slice(1);
        // tslint:disable-next-line:max-line-length
        this.router.navigate(['/user/search'], { queryParams: { channelTypeId: localChannelTypeId, channelTypeName: localChannelType }, queryParamsHandling: 'merge' });
      }
    }
    this.loader = false;
  }

  ngOnInit() {
    const authToken = localStorage.getItem(AppLocalStorageKeys.AUTH_Token);
    if (!this.isHomePage && authToken) {
      this.getChannelType();
    }
  }

  getChannelType() {
    this._homeBusiness.getUserselection().subscribe(data => {
      this.result = data;
      for (let i = 0; i < this.userlist.length; i++) {
        this.userlist[i].id = this.result[i].channelTypeId;
        // this.userlist[i].UserName = this.result[i].channelType && this.result[i].channelType.toLowerCase();
      }
    });
  }

  setCmsPage(user) {
    this.router.navigate([user.CmsPageUrl]);
  }

  setGuestChannelType(user) {
    if (this.isUpgrade) {
      if (user.id !== 5 && user.className !== 'sales-rep') {
        localStorage.setItem(AppLocalStorageKeys.TEMP_CHANNEL_TYPE_ID, user.id);
        localStorage.setItem(AppLocalStorageKeys.TEMP_CHANNEL_TYPE, user.value);

        localStorage.setItem(AppLocalStorageKeys.GUEST_CHANNEL_TYPE_ID, user.id);
        this.router.navigate(['/user/subscriptionplan']);
      }
    } else {
      if (user.id === 5) {
        localStorage.setItem(AppLocalStorageKeys.IS_SALES_REP, 'true');
      }
      this.router.navigate(['/user/search']);
      // tslint:disable-next-line:max-line-length
      this.router.navigate(['/user/search'], { queryParams: { channelTypeId: user.id, channelTypeName: user.value }, queryParamsHandling: 'merge' });
    }
  }
}
