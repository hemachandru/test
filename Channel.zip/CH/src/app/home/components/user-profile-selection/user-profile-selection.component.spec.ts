import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProfileSelectionComponent } from './user-profile-selection.component';

describe('UserProfileSelectionComponent', () => {
  let component: UserProfileSelectionComponent;
  let fixture: ComponentFixture<UserProfileSelectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserProfileSelectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProfileSelectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
