import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserProfileSelectionComponent } from './components/user-profile-selection/user-profile-selection.component';

import { AuthGuard, AnonymousGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';
import { DashboardComponent } from '@app/home/components/dashboard/dashboard.component';

const routes: Routes = [
  {
    path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], data: {
      currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
    }
  },
  {
    path: 'user_profile_selection', component: UserProfileSelectionComponent, canActivate: [AnonymousGuard],
    data: {
      currentStatus: [UserAccountStatus.SUBSCRIPTION]
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
