export class Counts {
  vendor: number;
  distributor: number;
  retailer: number;
  salesrep: number;
  product: number;
  rating: number;
}

export class Country {
  country: string;
}

export class HomeGeneralRootObject {
  counts: Counts;
  countries: Country[];
}



