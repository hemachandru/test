import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { ApiUrl } from '@app/config/constant_keys';
import { IRequestOptions } from '@app/shared/shared-HTTP-service/Interface/IRequestOptions';

@Injectable()
export class HomeService {
  private apiUrl = ApiUrl;
  private _option = <IRequestOptions>{};

  constructor(private _httpRequestService: HttpRequestService) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  // getUserAuthorizationCode(data: any, url: string): Observable<any> {
  //   return this._httpRequestService.postHttpRequestAPPToken(data, url);
  // }

  userSelection(url) {
    return this._httpRequestService.getHttpRequest(url);
  }

  getGeneralData(): Observable<any> {
    const url: any = this.apiUrl.HOME;
    return this._httpRequestService.getHttpRequestWithoutToken(url, true);
  }

  getLastestNews(): Observable<any> {
    const url: any = this.apiUrl.NEWSLIST;
    const data = '';
    return this._httpRequestService.postHttpRequestWithoutToken(data, url, true);
  }
}
