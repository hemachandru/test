import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HelpComponent } from './component/help/help.component';
import { GeneralRoutingModule } from '@app/general/general-routing.module';
import { SharedModule } from '@app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GeneralService } from '@app/general/services/general.service';
import { FaqComponent } from './component/faq/faq.component';
import {
  MatFormFieldModule,
  MatInputModule,
  MatExpansionModule,
  MatSelectModule
} from '@angular/material';
import { NewsComponent } from './component/news/news.component';
import { NewsDetailComponent } from './component/news-detail/news-detail.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { CmsTitleComponent } from './component/cms-title/cms-title.component';
import { OurTeamComponent } from './component/our-team/our-team.component';
import { PrivacyComponent } from './component/privacy/privacy.component';
import { GeneralHeaderComponent } from './component/general-header/general-header.component';
import { ClaimInfoComponent } from './component/claim-info/claim-info.component';
import { SalesRepInfoComponent } from './component/sales-rep-info/sales-rep-info.component';
import { NewsService } from './services/news.service';
import { VendorComponent } from './component/vendor/vendor.component';
import { DistributorComponent } from './component/distributor/distributor.component';
import { RetailerComponent } from './component/retailer/retailer.component';
import { SalesRepComponent } from './component/sales-rep/sales-rep.component';
import { PublicProfileComponent } from './component/public-profile/public-profile.component';
import { TermsConditionsComponent } from './component/terms-conditions/terms-conditions.component';
import { LegalInformationComponent } from './component/legal-information/legal-information.component';
import { ComingSoonPageComponent } from './component/coming-soon-page/coming-soon-page.component';

@NgModule({
  imports: [
    CommonModule,
    GeneralRoutingModule,
    SharedModule,
    FormsModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule
  ],
  exports: [
    MatInputModule,
    MatExpansionModule,
    MatSelectModule
  ],
  providers: [
    GeneralService,
    NewsService
  ],
  declarations: [
    HelpComponent,
    FaqComponent,
    NewsComponent,
    NewsDetailComponent,
    AboutUsComponent,
    GeneralHeaderComponent,
    CmsTitleComponent,
    OurTeamComponent,
    PrivacyComponent,
    ClaimInfoComponent,
    SalesRepInfoComponent,
    VendorComponent,
    DistributorComponent,
    RetailerComponent,
    SalesRepComponent,
    PublicProfileComponent,
    TermsConditionsComponent,
    LegalInformationComponent,
    ComingSoonPageComponent
  ],
})
export class GeneralModule { }
