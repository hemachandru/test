import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BannerData, CMSPage } from '@app/general/models/banner';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-retailer',
  templateUrl: './retailer.component.html',
  styleUrls: ['./retailer.component.scss']
})
export class RetailerComponent implements OnInit {
  public preloader: boolean;
  public bannerData: BannerData;
  public _CMSPageList: CMSPage;
  private apiUrl = ApiUrl;
  constructor(public _OrderService: OrderServiceService, private router: Router) { }

  ngOnInit() {
    this.bannerData = new BannerData();
    this.bannerData.customClass = this.apiUrl.RETAILER;
    this.bannerData.title = '';
    this.getOurTeamContent();
  }

  getOurTeamContent() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.RETAILER;
    this._OrderService.getServicewithoutToken( url, true).subscribe(response => {
      // const orderDetail = response as Response;
      this._CMSPageList = response.json();
      this.bannerData.title = this._CMSPageList.title;
      this.preloader = false;
    });
  }

  SubscripionPlan(id) {
    if (id) {
      localStorage.setItem(AppLocalStorageKeys.GUEST_CHANNEL_TYPE_ID, id);
      this.router.navigate(['/user/subscriptionplan']);
    }
  }

}
