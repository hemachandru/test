import { Component, OnInit, Input } from '@angular/core';
import { BannerData, CMSPage } from '@app/general/models/banner';
import { ApiUrl } from '@app/config/constant_keys';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss']
})
export class AboutUsComponent implements OnInit {
  public bannerData: BannerData;
  public _CMSPageList: CMSPage;
  private apiUrl = ApiUrl;
  public preloader: boolean;

  constructor(public _OrderService: OrderServiceService) { }

  ngOnInit() {
    this.bannerData = new BannerData();
    // this._CMSPageList = ;
    // this._CMSPageList  = new CMSPage();
    this.bannerData.customClass = this.apiUrl.ABOUT_US;
    this.bannerData.title = '';
    this.getAboutUsContent();
  }

  getAboutUsContent() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.ABOUT_US;
    this._OrderService.getServicewithoutToken( url, true).subscribe(response => {
      // const orderDetail = response as Response;
      this._CMSPageList = response.json();
      this.bannerData.title = this._CMSPageList.title;
      this.preloader = false;
    });
  }

}
