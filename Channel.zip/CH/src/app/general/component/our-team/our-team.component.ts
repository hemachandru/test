import { Component, OnInit } from '@angular/core';
import { BannerData, CMSPage } from '@app/general/models/banner';
import { ApiUrl } from '@app/config/constant_keys';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-our-team',
  templateUrl: './our-team.component.html',
  styleUrls: ['./our-team.component.scss']
})
export class OurTeamComponent implements OnInit {
  public bannerData: BannerData;
  public _CMSPageList: CMSPage;
  private apiUrl = ApiUrl;
  public preloader: boolean;

  constructor(public _OrderService: OrderServiceService) { }

  ngOnInit() {
    this.bannerData = new BannerData();
    this.bannerData.customClass = this.apiUrl.OUR_TEAM;
    this.bannerData.title = '';
    this.getOurTeamContent();
  }

  getOurTeamContent() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.OUR_TEAM;
    this._OrderService.getServicewithoutToken( url, true).subscribe(response => {
      // const orderDetail = response as Response;
      this._CMSPageList = response.json();
      this.bannerData.title = this._CMSPageList.title;
      this.preloader = false;
    });
  }

}
