import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CmsTitleComponent } from './cms-title.component';

describe('CmsTitleComponent', () => {
  let component: CmsTitleComponent;
  let fixture: ComponentFixture<CmsTitleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CmsTitleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CmsTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
