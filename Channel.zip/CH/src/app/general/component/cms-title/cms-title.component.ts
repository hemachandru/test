import { Component, OnInit, Input } from '@angular/core';
import { BannerData } from '@app/general/models/banner';

@Component({
  selector: 'app-cms-title',
  templateUrl: './cms-title.component.html',
  styleUrls: ['./cms-title.component.scss']
})


export class CmsTitleComponent implements OnInit {

  constructor() { }

  @Input() banner: BannerData;

  ngOnInit() {
  }

}
