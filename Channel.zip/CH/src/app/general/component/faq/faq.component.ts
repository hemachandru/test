import { Component, OnInit } from '@angular/core';
import { GeneralService } from '@app/general/services/general.service';
import { FaqList, Result, FaqSubDetails, Pagination } from '@app/general/models/faqlist';
import { PaginationService } from '../../../shared/shared-service/pagination.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { NoDataFound } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
  public leftmenu: boolean;
  public faqheader: Array<any>;
  public faqlist: Array<Result>;
  public faqObject: FaqList;
  public preloader: boolean;
  public faqsubDetail: FaqSubDetails;
  public searchdata: string;
  public offSet;
  public pageSize;
  public pager: any = {};
  public pagination: any;
  public resultCount: number;
  public _NoDataFound: NoDataFound;
  public HeaderName: string;
  public HeaderText: string;
  public Headerbanner: string;
  public search: string;
  public filterData: boolean;
  public presentvalue: boolean;

  constructor(private _generalService: GeneralService, private _pagination: PaginationService, private translate: TranslateService) {
    this.leftmenu = false;
    this.faqheader = [];
    this.faqlist = [];
    this.faqObject = new FaqList();
    this.preloader = false;
    this.faqsubDetail = new FaqSubDetails();
    this.faqObject.pagination = new Pagination();
    this.searchdata = '';
    this.offSet = 1;
    this.pageSize = 4;
    this._NoDataFound = new NoDataFound();
    this.HeaderName = this.translate.instant('Faq.HeaderName');
    this.HeaderText = this.translate.instant('Faq.subtitle');
    this.Headerbanner = '../assets/images/faq.png';
    this.search = '';
    this.presentvalue = false;
  }


  ngOnInit() {
    this.faqHeader();
    this.subCatgory(this.searchdata, this.offSet, this.pageSize);
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    // this._NoDataFound.noDataMsg = 'There is no faq from channel hub for you, at this time';
    this._NoDataFound.noDataMsg = this.translate.instant('Faq.nodata');
    this.filterData = false;
  }

  sidemenu() {
    if (!this.leftmenu) {
      this.leftmenu = true;
    } else {
      this.leftmenu = false;
    }
  }

  showFilter() {
    this.filterData = !this.filterData;
  }

  searchFunction(event) {
    this.faqsubDetail = {};
    this.subCatgory(event.value, this.offSet, this.pageSize);
    this.searchdata = event.value;
    event.blur();
  }

  faqHeader() {
    this._generalService.faqHeader().subscribe(serviceRes => {
      const response = serviceRes as Response;
      if (response.ok) {
        const result = response.json() as any;
        if (result.results.length > 0) {
          this.faqheader = result.results;
        } else {
          console.log('error');
        }

      }
    });
  }

  subCatgory(searchkey, offSet, pageSize) {
    this.preloader = true;
    this.presentvalue = false;
    this.faqObject.pagination.offset = offSet || this.offSet;
    this.faqObject.pagination.page = this.pageSize;

    this._generalService.faqList(this.faqsubDetail, searchkey, this.faqObject).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const faq_List = response.json() as any;
        this.faqlist = faq_List.results;
        this.resultCount = faq_List.pagination.total;
        if (!ValidationService.isNullOrEmpty(searchkey)) {
          this.presentvalue = true;
          if (this.resultCount === 0) {
            // tslint:disable-next-line:quotemark
            this._NoDataFound.noDataMsg = this.translate.instant('Faq.nosearchFaq') + ("'" + searchkey + "'");
          }
        }
        this.preloader = false;
      }
      this.preloader = false;
      this.setPage(offSet);
      // this.pager = this._pagination.setPage(this.faqObject.pagination.offset, this.resultCount, this.pageSize);
    });
  }

  paginationFunction(data: number) {
    this.subCatgory(this.searchdata, data, this.pageSize);
  }

  paginationFunctionOffset(pageSize: number) {
    this.pageSize = pageSize;
    this.subCatgory(this.searchdata, 1, pageSize);
  }

  setPage(page: number) {

    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 4);
      return;
    }

    // get pager object from service
    this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize, 4);
  }

  categoryFilter(subCategory, faqcategory) {
    if ((!ValidationService.isNullOrEmpty(subCategory.faqcategoryid))) {
      this.faqsubDetail.faqcategoryid = parseInt(subCategory.faqcategoryid, 10);
      // subCategory.faqSubCategory.forEach(subfaq => {
      this.faqsubDetail.faqsubcategoryid = parseInt(faqcategory.faqsubcategoryid, 10);
      this.search = '';
      this.searchdata = '';
      // });
    }
    this.subCatgory(this.searchdata, this.offSet, this.pageSize);
  }
}
