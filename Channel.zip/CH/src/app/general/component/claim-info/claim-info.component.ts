import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { SuccesErrorMessage, UserAccountStatus, ChannelHubCommon } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { SharedService } from '@app/shared/shared-service/shared-service';

@Component({
  selector: 'app-claim-info',
  templateUrl: './claim-info.component.html',
  styleUrls: ['./claim-info.component.scss']
})
export class ClaimInfoComponent implements OnInit {
  public verificationObject: SuccesErrorMessage;
  channelHubContactMail: string = ChannelHubCommon.channelHubContactEmail;
  title: string;
  channelId: string;
  constructor(private sharedService: SharedService, private router: Router) { }
  ngOnInit() {
    this.title = 'claininfo.title';
    this.getChannelProfileStatus();
  }

  bindVerificationPage() {
    this.channelId = '000' + parseInt(localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID), 10);
    this.verificationObject = {
      errorId: '2',
      errorType: 'Verified',
      errorTitle: 'Claim Info',
      icon: '',
      iconMessage: '',
      messages: [
        {
          messageContent: '',
        },
        {
          messageContent: 'claininfo.succesmsg',
        },
        {
          messageContent: 'claininfo.claimNo' + this.channelId,
        },
        {
          // tslint:disable-next-line:max-line-length
          messageContent: '<font size="2">For more details, <span class="bold-text"><a href="/help/support">' + this.channelHubContactMail + '</a></span></font>',
        }
      ],
      button: [{
        buttonType: '',
        buttonName: '',
        buttonValue: '',
        buttonLink: ''
      }],
      showButtonBlock: false
    };

  }

  async getChannelProfileStatus() {
    let userstatus;
    userstatus = await this.sharedService.getChannelStatusId();
    const response = userstatus as Response;
    if (response.ok) {
      const userStatusData = userstatus.json();
      localStorage.setItem(AppLocalStorageKeys.USER_STATUS_DETAILS, JSON.stringify(userstatus.json()));
      if (parseInt(userStatusData.channelStatusId, 10) === UserAccountStatus.CLAIM_APPROVED) {
        this.router.navigate(['/account', { outlets: { 'accountroute': ['profile'] } }]);
      } else {
        this.bindVerificationPage();
      }
    }

    return userstatus.json();
  }

}
