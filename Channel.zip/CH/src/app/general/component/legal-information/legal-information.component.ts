import { Component, OnInit } from '@angular/core';
import { BannerData, CMSPage } from '@app/general/models/banner';
import { WebUrl, ApiUrl } from '@app/config/constant_keys';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-legal-information',
  templateUrl: './legal-information.component.html',
  styleUrls: ['./legal-information.component.scss']
})
export class LegalInformationComponent implements OnInit {
  public bannerData: BannerData;
  public preloader: boolean;
  public webUrl = WebUrl;
  public _CMSPageList: CMSPage;
  public _PrivacyList: CMSPage;
  private apiUrl = ApiUrl;
  public privacyTitle: string;

  constructor(public _OrderService: OrderServiceService) {

  }

  ngOnInit() {
    this.bannerData = new BannerData();
    this.bannerData.customClass = 'about';
    this.bannerData.title = 'Legal Information';
    this.getLegalInformation();
    this.getPrivacy();
  }

  /**Call legal infomartion service */
  getLegalInformation() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.LEGAL_INFORMATION;
    this._OrderService.getServicewithoutToken(url, true).subscribe(response => {
      this._CMSPageList = response.json();
      this.preloader = false;
    });
  }

  /**Call Privacy service */
  getPrivacy() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.PRIVACY;
    this._OrderService.getServicewithoutToken(url, true).subscribe(response => {
      this._PrivacyList = response.json();
      this.privacyTitle = this._PrivacyList.title;
      this.preloader = false;
    });
  }

}
