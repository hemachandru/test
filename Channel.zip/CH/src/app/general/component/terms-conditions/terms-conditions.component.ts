import { Component, OnInit } from '@angular/core';
import { BannerData, CMSPage } from '@app/general/models/banner';
import { ApiUrl } from '@app/config/constant_keys';
import { OrderServiceService } from '@app/order/service/order-service.service';

@Component({
  selector: 'app-terms-conditions',
  templateUrl: './terms-conditions.component.html',
  styleUrls: ['./terms-conditions.component.scss']
})
export class TermsConditionsComponent implements OnInit {

  public preloader: boolean;
  public bannerData: BannerData;
  public _CMSPageList: CMSPage;
  private apiUrl = ApiUrl;
  constructor(public _OrderService: OrderServiceService) { }

  ngOnInit() {
    this.bannerData = new BannerData();
    this.bannerData.customClass = this.apiUrl.SALES_REP;
    this.bannerData.title = '';
    this.getOurTeamContent();
  }

  getOurTeamContent() {
    this.preloader = true;
    const url: any = this.apiUrl.CMS_PAGE + '/' + this.apiUrl.TERMS_CONDITIONS;
    this._OrderService.getServicewithoutToken( url, true).subscribe(response => {
      this._CMSPageList = response.json();
      this.bannerData.title = this._CMSPageList.title;
      this.preloader = false;
    });
  }

}
