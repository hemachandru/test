import { Component, OnInit } from '@angular/core';
import { SuccesErrorMessage, ChannelHubCommon } from '@app/config/constant';
import { AppLocalStorageKeys } from '@app/config/constant_keys';

@Component({
  selector: 'app-sales-rep-info',
  templateUrl: './sales-rep-info.component.html',
  styleUrls: ['./sales-rep-info.component.scss']
})
export class SalesRepInfoComponent implements OnInit {
  public verificationObject: SuccesErrorMessage;
  channelHubContactMail: string = ChannelHubCommon.channelHubsalesRepContactEmail;
  title: string;
  constructor() { }
  ngOnInit() {
    this.title = 'salesRep.title';
    this.bindVerificationPage();
  }

  bindVerificationPage() {
    this.verificationObject = {
      errorId: '2',
      errorType: 'Verified',
      errorTitle: 'salesRep.title',
      icon: '',
      iconMessage: '',
      messages: [
        {
          messageContent: '',
        },
        {
          messageContent: 'salesRep.thankreg',
        },
        {
          // tslint:disable-next-line:max-line-length
          messageContent: 'salesRep.message1',
        },
        {
          // tslint:disable-next-line:max-line-length
          messageContent: '<font size="2">If you have any further clarification kindly contact, <span class="bold-text"><a href="/help/support">' + this.channelHubContactMail + '</a></span></font>',
        }
      ],
      button: [{
        buttonType: '',
        buttonName: '',
        buttonValue: '',
        buttonLink: ''
      }],
      showButtonBlock: false
    };

  }

}
