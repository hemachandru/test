import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Response } from '@angular/http';
import { ComplainType, Config } from '@app/config/constant';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { ComplaintCategory, Complaint, CompalainDocument } from '../../models/complaint';
import { ToastrService } from 'ngx-toastr';
import { CountryMaster } from '@app/shared/models/shared-model';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { SharedService } from '@app/shared/shared-service/shared-service';
import { GeneralService } from '../../services/general.service';
import { CommonHelper } from '@app/shared/common-helper';
import { S3Buckets, ChannelType } from '@app/config/constant';
import { S3UploadFileService } from '@app/shared/shared-service/s3-upload-service';
import { Contact } from '@app/shared/models/contact';
import { PlatformLocation } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit, OnDestroy {
  public title;
  public webUrl = WebUrl;
  private queryParams: any;
  public complaintCategories: Array<ComplaintCategory>;
  public complaint: Complaint;
  public channelType: string;
  public matchingProcess: string;
  public matchingProcessLink: string;
  public productSuggestion: string;
  public productSuggestionLink: string;
  countryMasterList: Array<CountryMaster>;
  isGuestUser: boolean;
  complainType = ComplainType;
  currentComplaintType: string;

  helpForm: FormGroup;
  firstnameCtrl: FormControl;
  lastnameCtrl: FormControl;
  emailCtrl: FormControl;
  phonenoCtrl: FormControl;
  phonenoCodeCtrl: FormControl;
  mobilenoCtrl: FormControl;
  mobilenoCodeCtrl: FormControl;
  countryidCtrl: FormControl;
  complainttypeCtrl: FormControl;
  subjectCtrl: FormControl;
  channeltypeCtrl: FormControl;
  complaintcategoryidCtrl: FormControl;
  detaildescCtrl: FormControl;
  iprurlCtrl: FormControl;
  channelidCtrl: FormControl;
  useridCtrl: FormControl;
  public atachments: Array<any>;
  public preLoader = false;
  complainDocuments: Array<CompalainDocument>;
  controlIPRurl: string;
  ipr_msg_code: string;
  navigationSubscription: any;
  ctrlImageZone: string;
  msg_code_image_zone: string;
  public errorAccept: boolean;
  public conditionCheck: boolean;

  constructor(
    private generalService: GeneralService,
    private activeRoute: ActivatedRoute, private router: Router,
    private toastrService: ToastrService, private s3UploadFileService: S3UploadFileService,
    private sharedBusiness: SharedBusiness, private config: Config,
    private sharedService: SharedService, private platformLocation: PlatformLocation,
    private translate: TranslateService) {
    this.isGuestUser = localStorage.getItem(AppLocalStorageKeys.AUTH_Token,
    ) ? false : true;
    this.atachments = new Array<any>();

    this.ctrlImageZone = 'complaintImages';

    this.navigationSubscription = this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.loadForm();
      }
    });
  }

  ngOnInit() {
    this.controlIPRurl = 'iprurl';
    this.ipr_msg_code = '';
    this.channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
    if (this.channelType === 'DISTRIBUTOR') {
      this.matchingProcess = 'Tutorial explaining our matching process';
      this.productSuggestion = 'Tutorial explaining the product suggestion';
      this.matchingProcessLink = 'http://ior.ad/6whs';
      this.productSuggestionLink = 'http://ior.ad/6wwf';
    } else if (this.channelType === 'RETAILER') {
      this.matchingProcess = 'Tutorial explaining our matching process';
      this.productSuggestion = 'Tutorial explaining the product suggestion';
      this.matchingProcessLink = 'http://ior.ad/6wp7';
      this.productSuggestionLink = 'http://ior.ad/6wwf';

    } else if (this.channelType === 'VENDOR') {
      this.matchingProcess = 'Tutorial explaining our matching process';
      this.productSuggestion = 'Tutorial explaining the product management';
      this.matchingProcessLink = 'http://ior.ad/6w9e';
      this.productSuggestionLink = 'http://ior.ad/6wL2';
    }
  }

  ngOnDestroy() {
    if (this.navigationSubscription) {
      this.navigationSubscription.unsubscribe();
    }
  }

  loadForm() {
    this.msg_code_image_zone = '';
    delete this.complainDocuments;
    this.complainDocuments = new Array<CompalainDocument>();
    this.activeRoute.params.subscribe(params => {
      this.queryParams = params;
    });
    const key = this.queryParams.key ? this.queryParams.key : ComplainType.CONTACT_TYPE;

    if (key) {
      this.initializeForm();
      const channelType = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE);
      if (channelType) {
        this.channeltypeCtrl.setValue(channelType);
      } else {
        this.channeltypeCtrl.setValue(ChannelType.GUEST);
      }
      if (key.toString().toUpperCase() === ComplainType.COMPLAINT.toUpperCase() &&
        !this.isGuestUser) {
        this.currentComplaintType = ComplainType.COMPLAINT;
        this.title = 'help.complaint';
        this.complainttypeCtrl.setValue(this.currentComplaintType);
        this.getComplainListByCategoryType(ComplainType.COMPLAINT);
        this.helpForm.controls['iprurl'].clearValidators();
        this.helpForm.controls['iprurl'].setErrors(null);
      } else if (key.toString().toUpperCase() === ComplainType.CONTACT_TYPE.toUpperCase()
        || key.toString().toUpperCase() === ComplainType.SUPPORT.toUpperCase()) {
        this.title = 'help.support';
        this.currentComplaintType = ComplainType.CONTACT_TYPE;
        this.complainttypeCtrl.setValue(this.currentComplaintType);
        this.getComplainListByCategoryType(ComplainType.CONTACT_TYPE);
        this.helpForm.controls['iprurl'].clearValidators();
        this.helpForm.controls['iprurl'].setErrors(null);
      } else if (key.toString().toUpperCase() === ComplainType.TUTORIALS.toUpperCase() &&
        !this.isGuestUser) {
        this.title = 'help.tutorials';
        this.currentComplaintType = ComplainType.TUTORIALS;
        this.getComplainListByCategoryType(ComplainType.TUTORIALS);
      } else if (key.toString().toUpperCase() === ComplainType.IPR.toUpperCase() &&
        !this.isGuestUser) {
        this.title = 'help.ipr';
        this.currentComplaintType = ComplainType.IPR;
        this.complainttypeCtrl.setValue(this.currentComplaintType);
        this.getComplainListByCategoryType(ComplainType.IPR);
        // this.helpForm.controls['iprurl'].setValue('');
        this.helpForm.controls['iprurl'].setValidators([Validators.required,
        Validators.maxLength(255),
          //  Validators.pattern(this.config.urlPattern)
        ]);
      } else {
        this.router.navigate(['']);
      }
    } else {
      this.router.navigate(['']);
    }

    if (!this.isGuestUser) {
      this.getContact();
    } else {
      this.getCountryList();
    }
  }

  initializeForm() {
    this.complainttypeCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.channeltypeCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.firstnameCtrl = new FormControl('', Validators.compose(
      [Validators.required, Validators.minLength(2), Validators.maxLength(30)]
    ));

    this.lastnameCtrl = new FormControl('', Validators.compose(
      [Validators.required, Validators.minLength(1), Validators.maxLength(30)]));

    this.emailCtrl = new FormControl('', Validators.compose([Validators.required,
    Validators.pattern(this.config.emailPattern)]));

    this.phonenoCtrl = new FormControl('',
      Validators.compose([Validators.required, Validators.pattern(this.config.phoneCodeWithOutPlus),
      Validators.minLength(4),
      Validators.maxLength(20),
        // Validators.pattern(this.config.mobnumPattern)
      ]));

    this.phonenoCodeCtrl = new FormControl('',
      Validators.compose([Validators.pattern(this.config.phoneCodeWithPlus),
      Validators.minLength(1),
      Validators.maxLength(6),
      ]));

    this.mobilenoCtrl = new FormControl('',
      Validators.compose([Validators.required, Validators.pattern(this.config.phoneCodeWithOutPlus), Validators.minLength(4),
      Validators.maxLength(20),
        // Validators.pattern(this.config.mobnumPattern)
      ]));

    this.mobilenoCodeCtrl = new FormControl('',
      Validators.compose([Validators.pattern(this.config.phoneCodeWithPlus),
      Validators.minLength(1),
      Validators.maxLength(6),
      ]));

    this.countryidCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.complaintcategoryidCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.subjectCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.detaildescCtrl = new FormControl('', Validators.compose([Validators.required]));
    this.iprurlCtrl = new FormControl('', Validators.compose([,
      Validators.maxLength(255),
      //  Validators.pattern(this.config.urlPattern)
    ]
    ));
    this.channelidCtrl = new FormControl();
    this.useridCtrl = new FormControl();

    this.helpForm = new FormGroup({
      firstname: this.firstnameCtrl,
      lastname: this.lastnameCtrl,
      email: this.emailCtrl,
      phoneno: this.phonenoCtrl,
      phonenoCode: this.phonenoCodeCtrl,
      mobileno: this.mobilenoCtrl,
      mobilenoCode: this.mobilenoCodeCtrl,
      countryid: this.countryidCtrl,
      complainttype: this.complainttypeCtrl,
      subject: this.subjectCtrl,
      channeltype: this.channeltypeCtrl,
      complaintcategoryid: this.complaintcategoryidCtrl,
      detaildesc: this.detaildescCtrl,
      iprurl: this.iprurlCtrl,
      channelid: this.channelidCtrl,
      userid: this.useridCtrl
    });
  }
  addComplainDocument() {
    const complaintDoc = <CompalainDocument>{};
    this.complainDocuments.push(complaintDoc);
    this.atachments.push('');
  }

  buildFormItem() {
    let controls = {};
    controls = {
      documentPath: new FormControl('', Validators.compose([Validators.required])),
      documenttype: new FormControl('', Validators.compose([Validators.required]))
    };

    return new FormGroup(controls);
  }

  deleteFormItem(index) {
    this.complainDocuments.splice(index, 1);
    this.atachments.splice(index, 1);
    this.msg_code_image_zone = '';
  }

  getComplainListByCategoryType(complainType: string) {
    this.generalService.getComplainListByCategoryType(complainType).subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.complaintCategories = response.json() as Array<ComplaintCategory>;
      }
    });
  }

  getCountryList() {
    this.sharedBusiness.getCountryListBusiness().subscribe(data => {
      this.countryMasterList = data;
      const response = data as Response;
      if (response.ok) {
        this.countryMasterList = data;
        this.countryidCtrl.setValue('');
      }
    });
  }

  getContact() {
    const result = localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID);
    let contactId: number;
    if (result != null && result !== '') {
      contactId = parseInt(result, 10);
      this.sharedService.getContact(contactId).subscribe(response => {
        const contactInfo = (<Response>response).json() as Contact;
        this.setContactData(contactInfo);
      },
        (error) => {
          console.log(error);
        });
    }
  }

  setContactData(contactInfo: Contact): void {
    this.firstnameCtrl.setValue(contactInfo.firstName);
    this.lastnameCtrl.setValue(contactInfo.lastName);
    this.emailCtrl.setValue(contactInfo.email);
    const mobileNumber = contactInfo.mobileNo.split('-');
    if (contactInfo.phone1) {
      const PhoneNumber1 = contactInfo.phone1.split('-');
      this.phonenoCodeCtrl.setValue(PhoneNumber1[0]);
      this.phonenoCtrl.setValue(PhoneNumber1[1]);
    } else if (contactInfo.phone2) {
      const PhoneNumber2 = contactInfo.phone2.split('-');
      this.phonenoCodeCtrl.setValue(PhoneNumber2[0]);
      this.phonenoCtrl.setValue(PhoneNumber2[1]);
    } else {
      this.phonenoCodeCtrl.setValue(mobileNumber[0]);
      this.phonenoCtrl.setValue(mobileNumber[1]);
    }

    this.mobilenoCtrl.setValue(mobileNumber[1]);
    this.mobilenoCodeCtrl.setValue(mobileNumber[0]);
    this.countryidCtrl.setValue(contactInfo.countryId);
    this.useridCtrl.setValue(contactInfo.user.userId);
    const channelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    if (channelId) {
      this.channelidCtrl.setValue(channelId);
    }
  }

  submit() {
    if (this.helpForm.valid) {
      if (this.errorAccept) {
        this.errorAccept = true;
        this.conditionCheck = false;
        if (this.currentComplaintType === ComplainType.IPR) {
          if (!this.validateIPRUrl(this.iprurlCtrl.value)) {
            this.ipr_msg_code = '0001';
            return;
          }
        }

        const complaint = <Complaint>this.helpForm.value;
        const complaintSendData = new Complaint();
        complaintSendData.complainttype = complaint.complainttype;
        if (complaint.channelid) {
          complaintSendData.channelid = parseInt(complaint.channelid.toString(), 10);
          complaintSendData.userid = parseInt(complaint.userid.toString(), 10);
        }

        complaintSendData.channeltype = complaint.channeltype;
        complaintSendData.firstname = complaint.firstname;
        complaintSendData.lastname = complaint.lastname;
        complaintSendData.email = complaint.email;
        complaintSendData.phoneno = this.phonenoCodeCtrl.value + '-' + parseInt(complaint.phoneno.toString(), 10);
        complaintSendData.mobileno = this.mobilenoCodeCtrl.value + '-' + parseInt(complaint.mobileno.toString(), 10);
        complaintSendData.countryid = parseInt(complaint.countryid.toString(), 10);
        complaintSendData.subject = complaint.subject;
        complaintSendData.detaildesc = complaint.detaildesc;
        complaintSendData.iprurl = complaint.iprurl;
        complaintSendData.complaintcategoryid = parseInt(complaint.complaintcategoryid.toString(), 10);
        complaintSendData.compalainDocument = new Array<CompalainDocument>();
        if (this.complainDocuments && this.complainDocuments.length > 0) {
          this.complainDocuments.forEach(item => {
            complaintSendData.compalainDocument.push(<CompalainDocument>{
              documentPath: item.documentPath,
              documenttype: item.documenttype
            });
          });
        }

        this.preLoader = true;
        this.generalService.postComplain(complaintSendData).subscribe(result => {
          const response = result as Response;
          if (response.ok) {
            this.toastrService.success(this.translate.instant((this.currentComplaintType === ComplainType.IPR ||
              this.currentComplaintType === ComplainType.COMPLAINT) ?
              'help.toastMsg.complaintSaveSuccess' : 'help.toastMsg.helpSaveSuccess'));
            if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
              this.router.navigate(['/dashboard']);
            } else {
              this.router.navigate(['']);
            }

          } else {
            this.toastrService.error(this.translate.instant('help.toastMsg.failPost'));
          }
          this.preLoader = false;
        },
          (error) => {
            this.toastrService.error(this.translate.instant('help.toastMsg.tryagain'));
            console.log(error);
            this.preLoader = false;
          });
      } else {
        this.errorAccept = false;
        this.conditionCheck = true;
      }
    } else {
      this.markFormGroupTouched(this.helpForm);
    }
  }

  close() {
    if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
      this.router.navigate(['/dashboard']);
    } else {
      this.router.navigate(['']);
    }
  }

  async attachmentUpload(e) {
    this.msg_code_image_zone = '';
    const file = e.target.files.item(0);
    if (file) {
      if (this.complainDocuments.length < 5) {
        this.addComplainDocument();
      } else {
        this.msg_code_image_zone = '0002';
        return;
      }

      const indexArr = this.complainDocuments.length - 1;
      // const Dimension = 200;

      let fileExtension = file.name.substr((file.name.lastIndexOf('.') + 1));
      fileExtension = fileExtension.toString().toLowerCase();
      this.preLoader = true;
      if (CommonHelper.checkValidImage(fileExtension) || fileExtension === 'pdf') {
        const reader = new FileReader();
        const img = new Image();
        const self = this;
        // tslint:disable-next-line:no-shadowed-variable
        reader.onload = async (event: any) => {
          if (fileExtension !== 'pdf') {
            img.src = event.target.result;
            img.onload = async function () {
              // img.width === Dimension && img.height === Dimension
              if (img) {
                self.atachments[indexArr] = event.target.result;
                const folderName = S3Buckets.ACCOUNT_S3 + '/';
                const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
                e.target.value = null;
                self.preLoader = false;
                if (resImagePath && resImagePath.key) {
                  self.complainDocuments[indexArr].documentPath = resImagePath.key;
                  self.complainDocuments[indexArr].documenttype = 'image';
                } else {
                  self.msg_code_image_zone = '0003';
                  self.complainDocuments.splice(indexArr, 1);
                }
              } else {
                self.preLoader = false;
                if (self.complainDocuments.length < 5) {
                  self.deleteFormItem(indexArr);
                }
                e.target.value = null;
              }
            };
          } else {
            self.atachments[indexArr] = 'assets/images/pdf-default.png';
            const folderName = S3Buckets.ACCOUNT_S3 + '/';
            const resImagePath: any = await self.s3UploadFileService.uploadfile(file, folderName);
            self.preLoader = false;
            e.target.value = null;
            if (resImagePath && resImagePath.key) {
              self.complainDocuments[indexArr].documentPath = resImagePath.key;
              self.complainDocuments[indexArr].documenttype = 'pdf';
            } else {
              self.msg_code_image_zone = '0003';
              self.complainDocuments.splice(indexArr, 1);
            }
          }
        };
        reader.readAsDataURL(e.target.files[0]);
      } else {
        if (this.complainDocuments.length > 0) {
          this.deleteFormItem(indexArr);
        }
        this.msg_code_image_zone = '0001';
        this.preLoader = false;
        e.target.value = null;
      }
    }
  }

  markFormGroupTouched(formGroup) {
    const keys = Object.keys(formGroup.controls);
    keys.forEach(val => {
      const ctrl = formGroup.controls[val];
      if (!ctrl.valid) {
        ctrl.markAsTouched();
      }
    });
  }

  validateIPRUrl(iprUrl: string) {
    const pageURL = (this.platformLocation as any).location.hostname;
    if (iprUrl) {
      if (pageURL) {
        return iprUrl.includes(pageURL);
      } else {
        return true;
      }
    } else {
      return false;
    }
  }

  onIprUrlChange() {
    this.ipr_msg_code = '';
  }

  herebyAccept(event) {
    this.errorAccept = !this.errorAccept;
  }

  // Set Country code
  setPhoneCode() {
    const countryData = this.countryMasterList.filter(item => parseInt(item.countryId, 10)
      === parseInt(this.countryidCtrl.value, 10));
    if (countryData[0].phoneCode) {
      this.mobilenoCodeCtrl.setValue(countryData[0].phoneCode);
      this.phonenoCodeCtrl.setValue(countryData[0].phoneCode);
    }
  }

  notAllowSpace(e) {
    if (e.which === 32 || e.which === 45) {
      return false;
    }
  }
}
