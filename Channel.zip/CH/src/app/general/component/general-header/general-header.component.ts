import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-general-header',
  templateUrl: './general-header.component.html',
  styleUrls: ['./general-header.component.scss']
})
export class GeneralHeaderComponent implements OnInit {
  @Input() HeaderName: string;
  @Input() HeaderText: string;
  @Input() HeaderBanner: string;
  @Output() searchChanged = new EventEmitter();
  public newsearch: string;
  public clearsearch: string;
  focusclass: boolean;
  input: any;

  @Input() set search(value: string) {
    this.newsearch = value;
    // this.clearsearch = '';
  }

  get search() {
    return this.newsearch;
  }
  constructor() {
    // this.newsearch = this.newsearch;
  }

  ngOnInit() {
    this.focusclass = false;
  }

  clearitem(clearevent, event) {
    if (clearevent === '') {
      this.newsearch = '';
      this.search = '';
      event.blur();
      this.searchChanged.emit(clearevent);
    }
  }

  Searchitem(search, event) {
    this.newsearch = search;
    event.blur();
    this.searchChanged.emit(this.newsearch);
  }

}
