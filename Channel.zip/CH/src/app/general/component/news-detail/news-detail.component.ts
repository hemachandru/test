import { Component, OnInit } from '@angular/core';
import { GeneralService } from '@app/general/services/general.service';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { NewsItem, NewsList, Result, FilterNewsList, Tags, Pagination, NewsKey } from '@app/general/models/newslist';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { NoDataFound } from '@app/shared/models/shared-model';
import { NewsService } from '@app/general/services/news.service';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-news-detail',
  templateUrl: './news-detail.component.html',
  styleUrls: ['./news-detail.component.scss']
})
export class NewsDetailComponent implements OnInit {
  public HeaderName: string;
  public HeaderText: string;
  public Headerbanner: string;
  public preloader: boolean;
  public searchdata: string;
  public resultCount: number;
  public _NoDataFound: NoDataFound;
  public newsId: any;
  public newsObject: NewsItem;
  public newslist: Array<Result>;
  public newsfilter: FilterNewsList;
  public pageSize;
  public offSet;
  public tagsonly: Array<Tags>;
  public newsitemObject: NewsList;
  public newlistempty: any;
  subscription: Subscription;

  constructor(private _generalService: GeneralService, public _newsservice: NewsService,
    private activatedRoute: ActivatedRoute, private router: Router,
    private translate: TranslateService) {
    this.HeaderName = this.translate.instant('newslist.bodyLabels.title');
    this.HeaderText = this.translate.instant('newslist.bodyLabels.headerText');
    this.Headerbanner = '../assets/images/news.png';
    this.preloader = false;
    this.searchdata = '';
    this.offSet = 1;
    this.pageSize = 10;
    this._NoDataFound = new NoDataFound();
    this.newsObject = new NewsItem();
    this.newslist = new Array<Result>();
    this.newsfilter = new FilterNewsList();
    this.tagsonly = new Array<Tags>();
    this.newsitemObject = new NewsList();
    this.newsitemObject.pagination = new Pagination();
    this.newlistempty = {};
  }

  ngOnInit() {
    this._NoDataFound.noDataMsg = this.translate.instant('newslist.bodyLabels.presentlynoNews');

    this.activatedRoute.params.subscribe((params: any) => {
      this.newsId = parseInt(params.id, 10);
      this.newsDetails(this.newsId);
    });

  }
  newsDetails(id) {
    this.preloader = true;
    this._generalService.newsDetail(id).subscribe(res => {
      const response = res as Response;
      this.preloader = false;
      if (response.ok) {
        const result = response.json() as any;
        if (result) {
          this.newsObject = result;
          this.newsList(this.newsObject, this.searchdata, this.offSet, this.pageSize);
        } else {
          console.log('error');
        }

      }
    });
  }

  newsList(newsItem, searchkey, offSet, pageSize) {
    this.preloader = true;
    this.newsitemObject.pagination.page = this.pageSize;
    this.newsitemObject.pagination.offset = this.offSet;

    if ((!ValidationService.isNullOrEmpty(newsItem.newscategoryid))) {
      this.newsfilter.newscategoryid = [parseInt(newsItem.newscategoryid, 10)];
    }

    if ((!ValidationService.isNullOrEmpty(newsItem.newstypeid))) {
      this.newsfilter.newstypeid = [parseInt(newsItem.newstypeid, 10)];
    }
    if (!ValidationService.isNullOrEmpty(newsItem.newsKey)) {
      newsItem.newsKey.forEach(tag => {
        const tagid = parseInt(tag.newskeyid, 10);
        this.tagsonly.push(tagid);
      });
      this.newsfilter.keys = this.tagsonly;
    }

    if ((!ValidationService.isNullOrEmpty(newsItem.newsid))) {
      this.newsfilter.excludenewsid = parseInt(newsItem.newsid, 10);
    }

    this._generalService.newsList(this.newsfilter, searchkey, this.newsitemObject).subscribe(res => {
      this.preloader = false;
      const response = res as Response;
      if (response.ok) {
        const news_List = response.json() as any;
        this.newslist = news_List.results;
        this.resultCount = news_List.pagination.total;
      }

    });
  }

  seeallNews() {
    this.router.navigate(['/newslist']);
  }

  readMore(readeNews) {
    this.newsId = parseInt(readeNews.newsid, 10);
    this.newsDetails(this.newsId);
  }

  searchFunction(event: string) {
    this.searchdata = event;
    this._newsservice.sendDatastring(event);
    this.router.navigate(['/newslist']);
  }

  tagesclick(tag: NewsKey) {
    this._newsservice.sendData(tag);
    this.router.navigate(['/newslist']);
  }
}
