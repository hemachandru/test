import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coming-soon-page',
  templateUrl: './coming-soon-page.component.html',
  styleUrls: ['./coming-soon-page.component.scss']
})
export class ComingSoonPageComponent implements OnInit {
  public titlemsg: string;
  public title: string;
  constructor() {
    this.title = 'comingSoonPage.Title';
    this.titlemsg = 'comingSoonPage.Description';
   }

  ngOnInit() {
  }

}
