import { Component, OnInit } from '@angular/core';
import { GeneralService } from '@app/general/services/general.service';
import { Pagination, NewsList, Result, FilterNewsList, Tags } from '@app/general/models/newslist';
import { PaginationService } from '../../../shared/shared-service/pagination.service';
import { ValidationService } from '@app/shared/shared-service/validation-service';
import { NoDataFound } from '@app/shared/models/shared-model';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { NewsService } from '@app/general/services/news.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.scss']
})
export class NewsComponent implements OnInit {
  public HeaderName: string;
  public HeaderText: string;
  public Headerbanner: string;
  public preloader: boolean;
  public searchdata: string;
  public offSet;
  public pageSize;
  public pager: any = {};
  public pagination: any;
  public resultCount: number;
  public _NoDataFound: NoDataFound;
  public newslist: Array<Result>;
  public newsObject: NewsList;
  public newlistempty: any;
  public tagsonly: Array<Tags>;
  subscription: Subscription;
  public noresult: boolean;
  searchCount: any;
  public presentvalue: boolean;
  public searchother: string;
  constructor(private _generalService: GeneralService, public _newsservice: NewsService,
    private _pagination: PaginationService, private router: Router, private translate: TranslateService) {
    this.HeaderName = this.translate.instant('newslist.bodyLabels.title');
    this.HeaderText = this.translate.instant('newslist.bodyLabels.headerText');
    this.Headerbanner = '../assets/images/news.png';
    this.preloader = false;
    this.offSet = 1;
    this.pageSize = 10;
    this._NoDataFound = new NoDataFound();
    this.newslist = [];
    this.newsObject = new NewsList();
    this.newsObject.pagination = new Pagination();
    this.newlistempty = new FilterNewsList();
    this.tagsonly = [];
    this.presentvalue = false;
  }

  ngOnInit() {
    this.noresult = false;
    this.searchdata = '';
    this.resultCount = 0;
    this._NoDataFound.noDataImageSrc = '../assets/images/search.png';
    this._NoDataFound.noDataMsg = this.translate.instant('newslist.bodyLabels.noNews');
    if (!ValidationService.isNullOrEmpty(this._newsservice.filterSource.value)) {
      this.subscription = this._newsservice.currentFilterDetail.subscribe(item => {
        this.tagesclick(item);
      });
    } else if (!ValidationService.isNullOrEmpty(this._newsservice.stringSource.value)) {
      this.subscription = this._newsservice.currentstringDetail.subscribe(item => {
        this.searchdata = item;
        this.searchFunction(item);
      });
    } else {
      this.newsList(this.newlistempty, this.searchdata, this.offSet, this.pageSize);
    }
  }

  newsList(subCategory, searchkey, offSet, pageSize) {
    this.preloader = true;
    this.noresult = false;
    this.presentvalue = false;
    this.newsObject.pagination.offset = offSet || this.offSet;
    this.newsObject.pagination.page = this.pageSize;


    this._generalService.newsList(this.newlistempty, searchkey, this.newsObject).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const news_List = response.json() as any;
        this.newslist = news_List.results;
        this.resultCount = news_List.pagination.total;
        if (!ValidationService.isNullOrEmpty(this.searchdata)) {
          this.searchCount = news_List.pagination.total;
          this.presentvalue = true;
          if (this.resultCount === 0) {
            // tslint:disable-next-line:quotemark
            this._NoDataFound.noDataMsg = this.translate.instant('newslist.bodyLabels.noSearchNews') + ("'" + searchkey + "'");
          }
        }
        if (this.resultCount !== 0) {
          this.pager = this.setPage(offSet);
        } else {
          this.noresult = true;
        }

      }
      this.preloader = false;
    },
      (error) => {
        this.noresult = true;
        console.log(error);
      });
  }

  paginationFunction(data: number) {
    this.newsList(this.newlistempty, this.searchdata, data, this.pageSize);
  }
  setPage(page: number) {
    if (page <= 0 || page > this.pager.totalPages) {
      this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
      return;
    }
    return this.pager = this._pagination.getPager(this.resultCount, page, this.pageSize);
  }

  newDetailsView(news) {
    this.router.navigate(['/newsdetail/' + news.newsid]);
  }

  searchFunction(event) {
    this.searchdata = event;
    // this.searchother = event;
    this.preloader = true;
    delete this.newlistempty.keys;
    this.newsList(this.newlistempty, this.searchdata, this.offSet, this.pageSize);
  }

  tagesclick(tag) {
    if (!ValidationService.isNullOrEmpty(tag)) {
      const tagid = parseInt(tag.newskeyid, 10);
      this.tagsonly.push(tagid);
      this.newlistempty.keys = this.tagsonly;
    }
    this.newsList(this.newlistempty, this.searchdata, this.offSet, this.pageSize);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._newsservice.sendDatastring('');
    delete this.newlistempty.keys;
    this._newsservice.sendData(this.newlistempty.keys);
    // this.subscription.unsubscribe();
    this.searchdata = '';
  }

}
