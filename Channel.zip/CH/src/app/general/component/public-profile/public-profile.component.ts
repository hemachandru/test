import { Component, OnInit } from '@angular/core';
import { SharedBusiness } from '@app/shared/shared-business/shared-business';
import { ChannelCompanyDetailTitle, ChannelTypeIdEnum, CurrencyType } from '@app/config/constant';
import { ISlimScrollOptions } from 'ng2-slimscroll';
import { Router, ActivatedRoute } from '@angular/router';
import { ChannelBusiness } from '@app/channel/business/channel.business';
import { RootObjectChannelView, MatchingProfile, VendorProduct } from '@app/channel/models/channelView_models';
import { MatDialog } from '@angular/material';
import { DismissReasons, UpdateChannelData, OfficialDocument, ChannelClaim } from '@app/channel/models/channel_models';
import { PopUpTitle, PopUpSuccessMsg, SocialLinkConfig } from '@app/config/constant';
import { ConfirmDialogComponent } from '@app/shared/shared-component/confirm-dialog/confirm-dialog.component';
import { Response } from '@angular/http';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { AppLocalStorageKeys } from '@app/config/constant_keys';
import { BrandResult, ChannelKeyRetailerGet } from '@app/shared/models/shared-model';
import { TranslateService } from '@ngx-translate/core';
import { AwardsPopupComponent } from '@app/channel/component/awards-popup/awards-popup.component';

@Component({
  selector: 'app-public-profile',
  templateUrl: './public-profile.component.html',
  styleUrls: ['./public-profile.component.scss']
})
export class PublicProfileComponent implements OnInit {
  public titlemsg: string;
  public title: string;
  public contactList;
  public brandResult: BrandResult;
  public matchingDistributorList;
  interestDataShow = 3;
  existingDataShow = 3;
  customerDataShow = 3;
  serviceDataShow = 3;
  sellingDataShow = 5;
  locationDataShow = 5;
  locationretailerDataShow = 5;
  routeSubscription;
  channelCompanySubscription;
  profileId: number;
  channelCompany: any;
  channelCompanyDetailTitle;
  rating: number;
  public opts: ISlimScrollOptions;
  public loading: boolean;
  public channelId;
  public channelDetailsInfo: RootObjectChannelView = null;
  public productGroup;
  public productCategory;
  public locations;
  public channelTypeId;
  public matchdataParams: MatchingProfile;
  public channelJCTID;
  public _DismissReasons: Array<DismissReasons>;
  public _UpdateChannelData: UpdateChannelData;
  public relation_status;
  public preloader = false;
  public productListresult;
  public productListParams: VendorProduct;
  public channelType;
  public pendingApproval: string;
  public officialDistributorList;
  public noOfYear;
  public unauthorized: string;
  public _SocialLinkConfig;
  public _OfficialDocument: OfficialDocument;
  public _ChannelClaim: ChannelClaim;
  public hideaction: boolean;
  public isPublicBool: boolean;
  public scrollbarOptionsPublicview = { axis: 'y', theme: 'dark' };
  public channelKeyRetailers: ChannelKeyRetailerGet[];
  public channelKeyDistributors: ChannelKeyRetailerGet[];
  public isDownloadOfficialDocsClicked: boolean;
  public isOfficialDocsLoading: boolean;
  public _CurrencyType = CurrencyType;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private sharedBusiness: SharedBusiness,
    private _channelBusiness: ChannelBusiness,
    private toastr: ToastrService,
    public dialog: MatDialog,
    private translate: TranslateService
  ) {
    this.productListParams = <VendorProduct>{
      'isActive': true
    };

    this.title = 'dashboard.buttonLabels.publicView';
    this.titlemsg = '';
    this.hideaction = true;
  }

  ngOnInit() {
    this.unauthorized = '';
    this._UpdateChannelData = new UpdateChannelData();
    this.channelCompanyDetailTitle = ChannelCompanyDetailTitle;
    this.channelId = localStorage.getItem(AppLocalStorageKeys.CHANNEL_ID);
    this.getChannelCompanyDetails();
    this.opts = {
      barBackground: '#08314e',
      barBorderRadius: '0',
      barWidth: '4',
      gridWidth: '4',
      gridMargin: '1px 0'
    };
    this._SocialLinkConfig = SocialLinkConfig;
    this.isPublicBool = true;
  }
  // Get channel detail list with channel Id
  getChannelCompanyDetails() {
    this.preloader = true;
    this.unauthorized = ' ';
    this._channelBusiness.dashboardchannelBusiness().subscribe(result => {
      const response = result as Response;
      if (response.ok) {
        this.getContactList(this.channelId);
        this.getOfficialDistributorList(this.channelId);
        this.getProductList(this.productListParams);

        this.channelDetailsInfo = result.json() as RootObjectChannelView;
        // this.loadOfficialDocuments();
        this.channelKeyRetailers = this.channelDetailsInfo.channelKeyRetailer;
        this.channelKeyDistributors = this.channelDetailsInfo.channelKeyDistributor;

        this.relation_status = this.channelDetailsInfo.connectionStatusTypeId;
        this.pendingApproval = this.channelDetailsInfo.pendingApprovalInOutBound;
        this.channelJCTID = parseInt(this.channelDetailsInfo.channelJCT, 10);
        this.rating = this.channelDetailsInfo.rating;
        this.rating = 0; // Temporary count, Need to be removed after dynamic
        this.channelDetailsInfo.reviewCount = 0;  // Temporary count, Need to be removed after dynamic
        this.channelTypeId = this.channelDetailsInfo.channelTypeId;
        this.channelType = this.channelDetailsInfo.channelType;
        const channelTypeId = parseInt(this.channelTypeId, 10);
        if (channelTypeId !== ChannelTypeIdEnum.RETAILER) {
          this.getBrandList(this.channelId);
        }

        this.productGroup = this.channelDetailsInfo.tradeInformationIds.productGroup;
        this.productCategory = this.channelDetailsInfo.tradeInformationIds.productCategory;
        this.locations = this.channelDetailsInfo.tradeInformationIds.locations;
        this.matchdataParams = <MatchingProfile>{
          'channelId': this.channelId,
          'channelTypeId': channelTypeId,
          'productGroup': this.productGroup,
          'productCategory': this.productCategory,
          'locations': this.locations
        };
        this.productListParams = <VendorProduct>{
          'isActive': true,
          'channelId': this.channelId,
        };
        // Get no of years for vendor
        if (channelTypeId === ChannelTypeIdEnum.VENDOR) {
          const currentYear = moment(new Date(), 'DD/MM/YYY').year();
          const estYear = parseInt(this.channelDetailsInfo.estYear, 10);
          this.noOfYear = currentYear - estYear;
        }
      } else if (response.json()[0]['errors'][0]['code'] === 3028) {
        this.unauthorized = this.translate.instant('CommonUsageLabel.unauthorizedRequest');
      }
      this.preloader = false;

    }, (error) => {
      this.preloader = false;
      console.log(error);
    });
  }

  // Get Contact List
  getContactList(channelId) {
    this.preloader = true;
    this.sharedBusiness.getChannelContactListById(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.contactList = response.json();
      }
    }, (error) => {
      console.log(error);
    });
    this.preloader = false;
  }

  // Get Brand List
  getBrandList(channelId) {
    this.preloader = true;
    this.sharedBusiness.getChannelBrandList(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.brandResult = response.json();
      }
    }, (error) => {
      console.log(error);
    });
    this.preloader = false;
  }

  // Get Official Distributor List
  getOfficialDistributorList(channelId) {
    this.sharedBusiness.getOfficialDistributorList(channelId, true).subscribe(response => {
      const result = response as Response;
      if (result.ok) {
        this.officialDistributorList = response.json();
      }
    }, (error) => {
      console.log(error);
    });
  }

  // Product carosel List
  getProductList(productlistData: VendorProduct) {
    this.sharedBusiness.GetVendorProductList(productlistData).subscribe(res => {
      const response = res as Response;
      if (response.ok) {
        const result = response.json();
        this.productListresult = result;
      }
    });
  }

  locationDataFuction(currentdata, totalLenght) {
    this.locationDataShow = currentdata === 5 ? totalLenght : 5;
  }

  // officialDocuments() {
  //   this._channelBusiness.getOfficialDocuments(true, this.channelId).subscribe(response => {
  //     const officialData = response as Response;
  //     this._OfficialDocument = officialData.json();
  //   });
  // }

  // channelClaim() {
  //   this._channelBusiness.getChannelClaim(true, this.channelId).subscribe(response => {
  //     const claimData = response as Response;
  //     this._ChannelClaim = claimData.json();
  //     if (this._ChannelClaim.claim) {
  //       this.officialDocuments();
  //     } else {
  //       this._OfficialDocument.folderPath = '';
  //     }
  //   });
  // }

  downloadOfficialDocs() {
    this.isDownloadOfficialDocsClicked = false;
    if (this.channelDetailsInfo.channelDocument) {
      if (this._OfficialDocument && this._OfficialDocument.folderPath) {
        this.loading = false;
        window.location.href = this._OfficialDocument.folderPath;
      } else {
        this.loading = true;
        this.isDownloadOfficialDocsClicked = true;
        if (!this.isOfficialDocsLoading) {
          this.loadOfficialDocuments();
        }
      }
    }
  }

  loadOfficialDocuments() {
    this.channelDetailsInfo.channelDocument = true;
    if (this.channelDetailsInfo.channelDocument) {
      this.isOfficialDocsLoading = true;
      this._channelBusiness.getOfficialDocuments(true, this.channelId).subscribe(response => {
        const officialData = response as Response;
        this.loading = false;
        this.isOfficialDocsLoading = false;
        if (officialData.ok) {
          this._OfficialDocument = officialData.json();
          if (this.isDownloadOfficialDocsClicked) {
            window.location.href = this._OfficialDocument.folderPath;
            this.isDownloadOfficialDocsClicked = false;
          }
        }
      });
    }
  }

  // Awards popup
  awardsPopup() {
    this.dialog.open(AwardsPopupComponent, {
      data: {
        awards: this.channelDetailsInfo.awards
      },
      width: '800px',
      panelClass: 'awardsPanel'
    });
  }
}
