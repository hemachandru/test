import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { NewsKey } from '../models/newslist';

@Injectable()
export class NewsService {

  filterResult: NewsKey;
  public filterSource = new BehaviorSubject<NewsKey>(this.filterResult);

  currentFilterDetail = this.filterSource.asObservable();

  //
  stringResult: string;
  public stringSource = new BehaviorSubject<string>(this.stringResult);
  currentstringDetail = this.stringSource.asObservable();

  constructor() {
  }

  sendData(filter: NewsKey) {
    this.filterSource.next(filter);
  }


  updateData(isClosed: boolean) {
    this.filterSource.closed = isClosed;
  }

  sendDatastring(filter: string) {
    this.stringSource.next(filter);
  }

  updateDatastring(isClosed: boolean) {
    this.stringSource.closed = isClosed;
  }
}
