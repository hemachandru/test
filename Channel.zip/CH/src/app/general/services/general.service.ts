
import { Injectable } from '@angular/core';

import { HttpRequestService } from '@app/shared/shared-HTTP-service/HttpRequestService';
import { HttpParams } from '@angular/common/http';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { IRequestOptions } from '../../communication/services/Interface/IRequestOptions';
@Injectable()
export class GeneralService {
  private apiUrl = ApiUrl;
  private _option = <IRequestOptions>{};

  constructor(private _httpReqService: HttpRequestService) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  faqHeader() {
    const url: any = this.apiUrl.FAQ_HEADER;
    return this._httpReqService.getHttpRequestWithoutToken(url, true);
  }

  faqList(datas, searchkey, pagination) {
    let params = new HttpParams();
    if (searchkey !== '' && searchkey !== undefined) {
      params = params.set('search', searchkey);
    }
    params = params.set('page', pagination.pagination.offset);
    params = params.set('limit', pagination.pagination.page);

    const url: any = this.apiUrl.FAQ_LIST + '?' + params;
    return this._httpReqService.postHttpRequestWithoutToken(datas, url, true)
      .map(res => {
        return res;
      });
  }

  getComplainListByCategoryType(complainType: string) {
    const url = this.apiUrl.COMPLAINT_CATEGORY_LIST + '/' + complainType;
    return this._httpReqService.getHttpRequestWithoutToken(url, true);
  }

  postComplain(data: any) {
    const url = this.apiUrl.COMPLAINT;
    if (localStorage.getItem(AppLocalStorageKeys.AUTH_Token)) {
      return this._httpReqService.postHttpRequest(data, url, true);
    } else {
      return this._httpReqService.postHttpRequestWithoutToken(data, url, true);
    }
  }

  newsList(datas, searchkey, pagination) {
    let params = new HttpParams();
    if (searchkey !== '' && searchkey !== undefined) {
      params = params.set('search', searchkey);
    }
    params = params.set('page', pagination.pagination.offset);
    params = params.set('limit', pagination.pagination.page);

    const url: any = this.apiUrl.NEWS_LIST + '?' + params;
    return this._httpReqService.postHttpRequestWithoutToken(datas, url, true)
      .map(res => {
        return res;
      });
  }

  newsDetail(newsId) {
    const url: any = this.apiUrl.NEWS_ITEM + '/' + newsId;
    return this._httpReqService.getHttpRequestWithoutToken(url, true)
      .map(res => {
        return res;
      });
  }
}
