export interface NewsKey {
  newskeyid: string;
  newskey: string;
}

export interface Newscategory {
  newscategoryid: string;
  newscategoryname: string;
}

export interface Newstype {
  newstypeid: string;
  newstype: string;
}

export interface Thumbnailimage {
  documentUrl: string;
  documentId: string;
  documentTypeId: number;
  documentPath: string;
  deletedAt?: any;
}

export class NewsItem {
  newsid: string;
  title: string;
  content: string;
  thumbnailimageid: string;
  newscategoryid: string;
  newstypeid: string;
  source?: string;
  sourceurl?: string;
  isactive: string;
  updatedat: Date;
  newsKey: NewsKey[];
  newscategory: Newscategory;
  newstype: Newstype;
  thumbnailimage: Thumbnailimage;
  createdat?: Date;
  shortcontent?: string;
}

export class Pagination {
  limit: number;
  page: number;
  total: number;
  offset: number;
}

export interface Result {
  newsid: string;
  title: string;
  content: string;
  isactive: string;
  newscategoryname: string;
  newstype: string;
  documentPath: string;
  documentUrl: string;
  updatedat: Date;
}

export class NewsList {
  pagination: Pagination;
  results: Result[];
}

export class FilterNewsList {
  newscategoryid: any[];
  newstypeid: any[];
  keys: Tags[];
  excludenewsid: number;
}

export class Tags {

}
