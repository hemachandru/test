export interface ComplaintCategory {
    id: string;
    name: string;
    isactive: string;
    complainttype: string;
}

export interface CompalainDocument {
    documentPath: string;
    documenttype: string;
}

export class Complaint {
    complainttype: string;
    channelid?: number;
    userid?: number;
    channeltype: string;
    firstname: string;
    lastname: string;
    email: string;
    phoneno: string;
    mobileno: string;
    countryid: number;
    subject: string;
    detaildesc: string;
    iprurl?: string;
    complaintcategoryid: number;
    status: string;
    compalainDocument?: CompalainDocument[];
}
