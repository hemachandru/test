export class BannerData {
    customClass: string;
    title: string;
}

export class CMSPage {
    title: string;
    slug: string;
    metatitle: string;
    metadescription: string;
    metakeywords: string;
    pagecontent: string;
    updatedat: Date;
}
