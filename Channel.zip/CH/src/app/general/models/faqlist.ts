export class Pagination {
  limit: number;
  page: number;
  total: number;
  offset: number;
}

export interface FaqCategory {
  faqcategoryid: string;
  faqcategoryname: string;
}

export interface Faqsubcategory {
  faqsubcategoryid: string;
  faqsubcategoryname: string;
  faqcategoryid: string;
  faqCategory: FaqCategory;
}

export interface Result {
  faqid: string;
  question: string;
  answer: string;
  faqsubcategoryid: string;
  isactive: string;
  updatedat: Date;
  faqsubcategory: Faqsubcategory;
}

export class FaqList {
  pagination: Pagination;
  results: Result[];
}

export class FaqSubDetails {
  faqcategoryid?: number;
  faqsubcategoryid?: number;
}
