import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HelpComponent } from './component/help/help.component';
import { UserAccountStatus } from '@app/config/constant';
import { FaqComponent } from './component/faq/faq.component';
import { NewsComponent } from './component/news/news.component';
import { NewsDetailComponent } from './component/news-detail/news-detail.component';
import { AboutUsComponent } from './component/about-us/about-us.component';
import { OurTeamComponent } from './component/our-team/our-team.component';
import { PrivacyComponent } from './component/privacy/privacy.component';
import { AuthGuard, AnonymousGuard } from '@app/shared/shared-service/auth-guard.service';
import { ClaimInfoComponent } from '@app/general/component/claim-info/claim-info.component';
import { SalesRepInfoComponent } from '@app/general/component/sales-rep-info/sales-rep-info.component';
import { VendorComponent } from '@app/general/component/vendor/vendor.component';
import { RetailerComponent } from '@app/general/component/retailer/retailer.component';
import { SalesRepComponent } from '@app/general/component/sales-rep/sales-rep.component';
import { DistributorComponent } from '@app/general/component/distributor/distributor.component';
import { PublicProfileComponent } from './component/public-profile/public-profile.component';
import { TermsConditionsComponent } from './component/terms-conditions/terms-conditions.component';
import { LegalInformationComponent } from './component/legal-information/legal-information.component';
import { ComingSoonPageComponent } from '@app/general/component/coming-soon-page/coming-soon-page.component';

const routes: Routes = [
    {
        path: 'help', component: HelpComponent
    },
    {
        path: 'help/:key', component: HelpComponent
    },
    {
        path: 'faq', component: FaqComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'newslist', component: NewsComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'newsdetail/:id', component: NewsDetailComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'aboutus', component: AboutUsComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'ourteam', component: OurTeamComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'privacy', component: PrivacyComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'claiminfo', component: ClaimInfoComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'salesrepinfo', component: SalesRepInfoComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'vendor', component: VendorComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'retailer', component: RetailerComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'distributor', component: DistributorComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'business-developer', component: SalesRepComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'public-profile', component: PublicProfileComponent, canActivate: [AuthGuard], data: {
            currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
        }
    },
    {
        path: 'termsconditions', component: TermsConditionsComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'legal-information', component: LegalInformationComponent, canActivate: [AnonymousGuard]
    },
    {
        path: 'coming-soon', component: ComingSoonPageComponent, canActivate: [AuthGuard]
    }

];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class GeneralRoutingModule { }
