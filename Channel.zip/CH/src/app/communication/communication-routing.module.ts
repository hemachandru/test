import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';

import { AuthGuard } from '../shared/shared-service/auth-guard.service';
import { UserAccountStatus } from '@app/config/constant';
import { ErrorPageComponent } from '@app/core/components/errorpage/errorpage.component';
import { NotificationComponent } from './component/notification/notification.component';

const routes: Routes = [
  {
    path: 'notification',
    component: NotificationComponent,
    canActivate: [AuthGuard],
    data: {
      notificationPage: true,
      currentStatus: [UserAccountStatus.CHANNEL_APPROVED]
    }
  },
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
  declarations: []
})
export class CommunicationRoutingModule { }
