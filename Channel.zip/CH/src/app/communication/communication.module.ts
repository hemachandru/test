import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationComponent } from './component/notification/notification.component';
import { CommunicationRoutingModule } from '@app/communication/communication-routing.module';
import { SharedModule } from './../shared/shared.module';
import { NotificationService } from './services/notification.service';
import { SlimScrollModule } from 'ng2-slimscroll';
import { CoreModule } from '../core/core.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    CommunicationRoutingModule,
    SlimScrollModule,
    CoreModule
  ],
  providers: [NotificationService],
  declarations: [NotificationComponent]
})
export class CommunicationModule { }
