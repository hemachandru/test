import { Component, OnInit } from '@angular/core';
import { NotificationService } from '@app/communication/services/notification.service';
import { Subject } from 'rxjs/Subject';
import { CodeDataTransferService } from '../../../core/service/code-data-transfer.service';
import { Router } from '@angular/router';
import { AppLocalStorageKeys, WebUrl } from '@app/config/constant_keys';
import { NotificationFormatContact, SenderReceiverObject, ChannelTypeIdEnum } from '@app/config/constant';
import { ToastrService } from 'ngx-toastr';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})

export class NotificationComponent implements OnInit {
  public messageFlag: boolean;
  public webUrl = WebUrl;
  public title = 'notification.title';
  public notification_list = [];
  public markRead = new Subject();
  public preLoader = false;
  public titlemsg: string;
  public noresult: boolean;
  public scrollbarOptionsCnl = { axis: 'y', theme: 'minimal-dark' };
  public result: any;
  page: number;
  totalPages: number;
  constructor(
    private router: Router,
    private _notificationService: NotificationService,
    private codeDataTransferService: CodeDataTransferService,
    private toastr: ToastrService,
    private translate: TranslateService
  ) {
    this.messageFlag = true;
    this.page = 1;
  }

  ngOnInit() {
    this.noresult = false;
    this.titlemsg = 'notification.subtitle';
    // this.getNotificationlist(this.page);
    this.markRead.subscribe((value: any) => {
      const _userSubscriptionId = parseInt(localStorage.getItem(AppLocalStorageKeys.SUBSCRIPTION_CONTACTID), 10);
      if (value.isread === '1') {
        if (this.messageFlag) {
          this.messageRedirect(value, _userSubscriptionId);
        } else {
          this.channelRedirect(value, _userSubscriptionId);
        }
        return;
      } else {
        this.preLoader = true;
        this._notificationService.setNotificationRead(value.notificationid).subscribe(res => {
          this.preLoader = false;
          if (res.ok) {
            value.isread = '1';
            this.codeDataTransferService.changeNotificationRead(value);
            if (this.messageFlag) {
              this.messageRedirect(value, _userSubscriptionId);
            } else {
              this.channelRedirect(value, _userSubscriptionId);
            }
          } else {
            this.preLoader = false;
            console.error('Error =====>', res);
          }
        });
      }
    });

    // get the notification list referesh  after he notificaton recived.
    this.codeDataTransferService.currentNewNotification.subscribe(message => {
      this.getNotificationlist(this.page);
    });

  }

  getNotificationlist(page) {
    this.page = page;
    this.preLoader = true;
    this._notificationService.getNotification(page).subscribe(results => {
      const response = results as Response;
      this.preLoader = false;
      if (response.ok) {
        this.preLoader = false;
        this.result = results.body;
        // tslint:disable-next-line:triple-equals
        if (page != 1) {
          [].push.apply(this.notification_list, this.result.results);
        } else {
          this.notification_list = this.result.results;
        }
        this.totalPages = Math.ceil(this.result.pagination.total / 10);
        if (this.notification_list.length <= 0) {
          this.noresult = true;
        }
      }
    }, (error) => {
      this.noresult = true;
      this.preLoader = false;
      console.log(error);
    });
  }

  messageRedirect(value, _userSubscriptionId) {
    const data1 = localStorage.getItem(AppLocalStorageKeys.CHANNEL_TYPE_ID);
    // tslint:disable-next-line:radix
    const channelTypeId = parseInt(data1, 10);

    if (value.entity === 'PRODUCT') {
      if (value.formatcontact.formatkey === NotificationFormatContact.SUGGESTION_PRODUCT) {
        this.router.navigate([this.webUrl.PRODUCT_SUGGESTION]);
      } else if (channelTypeId === ChannelTypeIdEnum.VENDOR && value.entityid != null && value.entityreference != null) {
        this.router.navigate([this.webUrl.MY_PRODUCT_VIEW, value.entityreference]);
      } else if (value.entityid != null && value.entityreference != null) {
        this.router.navigate([this.webUrl.PRODUCT_SUGGESTION_VIEW, value.entityreference]);
      }
    } else if (value.entity === 'ORDER') {
      // if (value.tocontact.channel.channelType.channelType === 'RETAILER') {
      //   this.router.navigate([this.webUrl.ORDER_BUYER_REQUEST]);
      // } else if (value.tocontact.channel.channelType.channelType === 'VENDOR') {
      //   this.router.navigate([this.webUrl.ORDER_SELLER_REQUEST]);
      // } else if (value.formatcontact.contacttype === SenderReceiverObject.SENDER) {
      //   this.router.navigate([this.webUrl.ORDER_BUYER_REQUEST]);
      // } else {
      //   this.router.navigate([this.webUrl.ORDER_SELLER_REQUEST]);
      // }

      if (value.action) {
        if (value.action === 'buyer') {
          this.router.navigate([this.webUrl.ORDER_BUYER_REQUEST]);
        } else if (value.action === 'seller') {
          this.router.navigate([this.webUrl.ORDER_SELLER_REQUEST]);
        }
      }

    } else if (value.entity === 'CHANNEL' && value.entityid == null && value.formatcontact.formatkey === NotificationFormatContact.CHANNEL_RECOMMENDED) {
      this.toastr.error(this.translate.instant('notification.notAvailalbeInCHYet'));
    } else if (value.entity === 'CHANNEL' && value.entityid != null) {
      this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, value.entityid]);
    } else if (value.formatcontact.formatkey === NotificationFormatContact.SUGGESTION_CHANNEL) {
      this.router.navigate([this.webUrl.CHANNEL_SUGGESTION]);
    } else if ((parseInt(value.formatcontactid, 10) !== 5)
      && value.originatedcontact && (parseInt(value.originatedcontact.contactId, 10) !== _userSubscriptionId)) {
      this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, parseInt(value.originatedcontact.channel.channelId, 10)]);
    }
  }

  channelRedirect(value, _userSubscriptionId) {
    if (parseInt(value.formatcontactid, 10) !== 5 &&
      value.originatedcontact && (parseInt(value.originatedcontact.contactId, 10) !== _userSubscriptionId)) {
      this.router.navigate([this.webUrl.CHANNEL_VIEW_PAGE, parseInt(value.originatedcontact.channel.channelId, 10)]);
    }
  }
}
