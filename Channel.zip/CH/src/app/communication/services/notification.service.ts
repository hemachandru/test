import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpRequestService } from '../../shared/shared-HTTP-service';
import { IRequestOptions } from './Interface/IRequestOptions';
import { Observable } from 'rxjs/Observable';
import { ApiUrl, AppLocalStorageKeys } from '@app/config/constant_keys';
import { HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';

@Injectable()
export class NotificationService {

  private apiUrl = ApiUrl;
  private _option = <IRequestOptions>{};

  constructor(private _httpService: HttpRequestService) {
    this._option.observe = 'response';
    this._option.responseType = 'json';
  }

  getNotification(page): Observable<any> {
    const url = this.apiUrl.NOTIFICATION;
    this._option.params = new HttpParams().set('page', page);
    return this._httpService.getHttpClientRequest(url, this._option);
  }

  setNotificationRead(notificatinId: string): Observable<any> {
    const url = this.apiUrl.NOTIFICATION_READ;
    this._option.params = new HttpParams().set('id', notificatinId);
    const data = {};
    return this._httpService.postHttpClientRequest(url, data, this._option);
  }

}
