import { HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { FailedStartWorkspaceRequests } from 'aws-sdk/clients/workspaces';


export type IObserveOptions = 'body' | 'events' | 'response';

export type IResponseTypeOptions = 'arraybuffer' | 'blob' | 'json' | 'text';

export interface IRequestOptions {
    headers?: HttpHeaders | { [header: string]: string | Array<string> };
    observe?: IObserveOptions;
    params?: HttpParams | { [param: string]: string | Array<string> };
    reportProgress?: boolean;
    responseType?: IResponseTypeOptions;
    withCredentials?: boolean;
}
