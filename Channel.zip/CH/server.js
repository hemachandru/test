const http = require('http');
const fs = require('fs');
const path = require('path');
var cors = require('cors');
const express = require('express');
const app = express();
require('dotenv').config();
//const port = process.env.PORT;
const port = process.env.NODEPORT || 80;
//app.use(express.static(path.join(__dirname + 'lib'))); 
//app.use("/",  express.static(__dirname + '/dist'));
app.use(cors())
app.use('/', express.static(__dirname + '/dist', { redirect: false }));

app.get('*', function (req, res) {
  res.sendFile(path.resolve(__dirname + '/dist/index.html'));
})


http
  .createServer(app)
  .listen(port, (error) => {
    if (error) {
      console.error(error)
      return process.exit(1)
    } else {
      console.log('Listening on port: ' + port + '.')
    }
  })