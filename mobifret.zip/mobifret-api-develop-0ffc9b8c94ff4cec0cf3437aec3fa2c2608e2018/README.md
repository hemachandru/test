# Mofifret API 
 

# Software Requirment 

> * Node js - v6.2.0
> * Type Script - Version 2.3.3
> * PM2 server  - v1.1.3

# Build Process 
> * npm install
> * npm build

# Deployment Process
> * pm2 restart appdev.json
