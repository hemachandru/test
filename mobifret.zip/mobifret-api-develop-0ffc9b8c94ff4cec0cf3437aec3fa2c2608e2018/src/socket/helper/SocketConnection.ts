import * as SocketIo from "socket.io";
import { Sender } from "./Sender";
import { Receiver } from "./Receiver";
import { AccountBuisness, JwtLib } from "../../modules/index";
import { Transformation } from "../../modules/Account/transformation/index";

export class SocketConnection {

    private io: SocketIo;
    private sender: Sender;
    private receiver: Receiver;
    private namespace: string = "main";
    private callBack: any;
    private accountBuisness = new AccountBuisness();
    private jwtLib = new JwtLib();
    private authOption = {
        secret: process.env.SECRETKEY
    };

    constructor(io: SocketIo, namespace: string, callBack: any) {
        let self = this;
        self.io = io;
        self.namespace = namespace;
        self.io.use(self.jwtLib.authenticate(self.authOption, self.authCalback(self)));
        new callBack(this.io, this.namespace);
    }

    authCalback(self) {
        return async (payload, done) => {
            if (payload && payload.userID) {
                let result = await self.accountBuisness.GetCurrentUser(payload.userID);
                if (result) {
                    result = new Transformation().CurrentUser(result);
                    return done(null, result);
                }
                return done(null, 'user does not exist');
            } else {
                return done(null, 'unauthorize');
            }
        };
    }
}
