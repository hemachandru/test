import * as SocketIo from "socket.io";
import { Socket } from "../helper";
import { RedisLib } from "../../helper";
import { Exception } from "../../modules/Order/exception";
import { DriverMissionBusiness } from "../../modules/DriverMission/business/DriverMissionBusiness";
import { DriverMissionService } from "../../modules/DriverMission/service/DriverMissionService";
import { OrderService } from "../../modules/Order/service/OrderService";
import { SnsLib } from "../../helper/SnsLib";
import { AccountBuisness } from "../../modules/index";
import { SMSRequestLib } from "../../helper/OvhSmsLib";

const options = {
    withCoordinates: true,
    withHashes: true,
    withDistances: true,
    order: 'ASC',
    units: 'km',
    accurate: true
}

export class CompanyOrder {

    private sender: Socket.Sender;
    private receiver: Socket.Receiver;
    private io: SocketIo;
    private namespace: string;
    private orderQueue: any;
    private static driverMissionBusiness: DriverMissionBusiness = new DriverMissionBusiness();
    private driverMissionService: DriverMissionService = new DriverMissionService();
    private accountBuisness = new AccountBuisness();
    private orderService = new OrderService();
    private static redisClient: any = RedisLib.getInstance();
    private static connection: any;
    private static orderConfig: any;
    private static geoRedisDriverClient: any = RedisLib.getGeoInstanceDriver();
    private static geoRedisOrderClient: any = RedisLib.getGeoInstanceOrder();
    private static sns = new SnsLib();
    private static sms = new SMSRequestLib();

    private static schedular: any = RedisLib.getSchedular();

    constructor(io: SocketIo, namespace: string) {
        this.io = io;
        this.namespace = namespace;
        this.init();
    }
    
    monitorRedis(time, args) {
        console.log(args);
    }

    init() {
        let self = this;
        CompanyOrder.connection = self.io.of(self.namespace);
        CompanyOrder.connection.on("connection", self.connections(this));
    }

    static placeOrderEmit(orderDetail: any) {
        let self = this;
        self.orderConfig = orderDetail.config

        //self.orderConfig.expire = 200;
        console.log(self.orderConfig.expir);

        if (orderDetail.planned && orderDetail.planned.length > 0) {
            self.connection.to(process.env.ROOM_CLIENT).emit("join", orderDetail.planned);
            let orderData = {
                orderId: orderDetail.orderId,
                type: process.env.GENERAL_PLANNED_ORDER
            }
            CompanyOrder.notifyUser(process.env.ROOM_ADMIN, orderData, "generalNotify");
        }

        if (orderDetail.immediate && orderDetail.immediate.length > 0) {
            orderDetail.immediate.forEach(self.getNearByDriver(self));
        }
    }

    static getNearByDriver(self) {
        return (immediateOrder) => {
            options["count"] = self.orderConfig.no_driver;
            self.geoRedisDriverClient.nearby(immediateOrder.location, self.orderConfig.km, options, self.nearByDriverCallBack(self, immediateOrder));
        };
    }

    static nearByDriverCallBack(self, immediateOrder) {
        return (err, places) => {
            if (err) {
                console.error("Nearby get Error:", err)
            } else {
                let drivers = [];
                let driversUsername = [];
                let driversId = [];
                if (places && places.length > 0) {
                    drivers = places;
                    drivers.forEach(element => {
                        driversUsername.push(element.key);
                        try {
                            //[0] driver email id.
                            //[1] driver id. 
                            //[2] registration id.
                            let usernameSplit = element.key.split(":");
                            driversId.push(usernameSplit[1]);
                        } catch (e) {
                            console.error(e);
                        }
                    });
                    let driverMissions = {
                        orderID: immediateOrder.orderId,
                        driverID: driversId
                    }
                    self.driverMissionBusiness.DriverMissionCreate(driverMissions);
                }
                // need to work in logic
                if (drivers.length != self.orderConfig.no_drivers) {
                    self.updateLocation(immediateOrder, immediateOrder.orderId, "Order", []);

                    // Save Order.
                    self.redisClient.set(immediateOrder.orderId, JSON.stringify(immediateOrder));
                    console.log(self.orderConfig.expire);
                    self.schedular.schedule({ key: immediateOrder.orderId.toString(), expire: (parseInt(self.orderConfig.expire) * 1000), handler: self.expireEvent(self) }, function (err) {
                        if (err)
                            console.error("SET EXPIRED ERROR", err);
                        else
                            console.error("SET EXPIRED SUCCESS", immediateOrder.orderId);
                    });
                }

                // Save Drivers list recived order.
                self.redisClient.set(immediateOrder.orderId + ":Drivers", JSON.stringify(driversUsername));
                self.redisClient.expire(immediateOrder.orderId + ":Drivers", self.orderConfig.expire);

                console.log('Nearby Drivers:', drivers);
                drivers.forEach(self.emitDriverNearBy(self, immediateOrder));
            }
        }
    }

    static expireEvent(self) {
        return (err, key) => {
            console.log("EXPIRED: ", key + ' triggered');
            //delete order location.
            CompanyOrder.geoRedisOrderClient.removeLocation(key, (err, orderLocation) => {
                CompanyOrder.notifyUser(process.env.ROOM_ADMIN, key, "OrderTimeOut");
                console.log("DELETE ORDER LOCATION", key, orderLocation)
            });
        }
    }

    static emitDriverNearBy(self, immediateOrder) {
        return (driver) => {
            // Save Driver recived order.
            self.redisClient.set(immediateOrder.orderId + ":" + driver.key, JSON.stringify(immediateOrder));
            self.redisClient.expire(immediateOrder.orderId + ":" + driver.key, self.orderConfig.expire);
            if (driver.key) {
                //[0] driver email id.
                //[1] driver id. 
                //[2] registration id.
                let driverEmailAndId = driver.key.split(":");
                CompanyOrder.notifyUser(driver.key, [immediateOrder], "order nearby");
            }
        }
    }

    getRoomKey(roleId) {
        if ([1].indexOf(roleId) != -1) {
            return process.env.ROOM_ADMIN;
        } else if ([2, 3].indexOf(roleId) != -1) {
            return process.env.ROOM_CLIENT;
        } else if ([4, 5].indexOf(roleId) != -1) {
            return process.env.ROOM_COMPANY;
        } else if ([6].indexOf(roleId) != -1) {
            return process.env.ROOM_DRIVER;
        }
    }

    connections(that) {
        return (socket) => {
            let err = socket.request.err;
            let user = socket.request.user;
            if (err || !user) {
                socket.emit("unauthorized", err);
                socket.disconnect('unauthorized');
                return;
            }

            let roomKey = that.getRoomKey(user.userRole.id);
            let username = user.contact.email;
            let driverUsername = "";
            if (user.userRole.id === 6 && user.driver && user.driver.isActive && user.driver.isJobOnStatus && user.driver.vehicleId) {
                driverUsername = username + ":" + user.driver.id + ":" + user.registration.id;
            }
            console.log("test" + driverUsername)
            socket.join(roomKey);
            socket.join(username);

            if (driverUsername)
                socket.join(driverUsername);

            console.log("connected!!!!!!", user.userRole.id, username, roomKey);

            socket.on("join", (data: any) => {
                socket.join(roomKey);
                socket.join(username);
            });

            socket.on("leave", (data: string) => {
                console.log("Leave Rooms!!!!!", username);
                socket.leave(username);
                socket.leave(roomKey);
            });

            // socket.on("disconnect", () => {
            //     console.log("Disconnect!!!!!", roomKey)
            //     socket.leave(roomKey);
            // });

            socket.on("disconnect", function () {
                console.log(username + 'User disconnected');
                socket.leave(roomKey);
                socket.leave(username);
                socket.leave(driverUsername);
                try {
                    socket.disconnect();
                } catch (e) {
                    console.log("Disconnect Error", e)
                }
            });

            socket.on("location", (data: string | object) => {
                if (driverUsername) {
                    let parseData = that.parseingData(data);
                    let result = that.validateLocation(parseData);
                    CompanyOrder.updateLocation(parseData, driverUsername, "Driver", result, socket);
                }
            });

            socket.on("nearby", that.nearByOrders(that, driverUsername, socket));

            socket.on("driverLocation", that.getCurrentLocation(that, username, socket));

            socket.on("orderAssign", that.driverOrderAssigned(that, username, socket));

            socket.on("generalNotify", that.generalNotify(that, username, socket));

            socket.on("smsNotification", that.adminSMSRequest(that, socket));

            socket.emit('success', {
                message: 'success logged in!',
                user: socket.request.user
            });
        }
    }

    adminSMSRequest(that) {
        return async (data: string | object) => {
            let parseData = that.parseingData(data);
            CompanyOrder.sms.SMSAdminRequest(parseData);
        }
    }



    generalNotify(that, username, socket) {
        return async (data: string | object) => {
            let parseData = that.parseingData(data);
            if (parseData) {
                if (parseData.type == "AccountCreated") {
                    CompanyOrder.notifyUser(process.env.ROOM_ADMIN, parseData, "generalNotify");
                } else if (parseData.driverId && parseData.type == "Blocked") {
                    let driverInfo = await that.driverMissionService.GetDriverInfo(parseData.driverId)
                    CompanyOrder.notifyUser(driverInfo.user.userName, parseData, "generalNotify");
                    CompanyOrder.sns.sendPush(null, driverInfo.user.userId, process.env.PUSH_TYPE_BLOCKED, null, parseData.driverId);
                } else if (parseData.registrationId && parseData.type == "Blocked") {
                    let getPatnerUsername = await that.accountBuisness.GetRegisterIdDetail(parseData.registrationId);
                    CompanyOrder.notifyUser(getPatnerUsername.userName, parseData, "generalNotify");
                    let getCompanyDriverIDS = await that.driverMissionService.GetCompanyDriverIDs(parseData.registrationId);
                    getCompanyDriverIDS.map((driverUsername) => {
                        CompanyOrder.notifyUser(driverUsername.user.userName, parseData, "generalNotify");
                        CompanyOrder.sns.sendPush(null, driverUsername.user.userId, process.env.PUSH_TYPE_BLOCKED, null, getCompanyDriverIDS.driverId);
                    });
                } else if (parseData.userId) {
                    let customerInfo = await that.accountBuisness.GetCurrentUser(parseData.userId);
                    CompanyOrder.notifyUser(customerInfo.userName, parseData, "generalNotify");
                    CompanyOrder.sns.sendPush(null, customerInfo.userId, process.env.PUSH_TYPE_BLOCKED, null, parseData.userId);
                } else if (parseData.driverId && parseData.type == "ChangeVehicle") {
                    let driverInfo = await that.driverMissionService.GetDriverInfo(parseData.driverId)
                    CompanyOrder.notifyUser(driverInfo.user.userName, parseData, "VehicleAssigned");
                } else if (parseData.driverId && parseData.type == "vehicleRemoved") {
                    let driverInfo = await that.driverMissionService.GetDriverInfo(parseData.driverId)
                    if (driverInfo) {
                        CompanyOrder.notifyUser(driverInfo.user.userName, parseData, "DriverVehicleRemoved");
                        await that.driverMissionService.DriverVehicleOffJob(parseData.driverId)
                        CompanyOrder.sns.sendPush(null, driverInfo.user.userId, process.env.PUSH_TYPE_NOTIFY, null, parseData);
                    }
                } 
                // else if (parseData.type == "testing") {
                //     let pushPayload = {
                //         orderId: 1,
                //         driverId: 2,
                //         driverName: "sam",
                //         type: "Accept",
                //         isDriver: 1
                //     }
                //     CompanyOrder.sns.sendPush(null, 5, process.env.PUSH_TYPE_BLOCKED, null, pushPayload);

                // }
            }
            else {
                console.log("General type not found")
            }
        }
    }



    driverOrderAssigned(that, clientUsername, socket) {
        return async (data: string | object) => {
            if (clientUsername) {
                let parseData = that.parseingData(data);
                let checkOrderDriverID = await that.driverMissionService.CheckOrderDriverID(parseData.orderId, parseData.driverId)
                if (checkOrderDriverID) {
                    let data = {
                        orderData: {
                            orderId: parseData.orderId,
                            companyName: parseData.companyName,
                            type: parseData.type
                        },
                        pushPayload: {
                            orderId: parseData.orderId,
                            companyName: parseData.companyName,
                            type: process.env.PUSH_TYPE_ASSIGN,
                            isDriver: 1
                        }
                    }
                    CompanyOrder.notifyUser(parseData.driverUsername, data.orderData, process.env.GENERAL_ASSIGNED_ORDER);
                    let driverInfo = await that.driverMissionService.GetDriverInfo(parseData.driverId)
                    CompanyOrder.sns.sendPush(null, driverInfo.user.userId, process.env.PUSH_TYPE_ASSIGN, null, data.pushPayload);
                }
                let orderDetails: any = await that.orderService.GetSingleOrderDetails(parseData.orderId);
                if (orderDetails) {
                    let data = {
                        userId: orderDetails.userId,
                        driverName: orderDetails.driver.contact.firstName,
                        socketPayload: {
                            room: {
                                clientUserName: orderDetails.user.userName,
                                //partnerUserName: orderDetails.driver.registration.companyContact.email,
                                adminUserName: process.env.ROOM_ADMIN
                            },
                            orderDetail: {
                                orderId: orderDetails.orderId,
                                driverId: orderDetails.driverId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_ASSIGN,
                                status_at: orderDetails.updatedAt,
                                isDriver: 0,
                                driver_mobileNumber: orderDetails.driver.contact.mobile ? orderDetails.driver.contact.mobile : null,
                                driver_code: orderDetails.driverValidationCode
                            }
                        },
                        pushPayload: {
                            orderId: orderDetails.orderId,
                            driverId: orderDetails.driverId,
                            driverName: orderDetails.driver.contact.firstName,
                            type: process.env.PUSH_TYPE_ASSIGN,
                            status_at: orderDetails.updatedAt,
                            isDriver: 0,
                            driver_mobileNumber: orderDetails.driver.contact.mobile ? orderDetails.driver.contact.mobile : null,
                            driver_code: orderDetails.driverValidationCode
                        }
                    }
                    CompanyOrder.sns.sendPush(null, data.userId, process.env.PUSH_TYPE_ASSIGN, null, data.pushPayload);
                    CompanyOrder.OrderSocket(data, process.env.GENERAL_ASSIGNED_ORDER);
                    CompanyOrder.deleteRdisData(parseData.orderId);
                    /*******/
                    // let driversOrder = await self.driverMissionBusiness.GetDriverMission(orderId, null);
                    // this.cancelOrder(driversOrder, orderId);
                    /*******/

                } else {
                    console.log("Order ID not found");
                }

            } 
        }
    }

    getCurrentLocation(that, clientUsername, socket) {
        return async (data: string | object) => {
            if (clientUsername && data) {
                let parseData = that.parseingData(data);
                let getDriverId: any = await that.driverMissionService.GetOrderDriverId(parseData.orderId);
                if (getDriverId) {
                    let orderDriverUsername = getDriverId.driver.contact.email + ":" + getDriverId.driver.driverId + ":" + getDriverId.driver.registrationId;
                    CompanyOrder["geoRedis" + "Driver" + "Client"].location(orderDriverUsername, (err, driverLocation) => {
                        if (err) {
                            console.log("Driver Current LOCATION", orderDriverUsername, driverLocation)
                        } else {
                            let orderDriverLocation = {
                                orderId: getDriverId.orderId,
                                location: driverLocation
                            }
                            CompanyOrder.notifyUser(clientUsername, orderDriverLocation, "driverLocation");
                        }

                    });
                } else {
                    console.log("Driver Current LOCATION not found");
                }
            }
        }
    }

    static updateLocation(parseData, username, type, result, socket?) {
        if (result.length === 0 && username) {
            CompanyOrder["geoRedis" + type + "Client"].addLocation(username, parseData.location, function (err, reply) {
                if (err) {
                    console.error(type + " Location Added ERROR:", err);
                    if (socket)
                        socket.emit(type.toLowerCase() + "_update_status", new Exception().ThrowException());
                } else {
                    console.log(type + " Location Added:", username, reply);
                    if (socket)
                        socket.emit(type.toLowerCase() + "_update_status", "success");
                }
            });
        } else {
            console.error('Invalide Data:', result);
            if (socket)
                socket.emit(type.toLowerCase() + "_update_status", result);
        }
    }

    /******cancel order by client remove it from redis ********/
    static cancelByClient(driversOrder, orderId) {
        if (driversOrder) {
            driversOrder.forEach(element => {
                //delete perticular driver.
                CompanyOrder.redisClient.del(orderId + ":" + element.driver.user.userName+ ":" +element.driver.driverId+ ":" +element.driver.registrationId, (err, deleteDriver) => {
                    console.log("DELETE DRIVER", orderId, deleteDriver)
                });
              //  CompanyOrder.notifyUser(element.driver.user.userName, orderId, "order canceled");
            });
        }
        CompanyOrder.deleteRdisData(orderId);
    }
    /*********/
    static acceptOrder(driversOrder, orderId, driverId) {
        if (driversOrder) {
            driversOrder.forEach(element => {
                //delete perticular driver.
                /*CompanyOrder.redisClient.del(orderId + ":" + element.driver.user.userName, (err, deleteDriver) => {
                    console.log("DELETE DRIVER", orderId, deleteDriver)
                });*/

                CompanyOrder.redisClient.del(orderId + ":" + element.driver.user.userName + ":" +element.driver.driverId+ ":" +element.driver.registrationId, (err, deleteDriver) => {
                    console.log("DELETE DRIVER", orderId, deleteDriver);
                });

                if (element.driver.driverId != driverId) {
                    CompanyOrder.notifyUser(element.driver.user.userName, orderId, "remove order");
                }
            });
        }
        CompanyOrder.deleteRdisData(orderId);
    }

    static cancelOrder(driversOrder, orderId) {
        if (driversOrder) {
            driversOrder.forEach(element => {
                //delete perticular driver.
                CompanyOrder.redisClient.del(orderId + ":" + element.driver.user.userName + ":" +element.driver.driverId+ ":" +element.driver.registrationId , (err, deleteDriver) => {
                    console.log("DELETE DRIVER", orderId, deleteDriver)
                });
                CompanyOrder.notifyUser(element.driver.user.userName, orderId, "order canceled");
            });
        }
        CompanyOrder.deleteRdisData(orderId);
    }

    static deleteRdisData(orderId) {
        //delete order location.
        CompanyOrder.geoRedisOrderClient.removeLocation(orderId, (err, orderLocation) => {
            console.log("DELETE ORDER LOCATION", orderId, orderLocation)
        });

        //delete order.
        CompanyOrder.redisClient.del(orderId, (err, deletedOrder) => {
            console.log("DELETE ORDER", orderId, deletedOrder)
        });

        //delete order drivers list.
        CompanyOrder.redisClient.del(orderId + ":Drivers", (err, deletedOrderDriver) => {
            console.log("DELETE ORDER AND DRIVERS", orderId, deletedOrderDriver)
        });
    }

    nearByOrders(that, username, socket) {
        try{
        return (data: string | object) => {
            if (username) {
                let parseData = that.parseingData(data);
                CompanyOrder.geoRedisOrderClient.nearby(parseData.location, parseData.km, options, async (err, order) => {
                    if (err) {
                        console.error("Nearby get Error:", err)
                    } else {
                        let orders = [];
                        let checkOrder = [];
                        console.log(order.locationSet);
                        for (let element of order) {
                            checkOrder.push(parseInt(element.key));
                            //get driver previous orders.   
                            let prevOderDetail = await CompanyOrder.redisClient.getAsync(element.key + ":" + username);
                            if (prevOderDetail != null) {
                                prevOderDetail = JSON.parse(prevOderDetail);
                                orders.push(prevOderDetail);
                            } else {
                                //get current nearby orders.
                                let orderDetail = await CompanyOrder.redisClient.getAsync(element.key);
                                if (orderDetail) {
                                    orderDetail = JSON.parse(orderDetail);
                                    let parseDriver = [];
                                    let orderDrivers = await CompanyOrder.redisClient.getAsync(orderDetail.orderId + ":Drivers");
                                    if (orderDrivers) {
                                        parseDriver = JSON.parse(orderDrivers);
                                        if (parseDriver.length < 5) {
                                            let filterDriver = parseDriver.filter(filterKey => {
                                                return filterKey === username;
                                            });

                                            if (filterDriver.length === 0) {
                                                that.updateNearByDriverData(parseDriver, username, orderDetail, parseData);
                                            }
                                        }
                                    } else {
                                        that.updateNearByDriverData(parseDriver, username, orderDetail, parseData);
                                    }
                                    orders.push(orderDetail);
                                }
                            }
                        }
                        /**added to recheck the nearby order notificaton */
                        let newOrders: any = await that.orderService.GetNewOrders();
                        for (let newElement of newOrders) {
                            let newOpenOrder = await CompanyOrder.redisClient.getAsync(newElement.orderId + ":" + username);
                           // console.log(checkOrder.indexOf(newElement.orderId));
                            if ((checkOrder.indexOf(newElement.orderId) == -1) && (newOpenOrder != null)) {
                                newOpenOrder = JSON.parse(newOpenOrder);
                                orders.push(newOpenOrder);
                            }
                        }
                        console.log('Nearby orders:', orders);
                        CompanyOrder.connection.to(username).emit("order nearby", orders);
                    }
                });
            }
        }
        } catch (e) {
            console.error(e);
        }
    }

    updateNearByDriverData(parseDriver, username, orderDetail, parseData) {
        parseDriver.push(username);
        //[0] driver email id.
        //[1] driver id. 
        //[2] registration id.
        let usernameSplit = username.split(":");
        let driverArr = [usernameSplit[1]];
        CompanyOrder.redisClient.set(orderDetail.orderId + ":Drivers", JSON.stringify(parseDriver));
        CompanyOrder.redisClient.set(orderDetail.orderId + ":" + username, JSON.stringify(orderDetail));
        console.log(orderDetail.orderId + ":" + username, parseData.expire);
        CompanyOrder.redisClient.expire(orderDetail.orderId + ":" + username, parseData.expire);
        try {
            let driverMissions = {
                orderID: orderDetail.orderId,
                driverID: driverArr
            }  //usernameSplit[1]
            console.log(driverMissions);
            CompanyOrder.driverMissionBusiness.DriverMissionCreate(driverMissions);
        } catch (e) {
            console.error(e);
        }
    }

    parseingData(data: string | object) {
        if (typeof data === "string")
            return JSON.parse(data);
        else
            return data;
    }

    validateLocation(data: any) {
        let error = [];

        if (!data.location) {
            error.push(new Exception().ThrowException("1032"));
        } else {
            if (!data.location.latitude) {
                error.push(new Exception().ThrowException("1033"));
            }

            if (!data.location.longitude) {
                error.push(new Exception().ThrowException("1034"));
            }
        }

        return error;
    }

    static notifyUser(username, data, emitKey = "order canceled") {
        let driverOnline = CompanyOrder.connection.adapter.rooms[username];
        if (driverOnline) {
            CompanyOrder.connection.to(username).emit(emitKey, data);
            console.log("online:", username);
        } else {
            console.log("offline:", username);
        }
    }

    static OrderSocket(orderData, emitKey) {
        for (let username in orderData.socketPayload.room) {
            let socketUser = orderData.socketPayload.room[username];
            let driverOnline = CompanyOrder.connection.adapter.rooms[socketUser];
            if (driverOnline) {
                CompanyOrder.connection.to(socketUser).emit(emitKey, orderData.socketPayload.orderDetail);
                console.log("online:", username);
            } else {
                console.log("offline:", username);
            }
        }
    }
    /*
    /*****cron job code 
    deletedExpiredOrders(){
        return true;
    }
    deleteClosedOrders(){
    try{
        CompanyOrder.redisClient.keys('*', function (err, keys) {
            if (err) return console.log(err);
            console.log('********** Ready to show REDIS KEY ********');
            for(var i = 0, len = keys.length; i < len; i++) {
                let keyVal = keys[i].split(':');
                if(keyVal[0] !== 'LocalDriverLocation' && keys[i] !== 'LocalDriverLocation'){
                    
                    let orderId = keys[i];
                    let orderDetails = await that.orderService.GetSingleOrderDetails(orderId);
                    CompanyOrder.redisClient.del(keys[i], (err, deletedExpiredOrders) => {
                        console.log("DELETE ORDER AND DRIVERS", keys[i], deletedExpiredOrders);
                    });
                }
            }
            console.log('***********     Thank You    ********');
          }); 
        } catch (e) {
           console.error(e);
        } 
    }****/

}