import { CompanyOrder as _CompanyOrder } from "./CompanyOrder";

export namespace OrderPlacing {
    export const CompanyOrder = _CompanyOrder;
}