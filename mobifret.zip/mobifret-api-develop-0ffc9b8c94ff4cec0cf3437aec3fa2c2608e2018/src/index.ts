require('dotenv').config();
import "reflect-metadata";
import * as express from "express";
import * as bodyParser from "body-parser";
import { Routes } from "./Routes";
import { Socket } from "./socket/helper";
import { OrderPlacing } from "./socket/OrderPlacing";
import { Sequelize } from 'sequelize-typescript';
import { UrlHandler, ModuleHandler } from './helper';
import { Exception } from './middleware';
import * as Modules from "./modules";
import { moduleConfig } from './config/moduleConfig';
import { SequelizeLib } from './helper';

const app = express();
const argv = require("yargs").argv;
const server = require("http").Server(app);
const io = require("socket.io")(server);
const dbConfig = require("./config/dbConfig")[process.env.NODE_ENV];

const router = express.Router();

const routes = new Routes(router, app);
let sequelize: Sequelize;
let sequelizeLib: SequelizeLib;

export class Server {
    constructor() {
        app.use(bodyParser.json());
        app.use(Exception());
        this.routes(UrlHandler);
        this.connectDb();
        this.testDb();
        this.listen();
        this.socket();
    }

    listen() {
        server.listen(process.env.PORT || 3005, () => { });
    }

    connectDb() {
        sequelizeLib = SequelizeLib.getInstance();
        sequelize = sequelizeLib.getSequelize();
    }

    testDb() {
        sequelize
            .authenticate()
            .then(err => {
                console.log('Connection has been established successfully.');
            })
            .catch(err => {
                console.error('Unable to connect to the database:', err);
            });
    }

    addModule() {
        return moduleConfig;
    }

    socket() {
        const connection = new Socket.SocketConnection(io, "company", OrderPlacing.CompanyOrder);
    }

    routes(baseUrl) {
        let self = this;
        self.addModule().forEach((element) => {
            self.factory(element, baseUrl);
        })
    }

    factory(data: any, baseUrl: any) {
        let routesInstance = new Modules[data + "Routes"](express.Router()).Routes();
        app.use(baseUrl(data.toLowerCase()), routesInstance);
    }

}

new Server();