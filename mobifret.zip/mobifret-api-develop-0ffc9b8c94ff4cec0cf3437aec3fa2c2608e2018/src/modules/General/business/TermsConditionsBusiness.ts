import { TermsConditions, TermsConditionsService } from "../";

export class TermsConditionsBusiness {
    private termsConditionsService = new TermsConditionsService();
    
    async GetTermsConditions(roleid: number): Promise<TermsConditions[]> {
        let termsConditionsList = await this.termsConditionsService.GetTermsConditions(roleid);
        return termsConditionsList;
    }

}