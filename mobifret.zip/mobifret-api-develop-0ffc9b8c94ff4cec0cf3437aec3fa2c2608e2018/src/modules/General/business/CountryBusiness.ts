import { Country, CountryService } from "../";

export class CountryBusiness {
    private countryService = new CountryService();

    async GetCountry(): Promise<Country[]> {
        let countryList = await this.countryService.GetCountryService();
        return countryList;
    }

}