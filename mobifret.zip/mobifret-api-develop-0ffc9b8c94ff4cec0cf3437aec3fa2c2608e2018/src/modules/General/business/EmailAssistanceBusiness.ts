import { EmailAssistance, EmailAssistanceService } from "../";

export class EmailAssistanceBusiness {
    private emailAssistanceService = new EmailAssistanceService();

    async GetEmailAssistance(): Promise<EmailAssistance[]> {
        let emailAssistnaceList = await this.emailAssistanceService.GetEmailAssistance();
        return emailAssistnaceList;
    }

}