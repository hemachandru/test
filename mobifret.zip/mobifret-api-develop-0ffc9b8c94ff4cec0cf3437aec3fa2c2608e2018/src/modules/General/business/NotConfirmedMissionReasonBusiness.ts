import { Region, Country, RegionService } from "../";
import { NotConfirmedMissionReasonService } from "../service/NotConfirmedMissionReasonService";

export class NotConfirmedMissionReasonBusiness {
    private notConfirmedMissionReasonService = new NotConfirmedMissionReasonService();

    async GetNotConfirmedList(): Promise<any> {
        let result = await this.notConfirmedMissionReasonService.GetNotConfirmedList();
        return result;
    }
}