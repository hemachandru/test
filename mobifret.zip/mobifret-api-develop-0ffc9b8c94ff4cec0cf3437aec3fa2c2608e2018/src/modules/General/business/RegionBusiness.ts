import { Region, Country, RegionService } from "../";

export class RegionBusiness {
    private regionService = new RegionService();

    async GetRegion(countryid: string): Promise<Region[]> {
        let regionList = await this.regionService.GetRegion(countryid);
        return regionList;
    }
}