import { FreightType, FreightTypeService } from "../";

export class FreightTypeBusiness {
    private freightTypeService = new FreightTypeService();

    async GetFreightType(): Promise<FreightType[]> {
        let freightTypeList = await this.freightTypeService.GetFreightType();
        return freightTypeList;
    }

}