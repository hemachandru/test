import { FavouriteAddress, FavouriteAddressService } from "../";

export class FavouriteAddressBusiness {
    private favouriteAddressService = new FavouriteAddressService();

    async GetFavouriteAddress(userId: number): Promise<any> {
        let favouriteAddressList = await this.favouriteAddressService.GetFavouriteAddress(userId);
        return favouriteAddressList;
    }

    async FavAddress(params: any, userid: any): Promise<any> {
        try {


            let favaddressdetails: any = {
                favouriteName: params.name ? params.name : null,
                lat: params.address.lat,
                lan: params.address.lan,
                firstName: params.first_name,
                lastName: params.last_name ? params.last_name : null,
                email: params.email ? params.email : null,
                telephone: params.telephone,
                address1: params.address.address1,
                address2: params.address.address2 ? params.address.address2 : null,
                gateNumber: params.gate_number ? params.gate_number : null,
                appartmentName: params.apartment_name ? params.apartment_name : null,
                floor: params.floor ? params.floor : null,
                city: params.address.city ? params.address.city : null,
                country: params.address.country ? params.address.country : null,
                postalCode: params.address.postalcode,
                isLift: params.islift ? true : false,
                isBell: params.isbell ? true : false,
                userId: userid
            };
            let checkFavoriteAddr = await this.favouriteAddressService.CheckFavouriteAddress(favaddressdetails);
            let result;
            if (checkFavoriteAddr) {
                result = await this.favouriteAddressService.UpdateFavouriteAddress(checkFavoriteAddr.favouriteAddressId, favaddressdetails);
            } else {
                result = await this.favouriteAddressService.PostFavouriteAddress(favaddressdetails);
            }
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async DeleteFavouriteAddress(favouriteAddressId: any): Promise<any> {
        let deleteaddress = await this.favouriteAddressService.DeleteFavouriteAddress(favouriteAddressId);
        return deleteaddress;
    }

}