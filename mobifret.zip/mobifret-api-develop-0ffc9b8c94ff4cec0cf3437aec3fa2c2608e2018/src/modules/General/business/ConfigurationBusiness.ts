import { Configurations } from "../models/Configurations";
import { ConfigurationService } from '../service/ConfigurationService';

export class ConfigurationBusiness {
    private configurationService = new ConfigurationService();

    async GetConfiguration(): Promise<Configurations[]> {
        let configurationList = await this.configurationService.GetConfiguration();
        return configurationList;
    }

}