import { CallAssistance, CallAssistanceService } from "../";

export class CallAssistanceBusiness {
    private callAssistanceService = new CallAssistanceService();

    async GetCallAssistance(): Promise<CallAssistance[]> {
        let callAssistnaceList = await this.callAssistanceService.GetCallAssistance();
        return callAssistnaceList;
    }

}