import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo } from 'sequelize-typescript';
import { Country } from './Country';
@Table({
    tableName: "tblRegions"
})
export class Region extends Model<Region> {

    @AutoIncrement
    @PrimaryKey
    @Column
    regionId: number;

    @ForeignKey(() => Country)
    @Column
    countryId: number;

    @Column
    regionName: string;

    @BelongsTo(() => Country)
    country: Country;
    
}