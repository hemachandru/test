import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType, DefaultScope, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

@Table({
    tableName: "tblNotConfirmedMissionReasons"
})

export class NotConfirmedMissionReasons extends Model<NotConfirmedMissionReasons> {

    @AutoIncrement
    @PrimaryKey
    @Column
    reasonId: number;

    @Column
    reason: string;

    @Column
    status: number;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @DeletedAt
    deletedAt: Date;
}