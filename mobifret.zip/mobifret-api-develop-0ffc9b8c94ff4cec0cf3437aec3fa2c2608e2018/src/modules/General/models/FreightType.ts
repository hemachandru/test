import { Table, Column, Model, AutoIncrement, PrimaryKey, DefaultScope} from 'sequelize-typescript';

@DefaultScope({
  attributes: { exclude: ['createdAt', 'updatedAt',]}
})

@Table({
    timestamps: true,
    tableName: "tblFreightTypes"
})

export class FreightType extends Model<FreightType> {

    @AutoIncrement
    @PrimaryKey
    @Column
    freightTypeId: number;

    @Column
    freightType: string;
}