import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, DataType} from 'sequelize-typescript';
import { User } from "../../Account/models/User";
import { Region } from '../../General/models/Region';
import { Country } from '../../General/models/Country';

@DefaultScope({
  attributes: { exclude: ['createdAt', 'updatedAt',]}
})

@Table({
    timestamps: true,
    tableName: "tblFavouriteAddress"
})

export class FavouriteAddress extends Model<FavouriteAddress> {

    @AutoIncrement
    @PrimaryKey
    @Column
    favouriteAddressId: number;

    @Column
    favouriteName: string;

    @Column(DataType.FLOAT)
    lat: Number;

    @Column(DataType.FLOAT)
    lan: Number;
    
    @Column
    firstName: string;

    @Column
    lastName: string;

    @Column
    email: string;

    @Column
    telephone: string;

    @Column
    address1: string;

    @Column
    address2: string;

    @Column
    gateNumber: string;

    @Column
    appartmentName: string;

    @Column
    floor: string;

    @Column
    city: string;

    @Column
    country: string;

    @Column
    postalCode: string;

    @Column(DataType.BOOLEAN)
    isLift: boolean;

    @Column(DataType.BOOLEAN)
    isBell: boolean;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @BelongsTo(() => Region)
    region: Region;

    @ForeignKey(() => Country)
    @Column
    countryId: number;

    @BelongsTo(() => Country)
    countryname: Country;
}