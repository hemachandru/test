import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType } from 'sequelize-typescript';

@Table({
    tableName: "tblCountries"
})
export class Country extends Model<Country> {

    @AutoIncrement
    @PrimaryKey
    @Column
    countryId: number;

    @Column(DataType.CHAR(2))
    countryCode: string;

    @Column
    countryName: string;

    @Column
    active: boolean;

    @Column
    displayOrder: number;

}