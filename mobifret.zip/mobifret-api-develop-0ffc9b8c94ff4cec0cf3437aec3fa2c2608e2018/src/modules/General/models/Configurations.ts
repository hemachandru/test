import { Table, Column, Model, AutoIncrement, PrimaryKey} from 'sequelize-typescript';

@Table({
    tableName: "tblConfigurations"
})
export class Configurations extends Model<Configurations> {

    @AutoIncrement
    @PrimaryKey
    @Column
    configurationId: number;

    @Column
    configKey: string;

    @Column
    configValue: number;

}