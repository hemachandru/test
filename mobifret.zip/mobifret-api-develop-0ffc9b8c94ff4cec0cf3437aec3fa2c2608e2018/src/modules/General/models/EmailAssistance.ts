import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType, DefaultScope, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

@Table({
    timestamps: true,
    tableName: "tblEmailAssistances"
})

@DefaultScope({
  where: {assistanceStatus: 'Active'}
})

export class EmailAssistance extends Model<EmailAssistance> {

    @AutoIncrement
    @PrimaryKey
    @Column
    emailAssistanceId: number;

    @Column
    Email: string;

    @Column(DataType.ENUM('Active', 'Inactive', 'Deleted'))
    assistanceStatus: 'Active' | 'Inactive' | 'Deleted';

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @DeletedAt
    deletedAt: Date;

}