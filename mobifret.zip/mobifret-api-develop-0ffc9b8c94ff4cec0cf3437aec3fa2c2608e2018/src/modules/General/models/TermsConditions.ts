import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType, ForeignKey, DefaultScope, BelongsTo } from 'sequelize-typescript';
import { UserType } from "../../Account/models/UserType";

@DefaultScope({
    attributes: { exclude: ['termId', 'roleId', 'createdAt', 'updatedAt',] }
})

@Table({
    timestamps: false,
    tableName: "tblTermsAndConditions"
})

export class TermsConditions extends Model<TermsConditions> {

    @AutoIncrement
    @PrimaryKey
    @Column
    termId: number;

    @Column
    content: string;

    @Column(DataType.ENUM('ES', 'EN', 'FR'))
    lang: 'ES' | 'EN' | 'FR';

    @ForeignKey(() => UserType)
    @Column
    userTypeId: number;

    @BelongsTo(() => UserType)
    userType: UserType
}