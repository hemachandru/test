import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType, DefaultScope, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

@Table({
    timestamps: true,
    tableName: "tblCallAssistances"
})

@DefaultScope({
  where: {assistanceStatus: 'Active'}
})

export class CallAssistance extends Model<CallAssistance> {

    @AutoIncrement
    @PrimaryKey
    @Column
    callAssistanceId: number;

    @Column
    contactNumber: string;

    @Column(DataType.ENUM('Active', 'Inactive', 'Deleted'))
    assistanceStatus: 'Active' | 'Inactive' | 'Deleted';

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @DeletedAt
    deletedAt: Date;
}