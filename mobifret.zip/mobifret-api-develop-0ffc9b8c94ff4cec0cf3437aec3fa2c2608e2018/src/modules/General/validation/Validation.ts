import { FavouriteAddressService } from "../index";
import { Exception } from "../exception";

export class Validation {
    private error = [];
    constructor() {
        this.error = [];
    }

    FavouriteAddressValidation(data: any) {
        this.error = [];

        if (!data.address.lat) {
            this.error.push(new Exception().ThrowException("1003"));
        }

        if (!data.address.lan) {
            this.error.push(new Exception().ThrowException("1005"));
        }

        if (!data.first_name) {
            this.error.push(new Exception().ThrowException("1007"));
        }

        if (!data.telephone) {
            this.error.push(new Exception().ThrowException("1010"));
        }

        if (!data.address.address1) {
            this.error.push(new Exception().ThrowException("1012"));
        }

        if (!data.address.postalcode) {
            this.error.push(new Exception().ThrowException("1014"));
        }

        if (data.islift) {
            if (!(data.islift === false || data.islift === true)) {
                this.error.push(new Exception().ThrowException("1017"));
            }
        }

        if (data.isbell) {
            if (!(data.isbell === false || data.isbell === true)) {
                this.error.push(new Exception().ThrowException("1019"));
            }
        }

        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}