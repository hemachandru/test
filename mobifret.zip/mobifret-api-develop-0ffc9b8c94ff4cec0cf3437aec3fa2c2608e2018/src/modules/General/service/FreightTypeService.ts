import { Request, Response } from "express";
import { Core } from "../../Core";
import { FreightType } from "../";

export class FreightTypeService extends Core.BaseService {

    async GetFreightType(): Promise<FreightType[]> {
        try {
            let freightType = await FreightType.findAll<FreightType>({ raw: true });
            return freightType;
        } catch (e) {
            console.log("FreightType--", e);
            throw e;
        }
    }

}