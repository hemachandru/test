import { Request, Response } from "express";
import { Core } from "../../Core";
import { FavouriteAddress } from "../";

export class FavouriteAddressService extends Core.BaseService {

    async GetFavouriteAddress(userId: number): Promise<FavouriteAddress[]> {
        try {
            let favouriteAddress = await FavouriteAddress.findAll<FavouriteAddress>({
                where: {
                    userId: userId
                }, raw: true
            });
            return favouriteAddress;
        } catch (e) {
            console.log("FavouriteAddress--", e);

        }
    }

    async PostFavouriteAddress(objFavouriteAddress: FavouriteAddress): Promise<any> {
        try {

            let favaddress = new FavouriteAddress(objFavouriteAddress);
            let result = await favaddress.save();
            return result;
        } catch (e) {
            console.log("FavouriteAddress--", e);
            return false;
        }
    }

    async DeleteFavouriteAddress(favouriteAddressId: number): Promise<any> {
        try {
            let result = await FavouriteAddress.destroy({
                where: {
                    favouriteAddressId: favouriteAddressId
                }
            });
            return result;
        } catch (e) {
            console.log("FavouriteAddress--", e);
        }
    }

    async CheckFavouriteAddress(favaddressdetails: any): Promise<any> {
        try {
            let result = await FavouriteAddress.find<FavouriteAddress>({
                where: {
                    userId: favaddressdetails.userId,
                    telephone: favaddressdetails.telephone,
                    address1: favaddressdetails.address1,
                    city: favaddressdetails.city,
                    country: favaddressdetails.country,

                }, raw: true
            });
            return result;
        } catch (e) {
            console.log("FavouriteAddress--", e);
        }
    }


    async UpdateFavouriteAddress(favouriteAddressID: any, params: any): Promise<any> {
        try {
            let updateDriverMissionResult = await FavouriteAddress.update<FavouriteAddress>(params, {
                where: {
                    favouriteAddressId: favouriteAddressID,
                }
            });
            return updateDriverMissionResult;
        } catch (e) {
            console.log(e);
            return false;
        }
    }


}