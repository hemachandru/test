import { Request, Response } from "express";
import { Core } from "../../Core";
import { TermsConditions } from "../";

export class TermsConditionsService extends Core.BaseService {

    async GetTermsConditions(roleid: number): Promise<TermsConditions[]> {
        try {
            //console.log("roleid", roleid);
            let termsConditions = await TermsConditions.findAll<TermsConditions>({
                where: {
                    userTypeId: roleid
                }, raw: true 
            });
            return termsConditions;
        } catch (e) {
            console.log("TermsConditions--", e);
            throw e;
        }
    }

}