import { Request, Response } from "express";
import { Core } from "../../Core";
import { NotConfirmedMissionReasons } from "../models/NotConfirmedMissionReasons";
 

export class NotConfirmedMissionReasonService extends Core.BaseService {

    async GetNotConfirmedList(): Promise<any> {
        try {
            let result = await NotConfirmedMissionReasons.findAll<NotConfirmedMissionReasons>({
                raw: true
            });
            return result;
        } catch (e) {
            throw e;
        }
    }
}