import { Request, Response } from "express";
import { Core } from "../../Core";
import { Region } from "../";
import { Country } from '../';

export class RegionService extends Core.BaseService {
    async GetRegion(countryid: string): Promise<Region[]> {
        try {
            let region = await Region.findAll<Region>({
                where: {
                    countryId: countryid
                }, raw: true
            });
            return region;
        } catch (e) {
            console.log("Region--", e);
            throw e;
        }
    }
}