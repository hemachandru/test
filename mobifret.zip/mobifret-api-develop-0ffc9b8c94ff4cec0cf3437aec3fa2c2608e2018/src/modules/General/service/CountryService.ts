import { Request, Response } from "express";
import { Core } from "../../Core";
import { Country } from "../";

export class CountryService extends Core.BaseService {

    async GetCountryService(): Promise<Country[]> {
        try {
            //console.log("roleid", roleid);
            let country = await Country.findAll<Country>({raw: true});
            return country;
        } catch (e) {
            console.log("Country--", e);
            throw e;
        }
    }

}