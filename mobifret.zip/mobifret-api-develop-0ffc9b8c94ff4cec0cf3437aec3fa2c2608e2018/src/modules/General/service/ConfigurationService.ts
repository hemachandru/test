import { Request, Response } from "express";
import { Core } from "../../Core";
import { Configurations } from '../models/Configurations';

export class ConfigurationService extends Core.BaseService {

    async GetConfiguration(): Promise<Configurations[]> {
        try {
            let configuration = await Configurations.findAll<Configurations>({ raw: true });
            return configuration;
        } catch (e) {
            console.log("Configuration--", e);
            throw e;
        }
    }

}