import { Request, Response } from "express";
import { Core } from "../../Core";
import { EmailAssistance } from "../";

export class EmailAssistanceService extends Core.BaseService {

    async GetEmailAssistance(): Promise<EmailAssistance[]> {
        try {
            let emailAssistance = await EmailAssistance.findAll<EmailAssistance>({ raw: true });
            return emailAssistance;
        } catch (e) {
            console.log("EmailAssistance--", e);
            throw e;
        }
    }

}