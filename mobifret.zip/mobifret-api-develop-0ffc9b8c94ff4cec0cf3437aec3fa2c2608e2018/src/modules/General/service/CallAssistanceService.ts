import { Request, Response } from "express";
import { Core } from "../../Core";
import { CallAssistance } from "../";

export class CallAssistanceService extends Core.BaseService {

    async GetCallAssistance(): Promise<CallAssistance[]> {
        try {
            let callAssistance = await CallAssistance.findAll<CallAssistance>({ raw: true });
            return callAssistance;
        } catch (e) {
            console.log("CallAssistance--", e);
            throw e;
        }
    }
}