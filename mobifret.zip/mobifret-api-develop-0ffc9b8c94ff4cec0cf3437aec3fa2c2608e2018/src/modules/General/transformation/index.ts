import { Core } from "../../Core";
import { CallAssistance, EmailAssistance, FreightType, TermsConditions, Region, Country, FavouriteAddress } from '../';

export class Transformation extends Core.BaseTransformation {

    constructor() {
        super();
    }

    GeneralAssistance(callAssistance: any, emailAssistance: any) {

        let callAssis = [];
        let emailAssis = [];

        let ca: CallAssistance[] = callAssistance;
        let ea: EmailAssistance[] = emailAssistance;

        for (let i in ca) {
            let callAssistanceNode = new Object();
            callAssistanceNode["id"] = ca[i].callAssistanceId;
            callAssistanceNode["contact"] = ca[i].contactNumber;
            callAssis.push(callAssistanceNode);
        }

        for (let i in ea) {
            let emailAssistanceNode = new Object();
            emailAssistanceNode["id"] = ea[i].emailAssistanceId;
            emailAssistanceNode["contact"] = ea[i].Email;
            emailAssis.push(emailAssistanceNode);
        }

        let result = new Object();

        result["call"] = callAssis;
        result["email"] = emailAssis;

        return result;
    }

    GeneralFrightType(frieghtType: any) {

        let freighttype = [];

        let ft: FreightType[] = frieghtType;

        for (let i in ft) {
            let freighttypeNode = new Object();
            freighttypeNode["id"] = ft[i].freightTypeId;
            freighttypeNode["type"] = ft[i].freightType;
            freighttype.push(freighttypeNode);
        }

        return freighttype;
    }

    GeneralTermsConditions(termsConditions: any) {

        let resultObject = {};

        let tc: TermsConditions[] = termsConditions;
        for (let i in tc) {
            resultObject[tc[i].lang] = tc[i].content;
        }

        return resultObject;
    }

    GeneralRegions(regions: any) {
        let resultObject = [];
        let region: Region[] = regions;

        for (let i in region) {
            let regionNode = new Object();
            regionNode["id"] = region[i].regionId;
            regionNode["name"] = region[i].regionName;
            resultObject.push(regionNode);
        }
        return resultObject;
    }

    GeneralCountries(countries: any) {
        let resultObject = [];
        let country: Country[] = countries;

        for (let i in country) {
            let countryNode = new Object();
            countryNode["id"] = country[i].countryId;
            countryNode["name"] = country[i].countryName;
            resultObject.push(countryNode);
        }
        return resultObject;
    }

    GeneralConfiguration(config: any) {
        let radius;
        let time_out;
        let driver_request;
        let insurance_percentage;
        let android_minimum_app_version;
        let ios_minimum_app_version;
        config.forEach(element => {
            if (element.configKey == 'radius')
                radius = element.configValue
            if (element.configKey == 'time_out')
                time_out = element.configValue
            if (element.configKey == 'driver_request')
                driver_request = element.configValue
            if (element.configKey == 'insurance_percentage')
                insurance_percentage = element.configValue
            if (element.configKey == 'android_minimum_app_version')
                android_minimum_app_version = element.configValue
            if (element.configKey == 'ios_minimum_app_version')
                ios_minimum_app_version = element.configValue
        });

        let configObj = {
            radius: radius ? radius : null,
            time_out: time_out ? time_out : null,
            driver_request: driver_request ? driver_request : null,
            insurance_percentage: insurance_percentage ? insurance_percentage : null,
            android_minimum_app_version: android_minimum_app_version.toString(),
            ios_minimum_app_version: ios_minimum_app_version.toString()
        }

        return configObj;
    }

    GeneralFavouriteAddress(favouriteAddress: any) {
        let addressObject = [];
        let favAddress: FavouriteAddress[] = favouriteAddress;

        for (let i in favAddress) {
            let resultObject = {
                id: favAddress[i].favouriteAddressId,
                name: favAddress[i].favouriteName,
                first_name: favAddress[i].firstName,
                last_name: favAddress[i].lastName,
                email: favAddress[i].email,
                telephone: favAddress[i].telephone,
                address: {
                    lat: favAddress[i].lat,
                    lan: favAddress[i].lan,
                    address1: favAddress[i].address1,
                    address2: favAddress[i].address2,
                    city: favAddress[i].city,
                    country: favAddress[i].country,
                    postalcode: favAddress[i].postalCode
                },
                gate_number: favAddress[i].gateNumber,
                apartment_name: favAddress[i].appartmentName,
                floor: favAddress[i].floor,
                islift: favAddress[i].isLift ? true : false,
                isbell: favAddress[i].isBell ? true : false

            };

            addressObject.push(resultObject);
        }
        return addressObject;
    }

    NotConfirmendList(reason: any) {
        let resultObject = [];

        for (let i in reason) {
            let reasonNode = new Object();
            reasonNode["reasonid"] = reason[i].reasonId;
            reasonNode["reason"] = reason[i].reason;
            resultObject.push(reasonNode);
        }
        return resultObject;
    }
}