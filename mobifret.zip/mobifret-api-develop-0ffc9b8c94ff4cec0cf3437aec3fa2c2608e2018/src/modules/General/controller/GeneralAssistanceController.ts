import { Request, Response } from "express";
import { CallAssistanceController, EmailAssistanceController, CallAssistanceBusiness, EmailAssistanceBusiness } from '../';
import { Core } from "../../Core";
import { Transformation } from "../transformation/index";

export class GeneralAssistanceController extends Core.BaseController {
    private callAssistanceBusiness: CallAssistanceBusiness = new CallAssistanceBusiness();
    private emailAssistanceBusiness: EmailAssistanceBusiness = new EmailAssistanceBusiness();

    GetAssistance() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let callAssistance = await self.callAssistanceBusiness.GetCallAssistance();
                let emailAssistance = await self.emailAssistanceBusiness.GetEmailAssistance();

                if (callAssistance || emailAssistance) {
                    var result = new Transformation().GeneralAssistance(callAssistance, emailAssistance);
                    return res.send(result);
                }


            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}