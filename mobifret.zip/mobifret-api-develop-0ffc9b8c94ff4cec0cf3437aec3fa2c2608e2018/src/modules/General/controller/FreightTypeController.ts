import { Request, Response } from "express";
import { Core } from "../../Core";
import { FreightType, FreightTypeService, FreightTypeBusiness } from "../";
import { Transformation } from '../transformation';

export class FreightTypeController extends Core.BaseController {

    private freightTypeBusiness = new FreightTypeBusiness();

    /**
    * GET Fright Type
    */
    GetFrightType() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.freightTypeBusiness.GetFreightType();
                return res.send(new Transformation().GeneralFrightType(result));
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}