import { Request, Response } from "express";
import { Core } from "../../Core";
import { EmailAssistance, EmailAssistanceService, EmailAssistanceBusiness } from "../";

export class EmailAssistanceController extends Core.BaseController{
    
    private emailAssistanceBusiness = new EmailAssistanceBusiness();

    /**
    * GET Email Assistance
    */
    GetEmailAssistance() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.emailAssistanceBusiness.GetEmailAssistance();
                return res.send(result);
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}