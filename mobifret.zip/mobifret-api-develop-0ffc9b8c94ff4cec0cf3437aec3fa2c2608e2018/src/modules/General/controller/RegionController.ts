import { Request, Response } from "express";
import { Core } from "../../Core";
import { Region, RegionService, RegionBusiness } from "../";
import { Transformation } from '../transformation';

export class RegionController extends Core.BaseController {

    private regionBusiness = new RegionBusiness();

    /**
    * GET Region
    */
    GetRegion() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.regionBusiness.GetRegion(req.params.countryid);
                return res.send(new Transformation().GeneralRegions(result));
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }
}