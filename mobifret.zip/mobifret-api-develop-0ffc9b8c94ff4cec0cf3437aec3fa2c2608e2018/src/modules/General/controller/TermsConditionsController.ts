import { Request, Response } from "express";
import { Core } from "../../Core";
import { TermsConditions, TermsConditionsService, TermsConditionsBusiness } from "../";
import { Transformation } from '../transformation';

export class TermsConditionsController extends Core.BaseController {

    private termsConditionsBusiness = new TermsConditionsBusiness();
    private transformation = new Transformation();

    /**
    * GET Terms and Conditions
    */
    GetTermsConditions() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.termsConditionsBusiness.GetTermsConditions(req.params.roleid);
                let transresult = await this.transformation.GeneralTermsConditions(result);
                return res.send(transresult);
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}