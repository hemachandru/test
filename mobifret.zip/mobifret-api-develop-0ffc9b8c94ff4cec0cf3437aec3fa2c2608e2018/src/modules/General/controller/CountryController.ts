import { Request, Response } from "express";
import { Core } from "../../Core";
import { Country, CountryService, CountryBusiness } from "../";
import { Transformation } from '../transformation';

export class CountryController extends Core.BaseController {

    private countryBusiness = new CountryBusiness();

    /**
    * GET Fright Type
    */
    GetCountry() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.countryBusiness.GetCountry();
                return res.send(new Transformation().GeneralCountries(result));
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}