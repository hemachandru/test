import { Request, Response } from "express";
import { Core } from "../../Core";
import { Transformation } from '../transformation';
import { NotConfirmedMissionReasonBusiness } from "../business/NotConfirmedMissionReasonBusiness";

export class NotConfirmedMissionReasonController extends Core.BaseController {

    private notConfirmedMissionReasonBusiness = new NotConfirmedMissionReasonBusiness();

    /**
    * GET Region
    */
    GetNotConfirmedList() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.notConfirmedMissionReasonBusiness.GetNotConfirmedList();
                return res.send(new Transformation().NotConfirmendList(result));
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }
}