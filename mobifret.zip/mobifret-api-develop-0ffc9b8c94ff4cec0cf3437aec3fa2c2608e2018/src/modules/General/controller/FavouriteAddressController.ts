import { Request, Response } from "express";
import { Core } from "../../Core";
import { FavouriteAddress, FavouriteAddressService, FavouriteAddressBusiness } from "../";
import { Transformation } from '../transformation';
import { Validation } from "../validation";
import { Exception } from "../exception";

export class FavouriteAddressController extends Core.BaseController {

    private favouriteAddressBusiness = new FavouriteAddressBusiness();
    private validate = new Validation();

    /**
    * GET Fright Type
    */
    GetFavouriteAddress() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData:any = req.headers['user'];
                let result = await self.favouriteAddressBusiness.GetFavouriteAddress(parseInt(userData.userID));
                return res.send(new Transformation().GeneralFavouriteAddress(result));
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    PostFavouriteAddress() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.FavouriteAddressValidation(req.body);
                if (!validate.status) {
                    let userData:any = req.headers['user'];
                    let result = await self.favouriteAddressBusiness.FavAddress(req.body, parseInt(userData.userID));
                    if (result != false) {
                        return res.send();
                    } else {
                        return res.status(500).send([new Exception().ThrowException("")]);
                    }
                }
                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    DeleteFavouriteAddress() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.favouriteAddressBusiness.DeleteFavouriteAddress(req.params.favouriteAddressId);
                if (result == 1) {
                    return res.status(200).send();
                }
                return res.status(422).send([new Exception().ThrowException("1021")]);
            }
            catch (e) {
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

}