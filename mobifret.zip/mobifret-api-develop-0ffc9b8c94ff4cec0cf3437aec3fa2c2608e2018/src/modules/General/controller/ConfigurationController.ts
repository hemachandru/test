import { Request, Response } from "express";
import { Core } from "../../Core";
import { Configurations } from "../models/Configurations";
import { ConfigurationBusiness } from '../business/ConfigurationBusiness';
import { Transformation } from '../transformation';

export class ConfigurationController extends Core.BaseController {

    private configurationBusiness = new ConfigurationBusiness();

    /**
    * GET Fright Type
    */
    GetConfiguration() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.configurationBusiness.GetConfiguration();
                return res.send(new Transformation().GeneralConfiguration(result));
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}