import { Request, Response } from "express";
import { Core } from "../../Core";
import { CallAssistance, CallAssistanceService, CallAssistanceBusiness } from "../";

export class CallAssistanceController extends Core.BaseController {

    private callAssistanceBusiness = new CallAssistanceBusiness();

    /**
    * GET Call Assistance
    */
    GetCallAssistance() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.callAssistanceBusiness.GetCallAssistance();
                return res.send(result);
            } catch (e) {
                console.log(e);
                throw e;
            }
        };
    }

}