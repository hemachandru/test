import { error } from "./FavouriteAddressException";
import { Core } from "../../Core";

export class Exception extends Core.BaseException {
    constructor() {
        super(error);
    }
}