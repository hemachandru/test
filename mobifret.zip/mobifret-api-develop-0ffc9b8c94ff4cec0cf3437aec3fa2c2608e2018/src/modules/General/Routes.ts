import { Router } from "express";
import { Core } from "../Core";
import { CallAssistanceController } from './controller/CallAssistanceController';
import { EmailAssistanceController } from './controller/EmailAssistanceController';
import { TermsConditionsController } from "./controller/TermsConditionsController";
import { RegionController } from './controller/RegionController';
import { GeneralAssistanceController } from './controller/GeneralAssistanceController';
import { FreightTypeController } from './controller/FreightTypeController';
import { CountryController } from './controller/CountryController';
import { FavouriteAddressController } from './controller/FavouriteAddressController';
import { ConfigurationController } from './controller/ConfigurationController';


import { Middleware } from "../Account/middleware";
import { NotConfirmedMissionReasonController } from "./controller/NotConfirmedMissionReasonController";

export class Routes extends Core.BaseRoutes {

    private route: Router;
    private callAssistanceController: CallAssistanceController = new CallAssistanceController();
    private emailAssistanceController: EmailAssistanceController = new EmailAssistanceController();
    private termsConditionsController: TermsConditionsController = new TermsConditionsController();
    private regionController: RegionController = new RegionController();
    private generalAssistanceController: GeneralAssistanceController = new GeneralAssistanceController();
    private freightypeController: FreightTypeController = new FreightTypeController();
    private countryController: CountryController = new CountryController();
    private favouriteAddressController: FavouriteAddressController = new FavouriteAddressController();
    private configurationController: ConfigurationController = new ConfigurationController();
    private notConfirmedMissionReasonController: NotConfirmedMissionReasonController = new NotConfirmedMissionReasonController();

    private middleware: Middleware = new Middleware();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;

        //Get Call Assistance Routes
        self.route.get("/v1/getCallAssistance", [self.middleware.Authorization()], self.callAssistanceController.GetCallAssistance());

        //Get Email Assistance Routes
        self.route.get("/v1/getEmailAssistance", [self.middleware.Authorization()], self.emailAssistanceController.GetEmailAssistance());

        //Get Term Conditions Routes
        self.route.get("/v1/getTermsConditions/:roleid", [self.middleware.AppAuthorization()], self.termsConditionsController.GetTermsConditions());

        //Get Region Routes
        self.route.get("/v1/getRegions/:countryid", [self.middleware.AppAuthorization()], self.regionController.GetRegion());

        //Get Country Routes
        self.route.get("/v1/getCountry", [self.middleware.AppAuthorization()], self.countryController.GetCountry());

        //Get Assistance Routes
        self.route.get("/v1/getAssistance", [self.middleware.Authorization()], self.generalAssistanceController.GetAssistance());

        //Get FreightType Routes
        self.route.get("/v1/getFreightType", [self.middleware.AppAuthorization()], self.freightypeController.GetFrightType());

        //Get FavouriteAddress Routes
        self.route.get("/v1/getFavouriteAddress", [self.middleware.Authorization()], self.favouriteAddressController.GetFavouriteAddress());

        //Post FavouriteAddress Routes
        self.route.post("/v1/postFavouriteAddress", [self.middleware.Authorization()], self.favouriteAddressController.PostFavouriteAddress());

        //Delete FavouriteAddress Routes
        self.route.delete("/v1/deleteFavouriteAddress/:favouriteAddressId", [self.middleware.Authorization()], self.favouriteAddressController.DeleteFavouriteAddress());

        //Get Configuration
        self.route.get("/v1/getConfiguration", [self.middleware.AppAuthorization()], self.configurationController.GetConfiguration());

         //Get Not Confirmed Mission Reasons 
         self.route.get("/v1/getNotConfirmedList", [self.middleware.AppAuthorization()], self.notConfirmedMissionReasonController.GetNotConfirmedList());

        return self.route;
    }

}