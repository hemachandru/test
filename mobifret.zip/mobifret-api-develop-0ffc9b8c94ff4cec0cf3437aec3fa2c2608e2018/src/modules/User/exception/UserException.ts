export let error = {
    "1101": "Firstname does not empty",
    "1102": "Lastname does not empty",
    "1103": "Mobile number does not empty",
    "1104": "User profile not successfull",
}