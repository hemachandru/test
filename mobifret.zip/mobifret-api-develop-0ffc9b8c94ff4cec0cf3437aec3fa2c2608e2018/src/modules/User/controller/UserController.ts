import { Request, Response } from "express";
import { Core } from "../../Core";
import { UserBusiness } from '../business/UserBusiness';
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";

export class UserController extends Core.BaseController {

    private userBusiness = new UserBusiness();
    private validate = new Validation();


    constructor() {
        super();
    }

    PutProfile() {
        let self = this;
        return async (req: Request, res: Response) => {
            let userData: any = req.headers['user'];
            let user = await self.userBusiness.EditProfile(req.body, userData.userID);
            return res.status(200).send("success");
        }
    }



    //Update Profile Info Controller
    UpdateProfile() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers["user"];
                let validate = await this.validate.validateUserProfileUpdate(userData, req.body);
                if (!validate.status) {
                    if (userData) {
                        let result = await self.userBusiness.UpdateProfile(userData, req.body);
                        if (result) {
                            return res.status(200).send('Success');
                        } else {
                            return res.status(422).send([new Exception().ThrowException("1104")]);
                        }
                    }
                } else {
                    return res.status(422).send(validate.error);
                }

            } catch (e) {
                throw (e);
            }
        };
    }
}