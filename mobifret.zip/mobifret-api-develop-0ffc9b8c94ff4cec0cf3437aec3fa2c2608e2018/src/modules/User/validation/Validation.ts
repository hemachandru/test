import { Exception } from "../exception";
const bcrypt = require('bcrypt');
import { S3Lib } from '../../../helper';
import { Core } from "../../Core/index";

export class Validation extends Core.BaseValidation {
    private error = [];
    private s3 = new S3Lib();
    constructor() {
        super();
        this.error = [];
    }

    isEmpty(str) { return (str.length === 0 || !str.trim()) };
    hasWhiteSpace(s) { return s.indexOf(' ') >= 0; }

    async validateUserProfileUpdate(userdata: any, data: any) {
        this.error = [];

        if (userdata.roleID === 6 || userdata.roleID === 3 || userdata.roleID === 2) {
            if (data.profile_image) {
                let profileResult = await this.s3.FindObject(data.profile_image);
                if (!profileResult) {
                    this.error.push(new Exception().ThrowException("1028"));
                }
            }

            if (data.firstname) {
                if (this.isEmpty(data.firstname)) {
                    this.error.push(new Exception().ThrowException("1101"));
                }
            }

            if (data.lastname) {
                if (this.isEmpty(data.lastname)) {
                    this.error.push(new Exception().ThrowException("1102"));
                }
            }

            if (data.mobile) {
                if (this.isEmpty(data.mobile)) {
                    this.error.push(new Exception().ThrowException("1103"));
                }
            }
        }

        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}