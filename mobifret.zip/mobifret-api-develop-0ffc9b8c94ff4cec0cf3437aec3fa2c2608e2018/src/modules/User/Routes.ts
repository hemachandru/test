import { Router } from "express";
import { Core } from "../Core";
import { Middleware } from "../Account/middleware";
import { UserController } from "./controller/UserController";
import { AccountController } from "../Account/controller/AccountController";

export class Routes extends Core.BaseRoutes {
    private route: Router;
    private middleware: Middleware = new Middleware();
    private userController: UserController = new UserController();
    private accountController: AccountController = new AccountController();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;
        //Update Profile Info
        self.route.patch("/v1/profileupdate", [self.middleware.Authorization()], self.userController.UpdateProfile());
        self.route.get("/v1/currentuser", [self.middleware.Authorization()], self.accountController.GetCurrentUser());
        return self.route;
    }
}
