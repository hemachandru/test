import { Core } from "../../Core";
import * as crypto from "crypto";

export class Utility extends Core.BaseHelper {
    constructor() {
        super();
    }
}