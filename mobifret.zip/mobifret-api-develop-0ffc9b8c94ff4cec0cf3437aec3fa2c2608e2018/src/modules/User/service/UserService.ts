import { Request, Response } from "express";
import { Core } from "../../Core";

export class UserService extends Core.BaseService {

    async editProfile(): Promise<any> {
        return null;
    }

}