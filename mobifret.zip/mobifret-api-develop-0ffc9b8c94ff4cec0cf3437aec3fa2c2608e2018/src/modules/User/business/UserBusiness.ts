import { UserService } from '../../Account/service/UserService';
import { Utility } from '../helper';
import { S3Lib } from "../../../helper/S3Lib";
import { DocumentService } from "../../Account/service/DocumentService";
import { ContactService } from '../../Account/service/ContactService';
import { CompanyDetailService } from '../../Account/service/CompanyDetailService';
import { User } from '../../index';

export class UserBusiness {
    private userService = new UserService();
    private utility = new Utility();
    private s3 = new S3Lib();
    private documentService = new DocumentService();
    private contactService = new ContactService();
    private companyService = new CompanyDetailService();


    constructor() {

    }

    async EditProfile(data: any, userid: any): Promise<any> {
        return null;
    }



    //Update User Profile Business
    async UpdateProfile(userData: any, userObject: any): Promise<any> {
        let self = this;
        let userDetail = await this.userService.GetCurrentUser(userData.userID);
        let profileImage = userObject.profile_image;
        let photoResult;
        let companyDetails = {};
        if (userObject && profileImage) {
            let photoDestination = "api/registration/profile/" + this.utility.GenerateRandomString(15) + "_" + new Date().getTime() + ".jpg";
            let photoS3 = await this.s3.CopyObjectPublic("/" + profileImage, photoDestination);
            let photoDocument: any = {
                documentType: 'photo',
                document: photoS3 ? photoDestination : null
            }
            photoResult = await this.documentService.PostDocument(photoDocument);
            userObject['photoId'] = photoResult.getDataValue("documentId");

        }
        if (userObject.firstname)
            userObject['firstName'] = userObject.firstname;

        if (userObject.lastname)
            userObject['lastName'] = userObject.lastname;

        if (userObject.postalcode)
            userObject['postalCode'] = userObject.postalcode;

        if (userObject.region_id)
            userObject['regionId'] = userObject.region_id;

        if (userObject.country)
            userObject['countryId'] = userObject.country;

        if (userObject.country)
            userObject['countryId'] = userObject.country;

        if (userObject.codeNaf)
            companyDetails['codeNaf'] = userObject.codeNaf;

        if (userObject.tva)
            companyDetails['tva'] = userObject.tva;

        if (userObject) {
            let updatePersonalInfo = await this.contactService.updateContact(userDetail.contactId, userObject);
        }

        if (companyDetails) {
            let companyResult = await this.companyService.UpdateCompanyDetail(userDetail.registrationId, companyDetails);
        }

        if (userObject.companyname) {
            let companyResult = await this.companyService.UpdateCompanyName(userDetail.registrationId, userObject.companyname);
        }

        return true;
    }

}