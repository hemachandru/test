import { Core } from "../../Core";

export class Transformation extends Core.BaseTransformation {

    constructor() {
        super();
    }

    CurrentUser(data: any) {
        // delete data.currentPassword;
        // delete data.passwordOne;
        // delete data.passwordTwo;
        // delete data.passwordThree;

        let countryNode = {};
        let regionNode = {};
        let driverNode = {};
        let deviceNode = [];

        if (data.contact.country) {
            countryNode["id"] = data.contact.country.countryId;
            countryNode["code"] = data.contact.country.countryCode;
            countryNode["name"] = data.contact.country.countryName;
        }

        if (data.region) {
            regionNode["id"] = data.region.regionId;
            regionNode["name"] = data.region.regionName;
        }

        if (data.driver) {
            driverNode["id"] = data.driver.driverId;
            driverNode["isActive"] = data.driver.isActive;
        }

        if (data.device && data.device.length > 0) {
            data.device.forEach(element => {
                if (element.status) {
                    deviceNode.push({
                        "device_id": element.deviceId,
                        "device_uuid": element.deviceUuid,
                        "device_token": element.deviceToken,
                        "device_type": element.deviceType,
                        "device_os": element.deviceOs,
                        "device_arn": element.deviceArn
                    });
                }
            });
        }

        let result: any = {
            id: data.userId,
            userRole: {
                id: data.userType.userTypeId,
                name: data.userType.userType
            },
            registration: {
                id: data.registration.registrationId,
                companyName: data.registration.companyName,
                isActive: data.registration.isActive
            },
            contact: {
                id: data.contact.contactId,
                firstName: data.contact.firstName,
                lastName: data.contact.lastName,
                dob: data.contact.dob,
                landline: data.contact.landline,
                mobile: data.contact.mobile,
                email: data.contact.email,
                address1: data.contact.address1,
                address2: data.contact.address2,
                postalCode: data.contact.postalCode,
                city: data.contact.city,
                state: data.contact.state,
                country: countryNode,
                profile_image: data.contact.document ? process.env.AWS_CDN_URL + "/" + data.contact.document.document : null
            },
            region: regionNode,
            driver: driverNode,
            device: deviceNode
        }

        return result;
    }
}