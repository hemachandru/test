import { Exception } from "../exception";
import { DriverMissionService } from '../service/DriverMissionService';

export class Validation {
    private error = [];
    private driverMissionService: DriverMissionService = new DriverMissionService();
    constructor() {
        this.error = [];
    }

    async CheckDriver(driverId: any, data: any) {
        this.error = [];
        if (!(data.isjobStatus >= 0)) {
            this.error.push(new Exception().ThrowException("1080"));
        }
        if (data.isjobStatus === 1) {
            if (!data.qr_code) {
                this.error.push(new Exception().ThrowException("1066"));
            }
            let driverVehicleResult = await this.driverMissionService.CheckDriverVehicle(data.qr_code);
            if (driverVehicleResult) {
                if (driverVehicleResult.driverId === null) {
                    let companyDriverVehiclID = await this.driverMissionService.CheckCompanyDriverVehicle(driverVehicleResult.vehicleId, driverId);
                    if (companyDriverVehiclID.length === 0) {
                        this.error.push(new Exception().ThrowException("1088"));
                    } else {
                        let driverVehicleId = await this.driverMissionService.GetDriverVehicleId(driverId);
                        if (driverVehicleId) {
                            await this.driverMissionService.RemoveDriverVehicleId(driverVehicleId.vehicleId);
                        }
                        await this.driverMissionService.updateDriverIdVehicle(driverVehicleResult.vehicleId, driverId);
                    }
                } else if (driverVehicleResult.driverId != driverId) {
                    this.error.push(new Exception().ThrowException("1089"));
                }
            } else {
                this.error.push(new Exception().ThrowException("1090"));
            }
        }
        return this.handler(this.error);
    }

    CheckQRCode(data: any) {
        this.error = [];

        if (!data.shipment_id) {
            this.error.push(new Exception().ThrowException("1082"));
        }

        if (!data.registrationid) {
            this.error.push(new Exception().ThrowException("1081"));
        }

        if (!data.qr_code) {
            this.error.push(new Exception().ThrowException("1066"));
        }
        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}