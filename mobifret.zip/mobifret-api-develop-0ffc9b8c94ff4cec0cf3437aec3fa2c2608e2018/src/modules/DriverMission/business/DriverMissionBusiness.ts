import { DriverMissionService } from "../service/DriverMissionService";
import { Cart as Order } from '../../Cart/models/Cart';
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";

export class DriverMissionBusiness {

    private driverMissionService = new DriverMissionService();

    async CheckOrderOrDriver(orderID: any, driverID: any, userId: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderOrDriver(orderID, driverID, userId);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async CheckOrderStatusDriver(orderID: any, driverID: any, registrationId: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderStatusDriver(orderID, driverID, registrationId);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async CheckOrderClient(orderID: any, userid: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderClient(orderID, userid);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async CheckOrderStatusClient(orderID: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderStatusClient(orderID);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async CheckOrderDriverPickupCode(orderID: any, driverID: any, registrationId: any, pickup_code: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderDriverPickupCode(orderID, driverID, registrationId, pickup_code);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async CheckOrderDriverDeliveryCode(orderID: any, driverID: any, registrationId: any, delivery_code: any): Promise<string> {
        try {
            let result = await this.driverMissionService.CheckOrderDriverDeliveryCode(orderID, driverID, registrationId, delivery_code);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }


    async GetDriverMission(orderID: any, status: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetDriverMission(orderID, status);
            return result;
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async DriverAccept(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.Accepted, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }

    }

    async DriverCancel(orderID: any, reasonData: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, null, null, OrderStatusEnum.Cancelled, reasonData);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }

    }

    async DriverStart(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.Started, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async DriverPickup(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.Pickup, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async DriverReached(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.Reached, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }


    async DriverComplete(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.Completed, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async DriverNotComplete(orderID: any, driverID: any, registrationID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverAcceptOrCancel(orderID, driverID, registrationID, OrderStatusEnum.NotCompleted, null);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async ClientOrderCancelled(orderID: any, userid: any, reason: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.ClientOrderCancelled(orderID, userid, OrderStatusEnum.ClientCancelled, reason);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async DriverReject(orderID: any, driverID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverReject(orderID, driverID);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }

    }

    async DriverMissionCreate(params: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.DriverMissionCreate(params.orderID, params.driverID);
            if (result)
                return true;
            return false;
        } catch (e) {
            console.log(e);
            return false;
        }

    }

    async GetOrderListDriver(params: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetOrderListDriver(params);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }


    async GetOrderListDriverCount(userid: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetOrderListDriverCount(userid);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetOrderListDriverStatusCount(params: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetOrderListDriverStatusCount(params);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async FindRateOrder(orderID: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.FindRatingOrder(orderID);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetSingleOrderDriver(orderid: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetSingleOrderDriver(orderid);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async CheckOrderRating(orderID: any): Promise<any> {
        try {
            let result = await this.driverMissionService.CheckOrderRating(orderID);
            return result;
        } catch (e) {
            console.error(e);
            return false;
        }
    }

    async ScanQr(shipmentID: any, qrCodeDetail: any): Promise<any> {
        try {
            let result = await this.driverMissionService.ScanQr(shipmentID, qrCodeDetail);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async RateOrder(params: any): Promise<Boolean> {
        try {
            let result = await this.driverMissionService.RateOrder(params);
            return result;
        } catch (e) {
            console.error(e);
            return false;
        }
    }

    async CheckQr(registrationid: number, qrCode: any): Promise<any> {
        try {
            let result = await this.driverMissionService.CheckQr(registrationid, qrCode);
            return result;
        } catch (e) {
            console.log(e);
            return null;
        }
    }

    async DriverUpdateStatus(driverid: number, isjobStatus: any): Promise<any> {
        try {
            let result = await this.driverMissionService.DriverUpdateStatus(driverid, isjobStatus);
            return result;
        } catch (e) {
            return null;
        }
    }

    async CheckQRCode(shipmentID: any, qrcode: any): Promise<any> {
        try {
            let result = await this.driverMissionService.CheckQRCode(shipmentID, qrcode);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }

    }

    async GetOrderDriverId(orderid: any): Promise<any> {
        try {
            let result = await this.driverMissionService.GetOrderDriverId(orderid)
            return result;

        } catch (e) {

        }
    }

    async CheckDriverVehicle(driverid: any, qrcode: any): Promise<any> {
        try {
            let currentDriverVehicleId = await this.driverMissionService.GetDriverVehicleId(driverid)
            let deleteDriverVehicle = await this.driverMissionService.DeleteDriverVehicle(driverid, currentDriverVehicleId.vehicleId)
            let driverVehicleResult = await this.driverMissionService.CheckDriverVehicle(qrcode)
            let vehicleID = driverVehicleResult.getDataValue("vehicleId");
            if (vehicleID) {
                let updateDriverVehicle: any = await this.driverMissionService.updateDriverIdVehicle(vehicleID, driverid)
                if (updateDriverVehicle) {
                    let updateOrderVehicle: any = await this.driverMissionService.updateVehicleInOrder(vehicleID, driverid)
                    return updateOrderVehicle;
                }
            }
        } catch (e) {
            console.log(e);
        }
    }

    async CheckDriverVehicleID(driverid: any): Promise<any> {
        try {
            let result = await this.driverMissionService.CheckDriverVehicleID(driverid)
            return result;

        } catch (e) {

        }
    }

    async DriverPickupValidationCode(orderid: any, otppin: any): Promise<any> {
        try {
            let result = await this.driverMissionService.DriverPickupValidationCode(orderid, otppin)
            return result;

        } catch (e) {

        }
    }

    async RemoveDriverVehicleId(driverid: any, vehicleid: any): Promise<any> {
        try {
            let result = await this.driverMissionService.RemoveDriverVehicleId(vehicleid)
            return result;
        } catch (e) {
        }
    }
}