import { Router } from "express";
import { Core } from "../Core";
import { DriverMissionController } from "./controller/DriverMissionController";
import { Middleware } from "../Account/middleware";

export class Routes extends Core.BaseRoutes {
    private route: Router;
    private driverMissionController: DriverMissionController = new DriverMissionController();
    private middleware: Middleware = new Middleware();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;
        self.route.post("/v1/accept/:orderid", [self.middleware.Authorization()], self.driverMissionController.AcceptOrder());
        self.route.post("/v1/reject/:orderid", [self.middleware.Authorization()], self.driverMissionController.RejectOrder());
        self.route.post("/v1/cancel/:orderid", [self.middleware.Authorization()], self.driverMissionController.CancelOrder());
        self.route.post("/v1/start/:orderid", [self.middleware.Authorization()], self.driverMissionController.DriverOrderStart());
        self.route.post("/v1/pickup/:orderid", [self.middleware.Authorization()], self.driverMissionController.DriverOrderPickup());
        self.route.post("/v1/reached/:orderid", [self.middleware.Authorization()], self.driverMissionController.DriverOrderReached());
        self.route.post("/v1/complete/:orderid", [self.middleware.Authorization()], self.driverMissionController.DriverOrderComplete());
        self.route.post("/v1/notCompleted/:orderid", [self.middleware.Authorization()], self.driverMissionController.DriverOrderNotComplete());
        self.route.get("/v1/getOrderListDriver/:type", [self.middleware.Authorization()], self.driverMissionController.GetOrderListDriver());
        self.route.get("/v1/orderDriver/:id", [self.middleware.Authorization()], self.driverMissionController.GetSingleOrderDriver());
        self.route.post("/v1/driver/:driverid", [self.middleware.Authorization()], self.driverMissionController.DriverUpdateStatus());
        self.route.post("/v1/qrUpdate", [self.middleware.Authorization()], self.driverMissionController.ScanQr());
        self.route.get("/v1/getOrderListDriverCount", [self.middleware.Authorization()], self.driverMissionController.GetOrderListDriverCount());
        self.route.post("/v1/qrcodecheck/:shipmentid", [self.middleware.Authorization()], self.driverMissionController.QRCodeCheck()); 
        self.route.post("/v1/changevehicle/:driverid", [self.middleware.Authorization()], self.driverMissionController.ChangeVehicle()); 
        return self.route;
    }
}


