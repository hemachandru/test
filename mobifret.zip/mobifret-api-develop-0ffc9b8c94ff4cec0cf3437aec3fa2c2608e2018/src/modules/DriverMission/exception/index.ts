import { error } from "./DriverMissionException";
import { Core } from "../../Core";

export class Exception extends Core.BaseException {
    constructor() {
        super(error);
    }
}