import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';
import { QRBatch } from './QRBatch';

@Table({
    tableName: "tblQRBatchDetail"
})

export class QRBatchDetail extends Model<QRBatchDetail> {

    @AutoIncrement
    @PrimaryKey
    @Column
    qrBatchDetailId: number;

    @ForeignKey(() => QRBatch)
    @Column
    qrBatchId: number;

    @Column
    qrCode: string;

    @Column
    isAllocated: boolean;

    @BelongsTo(() => QRBatch)
    qrBatch: QRBatch;

}