import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblVehicleStatus",
})

export class VehicleStatus extends Model<VehicleStatus> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleStatusId: number

    @Column
    vehicleStatus: string
}