import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt, HasOne } from 'sequelize-typescript';
import { Registration } from '../../Account/models/Registration';
import { Region } from '../../General/models/Region';
import { Contact } from '../../Account/models/Contact';
import { Document } from '../../Account/models/Document';
import { User } from '../../Account/models/User';
import { Vehicle } from './Vehicle';

@Table({
    timestamps: true,
    tableName: "tblDrivers"
})

export class Driver extends Model<Driver> {

    @AutoIncrement
    @PrimaryKey
    @Column
    driverId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @ForeignKey(() => Contact)
    @Column
    contactId: number;

    @ForeignKey(() => Document)
    @Column
    documentId: number;

    @Column
    isActive: boolean;

    @Column
    isOn: boolean;

    @Column
    document: string;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @Column(DataType.FLOAT)
    lat: number;

    @Column(DataType.FLOAT)
    lan: number;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @DeletedAt
    deletedAt: Date;

    @Column
    driverDetailId: string;

    @BelongsTo(() => Registration)
    registration: Registration;

    @BelongsTo(() => Contact)
    contact: Contact;

    @BelongsTo(() => Region)
    region: Region;

    @BelongsTo(() => Document)
    documents: Document;

    @BelongsTo(() => User)
    user: User;

    @HasOne(() => Vehicle)
    vehicle: Vehicle;

}