import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblVehicleCategories",
})

export class VehicleCategory extends Model<VehicleCategory> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleCategoryId: number

    @Column
    vehicleCategory: string

    @Column
    isActive: boolean;
}