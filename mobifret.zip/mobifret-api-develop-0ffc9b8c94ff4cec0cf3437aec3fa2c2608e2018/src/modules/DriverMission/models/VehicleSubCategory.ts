import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo } from 'sequelize-typescript';
import { VehicleSpecialitieCategory } from './VehicleSpecialitieCategory';

@Table({
    tableName: "tblVehicleSubCategories",
})

export class VehicleSubCategory extends Model<VehicleSubCategory> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleSubCategoryId: number

    @Column
    vehicleSubCategory: string

    @ForeignKey(() => VehicleSpecialitieCategory)
    @Column
    vehicleSpecialitieCategoryId: number;

    @BelongsTo(() => VehicleSpecialitieCategory)
    vehicleSpecialitieCategory: VehicleSpecialitieCategory;

    @Column
    isActive: boolean;
}