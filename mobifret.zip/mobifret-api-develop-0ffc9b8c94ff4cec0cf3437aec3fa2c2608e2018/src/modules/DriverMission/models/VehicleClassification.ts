import { Table, Column, Model, AutoIncrement, PrimaryKey, DataType } from 'sequelize-typescript';

@Table({
    tableName: "tblVehicleClassifications",
})

export class VehicleClassification extends Model<VehicleClassification> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleClassificationId: number

    @Column
    vehicleClassification: string

    @Column(DataType.FLOAT)
    weight: number;

    @Column(DataType.FLOAT)
    breadth: number;

    @Column(DataType.FLOAT)
    length: number;

    @Column(DataType.FLOAT)
    height: number;

    @Column(DataType.FLOAT)
    volume: number;

    @Column(DataType.FLOAT)
    noOfPalette: number;

    @Column
    isActive: boolean;
}