import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblVehicleSpecialitieCategories",
})

export class VehicleSpecialitieCategory extends Model<VehicleSpecialitieCategory> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleSpecialitieCategoryId: number

    @Column
    vehicleSpecialitieCategory: string

    @Column
    isActive: boolean;
}