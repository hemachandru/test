import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';
import { QRBatchDetail } from './QRBatchDetail';
import { ShipmentDetail } from '../../Cart/models/ShipmentDetail';

@Table({
    tableName: "tblQRShipments"
})

export class QRShipment extends Model<QRShipment> {

    @AutoIncrement
    @PrimaryKey
    @Column
    qrShipmentId: number;

    @ForeignKey(() => QRBatchDetail)
    @Column
    qrBatchDetailId: number;

    @ForeignKey(() => ShipmentDetail)
    @Column
    shipmentId: number;

}