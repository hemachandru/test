import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType } from 'sequelize-typescript';
import { WeightType } from './WeightType';
import { VolumeType } from './VolumeType';
import { VehicleStatus } from './VehicleStatus';
import { VehicleCategory } from './VehicleCategory';
import { VehicleClassification } from './VehicleClassification';
import { VehicleType } from './VehicleType';
import { VehicleSpecialitieCategory } from './VehicleSpecialitieCategory';
import { VehicleSubCategory } from './VehicleSubCategory';
import { Driver } from './Driver';
import { Document } from '../../Account/models/Document';
import { User } from '../../Account/models/User';
import { Registration } from '../../Account/models/Registration';
import { QRBatchDetail } from './QRBatchDetail';
import { UpdatedAt } from 'sequelize-typescript/lib/annotations/UpdatedAt';

@Table({
    tableName: "tblVehicles"
})

export class Vehicle extends Model<Vehicle>{

    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleId: number;

    @Column
    vehicleName: string

    @Column
    manufactureYear: number

    @Column
    vehicleNumber: string

    @Column
    registrationDate: Date

    @Column
    runningKM: number

    @Column
    model: string

    @Column
    version: string

    @Column
    color: string

    @Column(DataType.DOUBLE(8, 2))
    weightCapacity: number;

    @ForeignKey(() => WeightType)
    @Column
    weightTypeId: number;

    @Column(DataType.FLOAT)
    volumeCapacity: number;

    @ForeignKey(() => VolumeType)
    @Column
    volumeTypeId: number;

    @ForeignKey(() => VehicleStatus)
    @Column
    vehicleStatusId: number;

    @ForeignKey(() => VehicleCategory)
    @Column
    vehicleCategoryId: number;

    @ForeignKey(() => VehicleClassification)
    @Column
    vehicleClassificationId: number;

    @ForeignKey(() => VehicleType)
    @Column
    vehicleTypeId: number;

    @ForeignKey(() => VehicleSpecialitieCategory)
    @Column
    vehicleSpecialitieCategoryId: number;

    @ForeignKey(() => VehicleSubCategory)
    @Column
    vehicleSubCategoryId: number;

    @Column
    hayon: boolean;

    @ForeignKey(() => Driver)
    @Column
    driverId: number;

    @ForeignKey(() => Document)
    @Column
    licenceDocumentId: number;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @Column
    vehicleDetailId: string

    @ForeignKey(() => QRBatchDetail)
    @Column
    qrBatchDetailId: number

    @BelongsTo(() => QRBatchDetail)
    qrBatchDetail: QRBatchDetail;

    @BelongsTo(() => Driver)
    driver: Driver;

    @BelongsTo(() => Registration)
    registration: Registration;

    @Column
    createdAt: Date;

    @Column
    updatedAt: Date;

    @Column
    deletedAt: Date;
}


















