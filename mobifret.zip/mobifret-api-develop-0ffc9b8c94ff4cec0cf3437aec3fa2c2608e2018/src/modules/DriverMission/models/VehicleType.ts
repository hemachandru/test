import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblVehicleTypes",
})

export class VehicleType extends Model<VehicleType> {
    @AutoIncrement
    @PrimaryKey
    @Column
    vehicleTypeId: number

    @Column
    vehicleType: string

    @Column
    isActive: boolean;
}