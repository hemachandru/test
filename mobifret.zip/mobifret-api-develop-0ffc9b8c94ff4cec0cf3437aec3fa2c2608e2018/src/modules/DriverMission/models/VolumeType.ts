import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblVolumeTypes",
})

export class VolumeType extends Model<VolumeType> {
    @AutoIncrement
    @PrimaryKey
    @Column
    volumeTypeId: number

    @Column
    volumeType: string
}