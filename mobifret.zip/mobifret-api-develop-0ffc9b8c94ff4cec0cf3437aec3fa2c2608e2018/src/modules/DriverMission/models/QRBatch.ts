import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';
import { User } from '../../Account/models/User';

@Table({
    tableName: "tblQRBatch"
})

export class QRBatch extends Model<QRBatch> {

    @AutoIncrement
    @PrimaryKey
    @Column
    qrBatchId: number;

    @Column
    totalQR: number;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @Column
    documentId: number;

    @Column
    printedAt: Date;

    @Column
    isAllocated: boolean;

    @Column
    isVechicle: boolean;

    @BelongsTo(() => User)
    user: User;

}