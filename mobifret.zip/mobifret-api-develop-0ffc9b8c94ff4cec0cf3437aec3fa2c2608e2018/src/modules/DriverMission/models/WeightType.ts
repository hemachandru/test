import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblWeightTypes",
})

export class WeightType extends Model<WeightType> {
    @AutoIncrement
    @PrimaryKey
    @Column
    weightTypeId: number

    @Column
    weightType: string
}