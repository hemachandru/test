import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';
import { Registration } from '../../Account/models/Registration';
import { Driver } from "./Driver";
import { Cart } from "../../Cart/models/Cart";
import { ShipmentDetail } from "../../Cart/models/ShipmentDetail";

@Table({
    timestamps: true,
    tableName: "tblRating"
})

export class Rating extends Model<Rating> {

    @AutoIncrement
    @PrimaryKey
    @Column
    ratingId: number;

    @ForeignKey(() => Driver)
    @Column
    driverId: number;

    @ForeignKey(() => Cart)
    @Column
    orderId: number;

    @ForeignKey(() => ShipmentDetail)
    @Column
    shipmentDetailId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @Column
    outOf: number;

    @Column
    rating: number;

    @Column
    comment: string;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;
   
}