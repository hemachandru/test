import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType } from 'sequelize-typescript';
import { Cart as Order } from '../../Cart/models/Cart';
import { Driver } from '../models/Driver';

@Table({
    tableName: "tblDriverMissions"
})

export class DriverMission extends Model<DriverMission> {

    @AutoIncrement
    @PrimaryKey
    @Column
    driverMissionId: number;

    @ForeignKey(() => Driver)
    @Column
    driverId: number;

    @ForeignKey(() => Order)
    @Column
    orderId: number;

    @Column(DataType.ENUM('send', 'accept', 'reject'))
    status: 'send' | 'accept' | 'reject';

    @BelongsTo(() => Driver)
    driver: Driver;

    @BelongsTo(() => Order)
    order: Order;

}