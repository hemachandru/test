import { Core } from "../../Core";
import { DriverMissionService } from '../service/DriverMissionService';
import { Transformation as AddressTransform } from '../../Cart/transformation';

export class Transformation extends Core.BaseTransformation {

    private driverMissionService: DriverMissionService = new DriverMissionService();

    constructor() {
        super();
    }

    async formatDriverOrderList(objOrder: any, params: any, count: any): Promise<any> {
        let orderArray = [];
        for (let singleOrder of objOrder) {
            let fromAddress = await new AddressTransform().getAddress(singleOrder.fromShipmentAddressId);
            let toAddress = await new AddressTransform().getAddress(singleOrder.toShipmentAddressId);
            let orderHistoryNode = {

            };
            singleOrder.orderHistory.forEach(element => {
                if (element.orderStatusId == singleOrder.orderStatusId) {
                    orderHistoryNode = {
                        status: singleOrder.orderstatus.orderStatus,
                        status_at: element.statusAt
                    }
                }
            });
            let orderNode = {
                id: singleOrder.orderId,
                created_at: singleOrder.createdAt,
                from_address: fromAddress,
                to_address: toAddress,
                driver_code: singleOrder.driverValidationCode,
                duration: singleOrder.duration,
                status: orderHistoryNode,
                shipment_mode: singleOrder.shipmentMode,
                plan_date_time: singleOrder.assignedAt ? singleOrder.assignedAt : null,
                net_cost: singleOrder.netCost,
            }
            orderArray.push(orderNode);
        }

        let resultObject = {
            count: count.length,
            offset: params.offset,
            limit: params.limit,
            items: orderArray
        }

        return resultObject;

    }

    async formatDriverSingleOrder(objOrder): Promise<any> {
        if (objOrder) {
            let fromAddress = await new AddressTransform().getAddress(objOrder.fromShipmentAddressId);
            let toAddress = await new AddressTransform().getAddress(objOrder.toShipmentAddressId);
            let orderHistoryNode = {

            };
            objOrder.orderHistory.forEach(element => {
                if (element.orderStatusId == objOrder.orderStatusId) {
                    orderHistoryNode = {
                        status: objOrder.orderstatus.orderStatus,
                        status_at: element.statusAt
                    }
                }
            });
            let shipmentArray = []
            objOrder.shipment.forEach(singleShipment => {
                let shipmentNode = {
                    id: singleShipment.shipmentDetailId,
                    freight_type: {
                        id: singleShipment.freightType.freightTypeId,
                        type: singleShipment.freightType.freightType
                    },
                    shipment_cost: singleShipment.shipmentCost,
                    insurance_cost: singleShipment.insuranceCost,
                    tax_cost: singleShipment.taxCost,
                    net_shipment_cost: singleShipment.netShipmentCost,
                    shipment_image: singleShipment.shipmentPhotoId ? process.env.AWS_CDN_URL + "/" + singleShipment.photo.document : null,
                    isstackable: singleShipment.isStackable,
                    isfilmeed: singleShipment.isFilmeed,
                    quantity: singleShipment.quantity,
                    weight: singleShipment.weight,
                    width: singleShipment.width,
                    breadth: singleShipment.breadth,
                    height: singleShipment.height,
                    comments: singleShipment.comments,
                    qrBatchDetailId: singleShipment.qrBatchDetailId != null ? singleShipment.qrBatchDetailId : 0,
                    shipment_status: {
                        id: singleShipment.shipmentStatus.shipmentStatusId,
                        status: singleShipment.shipmentStatus.shipmentStatus
                    },
                };
                shipmentArray.push(shipmentNode);
            });
            let orderNode = {
                id: objOrder.orderId,
                created_at: objOrder.createdAt,
                driver_code: objOrder.driverValidationCode,
                comments: objOrder.comments,
                from_address: fromAddress,
                to_address: toAddress,
                status: orderHistoryNode,
                shipment: shipmentArray,
                shipment_mode: objOrder.shipmentMode,
                plan_date_time: objOrder.assignedAt ? objOrder.assignedAt : null
            }
            return orderNode;
        }

        return objOrder;
    }


    async FormatOrderListDriverCount(data: any): Promise<any> {
        let result = data;
        let count = 0;
        let resultObj = {
            count: result.length,
        }
        return resultObj;
    }

}