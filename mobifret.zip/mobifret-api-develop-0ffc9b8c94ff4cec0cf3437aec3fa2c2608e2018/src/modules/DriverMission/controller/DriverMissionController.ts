import { Request, Response } from "express";
import { Core } from "../../Core";
import { DriverMissionBusiness } from "../business/DriverMissionBusiness";
import { DriverMissionService } from "../service/DriverMissionService";
import { OrderService } from "../../Order/service/OrderService";
import { CartService } from "../../Cart/service/CartService";
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";
import { OrderPlacing } from "../../../socket/OrderPlacing/index";
import { SnsLib } from "../../../helper/SnsLib";
import { MailLib } from "../../Account/mailer/mail";
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";
import { SMSRequestLib } from "../../../helper/OvhSmsLib";


export class DriverMissionController extends Core.BaseController {

    private driverMissionBusiness = new DriverMissionBusiness();
    private driverMissionService = new DriverMissionService();
    private orderService = new OrderService();
    private cartService = new CartService();
    private validate = new Validation();
    private sns = new SnsLib();
    private mailer = new MailLib();
    private SMS = new SMSRequestLib();

    GenerateRandomString(len) {
        var text = "";
        var charset = "0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }


    GetOrderListDriver() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let offset = req.query.offset ? req.query.offset : process.env.ORDER_OFFSET;
                let limit = req.query.limit ? req.query.limit : process.env.ORDER_LIMIT;
                let userData: any = req.headers['user'];
                let params;
                if (req.params.type == "inprogress") {
                    params = {
                        type: req.params.type,
                        offset: parseInt(offset),
                        limit: parseInt(limit),
                        status: req.query.status ? req.query.status : "all",
                        userid: userData.userID
                    }
                }
                if (req.params.type == "complete") {
                    params = {
                        type: req.params.type,
                        offset: parseInt(offset),
                        limit: parseInt(limit),
                        date: req.query.date ? req.query.date : "all",
                        userid: userData.userID
                    }
                }
                let result = await self.driverMissionBusiness.GetOrderListDriver(params);
                let resultCount;
                if (result) {
                    resultCount = await self.driverMissionBusiness.GetOrderListDriverStatusCount(params);
                }
                let resultData = await new Transformation().formatDriverOrderList(result, params, resultCount);
                return res.status(200).send(resultData);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetOrderListDriverCount() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers['user'];
                let result = await self.driverMissionBusiness.GetOrderListDriverCount(userData.userID);
                let resultData = await new Transformation().FormatOrderListDriverCount(result);
                return res.status(200).send(resultData);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }


    GetSingleOrderDriver() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.driverMissionBusiness.GetSingleOrderDriver(req.params.id);
                let resultData = await new Transformation().formatDriverSingleOrder(result);
                return res.status(200).send(resultData);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    AcceptOrder() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.driverMissionBusiness.CheckOrderOrDriver(orderId, req.body.driverId, null);
            if (!validate) {
                let result = await self.driverMissionBusiness.DriverAccept(orderId, req.body.driverId, req.body.registrationId);
                res.status(200).send();
                let driversOrder = await self.driverMissionBusiness.GetDriverMission(orderId, null);
                OrderPlacing.CompanyOrder.acceptOrder(driversOrder, orderId, req.body.driverId);
                let orderDetails: any = await self.orderService.GetSingleOrderDetails(orderId);
                if (orderDetails) {
                    let data = {
                        userId: orderDetails.userId,
                        driverName: orderDetails.driver.contact.firstName,
                        socketPayload: {
                            room: {
                                clientUserName: orderDetails.user.userName,
                                partnerUserName: orderDetails.driver.registration.companyContact.email,
                                adminUserName: process.env.ROOM_ADMIN
                            },
                            orderDetail: {
                                orderId: orderDetails.orderId,
                                driverId: orderDetails.driverId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_ACCEPT,
                                status_at: orderDetails.updatedAt,
                                isDriver: 0,
                                driver_mobileNumber: orderDetails.driver.contact.mobile ? orderDetails.driver.contact.mobile : null,
                                driver_code: orderDetails.driverValidationCode 
                            }
                        },
                        pushPayload: {
                            orderId: orderDetails.orderId,
                            driverId: orderDetails.driverId,
                            driverName: orderDetails.driver.contact.firstName,
                            type: process.env.PUSH_TYPE_ACCEPT,
                            status_at: orderDetails.updatedAt,
                            isDriver: 0,
                            driver_mobileNumber: orderDetails.driver.contact.mobile ? orderDetails.driver.contact.mobile : null,
                            driver_code: orderDetails.driverValidationCode
                        }

                    }
                    await self.sns.sendPush(null, data.userId, process.env.PUSH_TYPE_ACCEPT, null, data.pushPayload);
                    OrderPlacing.CompanyOrder.OrderSocket(data, process.env.GENERAL_ACCEPT_ORDER);

                }
                return;
            }
            return res.status(422).send([new Exception().ThrowException(validate)]);
        };
    }

    RejectOrder() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.driverMissionBusiness.CheckOrderOrDriver(orderId, req.body.driverId, null);

            if (["1063"].indexOf(validate) != -1) {
                return res.status(500).send([new Exception().ThrowException(validate)]);
            }

            await self.driverMissionBusiness.DriverReject(orderId, req.body.driverId);
            return res.status(200).send();
        };
    }

    CancelOrder() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let user: any = req.headers["user"]
            let validateOrder = await self.driverMissionBusiness.CheckOrderOrDriver(orderId, null, user.userId);
            if (!validateOrder || ["1061", "1062"].indexOf(validateOrder) != -1) {
                self.driverMissionBusiness.DriverCancel(orderId, req.body);

                let driversOrder = await self.driverMissionBusiness.GetDriverMission(orderId, validateOrder ? "accept" : null);
                OrderPlacing.CompanyOrder.cancelOrder(driversOrder, orderId);
                let orderDetails: any = await self.orderService.GetSingleOrderDetails(orderId);
                res.status(200).send();
                let deliveryCustomerInfo: any = await self.cartService.GetAddress(orderDetails.toShipmentAddressId);
                if (orderDetails) {
                    let data = {
                        userId: orderDetails.userId,
                        driverName: orderDetails.driver.contact.firstName,
                        socketPayload: {
                            room: {
                                clientUserName: orderDetails.user.userName,
                                partnerUserName: orderDetails.driver.registration.companyContact.email,
                                adminUserName: process.env.ROOM_ADMIN
                            },
                            orderDetail: {
                                orderId: orderDetails.orderId,
                                driverId: orderDetails.driverId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_CANCEL,
                                status_at: orderDetails.updatedAt,
                                reason: orderDetails.missionReasons ? orderDetails.missionReasons.reason : null,
                                comments: orderDetails.deliveryComments,
                                isDriver: 0
                            }
                        },
                        pushPayload: {
                            orderId: orderDetails.orderId,
                            driverId: orderDetails.driverId,
                            driverName: orderDetails.driver.contact.firstName,
                            type: process.env.PUSH_TYPE_CANCEL,
                            status_at: orderDetails.updatedAt,
                            reason: orderDetails.missionReasons ? orderDetails.missionReasons.reason : null,
                            comments: orderDetails.deliveryComments,
                            isDriver: 0
                        },
                        mailPayload: {
                            customerName: orderDetails.user.userName,
                            deliveryEmailId: deliveryCustomerInfo.email,
                            orderId: orderDetails.orderId,
                            driverName: orderDetails.driver.contact.firstName,
                            type: process.env.PUSH_TYPE_CANCEL,
                            subject: process.env.ORDER_CANCEL_SUBJECT
                        }
                    }
                    self.mailer.orderMailer(data.mailPayload);
                    await self.sns.sendPush(null, data.userId, process.env.PUSH_TYPE_CANCEL, data.driverName, data.pushPayload);
                    OrderPlacing.CompanyOrder.OrderSocket(data, process.env.GENERAL_CANCEL_ORDER);
                }

                return;
            }
            return res.status(422).send([new Exception().ThrowException()]);
        };
    }

    RateOrder() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let alreadyRated = await self.driverMissionBusiness.FindRateOrder(orderId);

            if (alreadyRated)
                return res.status(422).send([new Exception().ThrowException("1064")]);

            let rateOrder = await self.driverMissionBusiness.CheckOrderRating(orderId);

            if (rateOrder) {
                let inputData = {
                    orderId: orderId,
                    driverId: rateOrder.driverId,
                    registrationId: rateOrder.registrationId,
                    // outOf: process.env.RATE_MAX,
                    shipmentDetailId: null,
                    rating: req.body.rating,
                    comment: req.body.comment
                };

                let rateOrderResult = await self.driverMissionBusiness.RateOrder(inputData);

                return res.status(200).send();
            }

            return res.status(422).send([new Exception().ThrowException("1065")]);
        }
    }

    ScanQr() {
        let self = this;
        return async (req: Request, res: Response) => {
            let validate = await self.validate.CheckQRCode(req.body);
            if (!validate.status) {
                let qrCodeResult = await this.driverMissionBusiness.CheckQr(req.body.registrationid, req.body.qr_code);
                if (qrCodeResult.length) {
                    let shipmentId = req.body.shipment_id;
                    let qrCode = req.body.qr_code;
                    let result = await self.driverMissionBusiness.ScanQr(shipmentId, qrCodeResult[0]);
                    if (result)
                        return res.status(200).send({
                            "qrBatchDetailId": qrCodeResult[0].qrBatchDetailId
                        });
                }
                return res.status(422).send([new Exception().ThrowException("1067")]);
            } else {
                return res.status(422).send(validate.error);
            }

        };
    }


    DriverUpdateStatus() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.validate.CheckDriver(req.params.driverid, req.body);
            if (!validate.status) {
                self.driverMissionBusiness.DriverUpdateStatus(req.params.driverid, req.body.isjobStatus);
                return res.status(200).send();
            } else {
                return res.status(422).send(validate.error);
            }

        };
    }

    DriverOrderStart() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.driverMissionBusiness.CheckOrderStatusDriver(orderId, req.body.driverId, req.body.registrationId);
            if (validate) {
                self.driverMissionBusiness.DriverStart(orderId, req.body.driverId, req.body.registrationId);
                return res.status(200).send();
            } else {
                return res.status(422).send([new Exception().ThrowException("1083")]);
            }

        };
    }

    DriverOrderPickup() {
        let self = this;
        return async (req: Request, res: Response) => {
            let checkDriverVehicle = await self.driverMissionBusiness.CheckDriverVehicleID(req.body.driverId);
            if (checkDriverVehicle) {
                let orderId = req.params.orderid;
                console.log(req.body);
                let validate = await self.driverMissionBusiness.CheckOrderDriverPickupCode(orderId, req.body.driverId, req.body.registrationId, req.body.validationCode);
                if (validate) {
                    let result = self.driverMissionBusiness.DriverPickup(orderId, req.body.driverId, req.body.registrationId);
                    let OTPPIN;
                    if (result) {
                        OTPPIN = this.GenerateRandomString(4);
                        //OTPPIN = 1234;
                        let result = self.driverMissionBusiness.DriverPickupValidationCode(orderId, OTPPIN);
                    }
                    res.status(200).send();
                    let orderDetails: any = await self.orderService.GetSingleOrderDetails(orderId);
                    let deliveryCustomerInfo: any = await self.cartService.GetAddress(orderDetails.toShipmentAddressId);
                    let orderSMS = {
                        message: 'Mobifret Testing: Dear Customer, Your OTP pin is :' + OTPPIN + ' with ORDER ID' + " " + + orderDetails.orderId + "." +'Please use this pin to receive your order.',
                        deliveryCustomerNum: deliveryCustomerInfo.telephone.toString()

                    }
                    console.log(orderSMS);
                    if (orderDetails) {
                        let data = {
                            userId: orderDetails.userId,
                            driverName: orderDetails.driver.contact.firstName,
                            socketPayload: {
                                room: {
                                    clientUserName: orderDetails.user.userName,
                                    partnerUserName: orderDetails.driver.registration.companyContact.email,
                                    adminUserName: process.env.ROOM_ADMIN
                                },
                                orderDetail: {
                                    orderId: orderDetails.orderId,
                                    driverId: orderDetails.driverId,
                                    driverName: orderDetails.driver.contact.firstName,
                                    type: process.env.PUSH_TYPE_PICKUP,
                                    status_at: orderDetails.updatedAt,
                                    isDriver: 0
                                }

                            },
                            pushPayload: {
                                orderId: orderDetails.orderId,
                                driverId: orderDetails.driverId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_PICKUP,
                                status_at: orderDetails.updatedAt,
                                isDriver: 0
                            },
                            mailPayload: {
                                customerName: orderDetails.user.userName,
                                deliveryEmailId: deliveryCustomerInfo.email,
                                orderId: orderDetails.orderId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_PICKUP,
                                subject: process.env.ORDER_PICKUP_SUBJECT
                            }
                        }
                        await self.mailer.orderMailer(data.mailPayload);
                        await self.sns.sendPush(null, data.userId, process.env.PUSH_TYPE_PICKUP, data.driverName, data.pushPayload);
                        OrderPlacing.CompanyOrder.OrderSocket(data, process.env.GENERAL_PICKUP_ORDER);
                        self.SMS.SmsRequest(orderSMS);
                        return;
                    } else {
                        return res.status(422).send([new Exception().ThrowException("1084")]);
                    }

                } else {
                    return res.status(422).send([new Exception().ThrowException("1092")]);
                }
            }

        };
    }

    DriverOrderReached() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.driverMissionBusiness.CheckOrderStatusDriver(orderId, req.body.driverId, req.body.registrationId);
            if (validate) {
                self.driverMissionBusiness.DriverReached(orderId, req.body.driverId, req.body.registrationId);
                return res.status(200).send();
            } else {
                return res.status(422).send([new Exception().ThrowException("1083")]);
            }
        };
    }

    DriverOrderComplete() {
        let self = this;
        return async (req: Request, res: Response) => {
            let checkDriverVehicle = await self.driverMissionBusiness.CheckDriverVehicleID(req.body.driverId);
            if (checkDriverVehicle) {
                let orderId = req.params.orderid;
                let validate = await self.driverMissionBusiness.CheckOrderDriverDeliveryCode(orderId, req.body.driverId, req.body.registrationId, req.body.validationCode);
                if (validate) {
                    self.driverMissionBusiness.DriverComplete(orderId, req.body.driverId, req.body.registrationId);
                    res.status(200).send();
                    let orderDetails: any = await self.orderService.GetSingleOrderDetails(orderId);
                    let deliveryCustomerInfo: any = await self.cartService.GetAddress(orderDetails.fromShipmentAddressId);
                    if (orderDetails) {
                        let data = {
                            userId: orderDetails.userId,
                            driverName: orderDetails.driver.contact.firstName,
                            socketPayload: {
                                room: {
                                    clientUserName: orderDetails.user.userName,
                                    partnerUserName: orderDetails.driver.registration.companyContact.email,
                                    adminUserName: process.env.ROOM_ADMIN
                                },
                                orderDetail: {
                                    orderId: orderDetails.orderId,
                                    driverId: orderDetails.driverId,
                                    driverName: orderDetails.driver.contact.firstName,
                                    type: process.env.PUSH_TYPE_COMPLETE,
                                    status_at: orderDetails.updatedAt,
                                    isDriver: 0
                                }
                            },
                            pushPayload: {
                                orderId: orderDetails.orderId,
                                driverId: orderDetails.driverId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_COMPLETE,
                                status_at: orderDetails.updatedAt,
                                isDriver: 0
                            },
                            mailPayload: {
                                customerName: orderDetails.user.userName,
                                deliveryEmailId: deliveryCustomerInfo.email,
                                orderId: orderDetails.orderId,
                                driverName: orderDetails.driver.contact.firstName,
                                type: process.env.PUSH_TYPE_COMPLETE,
                                subject: process.env.ORDER_COMPLETE_SUBJECT
                            }
                        }
                        await self.mailer.orderMailer(data.mailPayload);
                        await self.sns.sendPush(null, data.userId, process.env.PUSH_TYPE_COMPLETE, null, data.pushPayload);
                        OrderPlacing.CompanyOrder.OrderSocket(data, process.env.GENERAL_COMPLETE_ORDER);
                    }
                    return;
                } else {
                    return res.status(422).send([new Exception().ThrowException("1085")]);
                }
            } else {
                return res.status(422).send([new Exception().ThrowException("1092")]);
            }

        };
    }

    DriverOrderNotComplete() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let validate = await self.driverMissionBusiness.CheckOrderStatusDriver(orderId, req.body.driverId, req.body.registrationId);
            if (validate) {
                self.driverMissionBusiness.DriverNotComplete(orderId, req.body.driverId, req.body.registrationId);
                return res.status(200).send();
            } else {
                return res.status(422).send([new Exception().ThrowException("1083")]);
            }

        };
    }

    ClientOrderCancelled() {
        let self = this;
        return async (req: Request, res: Response) => {
            let orderId = req.params.orderid;
            let user: any = req.headers["user"]
            let validate = await self.driverMissionBusiness.CheckOrderClient(orderId, user.userID);
            let checkOrderStatus;
            if (validate) {
                checkOrderStatus = await self.driverMissionBusiness.CheckOrderStatusClient(orderId);
                if (checkOrderStatus) {
                    self.driverMissionBusiness.ClientOrderCancelled(orderId, user.userID, req.body.comments);
                    /*******/
                    let driversOrder = await self.driverMissionBusiness.GetDriverMission(orderId, null);
                    OrderPlacing.CompanyOrder.cancelByClient(driversOrder, orderId);
                    /*******/
                    res.status(200).send();
                    if (!(checkOrderStatus.orderStatusId === OrderStatusEnum.New)) {
                        let orderDetails: any = await self.orderService.GetSingleOrderDetails(orderId);
                        let deliveryCustomerInfo: any = await self.cartService.GetAddress(orderDetails.toShipmentAddressId);
                        if (orderDetails) {
                            let data = {
                                userId: orderDetails.userId,
                                driverid: orderDetails.driver.userId,
                                socketPayload: {
                                    room: {
                                        driverName: orderDetails.driver.contact.email + ":" + orderDetails.driver.driverId + ":" + orderDetails.driver.registrationId,
                                        partnerUserName: orderDetails.driver.registration.companyContact.email,
                                        adminUserName: process.env.ROOM_ADMIN
                                    },
                                    orderDetail: {
                                        orderId: orderDetails.orderId,
                                        driverId: orderDetails.driverId,
                                        driverName: orderDetails.driver.contact.firstName,
                                        type: process.env.PUSH_TYPE_CANCEL,
                                        status_at: orderDetails.updatedAt,
                                        comments: req.body.comments,
                                        isDriver: 1
                                    }
                                },
                                pushPayload: {
                                    orderId: orderDetails.orderId,
                                    userId: orderDetails.userId,
                                    type: process.env.PUSH_TYPE_CANCEL,
                                    status_at: orderDetails.updatedAt,
                                    comments: req.body.comments,
                                    isDriver: 1
                                },
                                mailPayload: {
                                    customerName: orderDetails.user.userName,
                                    deliveryEmailId: deliveryCustomerInfo.email,
                                    orderId: orderDetails.orderId,
                                    driverName: orderDetails.driver.contact.firstName,
                                    type: process.env.PUSH_TYPE_CANCEL,
                                    subject: process.env.ORDER_CANCEL_SUBJECT
                                }
                            }
                            self.mailer.orderMailer(data.mailPayload);
                            await self.sns.sendPush(null, data.driverid, process.env.PUSH_TYPE_CANCEL, null, data.pushPayload);
                            OrderPlacing.CompanyOrder.OrderSocket(data, process.env.GENERAL_CANCEL_ORDER);
                        }
                    }
                    return;
                } else {
                    return res.status(422).send([new Exception().ThrowException("1093")]);
                }

            } else {
                return res.status(422).send([new Exception().ThrowException("1083")]);
            }

        };
    }

    QRCodeCheck() {
        let self = this;
        return async (req: Request, res: Response) => {
            let shipmentID = req.params.shipmentid;
            let validate = await self.driverMissionBusiness.CheckQRCode(shipmentID, req.body.qr_code);
            if (validate)
                return res.status(200).send();
            else
                return res.status(422).send([new Exception().ThrowException("1086")]);
        };
    }

    ChangeVehicle() {
        let self = this;
        return async (req: Request, res: Response) => {
            let driverId = req.params.driverid;
            let validate = await self.driverMissionBusiness.CheckDriverVehicle(driverId, req.body.qr_code);
            if (validate)
                return res.status(200).send();
            else
                return res.status(422).send([new Exception().ThrowException("1091")]);
        };
    }

}