import { Request, Response } from "express";
import { Sequelize } from 'sequelize-typescript';
import { Core } from "../../Core";
import { Document } from '../../Account/models/Document';
import { Cart as Order } from '../../Cart/models/Cart';
import { OrderStatus } from '../../Cart/models/OrderStatus';
import { OrderStatusHistory } from '../../Cart/models/OrderStatusHistory';
import { ShipmentDetail } from '../../Cart/models/ShipmentDetail';
import { ShipmentHistory } from '../../Cart/models/ShipmentHistory';
import { ShipmentStatus } from '../../Cart/models/ShipmentStatus';
import { ShipmentAddress } from '../../Cart/models/ShipmentAddress';
import { Vehicle } from '../models/Vehicle';
import { Driver } from '../models/Driver';
import { Rating } from '../models/Rating';
import { Registration } from '../../Account/models/Registration';
import { User } from '../../Account/models/User';
import { SequelizeLib } from '../../../helper';
import { FreightType } from '../../General/models/FreightType';
import { DriverMission } from '../models/DriverMission';
import { QRShipment } from '../models/QRShipment';
import { QRBatchDetail } from '../models/QRBatchDetail';
import * as moment from "moment";
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";
import { Contact } from "../../Account/models/Contact";
import { Boolean } from "aws-sdk/clients/ssm";

export class DriverMissionService extends Core.BaseService {
    private sequelize: Sequelize;
    private sequelizeLib: SequelizeLib;

    async CheckOrderOrDriver(orderID: any, driverID: any, userId: any): Promise<string> {
        let option = {
            orderId: orderID
        };
        if (userId) {
            option["userId"] = userId;
        }
        let orderResult = await Order.find<Order>({
            where: option,
        });

        if (!orderResult)
            return "1063";
        else if (orderResult && orderResult.driverId && orderResult.driverId === driverID)
            return "1061";
        else if (orderResult && orderResult.driverId)
            return "1062";

        return null;
    }


    async CheckOrderStatusDriver(orderID: any, driverID: any, registrationID: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                driverId: driverID,
                registrationId: registrationID
            };
            let orderResult = await Order.find<Order>({
                where: option,
            });
            return orderResult;
        } catch (e) {
            return e;
        }
    }


    async CheckOrderClient(orderID: any, userid: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                userId: userid,
            };
            let orderResult = await Order.find<Order>({
                where: option,
            });
            return orderResult;
        } catch (e) {
            return e;
        }
    }

    async CheckOrderStatusClient(orderID: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                orderStatusId: [OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.New, OrderStatusEnum.Pickup]
            };
            let orderResult = await Order.find<Order>({
                where: option,
            });
            return orderResult;
        } catch (e) {
            return e;
        }
    }


    async CheckOrderDriverPickupCode(orderID: any, driverID: any, registrationID: any, pickupCode: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                driverId: driverID,
                registrationId: registrationID,
                driverValidationCode: pickupCode

            };
            let orderResult = await Order.find<Order>({
                where: option,
            });
            return orderResult;
        } catch (e) {
            return e;
        }
    }


    async CheckOrderDriverDeliveryCode(orderID: any, driverID: any, registrationID: any, deliveryCode: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                driverId: driverID,
                registrationId: registrationID,
                deliveryValidationCode: deliveryCode

            };
            let orderResult = await Order.find<Order>({
                where: option,
            });
            return orderResult;
        } catch (e) {
            return e;
        }
    }

    async DriverAcceptOrCancel(orderID: any, driverID: any, registrationID: any, status: any, reasonData: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();

        try {

            let orderResult = await Order.find<Order>({
                where: { orderId: orderID },
                include: [ShipmentDetail]
            });

            let getDriverVehicleID = await Vehicle.find<Vehicle>({
                where: {
                    driverId: driverID,
                    deletedAt: {
                        $eq: null
                    }
                }
            });

            let orderHistoryNode = {
                orderId: orderResult.orderId,
                orderStatusId: status
            }
            let shipmentID = [];
            let shipmentHistoryObj = [];

            orderResult.shipment.forEach(singleShipment => {
                shipmentID.push(singleShipment.shipmentDetailId);
                let shipmentHistoryNode = {
                    orderId: orderID,
                    shipmentDetailId: singleShipment.shipmentDetailId,
                    shipmentStatusId: status
                };
                shipmentHistoryObj.push(shipmentHistoryNode);
            });

            let orderOption = {
                orderStatusId: status
            }

            if (status == OrderStatusEnum.Completed)
                orderOption['completedAt'] = new Date();

            if (driverID && registrationID) {
                orderOption["driverId"] = driverID
                orderOption["registrationId"] = registrationID
            }
            if (reasonData) {
                orderOption["reasonId"] = reasonData.reasonid,
                    orderOption["deliveryComments"] = reasonData.comments ? reasonData.comments : null

            }


            if (getDriverVehicleID) {
                orderOption["vehicleId"] = getDriverVehicleID.vehicleId
            }

            let updateOrderResult = await Order.update<Order>(orderOption,
                {
                    where: {
                        orderId: orderID
                    }, transaction: t
                });

            let orderHistoryResult = await OrderStatusHistory.create(orderHistoryNode, { transaction: t });

            let updateShipmentResult = await ShipmentDetail.update<ShipmentDetail>({
                shipmentStatusId: status
            },
                {
                    where: {
                        shipmentDetailId: shipmentID
                    }, transaction: t
                });

            let shipmentHistoryResult = await ShipmentHistory.bulkCreate(shipmentHistoryObj, { transaction: t });

            if (driverID) {
                let updateDriverMissionResult = await DriverMission.update<DriverMission>({
                    status: 'accept'
                }, {
                        where: {
                            orderId: orderID,
                            driverId: driverID
                        }, transaction: t
                    });
            }

            let transactionCommit = await t.commit();
            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }

    }


    async ClientOrderCancelled(orderID: any, userid: any, status: any, reason: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();

        try {

            let orderResult = await Order.find<Order>({
                where: { orderId: orderID },
                include: [ShipmentDetail]
            });

            let orderHistoryNode = {
                orderId: orderResult.orderId,
                orderStatusId: status
            }
            let shipmentID = [];
            let shipmentHistoryObj = [];

            orderResult.shipment.forEach(singleShipment => {
                shipmentID.push(singleShipment.shipmentDetailId);
                let shipmentHistoryNode = {
                    orderId: orderID,
                    shipmentDetailId: singleShipment.shipmentDetailId,
                    shipmentStatusId: status
                };
                shipmentHistoryObj.push(shipmentHistoryNode);
            });

            let orderOption = {
                orderStatusId: status
            }
            if (reason) {
                orderOption["deliveryComments"] = reason ? reason : null
            }

            let updateOrderResult = await Order.update<Order>(orderOption,
                {
                    where: {
                        orderId: orderID
                    }, transaction: t
                });

            let orderHistoryResult = await OrderStatusHistory.create(orderHistoryNode, { transaction: t });

            let updateShipmentResult = await ShipmentDetail.update<ShipmentDetail>({
                shipmentStatusId: status
            },
                {
                    where: {
                        shipmentDetailId: shipmentID
                    }, transaction: t
                });

            let shipmentHistoryResult = await ShipmentHistory.bulkCreate(shipmentHistoryObj, { transaction: t });

            let transactionCommit = await t.commit();
            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }

    }

    async DriverReject(orderID: any, driverID: any): Promise<Boolean> {
        try {
            let updateDriverMissionResult = await DriverMission.update<DriverMission>({
                status: 'reject'
            }, {
                    where: {
                        orderId: orderID,
                        driverId: driverID
                    }
                });
            return true;
        } catch (e) {
            console.log(e);
            return false;
        }
    }


    async DriverMissionCreate(orderID: any, driverID: any): Promise<any> {
        let driverMissionCreatResult = [];
        try {
            console.log('299 DriverMissionCreate');
            console.log(driverID);
            let driverMissionArray = [];
            if(driverID != null){
                driverID.forEach(element => {
                    let driverMissionNode = {
                        driverId: element,
                        orderId: orderID,
                        status: 'send'
                    }
                    driverMissionArray.push(driverMissionNode);
                });
            
                driverMissionCreatResult = await DriverMission.bulkCreate(driverMissionArray);
            }
            return driverMissionCreatResult;
        } catch (e) {
            console.log(e);
            console.log('HEREEEEEE');
            return driverMissionCreatResult;
           // return false;
        }
    }

    async GetDriverMission(orderID: any, status: any): Promise<any> {
        try {
            let options = { orderId: orderID };
            if (status) {
                options["status"] = status;
            }
            let drivers = await DriverMission.findAll<DriverMission>({
                where: options,
                include: [{
                    model: Driver,
                    include: [User]
                }]
            });
            if (drivers) {
                return drivers;
            }
            return null
        } catch (e) {
            console.log(e);
            return e;
        }
    }

    async GetDriver(userID: any): Promise<Driver> {
        let result = await Driver.find<Driver>({
            where: { userId: userID }
        });
        return result;
    }

    async GetOrderListDriver(params: any): Promise<any> {
        let result = null;
        let driverDetail = await this.GetDriver(params.userid);
        let driverID = driverDetail.driverId;
        if (params.type == "complete") {
            if (params.date != "all") {
                let dayStart = moment(params.date).startOf('day');
                let dayEnd = moment(params.date).endOf('day');
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        //orderStatusId: OrderStatusEnum.Completed,
                        orderStatusId: [OrderStatusEnum.Completed, OrderStatusEnum.Cancelled],
                        completedAt: {
                            $gte: dayStart,
                            $lte: dayEnd
                        }
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        //orderStatusId: OrderStatusEnum.Completed,
                        orderStatusId: [OrderStatusEnum.Completed, OrderStatusEnum.Cancelled],
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            }
        } else if (params.type == "inprogress") {
            if (params.status == "accept") {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Accepted]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else if (params.status == "assign") {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Assigned]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else if (params.status == "started") {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Started]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else if (params.status == "reached") {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Reached]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else if (params.status == "pickup") {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Pickup]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            } else {
                result = await Order.findAll<Order>({
                    offset: params.offset,
                    limit: params.limit,
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                    },
                    include: [OrderStatusHistory, OrderStatus],
                    order: [['orderId', 'DESC']]
                });
            }
        } else {
            let temp = [];
            result = temp;
        }
        return result;
    }


    async GetOrderListDriverCount(userid: any): Promise<any> {
        try {
            let result = null;
            let driverDetail = await this.GetDriver(userid);
            let driverID = driverDetail.driverId;
            result = await Order.findAll<Order>({
                where: {
                    driverId: driverID,
                    orderStatusId: [OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                },
                include: [OrderStatusHistory, OrderStatus]
            });
            return result;

        } catch (e) {
            return e;
        }
    }

    async GetOrderListDriverStatusCount(params: any): Promise<any> {
        let result = null;
        let driverDetail = await this.GetDriver(params.userid);
        let driverID = driverDetail.driverId;
        if (params.type == "complete") {
            if (params.date != "all") {
                let dayStart = moment(params.date).startOf('day');
                let dayEnd = moment(params.date).endOf('day');
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: OrderStatusEnum.Completed,
                        completedAt: {
                            $gte: dayStart,
                            $lte: dayEnd
                        }
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: OrderStatusEnum.Completed,

                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            }
        } else if (params.type == "inprogress") {
            if (params.status == "accept") {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Accepted]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else if (params.status == "assign") {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Assigned]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else if (params.status == "started") {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Started]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else if (params.status == "reached") {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Reached]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else if (params.status == "pickup") {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Pickup]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            } else {
                result = await Order.findAll<Order>({
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                    },
                    include: [OrderStatusHistory, OrderStatus]
                });
            }
        } else {
            let temp = [];
            result = temp;
        }
        return result;
    }

    async RateOrder(params: any): Promise<any> {
        try {
            let ratingResult = await Rating.create(params);
            return ratingResult;
        } catch (e) {
            return e;
        }
    }

    async CheckOrderRating(orderID: any): Promise<any> {
        try {
            let option = {
                orderId: orderID,
                orderStatusId: OrderStatusEnum.Completed
            };

            let orderResult = await Order.find<Order>({
                where: option,
            });

            return orderResult;

            // if (orderResult)
            //     return true;

            // return false;
        } catch (e) {
            return e;
        }
    }

    async GetSingleOrderDriver(orderID: any): Promise<Order> {
        try {

            let result = await Order.find<Order>({
                where: { orderId: orderID },
                include: [{
                    model: ShipmentDetail,
                    include: [ShipmentStatus, FreightType, Document]
                }, OrderStatusHistory, OrderStatus]
            });
            return result;
        } catch (e) {
            return e;
        }

    }

    async ScanQr(shipmentID: any, qrCodeDetail: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();

        try {
            let arShipmentNode = {
                qrBatchDetailId: qrCodeDetail.qrBatchDetailId,
                shipmentId: shipmentID
            }
            //let qrShipmentResult = await QRShipment.create(arShipmentNode, { transaction: t });
            let updateShipmentDetailQrBatchResult = await ShipmentDetail.update<ShipmentDetail>({
                qrBatchDetailId: qrCodeDetail.qrBatchDetailId
            },
                {
                    where: {
                        shipmentDetailId: arShipmentNode.shipmentId
                    }, transaction: t
                });

            let updateQrBatchResult = await QRBatchDetail.update<QRBatchDetail>({
                isAllocated: 1
            },
                {
                    where: {
                        qrBatchDetailId: qrCodeDetail.qrBatchDetailId
                    }, transaction: t
                });
            let transactionCommit = await t.commit();
            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }

    }

    async FindRatingOrder(orderID: any): Promise<Boolean> {
        try {
            let option = {
                orderId: orderID,
            }

            let ratingResult = await Rating.find<Rating>({
                where: option
            });
            if (ratingResult)
                return true;

            return false
        } catch (e) {
            return e;
        }
    }

    // async CheckQr(qrCode: any): Promise<QRBatchDetail> {
    //     let result = await QRBatchDetail.find<QRBatchDetail>({
    //         where: {
    //             qrCode: qrCode,
    //             isAllocated: 0
    //         }
    //     });
    //     return result;
    // }


    //Get user game by id and get feedbacks
    // async CheckQr(registrationid: number, qrcode: string): Promise<any> {
    //     this.sequelizeLib = SequelizeLib.getInstance();
    //     this.sequelize = this.sequelizeLib.getSequelize();
    //     try {
    //         let queryString = "select qrBatchDetailId from "
    //             + " tblQRBatchDetail QD "
    //             + " inner join tblQRRequest QR on QR.qrBatchId= QD.qrBatchId "
    //             + " WHERE QR.deletedAt is null AND"
    //             + " case when QD.isAllocated is null then 0 else QD.isAllocated end = 0 AND "
    //             + " QR.registrationId = " + registrationid + " AND  QD.qrCode = '" + qrcode + "' "
    //         let result = await this.sequelize.query(queryString);
    //         return result[0];
    //     } catch (e) {
    //         return e
    //     }
    // }

    async CheckQr(registrationid: number, qrcode: string): Promise<any> {
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        try {
            let queryString = "select qrBatchDetailId from "
                + " tblQRBatchDetail QD "
                + " inner join tblQRRequest QR on QR.qrBatchId= QD.qrBatchId "
                + " WHERE QR.deletedAt is null AND"
                + " QD.isAllocated = 1 AND"
                + " QR.registrationId = " + registrationid + " AND  QD.qrCode = '" + qrcode + "' "
            let result = await this.sequelize.query(queryString);
            return result[0];
        } catch (e) {
            return e
        }
    }


    async DriverUpdateStatus(driverid: number, isjobStatus: any): Promise<any> {
        try {
            let updateDriverMissionResult = await Driver.update<Driver>({
                isOn: isjobStatus
            }, {
                    where: {
                        driverId: driverid
                    }
                });
            return true;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async CheckQRCode(shipmentID: any, qrcode: any): Promise<Boolean> {
        try {
            let option = {
                shipmentDetailId: shipmentID,
            };

            let orderResult = await ShipmentDetail.find<Order>({
                include: [{
                    model: QRBatchDetail,
                    where: {
                        qrCode: qrcode
                    }
                }],
                where: option,
            });

            if (orderResult)
                return true;

            return false;
        } catch (e) {
            return e;
        }
    }

    async CheckDriverVehicle(qrcode: any): Promise<any> {
        try {
            let driverVehicleResult = await Vehicle.find<Vehicle>({
                include: [{
                    model: QRBatchDetail,
                    where: {
                        qrCode: qrcode
                    }
                }],
            });
            return driverVehicleResult;
        } catch (e) {
            return e;
        }
    }

    // async CheckCompanyDriverVehicle(vehicleId: any, driverid: any, registerid: any): Promise<any> {
    //     try {
    //         // let option = {
    //         //     registrationId: registerid
    //         // };
    //         let companyDriverVehicleResult = await Vehicle.findAll<Vehicle>({
    //             include: [{
    //                 model: Registration,
    //                 include: [
    //                     {
    //                         model: Driver,
    //                         where: {
    //                             driverId: driverid,
    //                             registrationId: registerid,
    //                         }
    //                     }
    //                 ]

    //             }],
    //             where: {
    //                 vehicleId: vehicleId,
    //                 //registrationId: registerid,
    //                 // driverId: driverid

    //             }
    //         });

    //         if (companyDriverVehicleResult)
    //             return true;

    //         return false;
    //     } catch (e) {
    //         return e;
    //     }
    // }

    async CheckCompanyDriverVehicle(vehicleId: any, driverid: any): Promise<any> {
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        try {
            let queryString = "select `Vehicle`.`vehicleId`, `Vehicle`.`driverId`,`Vehicle`.`registrationId`, "
                + " `driver`.`driverId` AS `driver.driverId`,`driver`.`registrationId` AS `driver.registrationId` FROM "
                + "  `tblVehicles` AS `Vehicle` inner join "
                + " `tblDrivers` AS `driver` ON `Vehicle`.`registrationId` = `driver`.`registrationId` "
                + " WHERE `Vehicle`.`vehicleId` = " + vehicleId + " AND  `driver`.`driverId` = '" + driverid + "' "
            let result = await this.sequelize.query(queryString);
            return result[0];
        } catch (e) {
            return e
        }
    }


    async updateDriverIdVehicle(vehicleID: any, driverID: any): Promise<Boolean> {
        try {
            let updateDriverMissionResult = await Vehicle.update<Vehicle>({
                driverId: driverID
            }, {
                    where: {
                        vehicleId: vehicleID,
                    }
                });
            return true;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetOrderDriverId(orderId: any): Promise<any> {
        try {

            let option = {
                orderId: orderId
            }
            let result = await Order.find<Order>({
                attributes: ['orderId', 'driverId'],
                include: [{
                    model: Driver,
                    //attributes: ['driverId', 'registrationId', 'contactId']
                    include: [{
                        model: Contact,
                    }]
                }],
                where: option
            });
            return result;
        } catch (e) {
            return e;
        }
    }


    async CheckOrderDriverID(orderID: any, driverID: any): Promise<Boolean> {
        try {
            let option = {
                orderId: orderID,
                driverId: driverID,
            }

            let result = await Order.find<Order>({
                where: option
            });
            if (result)
                return true;

            return false
        } catch (e) {
            return e;
        }
    }


    async GetDriverInfo(driverid: any): Promise<any> {
        try {
            let result = await Driver.find<Driver>({
                include: [{
                    model: User,
                    //attributes: ['userId', 'registrationId'],
                }],
                where: {
                    driverId: driverid
                }
            });
            return result;
        } catch (e) {
            return e;
        }
    }

    async GetDriverBlockedORNot(driverid: any): Promise<Boolean> {
        try {
            let result = await Driver.find<Driver>({
                where: {
                    driverId: driverid,
                    isActive: {
                        $eq: 0
                    }
                }
            });
            return true;
        } catch (e) {
            return e;
        }
    }


    async updateVehicleInOrder(vehicleID: any, driverID: any): Promise<any> {
        try {
            let updateVehicleOrderResult = await Order.update<Vehicle>({
                vehicleId: vehicleID,
            }, {
                    where: {
                        driverId: driverID,
                        orderStatusId: [OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                    }
                });
            return updateVehicleOrderResult;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetDriverVehicleId(driverid: any): Promise<any> {
        try {
            let result = await Vehicle.find<Vehicle>({
                where: {
                    driverId: driverid,
                    deletedAt: {
                        $eq: null
                    }
                }
            });
            return result;
        } catch (e) {
            return e;
        }
    }

    async DeleteDriverVehicle(driverid: any, vehicleid: any): Promise<Boolean> {
        try {
            let result = await Vehicle.update<Vehicle>({ "driverId": null }, {
                where: {
                    vehicleId: vehicleid
                }
            });

            let driverOffJob = await Driver.update<Driver>({ "isOn": 0 }, {
                where: {
                    driverId: driverid
                }
            });
            return true;
        } catch (e) {
            return false;
            // console.error(e);
            // return e;
        }
    }

    async GetCompanyDriverIDs(registerid: any): Promise<any> {
        try {
            let result = await Driver.findAll<Driver>({
                include: [{
                    model: User,
                    attributes: ['userId', 'registrationId', 'userName'],
                }],
                where: {
                    registrationId: registerid
                }
            });
            return result;
        } catch (e) {
            return e;
        }
    }


    async DriverVehicleOffJob(driverid: any): Promise<Boolean> {
        try {
            let driverOffJob = await Driver.update<Driver>({ "isOn": 0 }, {
                where: {
                    driverId: driverid
                }
            });
            return true;
        } catch (e) {
            return false;
            // console.error(e);
            // return e;
        }
    }

    async CheckDriverVehicleID(driverid: any): Promise<any> {
        try {
            let result = await Vehicle.findAll<Vehicle>({
                where: {
                    driverId: driverid,
                    deletedAt: {
                        $eq: null
                    }
                }
            });
            return result;
        } catch (e) {
            console.error(e);
            return e;
        }
    }

    async DriverPickupValidationCode(orderid: any, otppin: any): Promise<any> {
        try {
            let result = await Order.update<Order>({ "deliveryValidationCode": otppin }, {
                where: {
                    orderId: orderid
                }
            });
            return result;
        } catch (e) {
            console.error(e);
            return e;
        }
    }

    async RemoveDriverVehicleId(vehicleid: any): Promise<Boolean> {
        try {
            let result = await Vehicle.update<Vehicle>({ "driverId": null }, {
                where: {
                    vehicleId: vehicleid
                }
            });
            return true;
        } catch (e) {
            return false;
        }
    }

}