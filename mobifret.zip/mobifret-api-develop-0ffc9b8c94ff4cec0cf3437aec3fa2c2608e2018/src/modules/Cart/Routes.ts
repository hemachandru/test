import { Router } from "express";
import { Core } from "../Core";
import { Middleware } from "../Account/middleware";
import { CartController } from "./controller/CartController";
import { PricingController } from "../Pricing/controller/PricingController";


export class Routes extends Core.BaseRoutes {
    private route: Router;
    private middleware: Middleware = new Middleware();
    private cartController: CartController = new CartController();
    private pricingController: PricingController = new PricingController();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;
        self.route.post("/v1/addCart", [self.middleware.Authorization()], self.cartController.CreateCart());
        self.route.get("/v1/getCart", [self.middleware.Authorization()], self.cartController.GetCart());
        self.route.get("/v1/getCartCount", [self.middleware.Authorization()], self.cartController.GetCartCount());
        self.route.get("/v1/getSingleCart/:id", [self.middleware.Authorization()], self.cartController.GetSingleCart());
        self.route.delete("/v1/deleteCart/:cartId", [self.middleware.Authorization()], self.cartController.DeleteCart());
        self.route.post("/v1/getPrice", [self.middleware.Authorization()], self.pricingController.GetPrice());
        return self.route;
    }
}
