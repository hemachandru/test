import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, HasMany, DataType } from 'sequelize-typescript';
import { Cart } from './Cart';
import { Document } from '../../Account/models/Document';
import { FreightType } from '../../General/models/FreightType';
import { ShipmentStatus } from './ShipmentStatus';
import { QRBatchDetail } from '../../DriverMission/models/QRBatchDetail';
import { ShipmentHistory } from './ShipmentHistory';

@Table({
    tableName: "tblShipmentDetail"
})

export class ShipmentDetail extends Model<ShipmentDetail>{

    @AutoIncrement
    @PrimaryKey
    @Column
    shipmentDetailId: number;

    @ForeignKey(() => Cart)
    @Column
    orderId: number;

    @ForeignKey(() => FreightType)
    @Column
    freightTypeId: number;

    @Column(DataType.FLOAT)
    shipmentCost: number;

    @Column(DataType.FLOAT)
    insuranceCost: number;

    @Column(DataType.FLOAT)
    taxCost: number;

    @Column(DataType.FLOAT)
    netShipmentCost: number;

    @ForeignKey(() => ShipmentStatus)
    @Column
    shipmentStatusId: number;

    @ForeignKey(() => QRBatchDetail)
    @Column
    qrBatchDetailId: number;

    @Column
    isValidDelivery: boolean;

    @Column
    isStackable: boolean;

    @Column
    isFilmeed: boolean;

    @Column(DataType.FLOAT)
    insurancePercentage: number;

    @Column(DataType.FLOAT)
    consignmentCost: number;

    @Column
    isTaxable: boolean;

    @ForeignKey(() => Document)
    @Column
    shipmentPhotoId: number;

    @Column
    comments: string;

    @Column
    quantity: number;

    @Column(DataType.FLOAT)
    weight: number;

    @Column(DataType.FLOAT)
    length: number;

    @Column(DataType.FLOAT)
    breadth: number;

    @Column(DataType.FLOAT)
    height: number;

    @BelongsTo(() => Cart)
    order: Cart;

    @BelongsTo(() => FreightType)
    freightType: FreightType;

    @BelongsTo(() => ShipmentStatus)
    shipmentStatus: ShipmentStatus;

    @BelongsTo(() => QRBatchDetail)
    qrBatchDetail: QRBatchDetail;

    @BelongsTo(() => Document)
    photo: Document;

    @HasMany(() => ShipmentHistory)
    shipmentHistory: ShipmentHistory[];

}

