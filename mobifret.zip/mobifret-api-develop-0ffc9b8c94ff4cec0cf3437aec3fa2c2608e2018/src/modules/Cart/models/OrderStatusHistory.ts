import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, CreatedAt } from 'sequelize-typescript';
import { OrderStatus } from './OrderStatus';
import { Cart } from './Cart';

@Table({
    timestamps: false,
    tableName: "tblOrderStatusHistory"
})

export class OrderStatusHistory extends Model<OrderStatusHistory> {

    @AutoIncrement
    @PrimaryKey
    @Column
    orderStatusHistoryId: number;

    @ForeignKey(() => Cart)
    @Column
    orderId: number;

    @ForeignKey(() => OrderStatus)
    @Column
    orderStatusId: number;

    @Column
    statusAt: Date;

    @BelongsTo(() => OrderStatus)
    orderstatus: OrderStatus;

    @BelongsTo(() => Cart)
    cart: Cart;
}