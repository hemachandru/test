import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, CreatedAt } from 'sequelize-typescript';
import { ShipmentStatus } from './ShipmentStatus';
import { Cart } from './Cart';
import { ShipmentDetail } from './ShipmentDetail';

@Table({
    timestamps: false,
    tableName: "tblShipmentHistory"
})

export class ShipmentHistory extends Model<ShipmentHistory> {

    @AutoIncrement
    @PrimaryKey
    @Column
    shipmentHistoryId: number;

    @ForeignKey(() => Cart)
    @Column
    orderId: number;

    @ForeignKey(() => ShipmentDetail)
    @Column
    shipmentDetailId: number;

    @ForeignKey(() => ShipmentStatus)
    @Column
    shipmentStatusId: number;

    @Column
    statusAt: Date;

    @BelongsTo(() => Cart)
    cart: Cart;

    @BelongsTo(() => ShipmentDetail)
    shipmentDetail: ShipmentDetail;

    @BelongsTo(() => ShipmentStatus)
    shipmentStatus: ShipmentStatus;

}