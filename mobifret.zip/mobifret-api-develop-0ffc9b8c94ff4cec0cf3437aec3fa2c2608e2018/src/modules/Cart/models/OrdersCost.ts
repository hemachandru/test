import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, HasOne, HasMany, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

import { Cart } from './Cart';


@Table({
    timestamps: true,
    tableName: "tblOrdersCost"
})

export class OrdersCost extends Model<OrdersCost>{

    @AutoIncrement
    @PrimaryKey
    @Column
    orderCostId: number;

    @ForeignKey(() => Cart)
    @Column
    orderId: number;

    @Column
    vehicleClassificationId: number;

    @Column(DataType.FLOAT)
    depAmount: number;

    @Column(DataType.FLOAT)
    vehicleInsurance: number;

    @Column(DataType.FLOAT)
    salaryAmount: number;

    @Column(DataType.FLOAT)
    tax: number;

    @Column(DataType.FLOAT)
    maintenance: number;

    @Column(DataType.FLOAT)
    fuel: number;

    @Column(DataType.FLOAT)
    oil: number;

    @Column(DataType.FLOAT)
    tyre: number;

    @Column(DataType.FLOAT)
    rent: number;

    @Column(DataType.FLOAT)
    empsalary: number;

    @Column(DataType.FLOAT)
    overHeadMaintenance: number;

    @Column(DataType.FLOAT)
    mic: number;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

}