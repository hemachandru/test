import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblOrderStatus"
})

export class OrderStatus extends Model<OrderStatus> {

    @AutoIncrement
    @PrimaryKey
    @Column
    orderStatusId: number;

    @Column
    orderStatus: string;

}