import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblShipmentStatus"
})

export class ShipmentStatus extends Model<ShipmentStatus> {

    @AutoIncrement
    @PrimaryKey
    @Column
    shipmentStatusId: number;

    @Column
    shipmentStatus: string;

}