import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, HasOne, HasMany, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

import { OrderStatus } from './OrderStatus';
import { Vehicle } from '../../DriverMission/models/Vehicle';
import { Driver } from '../../DriverMission/models/Driver';
import { Registration } from '../../Account/models/Registration';
import { User } from '../../Account/models/User';
import { ShipmentAddress } from './ShipmentAddress';
import { ShipmentDetail } from './ShipmentDetail';
import { OrderStatusHistory } from './OrderStatusHistory';
import { Rating } from "../../DriverMission/models/Rating";
import { NotConfirmedMissionReasons } from '../../General/models/NotConfirmedMissionReasons';


@Table({
    timestamps: true,
    tableName: "tblOrders"
})

export class Cart extends Model<Cart>{

    @AutoIncrement
    @PrimaryKey
    @Column
    orderId: number;

    @Column(DataType.ENUM('Planned', 'Immediate'))
    shipmentMode: 'Planned' | 'Immediate';

    @Column(DataType.FLOAT)
    orderCost: number;

    @Column(DataType.FLOAT)
    insuranceCost: number;

    @Column(DataType.FLOAT)
    taxCost: number;

    @Column(DataType.FLOAT)
    netCost: number;

    @Column(DataType.FLOAT)
    companyMargin: number;

    @Column(DataType.FLOAT)
    mobfretMargin: number;

    @Column(DataType.FLOAT)
    overAllMargin: number;

    @Column
    linecnt: number;

    @Column
    duration: number;

    @ForeignKey(() => NotConfirmedMissionReasons)
    @Column
    reasonId: number;

    @Column(DataType.FLOAT)
    distance: number;

    @Column(DataType.FLOAT)
    estCost: number;

    @Column
    driverValidationCode: string;

    @Column
    isDriverMatch: boolean;

    @Column
    deliveryValidationCode: string;

    @Column
    isDeliveryMatch: boolean;

    @ForeignKey(() => ShipmentAddress)
    @Column
    fromShipmentAddressId: number;

    @ForeignKey(() => ShipmentAddress)
    @Column
    toShipmentAddressId: number;

    @ForeignKey(() => OrderStatus)
    @Column
    orderStatusId: number;

    @ForeignKey(() => Vehicle)
    @Column
    vehicleId: number;

    @ForeignKey(() => Driver)
    @Column
    driverId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @ForeignKey(() => Registration)
    @Column
    clientRegistrationId: number;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @Column
    comments: string;

    @Column
    deliveryComments: string;
    
    @Column
    assignedAt: Date;

    @Column
    shipmentAt: Date;

    @Column
    completedAt: Date;

    @Column
    isDeleted: boolean;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @Column
    isInsured: boolean;

    @Column(DataType.FLOAT)
    consignmentCost: number;

    @Column(DataType.FLOAT)
    insurancePercentage: number;

    @BelongsTo(() => ShipmentAddress)
    shipmentAddress: ShipmentAddress;

    @BelongsTo(() => OrderStatus)
    orderstatus: OrderStatus;

    @BelongsTo(() => Vehicle)
    Vehicle: Vehicle;

    @BelongsTo(() => Driver)
    driver: Driver;

    @BelongsTo(() => Registration)
    registration: Registration;

    @BelongsTo(() => User)
    user: User;

    @HasMany(() => ShipmentDetail)
    shipment: ShipmentDetail[];

    @HasMany(() => OrderStatusHistory)
    orderHistory: OrderStatusHistory[];

    @HasOne(() => Rating)
    rating: Rating;

    @BelongsTo(() => NotConfirmedMissionReasons)
    missionReasons: NotConfirmedMissionReasons;

}