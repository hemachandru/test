import { Table, Column, Model, AutoIncrement, PrimaryKey, ForeignKey, BelongsTo, DataType, CreatedAt, UpdatedAt, DeletedAt } from 'sequelize-typescript';

import { Region } from '../../General/models/Region';
import { Country } from '../../General/models/Country';

@Table({
    timestamps: true,
    tableName: "tblShipmentAddresses"
})

export class ShipmentAddress extends Model<ShipmentAddress>{

    @AutoIncrement
    @PrimaryKey
    @Column
    shipmentAddressId: number;

    @Column(DataType.ENUM('Pickup', 'Delivery'))
    addressType: 'Pickup' | 'Delivery';

    @Column(DataType.FLOAT)
    lat: number;

    @Column(DataType.FLOAT)
    lan: number;

    @Column
    firstName: string;

    @Column
    lastName: string;

    @Column
    email: string;

    @Column
    telephone: string;

    @Column
    address1: string;

    @Column
    address2: string;

    @Column
    gateNumber: string;

    @Column
    appartmentName: string;

    @Column
    floor: string;

    @Column
    city: string;

    @Column
    country: string;

    @Column
    postalCode: string;

    @Column
    isLift: boolean;

    @Column
    isBell: boolean;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @ForeignKey(() => Country)
    @Column
    countryId: number;

    @BelongsTo(() => Region)
    region: Region;

    @BelongsTo(() => Country)
    countryNode: Country;
}