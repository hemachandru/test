import { Exception } from "../exception";

export class Validation {
    private error = [];
    constructor() {
        this.error = [];
    }

    CartValidation(data: any) {
        this.error = [];

        if (!data.from_address) {
            this.error.push(new Exception().ThrowException("1034"));
        }

        if (data.from_address) {
            if (!data.from_address.first_name) {
                this.error.push(new Exception().ThrowException("1035"));
            }
            if (!data.from_address.email) {
                this.error.push(new Exception().ThrowException("1036"));
            }
            if (!data.from_address.telephone) {
                this.error.push(new Exception().ThrowException("1037"));
            }
            if (!data.from_address.address) {
                this.error.push(new Exception().ThrowException("1058"));
            }
            if (data.from_address.address) {
                if (!data.from_address.address.address1) {
                    this.error.push(new Exception().ThrowException("1038"));
                }
                if (!data.from_address.address.lat) {
                    this.error.push(new Exception().ThrowException("1039"));
                }
                if (!data.from_address.address.lan) {
                    this.error.push(new Exception().ThrowException("1040"));
                }
                // if (data.from_address.address.lat) {
                //     //if (!(/^(\+|-)?(?:90(?:(?:\.0{1,6})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,6})?))$/.test(data.from_address.address.lat))) {
                //         this.error.push(new Exception().ThrowException("1042"));
                //     //}
                // }
                // if (data.from_address.address.lan) {
                //     if (!(/^(\+|-)?(?:180(?:(?:\.0{1,6})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,6})?))$/.test(data.from_address.address.lan))) {
                //         this.error.push(new Exception().ThrowException("1043"));
                //     }
                // }
            }
            // if (!data.from_address.floor) {
            //     this.error.push(new Exception().ThrowException("1041"));
            // }
        }

        if (!data.to_address) {
            this.error.push(new Exception().ThrowException("1044"));
        }

        if (data.to_address) {
            if (!data.to_address.first_name) {
                this.error.push(new Exception().ThrowException("1045"));
            }
            // if (!data.to_address.email) {
            //     this.error.push(new Exception().ThrowException("1046"));
            // }
            if (!data.to_address.telephone) {
                this.error.push(new Exception().ThrowException("1047"));
            }
            if (!data.to_address.address) {
                this.error.push(new Exception().ThrowException("1059"));
            }
            if (data.to_address.address) {
                if (!data.to_address.address.address1) {
                    this.error.push(new Exception().ThrowException("1048"));
                }
                if (!data.to_address.address.lat) {
                    this.error.push(new Exception().ThrowException("1049"));
                }
                if (!data.to_address.address.lan) {
                    this.error.push(new Exception().ThrowException("1050"));
                }
                // if (data.to_address.address.lat) {
                //     if (!(/^(\+|-)?(?:90(?:(?:\.0{1,15})?)|(?:[0-9]|[1-8][0-9])(?:(?:\.[0-9]{1,6})?))$/.test(data.from_address.address.lat))) {
                //         this.error.push(new Exception().ThrowException("1052"));
                //     }
                // }
                // if (data.to_address.address.lan) {
                //     if (!(/^(\+|-)?(?:180(?:(?:\.0{1,15})?)|(?:[0-9]|[1-9][0-9]|1[0-7][0-9])(?:(?:\.[0-9]{1,6})?))$/.test(data.from_address.address.lan))) {
                //         this.error.push(new Exception().ThrowException("1053"));
                //     }
                // }
            }
            // if (!data.to_address.floor) {
            //     this.error.push(new Exception().ThrowException("1051"));
            // }
        }

        if (!data.shipment_mode) {
            this.error.push(new Exception().ThrowException("1054"));
        }

        if (data.shipment_mode) {
            if (!(data.shipment_mode == "Immediate" || data.shipment_mode == "Planned")) {
                this.error.push(new Exception().ThrowException("1055"));
            }
            if (data.shipment_mode == "Planned") {
                if (!data.assigned_at) {
                    this.error.push(new Exception().ThrowException("1056"));
                }
            }
        }

        if (!(data.shipment && data.shipment.length != 0)) {
            this.error.push(new Exception().ThrowException("1057"));
        }

        if (data.isInsured) {
            if (data.isInsured == 1) {
                if (!data.insurance_cost) {
                    this.error.push(new Exception().ThrowException("1071"));
                }
                if (!data.consignment_cost) {
                    this.error.push(new Exception().ThrowException("1072"));
                }
                if (!data.insurance_percentage) {
                    this.error.push(new Exception().ThrowException("1073"));
                }

            }
        }

        // if (!data.order_cost) {
        //     this.error.push(new Exception().ThrowException("1060"));
        // }

        // if (!data.insurance_cost) {
        //     this.error.push(new Exception().ThrowException("1061"));
        // }

        // if (!data.tax_cost) {
        //     this.error.push(new Exception().ThrowException("1062"));
        // }

        // if (!data.net_cost) {
        //     this.error.push(new Exception().ThrowException("1063"));
        // }

        // if (data.order_cost) {
        //     if (!(/^[1-9]\d*(\.\d+)?$/.test(data.order_cost))) {
        //         this.error.push(new Exception().ThrowException("1064"));
        //     }
        // }

        // if (data.insurance_cost) {
        //     if (!(/^[1-9]\d*(\.\d+)?$/.test(data.insurance_cost))) {
        //         this.error.push(new Exception().ThrowException("1065"));
        //     }
        // }

        // if (data.tax_cost) {
        //     if (!(/^[1-9]\d*(\.\d+)?$/.test(data.tax_cost))) {
        //         this.error.push(new Exception().ThrowException("1066"));
        //     }
        // }

        // if (data.net_cost) {
        //     if (!(/^[1-9]\d*(\.\d+)?$/.test(data.net_cost))) {
        //         this.error.push(new Exception().ThrowException("1067"));
        //     }
        // }

        // let shipmentCount = 0;
        // let shipmentOrderCostValid = [];
        // if (data.shipment && data.shipment.length != 0) {
        //     data.shipment.forEach(element => {
        //         if (element.shipment_cost) {
        //             shipmentCount = shipmentCount + 1;
        //             if (/^[1-9]\d*(\.\d+)?$/.test(element.shipment_cost)) {
        //                 shipmentOrderCostValid.push(true);
        //             } else {
        //                 shipmentOrderCostValid.push(false);
        //             }
        //         }
        //     });
        // }

        // if (data.shipment) {
        //     if (data.shipment.length != shipmentCount) {
        //         this.error.push(new Exception().ThrowException("1068"));
        //     }
        //     if (data.shipment.length == shipmentCount) {
        //         if (shipmentOrderCostValid.indexOf(false) > -1) {
        //             this.error.push(new Exception().ThrowException("1069"));
        //         }
        //     }
        // }

        return this.handler(this.error);
    }


    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}