import { error } from "./CartException";
import { Core } from "../../Core";

export class Exception extends Core.BaseException {
    constructor() {
        super(error);
    }
}