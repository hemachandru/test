import { Request, Response } from "express";
import { Sequelize } from 'sequelize-typescript';
import { Core } from "../../Core";
import { Cart } from "../models/Cart";
import { Document } from '../../Account/models/Document';
import { OrderStatus } from '../models/OrderStatus';
import { OrderStatusHistory } from '../models/OrderStatusHistory';
import { ShipmentDetail } from '../models/ShipmentDetail';
import { ShipmentStatus } from '../models/ShipmentStatus';
import { ShipmentHistory } from '../models/ShipmentHistory';
import { ShipmentAddress } from '../models/ShipmentAddress';
import { FreightType } from '../../General/models/FreightType';
import { Vehicle } from '../../DriverMission/models/Vehicle';
import { Driver } from '../../DriverMission/models/Driver';
import { Registration } from '../../Account/models/Registration';
import { User } from '../../Account/models/User';
import { SequelizeLib } from '../../../helper';
import { S3Lib } from '../../../helper';
import { DocumentService } from "../../Account/service/DocumentService";
import { OrdersCost } from '../models/OrdersCost';
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";


export class CartService extends Core.BaseService {

    private sequelize: Sequelize;
    private sequelizeLib: SequelizeLib;
    private s3 = new S3Lib();
    private documentService = new DocumentService();

    GenerateRandomString(len) {
        var text = "";
        var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }

    async PostCart(objOrder: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();
        try {
            let fromAddressID = 0;
            let toAddressID = 0;

            let addressResult = await ShipmentAddress.bulkCreate(objOrder.address, { transaction: t });

            for (let i in addressResult) {
                if (i == "0")
                    fromAddressID = addressResult[i].getDataValue("shipmentAddressId");
                if (i == "1")
                    toAddressID = addressResult[i].getDataValue("shipmentAddressId");
            }

            let orderObj = {
                shipmentMode: objOrder.order.shipmentMode,
                //orderCost: objOrder.order.orderCost,
                insuranceCost: objOrder.order.insuranceCost,
                //taxCost: objOrder.order.taxCost,
                //netCost: objOrder.order.netCost,
                driverValidationCode: objOrder.order.driverValidationCode,
                deliveryValidationCode: null,
                fromShipmentAddressId: fromAddressID,
                toShipmentAddressId: toAddressID,
                orderStatusId: objOrder.order.orderStatusId,
                registrationId: objOrder.order.registrationId,
                userId: objOrder.order.userId,
                clientRegistrationId: objOrder.order.clientRegistrationId,
                comments: objOrder.order.comments,
                assignedAt: objOrder.order.assignedAt,
                linecnt: objOrder.order.linecnt,
                duration: objOrder.order.duration,
                distance: objOrder.order.distance,
                isInsured: objOrder.order.isInsured,
                consignmentCost: objOrder.order.consignmentCost,
                insurancePercentage: objOrder.order.insurancePercentage

            }

            let orderResult = await Cart.create(orderObj, { transaction: t });
            let orderID = orderResult.getDataValue("orderId");

            for (let i in objOrder.shipment) {
                let photoResult;
                if (objOrder.shipment[i].shipmentPhoto) {
                    let photoDestination = "api/shipment/" + this.GenerateRandomString(15) + "_" + new Date().getTime() + ".jpg";
                    let photoS3 = await this.s3.CopyObjectPublic("/" + objOrder.shipment[i].shipmentPhoto, photoDestination);
                    let photoDocument: any = {
                        documentType: 'photo',
                        document: photoS3 ? photoDestination : null
                    }
                    photoResult = await this.documentService.PostDocument(photoDocument);
                    if (photoResult) {
                        objOrder.shipment[i].shipmentPhotoId = photoResult.getDataValue("documentId");
                    } else {
                        objOrder.shipment[i].shipmentPhotoId = null;
                    }
                    delete objOrder.shipment[i].shipmentPhoto;
                } else {
                    objOrder.shipment[i].shipmentPhotoId = null;
                }
                objOrder.shipment[i].orderId = orderID;
            }

            let shipmentResult = await ShipmentDetail.bulkCreate(objOrder.shipment, { transaction: t });

            let transactionCommit = await t.commit();

            let pricingList = await this.sequelize.query('CALL price_Calculation (:ip_distance, :ip_duration, :ip_length, :ip_breadth, :ip_height, :ip_weight , :ip_cnt , :ip_insuranceCost, :ip_orderId )',
                {
                    replacements: {
                        ip_distance: 0,
                        ip_duration: 0,
                        ip_length: 0,
                        ip_breadth: 0,
                        ip_height: 0,
                        ip_weight: 0,
                        ip_cnt: 0,
                        ip_insuranceCost: 0,
                        ip_orderId: orderID
                    }
                }
            );


            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }
    }

    async GetSingleCart(id: number): Promise<Cart> {
        try {
            let result = await Cart.findOne<Cart>({
                where: {
                    orderId: id,
                    orderStatusId: OrderStatusEnum.Cart
                },
                include: [
                    {
                        model: ShipmentDetail,
                        include: [ShipmentStatus, FreightType, Document]
                    },
                    OrderStatus]
            });
            if (result)
                return result.toJSON();
            return result;
        } catch (e) {
            //throw e;
            console.log(e);
            return null;
        }

    }

    async GetAddress(id: number): Promise<ShipmentAddress> {
        try {
            let result = await ShipmentAddress.findOne<ShipmentAddress>({
                where: { shipmentAddressId: id }
            });
            if (result)
                return result.toJSON();
            return result;
        } catch (e) {
            //throw e;
            console.log(e);
            return null;
        }

    }

    async DeleteCart(id: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();

        try {

            let result: any = await this.GetSingleCart(id);
            if (result) {

                let orderID = result.orderId;
                let shipmentID = [];
                let addressID = [];
                let photoID = [];

                addressID.push(result.fromShipmentAddressId);
                addressID.push(result.toShipmentAddressId);


                result.shipment.forEach(element => {
                    shipmentID.push(element.shipmentDetailId);
                    if (element.shipmentPhotoId) {
                        photoID.push(element.photo.documentId);
                    }
                });



                if (shipmentID.length) {
                    let resultShipmentDelete = await ShipmentDetail.destroy({
                        where: {
                            shipmentDetailId: shipmentID
                        }, transaction: t
                    });
                }





                if (photoID.length) {
                    let resultPhotoDelete = await Document.destroy({
                        where: {
                            documentId: photoID
                        }, transaction: t
                    });
                }

                let orderCostDelete = await OrdersCost.destroy({
                    where: {
                        orderId: orderID
                    }, transaction: t
                });


                let resultCartDelete = await Cart.destroy({
                    where: {
                        orderId: orderID
                    }, transaction: t
                });



                let resultAddressDelete = await ShipmentAddress.destroy({
                    where: {
                        shipmentAddressId: addressID
                    }, transaction: t
                });

                let transactionCommit = await t.commit();
                return true;
            }
            return false;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }
    }

    async GetCart(id: number): Promise<any> {
        try {
            let result = await Cart.findAll<Cart>({
                where: {
                    userId: id,
                    orderStatusId: OrderStatusEnum.Cart
                },
                include: [
                    {
                        model: ShipmentDetail,
                        include: [ShipmentStatus, FreightType, Document]
                    },
                    OrderStatus]
            });
            return result;
        } catch (e) {
            console.log(e);
            return null;
        }

    }

}