import { Request, Response } from "express";
import { Core } from "../../Core";
import { CartBusiness } from "../business/CartBusiness";
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";
import { S3Lib } from '../../../helper';
import { UserService } from '../../Account/service/UserService';

export class CartController extends Core.BaseController {

    private cartBusiness = new CartBusiness();
    private s3 = new S3Lib();
    private userService = new UserService();
    private validate = new Validation();

    CreateCart() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.CartValidation(req.body);
                if (!validate.status) {
                    let userData: any = req.headers['user'];
                    let userResult = await self.userService.GetCurrentUser(parseInt(userData.userID));
                    if (req.body.shipment) {
                        let error = [];
                        for (let i in req.body.shipment) {
                            if (req.body.shipment[i].shipment_image) {
                                let shipmentImageResult = await this.s3.FindObject(req.body.shipment[i].shipment_image);
                                error.push(shipmentImageResult);
                            }
                        }
                        if (error.indexOf(false) > -1) {
                            return res.status(422).send([new Exception().ThrowException("1031")]);
                        }
                    }
                    let result = await self.cartBusiness.CartProcess(req.body, userResult);
                    if (!result) {
                        return res.status(500).send([new Exception().ThrowException("")]);
                    }
                    return res.status(200).send();
                }
                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetSingleCart() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.cartBusiness.GetSingleCart(req.params.id);
                if (result) {
                    let sendResult = await new Transformation().formatSingleCart(result);
                    return res.send(sendResult);
                }
                return res.send(result);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    DeleteCart() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.cartBusiness.DeleteCart(req.params.cartId);
                if (result)
                    return res.send();
                return res.status(422).send([new Exception().ThrowException("1033")]);
            }
            catch (e) {
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetCartCount() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers['user'];
                let result = await self.cartBusiness.GetCart(parseInt(userData.userID));
                if (result) {
                    let sendResult = await new Transformation().formatGetCartCount(result);
                    return res.send(sendResult);
                }
                return res.status(200).send();

            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetCart() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers['user'];
                let result = await self.cartBusiness.GetCart(parseInt(userData.userID));
                if (result) {
                    let sendResult = await new Transformation().formatGetCart(result);
                    return res.send(sendResult);
                }
                return res.status(200).send();

            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

}