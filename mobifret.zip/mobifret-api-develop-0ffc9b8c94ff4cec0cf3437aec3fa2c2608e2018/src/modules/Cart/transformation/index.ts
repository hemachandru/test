import { Core } from "../../Core";
import { ShipmentAddress } from '../models/ShipmentAddress';
import { CartService } from '../service/CartService';

export class Transformation extends Core.BaseTransformation {

    private cartService = new CartService();

    constructor() {
        super();
    }

    async formatSingleCart(data: any): Promise<any> {

        let orderStatusObj = {
            id: data.orderstatus.orderStatusId,
            status: data.orderstatus.orderStatus
        };

        let shipmentObj = [];

        data.shipment.forEach(element => {

            let shipmentNode = {
                id: element.shipmentDetailId,
                freight_type: {
                    id: element.freightType.freightTypeId,
                    type: element.freightType.freightType
                },
                // shipment_cost: element.shipmentCost,
                // insurance_cost: element.insuranceCost,
                // tax_cost: element.taxCost,
                // net_shipment_cost: element.netShipmentCost,
                shipment_image: element.shipmentPhotoId ? process.env.AWS_CDN_URL + "/" + element.photo.document : null,
                isstackable: element.isStackable,
                isfilmeed: element.isFilmeed,
                quantity: element.quantity,
                length: element.length,
                weight: element.weight,
                width: element.width,
                breadth: element.breadth,
                height: element.height,
                comments: element.comments,
                shipment_status: {
                    id: element.shipmentStatus.shipmentStatusId,
                    status: element.shipmentStatus.shipmentStatus
                }

            };

            shipmentObj.push(shipmentNode);

        });

        let fromAddress = await this.getAddress(data.fromShipmentAddressId);
        let toAddress = await this.getAddress(data.toShipmentAddressId);

        let cartObj = {
            id: data.orderId,
            shipment_mode: data.shipmentMode,
            order_cost: data.orderCost,
            insurance_cost: data.insuranceCost,
            tax_cost: data.taxCost,
            net_cost: data.netCost,
            comments: data.comments,
            from_address: fromAddress,
            to_address: toAddress,
            assigned_at: data.assignedAt,
            shipment_at: data.shipmentAt,
            order_status: orderStatusObj,
            shipment: shipmentObj,
            isInsured: data.isInsured,
            consignmentCost: data.consignmentCost,
            insurancePercentage: data.insurancePercentage
        }

        return cartObj;
    }

    async getAddress(id: number): Promise<any> {
        let result = await this.cartService.GetAddress(id);
        let resultObject = {
            id: id,
            first_name: result.firstName,
            last_name: result.lastName,
            email: result.email,
            telephone: result.telephone,
            address: {
                lat: result.lat,
                lan: result.lan,
                address1: result.address1,
                address2: result.address2,
                city: result.city,
                country: result.country,
                postalcode: result.postalCode
            },
            gate_number: result.gateNumber,
            apartment_name: result.appartmentName,
            floor: result.floor,
            islift: result.isLift ? true : false,
            isbell: result.isBell ? true : false

        };

        return resultObject;
    }


    async formatGetCart(data: any): Promise<any> {
        let cartArray = [];
        let result = data;
        let totalAmount = 0;
        for (let i in result) {
            totalAmount += result[i].netCost;
            let toAddress = await this.getAddress(result[i].toShipmentAddressId);
            let cartNode = {
                id: result[i].orderId,
                to_address: toAddress,
                net_cost: result[i].netCost,
                distance: result[i].distance,
                duration: result[i].duration,
                shipment_count: result[i].shipment.length
            };
            cartArray.push(cartNode);
        }

        let resultObj = {
            count: data.length,
            total_cost: totalAmount,
            data: cartArray
        }
        return resultObj;
    }

    async formatGetCartCount(data: any): Promise<any> {
        let result = data;
        let count = 0;
        let resultObj = {
            count: result.length,
        }
        return resultObj;
    }

}