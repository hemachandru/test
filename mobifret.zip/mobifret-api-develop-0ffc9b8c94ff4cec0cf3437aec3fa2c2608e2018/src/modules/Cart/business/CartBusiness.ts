import { CartService } from "../service/CartService";
import { Cart } from '../models/Cart';
import { ShipmentStatusEnum } from "../../Order/helper/ShipmentStatusEnum";
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";


export class CartBusiness {

    private cartService = new CartService();

    GenerateRandomString(len) {
        var text = "";
        var charset = "0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }

    async CartProcess(order: any, user: any): Promise<Boolean> {
        try {

            let fromAddress: any = {
                addressType: 'Pickup',
                lat: order.from_address.address.lat,
                lan: order.from_address.address.lan,
                firstName: order.from_address.first_name,
                lastName: order.from_address.last_name ? order.from_address.last_name : null,
                email: order.from_address.email ? order.from_address.email : null,
                telephone: order.from_address.telephone,
                address1: order.from_address.address.address1,
                address2: order.from_address.address.address2 ? order.from_address.address.address2 : null,
                gateNumber: order.from_address.gate_number ? order.from_address.gate_number : null,
                appartmentName: order.from_address.apartment_name ? order.from_address.apartment_name : null,
                floor: order.from_address.floor ? order.from_address.floor : null,
                city: order.from_address.address.city ? order.from_address.address.city : null,
                country: order.from_address.address.country ? order.from_address.address.country : null,
                postalCode: order.from_address.address.postalcode,
                isLift: order.from_address.islift ? true : false,
                isBell: order.from_address.isbell ? true : false
            }

            let toAddress: any = {
                addressType: 'Delivery',
                lat: order.to_address.address.lat,
                lan: order.to_address.address.lan,
                firstName: order.to_address.first_name,
                lastName: order.to_address.last_name ? order.to_address.last_name : null,
                email: order.to_address.email ? order.to_address.email : null,
                telephone: order.to_address.telephone,
                address1: order.to_address.address.address1,
                address2: order.to_address.address.address2 ? order.to_address.address.address2 : null,
                gateNumber: order.to_address.gate_number ? order.to_address.gate_number : null,
                appartmentName: order.to_address.apartment_name ? order.to_address.apartment_name : null,
                floor: order.to_address.floor ? order.to_address.floor : null,
                city: order.to_address.address.city ? order.to_address.address.city : null,
                country: order.to_address.address.country ? order.to_address.address.country : null,
                postalCode: order.to_address.address.postalcode,
                isLift: order.to_address.islift ? true : false,
                isBell: order.to_address.isbell ? true : false
            }

            let addressArray: any = [];
            addressArray[0] = fromAddress;
            addressArray[1] = toAddress;

            let shipment: any = [];

            for (let i in order.shipment) {
                let shipmentNode = new Object();
                shipmentNode["freightTypeId"] = order.shipment[i].freight_type;
                // shipmentNode["shipmentCost"] = order.shipment[i].shipment_cost;
                // shipmentNode["insuranceCost"] = order.shipment[i].insurance_cost;
                // shipmentNode["taxCost"] = order.shipment[i].tax_cost;
                // shipmentNode["netShipmentCost"] = order.shipment[i].net_shipment_cost;
                shipmentNode["shipmentStatusId"] = ShipmentStatusEnum.Cart;
                shipmentNode["shipmentPhoto"] = order.shipment[i].shipment_image ? order.shipment[i].shipment_image : null;
                shipmentNode["isStackable"] = order.shipment[i].isstackable ? order.shipment[i].isstackable : false;
                shipmentNode["isFilmeed"] = order.shipment[i].isfilmeed ? order.shipment[i].isfilmeed : false;
                shipmentNode["quantity"] = order.shipment[i].quantity;
                shipmentNode["weight"] = order.shipment[i].weight ? order.shipment[i].weight : null;
                shipmentNode["length"] = order.shipment[i].length ? order.shipment[i].length : null;
                shipmentNode["breadth"] = order.shipment[i].breadth ? order.shipment[i].breadth : null;
                shipmentNode["height"] = order.shipment[i].height ? order.shipment[i].height : null;
                shipmentNode["comments"] = order.shipment[i].comments ? order.shipment[i].comments : null;
                shipment.push(shipmentNode);
            }

            let insuranceCost: any = 0;
            if (order.isInsured == 1)
                insuranceCost = ((order.insurance_percentage * order.consignment_cost) / 100).toFixed(3);

            let ord: any = {
                shipmentMode: order.shipment_mode,
                // orderCost: order.order_cost,
                // insuranceCost: order.insurance_cost,
                // taxCost: order.tax_cost,
                // netCost: order.net_cost,
                driverValidationCode: this.GenerateRandomString(4),
                // deliveryValidationCode: this.GenerateRandomString(4),
                //driverValidationCode: 1234,
                //deliveryValidationCode: 1234,
                orderStatusId: OrderStatusEnum.Cart,
                userId: user.userId,
                clientRegistrationId: user.registrationId,
                comments: order.comments,
                assignedAt: order.assigned_at ? order.assigned_at : null,
                linecnt: shipment.length,
                duration: order.duration,
                distance: order.distance,
                insuranceCost: insuranceCost,
                isInsured: order.isInsured ? order.isInsured : 0,
                consignmentCost: order.consignment_cost ? order.consignment_cost : 0,
                insurancePercentage: order.insurance_percentage ? order.insurance_percentage : 0
            };

            let orderObject: any = {
                order: ord,
                address: addressArray,
                shipment: shipment
            }

            let result = await this.cartService.PostCart(orderObject);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetSingleCart(id: number): Promise<Cart> {
        let result = await this.cartService.GetSingleCart(id);
        return result;
    }

    async DeleteCart(id: number): Promise<Boolean> {
        let result = await this.cartService.DeleteCart(id);
        return result;
    }

    async GetCart(id: number): Promise<any> {
        let result = await this.cartService.GetCart(id);
        return result;
    }

}