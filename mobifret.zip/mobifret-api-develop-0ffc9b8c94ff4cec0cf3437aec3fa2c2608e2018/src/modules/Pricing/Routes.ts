import { Router } from "express";
import { Core } from "../Core";
import { Middleware } from "../Account/middleware";
import { PricingController } from './controller/PricingController';


export class Routes extends Core.BaseRoutes {
    private route: Router;
    private middleware: Middleware = new Middleware();
    private pricingController: PricingController = new PricingController();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;
        self.route.post("/v1/getPrice", [self.middleware.Authorization()], self.pricingController.GetPrice());
        return self.route;
    }
}
