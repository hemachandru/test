import { Core } from "../../Core";

export class Transformation extends Core.BaseTransformation {

    constructor() {
        super();
    }


    priceTransfrom(data: any) {
        let map = {};
        map = {
            "orderCost": data[0].orderCost,
            "marginCost": data[0].marginCost,
            "insuranceCost": data[0].insuranceCost,
            "netCost": data[0].netCost,
        }

        return map;
    }
}