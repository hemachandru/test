import { Request, Response } from "express";
import { Core } from "../../Core";
import { Sequelize } from 'sequelize-typescript';
import { SequelizeLib } from '../../../helper';

export class PricingService extends Core.BaseService {
    private sequelize: Sequelize;
    private sequelizeLib: SequelizeLib;
    constructor() {
        super();

    }

    // async getPrice(pricingObj: any): Promise<any> {
    //     try {
    //         return 100;
    //     } catch (e) {
    //         console.log(e);
    //         return 100;
    //     }
    // }



    async getPrice(requestObject: any): Promise<any> {
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        try {
            let pricingList = await this.sequelize.query('CALL price_Calculation (:ip_distance, :ip_duration, :ip_length, :ip_breadth, :ip_height, :ip_weight , :ip_cnt , :ip_insuranceCost, :ip_orderId )',
                {
                    replacements: {
                        ip_distance: requestObject.distance,
                        ip_duration: requestObject.duration,
                        ip_length: requestObject.length,
                        ip_breadth: requestObject.breadth,
                        ip_height: requestObject.height,
                        ip_weight: requestObject.weight,
                        ip_cnt: requestObject.cnt,
                        ip_insuranceCost: requestObject.insuranceCost,
                        ip_orderId: requestObject.orderid
                    }
                }
            );
            //let pricingList = await this.sequelize.query('CALL price_Calculation (46.4,62,0,0,210,500,10,100,0)');
            return pricingList;
        } catch (e) {
            return e;
        }
    }

}