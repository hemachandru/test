import { Request, Response } from "express";
import { Core } from "../../Core";
import { PricingBusiness } from '../business/PricingBusiness';
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";

export class PricingController extends Core.BaseController {

    private pricingBusiness = new PricingBusiness();
    private validate = new Validation();

    constructor() {
        super();
    }

    GetPrice() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers["user"];
                let validate = this.validate.pricingCalcValidate(req.body);
                if (!validate.status) {
                    let result = await self.pricingBusiness.GetPrice(req.body);
                    if (result) {
                        let modifyresult = new Transformation().priceTransfrom(result);
                        return res.send(modifyresult);
                    } else {
                        return res.status(422).send([new Exception().ThrowException("1159")]);
                    }
                } else {
                    return res.status(422).send(validate.error);
                }
            } catch (e) {
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

}