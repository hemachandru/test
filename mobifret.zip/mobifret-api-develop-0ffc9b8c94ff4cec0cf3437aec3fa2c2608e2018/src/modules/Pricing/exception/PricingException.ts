export let error = {
    "1111": "Distance field required",
    "1112": "Field should be number",
    "1113": "Field should not be decimal value",
    "1114": "Shipment Array should not be empty",
    "1115": "Freight type field required",
    "1116": "Insurance cost field required",
    "1117": "Quantity field required",
    "1118": "Length field required",
    "1119": "Breadth field required",
    "1120": "Height field required",
    "1121": "Weight field required",
    "1123": "duration field required"

}