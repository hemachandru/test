import { PricingService } from '../service/PricingService';

export class PricingBusiness {
    private pricingService = new PricingService();

    constructor() {

    }

    async GetPrice(price: any): Promise<any> {
        let shipmentCount = 0;
        let insuranceCost = price.insurance_cost ? price.insurance_cost : 0;
        let distance = price.distance;
        let duration = price.duration;
        let maxLength = 0;
        let maxBreadth = 0;
        let maxHeight = 0;
        let maxWeight = 0;
        let orderId = 0;

        for (let i in price.shipment) {
            shipmentCount += price.shipment[i].quantity;
            //insuranceCost += price.shipment[i].insurance_cost;
            if (maxLength <= price.shipment[i].length)
                maxLength = price.shipment[i].length;
            if (maxBreadth <= price.shipment[i].breadth)
                maxBreadth = price.shipment[i].breadth;
            if (maxHeight <= price.shipment[i].height)
                maxHeight = price.shipment[i].height;
            if (maxWeight <= price.shipment[i].weight)
                maxWeight = price.shipment[i].weight;
        }

        let pricingObj: any = {
            distance: distance,
            duration: duration,
            length: maxLength,
            breadth: maxBreadth,
            height: maxHeight,
            weight: maxWeight,
            cnt: shipmentCount,
            insuranceCost: insuranceCost,
            orderid: orderId
        }

        let pricing = await this.pricingService.getPrice(pricingObj);
        if (pricing) {
            return pricing;
        }
        return null;
    }

}