import { Exception } from "../exception";
const bcrypt = require('bcrypt');
import { S3Lib } from '../../../helper';
import { Core } from "../../Core/index";

export class Validation extends Core.BaseValidation {
    private error = [];
    private s3 = new S3Lib();
    constructor() {
        super();
        this.error = [];
    }
    isNumber(n) { return /^-?[\d.]+(?:e-?\d+)?$/.test(n); };
    IsDecimal(input) { return input % 1 != 0 }

    pricingCalcValidate(data: any) {
        this.error = [];
        if (data) {

            // if (!data.distance) {
            //     this.error.push(new Exception().ThrowException("1111"));
            // } else if (!this.isNumber(data.distance)) {
            //     this.error.push(new Exception().ThrowException("1112"));
            // }


            // if (!data.duration) {
            //     this.error.push(new Exception().ThrowException("1111"));
            // } else if (!this.isNumber(data.duration)) {
            //     this.error.push(new Exception().ThrowException("1112"));
            // } else if (this.IsDecimal(data.duration)) {
            //     this.error.push(new Exception().ThrowException("1113"));
            // }


            // if (data.insurance_cost) {
            //     this.error.push(new Exception().ThrowException("1116"));
            // } else if (!this.isNumber(data.insurance_cost)) {
            //     this.error.push(new Exception().ThrowException("1112"));
            // }

            if (data.shipment.length > 0) {

                data.shipment.forEach(element => {
                    if (!element.freight_type) {
                        this.error.push(new Exception().ThrowException("1115"));
                    } else if (!this.isNumber(element.freight_type)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    } else if (this.IsDecimal(element.freight_type)) {
                        this.error.push(new Exception().ThrowException("1113"));
                    }

                    if (!element.quantity) {
                        this.error.push(new Exception().ThrowException("1117"));
                    } else if (!this.isNumber(element.quantity)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    }

                    if (!(element.length >= 0)) {
                        this.error.push(new Exception().ThrowException("1118"));
                    } else if (!this.isNumber(element.length)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    } else if (this.IsDecimal(element.length)) {
                        this.error.push(new Exception().ThrowException("1113"));
                    }

                    if (!(element.breadth >= 0)) {
                        this.error.push(new Exception().ThrowException("1119"));
                    } else if (!this.isNumber(element.breadth)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    } else if (this.IsDecimal(element.breadth)) {
                        this.error.push(new Exception().ThrowException("1113"));
                    }

                    if (!(element.height >= 0)) {
                        this.error.push(new Exception().ThrowException("1120"));
                    } else if (!this.isNumber(element.height)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    } else if (this.IsDecimal(element.height)) {
                        this.error.push(new Exception().ThrowException("1113"));
                    }

                    if (!(element.weight >= 0)) {
                        this.error.push(new Exception().ThrowException("1121"));
                    } else if (!this.isNumber(element.weight)) {
                        this.error.push(new Exception().ThrowException("1112"));
                    } else if (this.IsDecimal(element.weight)) {
                        this.error.push(new Exception().ThrowException("1113"));
                    }


                });

            } else {
                this.error.push(new Exception().ThrowException("1114"));
            }


        }

        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}