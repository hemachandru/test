export class BaseRoutes {
    constructor() {

    }
}
