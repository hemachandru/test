export class BaseValidation {
    constructor() {
    }
}
