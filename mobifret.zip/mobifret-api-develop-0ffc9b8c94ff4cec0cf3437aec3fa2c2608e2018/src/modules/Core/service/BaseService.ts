export class BaseService {
    constructor() {

    }
}
