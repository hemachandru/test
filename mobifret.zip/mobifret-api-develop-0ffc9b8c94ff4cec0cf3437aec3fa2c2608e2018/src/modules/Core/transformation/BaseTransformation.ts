export class BaseTransformation {
    constructor() {

    }
}