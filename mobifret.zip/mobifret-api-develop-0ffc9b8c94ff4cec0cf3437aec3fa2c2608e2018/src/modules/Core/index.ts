import { BaseRoutes as _BaseRoutes } from "./BaseRoutes";
import { BaseService as _BaseService } from "./service/BaseService";
import { BaseController as _BaseController } from "./controller/BaseController";
import { BaseHelper as _BaseHelper } from "./helper/BaseHelper";
import { BaseMiddleware as _BaseMiddleware } from "./middleware/BaseMiddleware";
import { BaseException as _BaseException } from "./exception/BaseException";
import { BaseTransformation as _BaseTransformation } from "./transformation/BaseTransformation";
import {BaseMailer as _BaseMailer}from './mailer/BaseMailer';
import { BaseValidation as _BaseValidation } from "./Validation/BaseValidation";

export namespace Core {
    export const BaseRoutes = _BaseRoutes;
    export const BaseService = _BaseService;
    export const BaseController = _BaseController;
    export const BaseHelper = _BaseHelper;
    export const BaseMiddleware = _BaseMiddleware;
    export const BaseException = _BaseException;
    export const BaseTransformation = _BaseTransformation;
    export const BaseMailer = _BaseMailer;
    export const BaseValidation = _BaseValidation;
}