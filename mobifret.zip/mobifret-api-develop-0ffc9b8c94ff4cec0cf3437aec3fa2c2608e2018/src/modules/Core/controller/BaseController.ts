export class BaseController {
    constructor() {

    }
}
