import { Core } from "../../Core";
import { Exception } from "../exception";
import { UserService } from '../service/UserService';

let ms = require('ms');
let moment = require("moment");
let expire = ms('1d');
let xtend = require('xtend');
let jwtSimple = require('jwt-simple');
let jwtWebToken = require('jsonwebtoken');

export class JwtLib extends Core.BaseHelper {
    verify: any;
    private options: any;

    private jwt: any;
    private errors: any;
    private userService = new UserService();

    private defaultOptions: any = {
        algorithm: 'HS256',
        succeedWithoutToken: false
    };

    constructor() {
        super();
        this.jwt = jwtWebToken;
    }

    Decode(req, headerType) {
        let self = this;
        try {
            let token = this.Fetch(req);
            if (token) {
                let decodeData = self.jwt.verify(token, process.env.SECRETKEY)
                return decodeData;
            }

            return null;

        } catch (e) {
            console.log("fetch", e);
            return null;
        }
    }

    Fetch(req) {
        try {
            var tokens = req.headers['authorization'];
            if (tokens) {
                var tokenArray = tokens.split(" ");
                if (tokenArray && tokenArray.length > 1) {
                    return tokenArray[1].trim();
                }
                return null;
            }
            return null;
        } catch (e) {
            console.log("fetch", e);
            return null;
        }
    }

    BeforeVerification(req, res, next) {
        let self = this;
        try {
            var token = self.Fetch(req);

            if (token) {
                self.jwt.verify(token, process.env.SECRETKEY,
                    async function (err, decoded) {
                        if (err) {
                            return res.status(401).send(new Exception().ThrowException("1000"));
                        }

                       
                            if(decoded.userID){
                                let UserResult:any = await self.userService.CheckUser(decoded.userID,decoded.deviceUuid);
                                if (UserResult !== null) {
                                        

                                        let userData = self.Decode(req, 'authorization');
                                        req.headers['user'] = userData;
                                        let newToken = self.RefreshToken(decoded);

                                        if (newToken) {
                                            res.set('Authorization', 'Bearer ' + newToken);
                                            next();
                                        } else {
                                            res.set('Authorization', 'Bearer ' + token);
                                            next();
                                        }

                                    
                                } else {
                                    return res.status(401).send([new Exception().ThrowException("1196")]);
                                }
                            }else{
                               return res.status(401).send([new Exception().ThrowException("1196")]); 
                            }
                        




                    });
            }
            else {
                return res.status(401).send(new Exception().ThrowException("1001"));
            }
        } catch (e) {
            console.log("beforeApiCall", e);
            return res.status(401).send(new Exception().ThrowException("1001"));
        }
    }

    AppBeforeVerification(req, res, next) {
        let self = this;
        try {
            //var token = req.headers['appauth']; 
            var token = self.Fetch(req);
            //console.log(token);
            if (token) {
                self.jwt.verify(token, process.env.SECRETKEY,
                    function (err, decoded) {
                        if (err) {
                            return res.status(401).send(new Exception().ThrowException("1000"));
                        }

                        let newToken = self.RefreshToken(decoded);

                        if (newToken) {
                            //res.set('appauth', newToken);
                            res.set('Authorization', 'Bearer ' + newToken);
                            next();
                        } else {
                            //res.set('appauth', token);
                            res.set('Authorization', 'Bearer ' + token);
                            next();
                        }
                    });
            }
            else {
                return res.status(401).send(new Exception().ThrowException("1001"));
            }
        } catch (e) {
            console.log("beforeApiCall", e);
            return res.status(401).send(new Exception().ThrowException("1001"));
        }
    }

    RefreshToken(decoded) {
        let self = this;
        try {
            var token_exp,
                now,
                newToken;

            token_exp = decoded.exp;
            now = moment().unix().valueOf();

            if ((token_exp - now) < expire) {
                var user = decoded;
                newToken = self.GenerateToken(user, false);
                if (newToken) {
                    return newToken;
                }
            } else {
                return null;
            }
        } catch (e) {
            console.log("RefreshToken", e);
            return null;
        }
    }

    GenerateToken(data, expStatus?) {
        let self = this;
        var token;
        if (expStatus) {
            var options = {
                expiresIn: expire
            };
            token = self.jwt.sign(data, process.env.SECRETKEY, options);
        } else {
            token = self.jwt.sign(data, process.env.SECRETKEY);
        }
        return token;
    }

    ErrorVerification(err, req, res, next) {
        let self = this;
        try {
            var token = self.Fetch(req);
            if (token) {
                self.jwt.verify(token, process.env.SECRETKEY,
                    function (err, decoded) {
                        if (err) {
                            return res.status(401).send(new Exception().ThrowException("1000"));
                        }

                        var newToken = self.RefreshToken(decoded);

                        if (newToken) {
                            res.set('Authorization', 'Bearer ' + newToken);
                            next();
                        } else {
                            res.set('Authorization', 'Bearer ' + token);
                            next();
                        }
                    });
            } else {
                return res.status(401).send(new Exception().ThrowException("1001"));
            }
        } catch (e) {
            console.log("errorVerification", e);
            return res.status(401).send(new Exception().ThrowException("1001"));
        }
    }

    authenticate(options, verify) {
        let self = this;
        self.options = xtend(self.defaultOptions, options);
        if (!self.options.secret) {
            throw new TypeError('socket jwt auth requires a secret');
        }

        self.verify = verify;
        if (!self.verify) {
            throw new TypeError('socket jwt auth requires a verify callback');
        }

        return (socket, next) => {
            let token = socket.handshake.query.auth_token;
            let verified = (err, user, message) => {
                if (err) {
                    return next(new Error(err));
                } else if (!user) {
                    if (!self.options.succeedWithoutToken) return next(message, next);
                    socket.request.user = { logged_in: false };
                    return next();
                } else if (user && user === 'user does not exist') {
                    socket.request.user = null;
                    socket.request.err = user;
                    return next();
                } else if (user && user === 'unauthorize') {
                    socket.request.user = null;
                    socket.request.err = user;
                    return next();
                } else {
                    user.logged_in = true;
                    socket.request.user = user;
                    return next();
                }
            };
            try {
                let payload = {};
                if (!token) {
                    self.verify(payload, verified);
                } else {
                    payload = jwtSimple.decode(token, self.options.secret, self.options.algorithm);
                }
                self.verify(payload, verified);
            } catch (ex) {
                next(ex, next);
            }
        }
    }

}