import { Core } from "../../Core";
import { JwtLib } from "../";

export class Middleware extends Core.BaseMiddleware {
    private jwt: JwtLib;

    constructor() {
        super();
        this.jwt = new JwtLib();
    }

    Authorization() {
        let self = this;
        return (req, res, next) => {
            self.jwt.BeforeVerification(req, res, next);
        }
    }

    AppAuthorization() {
        let self = this;
        return (req, res, next) => {
            self.jwt.AppBeforeVerification(req, res, next);
        }
    }
}