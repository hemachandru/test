import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo } from 'sequelize-typescript';
import { Region } from '../../General/models/Region';
import { Document } from "./Document";
import { Country } from '../../General/models/Country';

@Table({
    tableName: "tblContacts"
})

export class Contact extends Model<Contact> {

    @AutoIncrement
    @PrimaryKey
    @Column
    contactId: number;

    @Column
    firstName: string;

    @Column
    lastName: string;

    @Column
    dob: Date;

    @Column
    gender: string;

    @Column
    landline: string;

    @Column
    mobile: string;

    @Column
    fax: string;

    @Column
    email: string;

    @Column
    address1: string;

    @Column
    address2: string;

    @Column
    postalCode: string;

    @Column
    city: string;

    @Column
    state: string;

    @ForeignKey(() => Country)
    @Column
    countryId: number;

    @ForeignKey(() => Document)
    @Column
    photoId: number;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @BelongsTo(() => Region)
    region: Region;

    @BelongsTo(() => Country)
    country: Country;

    @BelongsTo(() => Document)
    document: Document;
}