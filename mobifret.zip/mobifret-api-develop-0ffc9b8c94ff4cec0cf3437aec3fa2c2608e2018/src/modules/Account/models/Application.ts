import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope } from 'sequelize-typescript';

@Table({
    tableName: "tblApplications"
})

export class Application extends Model<Application> {

    @AutoIncrement
    @PrimaryKey
    @Column
    applicationId: number;

    @Column
    clientKey: string;

    @Column
    secretKey: string;
}