import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, CreatedAt, UpdatedAt } from 'sequelize-typescript';

@Table({
    timestamps: true,
    tableName: "tblGuests"
})

export class Guest extends Model<Guest> {

    @AutoIncrement
    @PrimaryKey
    @Column
    guestId: number;

    @Column
    email: string;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;
}