import { Table, Column, Model, AutoIncrement, PrimaryKey } from 'sequelize-typescript';

@Table({
    tableName: "tblUserTypes"
})

export class UserType extends Model<UserType> {

    @AutoIncrement
    @PrimaryKey
    @Column
    userTypeId: number;

    @Column
    userType: string;
}