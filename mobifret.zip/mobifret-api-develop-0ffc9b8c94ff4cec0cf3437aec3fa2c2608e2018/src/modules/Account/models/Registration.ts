import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, HasMany, DataType, CreatedAt, UpdatedAt } from 'sequelize-typescript';
import { RegistrationType } from "./RegistrationType";
import { Region } from '../../General/models/Region';
import { Contact } from "./Contact";
import { CompanyDetail } from './CompanyDetail';

@Table({
    tableName: "tblRegistrations"
})

export class Registration extends Model<Registration> {

    @AutoIncrement
    @PrimaryKey
    @Column
    registrationId: number;

    @Column
    companyName: string;

    @Column
    companyId: string;

    @Column
    startDate: Date;

    @Column
    endDate: Date;

    @ForeignKey(() => RegistrationType)
    @Column
    registrationTypeId: number;

    @Column
    verificationCode: string;

    @Column
    codeSentAt: Date;

    @Column
    verifiedAt: Date;

    @Column
    isActive: boolean;

    @ForeignKey(() => Contact)
    @Column
    contactId: number;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @Column(DataType.FLOAT)
    mobifretMargin: number;

    @Column(DataType.FLOAT)
    companyMargin: number;

    @BelongsTo(() => RegistrationType)
    registrationType: RegistrationType;

    @BelongsTo(() => Region)
    region: Region;

    @HasMany(() => CompanyDetail, 'registrationId')
    companydetails: CompanyDetail[];

    @BelongsTo(() => Contact)
    companyContact: Contact;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;
}