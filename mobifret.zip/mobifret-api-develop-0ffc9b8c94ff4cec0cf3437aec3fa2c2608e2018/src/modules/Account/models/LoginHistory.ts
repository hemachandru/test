import {  Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, DataType, HasMany  } from 'sequelize-typescript';
import { User } from "./User";

@Table({
    tableName: "tblLoginHistory"
})

export class LoginHistory extends Model<LoginHistory> {

  @AutoIncrement
  @PrimaryKey
  @Column
  loginHistoryId:number;

  @ForeignKey(() => User)
  @Column
  userId: number;
  
  @BelongsTo(() => User)
  user: User;

  @Column
  languageCode:string;

  @Column(DataType.DATE)
  intime:Date;

  @Column(DataType.DATE)
  outtime:Date;

  @Column
  deviceUuid:string

  @Column(DataType.DATE)
  createdAt:Date;

  @Column(DataType.DATE)
  updatedAt:Date;
}