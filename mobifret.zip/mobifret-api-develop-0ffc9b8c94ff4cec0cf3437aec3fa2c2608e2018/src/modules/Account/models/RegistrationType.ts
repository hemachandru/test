import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope } from 'sequelize-typescript';

@Table({
    tableName: "tblRegistrationTypes"
})

export class RegistrationType extends Model<RegistrationType> {

    @AutoIncrement
    @PrimaryKey
    @Column
    registrationTypeId: number;

    @Column
    registrationType: string;
}