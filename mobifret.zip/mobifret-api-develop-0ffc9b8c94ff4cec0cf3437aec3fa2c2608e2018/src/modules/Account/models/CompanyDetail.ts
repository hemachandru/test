import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo } from 'sequelize-typescript';
import { Registration } from './Registration';
import { Document } from './Document';

@Table({
    tableName: "tblCompanyDetails"
})
export class CompanyDetail extends Model<CompanyDetail> {

    @AutoIncrement
    @PrimaryKey
    @Column
    companyDetailId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @Column
    siret: string;

    @Column
    codeNaf: string;

    @Column
    tva: string;

    @ForeignKey(() => Document)
    @Column
    kbisDocumentId: number;

    @Column
    licenceNumber: string;

    @ForeignKey(() => Document)
    @Column
    licenceDocumentId: number;

    @Column
    licenceExpiryAt: Date;

    @Column
    urssaf: string;

    @ForeignKey(() => Document)
    @Column
    urssafDocumentId: number;

    @Column
    urssafExpiryAt: Date;

    @BelongsTo(() => Registration)
    registration: Registration;

    @BelongsTo(() => Document)
    document: Document;
}