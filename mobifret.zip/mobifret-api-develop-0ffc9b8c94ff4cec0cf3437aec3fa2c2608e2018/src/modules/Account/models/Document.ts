import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, DataType, CreatedAt, UpdatedAt } from 'sequelize-typescript';

@Table({
    timestamps: true,
    tableName: "tblDocuments"
})

export class Document extends Model<Document> {

    @AutoIncrement
    @PrimaryKey
    @Column
    documentId: number;

    @Column(DataType.ENUM('photo', 'document'))
    documentType: 'photo' | 'document';

    @Column
    document: string;

    @CreatedAt
    createdAt: Date;

    @UpdatedAt
    updatedAt: Date;

}