import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope } from 'sequelize-typescript';
import { User } from "./User";

@Table({
    tableName: "tblDevices"
})

export class Device extends Model<Device> {

    @AutoIncrement
    @PrimaryKey
    @Column
    deviceId: number;

    @ForeignKey(() => User)
    @Column
    userId: number;

    @Column
    deviceUuid: string;

    @Column
    deviceToken: string;

    @Column
    deviceArn: string;

    @Column
    deviceType: string;

    @Column
    deviceOs: string;

    @Column
    status: boolean;
}