import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, DataType } from 'sequelize-typescript';

@Table({
    tableName: "tblRunningPrefixes"
})

export class RunningPrefixes extends Model<RunningPrefixes> {

    @AutoIncrement
    @PrimaryKey
    @Column
    runningPrefixesId: number;

    @Column
    consPrefix: string;

    @Column
    runningPrefix: string;

    @Column(DataType.ENUM('clientCompany', 'clientIndividual', 'partnerCompany', 'partnerIndividual', 'driver', 'vehicle'))
    prefixFor: 'clientCompany' | 'clientIndividual' | 'partnerCompany' | 'partnerIndividual' | 'driver' | 'vehicle';
}