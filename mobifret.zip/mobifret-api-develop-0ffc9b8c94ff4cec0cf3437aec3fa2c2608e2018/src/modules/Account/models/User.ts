import { Table, Column, Model, HasOne, AutoIncrement, PrimaryKey, ForeignKey, DefaultScope, BelongsTo, HasMany } from 'sequelize-typescript';
import { Registration } from "./Registration";
import { Contact } from "./Contact";
import { Region } from '../../General/models/Region';
import { UserType } from "./UserType";
import { Driver } from "../../DriverMission/models/Driver";
import { Device } from "./Device";
import { LoginHistory } from "./LoginHistory";


@Table({
    tableName: "tblUsers"
})

export class User extends Model<User> {

    @AutoIncrement
    @PrimaryKey
    @Column
    userId: number;

    @ForeignKey(() => Registration)
    @Column
    registrationId: number;

    @ForeignKey(() => Contact)
    @Column
    contactId: number;

    @Column
    userName: string;

    @Column
    currentPassword: string;

    @Column
    passwordOne: string;

    @Column
    passwordTwo: string;

    @Column
    passwordThree: string;

    @ForeignKey(() => Region)
    @Column
    regionId: number;

    @ForeignKey(() => UserType)
    @Column
    userTypeId: number;

    @BelongsTo(() => Registration)
    registration: Registration;

    @BelongsTo(() => Contact)
    contact: Contact;

    @BelongsTo(() => Region)
    region: Region;

    @BelongsTo(() => UserType)
    userType: UserType;

    @HasOne(() => Driver)
    driver: Driver;

    @HasMany(() => Device)
    device: Device[];

    @HasMany(() => LoginHistory)
    loginHistory: LoginHistory[];

}