import { IAccountBusiness } from './IAccountBusiness';
import { User } from '../models/User';
import { Guest } from "../models/Guest";
import { UserService } from '../service/UserService';
import { ContactService } from "../service/ContactService";
import { GuestService } from '../service/GuestService';
import { JwtLib } from "../";
import { ApplicationService } from "../service/ApplicationService";
import { RegistrationService } from "../service/RegistrationService";
import { DocumentService } from "../service/DocumentService";
import { CompanyDetailService } from "../service/CompanyDetailService";
import { Mailer } from '../mailer';
import { S3Lib, SnsLib } from '../../../helper';
import { Device } from "../models/Device";
import { DeviceService } from "../service/DeviceService";
const bcrypt = require('bcrypt');
const saltRounds = 10;

let path = require("path");
let fs = require('fs');
let ejs = require('ejs');

export class AccountBuisness implements IAccountBusiness {
    private userService = new UserService();
    private deviceService = new DeviceService();
    private contactService = new ContactService();
    private registrationService = new RegistrationService();
    private applicationService = new ApplicationService();
    private documentService = new DocumentService();
    private companyService = new CompanyDetailService();
    private guestService = new GuestService();
    private jwtlib = new JwtLib();
    private s3 = new S3Lib();
    private sns = new SnsLib();

    constructor() {

    }

    async DeviceEntry(device: Device, userId: number, status: boolean) {
        let _device = await this.deviceService.GetDevice(device, userId);
        if (_device) {
            await this.deviceService.PutDevice(device, userId, status);
            return _device;
        }

        device.userId = userId;
        await this.deviceService.PostDevice(device);
        return device;

    }

    async UpdateDevice(device: any) {
        let _updateStatus = await this.deviceService.UpdateDevice(device);
        return _updateStatus;

    }

    async LogoutDevice(device: any, userId: number, status: boolean) {
        return await this.deviceService.PutDevice(device, userId, status);
    }

    async CheckUserName(username: string): Promise<User> {
        let user;
        user = await this.userService.CheckUsername(username);
        if (user) {
            if (user.userTypeId == 6) {
                let driverActive = await this.userService.CheckDriverActive(user.userId);
                if (driverActive) {
                    return user;
                } else {
                    return null;
                }
            }
            return user;
        }
        return null;
    }

    async CheckLoginHistory(userId: any): Promise<User> {
        let user;
        user = await this.userService.CheckLoginHistory(userId);
        if (user) {
            return user;
        }
        return null;
    }



    async LoginUser(password: string, user: User, device: Device): Promise<string> {

        let deCrptPass = await this.ReplacePSWDStr(user.currentPassword);
        let check = await bcrypt.compare(password, deCrptPass);
        if (check) {
            let tokenData = {
                userID: user.userId,
                roleID: user.userType.userTypeId
            }

            if (device) {
                tokenData["deviceUuid"] = device.deviceUuid;
            }
            let token = this.jwtlib.GenerateToken(tokenData);
            return token;
        }
        return null;
    }

    async ReplacePSWDStr(DBPassword: string): Promise<string> {
        var replaceStr;
        var passwordStr = DBPassword;

        if (passwordStr.substr(1, 2) == '2y') {
            replaceStr = passwordStr.substr(0, 2) + 'a' + passwordStr.substr(2 + 1);
        } else {
            replaceStr = DBPassword;
        }
        return replaceStr;
    }

    async GuestLoginUser(username: string, device: Device): Promise<string> {
        let guest: any = {
            email: username
        };
        try {
            let saveGuest = await this.guestService.PostGuest(guest);
        } catch (e) {
            console.log(e);
        } finally {
            if (device) {
                guest["deviceUuid"] = device.deviceUuid;
            }
        }
        
        let token = this.jwtlib.GenerateToken(guest);
        return token;

    }

    async GetCurrentUser(userId: number): Promise<User> {
        let user = await this.userService.GetCurrentUser(userId);
        return user;
    }

    async CheckEmail(email: string): Promise<Boolean> {
        let status = await this.contactService.CheckEmail(email);
        return status;
    }

    async ForgetPassword(username: string, password: string, userDetail: any): Promise<Boolean> {
        let hashPassword = await bcrypt.hash(password, saltRounds);
        let updatePassword = await this.userService.ChangePassword(username, hashPassword);
        let templatepath = path.resolve(__dirname, '..', '..', '..', '..') + '/src/modules/Account/mailer/forgotPassword.ejs';
        let template = await fs.readFileSync(templatepath, 'utf8');
        let usernode = {
            name: userDetail.contact.firstName + " " + userDetail.contact.lastName,
            password: password
        }

        let templateContent = await ejs.render(template, {
            user: usernode,
            url: ''
        });

        let mailOpt = {
            to: username,
            subject: 'Forgot Password',
            html: templateContent
        };

        if (updatePassword) {
            let result: any = await new Mailer().SendMail(mailOpt);
            if (result) {
                return true;
            }
            return false;
        }
    }

    ForgetUsername(email: string): string {
        return "";
    }

    GenerateRandomString(len) {
        var text = "";
        var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }

    async RegisterUser(account: any, device: Device): Promise<string> {
        try {
            let hashPassword = await bcrypt.hash(account.contact.password, saltRounds);
            let photoResult;
            let documentResult;

            if (account.contact.profile_image) {
                let photoDestination = "api/registration/profile/" + this.GenerateRandomString(15) + "_" + new Date().getTime() + ".jpg";
                let photoS3 = await this.s3.CopyObjectPublic("/" + account.contact.profile_image, photoDestination);
                let photoDocument: any = {
                    documentType: 'photo',
                    document: photoS3 ? photoDestination : null
                }
                photoResult = await this.documentService.PostDocument(photoDocument);
            }

            let contact: any = {
                firstName: account.contact.firstname,
                lastName: account.contact.lastname,
                dob: account.contact.dob ? account.contact.dob : null,
                landline: account.contact.landline ? account.contact.landline : null,
                mobile: account.contact.mobile,
                email: account.contact.email,
                address1: account.contact.address1 ? account.contact.address1 : null,
                address2: account.contact.address2 ? account.contact.address2 : null,
                postalCode: account.contact.postalcode ? account.contact.postalcode : null,
                city: account.contact.city ? account.contact.city : null,
                state: account.contact.state ? account.contact.state : null,
                countryId: account.contact.country ? account.contact.country : null,
                photoId: account.contact.profile_image ? photoResult.getDataValue("documentId") : null,
                regionId: account.contact.region_id ? account.contact.region_id : null
            }

            let contactResult = await this.contactService.PostContact(contact);

            let registration: any = {
                companyName: account.registration.companyname ? account.registration.companyname : null,
                contactId: contactResult.getDataValue("contactId"),
                registrationTypeId: account.registration.registration_type_id,
                isActive: true,
                regionId: account.contact.region_id ? account.contact.region_id : null,
            }

            let registrationResult = await this.registrationService.PostRegistration(registration);
            if (registrationResult) {
                if (account.registration.registration_type_id == 3) {
                    let compnayPrefix = "clientIndividual";
                    let registrationId = registrationResult.getDataValue("registrationId");
                    let compnayPrefixResult = await this.registrationService.GetRunningPrefix(compnayPrefix);
                    let companyId = compnayPrefixResult.consPrefix ? compnayPrefixResult.consPrefix + registrationId : registrationId;
                    await this.registrationService.UpdateRunningPrefix(registrationId, companyId);
                }

                if (account.registration.registration_type_id == 2) {
                    let compnayPrefix = "clientCompany";
                    let registrationId = registrationResult.getDataValue("registrationId");
                    let compnayPrefixResult = await this.registrationService.GetRunningPrefix(compnayPrefix);
                    let companyId = compnayPrefixResult.consPrefix ? compnayPrefixResult.consPrefix + registrationId : registrationId;
                    await this.registrationService.UpdateRunningPrefix(registrationId, companyId);
                }
            }

            if (account.registration.registration_type_id == 2) {

                if (account.company.document_image) {
                    let documentDestination = "api/registration/document/" + this.GenerateRandomString(15) + "_" + new Date().getTime() + ".jpg";
                    let documentS3 = await this.s3.CopyObjectPrivate("/" + account.company.document_image, documentDestination);
                    let documentDocument: any = {
                        documentType: 'document',
                        document: documentS3 ? documentDestination : null
                    }
                    documentResult = await this.documentService.PostDocument(documentDocument);
                }

                let company: any = {
                    siret: account.company.siret,
                    tva: account.company.tva,
                    codeNaf: account.company.codeNaf ? account.company.codeNaf : null,
                    registrationId: registrationResult.getDataValue("registrationId"),
                    kbisDocumentId: account.company.document_image ? documentResult.getDataValue("documentId") : null
                }

                let companyResult = await this.companyService.PostCompanyDetail(company);
            }

            let user: any = {
                userName: account.contact.email,
                registrationId: registrationResult.getDataValue("registrationId"),
                contactId: contactResult.getDataValue("contactId"),
                currentPassword: hashPassword,
                regionId: account.contact.region_id ? account.contact.region_id : null,
                userTypeId: account.registration.registration_type_id
            }

            let userResult = await this.userService.PostUser(user);
            let tokenData = {
                userID: userResult.getDataValue("userId"),
                roleID: userResult.getDataValue("userTypeId")
            }

            if (device) {
                device.userId = userResult.getDataValue("userId");
                let checkDeviceUID = await this.deviceService.checkDeviceUuID(device.deviceUuid);
                if (!checkDeviceUID)
                    await this.deviceService.PostDevice(device);
                tokenData["deviceUuid"] = device.deviceUuid;
                if (!device.deviceArn && device.deviceType && device.deviceUuid)
                    this.sns.registerDevice(device, process.env["SNS_" + device.deviceType + "_ARN"]);
            }

            let token = this.jwtlib.GenerateToken(tokenData);

            return token;

        } catch (e) {
            console.log(e);
        }
    }

    async AppAuth(secretKey: string, clientKey: string): Promise<string> {
        let result = await this.applicationService.GetKeys(secretKey, clientKey);
        if (result) {
            let token = this.jwtlib.GenerateToken(result);
            return token;
        } else {
            return null;
        }
    }

    async PasswordHash(password: any): Promise<any> {
        let hashPassword = await bcrypt.hash(password, saltRounds);
        return hashPassword;
    }


    async DriveInfo(id: any): Promise<any> {
        let result = await this.userService.GetDriverInfo(id);
        return result;
    }

    async CheckDriverActive(driverid: any): Promise<any> {
        let result = await this.userService.CheckDriverActive(driverid);
        return result;
    }

    async ChangePasswordHash(userid: any, password: any): Promise<any> {
        let hashPassword = await bcrypt.hash(password, saltRounds);
        let result = await this.userService.ChangePasswordUserId(userid, hashPassword);
        return result;
    }

    async GetRegisterIdDetail(registerid: any): Promise<any> {
        let result = await this.userService.GetRegisterIdDetail(registerid);
        return result;
    }

    async TestAPI(reqData: any): Promise<Boolean> {
        //s3 bucket find object test
        let result = await this.s3.FindObject(reqData.path);
        return result;

        // let templatepath = path.resolve(__dirname, '..', '..', '..', '..') + '/src/modules/Account/mailer/forgotPassword.ejs';
        // let template = await fs.readFileSync(templatepath, 'utf8');
        // let temp = await ejs.render(template, {
        //     user: "Sivakavi"
        // });

        // let mailOtp = {
        //     to: reqData.to,
        //     subject: reqData.subject,
        //     html: temp
        // }

        // // smtp email test
        // let result = await new Mailer().SendMail(mailOtp);
        // return result;

    }

    async SetLoginHistroy(UserObject: any, requestObject: any): Promise<any> {
        let LoginObject: Object = {
            "userId": UserObject.userId,
            "languageCode": parseInt(requestObject.languageId) === 1 ? 'en' : 'fr',
            "intime": new Date(),
            "outtime": null
        }
        if (requestObject.device) {
            LoginObject["deviceUuid"] = requestObject.device.deviceUuid
        }
        let user = await this.userService.SetLoginHistroy(LoginObject);
        return user;
    }
    
    async LogoutLoginHistory(userId: number) {
        return await this.userService.PutLoginHistory(userId);
    }

    async SetLoginHistroyOnRegister(UserObject: any, requestObject: any): Promise<any> {
        let LoginObject: Object = {
            "userId": UserObject.userId,
            "languageCode": parseInt(requestObject.languageId) === 1 ? 'en' : 'fr',
            "intime": new Date(),
            "outtime": new Date()
        }
        if (requestObject.device) {
            LoginObject["deviceUuid"] = requestObject.device.deviceUuid
        }
        let user = await this.userService.SetLoginHistroy(LoginObject);
        return user;
    }
}