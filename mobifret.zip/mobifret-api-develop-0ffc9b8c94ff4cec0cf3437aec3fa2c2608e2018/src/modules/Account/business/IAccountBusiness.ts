import { User } from '../models/User';
import { Device } from "../models/Device";

export interface IAccountBusiness {
    LoginUser(passwod: string, user: User, device: Device): Promise<string>,
    ForgetPassword(username: string, password: string, CheckUserName: any): Promise<Boolean>,
    ForgetUsername(email: string): string,
    RegisterUser(user: User, device: Device): Promise<string>,
    CheckUserName(username: string): Promise<User>
}