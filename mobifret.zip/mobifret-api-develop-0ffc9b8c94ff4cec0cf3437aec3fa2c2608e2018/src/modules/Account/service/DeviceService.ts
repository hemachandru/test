import { Request, Response } from "express";
import { Core } from "../../Core";
import { Device } from "../models/Device";

export class DeviceService extends Core.BaseService {

    async GetDevice(device: Device, userId: number): Promise<Device> {
        try {
            let result = await Device.findOne<Device>({ where: { deviceUuid: device.deviceUuid, deviceToken: device.deviceToken }, raw: true });
            return result;
        } catch (e) {
            throw e;
        }
    }

    // async GetDevice(device: Device, userId: number): Promise<Device> {
    //     try {
    //         let result = await Device.findOne<Device>({ where: { deviceUuid: device.deviceUuid, userId: userId }, raw: true });
    //         return result;
    //     } catch (e) {
    //         throw e;
    //     }
    // }


    async checkDeviceUuID(deviceUID: any): Promise<Device> {
        try {
            let result = await Device.findOne<Device>({ where: { deviceUuid: deviceUID }, raw: true });
            return result;
        } catch (e) {
            throw e;
        }
    }

    async PostDevice(device: Device): Promise<Device> {
        try {
            const _device = new Device(device);
            let result = await _device.save();
            return result;
        } catch (e) {
            throw e;
        }
    }

    async PutDevice(device: any, userId: number, status: boolean): Promise<boolean> {
        try {
            let deviceData: any = {
                status: status,
                userId: userId
            }
            let result = await Device.update<Device>(deviceData, { where: { deviceUuid: device.deviceUuid,deviceToken: device.deviceToken } });
            if (result)
                return true;

            return false;
        } catch (e) {
            throw e;
        }
    }

    // async PutDevice(device: any, userId: number, status: boolean): Promise<boolean> {
    //     try {
    //         let result = await Device.update<Device>({ status: status }, { where: { deviceUuid: device.deviceUuid, userId: userId } });
    //         if (result)
    //             return true;

    //         return false;
    //     } catch (e) {
    //         throw e;
    //     }
    // }

    async UpdateDevice(device: any): Promise<boolean> {
        try {
            let result = await Device.update<Device>(device, { where: { deviceUuid: device.deviceUuid } });
            if (result)
                return true;

            return false;
        } catch (e) {
            throw e;
        }
    }

    // async UpdateDevice(device: any): Promise<boolean> {
    //     try {
    //         let result = await Device.update<Device>(device, { where: { deviceUuid: device.deviceUuid, userId: device.userId } });
    //         if (result)
    //             return true;

    //         return false;
    //     } catch (e) {
    //         throw e;
    //     }
    // }

    async GetDeviceUser(userId: any): Promise<Device[]> {
        try {
            let result = await Device.findAll<Device>({ where: { userId: userId, status: true } });
            return result;
        } catch (e) {
            throw e;
        }
    }
}