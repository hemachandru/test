
import { Core } from "../../Core";
import { Registration } from "../models/Registration";
import { CompanyDetail } from "../models/CompanyDetail";


export class CompanyDetailService extends Core.BaseService {

    async PostCompanyDetail(objUserRole: CompanyDetail): Promise<CompanyDetail> {
        try {
            const companyDetail = new CompanyDetail(objUserRole);
            let result = await companyDetail.save();
            return result;
        } catch (e) {
            throw e;
        }
    }

    //Update personal information
    async UpdateCompanyDetail(registrationid: number, companydetails: any): Promise<any> {
        try {
            let result = await CompanyDetail.update<CompanyDetail>(companydetails, { where: { registrationId: registrationid } });
            return result;
        } catch (e) {
            return e;
        }
    }


    //Update personal information
    async UpdateCompanyName(registrationid: any, companyname: any): Promise<any> {
        try {
            let result = await Registration.update<Registration>({ companyName: companyname }, { where: { registrationId: registrationid } });
            return result;
        } catch (e) {
            return e;
        }
    }

}