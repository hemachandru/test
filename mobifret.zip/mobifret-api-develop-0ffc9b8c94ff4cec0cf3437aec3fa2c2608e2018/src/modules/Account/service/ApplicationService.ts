import { Request, Response } from "express";
import { Core } from "../../Core";
import { Application } from "../models/Application";

export class ApplicationService extends Core.BaseService {

    async GetKeys(secretKey: string, clientKey: string): Promise<Application> {
        try {
            let result = await Application.findOne<Application>({ where: { clientKey: clientKey, secretKey: secretKey }, raw: true });
            return result;
        } catch (e) {
            throw e;
        }
    }
}