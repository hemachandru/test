import { Core } from "../../Core";
import { Guest } from "../models/Guest";

export class GuestService extends Core.BaseService {

    async PostGuest(objGuest: Guest): Promise<Guest> {
        try {
            const guest = new Guest(objGuest);
            let result = await guest.save();
            return result;
        } catch (e) {
            throw e;
        }
    }
}