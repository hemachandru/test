import { Request, Response } from "express";
import { Core } from "../../Core";
import { Document } from "../models/Document";

export class DocumentService extends Core.BaseService {

    async PostDocument(objDocument: Document): Promise<Document> {
        try {
            const document = new Document(objDocument);
            let result = await document.save();
            return result;
        } catch (e) {
            throw e;
        }
    }

}