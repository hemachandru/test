import { Request, Response } from "express";
import { Core } from "../../Core";
import { Registration } from "../models/Registration";
import { RunningPrefixes } from "../models/RunningPrefixes";

export class RegistrationService extends Core.BaseService {

    async PostRegistration(objRegistration: Registration): Promise<Registration> {
        try {
            const registration = new Registration(objRegistration);
            let result = await registration.save();
            return result;
        } catch (e) {
            throw e;
        }
    }

    async GetRunningPrefix(prefix: any): Promise<any> {
        try {
            let result = await RunningPrefixes.find<RunningPrefixes>({ where: { prefixFor: prefix } });
            return result;
        } catch (e) {
            throw e;
        }
    }

    async UpdateRunningPrefix(registerid: any, companyid): Promise<any> {
        try {
            let result = await Registration.update<Registration>({ "companyId": companyid }, {
                where: {
                    registrationId: registerid
                }
            });
            return result;
        } catch (e) {
            return e;
            // console.error(e);
            // return e;
        }
    }

}