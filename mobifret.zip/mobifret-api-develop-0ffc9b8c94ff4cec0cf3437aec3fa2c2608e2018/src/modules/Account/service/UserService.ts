import { Request, Response } from "express";
import { Core } from "../../Core";
import { User } from "../models/User";
import { UserType } from "../models/UserType";
import { Registration } from "../models/Registration";
import { Contact } from "../models/Contact";
import { Document } from "../models/Document";
import { Region } from '../../General/models/Region';
import { Country } from '../../General/models/Country';
import { Driver } from "../../DriverMission/models/Driver";
import { Device } from "../models/Device";
import { CompanyDetail } from "../models/CompanyDetail";
import { read } from "fs";
import { Vehicle } from "../../DriverMission/models/Vehicle";
import { LoginHistory } from "../models/LoginHistory"; 

export class UserService extends Core.BaseService {

    async LoginUser(username: string, password: string): Promise<User> {
        try {
            let result = await User.findOne<User>({ where: { userName: username, currentPassword: password }, raw: true });
            return result;
        } catch (e) {
            throw e;
        }
    }

    async GetCurrentUser(userId: number): Promise<User> {
        try {
            let result = await User.findOne<User>({
                where: { userId: userId },
                include: [
                    {
                        model: Contact,
                        include: [Country, Document]
                    },
                    {
                        model: Registration,
                        include: [{
                            model: CompanyDetail,
                        }
                        ]
                    }, {
                        model: Driver,
                        include: [{
                            model: Vehicle,
                            where: {
                                deletedAt: {
                                    $eq: null
                                }
                            },
                            required: false
                        }]
                    }, UserType, Region, Device]
            });
            if (result) {
                return result.toJSON();
            }

            return null;
        } catch (e) {
            throw e;
        }
    }

    async CheckUsername(username: string): Promise<User> {
        try {
            let result = await User.findOne<User>({
                where: {
                    userName: username
                },
                include: [ UserType, 
                           Contact,
                        ]
            });
            if (result) {
                return result.toJSON();
            }
            return null;
        } catch (e) {
            throw e;
        }
    }

    async CheckLoginHistory(userId: string): Promise<User> {
        try {
            let result = await LoginHistory.findOne<User>({
                where: {
                    userId: userId,
                    outtime: null
                }
            });
            if (result) {
                return result.toJSON();
            }
            return null;
        } catch (e) {
            throw e;
        }
    }

    async PostUser(objUser: User): Promise<User> {
        try {
            let user = new User(objUser);
            let result = await user.save();
            return result;
        } catch (e) {
            throw e;
        }
    }

    async ChangePassword(username: string, password: string): Promise<Boolean> {
        try {
            let user = await User.findOne<User>({ where: { userName: username } });
            user.currentPassword = password;
            let userUpdate = await user.save();
            if (user) {
                return true;
            }
            return false;
        } catch (e) {
            throw e;
        }
    }

    async ChangePasswordUserId(userId: number, password: string): Promise<Boolean> {
        try {
            let user = await User.findOne<User>({ where: { userId: userId } });
            user.currentPassword = password;
            let userUpdate = await user.save();
            if (user) {
                return true;
            }
            return false;
        } catch (e) {
            throw e;
        }
    }

    async GetDriverInfo(driverid: any): Promise<any> {
        try {
            let result = await Driver.findAll<Driver>({
                include: [{
                    model: User,
                    attributes: ['userId', 'registrationId'],
                }],
                where: {
                    driverId: driverid
                }
            });
            return result;
        } catch (e) {
            return e;
        }
    }

    async CheckDriverActive(userid: any): Promise<any> {
        try {
            let result = await Driver.find<Driver>({
                where: {
                    userId: userid,
                    isActive: 1
                }
            });
            return result;
        } catch (e) {
            return e;
        }
    }

    async GetRegisterIdDetail(registrationid: any): Promise<any> {
        try {
            let result = await User.findOne<User>({
                where: {
                    registrationId: registrationid
                },
            });
            if (result) {
                return result.toJSON();
            }
            return null;
        } catch (e) {
            throw e;
        }
    }


    async SetLoginHistroy(loginObject: any): Promise<any> {
        try {
            const LoginHistoryInfoObject = new LoginHistory(loginObject);
            let result = await LoginHistoryInfoObject.save();
            return result.toJSON();
        } catch (e) {
            throw e;
        }
    }

    async PutLoginHistory(userId: number): Promise<any> {
        try {
            let result = await LoginHistory.update<LoginHistory>({ outtime: new Date() }, { where: { userId: userId, outtime: { $eq: null } } });
            if (result)
                return true;

            return false;
        } catch (e) {
            throw e;
        }
    }
    
    async CheckUser(UserId: number, deviceUuid: any): Promise<any> {
        let result = await User.find({
            attributes: ['userId'],
            include: [{
                attributes: ['loginHistoryId'],
                model: LoginHistory,
                where: {
                    deviceUuid: deviceUuid,
                    outtime: { $eq: null }
                }
            }],
            where: { userId: UserId },
            raw: true
        });
        return result
    }
}