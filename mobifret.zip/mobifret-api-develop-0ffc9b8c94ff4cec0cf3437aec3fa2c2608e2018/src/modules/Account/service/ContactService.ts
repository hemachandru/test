import { Request, Response } from "express";
import { Core } from "../../Core";
import { Contact } from "../models/Contact";


export class ContactService extends Core.BaseService {

    async CheckEmail(email: string): Promise<Boolean> {
        try {
            let result = await Contact.findOne<Contact>({ where: { email: email }, raw: true });

            if (result) {
                return true;
            }
            return false;
        } catch (e) {
            throw e;
        }
    }

    async PostContact(objContact: Contact): Promise<Contact> {
        try {
            const contact = new Contact(objContact);
            let result = await contact.save();
            return result;
        } catch (e) {
            throw e;
        }
    }


    //Update personal information
    async updateContact(contactid: number, personalInfo: any): Promise<any> {
        try {
            let result = await Contact.update<Contact>(personalInfo, { where: { contactId: contactid } });
            return result;
        } catch (e) {
            return e;
        }
    }




}