import { UserService } from "../index";
import { Exception } from "../exception";
const bcrypt = require('bcrypt');

export class Validation {
    private error = [];
    constructor() {
        this.error = [];
    }
    
    async ReplacePSWDStr(DBPassword: string): Promise<string> {
        var replaceStr;
        var passwordStr = DBPassword;

        if (passwordStr.substr(1, 2) == '2y') {
            replaceStr = passwordStr.substr(0, 2) + 'a' + passwordStr.substr(2 + 1);
        } else {
            replaceStr = DBPassword;
        }
        return replaceStr;
    }

    LoginValidate(data: any) {
        this.error = [];
        if (!data.username) {
            this.error.push(new Exception().ThrowException("1003"));
        }

        if (!data.password) {
            this.error.push(new Exception().ThrowException("1008"));
        }
        return this.handler(this.error);
    }

    AppValidate(data: any) {
        this.error = [];
        if (!data.secretKey || !data.clientKey) {
            this.error.push(new Exception().ThrowException("1007"));
        }
        return this.handler(this.error);
    }

    async ChangePasswordValidate(user: any, data: any) {
        this.error = [];
        if (!data.old_password) {
            this.error.push(new Exception().ThrowException("1032"));
        } else {
            let deCrptPass = await this.ReplacePSWDStr(user.currentPassword);
            let check = await bcrypt.compare(data.old_password, deCrptPass);
            if (!check) {
                this.error.push(new Exception().ThrowException("1030"));
            }
        }

        if (!data.new_password) {
            this.error.push(new Exception().ThrowException("1031"));
        }
        return this.handler(this.error);
    }

    GustLoginValidate(data: any) {
        this.error = [];
        if (!data.username) {
            this.error.push(new Exception().ThrowException("1003"));
        }

        if (data.username) {
            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(data.username))) {
                this.error.push(new Exception().ThrowException("1004"));
            }
        }
        return this.handler(this.error);
    }

    // ForgotPasswordValidation(data: any){
    //     this.error = [];
    //     if (!data.username) {
    //         this.error.push(new Exception().ThrowException("1003"));
    //     }

    //     if (data.username) {
    //         if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(data.username))) {
    //             this.error.push(new Exception().ThrowException("1004"));
    //         }
    //     }
    //     return this.handler(this.error);
    // }

    RegistrationValidation(data: any) {
        this.error = [];

        if (!data.contact.firstname) {
            this.error.push(new Exception().ThrowException("1011"));
        }

        if (!data.contact.lastname) {
            this.error.push(new Exception().ThrowException("1012"));
        }

        if (!data.contact.mobile) {
            this.error.push(new Exception().ThrowException("1013"));
        }

        if (!data.contact.email) {
            this.error.push(new Exception().ThrowException("1016"));
        }

        if (data.contact.email) {
            if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(data.contact.email))) {
                this.error.push(new Exception().ThrowException("1004"));
            }
        }

        if (!data.contact.password) {
            this.error.push(new Exception().ThrowException("1008"));
        }

        // if (data.contact.password != data.contact.cpassword) {
        //     this.error.push(new Exception().ThrowException("1017"));
        // }

        if (!data.registration.registration_type_id) {
            this.error.push(new Exception().ThrowException("1015"));
        }

        if (data.registration.registration_type_id == 2) {
            if (!data.registration.companyname) {
                this.error.push(new Exception().ThrowException("1021"));
            }
            if (!data.contact.landline) {
                this.error.push(new Exception().ThrowException("1018"));
            }
            if (!data.contact.address1) {
                this.error.push(new Exception().ThrowException("1022"));
            }
            if (!data.contact.postalcode) {
                this.error.push(new Exception().ThrowException("1023"));
            }
            // if (!data.contact.region_id) {
            //     this.error.push(new Exception().ThrowException("1024"));
            // }
            if (!data.contact.country) {
                this.error.push(new Exception().ThrowException("1025"));
            }
            if (data.company) {
                if (!data.company.siret) {
                    this.error.push(new Exception().ThrowException("1019"));
                }
                if (!data.company.tva) {
                    this.error.push(new Exception().ThrowException("1020"));
                }
            } else {
                this.error.push(new Exception().ThrowException("1026"));
            }
        }

        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}