import { Router } from "express";
import { Core } from "../Core";
import { AccountController } from "./controller/AccountController";
import { Middleware } from "./middleware";


export class Routes extends Core.BaseRoutes {
    private route: Router;
    private accountController: AccountController = new AccountController();
    private middleware: Middleware = new Middleware();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;

        self.route.post("/v1/appauth", self.accountController.AppAuth());

        self.route.post("/v1/login", [self.middleware.AppAuthorization()], self.accountController.LoginUser());
        self.route.post("/v1/register", [self.middleware.AppAuthorization()], self.accountController.RegisterUser());
        self.route.post("/v1/guestLogin", [self.middleware.AppAuthorization()], self.accountController.GuestLoginUser());
        self.route.post("/v1/forgotpassword", [self.middleware.AppAuthorization()], self.accountController.ForgotPassword());

        self.route.get("/v1/currentuser", [self.middleware.Authorization()], self.accountController.GetCurrentUser());
        self.route.post("/v1/updatedevice", [self.middleware.Authorization()], self.accountController.UpdateDeviceToken());
        self.route.post("/v1/changepassword", [self.middleware.Authorization()], self.accountController.ChangePassword());
        self.route.post("/v1/logout", [self.middleware.Authorization()], self.accountController.LogoutUser());
        self.route.post("/v1/passwordHash", [self.middleware.AppAuthorization()], self.accountController.PasswordHash());
        self.route.get("/v1/driverinfo/:id", [self.middleware.AppAuthorization()], self.accountController.DriverInfo());
    
        self.route.post("/v1/testapi", self.accountController.TestAPI());

        return self.route;
    }
}
