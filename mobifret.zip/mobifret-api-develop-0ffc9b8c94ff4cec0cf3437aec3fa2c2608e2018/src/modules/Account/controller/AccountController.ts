import { Request, Response } from "express";
import { Core } from "../../Core";
import { AccountBuisness } from "../business/AccountBuisness";
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";
import { JwtLib, UserService } from "../index";
import { S3Lib } from '../../../helper';
import { Device } from "../models/Device";
import { SnsLib } from "../../../helper";
import { SMSRequestLib } from "../../../helper/OvhSmsLib";
const passwordGenerator = require('generate-password');
import { OrderPlacing } from "../../../socket/OrderPlacing";

export class AccountController extends Core.BaseController {

    private accountBuisness = new AccountBuisness();
    private userService = new UserService();
    private validate = new Validation();
    private jwtlib = new JwtLib();
    private s3 = new S3Lib();
    private sns = new SnsLib();
    private SMS = new SMSRequestLib();

    constructor() {
        super();
    }

    /**
    * Post /login
    */
    LoginUser() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.LoginValidate(req.body);
                if (!validate.status) {
                    let user = await self.accountBuisness.CheckUserName(req.body.username);
                    if (user && user.currentPassword) {
                        let device;
                        let loginHistory = await self.accountBuisness.CheckLoginHistory(user.userId);
                        if(loginHistory){
                            if(req.body.forceLogin){
                                let islogout = await this.accountBuisness.LogoutLoginHistory(user.userId);
                                let old_device={
                                    deviceUuid: loginHistory['deviceUuid']
                                }
                                let set_olddevice = await this.accountBuisness.LogoutDevice(old_device, user.userId, false);
                                if(!islogout){
                                    validate.error.push(new Exception().ThrowException("1197"));
                                    return res.status(422).send(validate.error);
                                } else {
                                    let dataNotify = {
                                        type: "userSessionLogout",
                                        userId:user.userId,
                                        username:user.userName
                                    };
                                    OrderPlacing.CompanyOrder.notifyUser(user.userName, dataNotify, "generalNotify");
                                }
                            }else{
                                validate.error.push(new Exception().ThrowException("1195"));
                                return res.status(422).send(validate.error);
                            }
                        }

                        let login = await this.accountBuisness.SetLoginHistroy(user, req.body);
                        if (req.body.device) {
                            device = await self.accountBuisness.DeviceEntry(req.body.device, user.userId, true);
                            device.userId = user.userId;
                            if (!device.deviceArn && device.deviceType && device.deviceUuid){
                                self.sns.registerDevice(device, process.env["SNS_" + device.deviceType + "_ARN"]);
                            }

                        }

                        let result = await self.accountBuisness.LoginUser(req.body.password, user, device);
                        if (result) {
                            res.set('Authorization', 'Bearer ' + result);
                            return res.status(200).send();
                        } else {
                            validate.error.push(new Exception().ThrowException("1006"));
                        }
                    } else {
                        validate.error.push(new Exception().ThrowException("1005"));
                    }

                }

                return res.status(422).send(validate.error);

            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    LogoutUser() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let user: any = req.headers["user"];
                if (user && user.deviceUuid) {
                    let _device = {
                        "deviceUuid": user.deviceUuid
                    }
                    self.accountBuisness.LogoutDevice(_device, user.userID, false);
                    self.accountBuisness.LogoutLoginHistory(user.userID);
                }
                return res.status(200).send();
            } catch (e) {
                throw e;
            }
        };
    }

    ForgotPassword() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.GustLoginValidate(req.body);
                if (!validate.status) {
                    let checkUsername = await self.accountBuisness.CheckUserName(req.body.username);
                    if (checkUsername && checkUsername.currentPassword) {
                        let password = await passwordGenerator.generate({
                            length: 8,
                            numbers: true,
                            symbols: true,
                            uppercase: true,
                            strict: true
                        });

                        let result = await self.accountBuisness.ForgetPassword(req.body.username, password, checkUsername);
                        if (result) {
                            let temp = [];
                            return res.status(200).send(temp);
                        } else {
                            validate.error.push(new Exception().ThrowException("1027"));
                        }
                    } else {
                        validate.error.push(new Exception().ThrowException("1005"));
                    }
                }

                return res.status(422).send(validate.error);

            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    UpdateDeviceToken() {
        let self = this;
        return async (req: Request, res: Response) => {
            let user: any = req.headers["user"];
            if (user && user.deviceUuid) {
                let _device = {
                    "deviceUuid": user.deviceUuid,
                    "deviceToken": req.body.deviceToken,
                    "userId": user.userID,
                }
                let result = await self.accountBuisness.UpdateDevice(_device);
                return res.status(200).send();
            }
            return res.status(422).send([new Exception().ThrowException("1033")]);
        };
    }

    GetCurrentUser() {
        let self = this;
        return async (req: Request, res: Response) => {
            let userData = self.jwtlib.Decode(req, "authorization");
            if (userData.userID) {
                let result = await self.accountBuisness.GetCurrentUser(userData.userID);
                if (result) {
                    result = new Transformation().CurrentUser(result);
                    return res.send(result);
                }
            }

            return res.status(422).send([new Exception().ThrowException("1009")]);
        }
    }


    /**
    * Post /GuestLogin
    */
    GuestLoginUser() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.GustLoginValidate(req.body);
                if (!validate.status) {
                    let checkUsername = await self.accountBuisness.CheckUserName(req.body.username);
                    if (!checkUsername) {
                        let device;
                        if (req.body.device) {
                            device = await self.accountBuisness.DeviceEntry(req.body.device, null, true);
                            if (!device.deviceArn && device.deviceType && device.deviceUuid)
                                self.sns.registerDevice(device, process.env["SNS_" + device.deviceType + "_ARN"]);
                        }

                        let result = await self.accountBuisness.GuestLoginUser(req.body.username, device);
                        if (result) {
                            //return res.send(result);
                            res.set('Authorization', 'Bearer ' + result);
                            return res.status(200).send();
                        }
                    } else {
                        validate.error.push(new Exception().ThrowException("1010"));
                    }
                }

                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }


    CheckUserName() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.accountBuisness.CheckUserName(req.body.username);
                return res.send(result);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    /**
    * POST /User
    */
    RegisterUser() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.RegistrationValidation(req.body);
                if (!validate.status) {
                    if (req.body.contact.profile_image) {
                        let profileResult = await this.s3.FindObject(req.body.contact.profile_image);
                        if (!profileResult) {
                            return res.status(422).send([new Exception().ThrowException("1028")]);
                        }
                    }

                    if (req.body.company) {
                        if (req.body.company.document_image) {
                            let documentResult = await this.s3.FindObject(req.body.company.document_image);
                            if (!documentResult) {
                                return res.status(422).send([new Exception().ThrowException("1029")]);
                            }
                        }
                    }
                    let checkUsername = await self.accountBuisness.CheckUserName(req.body.contact.email);
                    if (!checkUsername) {
                        let result = await self.accountBuisness.RegisterUser(req.body, req.body.device);
                        if (result) {
                            
                            let user = await self.accountBuisness.CheckUserName(req.body.contact.email);
                            let login = await this.accountBuisness.SetLoginHistroy(user, req.body);
                            if (req.body.device) {
                                let device = await self.accountBuisness.DeviceEntry(req.body.device, user.userId, true);
                            }
                            //return res.send(result);
                            res.set('Authorization', 'Bearer ' + result);
                            return res.status(200).send();
                        } else {
                            return res.status(500).send([new Exception().ThrowException("")]);
                        }
                    } else {
                        validate.error.push(new Exception().ThrowException("1010"));
                    }
                }
                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    ChangePassword() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let user: any = req.headers.user;
                let currentUser = await self.accountBuisness.GetCurrentUser(user.userID);
                let validate = await self.validate.ChangePasswordValidate(currentUser, req.body);
                if (!validate.status) {
                    let result = await this.accountBuisness.ChangePasswordHash(user.userID, req.body.new_password);
                    if (result)
                        return res.status(200).send("success");
                    return res.status(500).send([new Exception().ThrowException("1009")]);
                }

                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        }
    }

    AppAuth() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let validate = this.validate.AppValidate(req.body);
                if (!validate.status) {
                    let result = await self.accountBuisness.AppAuth(req.body.secretKey, req.body.clientKey);
                    if (result) {
                        //return res.send(result);
                        //return
                        res.set('Authorization', 'Bearer ' + result);
                        return res.status(200).send();
                    } else {
                        validate.error.push(new Exception().ThrowException("1007"));
                    }
                }
                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }


    TestAPI() {
        let self = this;
        // s3 bucket find object test
        // return async (req: Request, res: Response) => {
        //     let result = await self.accountBuisness.TestAPI(req.body); 
        //     return res.send(result);
        // };

        // smtp email test
        return async (req: Request, res: Response) => {
            let code = "12356"
            let result;
            await self.SMS.SmsRequest(code);
            return res.send(result);
        };
    }


    PasswordHash() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.accountBuisness.PasswordHash(req.body.password);
                return res.send(result);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    DriverInfo() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.accountBuisness.DriveInfo(req.params.id);
                return res.send(result);
            } catch (e) {
                console.log(e);
                res.status(500).send([new Exception().ThrowException("")]);
            }
        }
    }
}