import { Core } from "../../Core";

export class Mailer extends Core.BaseMailer {
    constructor() {
        super();
    }
}