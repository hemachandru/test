
import { Mailer } from '../mailer';

let path = require("path");
let fs = require('fs');
let ejs = require('ejs');


export class MailLib {


    constructor() {
    }


    async orderMailer(mailObject: any, ): Promise<Boolean> {
        let templatepath = path.resolve(__dirname, '..', '..', '..', '..') + '/src/modules/Account/mailer/orderMail.ejs';
        let template = await fs.readFileSync(templatepath, 'utf8');

        let templateContent = await ejs.render(template, {
            user: mailObject,
            url: ''
        });

        let mailOpt = {
            to: mailObject.deliveryEmailId,
            subject: mailObject.subject,
            html: templateContent
        };

        let result: any = await new Mailer().SendMail(mailOpt);
        if (result) {
            return true;
        }
        return false;
    }


}