import { Request, Response } from "express";
import { Core } from "../../Core";
import { OrderBusiness } from "../business/OrderBusiness";
import { Validation } from "../validation";
import { Exception } from "../exception";
import { Transformation } from "../transformation/index";
import { S3Lib } from '../../../helper';
import { UserService } from '../../Account/service/UserService';
import { OrderPlacing } from "../../../socket/OrderPlacing";

export class OrderController extends Core.BaseController {

    private orderBusiness = new OrderBusiness();
    private s3 = new S3Lib();
    private userService = new UserService();
    private validate = new Validation();


    CreateOrderWithoutCart() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers['user'];
                let userResult = await self.userService.GetCurrentUser(parseInt(userData.userID));
                if (req.body.shipment) {
                    let error = [];
                    for (let i in req.body.shipment) {
                        if (req.body.shipment[i].shipment_image) {
                            let shipmentImageResult = await this.s3.FindObject(req.body.shipment[i].shipment_image);
                            error.push(shipmentImageResult);
                        }
                    }
                    if (error.indexOf(false) > -1) {
                        return res.status(422).send([new Exception().ThrowException("1031")]);
                    }
                }
                let result = await self.orderBusiness.OrderProcess(req.body, userResult);
                if (!result) {
                    return res.status(500).send([new Exception().ThrowException("")]);
                }
                return res.status(200).send();

            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    CreateOrder() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let userData: any = req.headers['user'];
                let validate = await this.validate.OrderValidation(req.body, userData.userID);
                if (!validate.status) {
                    let result = await self.orderBusiness.CreateOrder(req.body.orderID);
                    if (!result) {
                        return res.status(500).send([new Exception().ThrowException("")]);
                    }
                    let socketData = await new Transformation().formatSocketOrder(req.body.orderID);
                    res.status(200).send();
                    OrderPlacing.CompanyOrder.placeOrderEmit(socketData);
                    return;
                }
                return res.status(422).send(validate.error);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetOrderListClient() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let offset = req.query.offset ? req.query.offset : process.env.ORDER_OFFSET;
                let limit = req.query.limit ? req.query.limit : process.env.ORDER_LIMIT;
                let userData: any = req.headers['user'];
                let params = {
                    type: req.params.type,
                    offset: parseInt(offset),
                    limit: parseInt(limit),
                    userid: userData.userID
                }
                let result = await self.orderBusiness.GetOrderListClient(params);
                let resultCount;
                if (result) {
                    resultCount = await self.orderBusiness.GetOrderListClientCount(params);
                }
                let resultData = await new Transformation().formatClientOrderList(result, params, resultCount);
                return res.status(200).send(resultData);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetSingleOrderClient() {
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                let result = await self.orderBusiness.GetSingleOrderClient(req.params.id);
                let resultData = await new Transformation().formatClientSingleOrder(result);
                return res.status(200).send(resultData);
            } catch (e) {
                console.log(e);
                return res.status(500).send([new Exception().ThrowException("")]);
            }
        };
    }

    GetOrderFromCache(){
        let self = this;
        return async (req: Request, res: Response) => {
            try {
                //let lat = req.params.lat;
                //let lan = req.params.lan;
                let socketData = [];
                let checkOrder = [];
                let userData: any = req.headers['user'];
                let userID = userData.userID;
                let orderIds = await self.orderBusiness.GetOrderWithInRadius(userID);
                for (let ids in orderIds) {
                    let data = orderIds[ids];
                    console.log(data.orderId);
                    if(checkOrder.indexOf(data.orderId) == -1){
                        socketData[ids] = await new Transformation().formatSocketOrder(data.orderId);
                    }
                    checkOrder.push(data.orderId);
                   
                }
                return res.status(200).send(socketData);
            } catch (e) {
                console.log(e);
            }
        };
    }

}