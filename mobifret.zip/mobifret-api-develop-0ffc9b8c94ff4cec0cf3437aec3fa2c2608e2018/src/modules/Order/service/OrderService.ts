import { Request, Response } from "express";
import { Sequelize } from 'sequelize-typescript';
import { Core } from "../../Core";
import { Document } from '../../Account/models/Document';
import { Cart as Order } from '../../Cart/models/Cart';
import { OrderStatus } from '../../Cart/models/OrderStatus';
import { OrderStatusHistory } from '../../Cart/models/OrderStatusHistory';
import { ShipmentDetail } from '../../Cart/models/ShipmentDetail';
import { ShipmentHistory } from '../../Cart/models/ShipmentHistory';
import { ShipmentStatus } from '../../Cart/models/ShipmentStatus';
import { ShipmentAddress } from '../../Cart/models/ShipmentAddress';
import { Vehicle } from '../../DriverMission/models/Vehicle';
import { Driver } from '../../DriverMission/models/Driver';
import { Registration } from '../../Account/models/Registration';
import { User } from '../../Account/models/User';
import { Contact } from "../../Account/models/Contact";
import { SequelizeLib } from '../../../helper';
import { S3Lib } from '../../../helper';
import { FreightType } from '../../General/models/FreightType';
import { DocumentService } from "../../Account/service/DocumentService";
import { Rating } from "../../DriverMission/models/Rating";
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";
import { ShipmentStatusEnum } from "../../Order/helper/ShipmentStatusEnum";
import { NotConfirmedMissionReasons } from "../../General/models/NotConfirmedMissionReasons";
import { ConfigurationService } from '../../General/service/ConfigurationService';

export class OrderService extends Core.BaseService {
    private sequelize: Sequelize;
    private sequelizeLib: SequelizeLib;
    private s3 = new S3Lib();
    private documentService = new DocumentService();
    private configurationService = new ConfigurationService();

    GenerateRandomString(len) {
        var text = "";
        var charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }

    async PostOrder(objOrder: any): Promise<Boolean> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();
        try {
            let fromAddressID = 0;
            let toAddressID = 0;

            let addressResult = await ShipmentAddress.bulkCreate(objOrder.address, { transaction: t });

            for (let i in addressResult) {
                if (i == "0")
                    fromAddressID = addressResult[i].getDataValue("shipmentAddressId");
                if (i == "1")
                    toAddressID = addressResult[i].getDataValue("shipmentAddressId");
            }

            let orderObj = {
                shipmentMode: objOrder.order.shipmentMode,
                orderCost: objOrder.order.orderCost,
                insuranceCost: objOrder.order.insuranceCost,
                taxCost: objOrder.order.taxCost,
                netCost: objOrder.order.netCost,
                driverValidationCode: objOrder.order.driverValidationCode,
                deliveryValidationCode: objOrder.order.deliveryValidationCode ? objOrder.order.deliveryValidationCode : null,
                fromShipmentAddressId: fromAddressID,
                toShipmentAddressId: toAddressID,
                orderStatusId: objOrder.order.orderStatusId,
                registrationId: objOrder.order.registrationId,
                userId: objOrder.order.userId
            }

            let orderResult = await Order.create(orderObj, { transaction: t });
            let orderID = orderResult.getDataValue("orderId");

            let orderHistoryObj = {
                orderId: orderID,
                orderStatusId: objOrder.order.orderStatusId
            }

            let orderStatusHistoryResult = await OrderStatusHistory.create(orderHistoryObj, { transaction: t });

            for (let i in objOrder.shipment) {
                let photoResult;
                if (objOrder.shipment[i].shipmentPhoto) {
                    let photoDestination = "api/registration/profile/" + this.GenerateRandomString(15) + "_" + new Date().getTime() + ".jpg";
                    let photoS3 = await this.s3.CopyObjectPublic("/" + objOrder.shipment[i].shipmentPhoto, photoDestination);
                    let photoDocument: any = {
                        documentType: 'photo',
                        document: photoS3 ? photoDestination : null
                    }
                    photoResult = await this.documentService.PostDocument(photoDocument);
                    if (photoResult) {
                        objOrder.shipment[i].shipmentPhotoId = photoResult.getDataValue("documentId");
                    } else {
                        objOrder.shipment[i].shipmentPhotoId = null;
                    }
                    delete objOrder.shipment[i].shipmentPhoto;
                } else {
                    objOrder.shipment[i].shipmentPhotoId = null;
                }

                objOrder.shipment[i].orderId = orderID;

                let shipmentResult = await ShipmentDetail.create(objOrder.shipment[i], { transaction: t });
                let shipmentID = shipmentResult.getDataValue("shipmentDetailId");

                let shipmentHistoryObj = {
                    orderId: orderID,
                    shipmentDetailId: shipmentID,
                    shipmentStatusId: objOrder.shipment[i].shipmentStatusId
                }

                let shipmentHistoryResult = await ShipmentHistory.create(shipmentHistoryObj, { transaction: t });

            }

            let transactionCommit = await t.commit();
            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }
    }

    async GetUserOrders(orderID: any): Promise<Order[]> {
        let result = await Order.findAll<Order>({
            where: { orderId: orderID },
            include: [ShipmentDetail, OrderStatus]
        });
        return result;
    }

    async CreateOrder(objOrder: any): Promise<any> {

        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let t = await this.sequelize.transaction();
        try {
            let userOrder = await this.GetUserOrders(objOrder);
            let orderID = [];
            let orderHistoryObj = [];
            let shipmentID = [];
            let shipmentHistoryObj = [];

            for (let singleOrder of userOrder) {
                orderID.push(singleOrder.orderId);
                let orderHistoryNode = {
                    orderId: singleOrder.orderId,
                    orderStatusId: OrderStatusEnum.New
                }
                orderHistoryObj.push(orderHistoryNode);
                for (let singleShipment of singleOrder.shipment) {
                    shipmentID.push(singleShipment.shipmentDetailId);
                    let shipmentHistoryNode = {
                        orderId: singleOrder.orderId,
                        shipmentDetailId: singleShipment.shipmentDetailId,
                        shipmentStatusId: ShipmentStatusEnum.New
                    };
                    shipmentHistoryObj.push(shipmentHistoryNode);
                }
            }

            let updateOrder = await Order.update<Order>({
                orderStatusId: OrderStatusEnum.New,
                createdAt:new Date().getTime()
            },
                {
                    where: {
                        orderId: orderID
                    }, transaction: t
                });

            let orderStatusHistoryResult = await OrderStatusHistory.bulkCreate(orderHistoryObj, { transaction: t });

            let updateShipment = await ShipmentDetail.update<ShipmentDetail>({
                shipmentStatusId: ShipmentStatusEnum.New
            },
                {
                    where: {
                        shipmentDetailId: shipmentID
                    }, transaction: t
                });

            let shipmentHistoryResult = await ShipmentHistory.bulkCreate(shipmentHistoryObj, { transaction: t });

            let transactionCommit = await t.commit();
            return true;
        } catch (e) {
            console.log(e);
            let transactionRollback = await t.rollback();
            return false;
        }
    }



    async GetOrderListClient(params: any): Promise<any> {
        let result = null;
        if (params.type == "complete") {
            result = await Order.findAll<Order>({ 
                offset: params.offset,
                limit: params.limit,
                where: {
                    userId: params.userid,
                    orderStatusId: [OrderStatusEnum.Completed, OrderStatusEnum.Cancelled, OrderStatusEnum.ClientCancelled]
                },
                include: [OrderStatusHistory, OrderStatus, Rating], 
                order: [['orderId', 'DESC']]
            });

        } else if (params.type == "inprogress") {
            result = await Order.findAll<Order>({
                offset: params.offset,
                limit: params.limit,
                where: {
                    userId: params.userid,
                    orderStatusId: [OrderStatusEnum.New, OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                },
                include: [OrderStatusHistory, OrderStatus, {

                    model: Driver,
                    //attributes: ['Id', 'platformName'],
                    include: [{
                        model: Contact,
                    }]

                }],
                order: [['orderId', 'DESC']]
            });
        } else {
            let temp = [];
            result = temp;
        }
        return result;
    }

    async GetOrderListClientCount(params: any): Promise<any> {
        let result = null;
        if (params.type == "complete") {
            result = await Order.findAll<Order>({ 
                where: {
                    userId: params.userid,
                    orderStatusId: [OrderStatusEnum.Completed, OrderStatusEnum.ClientCancelled]
                },
                include: [OrderStatusHistory, OrderStatus, Rating], 
                order: [['orderId', 'DESC']]
            });

        } else if (params.type == "inprogress") {
            result = await Order.findAll<Order>({
                where: {
                    userId: params.userid,
                    orderStatusId: [OrderStatusEnum.New, OrderStatusEnum.Assigned, OrderStatusEnum.Accepted, OrderStatusEnum.Started, OrderStatusEnum.Reached, OrderStatusEnum.Pickup]
                },
                include: [OrderStatusHistory, OrderStatus, {

                    model: Driver,
                    include: [{
                        model: Contact,
                    }]

                }],
                order: [['orderId', 'DESC']]
            });
        } else {
            let temp = [];
            result = temp;
        }
        return result;
    }

    async GetSingleOrderClient(orderID: any): Promise<Order> {
        let result = await Order.find<Order>({
            where: { orderId: orderID },
            include: [{
                model: ShipmentDetail,
                include: [ShipmentStatus, FreightType, Document]
            }, {
                model: OrderStatusHistory,
                include: [OrderStatus]
            }, OrderStatus, Rating , NotConfirmedMissionReasons]
        });
        return result;
    }

    async ValidateUserOrders(orderID: any, userID: any): Promise<Order[]> {
        let result = await Order.findAll<Order>({
            where: {
                orderId: orderID,
                orderStatusId: OrderStatusEnum.Cart,
                userId: userID
            }
        });
        return result;
    }

    async GetSingleOrderDetails(orderID: any): Promise<Order> {
        let result = await Order.find<Order>({
            where: { orderId: orderID },
            include: [{
                model: ShipmentDetail,
                include: [ShipmentStatus, FreightType, Document]
            }, OrderStatusHistory, OrderStatus, Rating, User, NotConfirmedMissionReasons, {

                model: Driver,
                include: [
                    {
                        model: Contact,
                    },
                    {
                        model: Registration,
                        include: [{
                            model: Contact,
                        }]
                    }
                ]


            }]
        });
        return result;
    }


    async GetNewOrders(): Promise<any> {
        let result = [];
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();

        let d = new Date();
        d.setHours(d.getHours() - 2);
        let currentDt = d.toISOString().substring(0, 19).replace('T', ' ');
        try {
            let queryString = "select orderId from "
                + " tblOrders orders "
                + " WHERE orders.createdAt > '"+currentDt+"' AND"
                + " orders.orderStatusId = " + OrderStatusEnum.New
            let result = await this.sequelize.query(queryString);
            return result[0];
        } catch (e) {
            return e
        }
    }

    async GetOrderWithInRadius(userID: any): Promise<any> {
        /*let result = [];
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();
        let config = await this.configurationService.GetConfiguration();;
        console.log(config);
        let d = new Date();
        d.setHours(d.getHours() - 2);
        let currentDt = d.toISOString().substring(0, 19).replace('T', ' ');
        try {

            let queryString =" SELECT orderId, ship.lat, ship.lan, SQRT( "
                + " POW(69.1 * (lat - "+lat+"), 2) +"
                + " POW(69.1 * ("+lan+" - lan) * COS(lat / 57.3), 2)) AS distance"
                + " FROM tblOrders as orders"
                + " left join "
                + " tblShipmentAddresses As ship ON orders.fromShipmentAddressId = ship.shipmentAddressId"
                + " HAVING distance < 5 And"
                + " createdAt > '"+currentDt+"' And"
                + " orderStatus = "+ OrderStatusEnum.New
                + " ORDER BY orderId ASC";

            let result = await this.sequelize.query(queryString);
            return result[0];
        } catch (e) {
            return e
        }*/
        let result = [];
        this.sequelizeLib = SequelizeLib.getInstance();
        this.sequelize = this.sequelizeLib.getSequelize();

        let configResult = await this.configurationService.GetConfiguration();

        configResult.forEach(element => {
            if (element.configKey == 'time_out'){
                let expire = element.configValue * 60;
            }    
        });

        let d = new Date();
        d.setHours(d.getHours() - 1);
        let currentDt = d.toISOString().substring(0, 19).replace('T', ' ');
        try {
            /*let queryString = "select orderId from "
                + " tblOrders orders "
                + " WHERE orders.createdAt > '"+currentDt+"' AND"
                + " orders.orderStatusId = " + OrderStatusEnum.New*/
            
            let queryString = "select driMis.orderId from "
                + " tblDriverMissions driMis "
                + " left join tblOrders as orders ON  driMis.orderId = orders.orderId"
                + " left join tblDrivers as driver ON  driMis.driverId = driver.driverId"
                + " WHERE orders.createdAt > '"+ currentDt +"' AND"
                + " orders.orderStatusId = " + OrderStatusEnum.New +" AND"
                + " orders.shipmentMode = 'Immediate' AND"
                + " driver.userId = " + userID	

            let result = await this.sequelize.query(queryString);
            return result[0];
        } catch (e) {
            return e
        }
    }

    
}