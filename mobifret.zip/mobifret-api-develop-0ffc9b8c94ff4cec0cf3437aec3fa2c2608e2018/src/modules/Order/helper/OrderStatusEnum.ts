export enum OrderStatusEnum {
    Cart = 1,
    New = 2,
    Assigned = 3,
    Accepted = 4,
    Started = 5,
    Reached = 6,
    Rejected = 7,
    Cancelled = 8,
    Pickup = 9,
    Completed = 10,
    NotCompleted = 11,
    ClientCancelled = 12
}
