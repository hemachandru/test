import { OrderService } from "../service/OrderService";
import { Cart as Order } from '../../Cart/models/Cart';
import { OrderStatusEnum } from "../../Order/helper/OrderStatusEnum";
import { ShipmentStatusEnum } from "../../Order/helper/ShipmentStatusEnum";

export class OrderBusiness {

    private orderService = new OrderService();

    GenerateRandomString(len) {
        var text = "";
        var charset = "0123456789";
        for (var i = 0; i < len; i++)
            text += charset.charAt(Math.floor(Math.random() * charset.length));
        return text;
    }

    async OrderProcess(order: any, user: any): Promise<Boolean> {
        try {

            let fromAddress: any = {
                addressType: 'Pickup',
                lat: order.from_address.lat,
                lan: order.from_address.lan,
                firstName: order.from_address.first_name,
                lastName: order.from_address.last_name ? order.from_address.last_name : null,
                email: order.from_address.email ? order.from_address.email : null,
                telephone: order.from_address.telephone,
                address1: order.from_address.address1,
                address2: order.from_address.address2 ? order.from_address.address2 : null,
                gateNumber: order.from_address.gate_number ? order.from_address.gate_number : null,
                appartmentName: order.from_address.apartment_name ? order.from_address.apartment_name : null,
                floor: order.from_address.floor ? order.from_address.floor : null,
                city: order.from_address.city ? order.from_address.city : null,
                country: order.from_address.country ? order.from_address.country : null,
                postalCode: order.from_address.postalcode,
                isLift: order.from_address.islift ? true : false,
                isBell: order.from_address.isbell ? true : false
            }

            let toAddress: any = {
                addressType: 'Delivery',
                lat: order.to_address.lat,
                lan: order.to_address.lan,
                firstName: order.to_address.first_name,
                lastName: order.to_address.last_name ? order.to_address.last_name : null,
                email: order.to_address.email ? order.to_address.email : null,
                telephone: order.to_address.telephone,
                address1: order.to_address.address1,
                address2: order.to_address.address2 ? order.to_address.address2 : null,
                gateNumber: order.to_address.gate_number ? order.to_address.gate_number : null,
                appartmentName: order.to_address.apartment_name ? order.to_address.apartment_name : null,
                floor: order.to_address.floor ? order.to_address.floor : null,
                city: order.to_address.city ? order.to_address.city : null,
                country: order.to_address.country ? order.to_address.country : null,
                postalCode: order.to_address.postalcode,
                isLift: order.to_address.islift ? true : false,
                isBell: order.to_address.isbell ? true : false
            }

            let addressArray: any = [];
            addressArray[0] = fromAddress;
            addressArray[1] = toAddress;

            let shipment: any = [];

            for (let i in order.shipment) {
                let shipmentNode = new Object();
                shipmentNode["freightTypeId"] = order.shipment[i].freight_type;
                shipmentNode["shipmentCost"] = order.shipment[i].shipment_cost;
                shipmentNode["insuranceCost"] = order.shipment[i].insurance_cost;
                shipmentNode["taxCost"] = order.shipment[i].tax_cost;
                shipmentNode["netShipmentCost"] = order.shipment[i].net_shipment_cost;
                shipmentNode["shipmentStatusId"] = ShipmentStatusEnum.New;
                shipmentNode["shipmentPhoto"] = order.shipment[i].shipment_image ? order.shipment[i].shipment_image : null;
                shipmentNode["isStackable"] = order.shipment[i].isstackable ? order.shipment[i].isstackable : 0;
                shipmentNode["isFilmeed"] = order.shipment[i].isfilmeed ? order.shipment[i].isfilmeed : 0;
                shipment.push(shipmentNode);
            }

            let ord: any = {
                shipmentMode: order.shipment_mode,
                orderCost: order.order_cost,
                insuranceCost: order.insurance_cost,
                taxCost: order.tax_cost,
                netCost: order.net_cost,
                driverValidationCode: this.GenerateRandomString(4),
                // deliveryValidationCode: this.GenerateRandomString(4),
                //driverValidationCode: 1234,
                deliveryValidationCode: null,
                orderStatusId: ShipmentStatusEnum.New,
                registrationId: user.registration.id,
                userId: user.id
            };

            let orderObject: any = {
                role: order.role,
                order: ord,
                address: addressArray,
                shipment: shipment
            }

            let result = await this.orderService.PostOrder(orderObject);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async CreateOrder(order: any): Promise<any> {
        try {
            let result = await this.orderService.CreateOrder(order);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetOrderListClient(params: any): Promise<any> {
        try {
            let result = await this.orderService.GetOrderListClient(params);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetOrderListClientCount(params: any): Promise<any> {
        try {
            let result = await this.orderService.GetOrderListClientCount(params);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async GetSingleOrderClient(orderid: any): Promise<any> {
        try {
            let result = await this.orderService.GetSingleOrderClient(orderid);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }
    async GetOrderWithInRadius(userID:any): Promise<any> {
        try {
            let result = await this.orderService.GetOrderWithInRadius(userID);
            return result;
        } catch (e) {
            console.log(e);
            return false;
        }
    }
}