import { Core } from "../../Core";
import { OrderService } from '../service/OrderService';
import { Transformation as AddressTransform } from '../../Cart/transformation';
import { ConfigurationService } from '../../General/service/ConfigurationService';
import { OrderStatusEnum } from "../helper/OrderStatusEnum";
import * as moment from "moment";

export class Transformation extends Core.BaseTransformation {

    private orderService = new OrderService();
    private configurationService = new ConfigurationService();

    constructor() {
        super();
    }

    async formatSocketOrder(objOrder): Promise<any> {
        let plannedOrderArray = [];
        let immediateOrderArray = [];
        let userOrder = await this.orderService.GetUserOrders(objOrder);

        for (let singleOrder of userOrder) {
            let fromAddress = await new AddressTransform().getAddress(singleOrder.fromShipmentAddressId);
            let toAddress = await new AddressTransform().getAddress(singleOrder.toShipmentAddressId);
            let orderSocketNode = {
                orderId: singleOrder.orderId,
                net_cost: singleOrder.netCost,
                from_address: fromAddress,
                to_address: toAddress,
                location: {
                    latitude: fromAddress.address.lat,
                    longitude: fromAddress.address.lan
                },
                created_at: singleOrder.createdAt ? singleOrder.createdAt : null,
                duration: singleOrder.duration ? singleOrder.duration : null
            };

            if (singleOrder.shipmentMode === "Planned") {
                plannedOrderArray.push(orderSocketNode);
            } else if (singleOrder.shipmentMode === "Immediate") {
                immediateOrderArray.push(orderSocketNode);
            }

        }

        let km;
        let no_driver;
        let expire;

        let configResult = await this.configurationService.GetConfiguration();

        configResult.forEach(element => {
            if (element.configKey == 'radius')
                km = element.configValue
            if (element.configKey == 'time_out')
                expire = element.configValue * 60;
            if (element.configKey == 'driver_request')
                no_driver = element.configValue
        });


        let orderSocketObj = {
            planned: plannedOrderArray,
            immediate: immediateOrderArray,
            config: {
                km: km,
                no_driver: no_driver,
                expire: expire
            }
        };

        return orderSocketObj;

    }

    async formatClientOrderList(objOrder: any, params: any, totalcount: any): Promise<any> {
        let orderArray = [];
        for (let singleOrder of objOrder) {
            let fromAddress = await new AddressTransform().getAddress(singleOrder.fromShipmentAddressId);
            let toAddress = await new AddressTransform().getAddress(singleOrder.toShipmentAddressId);
            let orderHistoryNode = {};
            let pickupDate;
            let completeDate;
            let duration;
            let hours;
            singleOrder.orderHistory.forEach(element => {
                if (element.orderStatusId == singleOrder.orderStatusId) {
                    orderHistoryNode = {
                        status: singleOrder.orderstatus.orderStatus,
                        status_at: element.statusAt
                    }
                }
                if (element.orderStatusId == OrderStatusEnum.Pickup) {
                    pickupDate = element.statusAt
                }

                if (element.orderStatusId == OrderStatusEnum.Completed) {
                    completeDate = element.statusAt
                    let now = moment(pickupDate); //pickup date
                    let end = moment(completeDate); // complete date
                    duration = end.diff(now,'seconds')
                }

            });

            let orderNode = {
                id: singleOrder.orderId,
                created_at: singleOrder.createdAt,
                from_address: fromAddress,
                to_address: toAddress,
                status: orderHistoryNode,
                driver_code: singleOrder.driverValidationCode,
                duration: singleOrder.duration,
                shipment_mode: singleOrder.shipmentMode,
                plan_date_time: singleOrder.assignedAt ? singleOrder.assignedAt : null,
                isRating: singleOrder.rating ? 1 : 0,
                net_cost: singleOrder.netCost,
            }


            if (params.type == "complete") {
                orderNode['duration'] = duration
            }

            if (singleOrder.driver) {
                orderNode['driver_mobileNumber'] = singleOrder.driver.contact.mobile ? singleOrder.driver.contact.mobile : null
            }

            // if (singleOrder.rating) {
            //     orderNode["rating"] = singleOrder.rating.rating;
            // }
            orderArray.push(orderNode);
        }

        let resultObject = {
            count: totalcount.length,
            offset: params.offset,
            limit: params.limit,
            items: orderArray
        }

        return resultObject;

    }

    async formatClientSingleOrder(objOrder): Promise<any> {
        if (objOrder) {
            let fromAddress = await new AddressTransform().getAddress(objOrder.fromShipmentAddressId);
            let toAddress = await new AddressTransform().getAddress(objOrder.toShipmentAddressId);
            let orderHistoryNode = {};
            let orderHistory = [];
            objOrder.orderHistory.forEach(element => {
                if (element.orderStatusId == objOrder.orderStatusId) {
                    orderHistoryNode = {
                        status: objOrder.orderstatus.orderStatus,
                        status_at: element.statusAt
                    }
                }

                orderHistoryNode = {
                    status: element.orderstatus.orderStatus,
                    status_at: element.statusAt
                }
                orderHistory.push(orderHistoryNode);


            });
            let shipmentArray = []
            objOrder.shipment.forEach(singleShipment => {
                let shipmentNode = {
                    id: singleShipment.shipmentDetailId,
                    freight_type: {
                        id: singleShipment.freightTypeId,
                        type: singleShipment.freightType ? singleShipment.freightType.freightType : singleShipment.freightType
                    },
                    // shipment_cost: singleShipment.shipmentCost,
                    // insurance_cost: singleShipment.insuranceCost,
                    // tax_cost: singleShipment.taxCost,
                    // net_shipment_cost: singleShipment.netShipmentCost,
                    shipment_image: singleShipment.shipmentPhotoId ? process.env.AWS_CDN_URL + "/" + singleShipment.photo.document : null,
                    isstackable: singleShipment.isStackable,
                    isfilmeed: singleShipment.isFilmeed,
                    quantity: singleShipment.quantity,
                    weight: singleShipment.weight,
                    width: singleShipment.width,
                    breadth: singleShipment.breadth,
                    height: singleShipment.height,
                    comments: singleShipment.comments,
                    shipment_status: {
                        id: singleShipment.shipmentStatusId,
                        status: singleShipment.shipmentStatus.shipmentStatus
                    }
                };
                shipmentArray.push(shipmentNode);
            });
            let orderNode = {
                id: objOrder.orderId,
                order_cost: objOrder.orderCost,
                insurance_cost: objOrder.insuranceCost,
                tax_cost: objOrder.taxCost,
                net_cost: objOrder.netCost,
                distance: objOrder.distance,
                duration: objOrder.duration,
                created_at: objOrder.createdAt,
                driver_code: objOrder.driverValidationCode,
                comments: objOrder.comments,
                from_address: fromAddress,
                to_address: toAddress,
                status: orderHistoryNode,
                shipment: shipmentArray,
                orderHistory: orderHistory,
                shipment_mode: objOrder.shipmentMode,
                deliveryComments: objOrder.deliveryComments,
                plan_date_time: objOrder.assignedAt ? objOrder.assignedAt : null
            }
            if (objOrder.rating) {
                orderNode["rating"] = objOrder.rating.rating;
            }
            if (objOrder.missionReasons) {
                orderNode["NotConfirmedMissionReasons"] = objOrder.missionReasons.reason;
            }

                    
            return orderNode;
        }

        return objOrder;
    }

}