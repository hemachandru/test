import { Router } from "express";
import { Core } from "../Core";
import { OrderController } from "./controller/OrderController";
import { Middleware } from "../Account/middleware";
import { DriverMissionController } from "../DriverMission/controller/DriverMissionController";


export class Routes extends Core.BaseRoutes {
    private route: Router;
    private orderController: OrderController = new OrderController();
    private middleware: Middleware = new Middleware();
    private driverMissionController: DriverMissionController = new DriverMissionController();

    constructor(route: Router) {
        super();
        this.route = route;
    }

    Routes() {
        let self = this;
        self.route.post("/v1/order", [self.middleware.Authorization()], self.orderController.CreateOrder());
        self.route.get("/v1/getOrderListClient/:type", [self.middleware.Authorization()], self.orderController.GetOrderListClient());
        self.route.get("/v1/orderClient/:id", [self.middleware.Authorization()], self.orderController.GetSingleOrderClient());
        self.route.post("/v1/rate/:orderid", [self.middleware.Authorization()], self.driverMissionController.RateOrder());
        self.route.post("/v1/orderClientCancelled/:orderid", [self.middleware.Authorization()], self.driverMissionController.ClientOrderCancelled());
        self.route.get("/v1/forceNearByOrder/", [self.middleware.Authorization()], self.orderController.GetOrderFromCache());
        return self.route;
    }
}
