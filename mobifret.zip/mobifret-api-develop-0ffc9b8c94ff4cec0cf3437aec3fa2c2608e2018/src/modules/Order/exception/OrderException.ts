export let error = {
    "1031": "Shipment image get error",
    "1009": "User does not exits",
    "1032": "Location does not exits",
    "1033": "Latitude does not exits",
    "1034": "Longitude does not exits",
    "1035": "orderID required",
    "1036": "Order cannot processed"
}