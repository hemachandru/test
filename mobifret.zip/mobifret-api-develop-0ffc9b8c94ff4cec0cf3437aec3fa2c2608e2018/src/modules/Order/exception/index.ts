import { error } from "./OrderException";
import { Core } from "../../Core";

export class Exception extends Core.BaseException {
    constructor() {
        super(error);
    }
}