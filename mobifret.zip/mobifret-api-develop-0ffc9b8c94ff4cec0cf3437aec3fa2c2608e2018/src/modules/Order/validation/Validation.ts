import { Exception } from "../exception";
import { OrderService } from '../service/OrderService';

export class Validation {
    private error = [];
    private orderService: OrderService = new OrderService();
    constructor() {
        this.error = [];
    }

    async OrderValidation(data: any, userid: any) {
        this.error = [];
        let orderID = [];
        if (!data.orderID) {
            this.error.push(new Exception().ThrowException("1035"));
        }
        if (data.orderID) {
            if (data.orderID.length == 0) {
                this.error.push(new Exception().ThrowException("1035"));
            }
        }

        if (data.orderID) {
            if (data.orderID.length != 0) {
                data.orderID.forEach(element => {
                    orderID.push(element);
                });
                let orderResult = await this.orderService.ValidateUserOrders(orderID, userid);
                if (orderResult.length != data.orderID.length) {
                    this.error.push(new Exception().ThrowException("1036"));
                }
            }
        }

        return this.handler(this.error);
    }

    handler(error) {
        if (error.length > 0) {
            return {
                status: true,
                error: error
            }
        }

        return {
            status: false,
            error: []
        };
    }

}