import { JwtLib } from "../modules";
const jwt: JwtLib = new JwtLib();
export let Exception = () => {
    return (err, req, res, next) => {
       jwt.ErrorVerification(err, req, res, next);
    }
}
