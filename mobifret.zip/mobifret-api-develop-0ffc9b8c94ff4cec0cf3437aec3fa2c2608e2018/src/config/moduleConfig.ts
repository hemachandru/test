export const moduleConfig = [
    'Account',
    'General',
    'Order',
    'Cart',
    'DriverMission',
    'Pricing',
    'User'
];