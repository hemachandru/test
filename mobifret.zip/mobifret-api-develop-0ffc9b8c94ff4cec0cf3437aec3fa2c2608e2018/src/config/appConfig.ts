let path = require("path");
console.log("Process 2 : " + process.env.NODE_ENV);
let config = require(path.resolve(__dirname, '..', '..') + '/src/config/config.json')[process.env.NODE_ENV];

export = {
    "local": {
        "BASE": config.base,
        "SECRETKEY": config.secretkey,
        "EMAIL_HOST": config.email_host,
        "EMAIL_PORT": config.email_port,
        "EMAIL_USERNAME": config.email_username,
        "EMAIL_PASSWORD": config.email_password,
        "EMAIL_FROM": config.email_from,
        "AWS_ACCESS_KEY": config.aws_access_key_id,
        "AWS_SECRET_ACCESS_KEY": config.aws_secret_access_key,
        "PUBLIC_AWS_BUCKET": config.public_aws_bucket,
        "PRIVATE_AWS_BUCKET": config.private_aws_bucket,
        "TEMP_AWS_BUCKET": config.temp_aws_bucket,
        "AWS_CDN_URL": config.aws_cdn_url,
        "AWS_REGION": config.aws_region
    },
    "development": {
        "BASE": config.base,
        "SECRETKEY": config.secretkey,
        "EMAIL_HOST": config.email_host,
        "EMAIL_PORT": config.email_port,
        "EMAIL_USERNAME": config.email_username,
        "EMAIL_PASSWORD": config.email_password,
        "EMAIL_FROM": config.email_from,
        "AWS_ACCESS_KEY": config.aws_access_key_id,
        "AWS_SECRET_ACCESS_KEY": config.aws_secret_access_key,
        "PUBLIC_AWS_BUCKET": config.public_aws_bucket,
        "PRIVATE_AWS_BUCKET": config.private_aws_bucket,
        "TEMP_AWS_BUCKET": config.temp_aws_bucket,
        "AWS_CDN_URL": config.aws_cdn_url,
        "AWS_REGION": config.aws_region
    },
    "test": {
        "BASE": config.base,
        "SECRETKEY": config.secretkey,
        "EMAIL_HOST": config.email_host,
        "EMAIL_PORT": config.email_port,
        "EMAIL_USERNAME": config.email_username,
        "EMAIL_PASSWORD": config.email_password,
        "EMAIL_FROM": config.email_from,
        "PUBLIC_AWS_ACCESS_KEY": config.public_aws_access_key_id,
        "PUBLIC_AWS_SECRET_ACCESS_KEY": config.public_aws_secret_access_key,
        "PUBLIC_AWS_BUCKET": config.public_aws_bucket,
        "PRIVATE_AWS_ACCESS_KEY": config.private_aws_access_key_id,
        "PRIVATE_AWS_SECRET_ACCESS_KEY": config.private_aws_secret_access_key,
        "PRIVATE_AWS_BUCKET": config.private_aws_bucket,
        "TEMP_AWS_BUCKET": config.temp_aws_bucket,
        "AWS_CDN_URL": config.aws_cdn_url,
        "AWS_REGION": config.aws_region
    },
    "production": {
        "BASE": config.base,
        "SECRETKEY": config.secretkey,
        "EMAIL_HOST": config.email_host,
        "EMAIL_PORT": config.email_port,
        "EMAIL_USERNAME": config.email_username,
        "EMAIL_PASSWORD": config.email_password,
        "EMAIL_FROM": config.email_from,
        "PUBLIC_AWS_ACCESS_KEY": config.public_aws_access_key_id,
        "PUBLIC_AWS_SECRET_ACCESS_KEY": config.public_aws_secret_access_key,
        "PUBLIC_AWS_BUCKET": config.public_aws_bucket,
        "PRIVATE_AWS_ACCESS_KEY": config.private_aws_access_key_id,
        "PRIVATE_AWS_SECRET_ACCESS_KEY": config.private_aws_secret_access_key,
        "PRIVATE_AWS_BUCKET": config.private_aws_bucket,
        "TEMP_AWS_BUCKET": config.temp_aws_bucket,
        "AWS_CDN_URL": config.aws_cdn_url,
        "AWS_REGION": config.aws_region
    }
}