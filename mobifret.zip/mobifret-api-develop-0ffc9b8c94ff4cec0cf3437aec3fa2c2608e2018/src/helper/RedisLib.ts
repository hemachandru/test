import * as redis from 'redis';
import * as bluebird from 'bluebird';
import * as geoRedis from 'georedis';
import * as Scheduler from 'redis-scheduler';
bluebird.promisifyAll(redis.RedisClient.prototype);

export class RedisLib {
    private static instance: any;
    private static geoInstanceDriver: any;
    private static geoInstanceOrder: any;
    private static schedular: any;

    constructor() {
        if (!RedisLib.instance) {
            RedisLib.instance = redis.createClient(process.env.REDIS_PORT, process.env.REDIS_HOST);
        }

        RedisLib.instance.on("connect", function () {
            console.log("connected Redis");
        });
    }

    static getInstance() {
        if (!RedisLib.instance) {
            RedisLib.instance = redis.createClient(process.env.REDIS_POST, process.env.REDIS_HOST);
        }

        return RedisLib.instance;
    }

    static getGeoInstanceDriver() {
        if (!RedisLib.geoInstanceDriver && RedisLib.instance) {
            RedisLib.geoInstanceDriver = geoRedis.initialize(RedisLib.instance, {
                //zset: 'DriverLocation',
                zset: process.env.REDIS_ENV_PREFIX ? process.env.REDIS_ENV_PREFIX + 'DriverLocation' : 'DriverLocation',
                nativeGeo: false
            });
        } else {
            if (!RedisLib.instance) {
                RedisLib.instance = redis.createClient(process.env.REDIS_PORT, process.env.REDIS_HOST);
            }

            if (!RedisLib.geoInstanceDriver && RedisLib.instance) {
                RedisLib.geoInstanceDriver = geoRedis.initialize(RedisLib.instance, {
                    //zset: 'DriverLocation',
                    zset: process.env.REDIS_ENV_PREFIX ? process.env.REDIS_ENV_PREFIX + 'DriverLocation' : 'DriverLocation',
                    nativeGeo: false
                });

            }
        }

        return RedisLib.geoInstanceDriver.addSet(process.env.GEO_DRIVER_SET);
    }

    static getGeoInstanceOrder() {
        if (!RedisLib.geoInstanceOrder && RedisLib.instance) {
            RedisLib.geoInstanceOrder = geoRedis.initialize(RedisLib.instance, {
                //zset: 'OrderLocation',
                zset: process.env.REDIS_ENV_PREFIX ? process.env.REDIS_ENV_PREFIX + 'OrderLocation' : 'OrderLocation',
                nativeGeo: false
            });
        } else {
            if (!RedisLib.instance) {
                RedisLib.instance = redis.createClient(process.env.REDIS_POST, process.env.REDIS_HOST);
            }

            if (!RedisLib.geoInstanceOrder && RedisLib.instance) {
                RedisLib.geoInstanceOrder = geoRedis.initialize(RedisLib.instance, {
                    zset: process.env.REDIS_ENV_PREFIX ? process.env.REDIS_ENV_PREFIX + 'OrderLocation' : 'OrderLocation',
                    //zset: 'OrderLocation',
                    nativeGeo: false
                });
            }
        }

        return RedisLib.geoInstanceOrder;
    }

    static getSchedular() {
        return RedisLib.schedular = new Scheduler({ host: process.env.REDIS_HOST, port: process.env.REDIS_PORT });
    }
}