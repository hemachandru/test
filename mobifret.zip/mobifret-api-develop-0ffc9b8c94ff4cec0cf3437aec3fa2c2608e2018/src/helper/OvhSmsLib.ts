var ovh = require('ovh')({
    endpoint: process.env.OVH_END_POINT,
    appKey: process.env.OVH_SMS_APP_KEY,
    appSecret: process.env.OVH_SMS_APP_SECRET_KEY,
    consumerKey: process.env.OVH_SMS_APP_CONSUMER_KEY
});

export class SMSRequestLib {
    constructor() {
        //this.OvhSmsAuth()
    }

    // OvhSmsAuth() {
    //     ovh.request('POST', '/auth/credential', {
    //         'accessRules': [
    //           { 'method': 'GET', 'path': '/*'},
    //           { 'method': 'POST', 'path': '/*'},
    //           { 'method': 'PUT', 'path': '/*'},
    //           { 'method': 'DELETE', 'path': '/*'}
    //         ]
    //       }, function (error, credential) {
    //         console.log(error || credential);
    //       });
    // }


    //Order based SMS
    SmsRequest(data: any) {
        // Get the serviceName (name of your sms account)
        ovh.request('GET', '/sms/', function (err, serviceName) {
            if (err) {
                console.log(err, serviceName);
            }
            else {
                console.log("My account SMS is " + serviceName);
                // Send a simple SMS with a short number using your serviceName
                ovh.request('POST', '/sms/' + serviceName[0] + '/jobs', {
                    message: data.message,
                    senderForResponse: true,
                    // receivers: ['0033621141093']
                    receivers: ["0033"+data.deliveryCustomerNum]
                }, function (errsend, result) {
                    console.log(errsend, result);
                });
            }
        });
    }

    //Send sms from Admin side
    SMSAdminRequest(smsNotify: any) {
        // Get the serviceName (name of your sms account)
        console.log(smsNotify);
        ovh.request('GET', '/sms/', function (err, serviceName) {
            if (err) {
                console.log(err, serviceName);
            }
            else {
                console.log("My account SMS is " + serviceName);
                // Send a simple SMS with a short number using your serviceName
                ovh.request('POST', '/sms/' + serviceName[0] + '/jobs', {
                    message: smsNotify.message,
                    senderForResponse: true,
                    receivers: [smsNotify.mobile]
                }, function (errsend, result) {
                    console.log(errsend, result);
                });
            }
        });

    }

}