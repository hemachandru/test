import * as AWS from 'aws-sdk';

export class S3Lib {
    private options = {
        accessKeyId: process.env.AWS_ACCESS_KEY,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
        region: process.env.AWS_REGION
    };

    private s3 = new AWS.S3(this.options);

    constructor() {

    }

    async CopyObjectPublic(sourcePath, destinationPath): Promise<Boolean> {
        try {
            let params = {
                Bucket: process.env.PUBLIC_AWS_BUCKET,
                CopySource: process.env.TEMP_AWS_BUCKET + sourcePath,
                Key: destinationPath
            };
            let resultPromise = await this.s3.copyObject(params).promise();
            if (resultPromise.CopyObjectResult) {
                return true;
            }
            return false;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async CopyObjectPrivate(sourcePath, destinationPath): Promise<Boolean> {
        try {
            let params = {
                Bucket: process.env.PRIVATE_AWS_BUCKET,
                CopySource: process.env.TEMP_AWS_BUCKET + sourcePath,
                Key: destinationPath
            };
            let resultPromise = await this.s3.copyObject(params).promise();
            if (resultPromise.CopyObjectResult) {
                return true;
            }
            return false;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

    async FindObject(key): Promise<Boolean> {
        try {
            let params = {
                Bucket: process.env.TEMP_AWS_BUCKET,
                Key: key
            };
            let resultPromise = await this.s3.headObject(params).promise();
            if (resultPromise) {
                return true;
            }
            return false;
        } catch (e) {
            console.log(e);
            return false;
        }
    }

}