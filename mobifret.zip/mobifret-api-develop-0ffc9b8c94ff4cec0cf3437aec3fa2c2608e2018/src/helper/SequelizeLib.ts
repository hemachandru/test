import { Sequelize } from 'sequelize-typescript';
import { ModuleHandler } from './';
import { moduleConfig } from '../config/moduleConfig';

const dbConfig = require("../config/dbConfig")[process.env.NODE_ENV];

export class SequelizeLib {
    private static instance: SequelizeLib;
    private sequelize: Sequelize;
    private constructor() {
        // do something construct...
    }
    static getInstance() {
        if (!SequelizeLib.instance) {
            SequelizeLib.instance = new SequelizeLib();
            this.instance.sequelize = new Sequelize({
                name: dbConfig.database,
                dialect: dbConfig.dialect,
                username: dbConfig.username,
                password: dbConfig.password,
                host: dbConfig.host,
                port: dbConfig.port,
                modelPaths: ModuleHandler(this.instance.addModule())               
            });
            // ... any one time initialization goes here ...
        }
        return SequelizeLib.instance;
    }

    getSequelize() {
        return this.sequelize;
    }

    addModule() {
        return moduleConfig;
    }

}