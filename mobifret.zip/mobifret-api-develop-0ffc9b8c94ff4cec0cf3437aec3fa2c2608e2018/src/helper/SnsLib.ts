import * as AWS from 'aws-sdk';
import { Device } from "../modules/Account/models/Device";
import { DeviceService } from "../modules/Account/service/DeviceService";


export class SnsLib {

    private options = {
        accessKeyId: process.env.SNS_AWS_ACCESS_KEY,
        secretAccessKey: process.env.SNS_AWS_SECRET_ACCESS_KEY,
        region: process.env.AWS_REGION
    };
    private sns = new AWS.SNS(this.options);
    private deviceService = new DeviceService();

    constructor() {
    }

    // createTopic(topicName: string) {
    //     let params = {
    //         Name: topicName
    //     };
    //     sns.createTopic(params, function (err, data) {
    //         if (err) console.log(err, err.stack);
    //         else console.log(data);
    //     });
    // }

    async createTopic(topicName: string): Promise<any> {
        try {
            let params = {
                Name: topicName
            };
            let topicArn = await this.sns.createTopic(params).promise();
            return topicArn;
        } catch (e) {
            console.error("TOPIC CREATE", e);
            return false;
        }
    }

    async registerDevice(updateDevice: Device, appArn: string) {
        try {
            let self = this;
            let params = {
                PlatformApplicationArn: appArn,
                Token: updateDevice.deviceToken
            };
            let deviceArn = await this.sns.createPlatformEndpoint(params).promise();
            if (deviceArn) {
                updateDevice.deviceArn = deviceArn.EndpointArn;
                self.deviceService.UpdateDevice(updateDevice);
                return deviceArn;
            }
            return false;
            // sns.createPlatformEndpoint(params, function (err, data) {
            //     if (err) console.error("DEVICE CREATE ARN ISSUE", err, err.stack);
            //     else {
            //         console.log(data);
            //         updateDevice.deviceArn = data.EndpointArn;
            //         self.deviceService.UpdateDevice(updateDevice);
            //     }
            // });
        } catch (e) {
            console.error("DEVICE CREATE ARN ISSUE", e);
            return false;
        }
    }



    async sendPush(Arn: any, userID: any, type: any, title: any, body: any) {
        try {
            let bodyTxt: string;
            if (type == process.env.PUSH_TYPE_ACCEPT) {
                bodyTxt = "Your order is confirmed."
            } else if (type == process.env.PUSH_TYPE_COMPLETE) {
                bodyTxt = "Your order is delivered successfully."
            } else if (type == process.env.PUSH_TYPE_CANCEL) {
                bodyTxt = "Your order is been canceled."
            } else if (type == process.env.PUSH_TYPE_CANCEL && body.isDriver == 1) {
                bodyTxt = "The Order is cancelled by the customer."
            } else if (type == process.env.PUSH_TYPE_PICKUP) {
                bodyTxt = "The Order " + body.orderId + " status is pickedup."
            } else if (type == process.env.PUSH_TYPE_ASSIGN && body.isDriver == 1) {
                bodyTxt = "New order is planned for you by admin"
            } else if (type == process.env.PUSH_TYPE_ASSIGN && body.isDriver == 0) {
                bodyTxt = "Your order is confirmed."
            } else if (type == process.env.PUSH_TYPE_BLOCKED) {
                bodyTxt = "Your account is Blocked. Please contact your Admin or IT team"
            }

            let applePayload = {
                "aps": {
                    "alert": {
                        "title": "Mobifret",
                        "body": bodyTxt
                    }
                },
                "acme1": body,
                "type": type
            }
            console.log("ios-push-data1:" + applePayload.aps.alert.body);

            let androidPayload = {
                "data": {
                    "alert": {
                        "title": "Mobifret",
                        "body": body
                    },
                    "type": type
                },

            }

            let data = {
                default: "Mobifret",
                [process.env.SNS_IOS_PLATFORM]: JSON.stringify(applePayload),
                GCM: JSON.stringify(androidPayload),
            };
            console.log("ios-push-data2:" + data);

            let param = {
                Message: JSON.stringify(data),
                MessageStructure: 'json',
                TargetArn: Arn
            };

            if (userID) {
                let deviceToReg = await this.deviceService.GetDeviceUser(userID);
                console.log('Notification : param ============> ' + JSON.stringify(param))
                deviceToReg.forEach(element => {
                    if (element.status && element.deviceArn) {
                        param.TargetArn = element.deviceArn;
                        this.sns.publish(param, function (err, response) {
                            if (err) {
                                console.log('Notification : err ============> ' + err);
                            }
                            if (response) {
                                console.log('Notification : response ============> ' + JSON.stringify(response));
                            }
                        });
                    }
                });
                console.log("ios-push-data3:" + deviceToReg);

            } else {
                this.sns.publish(param).promise();
                console.log("ios-push-data4:" + param);
            }

        } catch (e) {
            console.error("SEND PUSH ERROR", e);
            return false;
        }
    }
}