import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Config } from '../../../config/constant';
import { HomeService } from '../service/home.service';

@Injectable()
export class HomeBusiness{
    constructor(
      private config: Config, 
      private router: Router, 
      private homeService: HomeService
    ) {}
    
    singleDescriptorBusiness(data) {
      let apiUrl = this.config.ediSingleUser + data
      // let apiUrl = "http://sit.infodynamic.net/ediservice/rest/jsonData/" + data
      return this.homeService.getJsonService(apiUrl).map((result => result));
    }

    saveJsonBusiness(data) {
      let apiUrl = this.config.saveJson + data
      return this.homeService.saveJsonService(apiUrl).map((result =>result));
    }


    descriptorListBusiness() {
      // debugger  
      // let apiUrl = this.config.ediUserList
      let apiUrl = this.config.demo
      return this.homeService.getJsonService(apiUrl).map((result => result));
    }


}