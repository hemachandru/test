import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { HttpRequestService } from '../../../shared/http-service/http-request.service';

@Injectable(
  // {providedIn: 'root'}
)
export class SharedService {

  constructor(private httpRequest: HttpRequestService) {}
  
  getJsonService(url: string) {
    // debugger
    return this.httpRequest.getHttpRequest(url);
  }
}