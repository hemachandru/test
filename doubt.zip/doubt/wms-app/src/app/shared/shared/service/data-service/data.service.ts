// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class DataService {
//   private data:any = undefined;
//   constructor() { }

//   setData(data:any){
//     this.data = data;
//   }

//   getData():any{
//     console.log(this.data)
//     // debugger
//     return this.data;
//   }

// }


import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class DataService {

    private _listners = new Subject<any>();
    private data:any = undefined;
    
    listen(): Observable<any> {
       console.log('observe')
       return this._listners.asObservable();
    }

    filter(id: any) {
      console.log('setting', id)
       this._listners.next(id);
    }
      
      setData(data:any){
         debugger
         this.data = data;
      }
      getData():any{
         debugger
         // console.log(this.data)
         return this.data;
      }

}
