import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TreeNestedComponent } from './components/tree-nested/tree-nested.component'

import {MatNativeDateModule} from '@angular/material';
import {DemoMaterialModule} from '../../../material-module';

import { ModalModule } from './components/modal';
import { ListGridComponent } from './components/list-grid/list-grid.component';
import { DragMultiTreeGridComponent } from './components/drag-multi-tree-grid/drag-multi-tree-grid.component';
import { TreeLoadmoreComponent } from './components/tree-loadmore/tree-loadmore.component';

@NgModule({
  declarations: [
    TreeNestedComponent,
    ListGridComponent,
    DragMultiTreeGridComponent,
    TreeLoadmoreComponent
  ],
  imports: [
    CommonModule,
    MatNativeDateModule,   
    DemoMaterialModule,
    ModalModule
  ],
  exports: [
    TreeNestedComponent,
    ListGridComponent,
    DragMultiTreeGridComponent,
    TreeLoadmoreComponent
  ]
})
export class SharedModule { }
