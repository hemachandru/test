import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Config } from '../../../config/constant';
import { SharedService } from '../service/shared.service';

@Injectable()
export class SharedBusiness{
    constructor(
      private config: Config, 
      private router: Router, 
      private shareService: SharedService
    ) {}
    
    singleDescriptorBusiness(data) {
      let apiUrl = this.config.ediSingleUser + data
      return this.shareService.getJsonService(apiUrl).map((result => result));
    }

    descriptorUserListBusiness() {
      let apiUrl = this.config.ediUserList
      return this.shareService.getJsonService(apiUrl).map((result => result));
    }


}