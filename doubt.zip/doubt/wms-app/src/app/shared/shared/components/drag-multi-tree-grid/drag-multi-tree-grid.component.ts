// import { Component, OnInit } from '@angular/core';

import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { Component, Injectable, ElementRef, ViewChild } from '@angular/core';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { BehaviorSubject } from 'rxjs';

/**
 * Node for to-do item
 */
export class TodoItemNode {
  children: TodoItemNode[];
  item: string;
}

/** Flat to-do item node with expandable and level information */
export class TodoItemFlatNode {
  item: string;
  level: number;
  expandable: boolean;
}

/**
 * The Json object for to-do list data.
 */

 const TREE_DATAs = {
  "index": 1,
  "xmltag": "Volume Header",
  "segcode": "VOL1",
  "id": 1,
  'expanded': true,
  "minOccurs": "0",
  "maxOccurs": "-1",
  "fieldList": [
      {
          "xmltag": "Record type",
          "from": 1,
          "to": 4,
          "length": 0,
          "propertyName": "",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "",
          "defaultValue": "VOL1",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": true
      },
      {
          "xmltag": "Submission serial unique identifier",
          "from": 5,
          "to": 10,
          "length": 0,
          "propertyName": "handhSequence",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "",
          "defaultValue": "",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": true
      },
      {
          "xmltag": "Filler",
          "from": 11,
          "to": 11,
          "length": 0,
          "propertyName": "",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "",
          "defaultValue": "",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": false
      },
      {
          "xmltag": "Filler",
          "from": 12,
          "to": 41,
          "length": 0,
          "propertyName": "",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "",
          "defaultValue": "",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": false
      },
      {
          "xmltag": "Submission agent reference code",
          "from": 42,
          "to": 51,
          "length": 0,
          "propertyName": "handhAgentRef",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "upper_case",
          "defaultValue": "",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": true
      },
      {
          "xmltag": "Filler",
          "from": 52,
          "to": 200,
          "length": 0,
          "propertyName": "",
          "arguments": [],
          "dataType": "TEXT",
          "dataFormat": "",
          "defaultValue": "",
          "leftPaddingSize": 0,
          "leftPaddingChar": "",
          "rightPaddingSize": 0,
          "rightPaddingChar": "",
          "mandatory": false
      }
  ],
  "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
  "segmentList": [
      {
          "index": 1,
          "xmltag": "First File Header",
          "segcode": "HDR1",
          "id": 2,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record type",
                  "from": 1,
                  "to": 4,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "HDR1",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Source identifier of originator",
                  "from": 5,
                  "to": 14,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "AMEX",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 15,
                  "to": 21,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Submission serial unique identifier",
                  "from": 22,
                  "to": 27,
                  "length": 0,
                  "propertyName": "handhSequence",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File section number",
                  "from": 28,
                  "to": 31,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "1",
                  "leftPaddingSize": 4,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File sequence number",
                  "from": 32,
                  "to": 35,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "1",
                  "leftPaddingSize": 4,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 36,
                  "to": 42,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File creation date(Julian Date Format)",
                  "from": 43,
                  "to": 47,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [
                      "0"
                  ],
                  "dataType": "TEXT",
                  "dataFormat": "JULIAN_DATE",
                  "defaultValue": "CURRENT_DATE",
                  "leftPaddingSize": 5,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 48,
                  "to": 48,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File expiry date(Julian Date Format)",
                  "from": 49,
                  "to": 53,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [
                      "30"
                  ],
                  "dataType": "TEXT",
                  "dataFormat": "JULIAN_DATE",
                  "defaultValue": "CURRENT_DATE",
                  "leftPaddingSize": 5,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Block count",
                  "from": 54,
                  "to": 60,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 7,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "System code",
                  "from": 61,
                  "to": 73,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 13,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 74,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 2,
          "xmltag": "Second File Header",
          "segcode": "HDR2",
          "id": 3,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record type",
                  "from": 1,
                  "to": 4,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "HDR2",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record format",
                  "from": 5,
                  "to": 5,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "F",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Block length",
                  "from": 6,
                  "to": 10,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "200",
                  "leftPaddingSize": 5,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record length",
                  "from": 11,
                  "to": 15,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "200",
                  "leftPaddingSize": 5,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Tape density",
                  "from": 16,
                  "to": 16,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "3",
                  "leftPaddingSize": 1,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Data set Position",
                  "from": 17,
                  "to": 17,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 1,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 18,
                  "to": 38,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Block attribute",
                  "from": 39,
                  "to": 39,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "B",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 40,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 3,
          "xmltag": "Transaction File Header",
          "segcode": "TFH",
          "id": 4,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record Type",
                  "from": 1,
                  "to": 3,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "TFH",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record sequence number",
                  "from": 4,
                  "to": 9,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [
                      "<#assign x = 1>"
                  ],
                  "dataType": "CUSTOM",
                  "dataFormat": "EXPRESSION",
                  "defaultValue": "x",
                  "leftPaddingSize": 6,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File Creation Date",
                  "from": 10,
                  "to": 15,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "DATE",
                  "dataFormat": "YYMMDD",
                  "defaultValue": "CURRENT_DATE",
                  "leftPaddingSize": 6,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File Creation Time",
                  "from": 16,
                  "to": 19,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "HHMM",
                  "defaultValue": "CURRENT_TIME",
                  "leftPaddingSize": 2,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 20,
                  "to": 22,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "AEME reference code",
                  "from": 23,
                  "to": 25,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "AMX",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Travel Agent Name",
                  "from": 26,
                  "to": 40,
                  "length": 0,
                  "propertyName": "handhCompanyName",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 41,
                  "to": 45,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Travel Agent Address",
                  "from": 46,
                  "to": 60,
                  "length": 0,
                  "propertyName": "handhCompanyAddress",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 61,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 4,
          "xmltag": "Transaction Batch Header",
          "segcode": "TBH",
          "id": 5,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record Type",
                  "from": 1,
                  "to": 3,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "TBH",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record sequence number",
                  "from": 4,
                  "to": 9,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [
                      "<#assign x = x+1>"
                  ],
                  "dataType": "CUSTOM",
                  "dataFormat": "EXPRESSION",
                  "defaultValue": "x",
                  "leftPaddingSize": 6,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "SE number",
                  "from": 10,
                  "to": 19,
                  "length": 0,
                  "propertyName": "handhSeNumber",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 10,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 20,
                  "to": 30,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Batch sequence number",
                  "from": 31,
                  "to": 33,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "1",
                  "leftPaddingSize": 3,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 34,
                  "to": 44,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File creation date",
                  "from": 45,
                  "to": 50,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "DATE",
                  "dataFormat": "YYMMDD",
                  "defaultValue": "CURRENT_DATE",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Currency Code",
                  "from": 51,
                  "to": 53,
                  "length": 0,
                  "propertyName": "handhCompanyCurrency",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "SOC reference number indicator",
                  "from": 54,
                  "to": 56,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "SOC reference number",
                  "from": 57,
                  "to": 62,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 6,
                  "leftPaddingChar": "0",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 63,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
          "segmentList": [
              {
                  "index": 1,
                  "xmltag": "Transaction Advice Basic",
                  "segcode": "TAB",
                  "id": 6,
                  'expanded': true,
                  "minOccurs": "0",
                  "maxOccurs": "-1",
                  "fieldList": [
                      {
                          "xmltag": "Record Type",
                          "from": 1,
                          "to": 3,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Record sequence number",
                          "from": 4,
                          "to": 9,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 10,
                          "to": 11,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Cardmember account No",
                          "from": 12,
                          "to": 26,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 27,
                          "to": 30,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 31,
                          "to": 32,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 33,
                          "to": 33,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Transaction type indicator",
                          "from": 34,
                          "to": 35,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Transaction value",
                          "from": 36,
                          "to": 43,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Transaction currency",
                          "from": 44,
                          "to": 46,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 47,
                          "to": 54,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "AEME Approval Code",
                          "from": 55,
                          "to": 56,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 57,
                          "to": 60,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Transaction Date",
                          "from": 61,
                          "to": 66,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 67,
                          "to": 70,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Invoice/Credit Note number",
                          "from": 71,
                          "to": 79,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 80,
                          "to": 82,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 83,
                          "to": 85,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Card expiry date",
                          "from": 86,
                          "to": 89,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "SE name",
                          "from": 90,
                          "to": 104,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 105,
                          "to": 109,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "SE address",
                          "from": 110,
                          "to": 124,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 125,
                          "to": 129,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Cardmember name",
                          "from": 130,
                          "to": 155,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Product code",
                          "from": 156,
                          "to": 158,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 159,
                          "to": 159,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Consultant Code",
                          "from": 160,
                          "to": 162,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 163,
                          "to": 163,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "REF 1",
                          "from": 164,
                          "to": 172,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 173,
                          "to": 173,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Departure date",
                          "from": 174,
                          "to": 179,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 180,
                          "to": 180,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Travel Office Code",
                          "from": 181,
                          "to": 189,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 190,
                          "to": 195,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Reserved",
                          "from": 196,
                          "to": 200,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      }
                  ],
                  "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                  "segmentList": [
                      {
                          "index": 2,
                          "xmltag": "Transaction Advice Addendum",
                          "segcode": "TAA",
                          "id": 7,
                          'expanded': true,
                          "minOccurs": "0",
                          "maxOccurs": "-1",
                          "fieldList": [
                              {
                                  "xmltag": "Record type",
                                  "from": 1,
                                  "to": 3,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "TAB",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Record sequence number",
                                  "from": 4,
                                  "to": 9,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [
                                      "<#assign x = x+1>"
                                  ],
                                  "dataType": "CUSTOM",
                                  "dataFormat": "EXPRESSION",
                                  "defaultValue": "x",
                                  "leftPaddingSize": 6,
                                  "leftPaddingChar": "0",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Cardmember account No",
                                  "from": 10,
                                  "to": 24,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 25,
                                  "to": 28,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Carrier/Supplier Name",
                                  "from": 29,
                                  "to": 48,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Destination",
                                  "from": 49,
                                  "to": 68,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Government Sales Tax Amount",
                                  "from": 69,
                                  "to": 82,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Government Sales Tax Indicator",
                                  "from": 83,
                                  "to": 83,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 84,
                                  "to": 89,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Agency commission amount",
                                  "from": 90,
                                  "to": 103,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Agency commission %",
                                  "from": 104,
                                  "to": 107,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 108,
                                  "to": 108,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Agency rebate amount",
                                  "from": 109,
                                  "to": 122,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Agency rebate %",
                                  "from": 123,
                                  "to": 126,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 127,
                                  "to": 128,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Product Specific Information",
                                  "from": 129,
                                  "to": 148,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 3",
                                  "from": 149,
                                  "to": 158,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 4",
                                  "from": 159,
                                  "to": 168,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Customer Initials",
                                  "from": 169,
                                  "to": 170,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Customer Surname",
                                  "from": 171,
                                  "to": 188,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Reserved",
                                  "from": 189,
                                  "to": 200,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              }
                          ],
                          "propertyName": "",
                          "segmentList": [],
                          "displaySegmentListAsSingleLine": false
                      },
                      {
                          "index": 3,
                          "xmltag": "Transaction Advice Mandatory ",
                          "segcode": "TAM",
                          "id": 8,
                          'expanded': true,
                          "minOccurs": "0",
                          "maxOccurs": "-1",
                          "fieldList": [
                              {
                                  "xmltag": "Record Type",
                                  "from": 1,
                                  "to": 3,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "SROC Record Sequence Number",
                                  "from": 4,
                                  "to": 9,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Cardmember Account Number",
                                  "from": 10,
                                  "to": 24,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 5",
                                  "from": 25,
                                  "to": 39,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 6",
                                  "from": 40,
                                  "to": 44,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 7",
                                  "from": 45,
                                  "to": 54,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "REF 2",
                                  "from": 55,
                                  "to": 78,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 79,
                                  "to": 200,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              }
                          ],
                          "propertyName": "",
                          "segmentList": [],
                          "displaySegmentListAsSingleLine": false
                      },
                      {
                          "index": 4,
                          "xmltag": "Transaction Advice Ticket",
                          "segcode": "TAT",
                          "id": 9,
                          'expanded': true,
                          "minOccurs": "0",
                          "maxOccurs": "-1",
                          "fieldList": [
                              {
                                  "xmltag": "Record type",
                                  "from": 1,
                                  "to": 3,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Record sequence number",
                                  "from": 4,
                                  "to": 9,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Cardmember Account No",
                                  "from": 10,
                                  "to": 24,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Air Ticket Number",
                                  "from": 25,
                                  "to": 38,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Sales Tax Currency",
                                  "from": 39,
                                  "to": 41,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Sales Tax Amount",
                                  "from": 42,
                                  "to": 51,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Sales Tax Code",
                                  "from": 52,
                                  "to": 53,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Total Airport Tax Currency",
                                  "from": 54,
                                  "to": 56,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Total Airport Tax Amount",
                                  "from": 57,
                                  "to": 68,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "PNR Locator",
                                  "from": 69,
                                  "to": 79,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 80,
                                  "to": 80,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Net remit indicator",
                                  "from": 81,
                                  "to": 81,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 82,
                                  "to": 138,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 139,
                                  "to": 139,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Conjunction ticket number suffix.",
                                  "from": 140,
                                  "to": 142,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "IATA Code",
                                  "from": 143,
                                  "to": 150,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Airline Commission %",
                                  "from": 151,
                                  "to": 153,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 154,
                                  "to": 200,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              }
                          ],
                          "propertyName": "",
                          "segmentList": [],
                          "displaySegmentListAsSingleLine": false
                      },
                      {
                          "index": 5,
                          "xmltag": "Transaction Advice Ticket Further Information ",
                          "segcode": "TAF",
                          "id": 10,
                          'expanded': true,
                          "minOccurs": "0",
                          "maxOccurs": "-1",
                          "fieldList": [
                              {
                                  "xmltag": "Record type",
                                  "from": 1,
                                  "to": 3,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Record sequence number",
                                  "from": 4,
                                  "to": 9,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Cardmember account No",
                                  "from": 10,
                                  "to": 24,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Air ticket number",
                                  "from": 25,
                                  "to": 38,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket transaction code",
                                  "from": 39,
                                  "to": 42,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Date of ticket issue",
                                  "from": 43,
                                  "to": 50,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Fare Currency",
                                  "from": 51,
                                  "to": 53,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Fare Amount",
                                  "from": 54,
                                  "to": 65,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Ticket Tour Code",
                                  "from": 66,
                                  "to": 79,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Equivalent fare paid currency",
                                  "from": 80,
                                  "to": 82,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Equivalent Fare paid amount",
                                  "from": 83,
                                  "to": 94,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 95,
                                  "to": 124,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Preceding Ticket Number",
                                  "from": 125,
                                  "to": 138,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              },
                              {
                                  "xmltag": "Filler",
                                  "from": 139,
                                  "to": 200,
                                  "length": 0,
                                  "propertyName": "",
                                  "arguments": [],
                                  "dataType": "TEXT",
                                  "dataFormat": "",
                                  "defaultValue": "",
                                  "leftPaddingSize": 0,
                                  "leftPaddingChar": "",
                                  "rightPaddingSize": 0,
                                  "rightPaddingChar": "",
                                  "mandatory": true
                              }
                          ],
                          "propertyName": "",
                          "segmentList": [
                              {
                                  "index": 1,
                                  "xmltag": "Transaction  Advice  Sector  Additional  Data ",
                                  "segcode": "TAS",
                                  "id": 11,
                                  'expanded': true,
                                  "minOccurs": "0",
                                  "maxOccurs": "-1",
                                  "fieldList": [
                                      {
                                          "xmltag": "Record type",
                                          "from": 1,
                                          "to": 3,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Record sequence No",
                                          "from": 4,
                                          "to": 9,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Cardmember Account No",
                                          "from": 10,
                                          "to": 24,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Air ticket number",
                                          "from": 25,
                                          "to": 38,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Conjunction Tkt No",
                                          "from": 39,
                                          "to": 52,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Sector Number",
                                          "from": 53,
                                          "to": 53,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Refund Sector indicator",
                                          "from": 54,
                                          "to": 54,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Carrier code",
                                          "from": 55,
                                          "to": 56,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Filler",
                                          "from": 57,
                                          "to": 57,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Flight number",
                                          "from": 58,
                                          "to": 61,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Sector Arrival time",
                                          "from": 62,
                                          "to": 65,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Sector Arrival date",
                                          "from": 66,
                                          "to": 73,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Sector Departure time",
                                          "from": 74,
                                          "to": 77,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Sector Departure date",
                                          "from": 78,
                                          "to": 85,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Departure Airport Code",
                                          "from": 86,
                                          "to": 88,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Filler",
                                          "from": 89,
                                          "to": 90,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Arrival Airport Code",
                                          "from": 91,
                                          "to": 93,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Filler",
                                          "from": 94,
                                          "to": 95,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Flight class",
                                          "from": 96,
                                          "to": 96,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Filler",
                                          "from": 97,
                                          "to": 97,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Stopover indicator",
                                          "from": 98,
                                          "to": 98,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Fare Basis Code",
                                          "from": 99,
                                          "to": 113,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      },
                                      {
                                          "xmltag": "Filler",
                                          "from": 114,
                                          "to": 200,
                                          "length": 0,
                                          "propertyName": "",
                                          "arguments": [],
                                          "dataType": "TEXT",
                                          "dataFormat": "",
                                          "defaultValue": "",
                                          "leftPaddingSize": 0,
                                          "leftPaddingChar": "",
                                          "rightPaddingSize": 0,
                                          "rightPaddingChar": "",
                                          "mandatory": true
                                      }
                                  ],
                                  "propertyName": "",
                                  "segmentList": [],
                                  "displaySegmentListAsSingleLine": false
                              }
                          ],
                          "displaySegmentListAsSingleLine": false
                      }
                  ],
                  "displaySegmentListAsSingleLine": false
              },
              {
                  "index": 5,
                  "xmltag": "Transaction Batch Trailer ",
                  "segcode": "TBT",
                  "id": 12,
                  'expanded': true,
                  "minOccurs": "0",
                  "maxOccurs": "-1",
                  "fieldList": [
                      {
                          "xmltag": "Record Type",
                          "from": 1,
                          "to": 3,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Record sequence number",
                          "from": 4,
                          "to": 9,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "SE number",
                          "from": 10,
                          "to": 19,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 20,
                          "to": 30,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Batch sequence number",
                          "from": 1,
                          "to": 33,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 34,
                          "to": 44,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Creation Date",
                          "from": 45,
                          "to": 50,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Total number Debit transactions",
                          "from": 51,
                          "to": 56,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Total amount Debit transactions",
                          "from": 57,
                          "to": 68,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Total number Credit transactions",
                          "from": 69,
                          "to": 74,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Total amount Credit transactions",
                          "from": 75,
                          "to": 86,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Total number items",
                          "from": 87,
                          "to": 92,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      },
                      {
                          "xmltag": "Filler",
                          "from": 93,
                          "to": 200,
                          "length": 0,
                          "propertyName": "",
                          "arguments": [],
                          "dataType": "TEXT",
                          "dataFormat": "",
                          "defaultValue": "",
                          "leftPaddingSize": 0,
                          "leftPaddingChar": "",
                          "rightPaddingSize": 0,
                          "rightPaddingChar": "",
                          "mandatory": true
                      }
                  ],
                  "propertyName": "",
                  "segmentList": [],
                  "displaySegmentListAsSingleLine": false
              }
          ],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 6,
          "xmltag": "Transaction File Summary",
          "segcode": "TFS",
          "id": 13,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record Type",
                  "from": 1,
                  "to": 3,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record sequence number",
                  "from": 4,
                  "to": 9,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Batch Count",
                  "from": 10,
                  "to": 13,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 14,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 7,
          "xmltag": "First File Trailer ",
          "segcode": "EOF1",
          "id": 14,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record type",
                  "from": 1,
                  "to": 4,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Source identifier of originator",
                  "from": 5,
                  "to": 14,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 15,
                  "to": 21,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Submission serial unique identifier",
                  "from": 22,
                  "to": 27,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File section number",
                  "from": 28,
                  "to": 31,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File sequence number",
                  "from": 32,
                  "to": 35,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 36,
                  "to": 42,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File Creation Date(Julian Date Format)",
                  "from": 43,
                  "to": 47,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 48,
                  "to": 48,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "File expiry date(Julian Date Format)",
                  "from": 49,
                  "to": 53,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 54,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      },
      {
          "index": 8,
          "xmltag": "Second File Trailer",
          "segcode": "EOF2",
          "id": 15,
          'expanded': true,
          "minOccurs": "0",
          "maxOccurs": "-1",
          "fieldList": [
              {
                  "xmltag": "Record type",
                  "from": 1,
                  "to": 4,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record format",
                  "from": 5,
                  "to": 5,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Block length",
                  "from": 6,
                  "to": 10,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Record length",
                  "from": 11,
                  "to": 15,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Tape density",
                  "from": 16,
                  "to": 16,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Data set Position",
                  "from": 17,
                  "to": 17,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 18,
                  "to": 38,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Block attribute",
                  "from": 39,
                  "to": 39,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              },
              {
                  "xmltag": "Filler",
                  "from": 40,
                  "to": 200,
                  "length": 0,
                  "propertyName": "",
                  "arguments": [],
                  "dataType": "TEXT",
                  "dataFormat": "",
                  "defaultValue": "",
                  "leftPaddingSize": 0,
                  "leftPaddingChar": "",
                  "rightPaddingSize": 0,
                  "rightPaddingChar": "",
                  "mandatory": true
              }
          ],
          "propertyName": "",
          "segmentList": [],
          "displaySegmentListAsSingleLine": false
      }
  ],
  "displaySegmentListAsSingleLine": false
}

const TREE_DATA11 = {
    "segmentList":[
        {
            "index": 1,
            "xmltag": "First File Header",
            "segcode": "HDR1",
            "id": 2,
            'expanded': true,
            "minOccurs": "0",
            "maxOccurs": "-1",
            "fieldList": [
                {
                    "xmltag": "Record type",
                    "from": 1,
                    "to": 4,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "HDR1",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Source identifier of originator",
                    "from": 5,
                    "to": 14,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "AMEX",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 15,
                    "to": 21,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Submission serial unique identifier",
                    "from": 22,
                    "to": 27,
                    "length": 0,
                    "propertyName": "handhSequence",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File section number",
                    "from": 28,
                    "to": 31,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "1",
                    "leftPaddingSize": 4,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File sequence number",
                    "from": 32,
                    "to": 35,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "1",
                    "leftPaddingSize": 4,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 36,
                    "to": 42,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File creation date(Julian Date Format)",
                    "from": 43,
                    "to": 47,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [
                        "0"
                    ],
                    "dataType": "TEXT",
                    "dataFormat": "JULIAN_DATE",
                    "defaultValue": "CURRENT_DATE",
                    "leftPaddingSize": 5,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 48,
                    "to": 48,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File expiry date(Julian Date Format)",
                    "from": 49,
                    "to": 53,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [
                        "30"
                    ],
                    "dataType": "TEXT",
                    "dataFormat": "JULIAN_DATE",
                    "defaultValue": "CURRENT_DATE",
                    "leftPaddingSize": 5,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Block count",
                    "from": 54,
                    "to": 60,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 7,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "System code",
                    "from": 61,
                    "to": 73,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 13,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 74,
                    "to": 200,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                }
            ],
            "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
            "segmentList": [],
            "displaySegmentListAsSingleLine": false
        },
        {
            "index": 2,
            "xmltag": "Second File Header",
            "segcode": "HDR2",
            "id": 3,
            'expanded': true,
            "minOccurs": "0",
            "maxOccurs": "-1",
            "fieldList": [
                {
                    "xmltag": "Record type",
                    "from": 1,
                    "to": 4,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "HDR2",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Record format",
                    "from": 5,
                    "to": 5,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "F",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Block length",
                    "from": 6,
                    "to": 10,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "200",
                    "leftPaddingSize": 5,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Record length",
                    "from": 11,
                    "to": 15,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "200",
                    "leftPaddingSize": 5,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Tape density",
                    "from": 16,
                    "to": 16,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "3",
                    "leftPaddingSize": 1,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Data set Position",
                    "from": 17,
                    "to": 17,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 1,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 18,
                    "to": 38,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Block attribute",
                    "from": 39,
                    "to": 39,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "B",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 40,
                    "to": 200,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                }
            ],
            "propertyName": "",
            "segmentList": [],
            "displaySegmentListAsSingleLine": false
        },
        {
            "index": 3,
            "xmltag": "Transaction File Header",
            "segcode": "TFH",
            "id": 4,
            'expanded': true,
            "minOccurs": "0",
            "maxOccurs": "-1",
            "fieldList": [
                {
                    "xmltag": "Record Type",
                    "from": 1,
                    "to": 3,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "TFH",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Record sequence number",
                    "from": 4,
                    "to": 9,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [
                        "<#assign x = 1>"
                    ],
                    "dataType": "CUSTOM",
                    "dataFormat": "EXPRESSION",
                    "defaultValue": "x",
                    "leftPaddingSize": 6,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File Creation Date",
                    "from": 10,
                    "to": 15,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "DATE",
                    "dataFormat": "YYMMDD",
                    "defaultValue": "CURRENT_DATE",
                    "leftPaddingSize": 6,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "File Creation Time",
                    "from": 16,
                    "to": 19,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "HHMM",
                    "defaultValue": "CURRENT_TIME",
                    "leftPaddingSize": 2,
                    "leftPaddingChar": "0",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 20,
                    "to": 22,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "AEME reference code",
                    "from": 23,
                    "to": 25,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "AMX",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Travel Agent Name",
                    "from": 26,
                    "to": 40,
                    "length": 0,
                    "propertyName": "handhCompanyName",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 41,
                    "to": 45,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Travel Agent Address",
                    "from": 46,
                    "to": 60,
                    "length": 0,
                    "propertyName": "handhCompanyAddress",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                },
                {
                    "xmltag": "Filler",
                    "from": 61,
                    "to": 200,
                    "length": 0,
                    "propertyName": "",
                    "arguments": [],
                    "dataType": "TEXT",
                    "dataFormat": "",
                    "defaultValue": "",
                    "leftPaddingSize": 0,
                    "leftPaddingChar": "",
                    "rightPaddingSize": 0,
                    "rightPaddingChar": "",
                    "mandatory": true
                }
            ],
            "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
            "segmentList": [],
            "displaySegmentListAsSingleLine": false
        }
    ]
}
const TREE_DATA = {
  Groceries: {
    'Almond Meal flour': null,
    'Organic eggs': null,
    'Protein Powder': null,
    Fruits: {
      Apple: null,
      Berries: ['Blueberry', 'Raspberry'],
      Orange: null
    }
  },
  Reminders: [
    'Cook dinner',
    'Read the Material Design spec',
    'Upgrade Application to Angular'
  ]
};



@Injectable()
export class ChecklistDatabase {
  dataChange = new BehaviorSubject<TodoItemNode[]>([]);

  get data(): TodoItemNode[] { return this.dataChange.value; }

  constructor() {
    this.initialize();
  }

  initialize() {
    // Build the tree nodes from Json object. The result is a list of `TodoItemNode` with nested
    //     file node as children.
    const data = this.buildFileTree(TREE_DATA, 0);

    // Notify the change.
    this.dataChange.next(data);
  }

  /**
   * Build the file structure tree. The `value` is the Json object, or a sub-tree of a Json object.
   * The return value is the list of `TodoItemNode`.
   */
  buildFileTree(obj: object, level: number): TodoItemNode[] {
    return Object.keys(obj).reduce<TodoItemNode[]>((accumulator, key) => {
      const value = obj[key];
      const node = new TodoItemNode();
      node.item = key;

      if (value != null) {
        if (typeof value === 'object') {
          node.children = this.buildFileTree(value, level + 1);
        } else {
          node.item = value;
        }
      }

      return accumulator.concat(node);
    }, []);
  }

  /** Add an item to to-do list */
  insertItem(parent: TodoItemNode, name: string): TodoItemNode {
    if (!parent.children) {
      parent.children = [];
    }
    const newItem = { item: name } as TodoItemNode;
    parent.children.push(newItem);
    this.dataChange.next(this.data);
    return newItem;
  }

  insertItemAbove(node: TodoItemNode, name: string): TodoItemNode {
    const parentNode = this.getParentFromNodes(node);
    const newItem = { item: name } as TodoItemNode;
    if (parentNode != null) {
      parentNode.children.splice(parentNode.children.indexOf(node), 0, newItem);
    } else {
      this.data.splice(this.data.indexOf(node), 0, newItem);
    }
    this.dataChange.next(this.data);
    return newItem;
  }

  insertItemBelow(node: TodoItemNode, name: string): TodoItemNode {
    const parentNode = this.getParentFromNodes(node);
    const newItem = { item: name } as TodoItemNode;
    if (parentNode != null) {
      parentNode.children.splice(parentNode.children.indexOf(node) + 1, 0, newItem);
    } else {
      this.data.splice(this.data.indexOf(node) + 1, 0, newItem);
    }
    this.dataChange.next(this.data);
    return newItem;
  }

  getParentFromNodes(node: TodoItemNode): TodoItemNode {
    for (let i = 0; i < this.data.length; ++i) {
      const currentRoot = this.data[i];
      const parent = this.getParent(currentRoot, node);
      if (parent != null) {
        return parent;
      }
    }
    return null;
  }

  getParent(currentRoot: TodoItemNode, node: TodoItemNode): TodoItemNode {
    if (currentRoot.children && currentRoot.children.length > 0) {
      for (let i = 0; i < currentRoot.children.length; ++i) {
        const child = currentRoot.children[i];
        if (child === node) {
          return currentRoot;
        } else if (child.children && child.children.length > 0) {
          const parent = this.getParent(child, node);
          if (parent != null) {
            return parent;
          }
        }
      }
    }
    return null;
  }

  updateItem(node: TodoItemNode, name: string) {
    node.item = name;
    this.dataChange.next(this.data);
  }

  deleteItem(node: TodoItemNode) {
    this.deleteNode(this.data, node);
    this.dataChange.next(this.data);
  }

  copyPasteItem(from: TodoItemNode, to: TodoItemNode): TodoItemNode {
    const newItem = this.insertItem(to, from.item);
    if (from.children) {
      from.children.forEach(child => {
        this.copyPasteItem(child, newItem);
      });
    }
    return newItem;
  }

  copyPasteItemAbove(from: TodoItemNode, to: TodoItemNode): TodoItemNode {
    const newItem = this.insertItemAbove(to, from.item);
    if (from.children) {
      from.children.forEach(child => {
        this.copyPasteItem(child, newItem);
      });
    }
    return newItem;
  }

  copyPasteItemBelow(from: TodoItemNode, to: TodoItemNode): TodoItemNode {
    const newItem = this.insertItemBelow(to, from.item);
    if (from.children) {
      from.children.forEach(child => {
        this.copyPasteItem(child, newItem);
      });
    }
    return newItem;
  }

  deleteNode(nodes: TodoItemNode[], nodeToDelete: TodoItemNode) {
    const index = nodes.indexOf(nodeToDelete, 0);
    if (index > -1) {
      nodes.splice(index, 1);
    } else {
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          this.deleteNode(node.children, nodeToDelete);
        }
      });
    }
  }
}



@Component({
  selector: 'app-drag-multi-tree-grid',
  templateUrl: './drag-multi-tree-grid.component.html',
  styleUrls: ['./drag-multi-tree-grid.component.scss'],
  providers: [ChecklistDatabase]
})
export class DragMultiTreeGridComponent {
  /** Map from flat node to nested node. This helps us finding the nested node to be modified */
  flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

  /** Map from nested node to flattened node. This helps us to keep the same object for selection */
  nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

  /** A selected parent node to be inserted */
  selectedParent: TodoItemFlatNode | null = null;

  /** The new item's name */
  newItemName = '';

  treeControl: FlatTreeControl<TodoItemFlatNode>;

  treeFlattener: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

  dataSource: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

  /** The selection for checklist */
  checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);

  /* Drag and drop */
  dragNode: any;
  dragNodeExpandOverWaitTimeMs = 300;
  dragNodeExpandOverNode: any;
  dragNodeExpandOverTime: number;
  dragNodeExpandOverArea: string;
  @ViewChild('emptyItem') emptyItem: ElementRef;

  constructor(private database: ChecklistDatabase) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

    database.dataChange.subscribe(data => {
      this.dataSource.data = [];
      this.dataSource.data = data;
    });
  }

  getLevel = (node: TodoItemFlatNode) => node.level;

  isExpandable = (node: TodoItemFlatNode) => node.expandable;

  getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

  hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

  hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.item === '';

  /**
   * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
   */
  transformer = (node: TodoItemNode, level: number) => {
    const existingNode = this.nestedNodeMap.get(node);
    const flatNode = existingNode && existingNode.item === node.item
      ? existingNode
      : new TodoItemFlatNode();
    flatNode.item = node.item;
    flatNode.level = level;
    flatNode.expandable = (node.children && node.children.length > 0);
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  }

  /** Whether all the descendants of the node are selected */
  descendantsAllSelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    return descendants.every(child => this.checklistSelection.isSelected(child));
  }

  /** Whether part of the descendants are selected */
  descendantsPartiallySelected(node: TodoItemFlatNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.descendantsAllSelected(node);
  }

  /** Toggle the to-do item selection. Select/deselect all the descendants node */
  todoItemSelectionToggle(node: TodoItemFlatNode): void {
    this.checklistSelection.toggle(node);
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
  }

  /** Select the category so we can insert the new item. */
  addNewItem(node: TodoItemFlatNode) {
    const parentNode = this.flatNodeMap.get(node);
    this.database.insertItem(parentNode, '');
    this.treeControl.expand(node);
  }

  /** Save the node to database */
  saveNode(node: TodoItemFlatNode, itemValue: string) {
    const nestedNode = this.flatNodeMap.get(node);
    this.database.updateItem(nestedNode, itemValue);
  }

  handleDragStart(event, node) {
    // Required by Firefox (https://stackoverflow.com/questions/19055264/why-doesnt-html5-drag-and-drop-work-in-firefox)
    event.dataTransfer.setData('foo', 'bar');
    event.dataTransfer.setDragImage(this.emptyItem.nativeElement, 0, 0);
    this.dragNode = node;
    this.treeControl.collapse(node);
  }

  handleDragOver(event, node) {
    event.preventDefault();

    // Handle node expand
    if (node === this.dragNodeExpandOverNode) {
      if (this.dragNode !== node && !this.treeControl.isExpanded(node)) {
        if ((new Date().getTime() - this.dragNodeExpandOverTime) > this.dragNodeExpandOverWaitTimeMs) {
          this.treeControl.expand(node);
        }
      }
    } else {
      this.dragNodeExpandOverNode = node;
      this.dragNodeExpandOverTime = new Date().getTime();
    }

    // Handle drag area
    const percentageX = event.offsetX / event.target.clientWidth;
    const percentageY = event.offsetY / event.target.clientHeight;
    if (percentageY < 0.25) {
      this.dragNodeExpandOverArea = 'above';
    } else if (percentageY > 0.75) {
      this.dragNodeExpandOverArea = 'below';
    } else {
      this.dragNodeExpandOverArea = 'center';
    }
  }

  handleDrop(event, node) {
    event.preventDefault();
    if (node !== this.dragNode) {
      let newItem: TodoItemNode;
      if (this.dragNodeExpandOverArea === 'above') {
        newItem = this.database.copyPasteItemAbove(this.flatNodeMap.get(this.dragNode), this.flatNodeMap.get(node));
      } else if (this.dragNodeExpandOverArea === 'below') {
        newItem = this.database.copyPasteItemBelow(this.flatNodeMap.get(this.dragNode), this.flatNodeMap.get(node));
      } else {
        newItem = this.database.copyPasteItem(this.flatNodeMap.get(this.dragNode), this.flatNodeMap.get(node));
      }
      this.database.deleteItem(this.flatNodeMap.get(this.dragNode));
      this.treeControl.expandDescendants(this.nestedNodeMap.get(newItem));
    }
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
  }

  handleDragEnd(event) {
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
  }
}