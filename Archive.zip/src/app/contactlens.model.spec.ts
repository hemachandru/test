import { Contactlens } from './contactlens.model';

describe('Contactlens', () => {
  it('should create an instance', () => {
    expect(new Contactlens()).toBeTruthy();
  });
});
