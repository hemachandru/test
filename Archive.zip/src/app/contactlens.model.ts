export class Contactlens {
    id!: number;
    name!: string;
}
