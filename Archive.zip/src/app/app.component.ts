import { Component, OnInit } from '@angular/core';

import {Contactlens} from "./contactlens.model";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  // constructor(private cLens: Contactlens) {}

  btnBack : any = 0;
  btnNext : any = 1;
  btnBackBool = false;
  btnNextBool = false;

  ngOnInit() {
    // this.cLens.id = 1;
    // this.cLens.name = "qqqq";
    this.btnConditions();
  }
  btnConditions() {
    this.btnBackBool = (this.btnBack !== 0) ? this.btnBackBool = true : this.btnBackBool = false;
    this.btnNextBool = (this.btnNext !== 0) ? this.btnNextBool = true : this.btnNextBool = false;
  }

  clickNext() { 
    this.btnBack ++;
    this.btnNext ++;
    this.btnConditions();
  }

  clickBack() {
    this.btnBack --;
    this.btnNext --;
    this.btnConditions();
  }
}
