import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selectedproduct',
  templateUrl: './selectedproduct.component.html',
  styleUrls: ['./selectedproduct.component.css']
})
export class SelectedproductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
