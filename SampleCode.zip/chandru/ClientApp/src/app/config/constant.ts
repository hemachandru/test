export class Config {
    emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
    //login = "https://reqres.in/api/login"
  login = "/token"
  list = "https://reqres.in/api/users?page=1"

  responseTypes = {
      error: "Error",
      success: "Success",
      warning: "Warning"
    }
  }
