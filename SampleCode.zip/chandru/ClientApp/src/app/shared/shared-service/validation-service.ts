import { FormGroup } from "@angular/forms";

export class ValidationService {

  

  static getValidatorErrorMessage(controlname, validatorName: string, validatorValue?: any) {
    let config = {
      'email': {
        'required': 'Please enter a email id',
        'pattern': 'Please enter a valid email id'
      },
      'password': {
        'required': 'Please enter a Password.',
        'pattern': 'Password  alphanumeric and special characters.',
      },

      'shipname': {
        'required': 'Please enter a Ship Name.',
      },
      'vesselcode': {
        'required': 'Please enter a Vessel Code.',
      },      
      'displacementTonnage': {
        'required': 'Please enter a Displacement Tonnage.',
      },
      'registerTonnage': {
        'required': 'Please enter a Register Tonnage.',
      },      
      'beam': {
        'required': 'Please enter a Beam.',
      },
      'deadWeightTonnage': {
        'required': 'Please enter a Dead Weight Tonnage.',
      },      
      'draft': {
        'required': 'Please enter a Draft.',
      },
      'length': {
        'required': 'Please enter a Length.',
      },      
      'ownerCompany': {
        'required': 'Please enter a Owner Company.',
      },
      'callSign': {
        'required': 'Please enter a Call Sign.',
      },
      'description': {
        'required': 'Please enter a Description.',
      }

    };
    return config[controlname][validatorName];
  }

  static isNullOrEmpty(val: any): boolean {
    if (val != undefined && val != null) {
      if (typeof val === "string") {
        return val.toString().trim() != '' ? false : true;
      }
      else {
        return false;
      }
    }
    else {
      return true;
    }
  }

}
