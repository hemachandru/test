import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErrorToasterMessagesComponent } from './error-toaster-messages.component';

describe('ErrorToasterMessagesComponent', () => {
  let component: ErrorToasterMessagesComponent;
  let fixture: ComponentFixture<ErrorToasterMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorToasterMessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorToasterMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
