import { Component, OnInit, Input } from '@angular/core';

import { ToastrService } from 'ngx-toastr';
import { debug } from 'util';
import { Config } from '../../../config/constant';


@Component({
  selector: 'error-toaster-messages',
  templateUrl: './error-toaster-messages.component.html',
  styleUrls: ['./error-toaster-messages.component.scss']
})
export class ErrorToasterMessagesComponent implements OnInit {

  @Input() ErrorMessageCode : string;
  @Input() ErrorMessageBody: string;
  @Input() ToastType: string;

  constructor(private toastr: ToastrService, private conf: Config) { }

  ngOnInit() {
    this.getErrorMessage(this.ErrorMessageCode, this.ErrorMessageBody)    
  }

  getErrorMessage(errorCode: any, errorBody: any) {
    setTimeout(() => this.showError(errorBody))
  }
  
  //showError1(errorBody) {
  //  this.toastr.error(errorBody, 'Error', {
  //    timeOut: 3000
  //  });
  //}

  showError(errorBody) {
    if (this.ToastType == this.conf.responseTypes.success) {
      this.toastr.success(errorBody, this.conf.responseTypes.success, {
        timeOut: 3000
      });
    } else if (this.ToastType == this.conf.responseTypes.error) {
      this.toastr.error(errorBody, this.conf.responseTypes.error, {
        timeOut: 3000
      });
    } else if (this.ToastType == this.conf.responseTypes.warning) {
      this.toastr.warning(errorBody, this.conf.responseTypes.warning, {
        timeOut: 3000
      });
    }
  }



}
