import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'popup-error-message',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent implements OnInit {

  @Input() ErrorMessageCode : string;
  @Input() ErrorMessageBody : string;

  customMsg: any;

  constructor() { }

  ngOnInit() {
    document.getElementById("openModalButton").click();

    this.getErrorMessage(this.ErrorMessageCode, this.ErrorMessageBody)
  }

  getErrorMessage(errorCode: any, errorBody: any) {
      if(errorCode == "400")
      {
        this.customMsg = errorBody
      }
    }

  //getErrorCode
}
