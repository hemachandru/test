import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ReactiveFormsModule } from '@angular/forms';

import { ControlErrorMessageComponent } from './shared-component/control-error-message/control-error-message.component';
import { TestComponent } from './shared-component/test/test.component';

import { NgxSpinnerModule } from 'ngx-spinner';
import { ModalModule } from './shared-modal';
import { SideMenuComponent } from './shared-component/side-menu/side-menu.component';
import { ErrorToasterMessagesComponent } from './shared-component/error-toaster-messages/error-toaster-messages.component';

@NgModule({
  declarations: [
    ControlErrorMessageComponent,
    TestComponent,
    SideMenuComponent,
    ErrorToasterMessagesComponent
  ],
  imports: [
    CommonModule,
    ModalModule,
    NgxSpinnerModule
  ],
  exports: [
    ControlErrorMessageComponent,
    ReactiveFormsModule,
    RouterModule,
    TestComponent,
    SideMenuComponent,
    NgxSpinnerModule,
    ErrorToasterMessagesComponent
  ]
})
export class SharedModule { }
