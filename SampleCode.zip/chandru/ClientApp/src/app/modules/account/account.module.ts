import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';

import { Config } from '../../config/constant'

import { AccountRoutingModule } from './account-routing.module';
import { LoginComponent } from './components/login/login.component';

export const COMPONENTS = [
  LoginComponent
];

@NgModule({
  declarations: COMPONENTS,
  imports: [
    CommonModule,
    HttpModule,
    AccountRoutingModule,
    SharedModule,
    FormsModule,
  ],
  providers: [Config]
})
export class AccountModule { }
