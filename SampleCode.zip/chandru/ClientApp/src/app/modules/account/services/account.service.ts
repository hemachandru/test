import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
//import http method 

import { HttpRequestService } from '../../../shared/http-service/http-request.service';

@Injectable()
export class AccountService {
  constructor(private httpRequest: HttpRequestService) {}

  loginService(data: any, url: string) {
    // debugger
    // return this.httpRequest.getHttpRequest(url);
    return this.httpRequest.postHttpRequestWithoutToken(data,url)
  }

}
