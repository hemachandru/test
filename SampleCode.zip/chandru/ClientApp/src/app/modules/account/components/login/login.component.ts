import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { Config } from '../../../../config/constant';

import {AccountBusiness} from '../../business/account.business'
import { AccountService } from '../../services/account.service';
import { HttpRequestService } from '../../../../shared/http-service/http-request.service';

import { NgxSpinnerService } from 'ngx-spinner';

// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [AccountBusiness, AccountService, HttpRequestService]
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  formSubmit = false;
  private errorMessage : any;

  msg_code;
  controlEmail;
  controlPassword;

  popupErrorMessageStatus: boolean = false;
  toastErrorMessageStatus: boolean = false;
  toastType: any;

  messagecode: any;
  messagebody: any;

  private user: any = {
    username: "",
    password: "",
    grant_type: ""
    //grant_type: password
  };

  constructor(
    private config: Config, 
    private fb: FormBuilder, 
    private accountBusiness: AccountBusiness,
    private spinner: NgxSpinnerService,
    private router: Router,
    // private toastr: ToastrService
    ) { }

    // showSuccess() {
    //   this.toastr.success('Hello world!', 'Toastr fun!');
    // }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    const email = '';
    const password = '';
    
    this.loginForm = this.fb.group({
      
      email: ['', 
        Validators.compose(
          [
            Validators.required,
           // Validators.pattern(this.config.emailPattern)
          ]
        )
      ],
      password: ['', Validators.compose([
        Validators.required
      ]
      )]

    }
    );
  }

  

  onSubmit() {
    this.popupErrorMessageStatus = false;
    this.toastErrorMessageStatus = false

    const values = this.loginForm.value;
    this.formSubmit = true;
    // console.log('values  --  : ',values);
    //debugger
    this.user.grant_type = "password";
    this.user.username = values.email;
    this.user.password = values.password;
    
    //console.log(this.user)
 //debugger
    if (this.loginForm.valid) {
      this.spinner.show();
      this.accountBusiness.accountLogin(this.user).subscribe(res => {
        console.log("success --> : ", res.access_token, res.token_type);
        this.spinner.hide();
        if (res.access_token) {
          localStorage.setItem('token', res.access_token)
          this.router.navigate(['/dashboard/dashboard']);
        }       
        
      }, (err) => {
        this.spinner.hide();
        //console.log("error:-->", err, '---- error_description', err.error_description);
        debugger
        this.messagebody = err.error_description;
        this.messagecode = "400";
        this.toastErrorMessageStatus = true
        this.popupErrorMessageStatus = false;
        this.toastType = "Error"
        //if (err.error_description == "The user name or password is incorrect."){
        //  this.popupErrorMessageStatus = true;
        //  this.toastErrorMessageStatus = false
        //} else {
        //  this.toastErrorMessageStatus = true
        //  this.popupErrorMessageStatus = false;
        //  this.toastType = "Error"
        //}
         //system  admin aaaa
      });
      
    } else {
      this.spinner.hide();
    }
  }



}
