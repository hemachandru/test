import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { VesselListComponent } from './components/vessel-list/vessel-list.component';
import { CreateVesselComponent } from './components/create-vessel/create-vessel.component'

const routes: Routes = [
  {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
  {
    path: 'dashboard', 
    component: DashboardComponent,
    data: {
      title: 'Dashboard'
    }
  },
  {path: 'list', component: VesselListComponent},
  {path: 'create', component: CreateVesselComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
