import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Config } from '../../../config/constant';
import { DashboadService } from '../services/dashboad.service';

@Injectable()
export class DashboadBusiness{
    constructor(
      private config: Config, 
      private router: Router, 
      private dashboadService: DashboadService
    ) {}
    
    saveVesselData(data) {
      // debugger
      let apiUrl = this.config.login
      return this.dashboadService.saveVesselService(data, apiUrl).map((result => result));
    }
    vesselList() {
      // debugger
      let apiUrl = this.config.list
      return this.dashboadService.listService(apiUrl).map((result => result));
    }
}