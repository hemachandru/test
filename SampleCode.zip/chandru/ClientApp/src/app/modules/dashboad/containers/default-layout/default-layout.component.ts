import { Component, OnDestroy, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';

import { navItems } from '../../model/dashboad'

import { DataService } from "../../services/data.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss'],
  providers: [DataService]
})
export class DefaultLayoutComponent implements OnDestroy {
  public navItems = navItems;
  public sidebarMinimized = true;
  private changes: MutationObserver;
  public element: HTMLElement;

  constructor(private dataService: DataService, private router: Router, @Inject(DOCUMENT) _document?: any) {

    this.changes = new MutationObserver((mutations) => {
      this.sidebarMinimized = _document.body.classList.contains('sidebar-minimized');
    });
    this.element = _document.body;
    this.changes.observe(<Element>this.element, {
      attributes: true,
      attributeFilter: ['class']
    });
    
  }

  ngOnDestroy(): void {
    this.changes.disconnect();
  }

  attributeData:any [];

  getNode(navItems) {
    // alert('hai')
    // console.log(navItems.target.outerText)
    // console.log(navItems.target.attributes.save)
    // console.log(navItems.target.attributes.edit)
    // console.log(navItems.target.attributes.delete.nodeValue)
    this.attributeData = [{
      save : navItems.target.attributes.save.nodeValue,
      edit : navItems.target.attributes.edit.nodeValue,
      delete : navItems.target.attributes.delete.nodeValue
    }]
    var id = "123"
    this.dataService.setData(id);
    // localStorage.setItem("toolBarAttributes", JSON.stringify(this.attributeData));
  }

  clickMe(){
    localStorage.clear()
    this.router.navigate(["/login"]);
  }
}
