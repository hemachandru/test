
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class DataService {

  private data:any = undefined;
   
      setData(data:any){
         // debugger
         console.log('Apple setting',data)
         this.data = data;
      }
      getData():any{
         // debugger
         console.log('Apple getting',this.data)
         return this.data;
      }

}