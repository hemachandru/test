import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';

import {DashboadBusiness} from '../../business/dashboad.business'
import { DashboadService } from '../../services/dashboad.service';
import { HttpRequestService } from '../../../../shared/http-service/http-request.service';

import { navItems} from '../../model/dashboad';
import { TableList } from '../../model/sampleData';

import { Router } from '@angular/router';

import { from } from 'rxjs';
@Component({
  selector: 'app-vessel-list',
  templateUrl: './vessel-list.component.html',
  styleUrls: ['./vessel-list.component.scss'],
  providers: [DashboadBusiness, DashboadService, HttpRequestService]
})
export class VesselListComponent implements OnInit {

  public vesselList : any;
  public navItems = navItems;
  public sampleList = TableList;
  
  menuSavePermission: boolean = false;
  menuEditPermission: boolean = false;
  menuDeletePermission: boolean = false;

  constructor(private dashboadBusiness: DashboadBusiness,private spinner: NgxSpinnerService,  private router: Router) { }

  ngOnInit() {

    for(let i = 0; i<= this.navItems.length; i++){
      console.log('ssssssssssssssssssss',this.navItems[i])
      //if(this.navItems[i].attributes){
        this.menuSavePermission = this.navItems[0].attributes.save;
        this.menuEditPermission = this.navItems[0].attributes.edit;
        this.menuDeletePermission = this.navItems[0].attributes.delete;
      //}
    }

    this.spinner.show();
      this.dashboadBusiness.vesselList().subscribe(res => {
        console.log("success --> : ", res);
        this.vesselList = res.data
        this.spinner.hide();
      }, (err) => {
          console.log("error" + err);
      });
  }

  //-------------- /create
  addVessel() {
    this.router.navigate(['/dashboard/create']);
  }

  refreshList() {
    // this.router.navigate(['/dashboard/list']);
    this.router.navigateByUrl('/dashboard/list', {skipLocationChange: true}).then(()=>
    this.router.navigate(["dashboard/list"])); 
  }
}
