import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { DataService } from "../../services/data.service";

@Component({
  templateUrl: 'dashboard.component.html',
  providers: [DataService]
})
export class DashboardComponent implements OnInit {

  mydata: any;
  constructor(private dataService: DataService){
  }
  ngOnInit() {
    if(this.mydata == undefined)
    {
      this.mydata = this.dataService.getData();
      console.log('Apple --> ',this.mydata)
    }
  }
}
