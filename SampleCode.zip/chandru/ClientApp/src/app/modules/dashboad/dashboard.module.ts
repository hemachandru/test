import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import { FormsModule } from '@angular/forms';


import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { VesselListComponent } from './components/vessel-list/vessel-list.component';

import { SharedModule } from '../../shared/shared.module';
import { Config } from '../../config/constant';
import { CreateVesselComponent } from './components/create-vessel/create-vessel.component'

import { SelectDropDownModule } from 'ngx-select-dropdown';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    HttpModule,
    DashboardRoutingModule,
    SharedModule,
    SelectDropDownModule
  ],
  declarations: [ DashboardComponent, VesselListComponent, CreateVesselComponent ],
  providers: [Config]
})
export class DashboardModule { }
