import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Config } from '../config/constant';

@Injectable()
export class HttpRequestService {
    private headers: Headers;
    constructor(private config: Config, private http: Http) {
        this.headers = new Headers();
    }

   /**
     * POST Http Request without Token 
     * Common service to handle PUT Http Request
     * 
     * @param {string} url - POST request with end point URL.
     * @param {string} data - POST request with data.
     * 
     * @return {Observable}
     */

    postHttpRequestWithoutToken(data: string, url: string) {
        var self = this;
        self.headers.set('Content-Type', 'application/json');
        self.headers.set('Accept', 'application/json');
        return self.http.post(url , data, {
            headers: self.headers
        })
            .map(self.successResponse)
            .catch(self.errorResponse)
            // .finally(() => {
            //     this.onFinally();
            // });
    }



    //************** HERE We do the default(Must Reusable) callback methods  **************

     /**
     * successResponse 
     * Common method to handle success response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private successResponse(result: Response) {
        return result.json() || null;
    }

    /**
     * errorResponse 
     * Common method to handle error response
     * 
     * @param {Response} error
     * 
     * @return {Observable}
     */
    private errorResponse(error: Response) {
        return Observable.throw(error.json() || null);
    }

    /**
     * onFinally
     */
    private onFinally(): void {
        console.log('Loading....')
    }

}