export class Config {
    travlogixBaseURL = "http://sit.infodynamic.net/travlogix/";
    travelb2bBaseURL = "http://sit.infodynamic.net/travelb2b/rest/api/all/";

    travlogixLogin = "loginAccess";
    travelb2bLogin = "authenticate";


    getBaseURLtravlogix() {
        return this.travlogixBaseURL;
    }
    getBaseURLtravelb2b() {
        return this.travelb2bBaseURL;
    }

}