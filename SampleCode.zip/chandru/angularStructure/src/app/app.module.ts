import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NotfoundComponent } from './component/notfound/notfound.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// import { AuthGuardService } from './auth/auth-guard.service';
// import { AuthService } from './auth/auth.service';

@NgModule({
  declarations: [
    AppComponent,
    NotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  bootstrap: [AppComponent],
  // providers: [AuthGuardService, AuthService]
})
export class AppModule { }
