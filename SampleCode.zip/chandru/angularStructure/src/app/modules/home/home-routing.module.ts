import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//import components
import { LandingpageComponent } from './component/landingpage/landingpage.component';

const routes: Routes = [

  {
    path: '',
    component:LandingpageComponent , 
    children:[ 
      {path:"", redirectTo:"home",pathMatch: 'full'},
      {path:"home", component:LandingpageComponent}
    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
