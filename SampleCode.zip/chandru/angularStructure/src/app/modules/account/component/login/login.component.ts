import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';

import { AccountBusiness } from '../../business/account.business'
import { AccountService } from '../../service/account-service';
import { HttpRequestService } from '../../../../service/http-request.service';

import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

//data send via services
import { DataService} from '../../../../shared/shared-service/data.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [AccountBusiness, AccountService, HttpRequestService] 
})
export class LoginComponent implements OnInit {
  @Output() loginState = new EventEmitter();
  message:string;

  data:any = {text: "example"};

  constructor(
    private router: Router, 
    private loginBusiness: AccountBusiness, 
    private formBuilder: FormBuilder,
    private dataService: DataService
    ) {}

  ngOnInit() {
      this.profileForm = this.formBuilder.group({
        userName: ['', [Validators.required]],
        password: ['', [Validators.required]]
    });
  }

  profileForm = new FormGroup({
    userName: new FormControl(''),
    password: new FormControl(''),
  });
  

  layoutStatus = 'login';
  login;
  onSignup() {
    this.login = 'signup';
    this.loginState.emit(this.login);    
    // this.router.navigate(['account/signup']);
    // window.location.href = 'https://www.google.com/';
  }
  public menuList = [];
  public submenuList = [];
  onSubmit() {
    this.loginBusiness.travlogixLogin(JSON.stringify(this.profileForm.value)).subscribe(res => {
      if(res.messageCode == "Success")
      {
        this.dataService.setData(res);
        // for(let i=0; i< res.data.ObjMenu.length; i++){
        //   if(res.data.ObjMenu[i].ParentKey == "-1" || res.data.ObjMenu[i].ParentKey == "54"){
        //     this.menuList.push(res.data.ObjMenu[i]);
        //   }
        // }  
        // console.log(this.menuList.length)
        this.router.navigate(['home/home']);  // ParentKey: -1
      }else{
        var data =  this.profileForm.value;
        this.onSubmittravelb2b(data);
      }
    }, (err) => {
        console.log("login travlogix error" + err);
    });
  }

  onSubmittravelb2b(data: any) {
    var userData = [data.userName, data.password]
    this.loginBusiness.travelB2BLogin(JSON.stringify(userData)).subscribe(res => {
      this.router.navigate(['home/home']);
    }, (err) => {
        console.log("login travelb2b error" + err);
    });

  }

}
