import { Component, OnInit, ViewChild, AfterViewInit  } from '@angular/core';
import { LoginComponent } from '../login/login.component'
import { SignupComponent } from '../signup/signup.component'
import { from } from 'rxjs';
@Component({
  selector: 'app-account-layout',
  templateUrl: './account-layout.component.html',
  styleUrls: ['./account-layout.component.scss']
})
export class AccountLayoutComponent implements AfterViewInit  {

  constructor() { }
  @ViewChild(LoginComponent) loginChild;
  // @ViewChild(SignupComponent) signupChild

  // ngOnInit() {
  // }
  layoutStatus:string;
  loginSt: string;
  signupSt: string;
  ngAfterViewInit() {

    // this.layoutStatus = this.loginChild.layoutStatus
    // this.layoutStatus = this.loginChild.signupChild
    // console.log('this.loginChild', this.loginChild , 'this.signupChild', this.signupChild)
  }
  ngOnInit(){
    this.layoutStatus = this.loginChild.layoutStatus;
    // this.loginSt = this.loginChild.layoutStatus
    // this.signupSt = this.signupChild.layoutStatus
    // if (this.loginSt){
    //   this.layoutStatus = this.loginChild.layoutStatus;
    //   // alert('-------Login init---: '+this.layoutStatus)
    // }else{
    //   this.layoutStatus = this.signupChild.layoutStatus;
    //   // alert('-------Signup init---: '+this.layoutStatus)
    // }

  }

  //displayState
  displayState(state) {
    this.layoutStatus = state;
    // alert(this.layoutStatus)
  }
}
