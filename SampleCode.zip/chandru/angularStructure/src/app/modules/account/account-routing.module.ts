import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// import { LoginComponent } from './component/login/login.component';
// import { SignupComponent } from './component/signup/signup.component';
import { AccountLayoutComponent } from './component/account-layout/account-layout.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {path:"", redirectTo:"layout",pathMatch: 'full'},
      {path:"layout", component:AccountLayoutComponent}
      // {path:"login", component:LoginComponent},
      // {path:"signup", component:SignupComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
