export class Config {
    baseURL = "http://sit.infodynamic.net/";

    ediSingleUser = "http://sit.infodynamic.net/ediservice/rest/jsonData/"
    ediUserList = "http://sit.infodynamic.net/ediservice/rest/jsonData/profile/user"
    demo = "https://jsonplaceholder.typicode.com/users"
    saveJson = "http://sit.infodynamic.net/ediservice/rest/marshal?jsonName="

    getBaseURL() {
        return this.baseURL;
    }

}