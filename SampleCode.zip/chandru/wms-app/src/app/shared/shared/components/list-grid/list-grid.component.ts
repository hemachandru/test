import { Component, OnInit, ViewChild, AfterViewInit, EventEmitter ,Output, Input } from '@angular/core';

import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';

//data send via services
import { DataService} from '../../service/data-service/data.service'

import { SharedBusiness } from "../../business/sharedBusiness"
import { SharedService } from '../../service/shared.service';

import { DragMultiTreeGridComponent } from '../drag-multi-tree-grid/drag-multi-tree-grid.component';

@Component({
  selector: 'app-list-grid',
  templateUrl: './list-grid.component.html',
  styleUrls: ['./list-grid.component.scss'],
  providers: [DataService, SharedBusiness, SharedService]
})
export class ListGridComponent implements OnInit {

  @ViewChild(DragMultiTreeGridComponent) child;

  @Input() treeData: string;

  addState: boolean = true;
  viewState: boolean = true;

  public displayedColumns = ['delimeterName', 'details', 'update', 'delete'];

  public dataSource = [
    {
      "id": 10,
      "delimeterName": "FIXED_LENGTH_MANIFEST"
    },
    {
      "id": 4,
      "delimeterName": "AMEX_INVOICE"
    },
    {
      "id": 5,
      "delimeterName": "AMEX_INVOICE_CHARGES"
    },
    {
      "id": 2,
      "delimeterName": "FIXED_LENGTH_DEMO"
    }
  ]

  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @Output() messageEvent = new EventEmitter<boolean>();
  @Output() addElementEvent = new EventEmitter<boolean>();
  
  @Output() onFilter = new EventEmitter();

  constructor(private dataService: DataService, private shareBusiness: SharedBusiness) { }

  stateChk:boolean = false;

  ngOnInit() {
    this.shareBusiness.descriptorUserListBusiness().subscribe(res => {
      console.log("apple boy--> : ", res);
    }, (err) => {
        console.log("error" + err);
    });
  }


  ngAfterViewInit(): void {
    // this.dataSource.sort = this.sort;
    // this.dataSource.paginator = this.paginator;
  }
  public doFilter = (value: string) => {
    console.log(value)
    // this.dataSource.filter = value.trim().toLocaleLowerCase();
  }
editId
  public redirectToDetails = (id: string) => {
    // console.log(id);
    this.editId = id
  }

  descriptorData: any;

  public redirectToUpdate = (id: string) => {
    this.descriptorData = id;
    this.dataService.filter(id);

    this.stateChk = true
    this.addElementEvent.emit(true)
    
    // this.editId = id
    // this.messageEvent.emit(id)
    // this.dataService.setData(id);
  }

  public redirectToDelete = (id: string) => {
    // console.log(id);
    this.editId = id
  }

  addElement(){
    this.stateChk = true
    this.addElementEvent.emit(true)
  }

  message:string;
  saveStructure(){
    // let myVal = localStorage.getItem('mydataSet')
    let data;
    this.shareBusiness.saveJsonBusiness(data).subscribe(res => {
      console.log("apple boy--> : ", res);
    }, (err) => {
        console.log("error" + err);
    });

    //saveStructure
  }
}
