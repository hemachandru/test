import { Component, Injectable } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { of as ofObservable, Observable, BehaviorSubject } from 'rxjs';

import { DataService} from '../../service/data-service/data.service'

import { SharedBusiness } from "../../business/sharedBusiness"
import { SharedService } from '../../service/shared.service';

import * as _ from 'lodash'


export class TodoxmltagNode {
    segmentList: TodoxmltagNode[];
    xmltag: string;
    index: string;
    segcode: string;
    id: number;
    expanded: boolean;
    minOccurs: string;
    maxOccurs: string;
    fieldList: ToDoFieldList[];
    propertyName: string;
    displaySegmentListAsSingleLine: boolean;
}

export class ToDoFieldList {
    xmltag : string;
    from : number;
    to : number;
    length : number;
    propertyName : string;
    arguments: string;
    dataType : string;
    dataFormat : string;
    defaultValue : string;
    leftPaddingSize : number;
    leftPaddingChar : string;
    rightPaddingSize : number;
    rightPaddingChar : string;
    mandatory : boolean;
}

export class TodoxmltagFlatNode {
    xmltag: string;
    level: number;
    expandable: boolean;
    
    index: string;
    segcode: string;
    id: number;
    expanded: boolean;
    minOccurs: string;
    maxOccurs: string;
    fieldList: [];
    propertyName: string;
    displaySegmentListAsSingleLine: boolean;
}

export interface Test {
    id: string;
  }

export interface MyJsonTest {
    id: string;
    propertyName: string;
    properties: MyJsonTest []
}



let TREE_DATA = {};

@Injectable()
export class ChecklistDatabase {
  dataChange: BehaviorSubject<TodoxmltagNode[]> = new BehaviorSubject<TodoxmltagNode[]>([]);

  get data(): TodoxmltagNode[] { return this.dataChange.value; }

  dataService: DataService

  constructor(dataService: DataService) {
    this.initialize();
  }

//   segments --->  segmentList
  initialize() {
    const data = this.buildFileTree(TREE_DATA, 0);
    this.dataChange.next(data);
  }

  buildFileTree(value: any, level: number) {
    //   console.log('value :' ,value)
    let data: any[] = [];
    for (let k in value) {
      let v = value[k];
      let node = new TodoxmltagNode();
      let fieldlistNode = new ToDoFieldList()
        node.xmltag = value[k].xmltag;    
        node.index = value[k].index;
        node.segcode = value[k].segcode;
        node.id = value[k].id;
        node.expanded = value[k].expanded;
        node.minOccurs = value[k].minOccurs;
        node.maxOccurs = value[k].maxOccurs;
        node.fieldList = value[k].fieldList;
        node. propertyName = value[k].propertyName;
        node.displaySegmentListAsSingleLine = value[k].displaySegmentListAsSingleLine;

      if (v === null || v === undefined) {
      } else if (typeof v === 'object') {
        node.segmentList = this.buildFileTree(v.segmentList, level + 1);
        // node.fieldList = this.buildFileTree(v.fieldList, level + 1)
      } else {
        node.xmltag = v;
      }
      data.push(node);
    }
    return data;
  }

  insertxmltag(parent: TodoxmltagNode, name: string) {
    const child = <TodoxmltagNode>{ xmltag: name };
    if (parent.segmentList) {
      parent.segmentList.push(child);
      this.dataChange.next(this.data);
    }
    else { 
      parent.segmentList = [];
      parent.segmentList.push(child);
      this.dataChange.next(this.data);
    }
  }

  updatexmltag(node: TodoxmltagNode, name: string) {
    //   debugger
      let testData :any = node;
    if( testData !== "save"){
        node.xmltag = name;
        node.index = "121"
        node.segcode = "HDR1";
        node.id = 2;
        node.expanded = true;
        node.minOccurs = "0";
        node.maxOccurs = "-1";
        node.fieldList = [];
        node. propertyName = "TIdTvlHandoffInvoiceHeaderEntity";
        node. segmentList = [];
        node.displaySegmentListAsSingleLine = false;

        this.dataChange.next(this.data);
        console.log('Updated Data',this.data)
    }else{
        console.log('Updated Save Data',this.data)
    }
  }
}

export interface Food {
    dataKey: string;
    datavalue: string;
  }


@Component({
    selector: 'app-drag-multi-tree-grid',
    templateUrl: './drag-multi-tree-grid.component.html',
    styleUrls: ['./drag-multi-tree-grid.component.scss'],
    providers: [ChecklistDatabase, DataService, SharedBusiness, SharedService]
})

export class DragMultiTreeGridComponent {
    flatNodeMap: Map<TodoxmltagFlatNode, TodoxmltagNode> = new Map<TodoxmltagFlatNode, TodoxmltagNode>();
    nestedNodeMap: Map<TodoxmltagNode, TodoxmltagFlatNode> = new Map<TodoxmltagNode, TodoxmltagFlatNode>();

    selectedParent: TodoxmltagFlatNode | null = null;
    newxmltagName: string = '';
    treeControl: FlatTreeControl<TodoxmltagFlatNode>;
  treeFlattener: MatTreeFlattener<TodoxmltagNode, TodoxmltagFlatNode>;
  dataSource: MatTreeFlatDataSource<TodoxmltagNode, TodoxmltagFlatNode>;
  checklistSelection = new SelectionModel<TodoxmltagFlatNode>(true /* multiple */);

  fieldList : any;
  tableShow: boolean = false

  foods: Food[] = [];

  fieldName : any ;
  fromName : any;
  toName: any;
//   datavalues: any;
  defaultValue: any;
  leftPadding:any;
  rightPadding: any;


  btnAdd : boolean = true;
  btnUpdate : boolean = false;

  //form controls values
  public fileType: string;
  public delimiter1: string;
  public delimiter2: string;
  public delimiter3: string;
  public mappingmodel: string;
  public segmentFieldChk : boolean;
  public parentSegmentSwapingChk: boolean;

  public filetypeValidation: boolean = false;
  public delimiterValidation: boolean = false;
  public mapingmodelValidation: boolean = false;
  public segmentFieldValidation: boolean = false;
  public parentSegmentSwapingValidation: boolean = false;

  public btnAddchkStatus: boolean = true;

  constructor(private getDat: ChecklistDatabase, private database: ChecklistDatabase, private shareDataLayer: DataService, private shareBusiness: SharedBusiness) {

    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel,
      this.isExpandable, this.getsegmentList);
    this.treeControl = new FlatTreeControl<TodoxmltagFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

    database.dataChange.subscribe(data => {
      this.dataSource.data = data;
    });

    //form controls values
    this.delimiter1 = "";
    this.delimiter2 = "";
    this.delimiter3 = "";
    this.mappingmodel = "";
    this.fileType = "";
    // this.segmentFieldChk = "";
    // this.parentSegmentSwapingChk = "";

  }

  message = 'value getting';

  dummy: Test[] = [
    {id: 'TIdTvlHandoffGenHeaderEntity'},
    {id: 'TIdTvlHandoffTicketDetailsEntity'},
    {id: 'TIdTvlHandoffSectorDetailsEntity'}
  ];

  myJsonCheck: MyJsonTest[] = [
    {
        id: "1",
        propertyName: "asdf",
        properties: [
            {
                id: "1.1",
                propertyName: "wert",
                properties: [
                    {
                        id: "1.1.1",
                        propertyName: "zsdff",
                        properties: []
                    }
                ]
            }
        ]
      },
      {
        id: "2",
        propertyName: "qwerty",
        properties: [
            {
                id : "2.1",
                propertyName : "poiu",
                properties : [
                    {
                        id: "2.1.1",
                        propertyName: "pmnfdhf",
                        properties: []
                    }
                ]
            }
        ]
      }
    ]

   
    myList = [
        {
            "People": [
                {
                    "id": "12",
                    "parentId": "0",
                    "text": "Man",
                    "level": "1",
                    "children": [
                        {
                            "id": "6",
                            "parentId": "12",
                            "text": "Boy",
                            "level": "2",
                            "children": null
                        },
                        {
                            "id": "7",
                            "parentId": "12",
                            "text": "Other",
                            "level": "2",
                            "children": null
                        }   
                    ]
                },
                {
                    "id": "9",
                    "parentId": "0",
                    "text": "Woman",
                    "level": "1",
                    "children":
                    {
        
                        "id": "11",
                        "parentId": "9",
                        "text": "Girl",
                        "level": "2",
                        "children": null
                    }
                }
        
            ],    
        
            "Animals": [
                {
                    "id": "5",
                    "parentId": "0",
                    "text": "Dog",
                    "level": "1",
                    "children": 
                        {
                            "id": "8",
                            "parentId": "5",
                            "text": "Puppy",
                            "level": "2",
                            "children": null
                        }
                },
                {
                    "id": "10",
                    "parentId": "13",
                    "text": "Cat",
                    "level": "1",
                    "children": 
                    {
                        "id": "14",
                        "parentId": "13",
                        "text": "Kitten",
                        "level": "2",
                        "children": null
                    }
                }
        
            ]
        }
    ]


myFinaDrp = [];
  ngOnInit() {
    this.fieldName = ""
    this.fromName = ""
    this.toName = ""
    // this.datavalues = ""
    this.defaultValue = ""
    this.leftPadding = ""
    this.rightPadding = ""
    // this.btnAdd ="ADD"

    // console.log('this.length : ', this.myJsonCheck.length)
    // for(let i=0 ; i<=this.myJsonCheck.length ; i++){
        // this.myFinaDrp.push(this.myJsonCheck[i].propertyName);
        // this.myJsonCheck[0].propertyName = "apple"
        // console.log('asdfasdfad: ', this.myJsonCheck[i].propertyName);
    // }
    // let mapped = this.myJsonCheck.map(({ propertyName }) => propertyName);
    // let mapped = this.myJsonCheck.map(({ properties }) => 
    //     properties.map(({propertyName}) => ({propertyName}))
    // );
    // console.log('asdfasdfad : ', mapped);

    // this.list_to_tree(this.myJsonCheck);
    this.list_to_tree(this.myList);
  }


  list_to_tree(list) {
    var map = {}, node, roots = [], i;
    for (i = 0; i < list.length; i += 1) {
        map[list[i].id] = i; // initialize the map
        list[i].children = []; // initialize the children
    }
    for (i = 0; i < list.length; i += 1) {
        node = list[i];
        if (node.parentId !== "0") {
            // if you have dangling branches check that map[node.parentId] exists
            list[map[node.parentId]].children.push(node);
        } else {
            roots.push(node);
        }
    }
    console.log(map);
    return roots;
}

  getLevel = (node: any) => { return node.level; };
  isExpandable = (node: any) => { return node.expandable; };

  getsegmentList = (node: any): Observable<any[]> => {
    return ofObservable(node.segmentList);
  }

  hasChild = (_: number, _nodeData: any) => { return _nodeData.expandable; };

  hasNoContent = (_: number, _nodeData: any) => { return _nodeData.xmltag === ''; };

  transformer = (node: any, level: number) => {
    let flatNode = this.nestedNodeMap.has(node) && this.nestedNodeMap.get(node)!.xmltag === node.xmltag
      ? this.nestedNodeMap.get(node)!
      : new TodoxmltagFlatNode();
    flatNode.xmltag = node.xmltag;
    flatNode.level = level;
    flatNode.expandable = !!node.segmentList;
    flatNode.fieldList = node.fieldList;
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  }

  descendantsAllSelected(node: any): boolean {
    const descendants = this.treeControl.getDescendants(node);
    return descendants.every(child => this.checklistSelection.isSelected(child));
  }

  descendantsPartiallySelected(node: any): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));
    return result && !this.descendantsAllSelected(node);
  }

  todoxmltagSelectionToggle(node: TodoxmltagFlatNode): void {
    this.checklistSelection.toggle(node);
    const descendants = this.treeControl.getDescendants(node);
    this.checklistSelection.isSelected(node)
      ? this.checklistSelection.select(...descendants)
      : this.checklistSelection.deselect(...descendants);
  }

  addNewxmltag(node: TodoxmltagFlatNode) {
    const parentNode = this.flatNodeMap.get(node);
    let isParentHassegmentList: boolean = false;
    if (parentNode.segmentList)
      isParentHassegmentList = true;
    this.database.insertxmltag(parentNode!, '');
    if (isParentHassegmentList)
      this.treeControl.expand(node);
  }

  deleteState(node) {
    const parentNode = this.flatNodeMap.get(node);
      console.log('Delete Node State : ',parentNode);
  }
 
//   parentNodeMap = new Map<TreeNode, TreeNode>();

//   deleteNode(node: TreeNode) {
//     const parentNode = this.parentNodeMap.get(node);
//     const index = parentNode.children.indexOf(node);
//     if (index !== -1) {
//       parentNode.children.splice(index, 1);
//       this.dataChange.next(this.data);
//       this.parentNodeMap.delete(node);
//     }
//   }

  
  //change text
 

  saveNode(node: any, xmltagValue: string) {
    const nestedNode = this.flatNodeMap.get(node);
    this.database.updatexmltag(nestedNode!, xmltagValue);
    console.log('Save node',nestedNode!)
  }

  passvalue (){

    //  // top all
    TREE_DATA_all[0].fixedLength = false
    TREE_DATA_all[0].jsonName = "AMEX_INVOICE_CHARGES_NEW_new"
    TREE_DATA_all[0].parentSwap = false
    TREE_DATA_all[0].segmentAsField = false

    // delimiters
    TREE_DATA_all[0].delimiters.segment = "";
    TREE_DATA_all[0].delimiters.field = ",";
    TREE_DATA_all[0].delimiters.component = "AMEX_INVOICE_CHARGES_NEW_new";
    TREE_DATA_all[0].delimiters.subcomponent = "~";

    // delimiters: {
    //     segment: " ", 
    //     field: ",", 
    //     component: "AMEX_INVOICE_CHARGES_NEW", 
    //     subcomponent: "~"
    // }

    // fixedLength 
    // jsonName  -- Mapping Model Name
    // parentSwap  -- Parent Segment Swaping
    // segmentAsField  -- Segment as field


    console.log('apple', TREE_DATA_all[0])
  }

  delimiterBool: boolean = true;
  addFieldList(node) {
    //   debugger
      console.log(node)
      this.shareDataLayer.setData(node);
    //   localStorage.setItem('selectedNode', node)
      var selRadio = sessionStorage.getItem('optionValue')
      if (selRadio == "delimiter"){
        this.delimiterBool = false;
      }else{
          this.delimiterBool = true;
      }

    this.tableShow = true
    console.log(node);
    this.fieldList = ""
    this.fieldList = node.fieldList
    console.log('fieldList', this.fieldList)

    this.foods = [
        {dataKey: '0', datavalue: 'TEXT'},
        {dataKey: '1', datavalue: 'DATE'},
        {dataKey: '2', datavalue: 'TIME'},
        {dataKey: '3', datavalue: 'NUMBER'},
        {dataKey: '4', datavalue: 'CUSTOM'}
      ];

  }

  fieldArray: Array<any> = [];
  newAttribute: any = {};
  addFieldValue() {
    if (this.fieldArray.length < 5) {
      this.fieldArray.push(this.newAttribute);
      this.newAttribute = {};
    } else {
      
    }
  }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  selectedIndex
  onSelect(selectedItem: any, index: any) {
    this.btnAddchkStatus = false
    console.log("Selected item Id nodes: ", index, '----' ,selectedItem);
    this.fieldName = selectedItem.xmltag;
    this.fromName = selectedItem.from; 
    this.toName = selectedItem.to;
    this.defaultValue = selectedItem.defaultValue;
    this.leftPadding = selectedItem.leftPaddingSize;
    this.rightPadding = selectedItem.rightPaddingSize;

    this.btnAdd = false;
    this.btnUpdate = true;
    this.selectedIndex = index
  }

  deletedValue: any;

  onDelete(selectedItem: any, position: any){
    //   debugger
    // alert("Are you want to delete the item : "+ selectedItem.xmltag);
    this.getNode = this.shareDataLayer.getData();
// debugger
// console.log('Initial field list Array : ', this.fieldList)
    let firstSetArray = this.fieldList
    let secondSetArray = firstSetArray.splice(position);
    let temporaryDeleteArray = secondSetArray.shift()
    let finalArray = firstSetArray.concat(secondSetArray);

    // console.log("1st Set Array : ", firstSetArray)
    // console.log("Second Set Array : ", secondSetArray)
    // console.log("Deleted Array : ", temporaryDeleteArray.xmltag)
    // console.log("original Array D : ", finalArray)
    this.deletedValue = temporaryDeleteArray.xmltag;
    this.fieldList = finalArray;
    // console.log('Final field list Array : : ',this.fieldList)
  }

  public getNode : any ;
  fieldUpdateChanges() {
    this.btnAdd = true;
    this.btnUpdate = false;
    this.getNode = this.shareDataLayer.getData();

    this.fieldList[this.selectedIndex].defaultValue = this.defaultValue
    this.fieldList[this.selectedIndex].from = this.fromName
    this.fieldList[this.selectedIndex].leftPaddingSize = this.leftPadding
    this.fieldList[this.selectedIndex].rightPaddingSize = this.rightPadding
    this.fieldList[this.selectedIndex].to = this.toName
    this.fieldList[this.selectedIndex].xmltag = this.fieldName

    console.log('field nodes : ', this.fieldList)
    //   addNewxmltag(node: TodoxmltagFlatNode) {
    //     const parentNode = this.flatNodeMap.get(node);
    //     // 
    //     let isParentHassegmentList: boolean = false;
    //     if (parentNode.segmentList)
    //       isParentHassegmentList = true;
    //     //
    //     this.database.insertxmltag(parentNode!, '');
    //     if (isParentHassegmentList)
    //       this.treeControl.expand(node);
    //   }
  }

  fieldAddChanges() {
    //   this.fieldList[this.selectedIndex].xmltag = "apple"
    this.getNode = this.shareDataLayer.getData();
    debugger
    if(this.defaultValue != "" && this.fromName != "" && this.leftPadding != "" && this.rightPadding != "" && this.toName != "" && this.fieldName != "") {
        this.btnAddchkStatus = false
        this.getNode.fieldList.push(
            {
                "dataFormat":'',
                "dataType":"TEXT",
                "defaultValue": this.defaultValue,
                "segcode":"root",
                "from": this.fromName,
                "leftPaddingChar": "",
                "leftPaddingSize": this.leftPadding,
                "length": "0",
                "mandatory": false,
                "propertyName": "",
                "rightPaddingChar": "",
                "rightPaddingSize": this.rightPadding,
                "to": this.toName,
                "xmltag": this.fieldName,
            }
        )
        this.fieldList = this.getNode.fieldList;
        console.log('field nodes : ', this.fieldList)
        this.fieldName = ""
        this.fromName = ""
        this.toName = ""
        this.defaultValue = ""
        this.leftPadding = ""
        this.rightPadding = ""
    }else {
        this.btnAddchkStatus = true
    }
    // btnAddchkStatus
      
  }

  saveStructure(){
    //chandru
    console.log('File Type values: ', this.fileType)
    // console.log('delimiter values : ', this.delimiter1, this.delimiter2, this.delimiter3)
    // console.log('mappingmodel values : ', this.mappingmodel)
    // console.log('Segment as field values : ', this.segmentFieldChk);
    // console.log('Parent Segment Swaping values : ', this.parentSegmentSwapingChk)
    
    
//   public filetypeValidation: boolean = false;
//   public delimiterValidation: boolean = false;
//   public mapingmodelValidation: boolean = false;
//   public segmentFieldValidation: boolean = false;
//   public parentSegmentSwapingValidation: boolean = false;

    //  // top all
    TREE_DATA_all[0].fixedLength = false;
    // TREE_DATA_all[0].jsonName = "AMEX_INVOICE_CHARGES_NEW_new"
    TREE_DATA_all[0].parentSwap = this.parentSegmentSwapingChk;
    TREE_DATA_all[0].segmentAsField = this.segmentFieldChk;

    // delimiters
    TREE_DATA_all[0].delimiters.segment = "";
    TREE_DATA_all[0].delimiters.field = this.delimiter1;
    TREE_DATA_all[0].delimiters.component = this.delimiter2;
    TREE_DATA_all[0].delimiters.subcomponent = this.delimiter3;

let name: any = "save";
let snode:any = "save";
    console.log('values: ', this.getDat.updatexmltag(name ,snode))

    // console.log('values: ', TREE_DATA_all[0].segments.segmentList[0].segmentList)
    
    // this.shareBusiness.saveJsonBusiness(TREE_DATA_all).subscribe(res => {
    //     console.log("apple boy--> : ", res);
    // }, (err) => {
    //     console.log("error" + err);
    // });

    // if(this.fileType != undefined && this.parentSegmentSwapingChk != undefined  && this.segmentFieldChk != undefined && this.delimiter1 != "") {
    //     console.log("correct")
    // }else {
    //     this.filetypeValidation = false;
    //     this.parentSegmentSwapingValidation = false;
    //     this.segmentFieldValidation = false;
    //     this.delimiterValidation = false;

    //     if(this.fileType == ""){
    //         this.filetypeValidation = true;
    //     }else if(this.parentSegmentSwapingChk == undefined) {
    //         this.parentSegmentSwapingValidation = true;
    //     }else if(this.segmentFieldChk == undefined){
    //         this.segmentFieldValidation = true;
    //     }else if(this.delimiter1 == ""){
    //         this.delimiterValidation = true;
    //     }
    // }

  }


  //form values
  fileInputchk: boolean = false
  setradio(value){
      if(value == "fixedLength"){
        this.fileType = "fixedlength"
        this.fileInputchk = true
      }else{
        this.fileInputchk = false
        this.fileType = "delimiter"
      }
      sessionStorage.setItem('optionValue', value)
  }

  segmentField(value){
      if(value == "yes"){
        this.segmentFieldChk = true;
      }else{
        this.segmentFieldChk = false;
      }
  }

  parentSegmentSwaping(value){
    if(value == "yes"){
        this.parentSegmentSwapingChk = true;
    }else{
        this.parentSegmentSwapingChk = false;
    }
}

uploadSchema() {

        // if ($('.flUpload').val() != '') {

            // var file = $('.flUpload')[0].files[0];
            // var fileName = file.name;
            // var fileExt = '.' + fileName.split('.').pop();
            //alert(fileExt);

        // }
        // else {
        //     alert('Please select a file.')
        // } //Extension end


        // //var filename = "name";
        // var filename = $("#txt_userid").val();
        // alert(filename);
        // var data = new FormData();
        // data.append("UploadedImage", $("#userimage").get(0).files[0]);

    //Upload end
}

}

const TREE_DATA_all = [
    {
        "field":",",
        "jsonName":"AMEX_INVOICE_CHARGES_NEW",
        "jsonId":5,
        "fixedLength":true,
        "segmentAsField":true,
        "parentSwap":false,
        "xmlns":"http://www.milyn.org/schema/edi-message-mapping-1.0.xsd",
        "segments":{
            "xmltag":"sample",
            "segmentList":[
                {
                    "index": 1,
                    "xmltag": "Volume Header",
                    "segcode": "VOL1",
                    "id": 1,
                    'expanded': true,
                    "minOccurs": "0",
                    "maxOccurs": "-1",
                    "fieldList": [
                        {
                            "xmltag": "Record type",
                            "from": 1,
                            "to": 4,
                            "length": 0,
                            "propertyName": "",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "",
                            "defaultValue": "VOL1",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": true
                        },
                        {
                            "xmltag": "Submission serial unique identifier",
                            "from": 5,
                            "to": 10,
                            "length": 0,
                            "propertyName": "handhSequence",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "",
                            "defaultValue": "",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": true
                        },
                        {
                            "xmltag": "Filler",
                            "from": 11,
                            "to": 11,
                            "length": 0,
                            "propertyName": "",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "",
                            "defaultValue": "",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": false
                        },
                        {
                            "xmltag": "Filler",
                            "from": 12,
                            "to": 41,
                            "length": 0,
                            "propertyName": "",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "",
                            "defaultValue": "",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": false
                        },
                        {
                            "xmltag": "Submission agent reference code",
                            "from": 42,
                            "to": 51,
                            "length": 0,
                            "propertyName": "handhAgentRef",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "upper_case",
                            "defaultValue": "",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": true
                        },
                        {
                            "xmltag": "Filler",
                            "from": 52,
                            "to": 200,
                            "length": 0,
                            "propertyName": "",
                            "arguments": [],
                            "dataType": "TEXT",
                            "dataFormat": "",
                            "defaultValue": "",
                            "leftPaddingSize": 0,
                            "leftPaddingChar": "",
                            "rightPaddingSize": 0,
                            "rightPaddingChar": "",
                            "mandatory": false
                        }
                    ],
                    "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                    "segmentList": [
                        {
                            "index": 1,
                            "xmltag": "First File Header",
                            "segcode": "HDR1",
                            "id": 2,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record type",
                                    "from": 1,
                                    "to": 4,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "HDR1",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Source identifier of originator",
                                    "from": 5,
                                    "to": 14,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "AMEX",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 15,
                                    "to": 21,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Submission serial unique identifier",
                                    "from": 22,
                                    "to": 27,
                                    "length": 0,
                                    "propertyName": "handhSequence",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File section number",
                                    "from": 28,
                                    "to": 31,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "1",
                                    "leftPaddingSize": 4,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File sequence number",
                                    "from": 32,
                                    "to": 35,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "1",
                                    "leftPaddingSize": 4,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 36,
                                    "to": 42,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File creation date(Julian Date Format)",
                                    "from": 43,
                                    "to": 47,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [
                                        "0"
                                    ],
                                    "dataType": "TEXT",
                                    "dataFormat": "JULIAN_DATE",
                                    "defaultValue": "CURRENT_DATE",
                                    "leftPaddingSize": 5,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 48,
                                    "to": 48,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File expiry date(Julian Date Format)",
                                    "from": 49,
                                    "to": 53,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [
                                        "30"
                                    ],
                                    "dataType": "TEXT",
                                    "dataFormat": "JULIAN_DATE",
                                    "defaultValue": "CURRENT_DATE",
                                    "leftPaddingSize": 5,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Block count",
                                    "from": 54,
                                    "to": 60,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 7,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "System code",
                                    "from": 61,
                                    "to": 73,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 13,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 74,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 2,
                            "xmltag": "Second File Header",
                            "segcode": "HDR2",
                            "id": 3,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record type",
                                    "from": 1,
                                    "to": 4,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "HDR2",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record format",
                                    "from": 5,
                                    "to": 5,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "F",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Block length",
                                    "from": 6,
                                    "to": 10,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "200",
                                    "leftPaddingSize": 5,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record length",
                                    "from": 11,
                                    "to": 15,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "200",
                                    "leftPaddingSize": 5,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Tape density",
                                    "from": 16,
                                    "to": 16,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "3",
                                    "leftPaddingSize": 1,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Data set Position",
                                    "from": 17,
                                    "to": 17,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 1,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 18,
                                    "to": 38,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Block attribute",
                                    "from": 39,
                                    "to": 39,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "B",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 40,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 3,
                            "xmltag": "Transaction File Header",
                            "segcode": "TFH",
                            "id": 4,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record Type",
                                    "from": 1,
                                    "to": 3,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "TFH",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record sequence number",
                                    "from": 4,
                                    "to": 9,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [
                                        "<#assign x = 1>"
                                    ],
                                    "dataType": "CUSTOM",
                                    "dataFormat": "EXPRESSION",
                                    "defaultValue": "x",
                                    "leftPaddingSize": 6,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File Creation Date",
                                    "from": 10,
                                    "to": 15,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "DATE",
                                    "dataFormat": "YYMMDD",
                                    "defaultValue": "CURRENT_DATE",
                                    "leftPaddingSize": 6,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File Creation Time",
                                    "from": 16,
                                    "to": 19,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "HHMM",
                                    "defaultValue": "CURRENT_TIME",
                                    "leftPaddingSize": 2,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 20,
                                    "to": 22,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "AEME reference code",
                                    "from": 23,
                                    "to": 25,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "AMX",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Travel Agent Name",
                                    "from": 26,
                                    "to": 40,
                                    "length": 0,
                                    "propertyName": "handhCompanyName",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 41,
                                    "to": 45,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Travel Agent Address",
                                    "from": 46,
                                    "to": 60,
                                    "length": 0,
                                    "propertyName": "handhCompanyAddress",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 61,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 4,
                            "xmltag": "Transaction Batch Header",
                            "segcode": "TBH",
                            "id": 5,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record Type",
                                    "from": 1,
                                    "to": 3,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "TBH",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record sequence number",
                                    "from": 4,
                                    "to": 9,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [
                                        "<#assign x = x+1>"
                                    ],
                                    "dataType": "CUSTOM",
                                    "dataFormat": "EXPRESSION",
                                    "defaultValue": "x",
                                    "leftPaddingSize": 6,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "SE number",
                                    "from": 10,
                                    "to": 19,
                                    "length": 0,
                                    "propertyName": "handhSeNumber",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 10,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 20,
                                    "to": 30,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Batch sequence number",
                                    "from": 31,
                                    "to": 33,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "1",
                                    "leftPaddingSize": 3,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 34,
                                    "to": 44,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File creation date",
                                    "from": 45,
                                    "to": 50,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "DATE",
                                    "dataFormat": "YYMMDD",
                                    "defaultValue": "CURRENT_DATE",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Currency Code",
                                    "from": 51,
                                    "to": 53,
                                    "length": 0,
                                    "propertyName": "handhCompanyCurrency",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "SOC reference number indicator",
                                    "from": 54,
                                    "to": 56,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "SOC reference number",
                                    "from": 57,
                                    "to": 62,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 6,
                                    "leftPaddingChar": "0",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 63,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                            "segmentList": [
                                {
                                    "index": 1,
                                    "xmltag": "Transaction Advice Basic",
                                    "segcode": "TAB",
                                    "id": 6,
                                    'expanded': true,
                                    "minOccurs": "0",
                                    "maxOccurs": "-1",
                                    "fieldList": [
                                        {
                                            "xmltag": "Record Type",
                                            "from": 1,
                                            "to": 3,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Record sequence number",
                                            "from": 4,
                                            "to": 9,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 10,
                                            "to": 11,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Cardmember account No",
                                            "from": 12,
                                            "to": 26,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 27,
                                            "to": 30,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 31,
                                            "to": 32,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 33,
                                            "to": 33,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Transaction type indicator",
                                            "from": 34,
                                            "to": 35,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Transaction value",
                                            "from": 36,
                                            "to": 43,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Transaction currency",
                                            "from": 44,
                                            "to": 46,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 47,
                                            "to": 54,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "AEME Approval Code",
                                            "from": 55,
                                            "to": 56,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 57,
                                            "to": 60,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Transaction Date",
                                            "from": 61,
                                            "to": 66,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 67,
                                            "to": 70,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Invoice/Credit Note number",
                                            "from": 71,
                                            "to": 79,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 80,
                                            "to": 82,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 83,
                                            "to": 85,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Card expiry date",
                                            "from": 86,
                                            "to": 89,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "SE name",
                                            "from": 90,
                                            "to": 104,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 105,
                                            "to": 109,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "SE address",
                                            "from": 110,
                                            "to": 124,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 125,
                                            "to": 129,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Cardmember name",
                                            "from": 130,
                                            "to": 155,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Product code",
                                            "from": 156,
                                            "to": 158,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 159,
                                            "to": 159,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Consultant Code",
                                            "from": 160,
                                            "to": 162,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 163,
                                            "to": 163,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "REF 1",
                                            "from": 164,
                                            "to": 172,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 173,
                                            "to": 173,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Departure date",
                                            "from": 174,
                                            "to": 179,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 180,
                                            "to": 180,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Travel Office Code",
                                            "from": 181,
                                            "to": 189,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 190,
                                            "to": 195,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Reserved",
                                            "from": 196,
                                            "to": 200,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        }
                                    ],
                                    "propertyName": "TIdTvlHandoffInvoiceHeaderEntity",
                                    "segmentList": [
                                        {
                                            "index": 2,
                                            "xmltag": "Transaction Advice Addendum",
                                            "segcode": "TAA",
                                            "id": 7,
                                            'expanded': true,
                                            "minOccurs": "0",
                                            "maxOccurs": "-1",
                                            "fieldList": [
                                                {
                                                    "xmltag": "Record type",
                                                    "from": 1,
                                                    "to": 3,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "TAB",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Record sequence number",
                                                    "from": 4,
                                                    "to": 9,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [
                                                        "<#assign x = x+1>"
                                                    ],
                                                    "dataType": "CUSTOM",
                                                    "dataFormat": "EXPRESSION",
                                                    "defaultValue": "x",
                                                    "leftPaddingSize": 6,
                                                    "leftPaddingChar": "0",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Cardmember account No",
                                                    "from": 10,
                                                    "to": 24,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 25,
                                                    "to": 28,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Carrier/Supplier Name",
                                                    "from": 29,
                                                    "to": 48,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Destination",
                                                    "from": 49,
                                                    "to": 68,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Government Sales Tax Amount",
                                                    "from": 69,
                                                    "to": 82,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Government Sales Tax Indicator",
                                                    "from": 83,
                                                    "to": 83,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 84,
                                                    "to": 89,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Agency commission amount",
                                                    "from": 90,
                                                    "to": 103,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Agency commission %",
                                                    "from": 104,
                                                    "to": 107,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 108,
                                                    "to": 108,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Agency rebate amount",
                                                    "from": 109,
                                                    "to": 122,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Agency rebate %",
                                                    "from": 123,
                                                    "to": 126,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 127,
                                                    "to": 128,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Product Specific Information",
                                                    "from": 129,
                                                    "to": 148,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 3",
                                                    "from": 149,
                                                    "to": 158,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 4",
                                                    "from": 159,
                                                    "to": 168,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Customer Initials",
                                                    "from": 169,
                                                    "to": 170,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Customer Surname",
                                                    "from": 171,
                                                    "to": 188,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Reserved",
                                                    "from": 189,
                                                    "to": 200,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                }
                                            ],
                                            "propertyName": "",
                                            "segmentList": [],
                                            "displaySegmentListAsSingleLine": false
                                        },
                                        {
                                            "index": 3,
                                            "xmltag": "Transaction Advice Mandatory ",
                                            "segcode": "TAM",
                                            "id": 8,
                                            'expanded': true,
                                            "minOccurs": "0",
                                            "maxOccurs": "-1",
                                            "fieldList": [
                                                {
                                                    "xmltag": "Record Type",
                                                    "from": 1,
                                                    "to": 3,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "SROC Record Sequence Number",
                                                    "from": 4,
                                                    "to": 9,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Cardmember Account Number",
                                                    "from": 10,
                                                    "to": 24,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 5",
                                                    "from": 25,
                                                    "to": 39,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 6",
                                                    "from": 40,
                                                    "to": 44,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 7",
                                                    "from": 45,
                                                    "to": 54,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "REF 2",
                                                    "from": 55,
                                                    "to": 78,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 79,
                                                    "to": 200,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                }
                                            ],
                                            "propertyName": "",
                                            "segmentList": [],
                                            "displaySegmentListAsSingleLine": false
                                        },
                                        {
                                            "index": 4,
                                            "xmltag": "Transaction Advice Ticket",
                                            "segcode": "TAT",
                                            "id": 9,
                                            'expanded': true,
                                            "minOccurs": "0",
                                            "maxOccurs": "-1",
                                            "fieldList": [
                                                {
                                                    "xmltag": "Record type",
                                                    "from": 1,
                                                    "to": 3,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Record sequence number",
                                                    "from": 4,
                                                    "to": 9,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Cardmember Account No",
                                                    "from": 10,
                                                    "to": 24,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Air Ticket Number",
                                                    "from": 25,
                                                    "to": 38,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Sales Tax Currency",
                                                    "from": 39,
                                                    "to": 41,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Sales Tax Amount",
                                                    "from": 42,
                                                    "to": 51,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Sales Tax Code",
                                                    "from": 52,
                                                    "to": 53,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Total Airport Tax Currency",
                                                    "from": 54,
                                                    "to": 56,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Total Airport Tax Amount",
                                                    "from": 57,
                                                    "to": 68,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "PNR Locator",
                                                    "from": 69,
                                                    "to": 79,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 80,
                                                    "to": 80,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Net remit indicator",
                                                    "from": 81,
                                                    "to": 81,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 82,
                                                    "to": 138,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 139,
                                                    "to": 139,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Conjunction ticket number suffix.",
                                                    "from": 140,
                                                    "to": 142,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "IATA Code",
                                                    "from": 143,
                                                    "to": 150,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Airline Commission %",
                                                    "from": 151,
                                                    "to": 153,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 154,
                                                    "to": 200,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                }
                                            ],
                                            "propertyName": "",
                                            "segmentList": [],
                                            "displaySegmentListAsSingleLine": false
                                        },
                                        {
                                            "index": 5,
                                            "xmltag": "Transaction Advice Ticket Further Information ",
                                            "segcode": "TAF",
                                            "id": 10,
                                            'expanded': true,
                                            "minOccurs": "0",
                                            "maxOccurs": "-1",
                                            "fieldList": [
                                                {
                                                    "xmltag": "Record type",
                                                    "from": 1,
                                                    "to": 3,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Record sequence number",
                                                    "from": 4,
                                                    "to": 9,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Cardmember account No",
                                                    "from": 10,
                                                    "to": 24,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Air ticket number",
                                                    "from": 25,
                                                    "to": 38,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket transaction code",
                                                    "from": 39,
                                                    "to": 42,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Date of ticket issue",
                                                    "from": 43,
                                                    "to": 50,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Fare Currency",
                                                    "from": 51,
                                                    "to": 53,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Fare Amount",
                                                    "from": 54,
                                                    "to": 65,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Ticket Tour Code",
                                                    "from": 66,
                                                    "to": 79,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Equivalent fare paid currency",
                                                    "from": 80,
                                                    "to": 82,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Equivalent Fare paid amount",
                                                    "from": 83,
                                                    "to": 94,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 95,
                                                    "to": 124,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Preceding Ticket Number",
                                                    "from": 125,
                                                    "to": 138,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                },
                                                {
                                                    "xmltag": "Filler",
                                                    "from": 139,
                                                    "to": 200,
                                                    "length": 0,
                                                    "propertyName": "",
                                                    "arguments": [],
                                                    "dataType": "TEXT",
                                                    "dataFormat": "",
                                                    "defaultValue": "",
                                                    "leftPaddingSize": 0,
                                                    "leftPaddingChar": "",
                                                    "rightPaddingSize": 0,
                                                    "rightPaddingChar": "",
                                                    "mandatory": true
                                                }
                                            ],
                                            "propertyName": "",
                                            "segmentList": [
                                                {
                                                    "index": 1,
                                                    "xmltag": "Transaction  Advice  Sector  Additional  Data ",
                                                    "segcode": "TAS",
                                                    "id": 11,
                                                    'expanded': true,
                                                    "minOccurs": "0",
                                                    "maxOccurs": "-1",
                                                    "fieldList": [
                                                        {
                                                            "xmltag": "Record type",
                                                            "from": 1,
                                                            "to": 3,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Record sequence No",
                                                            "from": 4,
                                                            "to": 9,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Cardmember Account No",
                                                            "from": 10,
                                                            "to": 24,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Air ticket number",
                                                            "from": 25,
                                                            "to": 38,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Conjunction Tkt No",
                                                            "from": 39,
                                                            "to": 52,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Sector Number",
                                                            "from": 53,
                                                            "to": 53,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Refund Sector indicator",
                                                            "from": 54,
                                                            "to": 54,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Carrier code",
                                                            "from": 55,
                                                            "to": 56,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Filler",
                                                            "from": 57,
                                                            "to": 57,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Flight number",
                                                            "from": 58,
                                                            "to": 61,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Sector Arrival time",
                                                            "from": 62,
                                                            "to": 65,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Sector Arrival date",
                                                            "from": 66,
                                                            "to": 73,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Sector Departure time",
                                                            "from": 74,
                                                            "to": 77,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Sector Departure date",
                                                            "from": 78,
                                                            "to": 85,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Departure Airport Code",
                                                            "from": 86,
                                                            "to": 88,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Filler",
                                                            "from": 89,
                                                            "to": 90,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Arrival Airport Code",
                                                            "from": 91,
                                                            "to": 93,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Filler",
                                                            "from": 94,
                                                            "to": 95,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Flight class",
                                                            "from": 96,
                                                            "to": 96,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Filler",
                                                            "from": 97,
                                                            "to": 97,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Stopover indicator",
                                                            "from": 98,
                                                            "to": 98,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Fare Basis Code",
                                                            "from": 99,
                                                            "to": 113,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        },
                                                        {
                                                            "xmltag": "Filler",
                                                            "from": 114,
                                                            "to": 200,
                                                            "length": 0,
                                                            "propertyName": "",
                                                            "arguments": [],
                                                            "dataType": "TEXT",
                                                            "dataFormat": "",
                                                            "defaultValue": "",
                                                            "leftPaddingSize": 0,
                                                            "leftPaddingChar": "",
                                                            "rightPaddingSize": 0,
                                                            "rightPaddingChar": "",
                                                            "mandatory": true
                                                        }
                                                    ],
                                                    "propertyName": "",
                                                    "segmentList": [],
                                                    "displaySegmentListAsSingleLine": false
                                                }
                                            ],
                                            "displaySegmentListAsSingleLine": false
                                        }
                                    ],
                                    "displaySegmentListAsSingleLine": false
                                },
                                {
                                    "index": 5,
                                    "xmltag": "Transaction Batch Trailer ",
                                    "segcode": "TBT",
                                    "id": 12,
                                    'expanded': true,
                                    "minOccurs": "0",
                                    "maxOccurs": "-1",
                                    "fieldList": [
                                        {
                                            "xmltag": "Record Type",
                                            "from": 1,
                                            "to": 3,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Record sequence number",
                                            "from": 4,
                                            "to": 9,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "SE number",
                                            "from": 10,
                                            "to": 19,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 20,
                                            "to": 30,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Batch sequence number",
                                            "from": 1,
                                            "to": 33,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 34,
                                            "to": 44,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Creation Date",
                                            "from": 45,
                                            "to": 50,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Total number Debit transactions",
                                            "from": 51,
                                            "to": 56,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Total amount Debit transactions",
                                            "from": 57,
                                            "to": 68,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Total number Credit transactions",
                                            "from": 69,
                                            "to": 74,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Total amount Credit transactions",
                                            "from": 75,
                                            "to": 86,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Total number xmltags",
                                            "from": 87,
                                            "to": 92,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        },
                                        {
                                            "xmltag": "Filler",
                                            "from": 93,
                                            "to": 200,
                                            "length": 0,
                                            "propertyName": "",
                                            "arguments": [],
                                            "dataType": "TEXT",
                                            "dataFormat": "",
                                            "defaultValue": "",
                                            "leftPaddingSize": 0,
                                            "leftPaddingChar": "",
                                            "rightPaddingSize": 0,
                                            "rightPaddingChar": "",
                                            "mandatory": true
                                        }
                                    ],
                                    "propertyName": "",
                                    "segmentList": [],
                                    "displaySegmentListAsSingleLine": false
                                }
                            ],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 6,
                            "xmltag": "Transaction File Summary",
                            "segcode": "TFS",
                            "id": 13,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record Type",
                                    "from": 1,
                                    "to": 3,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record sequence number",
                                    "from": 4,
                                    "to": 9,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Batch Count",
                                    "from": 10,
                                    "to": 13,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 14,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 7,
                            "xmltag": "First File Trailer ",
                            "segcode": "EOF1",
                            "id": 14,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record type",
                                    "from": 1,
                                    "to": 4,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Source identifier of originator",
                                    "from": 5,
                                    "to": 14,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 15,
                                    "to": 21,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Submission serial unique identifier",
                                    "from": 22,
                                    "to": 27,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File section number",
                                    "from": 28,
                                    "to": 31,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File sequence number",
                                    "from": 32,
                                    "to": 35,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 36,
                                    "to": 42,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File Creation Date(Julian Date Format)",
                                    "from": 43,
                                    "to": 47,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 48,
                                    "to": 48,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "File expiry date(Julian Date Format)",
                                    "from": 49,
                                    "to": 53,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 54,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        },
                        {
                            "index": 8,
                            "xmltag": "Second File Trailer",
                            "segcode": "EOF2",
                            "id": 15,
                            'expanded': true,
                            "minOccurs": "0",
                            "maxOccurs": "-1",
                            "fieldList": [
                                {
                                    "xmltag": "Record type",
                                    "from": 1,
                                    "to": 4,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record format",
                                    "from": 5,
                                    "to": 5,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Block length",
                                    "from": 6,
                                    "to": 10,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Record length",
                                    "from": 11,
                                    "to": 15,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Tape density",
                                    "from": 16,
                                    "to": 16,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Data set Position",
                                    "from": 17,
                                    "to": 17,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 18,
                                    "to": 38,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Block attribute",
                                    "from": 39,
                                    "to": 39,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                },
                                {
                                    "xmltag": "Filler",
                                    "from": 40,
                                    "to": 200,
                                    "length": 0,
                                    "propertyName": "",
                                    "arguments": [],
                                    "dataType": "TEXT",
                                    "dataFormat": "",
                                    "defaultValue": "",
                                    "leftPaddingSize": 0,
                                    "leftPaddingChar": "",
                                    "rightPaddingSize": 0,
                                    "rightPaddingChar": "",
                                    "mandatory": true
                                }
                            ],
                            "propertyName": "",
                            "segmentList": [],
                            "displaySegmentListAsSingleLine": false
                        }
                    ],
                    "displaySegmentListAsSingleLine": false
                }
            ]
        },
        "description":{
        "name":"manifest",
        "version":"1.0"
        },
        "delimiters":{
        "segment":" ",
        "field":",",
        "component":"AMEX_INVOICE_CHARGES_NEW",
        "subcomponent":"~"
        }
        }
]

const TREE_DATA_all1 = [
    {
        "field":",",
        "jsonName":"New_Json_name",
        "jsonId":6,
        "fixedLength":true,
        "segmentAsField":true,
        "parentSwap":false,
        "xmlns":"http://www.milyn.org/schema/edi-message-mapping-1.0.xsd",
        "segments":{
            "xmltag":"sample",
            "segmentList": [
                {
                    "index": 1,
                    "xmltag": "New XML Tree",
                    "segcode": "VOL1",
                    "id": 1,
                    'expanded': true,
                    "minOccurs": "0",
                    "maxOccurs": "-1",
                    "fieldList": [],
                    "propertyName": "newPropertyname",
                    "segmentList": [],
                    "displaySegmentListAsSingleLine": false
                }
            ]
        },
        "description":
            {
                "name":"manifest",
                "version":"1.0"
            },
        "delimiters":
            {
                "segment":" ",
                "field":",",
                "component":"AMEX_INVOICE_CHARGES_NEW",
                "subcomponent":"~"
            }
    }
]

TREE_DATA = TREE_DATA_all[0].segments.segmentList