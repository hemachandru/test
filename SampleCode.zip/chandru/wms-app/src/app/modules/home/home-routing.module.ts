import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DescriptorComponent } from './component/descriptor/descriptor.component';
import { HomeComponent } from './component/home/home.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {path:"", redirectTo:"edi",pathMatch: 'full'},
      {path:"home", component:HomeComponent},
      {path:"edi", component:DescriptorComponent}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
//appinitializer