import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class LoginService {

    constructor(private http: HttpClient) { }

    login(data) {
        data = { email: 'peter@klaven', password: 'cityslicka'};  //, password: 'cityslicka' 
        return this.http.post('https://reqres.in/api/login', data);
        // data = { userName: 'admin', password: 'password' };
        // return this.http.post('http://sit.infodynamic.net/travlogix/loginAccess', data);
    }

    getCustomerDetails() {
        return this.http.get('https://jsonplaceholder.typicode.com/users');
    }

}